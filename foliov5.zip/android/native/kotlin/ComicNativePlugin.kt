package app.comiclib.mobile

import android.Manifest
import android.app.Application
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.PowerManager
import android.provider.Settings
import androidx.activity.result.ActivityResult
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.getcapacitor.JSObject
import com.getcapacitor.Plugin
import com.getcapacitor.PluginCall
import com.getcapacitor.PluginMethod
import com.getcapacitor.annotation.ActivityCallback
import com.getcapacitor.annotation.CapacitorPlugin
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedOutputStream
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import java.util.UUID
import java.util.concurrent.Executors

/** Process-wide state shared by the plugin, the foreground service and the boot receiver. */
object ComicApp {
    lateinit var db: ComicDb
    var root: File? = null
    private var ready = false
    private val DEFAULT_SETTINGS = JSONObject("""{"theme":"system","density":2,"sort":"name","sortDir":"asc","readerMode":"paged","fit":"width","autoNextSec":8,"workers":0,"collision":"suffix","closeToTray":true,"healthOnStart":true,"autoExtractNew":false,"tagMode":"and","pageSize":20,"zoomPanSensitivity":1}""")

    /** Set when startup failed; the exception is rethrown to the UI (shown as "Could not start") instead of killing the process. */
    @Volatile var startupError: Throwable? = null

    @Synchronized fun ensure(ctx: Context) {
        if (ready) return
        try { start(ctx) } catch (t: Throwable) { startupError = t; android.util.Log.e("ComicApp", "Startup failed", t); throw t }
        startupError = null
    }

    private fun start(ctx: Context) {
        db = ComicDb(ctx.applicationContext)
        root = db.setting("root")?.let { File(it) }
        JobCenter.init(ctx, db)
        JobCenter.workers = workers()
        JobCenter.register("scan") { doScan(it) }
        JobCenter.register("extract") { doExtract(ctx.applicationContext, it) }
        JobCenter.register("verify") { doVerify(it) }
        JobCenter.register("thumbs") { doThumbs(ctx.applicationContext, it) }
        ready = true
    }

    fun settings(): JSONObject { val s = JSONObject(DEFAULT_SETTINGS.toString()); db.setting("settings")?.let { val o = JSONObject(it); o.keys().forEach { k -> s.put(k, o.get(k)) } }; return s }
    fun workers(): Int = ready.let { settings().optInt("workers", 0) }.let { if (it > 0) it else maxOf(1, minOf(3, Runtime.getRuntime().availableProcessors() / 2)) }
    fun thumbDir(ctx: Context) = File(ctx.filesDir, "thumbs").also { it.mkdirs() }
    fun abs(rel: String): File { val r = root ?: throw IllegalStateException("No mother folder selected"); return if (rel.isEmpty()) r else File(r, rel) }

    fun comicPages(dir: File): List<File> = (dir.listFiles() ?: emptyArray()).filter { it.isFile && Util.isImage(it.name) }.sortedWith { a, b -> Util.natural.compare(a.name, b.name) }

    fun makeThumb(ctx: Context, id: String, dir: File): Boolean {
        val first = comicPages(dir).firstOrNull() ?: return false
        fun render(w: Int, out: File): Boolean {
            val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }; BitmapFactory.decodeFile(first.path, o)
            if (o.outWidth <= 0) return false
            var sample = 1; while (o.outWidth / (sample * 2) >= w) sample *= 2
            val bmp = BitmapFactory.decodeFile(first.path, BitmapFactory.Options().apply { inSampleSize = sample }) ?: return false
            val h = w * 3 / 2; val scale = maxOf(w.toFloat() / bmp.width, h.toFloat() / bmp.height)
            val sw = (bmp.width * scale).toInt().coerceAtLeast(w); val sh = (bmp.height * scale).toInt().coerceAtLeast(h)
            val scaled = Bitmap.createScaledBitmap(bmp, sw, sh, true)
            val crop = Bitmap.createBitmap(scaled, (sw - w) / 2, 0, w, h)
            out.outputStream().use { crop.compress(Bitmap.CompressFormat.JPEG, 82, it) }
            bmp.recycle(); if (scaled != bmp) scaled.recycle(); return true
        }
        return runCatching { render(200, File(thumbDir(ctx), "${id}_s.jpg")) && render(400, File(thumbDir(ctx), "${id}_m.jpg")) }.getOrDefault(false)
    }

    fun upsertComic(ctx: Context, dir: File): Pair<Int, Boolean>? {
        val r = root ?: return null; val pages = comicPages(dir); if (pages.isEmpty()) return null
        val rel = dir.relativeTo(r).path.replace(File.separatorChar, '/'); val parts = rel.split('/')
        val size = pages.sumOf { it.length() }
        val id = db.rows("SELECT id FROM comics WHERE rel_path=?", rel).let { if (it.length() > 0) it.getJSONObject(0).getString("id") else "c_" + UUID.randomUUID().toString().replace("-", "").take(12) }
        db.tx {
            db.db.execSQL("INSERT INTO comics(id,rel_path,name,folder,author,pages,size,mtime,added_at) VALUES(?,?,?,?,?,?,?,?,?) ON CONFLICT(rel_path) DO UPDATE SET pages=excluded.pages,size=excluded.size,mtime=excluded.mtime",
                arrayOf(id, rel, parts.last(), parts.dropLast(1).joinToString("/"), if (parts.size > 1) parts[0] else "", pages.size, size, dir.lastModified(), System.currentTimeMillis()))
            db.ftsPut(id)
        }
        val ok = makeThumb(ctx, id, dir)
        db.db.execSQL("UPDATE comics SET thumb_rev=thumb_rev+1 WHERE id=?", arrayOf(id))
        return pages.size to ok
    }

    private fun doScan(job: Job) {
        val r = root ?: throw IllegalStateException("No mother folder selected")
        if (r.listFiles() == null) throw IllegalStateException("Folder is not readable. Allow all files access in Settings, or pick the folder again.")
        val prev = db.rows("SELECT id,rel_path,size,mtime,pages FROM comics")
        val prevMap = (0 until prev.length()).associate { prev.getJSONObject(it).let { o -> o.getString("rel_path") to (o.getLong("mtime") to o.getInt("pages")) } }
        val sr = Scanner.scan(r, prevMap) { d, c -> job.update(0.5, "$c comics in $d folders", 0) }
        db.tx {
            val prevRows = (0 until prev.length()).map { prev.getJSONObject(it) }
            val found = sr.comics.associateBy { it.rel }
            val gone = prevRows.filter { it.getString("rel_path") !in found }.toMutableList()
            val fresh = sr.comics.filter { f -> prevRows.none { it.getString("rel_path") == f.rel } }
            for (f in fresh) { // moved items keep their id, tags, favorites and progress
                val m = gone.firstOrNull { it.getInt("pages") == f.pages && (f.size < 0 || it.getLong("size") == f.size) && it.getString("rel_path").substringAfterLast('/') == f.name }
                    ?: gone.singleOrNull { it.getInt("pages") == f.pages && f.size >= 0 && it.getLong("size") == f.size }
                if (m != null) { gone.remove(m); db.db.execSQL("UPDATE comics SET rel_path=?,name=?,folder=?,author=? WHERE id=?", arrayOf(f.rel, f.name, f.folder, f.author, m.getString("id"))); db.ftsPut(m.getString("id")) }
            }
            for (g in gone) { db.db.execSQL("DELETE FROM comics WHERE id=?", arrayOf(g.getString("id"))); db.db.execSQL("DELETE FROM comic_fts WHERE comic_id=?", arrayOf(g.getString("id"))) }
            for (f in sr.comics) {
                val size = if (f.size >= 0) f.size else db.scalar("SELECT size FROM comics WHERE rel_path=?", f.rel)
                val id = "c_" + UUID.randomUUID().toString().replace("-", "").take(12)
                db.db.execSQL("INSERT INTO comics(id,rel_path,name,folder,author,pages,size,mtime,added_at) VALUES(?,?,?,?,?,?,?,?,?) ON CONFLICT(rel_path) DO UPDATE SET pages=excluded.pages,size=excluded.size,mtime=excluded.mtime",
                    arrayOf(id, f.rel, f.name, f.folder, f.author, f.pages, size, f.mtime, System.currentTimeMillis()))
            }
            db.ftsRebuild()
            val keep = HashSet<String>()
            for ((rel, g) in sr.archives) {
                keep += rel
                val parts = JSONArray(g.parts.map { it.name }); val parent = rel.substringBeforeLast('/', "")
                db.db.execSQL("INSERT INTO archives(id,rel_path,name,folder,author,size,parts,missing,encrypted,status,target_name) VALUES(?,?,?,?,?,?,?,?,0,'pending',?) ON CONFLICT(rel_path) DO UPDATE SET size=excluded.size,parts=excluded.parts,missing=excluded.missing",
                    arrayOf(Pipeline.sha256Text(rel).take(12).let { "a_$it" }, rel, g.base, parent, parent.substringBefore('/'), g.size, parts.toString(), JSONArray(g.missing).toString(), Util.sanitize(g.base)))
            }
            db.rows("SELECT rel_path,status FROM archives").let { a -> for (i in 0 until a.length()) a.getJSONObject(i).let { o -> if (o.getString("rel_path") !in keep && o.getString("status") != "deleted") db.db.execSQL("DELETE FROM archives WHERE rel_path=?", arrayOf(o.getString("rel_path"))) } }
            db.db.execSQL("DELETE FROM folders")
            val folders = HashMap<String, LongArray>()
            sr.dirs.forEach { folders.getOrPut(it) { longArrayOf(0, 0) } }
            for (c in sr.comics) { var p = c.folder; while (p.isNotEmpty()) { val f = folders.getOrPut(p) { longArrayOf(0, 0) }; f[0]++; f[1] += maxOf(0, c.size); p = p.substringBeforeLast('/', "") } }
            folders.forEach { (p, v) -> db.db.execSQL("INSERT INTO folders(path,name,parent,kind,comics,size) VALUES(?,?,?,?,?,?)", arrayOf(p, p.substringAfterLast('/'), p.substringBeforeLast('/', ""), if ('/' in p) "folder" else "author", v[0], v[1])) }
        }
        lastScan = JSONObject().put("comics", sr.comics.size).put("folders", sr.dirs.size).put("archives", sr.archives.size).put("added", 0).put("removed", 0).put("moved", 0).put("updated", 0).put("ms", 0)
        JobCenter.add("thumbs", "Generating thumbnails", JSONObject(), "background")
        if (settings().optBoolean("autoExtractNew")) enqueueExtract(db.rows("SELECT id FROM archives WHERE status='pending'").let { a -> (0 until a.length()).map { a.getJSONObject(it).getString("id") } }, null)
    }
    var lastScan = JSONObject()

    fun enqueueExtract(ids: List<String>, password: String?) {
        for (id in ids) {
            val a = db.rows("SELECT name,size,status FROM archives WHERE id=?", id).optJSONObject(0) ?: continue
            if (a.getString("status") in listOf("deleted", "extracting")) continue
            db.db.execSQL("UPDATE archives SET status='queued' WHERE id=?", arrayOf(id))
            JobCenter.add("extract", "Extract ${a.getString("name")}", JSONObject().put("archiveId", id).put("password", password ?: JSONObject.NULL), "extract", a.getLong("size"))
        }
    }

    private fun doExtract(ctx: Context, job: Job) {
        val id = job.payload.getString("archiveId"); val pw = job.payload.optString("password").takeIf { it.isNotEmpty() && it != "null" }
        val row = db.rows("SELECT * FROM archives WHERE id=?", id).optJSONObject(0) ?: return
        val r = root ?: return
        val primary = abs(row.getString("rel_path")); val dir = primary.parentFile!!
        val parts = JSONArray(row.getString("parts")).let { a -> (0 until a.length()).map { File(dir, a.getString(it)) } }
        val missing = JSONArray(row.getString("missing")).let { a -> (0 until a.length()).map { a.getString(it) } }
        db.db.execSQL("UPDATE archives SET status='extracting' WHERE id=?", arrayOf(id))
        val af = ArchiveFile(id, primary, parts, missing, row.getString("name"))
        val res = Pipeline.run(Pipeline.Ctx(db, r, af, pw, settings().optString("collision") == "ask",
            { f, m, b -> job.update(f, m, b) }, { job.abort != null }, { d -> upsertComic(ctx, d) }, { JobCenter.workers = maxOf(1, JobCenter.workers / 2) }))
        JobCenter.workers = workers()
        val status = res.getString("status")
        if (status == "cancelled") { db.db.execSQL("UPDATE archives SET status=? WHERE id=?", arrayOf(if (job.abort == "pause") "queued" else "pending", id)); return }
        val ok = status == "done" || status == "already_extracted"
        val layers = res.getJSONArray("layers"); val st = (0 until layers.length()).map { layers.getJSONObject(it).getString("status") }
        val tri = if (!ok) (if (status in listOf("needs_password", "needs_input", "no_images")) "amber" else "red") else if ("fail" in st) "red" else if ("warn" in st) "amber" else "green"
        val comics = res.optJSONArray("comics") ?: JSONArray(); val rels = (0 until comics.length()).map { File(comics.getJSONObject(it).getString("dir")).relativeTo(r).path.replace(File.separatorChar, '/') }
        val ids = rels.mapNotNull { rel -> db.rows("SELECT id FROM comics WHERE rel_path=?", rel).optJSONObject(0)?.getString("id") }
        val report = JSONObject().put("id", id).put("subject", row.getString("name")).put("archiveRelPath", row.getString("rel_path")).put("archiveSize", row.getLong("size")).put("comicIds", JSONArray(ids)).put("outputRelPaths", JSONArray(rels))
            .put("layers", layers).put("status", tri).put("state", if (ok) "done" else status).put("error", if (ok && tri != "red") JSONObject.NULL else res.opt("reason") ?: JSONObject.NULL).put("engineOutput", "").put("attempts", res.getJSONArray("attempts"))
            .put("warnings", res.getJSONArray("warnings")).put("manual", false).put("uncompressed", res.optLong("uncompressed")).put("extractedBytes", res.optLong("uncompressed")).put("updatedAt", System.currentTimeMillis())
        db.db.execSQL("INSERT INTO reports(id,json,updated_at) VALUES(?,?,?) ON CONFLICT(id) DO UPDATE SET json=excluded.json,updated_at=excluded.updated_at", arrayOf(id, report.toString(), System.currentTimeMillis()))
        res.optString("finalDir").takeIf { it.isNotEmpty() && it != "null" }?.let { db.db.execSQL("UPDATE archives SET target_name=? WHERE id=?", arrayOf(File(it).name, id)) }
        db.db.execSQL("UPDATE archives SET status=?,uncompressed=?,detail=?,encrypted=? WHERE id=?", arrayOf(if (ok) "done" else status, res.optLong("uncompressed"), res.optString("reason").takeIf { it != "null" }, if (pw != null || status == "needs_password") 1 else 0, id))
        ids.forEach { db.db.execSQL("UPDATE comics SET verification=? WHERE id=?", arrayOf(tri, it)) }
        notifyLibrary()
        if (status == "failed" || status == "quarantined") throw IllegalStateException(res.optString("reason"))
    }

    private fun doVerify(job: Job) {
        val id = job.payload.getString("id"); val r = root ?: return
        val rep = db.rows("SELECT json FROM reports WHERE id=?", id).optJSONObject(0)?.let { JSONObject(it.getString("json")) } ?: return
        val rels = rep.getJSONArray("outputRelPaths"); val layers = rep.getJSONArray("layers"); var bad = 0
        for (i in 0 until rels.length()) {
            val dir = abs(rels.getString(i)); val mf = File(dir, ".comiclib-manifest.json")
            if (!mf.exists()) { bad++; continue }
            val files = JSONObject(mf.readText()).getJSONArray("files")
            for (k in 0 until files.length()) { val f = files.getJSONObject(k); val file = File(dir, f.getString("path")); if (!file.exists() || Util.sha256(file).first != f.getString("sha256")) bad++; job.update((i + k.toDouble() / files.length()) / rels.length(), "Verifying ${rep.getString("subject")}", 0) }
        }
        layers.put(2, Pipeline.layer(3, if (bad == 0) "pass" else "fail", if (bad == 0) "All SHA-256 hashes match the manifest" else "$bad file(s) changed since extraction"))
        rep.put("layers", layers).put("status", if (bad == 0 && (0 until layers.length()).none { layers.getJSONObject(it).getString("status") == "fail" }) "green" else "red").put("updatedAt", System.currentTimeMillis())
        db.db.execSQL("UPDATE reports SET json=? WHERE id=?", arrayOf(rep.toString(), id)); notifyLibrary()
    }

    private fun doThumbs(ctx: Context, job: Job) {
        val rows = db.rows("SELECT id,rel_path FROM comics"); var done = 0
        for (i in 0 until rows.length()) {
            val o = rows.getJSONObject(i); val id = o.getString("id")
            if (!File(thumbDir(ctx), "${id}_m.jpg").exists()) makeThumb(ctx, id, abs(o.getString("rel_path")))
            job.update(i.toDouble() / maxOf(1, rows.length()), "${++done} of ${rows.length()}", 0)
            if (job.abort != null) return
        }
        listener?.invoke("thumbs", JSONObject())
    }

    var listener: ((String, Any) -> Unit)? = null
    fun notifyLibrary() { listener?.invoke("library", JSONObject()) }
}

class ComicNativeApp : Application() {
    override fun onCreate() { super.onCreate(); runCatching { ComicApp.ensure(this) } }  // failure is logged and surfaced by the plugin, not a launch crash
}

@CapacitorPlugin(name = "ComicNative")
class ComicNativePlugin : Plugin() {
    private val exec = Executors.newCachedThreadPool()
    private var pendingText: String? = null
    private var pendingExportFile: File? = null
    private var pendingExportFiles: List<File>? = null
    private var pendingExportName: String? = null
    private val db get() = ComicApp.db

    override fun load() {
        runCatching { ComicApp.ensure(context) }  // reported through invoke() so the UI can show it
        ComicApp.listener = { name, payload -> notifyListeners("event", JSObject().put("name", name).put("payload", payload)) }
        JobCenter.listeners.add { notifyListeners("event", JSObject().put("name", "jobs").put("payload", JobCenter.state())) }
    }

    private fun perm(): JSONObject {
        val allFiles = if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager() else ContextCompat.checkSelfPermission(context, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
        val notif = if (Build.VERSION.SDK_INT >= 33) ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED else NotificationManagerCompat.from(context).areNotificationsEnabled()
        val battery = context.getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(context.packageName)
        val saf = context.contentResolver.persistedUriPermissions.isNotEmpty()
        fun s(b: Boolean) = if (b) "granted" else "denied"
        return JSONObject().put("allFiles", s(allFiles)).put("safFolder", if (saf) "granted" else "denied").put("notifications", s(notif)).put("foregroundService", "granted").put("wakeLock", "granted").put("batteryOptimization", s(battery))
    }

    private fun settingsIntent(kind: String): Intent = when (kind) {
        "allFiles" -> if (Build.VERSION.SDK_INT >= 30) Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:${context.packageName}")) else Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${context.packageName}"))
        "notifications" -> Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName)
        "batteryOptimization" -> Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:${context.packageName}"))
        else -> Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${context.packageName}"))
    }.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

    private fun libraryJson(): JSONObject {
        val tags = HashMap<String, JSONArray>(); db.rows("SELECT comic_id,tag FROM comic_tags").let { a -> for (i in 0 until a.length()) a.getJSONObject(i).let { tags.getOrPut(it.getString("comic_id")) { JSONArray() }.put(it.getString("tag")) } }
        val comics = JSONArray(); db.rows("SELECT * FROM comics").let { a ->
            for (i in 0 until a.length()) { val r = a.getJSONObject(i)
                comics.put(JSONObject().put("id", r.getString("id")).put("path", ComicApp.abs(r.getString("rel_path")).path).put("relPath", r.getString("rel_path")).put("name", r.getString("name")).put("folder", r.getString("folder")).put("author", r.getString("author"))
                    .put("pages", r.getInt("pages")).put("size", r.getLong("size")).put("mtime", r.getLong("mtime")).put("addedAt", r.getLong("added_at")).put("favorite", r.getInt("favorite") == 1).put("read", r.getInt("read") == 1)
                    .put("lastPage", r.getInt("last_page")).put("lastReadAt", r.getLong("last_read_at")).put("tags", tags[r.getString("id")] ?: JSONArray()).put("thumbRev", r.getInt("thumb_rev"))
                    .apply { if (!r.isNull("fingerprint")) put("fp", JSONObject(r.getString("fingerprint"))); if (!r.isNull("verification")) put("verification", r.getString("verification")) }) } }
        val archives = JSONArray(); db.rows("SELECT * FROM archives WHERE status<>'deleted' ORDER BY rel_path").let { a ->
            for (i in 0 until a.length()) { val r = a.getJSONObject(i)
                archives.put(JSONObject().put("id", r.getString("id")).put("path", ComicApp.abs(r.getString("rel_path")).path).put("relPath", r.getString("rel_path")).put("name", r.getString("name")).put("folder", r.getString("folder")).put("author", r.getString("author"))
                    .put("size", r.getLong("size")).put("parts", JSONArray(r.getString("parts"))).put("missingParts", JSONArray(r.getString("missing"))).put("encrypted", r.getInt("encrypted") == 1).put("status", r.getString("status")).put("targetName", r.getString("target_name"))
                    .apply { if (!r.isNull("uncompressed")) put("uncompressed", r.getLong("uncompressed")); if (!r.isNull("detail")) put("detail", r.getString("detail")) }) } }
        val reports = JSONArray(); db.rows("SELECT json FROM reports").let { a -> for (i in 0 until a.length()) reports.put(JSONObject(a.getJSONObject(i).getString("json"))) }
        val trash = JSONArray(); db.rows("SELECT * FROM trash ORDER BY deleted_at DESC").let { a -> for (i in 0 until a.length()) a.getJSONObject(i).let { trash.put(JSONObject().put("id", it.getString("id")).put("name", it.getString("name")).put("originalPath", it.getString("original_path")).put("size", it.getLong("size")).put("deletedAt", it.getLong("deleted_at"))) } }
        return JSONObject().put("root", ComicApp.root?.path ?: JSONObject.NULL).put("comics", comics).put("folders", db.rows("SELECT path,name,parent,kind,comics,size FROM folders ORDER BY path")).put("archives", archives)
            .put("tags", db.rows("SELECT name,color FROM tags ORDER BY name")).put("reports", reports).put("trash", trash)
    }

    @PluginMethod
    fun invoke(call: PluginCall) {
        val method = call.getString("method") ?: return call.reject("method required")
        val args = call.getArray("args") ?: JSONArray()
        if (method == "pickFolder") return startActivityForResult(call, Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION or Intent.FLAG_GRANT_PREFIX_URI_PERMISSION), "pickResult")
        if (method == "pickTextFile") return startActivityForResult(call, Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*"), "textResult")
        if (method == "saveTextFile") { pendingText = args.getString(1); return startActivityForResult(call, Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("application/json").putExtra(Intent.EXTRA_TITLE, args.getString(0)), "saveResult") }
        if (method == "exportPage") {
            return try {
                ComicApp.ensure(context)
                val row = db.rows("SELECT name,rel_path FROM comics WHERE id=?", args.getString(0)).optJSONObject(0) ?: return call.reject("Comic not found")
                val pages = ComicApp.comicPages(ComicApp.abs(row.getString("rel_path")))
                val idx = args.getInt(1).coerceIn(0, maxOf(0, pages.size - 1))
                val file = pages.getOrNull(idx) ?: return call.reject("Page not found")
                val ext = Util.ext(file.name).ifEmpty { "jpg" }
                val mime = when (ext) { "png" -> "image/png"; "webp" -> "image/webp"; "gif" -> "image/gif"; "avif" -> "image/avif"; "bmp" -> "image/bmp"; else -> "image/jpeg" }
                val suggested = "${Util.sanitize(row.getString("name"))}_page_${"%03d".format(idx + 1)}.$ext"
                pendingExportFile = file
                pendingExportName = suggested
                startActivityForResult(call, Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType(mime).putExtra(Intent.EXTRA_TITLE, suggested), "exportPageResult")
            } catch (e: Throwable) { call.reject(e.message ?: "Export failed") }
        }
        if (method == "exportComic") {
            return try {
                ComicApp.ensure(context)
                val row = db.rows("SELECT name,rel_path FROM comics WHERE id=?", args.getString(0)).optJSONObject(0) ?: return call.reject("Comic not found")
                val pages = ComicApp.comicPages(ComicApp.abs(row.getString("rel_path")))
                if (pages.isEmpty()) return call.reject("No pages found to export")
                val suggested = "${Util.sanitize(row.getString("name"))}.cbz"
                pendingExportFiles = pages
                pendingExportName = suggested
                startActivityForResult(call, Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("application/zip").putExtra(Intent.EXTRA_TITLE, suggested), "exportComicResult")
            } catch (e: Throwable) { call.reject(e.message ?: "Export failed") }
        }
        if (method == "requestPermission") {
            val kind = args.getString(0)
            when (kind) {
                "notifications" -> if (Build.VERSION.SDK_INT >= 33) ActivityCompat.requestPermissions(activity, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 7) else context.startActivity(settingsIntent(kind))
                "wakeLock", "foregroundService" -> {}
                else -> context.startActivity(settingsIntent(kind))
            }
            return call.resolve(JSObject().put("result", perm()))
        }
        exec.execute {
            try {
                ComicApp.ensure(context)  // retries startup; a real failure (e.g. a migration error) is shown to the user with its message
                val r = dispatch(method, args)
                call.resolve(JSObject().put("result", r ?: JSONObject.NULL))
            } catch (e: Throwable) { android.util.Log.e("ComicNative", "invoke $method failed", e); call.reject((e.cause?.message ?: e.message ?: e.javaClass.simpleName)) }
        }
    }

    private fun idsOf(a: JSONArray, i: Int) = a.getJSONArray(i).let { x -> (0 until x.length()).map { x.getString(it) } }

    private fun dispatch(m: String, a: JSONArray): Any? {
        val root = ComicApp.root
        when (m) {
            "setSystemBars" -> { (activity as? MainActivity)?.applySystemBars(a.getBoolean(0)); return null }
            "thumbBase" -> return ComicApp.thumbDir(context).path
            "init" -> return JSONObject().put("platform", "android").put("appVersion", runCatching { context.packageManager.getPackageInfo(context.packageName, 0).versionName }.getOrNull() ?: "unknown").put("root", root?.path ?: JSONObject.NULL).put("settings", ComicApp.settings()).put("permissions", perm())
                .put("env", JSONObject().put("os", "Android ${Build.VERSION.RELEASE} (${Build.MODEL})").put("cpus", Runtime.getRuntime().availableProcessors()).put("freeBytes", (root ?: context.filesDir).usableSpace))
                .put("savedPasswordCount", db.scalar("SELECT COUNT(*) FROM passwords")).put("needsOnboarding", db.setting("onboarded") == null).put("demo", false).also { db.putSetting("onboarded", "1") }
            "setRoot" -> { ComicApp.root = File(a.getString(0)); db.putSetting("root", a.getString(0)); db.db.execSQL("DELETE FROM comics"); db.db.execSQL("DELETE FROM archives"); db.db.execSQL("DELETE FROM comic_fts"); return waitJob(JobCenter.add("scan", "Scanning library", JSONObject(), "scan")) }
            "getLibrary" -> return libraryJson()
            "scan" -> return waitJob(JobCenter.add("scan", "Scanning library", JSONObject(), "scan")).let { ComicApp.lastScan }
            "fixFolders" -> return waitJob(JobCenter.add("scan", "Scanning library", JSONObject(), "scan")).let { ComicApp.lastScan }
            "saveState" -> { saveState(a.getJSONObject(0)); return null }
            "pages" -> { val dir = db.rows("SELECT rel_path FROM comics WHERE id=?", a.getString(0)).optJSONObject(0)?.let { ComicApp.abs(it.getString("rel_path")) } ?: return JSONArray()
                if (!dir.exists() || !dir.isDirectory) throw IllegalStateException("Comic folder not found on storage. Try rescanning or checking folder permissions.")
                return JSONArray(ComicApp.comicPages(dir).map { JSONObject().put("name", it.name).put("url", it.path).put("size", it.length()) }) }
            "ensureThumb" -> { db.rows("SELECT rel_path FROM comics WHERE id=?", a.getString(0)).optJSONObject(0)?.let { ComicApp.makeThumb(context, a.getString(0), ComicApp.abs(it.getString("rel_path"))) }; return null }
            "readImage" -> { val f = File(a.getString(0)); if (!f.exists() || !f.canRead()) throw IllegalStateException("Image file is not readable: ${f.name}"); val bytes = f.readBytes(); val mime = when { bytes.size >= 4 && bytes[0] == 0x89.toByte() && bytes[1] == 0x50.toByte() && bytes[2] == 0x4E.toByte() && bytes[3] == 0x47.toByte() -> "image/png"; bytes.size >= 2 && bytes[0] == 0xFF.toByte() && bytes[1] == 0xD8.toByte() -> "image/jpeg"; bytes.size >= 12 && bytes[0] == 0x52.toByte() && bytes[1] == 0x49.toByte() && bytes[8] == 0x57.toByte() && bytes[9] == 0x45.toByte() -> "image/webp"; bytes.size >= 3 && bytes[0] == 0x47.toByte() && bytes[1] == 0x49.toByte() && bytes[2] == 0x46.toByte() -> "image/gif"; bytes.size >= 12 && bytes[4] == 0x66.toByte() && bytes[5] == 0x74.toByte() && bytes[6] == 0x79.toByte() && bytes[7] == 0x70.toByte() -> "image/avif"; bytes.size >= 2 && bytes[0] == 0x42.toByte() && bytes[1] == 0x4D.toByte() -> "image/bmp"; else -> when (Util.ext(f.name)) { "png" -> "image/png"; "webp" -> "image/webp"; "gif" -> "image/gif"; "avif" -> "image/avif"; "bmp" -> "image/bmp"; else -> "image/jpeg" } }; return "data:$mime;base64," + android.util.Base64.encodeToString(bytes, android.util.Base64.NO_WRAP) }
            "getJobs" -> return JobCenter.state()
            "extractAll" -> { ComicApp.enqueueExtract(db.rows("SELECT id FROM archives WHERE status='pending'").let { x -> (0 until x.length()).map { x.getJSONObject(it).getString("id") } }, null); return null }
            "extractArchives" -> { val o = a.optJSONObject(1); var ids = idsOf(a, 0); val pw = o?.optString("password")?.takeIf { it.isNotEmpty() }
                if (pw != null && o.optBoolean("applyToSimilar")) { db.db.execSQL("INSERT INTO passwords(id,label,blob) VALUES(?,?,?)", arrayOf("p_" + UUID.randomUUID().toString().take(8), "Added from extraction prompt", db.encrypt(pw))); ids = ids + db.rows("SELECT id FROM archives WHERE status='needs_password'").let { x -> (0 until x.length()).map { x.getJSONObject(it).getString("id") } } }
                ComicApp.enqueueExtract(ids.distinct(), pw); return null }
            "reverify" -> { idsOf(a, 0).forEach { JobCenter.add("verify", "Verify $it", JSONObject().put("id", it), "verify") }; return null }
            "jobControl" -> { when (a.getString(0)) { "pause" -> JobCenter.pauseAll(); "resume" -> JobCenter.resumeAll(); "cancel" -> JobCenter.cancel(a.optString(1).takeIf { it.isNotEmpty() && it != "null" }); "retry" -> JobCenter.retry(a.getString(1)); "clear" -> JobCenter.clearFinished() }; return null }
            "skipArchive" -> { db.db.execSQL("UPDATE archives SET status='skipped' WHERE id=?", arrayOf(a.getString(0))); return null }
            "markManual" -> { db.rows("SELECT json FROM reports WHERE id=?", a.getString(0)).optJSONObject(0)?.let { db.db.execSQL("UPDATE reports SET json=? WHERE id=?", arrayOf(JSONObject(it.getString("json")).put("manual", a.getBoolean(1)).toString(), a.getString(0))) }; return null }
            "openFolder" -> return null
            "createFolder" -> { val rel = listOf(a.getString(0), Util.sanitize(a.getString(1))).filter { it.isNotEmpty() }.joinToString("/"); ComicApp.abs(rel).mkdirs(); waitJob(JobCenter.add("scan", "Scanning library", JSONObject(), "scan")); return rel }
            "moveComics" -> return moveComics(idsOf(a, 0), a.getString(1))
            "previewDelete" -> return previewDelete(idsOf(a, 0))
            "confirmDelete" -> return confirmDelete(idsOf(a, 0))
            "trashList" -> return libraryJson().getJSONArray("trash")
            "trashRestore" -> { db.rows("SELECT * FROM trash WHERE id=?", a.getString(0)).optJSONObject(0)?.let { t -> val orig = File(t.getString("original_path")); File(t.getString("trash_path")).listFiles()?.forEach { f -> val d = File(orig.parentFile, f.name); if (d.exists()) throw IllegalStateException("Cannot restore: ${f.name} already exists"); f.renameTo(d) }; File(t.getString("trash_path")).deleteRecursively(); db.db.execSQL("DELETE FROM trash WHERE id=?", arrayOf(a.getString(0))); db.db.execSQL("UPDATE archives SET status='done' WHERE id=?", arrayOf(a.getString(0))); db.db.execSQL("INSERT INTO deletion_log(at,action,path) VALUES(?,?,?)", arrayOf(System.currentTimeMillis(), "restore", t.getString("original_path"))) }; ComicApp.notifyLibrary(); return null }
            "trashEmpty" -> { var n = 0; db.rows("SELECT * FROM trash").let { x -> for (i in 0 until x.length()) { val t = x.getJSONObject(i); File(t.getString("trash_path")).deleteRecursively(); db.db.execSQL("DELETE FROM trash WHERE id=?", arrayOf(t.getString("id"))); db.db.execSQL("DELETE FROM archives WHERE id=? AND status='deleted'", arrayOf(t.getString("id"))); db.db.execSQL("INSERT INTO deletion_log(at,action,path) VALUES(?,?,?)", arrayOf(System.currentTimeMillis(), "empty-trash", t.getString("original_path"))); n++ } }; return n }
            "listPasswords" -> return db.rows("SELECT id,label FROM passwords")
            "addPassword" -> { db.db.execSQL("INSERT INTO passwords(id,label,blob) VALUES(?,?,?)", arrayOf("p_" + UUID.randomUUID().toString().take(8), a.getString(0), db.encrypt(a.getString(1)))); return null }
            "removePassword" -> { db.db.execSQL("DELETE FROM passwords WHERE id=?", arrayOf(a.getString(0))); return null }
            "exportPasswords" -> return JSONArray(db.passwords())
            "sizeReport" -> return sizeReport()
            "folderCheck" -> { val sr = Scanner.scan(root ?: throw IllegalStateException("No mother folder selected"), emptyMap()) { _, _ -> }
                val lib = db.rows("SELECT rel_path FROM comics").let { x -> (0 until x.length()).map { x.getJSONObject(it).getString("rel_path") }.toSet() }; val disk = sr.comics.map { it.rel }.toSet(); val mm = JSONArray()
                (disk - lib).forEach { mm.put(JSONObject().put("path", it).put("reason", "On disk but not in the library")) }; (lib - disk).forEach { mm.put(JSONObject().put("path", it).put("reason", "In the library but missing on disk")) }
                return JSONObject().put("diskFolders", sr.dirs.size).put("diskComics", disk.size).put("libraryFolders", db.scalar("SELECT COUNT(*) FROM folders")).put("libraryComics", lib.size).put("mismatches", mm) }
            "backupDb" -> { val id = "backup-${System.currentTimeMillis()}.db"; val f = File(context.filesDir, "backups/$id").also { it.parentFile?.mkdirs() }; db.db.execSQL("VACUUM INTO '${f.path.replace("'", "''")}'"); return id }
            "restoreBackup" -> { val f = File(context.filesDir, "backups/${File(a.getString(0)).name}"); val dbf = context.getDatabasePath("library.db"); db.close(); listOf("-wal", "-shm").forEach { File(dbf.path + it).delete() }; f.copyTo(dbf, true); db.open(); ComicApp.notifyLibrary(); return null }
            "applyImport" -> return applyImport(a.getJSONObject(0))
            "runHealth" -> return health(a.getBoolean(0))
            "getPermissions" -> return perm()
            "openSystemSettings" -> { context.startActivity(settingsIntent(a.getString(0))); return null }
            "diagnostics" -> return "Folio v5\nPlatform: android ${Build.VERSION.RELEASE} (${Build.MODEL}), SDK ${Build.VERSION.SDK_INT}\nMother folder: ${root?.path}\nComics: ${db.scalar("SELECT COUNT(*) FROM comics")}\nFree space: ${(root ?: context.filesDir).usableSpace / 1048576} MB\nPermissions: ${perm()}\nJobs: ${JobCenter.list().joinToString { "${it.kind}:${it.state}" }}"
            "copyText" -> { context.getSystemService(ClipboardManager::class.java).setPrimaryClip(ClipData.newPlainText("Comic Library", a.getString(0))); return null }
        }
        throw IllegalArgumentException("Unknown method $m")
    }

    private fun waitJob(j: Job) { while (j.state == "queued" || j.state == "running" || j.state == "paused") Thread.sleep(80); if (j.state == "failed") throw IllegalStateException(j.error) }

    private fun saveState(p: JSONObject) = db.tx {
        p.optJSONArray("comics")?.let { cs -> for (i in 0 until cs.length()) { val c = cs.getJSONObject(i); val id = c.getString("id")
            if (c.has("favorite")) db.db.execSQL("UPDATE comics SET favorite=? WHERE id=?", arrayOf(if (c.getBoolean("favorite")) 1 else 0, id))
            if (c.has("read")) db.db.execSQL("UPDATE comics SET read=? WHERE id=?", arrayOf(if (c.getBoolean("read")) 1 else 0, id))
            if (c.has("lastPage")) db.db.execSQL("UPDATE comics SET last_page=?,last_read_at=? WHERE id=?", arrayOf(c.getInt("lastPage"), c.optLong("lastReadAt"), id))
            c.optJSONArray("tags")?.let { t -> db.db.execSQL("DELETE FROM comic_tags WHERE comic_id=?", arrayOf(id)); for (k in 0 until t.length()) { db.db.execSQL("INSERT OR IGNORE INTO tags(name) VALUES(?)", arrayOf(t.getString(k))); db.db.execSQL("INSERT OR IGNORE INTO comic_tags(comic_id,tag) VALUES(?,?)", arrayOf(id, t.getString(k))) }; db.ftsPut(id) } } }
        p.optJSONArray("tagDefs")?.let { d -> for (i in 0 until d.length()) db.db.execSQL("INSERT INTO tags(name,color) VALUES(?,?) ON CONFLICT(name) DO UPDATE SET color=excluded.color", arrayOf(d.getJSONObject(i).getString("name"), d.getJSONObject(i).optString("color").takeIf { it.isNotEmpty() })) }
        p.optJSONArray("deleteTags")?.let { d -> for (i in 0 until d.length()) { db.db.execSQL("DELETE FROM comic_tags WHERE tag=?", arrayOf(d.getString(i))); db.db.execSQL("DELETE FROM tags WHERE name=?", arrayOf(d.getString(i))) }; db.ftsRebuild() }
        p.optJSONObject("settings")?.let { s -> db.putSetting("settings", ComicApp.settings().also { cur -> s.keys().forEach { k -> cur.put(k, s.get(k)) } }.toString()); JobCenter.workers = ComicApp.workers() }
    }

    private fun counts() = JSONObject().put("comics", db.scalar("SELECT COUNT(*) FROM comics")).put("tags", db.scalar("SELECT COUNT(DISTINCT tag) FROM comic_tags")).put("favorites", db.scalar("SELECT COUNT(*) FROM comics WHERE favorite=1")).put("read", db.scalar("SELECT COUNT(*) FROM comics WHERE read=1"))

    /** Backup, single transaction, rollback on any error, before and after counts. */
    private fun applyImport(a: JSONObject): JSONObject {
        val before = counts(); val id = dispatch("backupDb", JSONArray()) as String
        try { saveState(JSONObject().put("comics", a.getJSONArray("comics")).put("tagDefs", a.getJSONArray("tagDefs")).put("settings", a.optJSONObject("settings") ?: JSONObject())); a.optJSONArray("passwords")?.let { p -> for (i in 0 until p.length()) dispatch("addPassword", JSONArray().put("Imported").put(p.getString(i))) } }
        catch (e: Exception) { dispatch("restoreBackup", JSONArray().put(id)); throw IllegalStateException("Import failed and was rolled back: ${e.message}") }
        ComicApp.notifyLibrary()
        return JSONObject().put("before", before).put("after", counts()).put("backupId", id).put("applied", a.getJSONArray("comics").length())
    }

    private fun moveComics(ids: List<String>, dest: String): JSONArray {
        val out = JSONArray(); val destDir = ComicApp.abs(dest).also { it.mkdirs() }
        for (id in ids) try {
            val row = db.rows("SELECT rel_path FROM comics WHERE id=?", id).optJSONObject(0) ?: throw IllegalStateException("Comic not found"); val src = ComicApp.abs(row.getString("rel_path"))
            if (src.parentFile?.canonicalPath == destDir.canonicalPath) throw IllegalStateException("Already in this folder")
            if (destDir.canonicalPath.startsWith(src.canonicalPath + File.separator)) throw IllegalStateException("Cannot move a folder into itself")
            val before = Pipeline.listFiles(src); var name = src.name; var n = 2; while (File(destDir, name).exists()) name = "${src.name} (${n++})"
            val target = File(destDir, name)
            if (!src.renameTo(target)) { src.copyRecursively(target, false); if (Pipeline.listFiles(target).size != before.size) { target.deleteRecursively(); throw IllegalStateException("Copy verification failed; original left in place") }; src.deleteRecursively() }
            if (Pipeline.listFiles(target).size != before.size) throw IllegalStateException("Post-move file count differs")
            out.put(JSONObject().put("id", id).put("ok", true))
        } catch (e: Exception) { out.put(JSONObject().put("id", id).put("ok", false).put("error", e.message)) }
        waitJob(JobCenter.add("scan", "Scanning library", JSONObject(), "scan")); return out
    }

    /** Fresh verification of the extracted folders against manifests, archive contents. Nothing is deleted here. */
    private fun freshVerify(id: String): List<String> {
        val row = db.rows("SELECT * FROM archives WHERE id=?", id).optJSONObject(0) ?: return listOf("Archive not found")
        val rep = db.rows("SELECT json FROM reports WHERE id=?", id).optJSONObject(0)?.let { JSONObject(it.getString("json")) }
        if (rep == null || !(rep.getString("status") == "green" || (rep.optBoolean("manual") && rep.getString("status") == "amber"))) return listOf("Archive is not fully verified (green)")
        val primary = ComicApp.abs(row.getString("rel_path")); val dir = primary.parentFile!!; val errs = ArrayList<String>()
        val parts = JSONArray(row.getString("parts")); for (i in 0 until parts.length()) if (!File(dir, parts.getString(i)).exists()) errs += "Archive part is missing: ${parts.getString(i)}"
        if (errs.isNotEmpty()) return errs
        val af = ArchiveFile(id, primary, (0 until parts.length()).map { File(dir, parts.getString(it)) }, emptyList(), row.getString("name"))
        val ents = runCatching { Sz(af).open(null).use { it.entries() } }.recoverCatching { e -> db.passwords().firstNotNullOfOrNull { pw -> runCatching { Sz(af).open(pw).use { it.entries() } }.getOrNull() } ?: throw e }.getOrElse { return listOf("Cannot read the archive: ${it.message}") }
        val plan = Pipeline.plan(row.getString("name"), ents); val out = File(dir, row.getString("target_name"))
        if (!out.exists()) return listOf("Extracted folder is missing: ${out.name}")
        val have = Pipeline.listFiles(out).toMap()
        for ((e, d) in plan.files) { val s = have[d]; if (s == null) errs += "missing: $d" else if (s != e.size) errs += "size differs: $d" else if (e.crc != null && Util.sha256(File(out, d)).second != e.crc) errs += "checksum differs: $d" }
        return errs.take(20)
    }

    private fun previewDelete(ids: List<String>): JSONObject {
        val ok = JSONArray(); val bad = JSONArray(); var total = 0L
        for (id in ids) { val row = db.rows("SELECT name,size FROM archives WHERE id=?", id).optJSONObject(0) ?: continue; val errs = freshVerify(id)
            if (errs.isNotEmpty()) bad.put(JSONObject().put("id", id).put("name", row.getString("name")).put("reason", errs.joinToString("; ")))
            else { ok.put(JSONObject().put("id", id).put("name", row.getString("name")).put("size", row.getLong("size")).put("folders", db.rows("SELECT json FROM reports WHERE id=?", id).getJSONObject(0).let { JSONObject(it.getString("json")).getJSONArray("outputRelPaths") })); total += row.getLong("size") } }
        return JSONObject().put("ok", bad.length() == 0 && ok.length() > 0).put("archives", ok).put("totalBytes", total).put("failures", bad)
    }

    private fun confirmDelete(ids: List<String>): JSONObject {
        val fails = JSONArray(); var moved = 0; val root = ComicApp.root ?: throw IllegalStateException("No mother folder")
        for (id in ids) { val row = db.rows("SELECT * FROM archives WHERE id=?", id).optJSONObject(0) ?: continue; val errs = freshVerify(id)
            if (errs.isNotEmpty()) { fails.put(JSONObject().put("id", id).put("reason", errs.joinToString("; "))); continue }
            val tdir = File(root, ".comiclib/trash/$id-${System.currentTimeMillis()}").also { it.mkdirs() }; val primary = ComicApp.abs(row.getString("rel_path")); val parts = JSONArray(row.getString("parts"))
            for (i in 0 until parts.length()) File(primary.parentFile, parts.getString(i)).renameTo(File(tdir, parts.getString(i)))
            db.db.execSQL("INSERT INTO trash(id,name,original_path,trash_path,size,deleted_at) VALUES(?,?,?,?,?,?)", arrayOf(id, row.getString("name"), primary.path, tdir.path, row.getLong("size"), System.currentTimeMillis()))
            db.db.execSQL("INSERT INTO deletion_log(at,action,path,detail) VALUES(?,?,?,?)", arrayOf(System.currentTimeMillis(), "trash", primary.path, "moved to ${tdir.path}"))
            db.db.execSQL("UPDATE archives SET status='deleted' WHERE id=?", arrayOf(id)); moved++ }
        ComicApp.notifyLibrary(); return JSONObject().put("ok", fails.length() == 0).put("moved", moved).put("failures", fails)
    }

    private fun sizeReport(): JSONObject {
        val root = ComicApp.root ?: throw IllegalStateException("No mother folder selected")
        val rootBytes = root.walkTopDown().filter { it.isFile && !it.relativeTo(root).path.startsWith(".") }.sumOf { it.length() }
        val per = db.rows("SELECT CASE WHEN author='' THEN '(root)' ELSE author END AS folder, SUM(size) AS bytes FROM comics GROUP BY author")
        val arch = db.rows("SELECT CASE WHEN author='' THEN '(root)' ELSE author END AS folder, COUNT(*) AS n, SUM(size) AS b FROM archives WHERE status<>'deleted' GROUP BY author")
        val m = HashMap<String, JSONObject>(); for (i in 0 until per.length()) per.getJSONObject(i).let { m[it.getString("folder")] = JSONObject().put("folder", it.getString("folder")).put("bytes", it.getLong("bytes")).put("archives", 0).put("archiveBytes", 0) }
        for (i in 0 until arch.length()) arch.getJSONObject(i).let { o -> m.getOrPut(o.getString("folder")) { JSONObject().put("folder", o.getString("folder")).put("bytes", 0) }.put("archives", o.getInt("n")).put("archiveBytes", o.getLong("b")) }
        val cmp = JSONArray(); db.rows("SELECT name,uncompressed,id FROM archives WHERE uncompressed IS NOT NULL AND status='done'").let { x -> for (i in 0 until x.length()) x.getJSONObject(i).let { o -> val ex = db.scalar("SELECT COALESCE(SUM(size),0) FROM comics WHERE rel_path IN (SELECT value FROM json_each((SELECT json_extract(json,'\$.outputRelPaths') FROM reports WHERE id=?)))", o.getString("id")); cmp.put(JSONObject().put("archive", o.getString("name")).put("uncompressed", o.getLong("uncompressed")).put("extracted", ex).put("ok", ex <= o.getLong("uncompressed") && ex >= o.getLong("uncompressed") * 0.98)) } }
        return JSONObject().put("rootBytes", rootBytes).put("archiveBytes", db.scalar("SELECT COALESCE(SUM(size),0) FROM archives WHERE status<>'deleted'")).put("extractedBytes", db.scalar("SELECT COALESCE(SUM(size),0) FROM comics")).put("archiveUncompressed", db.scalar("SELECT COALESCE(SUM(uncompressed),0) FROM archives")).put("perFolder", JSONArray(m.values.toList())).put("comparisons", cmp)
    }

    private fun health(repair: Boolean): JSONObject {
        val log = JSONArray(); val checks = JSONArray()
        fun add(id: String, title: String, st: String, sum: String, det: List<String> = emptyList(), rep: Boolean = false) = checks.put(JSONObject().put("id", id).put("title", title).put("status", st).put("summary", sum).put("details", JSONArray(det)).put("repairable", rep))
        val integ = db.integrity(); var comics = db.scalar("SELECT COUNT(*) FROM comics"); var fts = db.scalar("SELECT COUNT(*) FROM comic_fts")
        if (repair && comics != fts) { fts = db.ftsRebuild(); log.put("Rebuilt full-text index ($fts rows)") }
        add("db", "Database integrity", if (integ != listOf("ok")) "red" else if (comics == fts) "green" else "amber", if (integ != listOf("ok")) "Integrity check failed" else if (comics == fts) "Healthy, schema v${db.db.version}" else "Search index out of sync", integ.take(5), comics != fts)
        val root = ComicApp.root; val missing = ArrayList<String>()
        db.rows("SELECT id,name,rel_path FROM comics").let { x -> for (i in 0 until x.length()) { val o = x.getJSONObject(i); val id = o.getString("id"); if (!ComicApp.abs(o.getString("rel_path")).exists()) missing += o.getString("name") else if (!File(ComicApp.thumbDir(context), "${id}_m.jpg").exists() && repair) ComicApp.makeThumb(context, id, ComicApp.abs(o.getString("rel_path"))) } }
        if (repair && missing.isNotEmpty()) { waitJob(JobCenter.add("scan", "Scanning library", JSONObject(), "scan")); log.put("Rescanned library: removed ${missing.size} missing comic(s)") }
        add("disk", "Library versus disk", if (missing.isEmpty() || repair) "green" else "amber", if (missing.isEmpty() || repair) "Library matches the disk" else "${missing.size} comics missing on disk", missing.take(30), missing.isNotEmpty())
        val noThumb = db.rows("SELECT id,name FROM comics").let { x -> (0 until x.length()).map { x.getJSONObject(it) }.filter { !File(ComicApp.thumbDir(context), "${it.getString("id")}_m.jpg").exists() } }
        add("thumbs", "Thumbnails", if (noThumb.isEmpty()) "green" else "amber", if (noThumb.isEmpty()) "All thumbnails present" else "${noThumb.size} missing or corrupt", noThumb.take(20).map { it.getString("name") }, noThumb.isNotEmpty())
        val orphan = db.scalar("SELECT COUNT(*) FROM comic_tags WHERE comic_id NOT IN (SELECT id FROM comics)"); if (repair && orphan > 0) { db.db.execSQL("DELETE FROM comic_tags WHERE comic_id NOT IN (SELECT id FROM comics)"); log.put("Removed $orphan orphaned tag link(s)") }
        add("meta", "Metadata consistency", if (orphan == 0L || repair) "green" else "amber", if (orphan == 0L || repair) "Tags consistent" else "$orphan orphaned tag link(s)", emptyList(), orphan > 0)
        val dups = db.scalar("SELECT COUNT(*) FROM (SELECT fingerprint FROM comics WHERE fingerprint IS NOT NULL GROUP BY fingerprint HAVING COUNT(*)>1)")
        add("dups", "Duplicate comics", if (dups == 0L) "green" else "amber", if (dups == 0L) "No duplicates found" else "$dups duplicate group(s)")
        val p = perm(); val okp = p.getString("allFiles") == "granted" && p.getString("notifications") == "granted"
        add("env", "Storage, permissions and service", if (okp) "green" else "amber", "${(root ?: context.filesDir).usableSpace / 1073741824} GB free, ${if (okp) "permissions granted" else "a permission is off"}, queue ${if (JobCenter.paused) "paused" else "running"}")
        return JSONObject().put("ranAt", System.currentTimeMillis()).put("checks", checks).put("log", log)
    }

    @ActivityCallback
    private fun pickResult(call: PluginCall?, r: ActivityResult) {
        val uri = r.data?.data ?: return call?.resolve(JSObject().put("result", JSONObject.NULL)) ?: Unit
        runCatching { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION) }
        val doc = android.provider.DocumentsContract.getTreeDocumentId(uri); val vol = doc.substringBefore(':'); val sub = doc.substringAfter(':', "")
        val path = if (vol == "primary") "${Environment.getExternalStorageDirectory().path}/$sub" else "/storage/$vol/$sub"
        call?.resolve(JSObject().put("result", path.trimEnd('/')))
    }

    @ActivityCallback
    private fun textResult(call: PluginCall?, r: ActivityResult) {
        val uri = r.data?.data ?: return call?.resolve(JSObject().put("result", JSONObject.NULL)) ?: Unit
        call?.resolve(JSObject().put("result", context.contentResolver.openInputStream(uri)!!.bufferedReader().use { it.readText() }))
    }

    @ActivityCallback
    private fun saveResult(call: PluginCall?, r: ActivityResult) {
        val uri = r.data?.data ?: return call?.resolve(JSObject().put("result", JSONObject.NULL)) ?: Unit
        context.contentResolver.openOutputStream(uri)!!.use { it.write((pendingText ?: "").toByteArray()) }
        call?.resolve(JSObject().put("result", uri.toString()))
    }

    @ActivityCallback
    private fun exportPageResult(call: PluginCall?, r: ActivityResult) {
        val uri = r.data?.data
        val src = pendingExportFile
        val name = pendingExportName
        pendingExportFile = null
        pendingExportName = null
        if (uri == null || src == null) {
            call?.resolve(JSObject().put("result", JSONObject().put("ok", false).put("cancelled", true)))
            return
        }
        exec.execute {
            try {
                context.contentResolver.openOutputStream(uri)?.use { out ->
                    src.inputStream().use { inp -> inp.copyTo(out) }
                } ?: throw IllegalStateException("Cannot open destination file")
                call?.resolve(JSObject().put("result", JSONObject().put("ok", true).put("filename", name ?: src.name).put("pages", 1)))
            } catch (e: Throwable) {
                call?.reject(e.message ?: "Failed to export page")
            }
        }
    }

    @ActivityCallback
    private fun exportComicResult(call: PluginCall?, r: ActivityResult) {
        val uri = r.data?.data
        val files = pendingExportFiles
        val name = pendingExportName
        pendingExportFiles = null
        pendingExportName = null
        if (uri == null || files == null) {
            call?.resolve(JSObject().put("result", JSONObject().put("ok", false).put("cancelled", true)))
            return
        }
        exec.execute {
            try {
                context.contentResolver.openOutputStream(uri)?.use { rawOut ->
                    ZipOutputStream(BufferedOutputStream(rawOut)).use { zos ->
                        zos.setLevel(0)
                        for (f in files) {
                            zos.putNextEntry(ZipEntry(f.name))
                            f.inputStream().use { inp -> inp.copyTo(zos) }
                            zos.closeEntry()
                        }
                    }
                } ?: throw IllegalStateException("Cannot open destination archive")
                call?.resolve(JSObject().put("result", JSONObject().put("ok", true).put("filename", name ?: "comic.cbz").put("pages", files.size)))
            } catch (e: Throwable) {
                call?.reject(e.message ?: "Failed to export comic")
            }
        }
    }
}
