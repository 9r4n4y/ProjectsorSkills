import { useEffect, useState } from "react";
import { Eye, EyeOff, Lock, ShieldCheck } from "lucide-react";
import type { AppLockConfig } from "@comiclib/shared";
import { verifyAnyPassword } from "@/lib/appLock";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/controls";

const MAX_ATTEMPTS = 5;
const COOLDOWN_MS = 30_000;

/**
 * Full-screen App Lock gate rendered INSTEAD of the main app shell whenever locked.
 * Because the library, Edge Panel, Quick Look, and Reader are not mounted while locked,
 * no shortcut, Back button, or overlay can bypass authentication.
 */
export function AppLockGate({ lock, onUnlock }: { lock: AppLockConfig; onUnlock: () => void }) {
  const [pw, setPw] = useState("");
  const [show, setShow] = useState(false);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const [fails, setFails] = useState(0);
  const [cooldownUntil, setCooldownUntil] = useState(0);
  const [now, setNow] = useState(() => Date.now());

  useEffect(() => {
    if (cooldownUntil <= Date.now()) return;
    const id = setInterval(() => setNow(Date.now()), 500);
    return () => clearInterval(id);
  }, [cooldownUntil]);

  const remainSec = Math.max(0, Math.ceil((cooldownUntil - now) / 1000));
  const cooling = remainSec > 0;

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (busy || cooling || !pw) return;
    setBusy(true);
    setErr(null);
    try {
      const matched = await verifyAnyPassword(pw, lock.slots);
      if (matched) {
        setPw("");
        setFails(0);
        onUnlock();
      } else {
        const nextFails = fails + 1;
        setFails(nextFails);
        setPw("");
        if (nextFails >= MAX_ATTEMPTS) {
          setCooldownUntil(Date.now() + COOLDOWN_MS);
          setFails(0);
          setErr("Too many wrong attempts. Please wait 30 seconds.");
        } else {
          setErr(`Incorrect password (${MAX_ATTEMPTS - nextFails} ${MAX_ATTEMPTS - nextFails === 1 ? "try" : "tries"} left).`);
        }
      }
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="flex min-h-dvh w-full items-center justify-center p-5 text-fg">
      <form
        onSubmit={(e) => void submit(e)}
        className="flex w-full max-w-sm flex-col gap-5 rounded-[28px] border-[2.5px] border-ink bg-surface p-6 shadow-[0_6px_0_var(--ink)]"
        aria-label="Unlock Folio"
      >
        <div className="flex flex-col items-center gap-2 text-center">
          <div className="flex size-14 items-center justify-center rounded-[18px] border-[2.5px] border-ink bg-lilac text-on shadow-[0_4px_0_var(--ink)]">
            <Lock className="size-6" />
          </div>
          <h1 className="font-display text-2xl">Folio is locked</h1>
          <p className="text-[13px] text-sub">
            Enter {lock.slots.length > 1 ? `any of your ${lock.slots.length} passwords` : "your password"} to unlock.
          </p>
        </div>

        <div className="flex flex-col gap-2">
          <div className="relative">
            <Input
              type={show ? "text" : "password"}
              value={pw}
              onChange={(e) => setPw(e.target.value)}
              placeholder="Enter password"
              aria-label="App password"
              autoFocus
              autoComplete="current-password"
              disabled={busy || cooling}
              className="pr-11"
            />
            <button
              type="button"
              aria-label={show ? "Hide password" : "Show password"}
              onClick={() => setShow((v) => !v)}
              className="absolute right-2 top-1/2 flex size-8 -translate-y-1/2 items-center justify-center rounded-full text-sub hover:bg-muted hover:text-fg"
            >
              {show ? <EyeOff className="size-4" /> : <Eye className="size-4" />}
            </button>
          </div>
          {err && (
            <p className="text-center text-xs font-bold text-bad" role="alert">
              {err}
            </p>
          )}
          {cooling && (
            <p className="text-center text-xs font-bold text-warn">
              Try again in {remainSec}s
            </p>
          )}
        </div>

        <Button type="submit" size="lg" disabled={busy || cooling || !pw} className="w-full">
          <ShieldCheck />
          {busy ? "Verifying..." : "Unlock"}
        </Button>
      </form>
    </div>
  );
}
