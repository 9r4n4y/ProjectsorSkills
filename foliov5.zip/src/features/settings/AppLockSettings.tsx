import { useState } from "react";
import { Check, KeyRound, Lock, Plus, ShieldCheck, Trash2, Unlock } from "lucide-react";
import type { AppLockConfig, AppLockSlot } from "@comiclib/shared";
import { createPasswordSlot, hasActiveAppLock, verifyAnyPassword } from "@/lib/appLock";
import { useStore } from "@/lib/store";
import { Button } from "@/components/ui/button";
import { Badge, Input, Segmented } from "@/components/ui/controls";
import { Card } from "@/components/PageShell";
import { cn } from "@/utils/cn";

const IDLE_PRESETS = [1, 2, 5, 10, 30] as const;

const DEFAULT_LOCK: AppLockConfig = {
  enabled: false,
  mode: "close",
  idleMinutes: 5,
  slots: [],
};

export function AppLockSettings({ onLockNow }: { onLockNow?: () => void }) {
  const settings = useStore((s) => s.settings);
  const setSettings = useStore((s) => s.setSettings);
  const toast = useStore((s) => s.toast);

  const lock: AppLockConfig = settings.appLock ?? DEFAULT_LOCK;
  const active = hasActiveAppLock(lock);

  // Require verifying with ANY one of the configured passwords before editing/resetting slots or disabling lock
  const [verified, setVerified] = useState(false);
  const [verifyInput, setVerifyInput] = useState("");
  const [verifyErr, setVerifyErr] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const [editingSlot, setEditingSlot] = useState<1 | 2 | 3 | null>(null);
  const [newPass, setNewPass] = useState("");
  const [confirmPass, setConfirmPass] = useState("");
  const [slotErr, setSlotErr] = useState<string | null>(null);

  const canManage = !active || verified;

  const saveLock = (next: AppLockConfig) => {
    setSettings({ appLock: next });
  };

  const handleVerify = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!verifyInput || busy) return;
    setBusy(true);
    setVerifyErr(null);
    try {
      const match = await verifyAnyPassword(verifyInput, lock.slots);
      if (match) {
        setVerified(true);
        setVerifyInput("");
        toast(`Verified with ${match.label}`);
      } else {
        setVerifyErr("Incorrect password. Enter any one of your active passwords.");
      }
    } finally {
      setBusy(false);
    }
  };

  const handleSaveSlot = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingSlot || busy) return;
    if (newPass.length < 4) {
      setSlotErr("Password must be at least 4 characters.");
      return;
    }
    if (newPass !== confirmPass) {
      setSlotErr("Passwords do not match.");
      return;
    }
    setBusy(true);
    setSlotErr(null);
    try {
      const slot = await createPasswordSlot(editingSlot, newPass, `Password ${editingSlot}`);
      const nextSlots: AppLockSlot[] = [...lock.slots.filter((s) => s.id !== editingSlot), slot].sort((a, b) => a.id - b.id);
      saveLock({ ...lock, enabled: true, slots: nextSlots });
      setVerified(true);
      setEditingSlot(null);
      setNewPass("");
      setConfirmPass("");
      toast(`Saved Password ${editingSlot}`);
    } finally {
      setBusy(false);
    }
  };

  const handleRemoveSlot = (id: 1 | 2 | 3) => {
    const nextSlots = lock.slots.filter((s) => s.id !== id);
    if (nextSlots.length === 0) {
      saveLock({ ...lock, enabled: false, slots: [] });
      setVerified(false);
      toast("App Lock disabled (all passwords removed)");
    } else {
      saveLock({ ...lock, slots: nextSlots });
      toast(`Removed Password ${id}`);
    }
  };

  const handleDisableLock = () => {
    saveLock({ ...lock, enabled: false, slots: [] });
    setVerified(false);
    setEditingSlot(null);
    toast("App Lock turned off");
  };

  return (
    <Card
      title="App Lock & Passwords"
      actions={
        <Badge tone={active ? "ok" : undefined}>
          {active ? `Locked (${lock.slots.length}/3)` : "Off"}
        </Badge>
      }
    >
      <p className="mb-3 text-[13px] text-sub">
        Protect Folio on Android, PC, and Web with up to 3 independent passwords (PBKDF2-SHA256). Any one of the 3 passwords unlocks the app and can reset or change any of the other slots.
      </p>

      {active && !verified ? (
        <form onSubmit={(e) => void handleVerify(e)} className="flex flex-col gap-2.5 rounded-[18px] border-2 border-ink bg-muted p-3.5">
          <div className="flex items-center gap-2 text-xs font-bold text-fg">
            <Lock className="size-4 text-accent" />
            Enter any one of your {lock.slots.length} passwords to manage or reset App Lock
          </div>
          <div className="flex flex-wrap gap-2">
            <Input
              type="password"
              value={verifyInput}
              onChange={(e) => setVerifyInput(e.target.value)}
              placeholder="Enter any active password"
              aria-label="Verify active password"
              autoComplete="current-password"
              className="min-w-0 flex-1"
            />
            <Button type="submit" disabled={busy || !verifyInput}>
              <ShieldCheck />
              {busy ? "Checking..." : "Verify"}
            </Button>
          </div>
          {verifyErr && <p className="text-xs font-bold text-bad">{verifyErr}</p>}
          {onLockNow && (
            <div className="pt-1">
              <Button type="button" variant="outline" size="sm" onClick={onLockNow}>
                <Lock />Lock app now
              </Button>
            </div>
          )}
        </form>
      ) : (
        <div className="flex flex-col gap-4">
          {/* 3 Password Slots */}
          <div className="flex flex-col gap-2">
            <div className="text-xs font-bold text-sub">Password slots (up to 3 — any one unlocks or resets any slot)</div>
            <div className="grid gap-2 sm:grid-cols-3">
              {([1, 2, 3] as const).map((id) => {
                const slot = lock.slots.find((s) => s.id === id);
                return (
                  <div
                    key={id}
                    className={cn(
                      "flex flex-col justify-between gap-2 rounded-[16px] border-2 border-ink p-3",
                      slot ? "bg-mint/25" : "bg-muted",
                    )}
                  >
                    <div className="flex items-center justify-between gap-2">
                      <span className="flex items-center gap-1.5 text-sm font-bold">
                        <KeyRound className="size-4" />
                        Password {id}
                      </span>
                      <Badge tone={slot ? "ok" : undefined}>{slot ? "Set" : "Empty"}</Badge>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <Button
                        type="button"
                        size="sm"
                        variant={slot ? "outline" : "secondary"}
                        className="flex-1"
                        onClick={() => {
                          setEditingSlot(id);
                          setNewPass("");
                          setConfirmPass("");
                          setSlotErr(null);
                        }}
                      >
                        {slot ? "Reset" : <><Plus />Set</>}
                      </Button>
                      {slot && (
                        <Button
                          type="button"
                          size="icon"
                          variant="ghost"
                          aria-label={`Remove Password ${id}`}
                          title={`Remove Password ${id}`}
                          onClick={() => handleRemoveSlot(id)}
                        >
                          <Trash2 />
                        </Button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Slot Editor Form */}
          {editingSlot !== null && (
            <form onSubmit={(e) => void handleSaveSlot(e)} className="flex flex-col gap-2.5 rounded-[18px] border-2 border-ink bg-muted p-3.5">
              <div className="text-xs font-bold">
                {lock.slots.some((s) => s.id === editingSlot) ? `Reset Password ${editingSlot}` : `Set Password ${editingSlot}`}
              </div>
              <div className="grid gap-2 sm:grid-cols-2">
                <Input
                  type="password"
                  value={newPass}
                  onChange={(e) => setNewPass(e.target.value)}
                  placeholder="New password (min 4 chars)"
                  aria-label="New password"
                  autoComplete="new-password"
                  autoFocus
                />
                <Input
                  type="password"
                  value={confirmPass}
                  onChange={(e) => setConfirmPass(e.target.value)}
                  placeholder="Confirm password"
                  aria-label="Confirm password"
                  autoComplete="new-password"
                />
              </div>
              {slotErr && <p className="text-xs font-bold text-bad">{slotErr}</p>}
              <div className="flex justify-end gap-2">
                <Button type="button" variant="ghost" size="sm" onClick={() => setEditingSlot(null)}>Cancel</Button>
                <Button type="submit" size="sm" disabled={busy || !newPass || !confirmPass}>
                  <Check />Save Password {editingSlot}
                </Button>
              </div>
            </form>
          )}

          {/* Auto-Lock Timing Options */}
          {active && canManage && (
            <div className="flex flex-col gap-3 border-t border-line pt-3">
              <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
                <div>
                  <div className="text-sm font-medium">When to ask for password again</div>
                  <div className="text-[13px] text-sub">
                    {lock.mode === "close"
                      ? "Stays unlocked until you close and reopen the app."
                      : `Locks automatically after ${lock.idleMinutes} minute${lock.idleMinutes === 1 ? "" : "s"} of inactivity.`}
                  </div>
                </div>
                <Segmented
                  label="Auto-lock mode"
                  value={lock.mode}
                  onChange={(v) => saveLock({ ...lock, mode: v })}
                  options={[
                    { value: "close", label: "On close" },
                    { value: "idle", label: "After idle" },
                  ]}
                />
              </div>

              {lock.mode === "idle" && (
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <span className="text-[13px] text-sub">Inactivity timeout</span>
                  <div className="flex flex-wrap gap-1.5">
                    {IDLE_PRESETS.map((m) => (
                      <button
                        key={m}
                        type="button"
                        onClick={() => saveLock({ ...lock, idleMinutes: m })}
                        className={cn(
                          "h-8 rounded-full border-2 px-3 text-xs font-bold transition-colors",
                          lock.idleMinutes === m ? "border-ink bg-butter text-on shadow-[0_2px_0_var(--ink)]" : "border-ink bg-surface text-fg hover:bg-muted",
                        )}
                      >
                        {m} min
                      </button>
                    ))}
                  </div>
                </div>
              )}

              <div className="flex flex-wrap items-center justify-between gap-2 pt-1">
                {onLockNow ? (
                  <Button type="button" variant="outline" size="sm" onClick={onLockNow}>
                    <Lock />Lock app now
                  </Button>
                ) : <span />}
                <Button type="button" variant="danger" size="sm" onClick={handleDisableLock}>
                  <Unlock />Disable App Lock
                </Button>
              </div>
            </div>
          )}
        </div>
      )}
    </Card>
  );
}
