// Generates the Capacitor Android project (if missing), copies the Kotlin plugin, manifest and the shared SQLite
// schema into it, and patches Gradle for 7-Zip-JBinding, Commons Compress and Kotlin. Safe to run repeatedly.
import { spawnSync } from "node:child_process";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { buildSync } from "esbuild";

const root = path.resolve(path.dirname(new URL(import.meta.url).pathname.replace(/^\/([A-Za-z]:)/, "$1")), "..");
const sh = (cmd, args, cwd = root) => {
  const r = spawnSync(cmd, args, { cwd, stdio: "inherit", shell: process.platform === "win32" });
  if (r.status !== 0) throw new Error(`${cmd} ${args.join(" ")} failed`);
};
const read = (p) => fs.readFileSync(p, "utf8");
const PKG = "app/comiclib/mobile";

// 0. fail fast with actionable messages
const need = (cmd, args, hint) => {
  const r = spawnSync(cmd, args, { encoding: "utf8", shell: process.platform === "win32" });
  if (r.error || r.status !== 0) throw new Error(`${cmd} is required but was not found. ${hint}`);
  return (r.stdout + r.stderr).trim();
};
need("javac", ["-version"], "Install a full JDK 17 or 21 (a JRE is not enough) and put it on PATH / set JAVA_HOME.");
const sdk = process.env.ANDROID_HOME || process.env.ANDROID_SDK_ROOT;
if (!sdk || !fs.existsSync(path.join(sdk, "platforms"))) throw new Error("ANDROID_HOME must point to an Android SDK that has a platforms/ folder. Install platform android-35 and build-tools 35.x with sdkmanager, then accept licenses: sdkmanager --licenses");
if (!fs.existsSync(path.join(sdk, "build-tools"))) throw new Error("Android SDK build-tools are missing. Run: sdkmanager \"build-tools;35.0.0\" \"platforms;android-35\"");

// 1. build the UI. Fonts (Quicksand, Bagel Fat One) come from @fontsource packages and are inlined into dist/index.html,
// so the offline app never downloads anything at runtime.
sh("npm", ["run", "build"]);

// 2. scaffold android/ with Capacitor if needed (keep android/native, which holds our sources)
const gradleApp = path.join(root, "android/app/build.gradle");
if (!fs.existsSync(gradleApp)) {
  const keep = path.join(os.tmpdir(), "comiclib-native-" + Date.now());
  fs.renameSync(path.join(root, "android/native"), keep);
  fs.rmSync(path.join(root, "android"), { recursive: true, force: true });
  sh("npx", ["cap", "add", "android"]);
  fs.renameSync(keep, path.join(root, "android/native"));
}

// 3. schema.json from the shared TypeScript schema (single source of truth)
const out = buildSync({ entryPoints: [path.join(root, "shared/src/schema.ts")], bundle: true, format: "esm", write: false, platform: "node" });
const mod = await import("data:text/javascript;base64," + Buffer.from(out.outputFiles[0].text).toString("base64"));
const assets = path.join(root, "android/app/src/main/assets");
fs.mkdirSync(assets, { recursive: true });
fs.writeFileSync(path.join(assets, "schema.json"), JSON.stringify(mod.MIGRATIONS));

// 4. Kotlin sources and manifest
const javaDir = path.join(root, "android/app/src/main/java", PKG);
fs.mkdirSync(javaDir, { recursive: true });
for (const f of fs.readdirSync(path.join(root, "android/native/kotlin"))) fs.copyFileSync(path.join(root, "android/native/kotlin", f), path.join(javaDir, f));
fs.rmSync(path.join(javaDir, "MainActivity.java"), { force: true });
fs.copyFileSync(path.join(root, "android/native/AndroidManifest.xml"), path.join(root, "android/app/src/main/AndroidManifest.xml"));

// 4b. launcher icon (user-supplied artwork, pre-rendered into android/native/res): copied over the Capacitor defaults
const resSrc = path.join(root, "android/native/res"), resDst = path.join(root, "android/app/src/main/res");
if (fs.existsSync(resSrc)) fs.cpSync(resSrc, resDst, { recursive: true });

// 5. Gradle patches
const KOTLIN = "1.9.25";
let top = read(path.join(root, "android/build.gradle"));
if (!top.includes("kotlin-gradle-plugin")) top = top.replace(/dependencies\s*\{/, `dependencies {\n        classpath 'org.jetbrains.kotlin:kotlin-gradle-plugin:${KOTLIN}'`);
if (!top.includes("jitpack.io")) top = top.replace(/allprojects\s*\{\s*repositories\s*\{/, "allprojects {\n    repositories {\n        maven { url 'https://jitpack.io' }");
fs.writeFileSync(path.join(root, "android/build.gradle"), top);
let app = read(gradleApp);
if (!app.includes("kotlin-android")) app = app.replace("apply plugin: 'com.android.application'", "apply plugin: 'com.android.application'\napply plugin: 'kotlin-android'");
if (!app.includes("7-Zip-JBinding")) {
  app = app.replace(/dependencies\s*\{/, `dependencies {
    // Archive engine: 7-Zip 16.02 core via JNI. ZIP, 7Z, RAR, RAR5, TAR, GZ, BZ2, XZ and multi-volume sets.
    implementation 'com.github.omicronapps:7-Zip-JBinding-4Android:Release-16.02-2.02'
    // Alternate engine used by the self-healing ladder (ZIP, 7Z, TAR).
    implementation 'org.apache.commons:commons-compress:1.26.2'
    implementation 'org.tukaani:xz:1.9'`);
  app = app.replace(/android\s*\{/, "android {\n    kotlinOptions { jvmTarget = '21' }\n    packagingOptions { jniLibs { useLegacyPackaging = true } }");
}
fs.writeFileSync(gradleApp, app);

// 5b. version: keep applicationId app.comiclib.mobile; versionCode/Name come from package.json "android" block
const pkg = JSON.parse(read(path.join(root, "package.json")));
const vc = pkg.android?.versionCode ?? 12, vn = pkg.android?.versionName ?? "5.0";
app = read(gradleApp).replace(/versionCode\s+\d+/, `versionCode ${vc}`).replace(/versionName\s+"[^"]*"/, `versionName "${vn}"`);
// androidx.activity / core are needed by MainActivity (already transitive via Capacitor; declared to fail loudly if not)
if (!app.includes("androidx.core:core-ktx") && !app.includes("androidx.activity:activity")) app = app.replace(/dependencies\s*\{/, "dependencies {\n    implementation 'androidx.activity:activity-ktx:1.9.3'\n    implementation 'androidx.core:core-ktx:1.15.0'");
fs.writeFileSync(gradleApp, app);

// 6. sync web assets into the Android project
sh("npx", ["cap", "sync", "android"]);
console.log("Android project is ready in android/");
