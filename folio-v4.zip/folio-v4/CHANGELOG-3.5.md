# Folio v3.5

- **Smooth, Robust Scroll-Mode Zoom**: Rebuilt scroll-mode pinch and double-tap zoom using a non-passive 2-finger touch handler with a 60fps GPU `translate3d`/`scale` live preview (zero React re-renders and zero layout reflow during the gesture), followed by an atomic pixel-exact layout-width and scroll-position commit on release for crisp rendering and native 2D scrolling without jitter or vanishing images.
- **Version Bump**: Updated code/build version to `3.5` (`3.5.0`, Android `versionCode 8`, `Folio-v3.5-debug.apk`).
