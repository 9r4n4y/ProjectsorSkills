# Folio v3.3

- **Fixed 7-Zip Extraction "IEND chunk missing" False Failures**:
  - Updated Android Layer 5 image verification (`Pipeline.kt`) to inspect actual file magic bytes instead of filename extensions (so JPEG, WebP, or AVIF images saved with a `.png` extension are no longer falsely rejected as truncated PNGs), scan up to 4 KB for `IEND`/`EOI` markers, and trust `BitmapFactory` full pixel decode for valid readable images.
  - Hardened `7-Zip-JBinding` extraction (`Engine.kt`) with `BufferedOutputStream`, explicit stream flush/close between entries, and `try/finally` cleanup.
  - Updated native `readImage` (`ComicNativePlugin.kt`) to detect image MIME types from magic bytes so misnamed images always render cleanly in the reader.
- **Version Bump**: Updated app name and version to **Folio v3.3** (`version 3.3.0`, Android `versionCode 6`, `Folio-v3.3-debug.apk`).
