import { useEffect, useState } from "react";
import { BellRing, FileDown, FileUp, FolderOpen, KeyRound, RefreshCw, ShieldAlert, Trash2 } from "lucide-react";
import type { PasswordEntry, PermissionStatus } from "@comiclib/shared";
import { api } from "@/lib/backend";
import { useStore } from "@/lib/store";
import { Button } from "@/components/ui/button";
import { Badge, Input, Segmented, Switch } from "@/components/ui/controls";
import { Card, PageShell } from "@/components/PageShell";
import { ExportDialog } from "./Metadata";

function Row({ title, hint, children }: { title: string; hint?: string; children: React.ReactNode }) {
  return (
    <div className="flex flex-col gap-2 py-3 first:pt-0 last:pb-0 sm:flex-row sm:items-center sm:justify-between sm:gap-6">
      <div className="min-w-0"><div className="text-sm font-medium">{title}</div>{hint && <div className="text-[13px] text-sub">{hint}</div>}</div>
      <div className="shrink-0">{children}</div>
    </div>
  );
}

const PERMS: { key: keyof PermissionStatus; title: string; why: string }[] = [
  { key: "allFiles", title: "All files access", why: "Lets the app read your comics where they are and extract next to the archives. Without it, use the folder picker." },
  { key: "notifications", title: "Notifications", why: "Shows progress and a summary while long tasks run." },
  { key: "foregroundService", title: "Foreground service", why: "Keeps extraction and verification running when the screen is off or the app is closed." },
  { key: "wakeLock", title: "Wake lock", why: "Stops the CPU sleeping in the middle of a task. Held only while work runs." },
  { key: "batteryOptimization", title: "Battery optimization exemption", why: "Prevents the system from stopping long extractions." },
];

export function PermissionsList({ perms, onChange }: { perms: PermissionStatus; onChange: (p: PermissionStatus) => void }) {
  return (
    <ul className="flex flex-col divide-y divide-line">
      {PERMS.filter((p) => perms[p.key] !== "unsupported").map((p) => (
        <li key={p.key} className="flex items-center gap-3 py-3 first:pt-0 last:pb-0">
          <div className="min-w-0 flex-1"><div className="text-sm font-medium">{p.title}</div><div className="text-[13px] text-sub">{p.why}</div></div>
          <Badge tone={perms[p.key] === "granted" ? "ok" : "warn"}>{perms[p.key] === "granted" ? "Allowed" : "Not allowed"}</Badge>
          {perms[p.key] !== "granted" && <Button size="sm" variant="outline" onClick={async () => onChange(await api.requestPermission(p.key))}>Allow</Button>}
          {perms[p.key] !== "granted" && <Button size="sm" variant="ghost" onClick={() => void api.openSystemSettings(p.key)}>Open settings</Button>}
        </li>
      ))}
    </ul>
  );
}

export function Settings() {
  const s = useStore((st) => st.settings);
  const set = useStore((st) => st.setSettings);
  const info = useStore((st) => st.info);
  const root = useStore((st) => st.root);
  const refresh = useStore((st) => st.refresh);
  const rescan = useStore((st) => st.rescan);
  const scanning = useStore((st) => st.scanning);
  const toast = useStore((st) => st.toast);
  const [pws, setPws] = useState<PasswordEntry[]>([]);
  const [newPw, setNewPw] = useState("");
  const [perms, setPerms] = useState<PermissionStatus | null>(null);
  const [dlg, setDlg] = useState<null | "export">(null);
  const loadPw = () => void api.listPasswords().then(setPws);
  useEffect(() => { loadPw(); void api.getPermissions().then(setPerms); }, []);

  const change = async () => {
    const p = await api.pickFolder();
    if (!p) return;
    try {
      await api.setRoot(p);
      await refresh();
      toast("Mother folder changed and scanned");
    } catch (e) {
      toast((e as Error).message, "error");
    }
  };

  const panSens = Math.max(0.5, Math.min(2.5, Number.isFinite(s.zoomPanSensitivity) ? s.zoomPanSensitivity : 1));

  return (
    <PageShell title="Settings" description={info?.demo ? "Browser preview. Changes are kept in this browser only." : "Manage your library, reading preferences, and backups."}>
      <Card title="Library">
        <Row title="Mother folder" hint={root ?? "None selected"}>
          <div className="flex gap-2">
            <Button variant="outline" onClick={() => void change()}><FolderOpen />Change</Button>
            <Button variant="outline" disabled={scanning} onClick={() => void rescan()}><RefreshCw className={scanning ? "animate-spin" : ""} />Rescan</Button>
          </div>
        </Row>
        <p className="mt-2 text-[13px] text-sub">Comics stay in your folders. The app keeps only an index, tags, favorites, settings and thumbnails.</p>
      </Card>

      <Card title="Appearance and reading">
        <div className="flex flex-col divide-y divide-line">
          <Row title="Comics per page" hint="How many comics show on one library page. Default 20."><Input type="number" min={5} max={200} value={s.pageSize} onChange={(e) => set({ pageSize: Math.max(1, Math.min(200, Math.round(+e.target.value) || 20)) })} className="w-24" aria-label="Comics per page" /></Row>
          <Row title="Theme"><Segmented label="Theme" value={s.theme} onChange={(v) => set({ theme: v })} options={[{ value: "system", label: "System" }, { value: "light", label: "Light" }, { value: "dark", label: "Dark" }]} /></Row>
          <Row title="Default reading mode" hint="Can also be changed inside the reader."><Segmented label="Reading mode" value={s.readerMode} onChange={(v) => set({ readerMode: v })} options={[{ value: "scroll", label: "Scroll" }, { value: "paged", label: "Tap" }, { value: "auto", label: "Auto" }]} /></Row>
          <Row title="Page fit"><Segmented label="Page fit" value={s.fit} onChange={(v) => set({ fit: v })} options={[{ value: "width", label: "Width" }, { value: "height", label: "Height" }]} /></Row>
          <Row title="Zoom pan sensitivity" hint="Controls how far the zoomed screen moves when swiping in Scroll, Tap, and Auto modes.">
            <div className="flex w-full min-w-[220px] flex-col gap-1 sm:w-64">
              <div className="flex items-center justify-between gap-2 text-xs font-bold">
                <span className="text-sub">Swipe distance</span>
                <div className="flex items-center gap-1.5">
                  <span className="rounded-full border-2 border-ink bg-butter px-2.5 py-0.5 tabular-nums text-on">{panSens.toFixed(1)}×</span>
                  {Math.abs(panSens - 1) > 0.01 && (
                    <button type="button" onClick={() => set({ zoomPanSensitivity: 1 })} className="text-xs font-bold text-accent underline-offset-2 hover:underline">Reset</button>
                  )}
                </div>
              </div>
              <input
                type="range"
                min={0.5}
                max={2.5}
                step={0.1}
                value={panSens}
                onChange={(e) => set({ zoomPanSensitivity: Math.round(+e.target.value * 10) / 10 })}
                aria-label="Zoom pan sensitivity"
                aria-valuetext={`${panSens.toFixed(1)} times`}
                className="mochi-range w-full"
                style={{ ["--p" as string]: (panSens - 0.5) / 2 }}
              />
              <div className="flex justify-between text-[11px] text-sub"><span>Precise (0.5×)</span><span>Normal (1.0×)</span><span>Fast (2.5×)</span></div>
            </div>
          </Row>
          <Row title="Auto-next interval" hint="Seconds per page in auto mode."><Input type="number" min={1} max={300} value={s.autoNextSec} onChange={(e) => set({ autoNextSec: Math.max(1, Math.min(300, +e.target.value || 8)) })} className="w-24" aria-label="Seconds per page" /></Row>
        </div>
      </Card>

      <Card title="Extraction and startup">
        <div className="flex flex-col divide-y divide-line">
          <Row title="Extract new archives automatically" hint="After each scan, queue archives that appeared."><Switch label="Extract new archives automatically" checked={s.autoExtractNew} onCheckedChange={(v) => set({ autoExtractNew: v })} /></Row>
          <Row title="Ask before using a numbered folder" hint="When the target folder already exists and differs."><Switch label="Ask when target exists" checked={s.collision === "ask"} onCheckedChange={(v) => set({ collision: v ? "ask" : "suffix" })} /></Row>
          <Row title="Run health checks at startup"><Switch label="Run health checks at startup" checked={s.healthOnStart} onCheckedChange={(v) => set({ healthOnStart: v })} /></Row>
          {info?.platform === "electron" && <Row title="Keep running in the tray when the window closes" hint="Tasks continue in the background."><Switch label="Close to tray" checked={s.closeToTray} onCheckedChange={(v) => set({ closeToTray: v })} /></Row>}
        </div>
      </Card>

      <Card title="Saved archive passwords" actions={<Badge>{pws.length}</Badge>}>
        <p className="mb-3 text-[13px] text-sub">Stored on this device, encrypted. They are tried automatically before asking you.</p>
        <ul className="mb-3 flex flex-col divide-y divide-line">
          {pws.map((p) => <li key={p.id} className="flex items-center gap-3 py-2 text-sm"><KeyRound className="size-4 text-sub" /><span className="min-w-0 flex-1 truncate">{p.label}</span><Button variant="ghost" size="icon" aria-label={`Remove ${p.label}`} onClick={async () => { await api.removePassword(p.id); loadPw(); }}><Trash2 /></Button></li>)}
          {pws.length === 0 && <li className="py-2 text-[13px] text-sub">No saved passwords.</li>}
        </ul>
        <form className="flex gap-2" onSubmit={async (e) => { e.preventDefault(); await api.addPassword(`Password ${pws.length + 1}`, newPw); setNewPw(""); loadPw(); }}>
          <Input type="password" value={newPw} onChange={(e) => setNewPw(e.target.value)} placeholder="Add a password" aria-label="New password" autoComplete="off" className="max-w-xs" />
          <Button type="submit" variant="secondary" disabled={!newPw}>Save</Button>
        </form>
      </Card>

      <Card title="Metadata backup">
        <p className="mb-3 text-[13px] text-sub">Export tags, favorites, folders, read progress, settings and fingerprints to one JSON file. Import it later on any device; moved and renamed comics are matched.</p>
        <div className="flex flex-wrap gap-2"><Button variant="outline" onClick={() => setDlg("export")}><FileDown />Export</Button><Button variant="outline" onClick={() => useStore.getState().setScreen("metadata")}><FileUp />Import and match</Button></div>
      </Card>

      {perms && info?.platform === "android" && (
        <Card title="Permissions" actions={<ShieldAlert className="size-4 text-sub" />}>
          <PermissionsList perms={perms} onChange={setPerms} />
        </Card>
      )}

      <Card title="Diagnostics">
        <Button variant="outline" onClick={async () => { await api.copyText(await api.diagnostics()); toast("Diagnostics copied"); }}><BellRing />Copy diagnostics</Button>
      </Card>
      {dlg === "export" && <ExportDialog onClose={() => setDlg(null)} />}
    </PageShell>
  );
}
