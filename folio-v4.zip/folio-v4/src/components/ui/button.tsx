import * as React from "react";
import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "@/utils/cn";

/*
 * Mochi buttons:
 *   - OUTER <button> is a static, transparent hit target so the pointer can never slide off mid-press;
 *   - INNER face carries the pastel fill, ink outline, ink shadow, and ALL motion;
 *   - Hover lift is gated to @media(hover:hover) so Android touch screens never get stuck in a lifted hover state;
 *   - A brief guaranteed press pulse (130 ms) ensures even ultra-fast taps visibly press down and spring back on every tap.
 */
const outer =
  "group relative inline-flex shrink-0 select-none touch-manipulation items-stretch justify-center rounded-[18px] border-0 bg-transparent p-0 pb-1 align-middle text-on disabled:pointer-events-none disabled:opacity-40 focus-visible:outline-none";

const faceBase =
  "pointer-events-none flex min-w-0 flex-1 items-center justify-center gap-2 whitespace-nowrap text-sm font-bold [&_svg]:size-4 [&_svg]:shrink-0 group-focus-visible:ring-4 group-focus-visible:ring-lilac";

const chunky =
  "border-[2.5px] border-ink text-on shadow-[0_4px_0_var(--ink)] transition-[transform,box-shadow,background-color] duration-300 ease-spring [@media(hover:hover)]:group-hover:-translate-y-0.5 [@media(hover:hover)]:group-hover:shadow-[0_6px_0_var(--ink)] group-active:translate-y-1 group-active:shadow-[0_0_0_var(--ink)] group-active:duration-75 group-data-[pressed=true]:translate-y-1 group-data-[pressed=true]:shadow-[0_0_0_var(--ink)] group-data-[pressed=true]:duration-75";

const faceVariants = cva(faceBase, {
  variants: {
    variant: {
      default: `${chunky} bg-butter`,
      secondary: `${chunky} bg-lilac`,
      outline: `${chunky} bg-surface !text-fg`,
      danger: `${chunky} bg-peach`,
      ghost:
        "text-fg transition-[transform,background-color] duration-250 ease-spring [@media(hover:hover)]:group-hover:bg-muted group-active:scale-90 group-active:bg-line group-active:duration-75 group-data-[pressed=true]:scale-90 group-data-[pressed=true]:bg-line group-data-[pressed=true]:duration-75",
    },
    size: {
      default: "h-9 rounded-[16px] px-4 pointer-coarse:h-11 pointer-coarse:px-5",
      sm: "h-8 rounded-[14px] px-3 text-[13px] pointer-coarse:h-10",
      lg: "h-11 rounded-[18px] px-6",
      icon: "size-9 rounded-full p-0 pointer-coarse:size-11 [&_svg]:size-[18px]",
    },
  },
  compoundVariants: [{ variant: "ghost", size: ["default", "sm", "lg"], class: "rounded-full" }],
  defaultVariants: { variant: "default", size: "default" },
});

export interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement>, VariantProps<typeof faceVariants> {
  /** extra classes for the visible face (colour, radius); className lands on the static outer button (layout). */
  faceClassName?: string;
}

export const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, faceClassName, variant, size, children, onPointerDown, onPointerUp, onPointerCancel, onClick, ...props }, ref) => {
    const [pressed, setPressed] = React.useState(false);
    const timerRef = React.useRef<ReturnType<typeof setTimeout> | null>(null);

    React.useEffect(() => {
      return () => {
        if (timerRef.current) clearTimeout(timerRef.current);
      };
    }, []);

    const triggerPulse = () => {
      setPressed(true);
      if (timerRef.current) clearTimeout(timerRef.current);
      timerRef.current = setTimeout(() => {
        setPressed(false);
        timerRef.current = null;
      }, 130);
    };

    return (
      <button
        ref={ref}
        type="button"
        data-pressed={pressed ? "true" : undefined}
        className={cn(outer, className)}
        onPointerDown={(e) => {
          triggerPulse();
          onPointerDown?.(e);
        }}
        onPointerUp={(e) => {
          onPointerUp?.(e);
        }}
        onPointerCancel={(e) => {
          onPointerCancel?.(e);
        }}
        onClick={(e) => {
          if (!pressed) triggerPulse();
          onClick?.(e);
        }}
        {...props}
      >
        <span className={cn(faceVariants({ variant, size }), faceClassName)}>{children}</span>
      </button>
    );
  },
);
Button.displayName = "Button";
