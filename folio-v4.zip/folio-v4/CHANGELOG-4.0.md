# Folio v4

- **Constant-Speed Inertial Scrolling While Zoomed**: Removed zoom-level speed attenuation when scrolling vertically in Scroll mode and added frame-rate-independent inertial momentum (60/90/120 Hz) so flicking down while zoomed scrolls with the exact same constant speed and natural glide as unzoomed scrolling—with zero flicker.
- **Zoom Pan Sensitivity Setting**: Added a persisted `Zoom pan sensitivity` slider (`0.5×`–`2.5×`, default `1.0×`) under **Settings → Appearance and reading** that controls swipe pan distance across Scroll, Tap, and Auto modes.
- **Version Bump**: Updated code/build version to `4.0.0` (Android `versionCode 10`, `versionName 4.0`, `Folio-v4-debug.apk`) while keeping the UI clean without version badges.
