# Folio v3.4

- **Scroll-Mode Zoom**: Added pinch-to-zoom, double-tap zoom (1x ↔ 2.2x), and top-bar `-` / `%` / `+` zoom controls (up to 4x) in continuous scroll mode using layout-width scaling + focal-point anchoring so zoomed pages stay sharp and never vanish on Android WebView.
- **Search Toolbar & Button Tap Animation Fix**: Fixed `Button` so touch devices no longer get stuck in `:hover`, added a guaranteed 130ms press-and-spring animation pulse on every tap, and gave the search section icon buttons proper circular sizing instead of stretched mobile grid cells.
- **Clean UI Without Version Badges**: Removed visible version pills from the library header, Edge Panel, window title, and launcher label while keeping `3.4` (`3.4.0`, `versionCode 7`) in code and build configs.
- **Preview Panel Grid Density**: Added a `Per row` selector (`2`, `3`, `4`, `5`, `6` images per row, remembered across sessions) inside Quick Look's page preview panel.
