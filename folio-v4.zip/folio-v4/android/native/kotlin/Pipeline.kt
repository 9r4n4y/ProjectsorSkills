package app.comiclib.mobile

import android.graphics.BitmapFactory
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.security.MessageDigest

/**
 * Native port of the shared TypeScript extraction pipeline (shared/src/extract.ts, layout.ts, verify.ts).
 * Same rules: own folder per archive, staging then atomic move, ten verification layers, self-healing ladder.
 */
object Pipeline {
    val NAMES = listOf("Archive integrity", "File list comparison", "CRC32 and SHA-256", "Count and total size", "Image decode", "Page sequence", "Empty and tiny files", "Manifest", "Post-move check", "Library index")

    fun layer(n: Int, status: String, summary: String, details: List<String> = emptyList()) = JSONObject()
        .put("layer", n).put("name", NAMES[n - 1]).put("status", status).put("summary", summary).put("details", JSONArray(details.take(40)))

    class Plan(val folder: String, val files: List<Pair<Entry, String>>, val unsafe: List<String>, val comicDirs: List<String>, val images: Int, val total: Long, val nested: List<String>)

    fun plan(name: String, entries: List<Entry>): Plan {
        val unsafe = ArrayList<String>()
        val cand = ArrayList<Pair<Entry, MutableList<String>>>()
        for (e in entries) {
            val p = e.path.replace('\\', '/').removePrefix("./")
            val raw = p.split('/')
            if (e.symlink) { unsafe += "${e.path}: symbolic link"; continue }
            if (p.startsWith("/") || Regex("^[A-Za-z]:").containsMatchIn(p) || raw.contains("..")) { unsafe += "${e.path}: path traversal or absolute path"; continue }
            if (e.isDir || Util.isJunk(p)) continue
            cand += e to raw.filter { it.isNotEmpty() && it != "." }.map(Util::sanitize).toMutableList()
        }
        while (cand.isNotEmpty()) { // collapse single top-level folders, never double nesting
            val loose = cand.any { it.second.size == 1 }
            val tops = cand.filter { it.second.size > 1 }.map { it.second[0] }.toSet()
            if (loose || tops.size != 1) break
            cand.forEach { it.second.removeAt(0) }
        }
        val seen = HashMap<String, Int>()
        val files = cand.map { (e, segs) ->
            var d = segs.joinToString("/")
            val n = seen.merge(d.lowercase(), 1, Int::plus)!!
            if (n > 1) { val last = segs.last(); val i = last.lastIndexOf('.'); segs[segs.size - 1] = if (i > 0) "${last.substring(0, i)} ($n)${last.substring(i)}" else "$last ($n)"; d = segs.joinToString("/") }
            e to d
        }
        val dirs = files.filter { Util.isImage(it.second) }.map { it.second.substringBeforeLast('/', "") }.toSortedSet().toList()
        return Plan(Util.sanitize(name), files, unsafe, dirs, files.count { Util.isImage(it.second) }, files.sumOf { it.first.size }, files.filter { Util.archiveExt(it.second) }.map { it.second })
    }

    /** Sniffs actual file magic bytes (not filename extension) and scans up to the last 4 KB for end markers. */
    private fun structural(f: File): String? {
        val len = f.length(); if (len < 12) return "file too small to be an image"
        val head = ByteArray(12)
        val tailLen = minOf(len, 4096L).toInt()
        val tail = ByteArray(tailLen)
        java.io.RandomAccessFile(f, "r").use { r ->
            r.readFully(head)
            r.seek(len - tailLen)
            r.readFully(tail)
        }
        val isPng = head[0] == 0x89.toByte() && head[1] == 0x50.toByte() && head[2] == 0x4E.toByte() && head[3] == 0x47.toByte()
        val isJpeg = head[0] == 0xFF.toByte() && head[1] == 0xD8.toByte()
        if (isPng) {
            if (!String(tail, Charsets.ISO_8859_1).contains("IEND")) return "truncated: IEND chunk missing"
        } else if (isJpeg) {
            var foundEoi = false
            for (i in tail.size - 2 downTo 0) {
                if (tail[i] == 0xFF.toByte() && tail[i + 1] == 0xD9.toByte()) { foundEoi = true; break }
            }
            if (!foundEoi) return "truncated: end of image marker missing"
        }
        return null
    }

    /**
     * Decodes the image with BitmapFactory first. Misnamed extensions (e.g. WebP/JPEG saved as .png),
     * trailing padding after IEND/EOI, and minor encoder quirks that Android decodes cleanly are accepted;
     * truly unreadable or corrupt files fail with the most specific reason available.
     */
    fun decodeOk(f: File): String? {
        if (f.length() < 12) return "file too small to be an image"
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(f.path, o)
        if (o.outWidth <= 0 || o.outHeight <= 0) return structural(f) ?: "invalid header or zero dimensions"
        val big = o.outWidth.toLong() * o.outHeight > 24_000_000L
        val bmp = try { BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = if (big) 2 else 1 }) } catch (e: OutOfMemoryError) { return null }
        if (bmp == null) return structural(f) ?: "full decode failed"
        val ok = bmp.width > 0 && bmp.height > 0
        bmp.recycle()
        return if (ok) null else (structural(f) ?: "full decode failed")
    }

    fun pageGaps(files: List<String>): List<String> {
        val out = ArrayList<String>()
        files.filter(Util::isImage).groupBy { it.substringBeforeLast('/', "") }.forEach { (dir, list) ->
            val nums = list.mapNotNull { Regex("(\\d+)(?!.*\\d)").find(it.substringAfterLast('/').substringBeforeLast('.'))?.value?.toIntOrNull() }
            if (nums.size < 2) return@forEach
            val set = nums.toSortedSet(); val missing = (set.first()..set.last()).filter { it !in set }
            val dups = nums.groupingBy { it }.eachCount().filter { it.value > 1 }.keys
            val p = if (dir.isEmpty()) "" else "$dir: "
            if (missing.isNotEmpty()) out += "${p}missing page number(s): ${missing.take(30).joinToString(", ")}"
            if (dups.isNotEmpty()) out += "${p}duplicate page number(s): ${dups.take(30).joinToString(", ")}"
        }
        return out
    }

    fun listFiles(dir: File): List<Pair<String, Long>> = dir.walkTopDown().filter { it.isFile && !java.nio.file.Files.isSymbolicLink(it.toPath()) }.map { it.relativeTo(dir).path.replace(File.separatorChar, '/') to it.length() }.toList()

    class Ctx(
        val db: ComicDb, val root: File, val a: ArchiveFile, val password: String?, val ask: Boolean,
        val progress: (Double, String, Long) -> Unit, val cancelled: () -> Boolean, val register: (File) -> Pair<Int, Boolean>?, val reduce: () -> Unit,
    )

    fun run(c: Ctx): JSONObject {
        val L = Array(10) { layer(it + 1, "skip", "Not reached") }
        val attempts = JSONArray(); val warnings = JSONArray()
        val a = c.a; val parent = a.dir
        val stage = File(parent, ".comiclib-staging-${a.id}")
        fun res(status: String, reason: String? = null, extra: JSONObject = JSONObject()) = extra.put("status", status).put("reason", reason ?: JSONObject.NULL)
            .put("layers", JSONArray(L.toList())).put("attempts", attempts).put("warnings", warnings)
        try {
            if (a.missing.isNotEmpty()) { L[0] = layer(1, "fail", "Volumes are missing", a.missing.map { "missing: $it" }); return res("failed", "Missing volume(s): ${a.missing.joinToString(", ")}") }
            c.progress(0.02, "Reading archive", 0)
            // ---- open and passwords ----
            var pw = c.password; var sz: Sz? = null; var entries: List<Entry>? = null; var openErr = ""
            val cands = (listOfNotNull(c.password) + c.db.passwords()).distinct()
            fun open(p: String?): Boolean = try { sz?.close(); sz = Sz(a).open(p); entries = sz!!.entries(); true } catch (e: Exception) { openErr = e.message ?: e.javaClass.simpleName; false }
            var needPw = false
            if (!open(pw)) needPw = Regex("assword|ncrypt", RegexOption.IGNORE_CASE).containsMatchIn(openErr)
            else if (entries!!.any { it.encrypted }) needPw = pw == null || sz!!.test(pw, c.cancelled) != null
            if (needPw) {
                var found: String? = null
                for (p in cands) { if (open(p) && sz!!.test(p, c.cancelled) == null) { found = p; break } }
                if (found == null) return res("needs_password", if (c.password != null) "The supplied password is incorrect" else "Password required")
                pw = found
            } else if (entries == null) {
                L[0] = layer(1, "fail", "Archive cannot be opened", listOf(openErr)); return res("quarantined", "Cannot open archive: $openErr")
            }
            val ents = entries!!
            // ---- layer 1 ----
            c.progress(0.04, "Testing archive integrity", 0)
            val t = sz!!.test(pw, c.cancelled)
            if (t != null) { L[0] = layer(1, "fail", "Archive test failed (7-Zip)", listOf(t)); return res("quarantined", "Archive integrity test failed: $t") }
            L[0] = layer(1, "pass", "Archive test passed (7-Zip)")
            // ---- plan ----
            val plan = plan(a.name, ents)
            val base = JSONObject().put("uncompressed", plan.total).put("entries", plan.files.size)
            if (plan.unsafe.isNotEmpty()) { L[1] = layer(2, "fail", "Archive contains unsafe entries", plan.unsafe); return res("failed", "Archive rejected: ${plan.unsafe.size} unsafe entry path(s) (path traversal or symbolic link)", base) }
            if (plan.images == 0 && plan.nested.isEmpty()) return res("no_images", "Archive contains no images", base)
            // ---- collision ----
            var target = plan.folder
            val clash = parent.list()?.firstOrNull { it.equals(target, ignoreCase = true) }
            if (clash != null) {
                val existing = File(parent, clash); val have = listFiles(existing).filter { !Util.isJunk(it.first) }.toMap()
                val same = have.size == plan.files.size && plan.files.all { (e, d) -> have[d] == e.size && (e.crc == null || Util.sha256(File(existing, d)).second == e.crc) }
                if (same) return res("already_extracted", "Already extracted and identical", base.put("finalDir", existing.path))
                if (c.ask) return res("needs_input", "A different folder named \"$clash\" already exists", base)
                var n = 2; while (parent.list()!!.any { it.equals("$target ($n)", true) }) n++
                target = "$target ($n)"; warnings.put("Target existed; extracted to \"$target\"")
            }
            val finalDir = File(File(stage, "final"), target)
            val destByIndex = plan.files.associate { it.first.index to it.second }
            val destByPath = plan.files.associate { it.first.path to it.second }
            val sha = HashMap<String, Pair<String, Long>>(); val decode = HashMap<String, String?>()
            var failed = emptySet<String>(); var sourceCorrupt = false; var good = false; var lastError = ""
            fun verify(): List<JSONObject> {
                val actual = listFiles(finalDir); val sizes = actual.toMap(); val planned = plan.files
                val missing = planned.filter { it.second !in sizes }.map { it.second }
                val extra = sizes.keys.filter { k -> planned.none { it.second == k } }
                val bad = HashSet<String>(missing)
                planned.filter { it.second in sizes }.forEach { (e, d) ->
                    val h = sha.getOrPut(d) { Util.sha256(File(finalDir, d)) }
                    if ((e.crc != null && h.second != e.crc) || sizes[d] != e.size) bad += d
                }
                val imgs = planned.filter { it.second in sizes && Util.isImage(it.second) }
                val dbad = imgs.filter { decode.getOrPut(it.second) { decodeOk(File(finalDir, it.second)) } != null }.map { it.second }
                val l2 = if (missing.isEmpty() && extra.isEmpty()) layer(2, "pass", "${planned.size} entries match the archive listing") else layer(2, "fail", "${missing.size} missing, ${extra.size} unexpected", missing.map { "missing: $it" } + extra.map { "unexpected: $it" })
                val crcBad = bad.filter { it !in missing }
                val l3 = if (crcBad.isEmpty()) layer(3, "pass", "${planned.count { it.first.crc != null }} checksum(s) verified") else layer(3, "fail", "${crcBad.size} file(s) failed the checksum", crcBad.map { "changed: $it" })
                val l4 = if (actual.size == planned.size && actual.sumOf { it.second } == plan.total) layer(4, "pass", "${actual.size} files, ${plan.total} bytes match") else layer(4, "fail", "Totals differ from the archive", listOf("files ${actual.size}/${planned.size}", "bytes ${actual.sumOf { it.second }}/${plan.total}"))
                val l5 = if (imgs.isEmpty()) layer(5, "warn", "No images to decode") else if (dbad.isEmpty()) layer(5, "pass", "${imgs.size} images decoded") else layer(5, "fail", "${dbad.size} of ${imgs.size} images failed to decode", dbad.map { "$it: ${decode[it]}" })
                val gaps = pageGaps(planned.map { it.second })
                val l6 = if (gaps.isEmpty()) layer(6, "pass", "Page numbering is continuous") else layer(6, "warn", "${gaps.size} numbering issue(s)", gaps)
                val zero = imgs.filter { (sizes[it.second] ?: 0) == 0L }.map { it.second }; val tiny = imgs.filter { (sizes[it.second] ?: 0) in 1..1023 }.map { it.second }
                val l7 = if (zero.isNotEmpty()) layer(7, "fail", "${zero.size} zero-byte image(s)", zero) else if (tiny.isNotEmpty()) layer(7, "warn", "${tiny.size} suspiciously small image(s)", tiny) else layer(7, "pass", "No empty or tiny files")
                failed = bad + (if (dbad.isNotEmpty() && bad.isEmpty() && imgs.all { i -> planned.first { it.second == i.second }.first.crc != null }) emptySet() else dbad.toSet())
                sourceCorrupt = bad.isEmpty() && dbad.isNotEmpty() && extra.isEmpty() && imgs.filter { it.second in dbad }.all { it.first.crc != null }
                if (sourceCorrupt) failed = emptySet()
                return listOf(l2, l3, l4, l5, l6, l7)
            }
            // ---- extract + verify with self-healing: retry, repair failed only, alternate engine, reduced parallelism ----
            val labels = listOf("extract", "re-extract failed files", "alternate engine (Commons Compress)", "reduced parallelism")
            var vl: List<JSONObject> = emptyList()
            for (s in 0 until 4) {
                if (c.cancelled()) throw InterruptedException()
                if (s == 1 && (failed.isEmpty() || failed.size >= plan.files.size)) continue
                if (s == 3) c.reduce()
                val t0 = System.currentTimeMillis(); var err: String? = null
                c.progress(0.06, "Extracting (${labels[s]})", 0)
                if (s == 0 || s >= 2) { stage.deleteRecursively(); finalDir.mkdirs(); sha.clear(); decode.clear() }
                else failed.forEach { File(finalDir, it).delete(); sha.remove(it); decode.remove(it) }
                var written = 0L
                val onBytes = { n: Long -> written += n; c.progress(0.06 + 0.54 * (written.toDouble() / maxOf(1L, plan.total)), "Extracting", written) }
                if (s == 2) err = Alt.extractAll(a, { n -> destByPath[n]?.let { File(finalDir, it) } }, c.cancelled)
                else {
                    val only = if (s == 1) plan.files.filter { it.second in failed }.map { it.first.index }.toIntArray() else plan.files.map { it.first.index }.toIntArray()
                    if (s != 0) { open(pw) }
                    val problems = runCatching { sz!!.extract(only, pw, { i -> destByIndex[i]?.let { File(finalDir, it) } }, onBytes, c.cancelled) }.getOrElse { err = it.message; emptyMap() }
                    if (problems.isNotEmpty() && err == null) err = "${problems.size} entries reported ${problems.values.first()}"
                }
                if (c.cancelled()) throw InterruptedException()
                c.progress(0.62, "Verifying extracted files", written)
                vl = verify()
                val fail = vl.any { it.getString("status") == "fail" }
                lastError = if (fail) vl.filter { it.getString("status") == "fail" }.joinToString("; ") { "${it.getString("name")}: ${it.getString("summary")}" } else err ?: ""
                attempts.put(JSONObject().put("n", attempts.length() + 1).put("engine", if (s == 2) "commons-compress" else "7zip-jbinding").put("mode", labels[s]).put("ok", !fail).put("error", if (lastError.isEmpty()) JSONObject.NULL else lastError).put("ms", System.currentTimeMillis() - t0))
                if (!fail) { good = true; break }
                if (sourceCorrupt) { warnings.put("Source archive stores undecodable image data (checksums match); retrying would not help"); break }
            }
            vl.forEach { L[it.getInt("layer") - 1] = it }
            sz?.close()
            if (!good) {
                val q = File(File(c.root, ".comiclib"), "quarantine").also { it.mkdirs() }
                val qd = File(q, "${a.id}-$target")
                runCatching { File(stage, "REASON.txt").writeText("${a.primary.path}\n$lastError\n"); qd.deleteRecursively(); stage.renameTo(qd) }
                return res("quarantined", lastError.ifEmpty { "Verification failed" }, base.put("quarantineDir", qd.path))
            }
            // ---- layer 8 manifests ----
            c.progress(0.93, "Writing manifest", 0)
            for (d in plan.comicDirs) {
                val own = plan.files.filter { f -> val best = plan.comicDirs.filter { x -> x.isEmpty() || f.second.startsWith("$x/") }.maxByOrNull { it.length }; best == d }
                val files = JSONArray()
                own.sortedWith { x, y -> Util.natural.compare(x.second, y.second) }.forEach { (e, dest) -> val h = sha[dest]!!; files.put(JSONObject().put("path", if (d.isEmpty()) dest else dest.substring(d.length + 1)).put("size", e.size).put("sha256", h.first).put("crc32", "%08x".format(h.second))) }
                File(File(finalDir, d), ".comiclib-manifest.json").writeText(JSONObject().put("version", 1).put("archive", a.primary.name).put("archiveSize", a.parts.sumOf { it.length() }).put("createdAt", System.currentTimeMillis())
                    .put("pageCount", own.count { Util.isImage(it.second) }).put("totalBytes", own.sumOf { it.first.size }).put("files", files).toString(1))
            }
            L[7] = if (plan.comicDirs.isEmpty()) layer(8, "skip", "No comic folders to describe") else layer(8, "pass", "${plan.comicDirs.size} manifest(s) written")
            // ---- atomic move + layer 9 ----
            val dest = File(parent, target)
            if (!finalDir.renameTo(dest)) throw IllegalStateException("Could not move the verified folder into place")
            stage.deleteRecursively()
            val after = listFiles(dest).filter { !it.first.endsWith(".comiclib-manifest.json") }
            val d9 = ArrayList<String>()
            plan.files.forEach { (e, d) -> val s = after.firstOrNull { it.first == d }?.second; if (s == null) d9 += "missing: $d" else if (s != e.size) d9 += "size changed: $d" }
            L[8] = if (d9.isEmpty()) layer(9, "pass", "${plan.files.size} files and sizes match") else layer(9, "fail", "${d9.size} difference(s) from the manifest", d9)
            // ---- layer 10 ----
            c.progress(0.97, "Updating library", 0)
            val comics = JSONArray(); val bad10 = ArrayList<String>()
            for (d in plan.comicDirs) {
                val dir = if (d.isEmpty()) dest else File(dest, d)
                val expected = plan.files.count { Util.isImage(it.second) && it.second.substringBeforeLast('/', "") == d }
                val info = c.register(dir)
                if (info == null || info.first != expected || !info.second) bad10 += "${d.ifEmpty { target }}: indexed ${info?.first}, expected $expected, thumbnail ${info?.second}"
                comics.put(JSONObject().put("dir", dir.path).put("name", dir.name).put("pageCount", info?.first ?: 0))
            }
            L[9] = if (plan.comicDirs.isEmpty()) layer(10, "skip", "No comic folders") else if (bad10.isEmpty()) layer(10, "pass", "${plan.comicDirs.size} comic(s) indexed with valid thumbnails") else layer(10, "fail", "Index cross-check failed", bad10)
            val anyFail = L.any { it.getString("status") == "fail" }
            return res(if (anyFail) "failed" else "done", null, base.put("finalDir", dest.path).put("comics", comics).put("passwordUsed", pw ?: JSONObject.NULL).put("nested", JSONArray(plan.nested.map { File(dest, it).path })))
        } catch (e: InterruptedException) {
            stage.deleteRecursively(); return res("cancelled", "Cancelled")
        } catch (e: Exception) {
            stage.deleteRecursively(); return res("failed", e.message ?: e.javaClass.simpleName)
        }
    }

    fun sha256Text(s: String): String = MessageDigest.getInstance("SHA-256").digest(s.toByteArray()).joinToString("") { "%02x".format(it) }
}
