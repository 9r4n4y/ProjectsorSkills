# Folio v3.6

- **Zero-Flicker GPU Scroll-Mode Zoom**: Replaced the layout-width commit step with a pure viewport-sized GPU `translate3d`/`scale` zoom stage—matching Tap mode's exact architecture. Pinching, panning, double-tapping, and releasing your fingers now stay 100% locked in place with zero flicker, zero force-adjust jump, and seamless vertical scrolling through the comic while zoomed in.
- **Version Bump**: Updated code/build version to `3.6` (`3.6.0`, Android `versionCode 9`, `Folio-v3.6-debug.apk`).
