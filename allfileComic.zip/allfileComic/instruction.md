# Android next-version update — implementation brief for the coding AI

## Request

Update the supplied Comic Library project and deliver a new, installable Android APK. Fix the crash/startup risk and Android usability issues below. Do not just describe fixes: inspect the actual app, implement the fixes, build the APK, run automated and device/emulator checks where available, and report exactly what was tested. Do not claim a crash is fixed unless the app has been launched and verified on Android. If a real device is unavailable, clearly say so and provide the precise logcat command/instructions needed to finish validation.

## What happened in the previous APK build

1. The input archive, `offline-comic-library-manager.zip`, contained a React/Vite/TypeScript comic-library UI, shared TypeScript logic, a Capacitor 7 Android wrapper, and native Kotlin Android database, scanner, archive extraction, background-job, and reader support. It was not a ready-made APK.
2. The project supplied `scripts/build-apk.mjs` and `scripts/prepare-android.mjs`. The intended pipeline builds the web UI, generates/synchronizes the Capacitor Android project, writes `schema.json` into Android assets, copies the custom Kotlin plugin/manifest, adds Android archive-engine Gradle dependencies, and runs Gradle `assembleDebug`.
3. `npm ci` completed successfully. The production UI build succeeded and created a single-file `dist/index.html` of about 694 KB. Capacitor generated the Android project and synced the web assets.
4. The first Gradle attempt failed because the sandbox had Java 21 runtime only, not a JDK/compiler (`javac`). OpenJDK 21 development tools were installed.
5. The sandbox is ARM64, while Android’s AAPT2 executable is x86-64. Gradle could not run AAPT2 natively. x86-64 user-mode emulation/runtime support was enabled, after which the Android build proceeded.
6. The APK then built successfully. Gradle compiled the Kotlin source and included the 7-Zip JNI library for `arm64-v8a`, `armeabi-v7a`, `x86`, and `x86_64`; the web app and schema were assets inside the APK. The manifest had no `INTERNET` permission. Commons Compress and XZ were Gradle runtime dependencies and were packaged into the APK. The APK was debug-signed.
7. The first APK was about 9.7 MB. After the user reported that it crashed on launch, the project was inspected. Startup calls `ComicNativeApp.onCreate()` → `ComicApp.ensure()` → `ComicDb` → database migrations. The first migration unconditionally created an FTS5 virtual table. Since Android platform SQLite may not include FTS5, this was identified as a **likely**, not device-log-confirmed, cause of a crash before the first screen. Android database migration code was changed to translate that table to an FTS4 virtual table. The updated APK compiled successfully at about 9.8 MB.
8. There was no attached Android device, emulator launch, or crash log in this environment. Therefore, the FTS5 diagnosis and FTS4 fix have not been confirmed by a runtime launch. The coding AI must treat startup verification and device logcat as priority work, not assume the inference was correct.

The previous APK used application ID `app.comiclib.mobile`, `versionCode 1`, and `versionName 1.0`. Preserve the app ID. For this update, increment versionCode (at least 2) and set an appropriate newer versionName. Preserve the signing certificate/key if the user expects an in-place upgrade; changing the debug signing key can make Android reject the update over an already installed copy. Never silently instruct the user to clear app data, because that can discard app settings/database state. If the signing key cannot be preserved, disclose that limitation before suggesting uninstall/reinstall.

## Crash and startup reliability

- Inspect and validate the Android FTS compatibility change. Confirm the FTS4 DDL is accepted on the project’s minimum supported Android SQLite version (min SDK is currently 23), including the `notindexed` and tokenizer options used. Ensure every migration succeeds and is transactional.
- Prefer runtime capability detection/fallback if appropriate: use FTS5 when supported, otherwise create the supported fallback; do not catch and hide unrelated SQL/schema failures. Make error reporting visible and useful rather than crashing with no diagnostics.
- Test both a clean install and upgrade from the prior database schema. Verify `ComicNativeApp` and plugin initialization, SQLite migrations, WebView asset loading, Capacitor plugin registration, and the first screen.
- Add regression tests for Android migration SQL or a testable migration helper so a future schema change cannot reintroduce an unsupported FTS feature without a clear failure.
- Capture Android logcat on launch and exercise the app. Investigate the actual fatal exception if any; do not assume the earlier FTS hypothesis is the only cause.

## Android UI must respect the status/navigation bars

The app currently declares `viewport-fit=cover`, and its root/page content can occupy the whole viewport. The reader has a `fixed inset-0` overlay and a toolbar with a `safe-t` class, but the main app shell does not have consistent status-bar inset handling. The project targets Android 35, where edge-to-edge behavior makes explicit system-bar handling especially important. Fix this consistently rather than applying a one-off margin to a screen.

Requirements:
- No interactive app content may be drawn under the Android status bar or behind its icons. Buttons, search, dialogs, reader toolbar controls and sliders must be fully visible and tappable below/inside safe insets.
- Handle the bottom navigation/gesture inset too, including reader controls and dialogs.
- Choose and implement one coherent strategy: either native window insets/decor-fits with content laid out below system bars, or deliberate edge-to-edge with native `WindowInsets` conveyed to CSS variables and applied consistently. Do not mix incompatible native and CSS padding approaches or double-apply insets.
- Check Capacitor Android 7 and target SDK 35 behavior on representative Android versions. Update the viewport/CSS/native window configuration as appropriate. Verify both normal app screens and full-screen reader, portrait/landscape, gesture and three-button navigation, display cutouts if available, and status-bar contrast/icons in light and dark themes.
- Add a screenshot-based/manual checklist or instrumentation/UI test confirming topmost buttons are not occluded and can be tapped.

## Comic reader: improve Android reading modes

Relevant implementation to inspect: `src/features/reader/Reader.tsx`, `src/features/reader/PageImage.tsx`, reader settings in `src/features/settings/Settings.tsx`, plus `src/index.css` and the Capacitor/native system-bar configuration. The reader currently has scroll, paged/tap, and auto modes, a `type=range` page scrubber, pointer/touch handlers, transforms for zoom/pan, and top/bottom overlay controls. It uses viewport-height units in the scroll layout and currently lays paged images from the top when width-fitted. The user describes the scrubber/slider as glitchy, the modes as unattractive on Android, unwanted gaps between images in slider/continuous mode, and tap-next pages not centered.

Implement a polished, touch-first Android reader:

1. **Page scrubber / slider stability:** Dragging the page slider must be smooth, track the finger, not jump/flicker, not accidentally trigger the reader’s page tap/swipe handler, and not cause excessive image reloads/renders. Pointer down/move/up/cancel must be handled consistently; prevent event bubbling into the page gesture recognizer. Keep keyboard/accessibility input and screen-reader label. Decide whether page preview follows live dragging or commits on release, but make it predictable. Show current/total page accurately and make the thumb easy to grab on touchscreens.
2. **Tap-to-next/paged mode:** For every page, center the image horizontally and vertically within the actual usable reader viewport (after safe-area/system-bar insets and any visible controls). Center both portrait and landscape pages without distortion. Preserve an intentional fit behavior (contain/fit-width/fit-height) and reset zoom/pan safely when changing pages or modes. Taps in left/right zones and on-screen navigation must work without being stolen by pinch/pan or reader controls.
3. **Continuous/slider reading:** Remove unintended blank gaps between consecutive comic page images. Do not reserve placeholder minimum heights or apply margins/padding/gaps that create white/black bands between already-loaded pages. Images should be `display:block`, sit directly adjacent, and scale consistently to the available width; lazy-loading placeholders should not look like permanent gaps. Preserve readable scrolling and restore the last read page reliably.
4. **Native Android styling:** Make reading modes coherent with Android touch targets, typography, edge-to-edge/safe-area rules, gestures, and controls. Give scroll, tap/paged and auto modes clear, understandable labels. Ensure controls are discoverable and do not overlap the comic or status/navigation bars. Avoid desktop-only visual treatment on narrow screens.
5. **Visual regression checks:** Verify long/short pages, portrait/landscape pages, mixed dimensions, large images, rotation, zoom/pinch, tap zones, gestures, page changes, slider scrub, entering/exiting reader, and resume position on an actual Android device or emulator. Confirm no page gaps in continuous mode and exact center alignment in paged mode.

## Android hardware Back behavior

The user expects Android Back to navigate backward inside the app rather than closing it. Current web code has `useBackClose()` using `popstate` for some overlays, but do not assume this handles Capacitor’s native hardware Back consistently.

Implement a clear priority stack for Android system Back:
1. Close the topmost dialog/popover/drawer or other transient overlay if one is open.
2. If reading, exit the reader back to the comic/library screen (preserve reading progress).
3. If on a nested screen, return to its parent/previous app screen.
4. If already at the top-level library with nothing to dismiss, keep the task/app alive or move it to background; do not call `App.exitApp()` or let the default WebView/Activity behavior terminate it. If the desired root behavior needs native `moveTaskToBack(true)` or Capacitor App plugin `minimizeApp()`, implement it in a supported, lifecycle-safe way and explain the choice.

Use Capacitor’s Android back-button event/native integration correctly, avoid duplicate back listeners, and ensure web-history overlay handling does not swallow the next Back press or create an infinite history loop. Test the physical/system Back button and Android gesture-back on each app state above. Do not trap Back so that users cannot leave the reader or app intentionally.

## Build, release, and quality requirements

- Keep the app offline and do not add the `INTERNET` permission unless a feature explicitly needs it and the user approves.
- Keep all app dependencies/extractor engines packaged. Inspect final APK contents and verify expected Kotlin classes, web assets/schema, Java libraries and native archive libraries for each intended ABI. `7-Zip-JBinding`, Commons Compress and XZ are important to archive extraction. Do not claim a particular archive format/ABI works unless the dependency and runtime path were verified.
- Build from a clean checkout/archive with documented steps; make the build script fail fast with actionable messages when a JDK, SDK, platform, build-tools, SDK license or dependency is missing. Do not depend on undocumented state from the old sandbox. Add CI or a repeatable build check if practical.
- Run `npm test`, `npm run typecheck`, and `npm run build:apk` (or the project’s supported equivalent). Fix regressions rather than merely reporting them.
- Verify the manifest has no unexpected permissions, check package ID/version, inspect APK size and hash, and confirm the APK is installable. Test install/upgrade, cold start, normal navigation, database migration, reader modes and Android Back.
- Deliver the new APK and a concise changelog/test report. Include device model and Android version for runtime tests, and include relevant logcat evidence. Clearly list any tests that could not be run.

## Definition of done

The new APK installs and launches without crashing on a fresh install and an upgrade path; the app UI and controls are below system bars and tappable; reader scrubber is stable; scroll mode has no unwanted page gaps; tap/paged mode centers every page; Android Back navigates within the app and does not unexpectedly exit at the library root; dependencies/extractors remain bundled; and build/runtime results are honestly reported.
The new APK installs and launches without crashing on a fresh install and an upgrade path; the app UI and controls are below system bars and tappable; reader scrubber is stable; scroll mode has no unwanted page gaps; tap/paged mode centers every page; Android Back navigates within the app and does not unexpectedly exit at the library root; dependencies/extractors remain bundled; and build/runtime results are honestly reported.
read those all and use the images as reference and fix my code and give the    new code.

 also note after this complete fix this ui problem also, The error happens in a way that this is the only page where I zoom out. Then it goes beyond the UI and get glitched out. And also at top you can see that there is overlapping UI glitched out out of the way. Fix that also. Also there is a problem in buttons I have seen. They are weird in many places or in most places like sometimes it show animation, sometime it don't. It's like there's a button and there's a button over it, which is invisible. Like try to understand what I'm trying to say. The functions happen but I don't see an emission and then I sometimes see animation but don't see the function happening to fix this, fix every buttons everywhere. And it must operate nicely when clicked. Like it sees the click and opens the UI stuff or whatever the thing it is or whatever the function it is. And also the grid size setting is also bugged. It only do small and large and do not do in betweens. So fix that also.