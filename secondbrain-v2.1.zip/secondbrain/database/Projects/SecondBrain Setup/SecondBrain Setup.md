# SecondBrain Setup

:::quick-info
Common name: SecondBrain project setup
State: in progress
Started: 2026-10-12
:::

The working plan for building and keeping this SecondBrain wiki running:
plain Markdown files, one folder per note, tags in the dash notation, and
an AI librarian with auditable rules.

## Remaining steps

- [x] Decide the folder structure and the allowed file list
- [x] Write the tag notation down in `_tags.md`
- [x] Set up the local website with the ranking search
- [x] Connect the AI librarian through the MCP server
- [ ] Move the first hundred notes in from the old wiki
- [ ] Set up the nightly backup to the external drive

## Design decisions

The search engine has no semantic model: it ranks notes from tags, keywords,
synonyms and links only. Tags boost more than keywords, and the coverage
factor makes a note that matches every part of a query beat a note that
matches one part many times. The full text stays in ordinary files, so any
editor can open it and no app can hold it hostage.

The housekeeping rhythm is written in the README: the backup tool keeps a
second copy up to date, the health check catches broken links and stray
tags, and every AI change lands in `logs/` where it can be undone.

## Connected notes

[[Garden Plan 2026]]

## Reference sources

- [Markdown guide](https://www.markdownguide.org/) — accessed 2026-10-12

:::meta
Created: 2026-10-12
Updated: 2026-10-30
Pinned: yes
:::
