Purpose: reflections and daily pages
