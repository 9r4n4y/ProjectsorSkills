# Lentil Soup for Cold Evenings

:::quick-info
Common name: Lentil Soup
Serves: 6
Time: 45 minutes
Often paired with: [[Quick Vegetable Pasta for Weeknights]]
:::

A thick, warming stew for autumn evenings. Red lentils break down into the
broth so there is no blending, and the whole pot costs almost nothing.

## Ingredients

- 300 g red lentils
- 2 carrots, diced
- 2 onions, diced
- 4 garlic cloves, sliced
- 1 tin tomatoes
- 1.5 litres vegetable stock
- 2 tsp cumin

## Method

1. Soften the onions, carrots and garlic in oil for 8 minutes.
2. Add the cumin, lentils, tomatoes and stock. Simmer 30 minutes.
3. Season, finish with lemon juice, eat with bread.

## My notes

- Freezes well in single portions; thins nicely with a little hot water.

## Connected notes

[[Quick Vegetable Pasta for Weeknights]]
[[Spanish Kitchen Words]]

## Reference sources

:::meta
Created: 2026-10-18
Updated: 2026-10-28
:::
