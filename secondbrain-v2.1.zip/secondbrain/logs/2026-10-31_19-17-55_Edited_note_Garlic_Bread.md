# Edited note Garlic Bread

- **When:** 2026-10-31 19:17:55
- **Who:** user
- **Title:** Edited note Garlic Bread

## What was done

- File: `database/Recipes/Garlic Bread/Garlic Bread.md`
- Reason: manual edit

**Before**

```markdown
# Garlic Bread

:::quick-info
Common name: Cheesy Garlic Bread
Serves: 4
Time: 15 minutes
Often paired with: [[Quick Vegetable Pasta for Weeknights]]
:::

The standard side dish for any pasta night. A baguette, butter, garlic and
a hot oven — ready faster than the pasta takes to boil.

## Ingredients

- 1 baguette
- 100 g soft butter
- 4 garlic cloves, crushed
- 60 g cheddar, grated (optional)
- Parsley, chopped

## Method

1. Heat the oven to 200 °C.
2. Mix the butter with the crushed garlic and most of the parsley.
3. Slice the baguette almost through, spread the garlic butter between the
   slices, and wrap loosely in foil.
4. Bake for 10 minutes, open the foil, add the cheese if using, and bake
   5 minutes more until golden.

## My notes

- Crushed garlic beats chopped garlic here — it spreads into the butter.

## Connected notes

[[Quick Vegetable Pasta for Weeknights]]

## Reference sources

:::meta
Status: verified
Created: 2026-10-16
Updated: 2026-10-16
:::

```

**After**

```markdown
# Garlic Bread

:::quick-info
Common name: Cheesy Garlic Bread
Serves: 4
Time: 15 minutes
Often paired with: [[Quick Vegetable Pasta for Weeknights]]
:::

The standard side dish for any pasta night. A baguette, butter, garlic and
a hot oven — ready faster than the pasta takes to boil.

## Ingredients

- 1 baguette
- 100 g soft butter
- 4 garlic cloves, crushed
- 60 g cheddar, grated (optional)
- Parsley, chopped

## Method

1. Heat the oven to 200 °C.
2. Mix the butter with the crushed garlic and most of the parsley.
3. Slice the baguette almost through, spread the garlic butter between the
   slices, and wrap loosely in foil.
4. Bake for 10 minutes, open the foil, add the cheese if using, and bake
   5 minutes more until golden.

## My notes

- Crushed garlic beats chopped garlic here — it spreads into the butter.

## Connected notes

[[Quick Vegetable Pasta for Weeknights]]

## Reference sources

:::meta
Status: verified
Created: 2026-10-16
Updated: 2026-10-31
:::
e
```

## How to undo

:::undo
{
 "title": "Edit note Garlic Bread",
 "steps": [
  {
   "op": "write",
   "path": "database/Recipes/Garlic Bread/Garlic Bread.md",
   "before": "# Garlic Bread\n\n:::quick-info\nCommon name: Cheesy Garlic Bread\nServes: 4\nTime: 15 minutes\nOften paired with: [[Quick Vegetable Pasta for Weeknights]]\n:::\n\nThe standard side dish for any pasta night. A baguette, butter, garlic and\na hot oven — ready faster than the pasta takes to boil.\n\n## Ingredients\n\n- 1 baguette\n- 100 g soft butter\n- 4 garlic cloves, crushed\n- 60 g cheddar, grated (optional)\n- Parsley, chopped\n\n## Method\n\n1. Heat the oven to 200 °C.\n2. Mix the butter with the crushed garlic and most of the parsley.\n3. Slice the baguette almost through, spread the garlic butter between the\n   slices, and wrap loosely in foil.\n4. Bake for 10 minutes, open the foil, add the cheese if using, and bake\n   5 minutes more until golden.\n\n## My notes\n\n- Crushed garlic beats chopped garlic here — it spreads into the butter.\n\n## Connected notes\n\n[[Quick Vegetable Pasta for Weeknights]]\n\n## Reference sources\n\n:::meta\nStatus: verified\nCreated: 2026-10-16\nUpdated: 2026-10-16\n:::\n"
  }
 ]
}
:::

---

Log files are never edited or deleted after they are written.
