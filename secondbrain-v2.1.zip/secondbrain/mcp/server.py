"""SecondBrain MCP server (spec 5, 15).

A thin layer over the core engine: the same parser, the same search engine
and the same store as the website, so the AI has every capability the user
has on the website - no hidden powers and no missing ones.

Transport: newline-delimited JSON-RPC 2.0 on stdio (the standard MCP stdio
transport). Methods: initialize, tools/list, tools/call, ping.

Run from an MCP client config:
    {"command": "python3", "args": ["/path/to/secondbrain/mcp/server.py"]}

Librarian rules enforced here (spec 6, 15):
- paths outside the allowed structure are refused (core/paths.py),
- only existing tags can be applied; a new tag is proposed under the
  *Proposed tags* heading in _tags.md and becomes usable once approved,
- every write creates its log file automatically, named User or AI,
- 'My notes' is append-only,
- the AI must ask before creating a new folder: the tools answer with
  needs_approval=true and only create the folder when the request sends
  approve_new_folder=true (i.e. the user has agreed).

v2: note verification was removed - notes carry no verified/unverified
state and no tool sets or reports a Status. Tags are independent labels
(no sub-tag hierarchy).
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from core import healthcheck, images, indexer, logger, paths, search, store  # noqa: E402
from core import tags as tags_mod  # noqa: E402
from core.textutil import key_of  # noqa: E402

PROTOCOL_VERSION = "2024-11-05"


# --------------------------------------------------------------------------
# Tool implementations (each returns a JSON-serializable dict)
# --------------------------------------------------------------------------

def _resolve_note(path_or_name: str) -> str:
    """Accept a rel path or a bare note name; return the note rel path."""
    p = store.note_md_path(path_or_name)
    if p.exists():
        return paths.rel(p)
    found = store.note_exists(path_or_name)
    if found:
        return paths.rel(found)
    raise FileNotFoundError(f"Note {path_or_name!r} not found in this wiki.")


def _ensure_folder(folder_rel: str, approve_new_folder: bool):
    folder = paths.safe_join(paths.DATABASE, *folder_rel.split("/")) \
        if folder_rel else paths.DATABASE
    if not folder.exists():
        if not approve_new_folder:
            return {"needs_approval": True,
                    "question": f"The folder {folder_rel!r} does not exist. "
                                "The AI must ask before creating a new folder. "
                                "Ask the user; if they approve, call again with "
                                "approve_new_folder=true."}
        store.create_folder("/".join(folder_rel.split("/")[:-1]),
                            folder_rel.split("/")[-1] if folder_rel else "",
                            who="ai")
    return None


def t_search_notes(a: dict) -> dict:
    return search.search(
        q=a.get("query", ""),
        mode=a.get("mode", "rank"),
        tags_sel=a.get("tags") or [],
        folders=a.get("folders") or [],
        folder_only=bool(a.get("folder_only")),
        scope=a.get("scope") or ["everything"],
        tag_mode=a.get("tag_mode", "rank"),
        kw_mode=a.get("keyword_mode", "rank"),
        include_connected=bool(a.get("include_connected")),
        status=a.get("status"),
        date_from=a.get("date_from"),
        date_to=a.get("date_to"),
        limit_to=a.get("limit_to") or None,
        offset=int(a.get("offset", 0)),
        limit=int(a.get("page_size", 20)),
    )


def t_suggest_tags(a: dict) -> dict:
    from website.server import suggest          # one implementation, shared
    idx = indexer.load_index()
    return suggest(idx, a.get("query", ""), a.get("kind", "all"))


def t_list_tags(a: dict) -> dict:
    ext = tags_mod.extract_all_notes_tags()
    mt = tags_mod.load_master()
    return {"tags": ext["tags"], "rows": ext["rows"], "counts": ext["counts"],
            "unapproved": ext["unapproved"], "proposed": ext["proposed"],
            "near_duplicates": ext["near_duplicates"],
            "used_once": ext["used_once"], "approved": mt.all_tags()}


def t_list_folders(a: dict) -> dict:
    return {"tree": store.folder_tree(), "subjects": store.list_subjects()}


def t_read_note(a: dict) -> dict:
    rp = _resolve_note(a.get("path", "") or a.get("name", ""))
    p = paths.ROOT / rp
    idx = indexer.load_index()
    e = idx["files"].get(rp)
    doc = store.parse_note(p.read_text(encoding="utf-8"), rp)
    return {"path": rp, "name": doc.title,
            "raw": doc.raw, "hash": store.text_sha256(doc.raw),
            "folder": e["folder"] if e else "", "tags": e["tags"] if e else [],
            "meta": doc.meta, "quick_info_rows": [
                {"label": r.label, "value": r.value, "group": r.group}
                for r in doc.quick_info_rows],
            "connected": doc.connected, "references": doc.references,
            "broken_links": idx["broken_links"].get(rp, [])}


def t_get_connections(a: dict) -> dict:
    rp = _resolve_note(a["path"])
    idx = indexer.load_index()
    doc = store.parse_note((paths.ROOT / rp).read_text(encoding="utf-8"), rp)
    return {
        "connected": [{"name": t, "exists": key_of(t) in
                       {key_of(x["title"]) for x in idx["files"].values()}}
                      for t in doc.connected],
        "linked_in_text": [{"target": t, "word": w} for t, w in doc.linked_in_text],
        "references": doc.references,
    }


def t_remove_broken_link(a: dict) -> dict:
    """Health helper: drop every reference to a note name that does not
    exist (the words in the text stay)."""
    rp = _resolve_note(a["path"])
    return store.remove_broken_link(rp, a["link"], "ai")


def t_create_note(a: dict) -> dict:
    gate = _ensure_folder(a.get("folder", ""), bool(a.get("approve_new_folder")))
    if gate:
        return gate
    out = store.create_note(a.get("folder", ""), a["name"], a.get("tags") or [],
                            a.get("text"), a.get("quick_info"), "ai",
                            a.get("reason", ""))
    out.update(store.propose_tags(a.get("tags") or [], "ai",
                                  a.get("reason", "")))
    return out


def t_edit_note(a: dict) -> dict:
    rp = _resolve_note(a["path"])
    return store.save_note_text(rp, a["text"], a.get("base_hash"), "ai",
                                bool(a.get("force")), a.get("reason", ""))


def t_append_my_notes(a: dict) -> dict:
    rp = _resolve_note(a["path"])
    return store.append_to_my_notes(rp, a["text"], "ai", a.get("reason", ""))


def t_move_note(a: dict) -> dict:
    rp = _resolve_note(a["path"])
    gate = _ensure_folder(a.get("folder", "") if a.get("folder") else "", True) \
        if a.get("folder") and not (paths.DATABASE / a["folder"]).exists() else None
    if gate:
        return gate
    return store.move_note(rp, a.get("folder", ""), a.get("name"), "ai")


def t_rename_note(a: dict) -> dict:
    """Rename in place: the note STAYS in its folder (v2 fix - the old
    version accidentally moved it to the database root)."""
    rp = _resolve_note(a["path"])
    note_dir = (paths.ROOT / rp)              # .../database/<Folder>/<Note>/<Note>.md
    folder_abs = note_dir.parent.parent       # .../database/<Folder>
    folder = ""
    if folder_abs != paths.DATABASE:
        folder = folder_abs.relative_to(paths.DATABASE).as_posix()
    return store.move_note(rp, folder, a["name"], "ai")


def t_edit_tags(a: dict) -> dict:
    rp = _resolve_note(a["path"])
    out = store.edit_tags(rp, a.get("add") or [], a.get("remove") or [], "ai")
    if out.get("proposed"):
        out.update(store.propose_tags(out["proposed"], "ai",
                                      a.get("reason", "")))
    return out


def t_connect_notes(a: dict) -> dict:
    rp = _resolve_note(a["path"])
    return store.edit_connections(rp, a.get("add") or [], a.get("remove") or [],
                                  a.get("edit_link"), "ai")


def t_add_reference(a: dict) -> dict:
    rp = _resolve_note(a["path"])
    return store.edit_references(rp, a.get("add"), a.get("remove_url"), "ai")


def t_edit_quick_info(a: dict) -> dict:
    rp = _resolve_note(a["path"])
    return store.set_quick_info(rp, a.get("text"), "ai")


def t_add_attachment(a: dict) -> dict:
    import base64
    rp = _resolve_note(a["path"])
    data = base64.b64decode(a["data_base64"])
    return images.add_attachment(rp, a["filename"], data, "ai")


def t_edit_links(a: dict) -> dict:
    rp = _resolve_note(a["path"])
    return store.edit_links(rp, a["word"], a.get("target"),
                            a.get("make_note", True), "ai")


def t_edit_metadata(a: dict) -> dict:
    rp = _resolve_note(a["path"])
    return store.set_metadata(rp, a.get("meta", {}), "ai")


def t_export_metadata(a: dict) -> dict:
    rp = _resolve_note(a["path"])
    return {"path": rp, "text": store.export_metadata(rp)}


def t_crop_image(a: dict) -> dict:
    rp = _resolve_note(a["path"])
    return images.crop_image(rp, a["filename"], a["rect"],
                             a.get("mode", "keep_both"), "ai")


def t_delete_image(a: dict) -> dict:
    rp = _resolve_note(a["path"])
    return images.delete_image(rp, a["filename"], "ai")


def t_rename_tag(a: dict) -> dict:
    return store.rename_tag(a["from"], a["to"], "ai", run=bool(a.get("run")))


def t_merge_tags(a: dict) -> dict:
    return store.merge_tags(a["from"], a["into"], "ai", run=bool(a.get("run")))


def t_health_check(a: dict) -> dict:
    return healthcheck.health_check()


def _backup_target(a: dict) -> Path:
    import json as _json
    target = a.get("to") or store.load_settings().get("backup_destination")
    if not target:
        raise ValueError("No backup folder given. Pass 'to' (a folder OUTSIDE "
                         "the project) or set backup_destination in "
                         "core/settings.json.")
    t = Path(target).expanduser().resolve()
    if t == paths.ROOT or paths.ROOT in t.parents or t in paths.ROOT.parents:
        raise ValueError("The backup copy must live OUTSIDE the project folder.")
    return t


def t_backup_preview(a: dict) -> dict:
    from backup import backup as bk
    t = _backup_target(a)
    scope = a.get("scope", "whole")
    direction = a.get("direction", "backup")
    if direction == "backup":
        src_m, dst_m = bk.manifest(paths.ROOT, scope), bk.manifest(t, scope)
    else:
        src_m, dst_m = bk.manifest(t, scope), bk.manifest(paths.ROOT, scope)
    cmp = bk.compare(src_m, dst_m)
    return {"direction": direction, "to": str(t), "scope": scope,
            "counts": {k: len(v) for k, v in cmp.items()},
            "preview": bk.preview(cmp)}


def t_backup_run(a: dict) -> dict:
    from backup import backup as bk
    t = _backup_target(a)
    s = store.load_settings()
    if s.get("backup_destination") != str(t):
        s["backup_destination"] = str(t)
        store.save_settings(s)          # before the run, so the copy matches
    direction = a.get("direction", "backup")
    rep = bk.run(direction, t, a.get("scope", "whole"), approve=True,
                 keep_versions=int(a.get("keep", 10)), log_fn=lambda m: None)
    return rep


def t_backup_restore(a: dict) -> dict:
    a = dict(a)
    a["direction"] = "restore"
    return t_backup_run(a)


def t_backup_verify(a: dict) -> dict:
    from backup import backup as bk
    t = _backup_target(a)
    return bk.verify_detailed(t, a.get("scope", "whole"), log_fn=lambda m: None)


def t_undo_change(a: dict) -> dict:
    return {"log": logger.apply_undo(a["log"], "ai")}


def t_saved_searches(a: dict) -> dict:
    action = a.get("action", "list")
    if action == "save":
        return store.save_search(a["name"], a.get("params", {}), "ai")
    if action == "delete":
        return store.delete_saved_search(a["name"])
    if action == "run":
        params = a.get("params") or next(
            (x["params"] for x in store.saved_searches()
             if x["name"] == a.get("name")), {})
        return search.search(**{**params, "q": a.get("query", params.get("q", ""))})
    return {"saved_searches": store.saved_searches()}


def t_file_note(a: dict) -> dict:
    text = a.get("text")
    if not text and a.get("inbox_file"):
        p = paths.safe_join(paths.INBOX, a["inbox_file"])
        if not p.exists():
            raise FileNotFoundError(f"Inbox file {a['inbox_file']!r} not found.")
        text = p.read_text(encoding="utf-8")
    gate = _ensure_folder(a.get("folder", ""), bool(a.get("approve_new_folder")))
    if gate:
        return gate
    return store.file_note(text, a["name"], a.get("folder", ""),
                           a.get("tags") or [], "ai", a.get("reason", ""))


def t_get_structure(a: dict) -> dict:
    read = lambda n: (paths.ROOT / n).read_text(encoding="utf-8")  # noqa: E731
    return {
        "allowed_structure": {
            "root_files": paths.ROOT_FILES,
            "top_folders": paths.TOP_FOLDERS,
            "note_folder": ["<Note Name>.md", "tags.txt", "attachments/"],
            "database": "Subject folders to any depth; optional _subject.md "
                        "per folder (Purpose, Template, Inherits). There are "
                        "no hidden/private folders any more.",
        },
        "README.md": read("README.md"),
        "StructureOFnotes.md": read("StructureOFnotes.md"),
    }


def t_approve_tags(a: dict) -> dict:
    """Move tags from *Proposed tags* to the approved list. The user's
    approval, relayed by the AI (spec 15)."""
    mt = tags_mod.load_master()
    approved, unknown = [], []
    master_path = paths.ROOT / "_tags.md"
    old = master_path.read_text(encoding="utf-8")
    lines = old.splitlines()
    out = []
    for t in a.get("tags") or []:
        t = tags_mod.validate_tag(t)
        if any(key_of(t) == key_of(p) for p in mt.proposed):
            approved.append(t)
        elif mt.has(t):
            approved.append(t)          # already approved
        else:
            unknown.append(t)
    for ln in lines:
        m = None
        stripped = ln.strip()
        if stripped.startswith("- "):
            cand = stripped[2:].strip().split(":")[0].split(",")[0].strip()
            if any(key_of(cand) == key_of(t) for t in approved) and \
                    any(key_of(cand) == key_of(p) for p in mt.proposed):
                continue                 # drop from Proposed
        out.append(ln)
    new_text = "\n".join(out)
    if approved:
        new_text = reinsert_approved(new_text, approved)
    if new_text != old:
        store.atomic_write(master_path, new_text)
        logger.new_log("ai", f"Approved tag{'s' if len(approved) > 1 else ''} "
                       f"{', '.join(approved)}",
                       "- Moved from *Proposed tags* to *Approved tags* in "
                       "`_tags.md` at the user's direction.",
                       undo={"title": "Approve tags", "steps": [
                           {"op": "write", "path": "_tags.md", "before": old}]})
    return {"approved": approved, "unknown": unknown}


def reinsert_approved(text: str, tags: list[str]) -> str:
    """Insert approved tags under their major-tag heading in Approved tags."""
    import re as _re
    lines = text.splitlines()
    out = []
    inserted = set()
    current_major = None
    for ln in lines:
        out.append(ln)
        m = _re.match(r"^###\s+(\S+)", ln.strip())
        if m:
            current_major = m.group(1)
            for t in tags:
                if t.split("-")[0].lower() == current_major.lower() \
                        and t not in inserted:
                    out.append(f"- {t}")
                    inserted.add(t)
    # any tag whose major heading did not exist: add under ## Approved tags
    rest = [t for t in tags if t not in inserted]
    if rest:
        final = []
        done = False
        for ln in out:
            final.append(ln)
            if not done and _re.match(r"(?im)^## Approved tags\s*$", ln.strip()):
                major = rest[0].split("-")[0]
                final.append(f"\n### {major}\n" + "\n".join(f"- {t}" for t in rest))
                done = True
        out = final
    return "\n".join(out)


# --------------------------------------------------------------------------
# Tool definitions (name, description, schema, function)
# --------------------------------------------------------------------------

def S(**props) -> dict:
    required = props.pop("required", None)
    schema = {"type": "object", "properties": props}
    if required:
        schema["required"] = required
    return schema


STR = {"type": "string"}
BOOL = {"type": "boolean"}
NUM = {"type": "number"}
ARR_S = {"type": "array", "items": STR}

TOOLS = [
    ("search_notes",
     "Run the full ranking search (same engine as the website). Returns "
     "ranked NOTES with score breakdowns, never text chunks. Modes: "
     "rank (default; tags/keywords only boost), strict_keyword (every query "
     "word required), strict_tag (all selected tags required).",
     S(query=STR, tags=ARR_S, folders=ARR_S, folder_only=BOOL,
       scope={"type": "array", "items": {"type": "string", "enum": [
           "everything", "file name", "tags", "headings", "body",
           "folder path"]}},
       tag_mode={"type": "string", "enum": ["rank", "require"]},
       keyword_mode={"type": "string", "enum": ["rank", "require"]},
       mode={"type": "string", "enum": ["rank", "strict_keyword", "strict_tag"]},
       include_connected=BOOL, status=STR, date_from=STR, date_to=STR,
       limit_to=ARR_S, offset=NUM, page_size=NUM),
     t_search_notes),
    ("suggest_tags", "Type-ahead over existing tags and folders (same as the "
     "website filter bar). Only things that exist can be chosen.",
     S(query=STR, kind={"type": "string", "enum": ["all", "tag", "folder"]}),
     t_suggest_tags),
    ("list_tags", "The full tag tree with usage counts, unapproved tags, "
     "near-duplicates and proposed tags (the auto tag extractor).",
     S(), t_list_tags),
    ("list_folders", "The subject folder tree with note counts.",
     S(), t_list_folders),
    ("list_subjects", "Alias of list_folders: the subject folder tree.",
     S(), t_list_folders),
    ("read_note", "The full text and metadata of one note (by rel path or "
     "unique note name).", S(path=STR, name=STR, required=["path"]),
     t_read_note),
    ("get_connections", "Connected notes (out), links written "
     "in text, and the reference sources of a note. No backlinks (v2).",
     S(path=STR, required=["path"]), t_get_connections),
    ("remove_broken_link", "Health helper: remove every wiki reference to a "
     "note name that does not exist; words written in the text stay.",
     S(path=STR, link=STR, required=["path", "link"]), t_remove_broken_link),
    ("file_note", "The librarian's main tool: file a raw note (text or an "
     "inbox file) into the deepest matching folder, or add the material to "
     "an existing note. Asks before creating a folder; proposes unknown "
     "tags for the user to approve.",
     S(name=STR, text=STR, inbox_file=STR, folder=STR, tags=ARR_S, reason=STR,
       approve_new_folder=BOOL, required=["name"]),
     t_file_note),
    ("create_note", "Create a note: the folder with <Note Name>.md, tags.txt "
     "and attachments/ is created. New folders need approve_new_folder=true "
     "after asking the user.",
     S(name=STR, folder=STR, text=STR, tags=ARR_S, quick_info=STR, reason=STR,
       approve_new_folder=BOOL, required=["name"]),
     t_create_note),
    ("edit_note", "Edit a note's raw Markdown. 'My notes' is append-only; "
     "existing lines cannot be changed. Pass base_hash (from read_note) to "
     "detect concurrent edits.",
     S(path=STR, text=STR, base_hash=STR, force=BOOL, reason=STR,
       required=["path", "text"]), t_edit_note),
    ("append_my_notes", "Append a line/entry at the end of the user's "
     "'My notes' section (the only allowed change there).",
     S(path=STR, text=STR, reason=STR, required=["path", "text"]),
     t_append_my_notes),
    ("move_note", "Move a note to another folder and/or rename it; every "
     "link to it is rewritten.", S(path=STR, folder=STR, name=STR,
                                   required=["path"]), t_move_note),
    ("rename_note", "Rename a note (stays in its folder); links rewritten.",
     S(path=STR, name=STR, required=["path", "name"]), t_rename_note),
    ("edit_tags", "Add or remove tags on a note. Tags are independent "
     "labels (no hierarchy). Only existing tags can be applied; unknown "
     "ones are proposed in _tags.md for approval.",
     S(path=STR, add=ARR_S, remove=ARR_S, reason=STR, required=["path"]),
     t_edit_tags),
    ("connect_notes", "Add/remove connected notes ([[File Name]] lines) or "
     "edit a link written in text (change target or unlink).",
     S(path=STR, add=ARR_S, remove=ARR_S,
       edit_link={"type": "object", "properties": {
           "target": STR, "word": STR, "new_target": STR, "unlink": BOOL}},
       required=["path"]), t_connect_notes),
    ("add_reference", "Add or remove a reference source ([Title](url) with "
     "the date accessed). The url is auto-https: domain.com becomes "
     "https://domain.com.",
     S(path=STR, add={"type": "object", "properties": {
         "title": STR, "url": STR, "accessed": STR}, "required": ["url"]},
       remove_url=STR, required=["path"]), t_add_reference),
    ("edit_quick_info", "Replace the note's quick info block (the raw text "
     "between :::quick-info and :::).",
     S(path=STR, text=STR, required=["path", "text"]), t_edit_quick_info),
    ("add_attachment", "Add an image to a note's attachments/ folder "
     "(base64 data).",
     S(path=STR, filename=STR, data_base64=STR, required=["path", "filename",
                                                           "data_base64"]),
     t_add_attachment),
    ("edit_links", "Change which words are a link and where it points "
     "(make_note=true for a wiki link, false for a web address), or remove "
     "the link and keep the words (target=null).",
     S(path=STR, word=STR, target=STR, make_note=BOOL, required=["path", "word"]),
     t_edit_links),
    ("edit_metadata", "Change the note's metadata block (Created, Updated, "
     "Pinned). Notes carry no verification status (removed in v2).",
     S(path=STR, meta={"type": "object"}, required=["path"]), t_edit_metadata),
    ("export_metadata", "The per-note plain-text export: file name, folder "
     "path, tags, dates, connected notes, references, attachments.",
     S(path=STR, required=["path"]), t_export_metadata),
    ("crop_image", "Crop an image (needs Pillow). The crop is saved as a NEW "
     "image; mode 'replace' backs the original up first, 'keep_both' keeps "
     "both.", S(path=STR, filename=STR,
                rect={"type": "object", "properties": {
                    "x": NUM, "y": NUM, "w": NUM, "h": NUM}},
                mode={"type": "string", "enum": ["replace", "keep_both"]},
                required=["path", "filename", "rect"]), t_crop_image),
    ("delete_image", "Delete an image; warns when the note still points to "
     "it and keeps the old file in backup history.",
     S(path=STR, filename=STR, required=["path", "filename"]), t_delete_image),
    ("rename_tag", "Rename a tag everywhere (descendants included). Returns "
     "a preview of every affected note first; run=true writes.",
     S(**{"from": STR, "to": STR, "run": BOOL}, required=["from", "to"]),
     t_rename_tag),
    ("merge_tags", "Merge one tag into another across all notes, with "
     "preview; run=true writes.", S(**{"from": STR, "into": STR, "run": BOOL},
                                     required=["from", "into"]), t_merge_tags),
    ("approve_tags", "The user approved proposed tags: move them from "
     "*Proposed tags* to *Approved tags* in _tags.md.",
     S(tags=ARR_S, required=["tags"]), t_approve_tags),
    ("health_check", "Broken links, notes with no tags, tags used once, "
     "near-duplicate tags, notes with no connections, files outside the "
     "allowed structure.", S(), t_health_check),
    ("backup_preview", "Preview a backup run: what is unchanged, changed, "
     "new, removed or moved.", S(to=STR, scope=STR, direction={
         "type": "string", "enum": ["backup", "restore"]}), t_backup_preview),
    ("backup_run", "Run the backup: copy only changed/new files, move "
     "renamed ones, keep replaced files in .versions/, verify every hash.",
     S(to=STR, scope=STR, keep=NUM, required=["to"]), t_backup_run),
    ("backup_restore", "Restore the project from a backup copy (same "
     "preview + hash check as backup_run).",
     S(to=STR, scope=STR, keep=NUM, required=["to"]), t_backup_restore),
    ("backup_verify", "Verify that the backup copy matches the live project "
     "by SHA-256.", S(to=STR, scope=STR, required=["to"]), t_backup_verify),
    ("undo_change", "Reverse a change using its log file (the log records "
     "how to undo it).", S(log=STR, required=["log"]), t_undo_change),
    ("saved_searches", "List, save, delete or run saved searches (query + "
     "folders + tags + modes).",
     S(action={"type": "string", "enum": ["list", "save", "delete", "run"]},
       name=STR, params={"type": "object"}, query=STR), t_saved_searches),
    ("get_structure", "The allowed folder/file structure plus the full text "
     "of README.md and StructureOFnotes.md.", S(), t_get_structure),
]

Dispatch = {name: fn for name, _d, _s, fn in TOOLS}


def tool_defs() -> list[dict]:
    return [{"name": n, "description": d, "inputSchema": s}
            for n, d, s, _f in TOOLS]


# --------------------------------------------------------------------------
# JSON-RPC over stdio
# --------------------------------------------------------------------------

def handle(msg: dict) -> dict | None:
    method = msg.get("method", "")
    mid = msg.get("id")
    is_notification = mid is None
    try:
        if method == "initialize":
            result = {
                "protocolVersion": msg.get("params", {}).get("protocolVersion",
                                                             PROTOCOL_VERSION),
                "capabilities": {"tools": {"listChanged": False}},
                "serverInfo": {"name": "secondbrain", "version": "1.0",
                               "title": "SecondBrain librarian"},
            }
        elif method == "notifications/initialized" or method.startswith("notifications/"):
            return None
        elif method == "ping":
            result = {}
        elif method == "tools/list":
            result = {"tools": tool_defs()}
        elif method == "tools/call":
            params = msg.get("params", {})
            name = params.get("name", "")
            args = params.get("arguments", {}) or {}
            fn = Dispatch.get(name)
            if fn is None:
                return _err(mid, -32602, f"Unknown tool: {name}")
            try:
                out = fn(args)
            except Exception as e:  # noqa: BLE001 - tool-level error
                return {"jsonrpc": "2.0", "id": mid, "result": {
                    "content": [{"type": "text", "text": json.dumps(
                        {"error": f"{type(e).__name__}: {e}"}, ensure_ascii=False)}],
                    "isError": True}}
            needs = isinstance(out, dict) and out.get("needs_approval")
            text = json.dumps(out, ensure_ascii=False, indent=1)
            result = {"content": [{"type": "text", "text": text}],
                      "isError": bool(needs)}
        elif method == "shutdown" or method == "exit":
            raise SystemExit(0)
        else:
            return _err(mid, -32601, f"Method not found: {method}")
        if is_notification:
            return None
        return {"jsonrpc": "2.0", "id": mid, "result": result}
    except SystemExit:
        raise
    except Exception as e:  # noqa: BLE001
        return _err(mid, -32603, f"{type(e).__name__}: {e}")


def _err(mid, code: int, message: str) -> dict:
    return {"jsonrpc": "2.0", "id": mid,
            "error": {"code": code, "message": message}}


def main():
    indexer.load_index()          # warm the index once at startup
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        try:
            msg = json.loads(line)
        except json.JSONDecodeError:
            sys.stdout.write(json.dumps(_err(None, -32700, "Parse error")) + "\n")
            sys.stdout.flush()
            continue
        try:
            reply = handle(msg)
        except SystemExit:
            break
        if reply is not None:
            sys.stdout.write(json.dumps(reply, ensure_ascii=False) + "\n")
            sys.stdout.flush()


if __name__ == "__main__":
    main()
