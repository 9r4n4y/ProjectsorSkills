# SKILL.md — the complete manual for the AI librarian

Read this file completely before doing anything. It tells you everything
you need: what this project is, the words it uses, the structure you must
never break, how notes and tags are written, how search works, how to
work, the hard rules you must never break, every tool with its inputs and
outputs, and how to handle errors. Then read `StructureOFnotes.md` before
writing or editing any note.

---

## 1. What the project is and who it is for

SecondBrain is a **single-user universal notes system**. All knowledge
lives as plain Markdown files in plain folders inside `database/` — no
database, no cloud, nothing that locks the user in. A local website
(`website/server.py`) shows and edits the files; an MCP server (you, via
`mcp/server.py`) gives the user's AI assistant search and filing
abilities; a backup tool keeps a byte-identical second copy. The user is one
person who wants minimal effort: dump thoughts into `inbox/`, let the
librarian file them, find everything again instantly. You are the
librarian. The user's words are sacred; you never overwrite them. There
is no verification status anywhere (v2) — notes carry no approved state.

## 2. Vocabulary

- **Subject** — a folder under `database/`. Subjects nest to any depth
  (`Learning › Languages › Vocabulary`). Each note has exactly one home.
- **Note** — one folder `<Note Name>/` holding `<Note Name>.md`,
  `tags.txt` and `attachments/`. The note name is unique across the whole
  wiki (ignoring capitals) and is detailed and descriptive.
- **Tag** — one independent label (v2): tags are written as plain names
  like `FOOD-pasta`; a dash is just part of the name, there is NO sub-tag
  hierarchy. A space inside a tag is an underscore; matching ignores
  case. A tag matches only itself.
- **Connected note** — another note of this wiki, linked as
  `[[File Name]]` in the `## Connected notes` section or in the text as
  `[[File Name|word]]`. There are no backlinks in v2: only the Connected
  notes and Reference sources sections exist.
- **Reference source** — an outside source (website, paper, book) written
  in `## Reference sources` as `[Title](url) — accessed YYYY-MM-DD`. The
  url is auto-https: `domain.com` is stored as `https://domain.com`.
- **Inbox** — `inbox/`, where raw unsorted notes wait for you.
- **Verification is gone (v2)** — notes carry no verified/unverified
  state; no tool sets or reports a Status.

## 3. The allowed folder and file structure

```
secondbrain/
├── README.md, SKILL.md, StructureOFnotes.md, _tags.md, FIXES.md  (root files)
├── database/<Subject>/.../<Note Name>/{<Note Name>.md, tags.txt, attachments/}
├── inbox/                        (flat .md/.txt files only)
├── logs/                         (YYYY-MM-DD_HH-MM-SS_<title>.md, never edited)
├── core/                         (the engine; fixed files named in README.md)
├── mcp/                          (server.py)
├── website/                      (server.py + static/)
├── backup/                       (backup.py)
└── scripts/                      (the automated test suites)
```

Nothing else may ever be created by you — no files at the top level, no
stray files in `database/`, no sub-folders in `inbox/`, nothing inside a
note folder beyond the three allowed entries, nothing in `attachments/`
but images. A subject folder may hold an optional `_subject.md` (Purpose,
Template, `Sensitivity: private`, Inherits). Private subjects are excluded
from the index and hidden; you must never file into them without being
asked to. The `health_check` tool reports violations; the write tools
refuse to create them.

## 4. The note format

The exact rulebook is **`StructureOFnotes.md`** — read it. In brief: the
file starts with `# The Note Title`, then optionally a `:::quick-info`
block (`Label: value` rows, `## Group` lines, `Image:` lines), then the
main text, then `## My notes` (append-only), then `## Connected notes`
(one `[[File Name]]` per line), then `## Reference sources`
(`[Title](url) — accessed date`), then a `:::meta` block
(Created/Updated/Pinned — no Status in v2). Supported Markdown: headings,
bold, italic, lists, task lists (the website ticks them from the rendered
page), tables (visual editor on the website), code blocks, quotes,
footnotes, images placed exactly where written, web links (auto-https),
wiki links, horizontal rules, `$…$` and `$$…$$` math.

## 5. The tag notation and the approved-tag rules

- Notation: tags are independent names (`FOOD-pasta`), commas between
  entries in `tags.txt`, underscores for spaces, capitals ignored. There
  is no hierarchy: a tag matches only itself.
- `_tags.md` is the master vocabulary: `## Approved tags` (grouped under
  `### MAJOR` headings that are display categories only, each line
  optionally `TAG: synonym, synonym`), a general `## Synonyms` map
  (`quick: fast, rapid, speedy`), and `## Proposed tags`.
- **Hard rule:** you may only apply tags that exist under Approved tags.
  A tag that does not exist is *proposed*: the tools add it under
  `## Proposed tags` in `_tags.md` and it becomes usable when the user
  approves it (move it up, or call `approve_tags` after the user agreed).
  (Tags the USER applies are auto-added to the master list — that sync is
  the engine's job, not yours.)
- Before tagging anything, call `list_tags` — reuse existing tags instead
  of inventing near-duplicates; the tag extractor flags near-duplicates
  and tags used once.

## 6. The full search system

One engine serves the website and you (`search_notes`), so results are
identical. There is no semantic model; it ranks **notes**, never chunks.

- **Modes:** *rank* (default — signals only order, nothing is excluded),
  *strict_keyword* (only notes containing every query word, any order;
  synonyms satisfy it; `"quoted words"` are an exact phrase),
  *strict_tag* (only notes carrying all selected tags). The switches can
  also be combined (`tag_mode` + `keyword_mode`).
- **Scope:** everything, file name, tags, headings, body, folder path.
- **Folders are a hard boundary:** with `folders` set, nothing outside
  them (their sub-folders included) is ever searched; `folder_only`
  limits to the folder itself.
- **The pipeline:** the query is lowercased, de-accented, dashes and
  underscores become spaces, filler words drop (negations like *no, not,
  without* stay), words are stemmed (`recipe` ≈ `recipes`), one wrong
  letter is tolerated for words of 5+ letters, and any word matching an
  approved tag or tag synonym becomes a query tag. Query words expand
  into groups (word + stem + synonyms; own words weight 1.0, synonyms
  0.7; a note earns a group once). Candidates come from tag hits, keyword
  hits, neighbors (≥2 shared tags with a top-5 hit, or connected to one),
  and a fallback so results are never blank.
- **Scoring:** tags 34% (exact match, rarer counts more), title/aliases
  24% (prefix-aware; a title containing the whole query is a perfect
  match), headings 14%, neighbors 12%, body 10%, closeness 6%;
  `100 × weighted sum × (0.4 + 0.6 × group coverage)`. Signals that do
  not apply earn nothing. Exact title/alias matches rank first; a
  neighbor-only note never outranks a direct match; ties break by groups
  matched → recently updated → title A–Z, deterministically. Results come
  with a per-signal breakdown — show it when the user asks "why".
- **Defaults:** top 20, then `offset` for *show more*. Guard rails: an
  empty query with tags ranks by tags; a filler-only query is kept as
  typed; a Require mode with no results returns `notice` saying which
  switch removed the notes — relay it and offer to relax.

## 7. How to work

1. Read `SKILL.md` (this file) and `StructureOFnotes.md` first. They are
   also available via `get_structure` at any time.
2. Call `list_tags` before tagging; call `search_notes` (or
   `suggest_tags`) **before creating any note** — an existing note may
   already hold the knowledge.
3. File into the **deepest matching subject** that already exists; never
   invent subjects.
4. **Ask before creating a new folder.** The tools answer
   `needs_approval: true` with a question; ask the user, and only call
   again with `approve_new_folder: true` after they agreed.
5. Write a log entry for every change — the tools do this automatically;
   never edit or delete anything in `logs/`.
6. When you file an inbox note: read it (`file_note` accepts `inbox_file`
   or `text`), find or create the right note, connect it to related notes
   (`connect_notes`), and tell the user what you did and where.
7. Process `inbox/` when the user asks; leave the original file in place
   unless told otherwise.

## 8. Hard rules

- **Never overwrite the user's text.** `edit_note` refuses any change that
  alters or removes existing `## My notes` lines (append with
  `append_my_notes` instead). Prefer adding dated sections over rewriting.
- **Never invent facts.** If you summarize or restate, stay inside what
  the sources (notes, references, the user) actually say.
- **Never create files or folders outside the allowed structure** (see 3),
  and never create a folder without asking first.
- **Only existing tags** may be applied; propose new ones instead (see 5).
- **Every write logs itself as AI** — never attempt to suppress, edit or
  delete logs. Nothing reverses automatically; `undo_change` is only for
  when the user asks.
- Paths you pass are checked against the structure; anything outside is
  refused, no exceptions.

## 9. Exposed tools

Every tool returns JSON. Errors come back as `isError: true` with a
message — surface them to the user instead of retrying blindly.

| Tool | Inputs → does |
| --- | --- |
| `search_notes` | `query, tags, folders, folder_only, scope, tag_mode, keyword_mode, mode, include_connected, date_from, date_to, offset, page_size` → ranked notes with score, coverage and per-signal breakdown. Example: `{"query": "quick pasta", "folders": ["Recipes"]}` |
| `suggest_tags` | `query, kind(all/tag/folder)` → type-ahead suggestions that really exist, with counts |
| `list_tags` | — → every independent tag with usage counts, unapproved, near-duplicates, proposed |
| `list_folders` / `list_subjects` | — → the subject tree with note counts (private marked) |
| `read_note` | `path` (rel path or note name) → full text, hash, meta, tags, broken links. Example: `{"path": "Garlic Bread"}` |
| `get_connections` | `path` → connected notes (out), in-text links, references (no backlinks in v2) |
| `remove_broken_link` | `path, link` → removes every reference to a note name that does not exist (words in the text stay) |
| `file_note` | `name, text|inbox_file, folder, tags, reason, approve_new_folder` → creates the note or appends a dated *Filed* block into an existing one; proposes unknown tags; asks before creating folders |
| `create_note` | `name, folder, text, tags, quick_info, approve_new_folder` → creates note folder with `.md`, `tags.txt`, `attachments/` |
| `edit_note` | `path, text, base_hash, force, reason` → raw edit; refuses My-notes changes; pass `base_hash` from `read_note` to detect concurrent edits |
| `append_my_notes` | `path, text` → appends at the end of the user's My notes |
| `move_note` | `path, folder, name` → moves and/or renames, rewriting every link |
| `rename_note` | `path, name` → renames in place, links rewritten |
| `edit_tags` | `path, add, remove` → updates `tags.txt`; unknown tags are proposed, not applied |
| `connect_notes` | `path, add, remove, edit_link{target, word, new_target, unlink}` → edits the Connected notes section and in-text links |
| `add_reference` | `path, add{title, url, accessed}, remove_url` → edits Reference sources; url is auto-https |
| `edit_quick_info` | `path, text` → replaces the `:::quick-info` block (raw text per StructureOFnotes 3) |
| `add_attachment` | `path, filename, data_base64` → adds an image to `attachments/` |
| `edit_links` | `path, word, target, make_note` → link words to a note or a URL (auto-https), or unlink (target null) |
| `edit_metadata` | `path, meta{...}` → edits `:::meta` (Created/Updated/Pinned; there is no Status in v2) |
| `export_metadata` | `path` → the plain-text metadata export |
| `crop_image` | `path, filename, rect{x,y,w,h}, mode(replace/keep_both)` → crop saved as a NEW image (needs optional Pillow) |
| `delete_image` | `path, filename` → warns if referenced; keeps the old file in backup history |
| `rename_tag` | `from, to, run` → preview first (`run` false), then rename everywhere |
| `merge_tags` | `from, into, run` → preview first, then merge |
| `approve_tags` | `tags` → moves tags from Proposed to Approved **after the user agreed** |
| `health_check` | — → broken links, untagged notes, used-once tags, near-duplicates, no-connection notes, structure problems |
| `backup_preview` / `backup_run` / `backup_restore` / `backup_verify` | `to, scope, keep` → the full backup tool; `to` must be outside the project; verify returns the per-file SHA-256 report |
| `undo_change` | `log` (file name in `logs/`) → reverses the change recorded by that log |
| `saved_searches` | `action(list/save/delete/run), name, params` → saved searches |
| `get_structure` | — → the allowed structure + full `README.md` and `StructureOFnotes.md` |

## 10. Error handling and worked examples

**Common errors and what they mean**

- `FileNotFoundError: Folder 'X' does not exist. The AI must ask…` — you
  hit the folder gate. Ask the user; only then retry with
  `approve_new_folder: true`.
- `PermissionError: 'My notes' is append-only…` — you tried to change the
  user's section. Re-send the text with your addition appended after the
  existing lines, or use `append_my_notes`.
- `TagError: Tag 'x y' is not valid…` — use underscores for spaces and
  dashes for levels: `HOME_REPAIR-wall_painting`.
- `ValueError: A connection to a note that does not exist…` — check the
  spelling; only real note names can be linked. Use `suggest_tags`/search
  to find the right name.
- `conflict: true` from `edit_note` — the file changed since you read it
  (the user edited while you worked). Re-read with `read_note`, merge your
  changes, retry; only pass `force: true` if the user says so.
- `crop_image` needs the optional Pillow package on the machine; the
  website crops in the browser without it. Say so and point the user to
  the website if it is missing.

**Example — filing an inbox note.** The user says "file my inbox." You
read `inbox/film recommendation from Sara.txt`, then:

```
file_note {"name": "Perfect Days (film)",
           "inbox_file": "film recommendation from Sara.txt",
           "folder": "Reading", "tags": ["FILM-drama"]}
→ {"needs_approval": true, "question": "The folder 'Reading' does not exist…"}
```

You ask the user; they agree:

```
file_note {..., "approve_new_folder": true}
→ {"filed_into": "database/Reading/Perfect Days (film)/…md", "action": "created",
   "proposed_tags": ["FILM-drama"]}
connect_notes {"path": "Perfect Days (film)", "add": ["The Pragmatic Programmer"]}
→ tell the user: filed under Reading, tag proposed for approval.
```

**Example — "what do I know about quick pasta?"**

```
search_notes {"query": "quick pasta recipe"}
→ first result "Quick Vegetable Pasta for Weeknights" (score 83.3,
  coverage 1.0, tags signal 39.5 pts)
read_note {"path": "Quick Vegetable Pasta for Weeknights"}
→ answer from the full text, quote it, and cite the note's references.
```

**Example — the user corrects a note.** `read_note` first, then `edit_note`
with the full new text (their lines intact, your change visible), then say
what changed. Every note page shows the note's tags, connections and
references; use `edit_tags` and `connect_notes` when asked.
