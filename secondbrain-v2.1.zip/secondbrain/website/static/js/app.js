/* SecondBrain v2.1 app shell (app.js): router, top bar with a global
 * search that works on EVERY page, a real Back button, desktop tab nav +
 * mobile bottom tab bar (Android friendly), keyboard shortcuts, and the
 * New Note dialog with live tag suggestions.
 * The graph page is gone: connected notes live on every note page. */
(function () {
  "use strict";
  const SB = window.SB;

  const routes = {
    "": () => SB.views.home(),
    home: () => SB.views.home(),
    search: (p) => SB.views.search(p),
    note: (p) => SB.views.note(decodeURIComponent(p || "")),
    tags: () => SB.views.tags(),
    files: (p) => SB.views.files(decodeURIComponent(p || "")),
    health: () => SB.views.health(),
    backup: () => SB.views.backup(),
    tools: () => SB.views.tools(),
  };

  const NAV = [
    ["home", "Home", "home"],
    ["files", "Folders", "folderopen"],
    ["tags", "Tags", "tag"],
    ["health", "Health", "health"],
    ["backup", "Backup", "backup"],
  ];

  async function route() {
    const h = location.hash.replace(/^#\/?/, "");
    const qm = h.indexOf("?");
    const path = qm >= 0 ? h.slice(0, qm) : h;
    const query = qm >= 0 ? h.slice(qm + 1) : "";
    const segs = path.split("/").filter(Boolean);
    const name = segs[0] || "";
    const param = segs.slice(1).join("/") + (query ? (segs.length > 1 ? "?" : "") + query : "");
    // unknown routes (e.g. the removed #/graph) land on home
    const fn = routes[name] || routes.home;
    SB.state.route = routes[name] ? name : "home";
    document.querySelectorAll(".mainnav a, .bottomnav a").forEach((a) => {
      a.classList.toggle("active", a.dataset.route === SB.state.route);
    });
    try {
      await fn(param);
    } catch (e) {
      document.getElementById("main").innerHTML =
        '<div class="notice warn"><b>Something went wrong:</b> ' + SB.esc(e.message) +
        '<div style="margin-top:8px"><button class="btn" onclick="history.back()">' +
        SB.icon("back") + " Go back</button></div></div>";
    }
    window.scrollTo(0, 0);
  }

  function topbar() {
    document.getElementById("topbar").innerHTML =
      '<div class="topbar-in">' +
      '<button class="backbtn" id="btn-back" title="Go back one step (Alt+Left)">' +
      SB.icon("back") + ' <span class="btn-label">Back</span></button>' +
      '<a class="brand" href="#/home"><span class="mark">SB</span><span class="brand-word">SecondBrain</span></a>' +
      '<div class="globalsearch">' +
      '<span class="gs-icon">' + SB.icon("search") + "</span>" +
      '<input id="global-q" placeholder="SEARCH EVERYWHERE…  (press /)" autocomplete="off">' +
      "</div>" +
      '<div class="topbar-actions">' +
      '<button class="btn accent" id="new-note" title="Create a new note">' + SB.icon("plus") + ' <span class="btn-label">New</span></button>' +
      '<button class="btn" id="theme-toggle" title="Light / dark"></button>' +
      "</div></div>" +
      '<nav class="mainnav">' +
      NAV.map((n) => '<a href="#/' + n[0] + '" data-route="' + n[0] + '">' +
        SB.icon(n[2]) + " " + n[1] + "</a>").join("") +
      "</nav>";

    document.getElementById("btn-back").onclick = () => {
      if (history.length > 1) history.back();
      else location.hash = "#/home";
    };
    document.getElementById("new-note").onclick = () => newNoteDialog("");

    const gq = document.getElementById("global-q");
    gq.addEventListener("keydown", (e) => {
      if (e.key === "Enter") {
        const q = gq.value.trim();
        location.hash = "#/search?q=" + encodeURIComponent(q);
        if (SB.state.route === "search") SB.views.search("q=" + encodeURIComponent(q));
      }
    });

    const tt = document.getElementById("theme-toggle");
    const paintToggle = () => {
      tt.innerHTML = SB.icon(SB.state.theme === "dark" ? "sun" : "moon") +
        ' <span class="btn-label">' + (SB.state.theme === "dark" ? "Light" : "Dark") + "</span>";
    };
    paintToggle();
    tt.onclick = () => {
      SB.setTheme(SB.state.theme === "dark" ? "light" : "dark");
      paintToggle();
    };
  }

  function bottomnav() {
    document.getElementById("bottomnav").innerHTML =
      NAV.map((n) => '<a href="#/' + n[0] + '" data-route="' + n[0] + '">' +
        SB.icon(n[2], 20) + "<span>" + n[1] + "</span></a>").join("");
  }

  function newNoteDialog(prefFolder) {
    SB.api.get("/api/folders").then((f) => {
      const opts = [{ p: "", n: "database (top level)", d: 0 }];
      const walk = (n, depth) => {
        if (n.path !== "") opts.push({ p: n.path, n: n.name, d: depth });
        (n.children || []).forEach((c) => walk(c, depth + 1));
      };
      walk(f.tree, 0);
      const pref = (prefFolder || "").replace(/^database\//, "");
      opts.forEach((o) => { if (o.p) o.p = o.p.replace(/^database\//, ""); });
      const w = SB.modal("Create a new note",
        "<p class='dim'>Creates the note folder with <b>&lt;Note Name&gt;.md</b>, " +
        "tags.txt and attachments/. Note names are unique across the wiki.</p>" +
        "<label>Note name</label><input id='nn-name' placeholder='e.g. Cold Brew Coffee Ratios'>" +
        "<label>Folder</label><select id='nn-folder'>" +
        opts.map((o) => "<option value='" + SB.esc(o.p) + "'" +
          (o.p === pref ? " selected" : "") + ">" +
          "\u00a0".repeat(o.d * 2) + SB.esc(o.n) + "</option>").join("") +
        "</select>" +
        "<label>Tags — type to see tags that already exist</label>" +
        "<div class='suggest-inline'><input id='nn-tags' placeholder='COOKING-drinks, METHOD-cold_brew'></div>" +
        "<div id='nn-chips' class='tagcloud' style='margin-top:8px'></div>", [
        { label: "Cancel" },
        { label: "Create and open", primary: true, onclick: async (w) => {
          const name = w.querySelector("#nn-name").value.trim();
          const folder = w.querySelector("#nn-folder").value;
          const tags = w.querySelector("#nn-tags").value.split(",").map((t) => t.trim()).filter(Boolean);
          if (!name) { SB.toast("Give the note a detailed name.", "err"); return false; }
          try {
            const out = await SB.api.post("/api/note/create", { folder, name, tags });
            if (out.proposed_tags && out.proposed_tags.length) {
              SB.toast("Created. New tags were added to _tags.md for you.");
            } else SB.toast("Created.");
            location.hash = "#/note/" + encodeURIComponent(name);
          } catch (e) { SB.toast(e.message, "err"); return false; }
        }},
      ]);
      const tagsInput = w.querySelector("#nn-tags");
      const chips = w.querySelector("#nn-chips");
      const paint = () => {
        chips.innerHTML = tagsInput.value.split(",").map((t) => t.trim()).filter(Boolean)
          .map((t) => SB.chip(t)).join("");
      };
      tagsInput.addEventListener("input", paint);
      SB.tagSuggest(tagsInput, (type, name) => {
        const cur = tagsInput.value.split(",").map((t) => t.trim()).filter(Boolean);
        if (!cur.includes(name)) cur.push(name);
        tagsInput.value = cur.join(", ");
        paint();
      }, { type: "tag", enterType: "tag" });
      paint();
      setTimeout(() => w.querySelector("#nn-name").focus(), 60);
    });
  }
  SB.newNoteDialog = newNoteDialog;

  /* keyboard shortcuts */
  document.addEventListener("keydown", (e) => {
    const inField = /input|textarea|select/i.test(document.activeElement.tagName);
    if ((e.altKey || e.metaKey) && e.key === "ArrowLeft") {
      e.preventDefault();
      history.back();
      return;
    }
    if (e.key === "/" && !inField) {
      e.preventDefault();
      const gq = document.getElementById("global-q");
      if (gq && window.matchMedia("(min-width: 860px)").matches) {
        gq.focus();
      } else {
        location.hash = "#/search";
        setTimeout(() => document.getElementById("s-q")?.focus(), 300);
      }
    }
    if ((e.key === "e" || e.key === "E") && !inField && SB.state.route === "note") {
      const btn = document.getElementById("btn-edit");
      if (btn) btn.click();
    }
    if (e.key === "Escape") SB.closeModal();
  });

  SB.setTheme(SB.state.theme);
  SB.setNoteSize(SB.state.noteSize);
  topbar();
  bottomnav();
  window.addEventListener("hashchange", route);
  route();
})();
