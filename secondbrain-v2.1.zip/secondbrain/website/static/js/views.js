/* SecondBrain v2.1 views (views.js): home, search (+ how-to guide), tags
 * (independent, editable), files (full folder browser), health (with
 * one-click fixes) + logs, backup (byte-identical + per-file SHA-256
 * verification), tools.
 * The connection-graph page is REMOVED: connected notes are shown on each
 * note page instead, used as references. The note view lives in note.js. */
(function () {
  "use strict";
  const SB = window.SB;
  const esc = SB.esc;
  SB.views = SB.views || {};

  /* ================= HOME ================= */

  SB.views.home = async function () {
    const st = await SB.api.get("/api/state");
    document.getElementById("main").innerHTML =
      '<div class="home">' +
      '<div class="hero">' +
      "<h1>SECOND<span class='acc'>BRAIN</span></h1>" +
      "<p>Your notes as plain Markdown — searchable, tagged, connected. Everything on a grid, nothing hidden.</p>" +
      '<div class="bigsearch"><input id="home-q" placeholder="SEARCH EVERYTHING…" autofocus>' +
      '<button class="btn accent big" id="home-go">' + SB.icon("search") + " SEARCH</button></div>" +
      '<div class="savedchips">' +
      st.saved_searches.map((s) =>
        '<a class="chip" href="#/search?' + new URLSearchParams(s.params).toString() + '">' +
        SB.icon("search", 12) + " " + esc(s.name) + "</a>").join("") +
      "</div></div>" +
      '<div class="statstrip">' +
      '<div class="stat accent"><b>' + st.notes + "</b><span>notes</span></div>" +
      '<div class="stat"><b>' + st.pinned.length + "</b><span>pinned</span></div>" +
      '<div class="stat"><b>' + st.saved_searches.length + "</b><span>saved searches</span></div>" +
      '<div class="stat"><b>' + st.recent.length + "</b><span>recent edits</span></div>" +
      "</div>" +
      '<div class="grid cols-2">' +
      '<div class="listcard panel"><h3>' + SB.icon("pin") + " Pinned</h3>" +
      '<ul class="notelist">' +
      (st.pinned.map(rowNote).join("") || '<li class="dim">Nothing pinned yet — use the pin button on a note.</li>') +
      "</ul></div>" +
      '<div class="listcard panel"><h3>' + SB.icon("eye") + " Recently updated</h3>" +
      '<ul class="notelist">' +
      st.recent.map(rowNote).join("") + "</ul></div></div>" +
      '<div class="grid cols-4" style="margin-top:var(--grid-gap)">' +
      linkCard("files", "Folderopen", "Folder browser", "Walk into any folder; create notes right there.") +
      linkCard("tags", "Tag", "Tag browser", "Independent tags with counts; edit, add, remove.") +
      linkCard("health", "Health", "Health & logs", "Issues with one-click fixes, undo, backup.") +
      linkCard("backup", "Backup", "Backup & restore", "Byte-identical copy, SHA-256 verified per file.") +
      "</div></div>";
    document.getElementById("home-go").onclick = go;
    document.getElementById("home-q").addEventListener("keydown", (e) => {
      if (e.key === "Enter") go();
    });
    function go() {
      const q = document.getElementById("home-q").value.trim();
      location.hash = "#/search?q=" + encodeURIComponent(q);
    }
    function rowNote(n) {
      return '<li><a href="#/note/' + encodeURIComponent(n.title) + '">' + esc(n.title) +
        "</a><span class='dim'>" + esc(n.folder || "") + "</span></li>";
    }
    function linkCard(route, ic, t, d) {
      return '<a class="qcard" href="#/' + route + '"><b>' + SB.icon(ic.toLowerCase()) + " " +
        esc(t) + "</b><span>" + esc(d) + "</span></a>";
    }
  };

  /* ================= SEARCH (structured + guide) ================= */

  const searchState = {
    q: "", mode: "rank", tags: [], folders: [], folder_only: false,
    scope: ["everything"], tag_mode: "rank", kw_mode: "rank",
    include_connected: false, status: "", date_from: "", date_to: "",
    limit_to: [], offset: 0, total: 0, results: [],
  };

  SB.views.search = async function (params) {
    const p = new URLSearchParams(params || "");
    searchState.q = p.get("q") || "";
    searchState.mode = p.get("mode") || "rank";
    searchState.tags = (p.get("tags") || "").split(",").filter(Boolean);
    searchState.folders = (p.get("folders") || "").split(",").filter(Boolean);
    if (p.get("tag_mode")) searchState.tag_mode = p.get("tag_mode");
    if (p.get("kw_mode")) searchState.kw_mode = p.get("kw_mode");
    if (p.get("scope")) searchState.scope = p.get("scope").split(",").filter(Boolean);
    if (p.get("folder_only")) searchState.folder_only = p.get("folder_only") === "1";
    if (p.get("include_connected")) searchState.include_connected = p.get("include_connected") === "1";
    searchState.limit_to = (p.get("limit_to") || "").split(",").filter(Boolean);
    renderSearch();
    await doSearch(0);
  };

  function searchHowTo() {
    SB.modal("How to use search",
      "<h3>Three steps</h3>" +
      "<p><b>1. Type words</b> — the engine ranks notes: tags count most, then " +
      "the title, headings, connected notes, body words and closeness. Synonyms " +
      "are included (fast ≈ quick), plurals match, and one wrong letter is " +
      "tolerated for words of five letters or more.</p>" +
      "<p><b>2. Pick a mode</b> (optional):</p>" +
      "<ul class='previewlist'>" +
      "<li><b>Ranking only</b> — default; nothing is excluded, signals only order.</li>" +
      "<li><b>Strict keyword</b> — only notes containing <i>every</i> query word. " +
      "Put words in quotes for an exact phrase.</li>" +
      "<li><b>Strict tag</b> — only notes carrying all selected tags.</li>" +
      "</ul>" +
      "<p><b>3. Narrow with filters</b> (all optional):</p>" +
      "<ul class='previewlist'>" +
      "<li><b>Tags & folders</b> — add chips below the search box; a folder is a " +
      "hard boundary (with 'this folder only' to exclude sub-folders).</li>" +
      "<li><b>Scope</b> — where words are looked: file name, tags, headings, body, folder path.</li>" +
      "<li><b>Dates</b> — filter by updated-from / to.</li>" +
      "<li><b>Include connected</b> — also list notes connected to your results.</li>" +
      "</ul>" +
      "<p class='dim'>Every result explains itself: open <i>Why this result</i> to " +
      "see the signals that earned its score. Results come 20 at a time.</p>",
      [{ label: "Got it", primary: true }]);
  }

  function renderSearch() {
    const s = searchState;
    document.getElementById("main").innerHTML =
      '<div class="searchpage">' +
      '<div class="pagehead"><div><h2>' + SB.icon("search") + " Search</h2>" +
      '<div class="sub">Type words — tags count most, then title, headings, connected notes and body.</div></div>' +
      '<div class="head-actions"><button class="btn" id="s-howto">' + SB.icon("help") + " How to</button></div></div>" +
      '<div class="searchbar"><input id="s-q" value="' + esc(s.q) + '" placeholder="SEARCH…">' +
      '<button class="btn accent" id="s-go">' + SB.icon("search") + " Search</button></div>" +

      '<div class="sectitle">MODE — how strict?</div>' +
      '<div class="card pad-sm"><div class="modebar">' +
      modeBtn("rank", "Ranking only") + modeBtn("strict_keyword", "Strict keyword") + modeBtn("strict_tag", "Strict tag") +
      '<label class="switch"><input type="checkbox" id="sw-conn" ' + (s.include_connected ? "checked" : "") +
      "> include notes connected to my results</label>" +
      "</div></div>" +

      '<div class="sectitle">NARROW BY — tags & folders</div>' +
      '<div class="card pad-sm"><div class="filterbar" id="filterbar"></div></div>' +

      '<div class="sectitle">ADVANCED — optional</div>' +
      '<div class="card pad-sm"><div class="filters2">' +
      '<div class="fgroup"><span>Look in</span>' +
      ["everything", "file name", "tags", "headings", "body", "folder path"].map((sc) =>
        '<label class="check"><input type="checkbox" data-scope="' + sc + '" ' +
        (s.scope.includes(sc) ? "checked" : "") + "> " + sc + "</label>").join("") + "</div>" +
      '<div class="fgroup"><span>Updated</span>' +
      '<input type="date" id="f-from" value="' + esc(s.date_from) + '" style="width:auto">' +
      '<span class="dim">to</span><input type="date" id="f-to" value="' + esc(s.date_to) + '" style="width:auto">' +
      "</div></div></div>" +

      '<div id="s-notice"></div>' +
      '<div class="sectitle">RESULTS</div>' +
      '<div id="s-results" class="results"></div>' +
      '<div class="morewrap"><button class="btn" id="s-more" style="display:none">Show 20 more</button> ' +
      '<button class="ghost" id="s-save">Save this search</button></div>' +
      "</div>";
    renderFilterBar();
    wireSearch();
    document.getElementById("s-howto").onclick = searchHowTo;
    setTimeout(() => { const q = document.getElementById("s-q"); if (q && !q.value) q.focus(); }, 50);
  }

  function modeBtn(m, label) {
    return '<button class="btn mode' + (searchState.mode === m ? " primary" : "") +
      '" data-mode="' + m + '">' + label + "</button>";
  }

  function renderFilterBar() {
    const s = searchState;
    const bar = document.getElementById("filterbar");
    bar.innerHTML =
      s.tags.map((t) => chipX("tag", t)).join("") +
      s.folders.map((f) => chipX("folder", f)).join("") +
      '<div class="suggest-inline" style="flex:1 1 300px">' +
      '<input id="filter-input" placeholder="Add a tag or folder filter…" autocomplete="off">' +
      "</div>" +
      (s.folders.length ? '<label class="check"><input type="checkbox" id="folder-only" ' +
        (s.folder_only ? "checked" : "") + "> this folder only (no sub-folders)</label>" : "");
    bar.querySelectorAll(".chipx").forEach((c) => {
      c.querySelector("button").onclick = () => {
        if (c.dataset.type === "tag") s.tags = s.tags.filter((t) => t !== c.dataset.name);
        else s.folders = s.folders.filter((t) => t !== c.dataset.name);
        renderFilterBar();
        doSearch(0);
      };
    });
    const folderOnly = document.getElementById("folder-only");
    if (folderOnly) folderOnly.onchange = () => {
      s.folder_only = folderOnly.checked;
      doSearch(0);
    };

    const inp = document.getElementById("filter-input");
    SB.tagSuggest(inp, (type, name) => {
      if (type === "tag") { if (!s.tags.includes(name)) s.tags.push(name); }
      else { if (!s.folders.includes(name)) s.folders.push(name); }
      renderFilterBar();
      doSearch(0);
    }, { type: "all", enterType: "tag" });
  }

  function chipX(type, name) {
    return '<span class="chip chipx" data-type="' + type + '" data-name="' + esc(name) + '">' +
      SB.icon(type === "tag" ? "tag" : "folder", 12) + " " + esc(name) +
      "<button aria-label='remove'>" + SB.icon("x", 11) + "</button></span>";
  }

  function wireSearch() {
    const s = searchState;
    document.getElementById("s-go").onclick = () => doSearch(0);
    document.getElementById("s-q").addEventListener("keydown", (e) => {
      if (e.key === "Enter") doSearch(0);
    });
    document.querySelectorAll(".mode").forEach((b) => {
      b.onclick = () => {
        s.mode = b.dataset.mode;
        renderSearch();
        doSearch(0);
      };
    });
    document.getElementById("sw-conn").onchange = (e) => {
      s.include_connected = e.target.checked;
      doSearch(0);
    };
    document.querySelectorAll("[data-scope]").forEach((cb) => {
      cb.onchange = () => {
        const v = cb.dataset.scope;
        if (cb.checked) {
          if (v === "everything") s.scope = ["everything"];
          else s.scope = s.scope.filter((x) => x !== "everything").concat(v);
        } else {
          s.scope = s.scope.filter((x) => x !== v);
          if (!s.scope.length) s.scope = ["everything"];
        }
        doSearch(0);
      };
    });
    document.getElementById("f-from").onchange = (e) => { s.date_from = e.target.value; doSearch(0); };
    document.getElementById("f-to").onchange = (e) => { s.date_to = e.target.value; doSearch(0); };
    document.getElementById("s-more").onclick = () => doSearch(s.offset + 20);
    document.getElementById("s-save").onclick = () => {
      SB.modal("Save this search", "<label>Name</label><input id='sv-name' placeholder='e.g. quick veggie dinners'>", [
        { label: "Cancel" },
        { label: "Save", primary: true, onclick: async (w) => {
          const name = w.querySelector("#sv-name").value.trim();
          if (!name) return false;
          await SB.api.post("/api/saved_searches/save", { name, params: currentParams() });
          SB.toast("Saved search pinned to the home page.");
        }},
      ]);
    };
  }

  function currentParams() {
    const s = searchState;
    const p = new URLSearchParams();
    p.set("q", s.q);
    p.set("mode", s.mode);
    if (s.tags.length) p.set("tags", s.tags.join(","));
    if (s.folders.length) p.set("folders", s.folders.join(","));
    if (s.folder_only) p.set("folder_only", "1");
    p.set("scope", s.scope.join(","));
    if (s.include_connected) p.set("include_connected", "1");
    if (s.limit_to && s.limit_to.length) p.set("limit_to", s.limit_to.join(","));
    if (s.date_from) p.set("date_from", s.date_from);
    if (s.date_to) p.set("date_to", s.date_to);
    return p;
  }

  async function doSearch(offset) {
    const s = searchState;
    s.offset = offset;
    const p = currentParams();
    p.set("offset", String(offset));
    const res = await SB.api.get("/api/search?" + p.toString());
    if (offset === 0) s.results = res.results;
    else s.results = s.results.concat(res.results);
    s.total = res.total;
    s.notice = res.notice;
    s.elapsed = res.elapsed_ms;
    s.queryTags = res.query.query_tags;
    s.groups = res.query.groups;
    renderResults(res);
  }

  function renderResults(res) {
    const s = searchState;
    const box = document.getElementById("s-results");
    if (!box) return;
    const within = (s.limit_to && s.limit_to.length)
      ? ' · within: ' + s.limit_to.map(esc).join(", ") +
        ' <button class="ghost tiny" id="limit-clear">clear</button>'
      : "";
    document.getElementById("s-notice").innerHTML = s.notice
      ? '<div class="notice warn">' + esc(s.notice) + "</div>" : "";
    document.getElementById("s-more").style.display =
      s.results.length < s.total ? "inline-flex" : "none";
    box.innerHTML =
      '<p class="dim mono" style="font-size:12px">' + s.total + " result(s) · " + s.elapsed + " ms" +
      (s.queryTags.length ? " · query tags: " + s.queryTags.map((t) => esc(t)).join(", ") : "") +
      within + "</p>" +
      (s.results.length ? s.results.map(resultCard).join("")
        : '<div class="notice">No results. Try fewer words, or switch the mode to “Ranking only”.</div>');
    const lc = document.getElementById("limit-clear");
    if (lc) lc.onclick = () => { s.limit_to = []; doSearch(0); };
  }

  function resultCard(r, i) {
    const why = r.score == null
      ? '<span class="badge conn">connected to ' + esc((r.connected_to || "").split("/").slice(-2)[0] || "") + "</span>"
      : '<span class="score' + (i === 0 ? " top" : "") + '">' + r.score + "</span>";
    return '<div class="result' + (r.direct === false ? " neighbor" : "") + '">' +
      '<div class="rhead"><a class="rtitle" href="#/note/' + encodeURIComponent(r.title) + '">' +
      esc(r.title) + "</a>" + why +
      "</div>" +
      '<div class="rmeta">' + SB.icon("folder", 12) + " " + esc(r.folder || "database") +
      ' <span class="dim">updated ' + esc(SB.fmtDate(r.updated)) + "</span>" +
      (r.neighbor_kind ? '<span class="badge">' + r.neighbor_kind + " only</span>" : "") +
      "</div>" +
      (r.tags && r.tags.length ? '<div class="rtags">' + r.tags.map((t) => SB.chip(t)).join("") + "</div>" : "") +
      '<p class="rsnippet">…' + esc(r.snippet || "") + "…</p>" +
      (r.score != null
        ? '<details class="why"><summary>Why this result</summary>' +
          '<div class="whybars">' + whyBars(r) +
          "<p class='dim mono' style='font-size:11px'>Score = signals × coverage " + r.coverage +
          " (matched " + r.matched_groups + " part(s) of the query).</p></div></details>"
        : "") +
      "</div>";
  }

  /* the why-panel shows only signals that actually earned points */
  function whyBars(r) {
    const names = { tags: "Tags", title: "Title match", headings: "Headings",
      neighbors: "Connected notes", body: "Body words", closeness: "Words close together" };
    const maxPts = Math.max(0.34, ...Object.values(r.breakdown || {}).map((v) => v.points), 0.05);
    const rows = Object.keys(r.breakdown)
      .filter((k) => r.breakdown[k].points > 0.001)
      .sort((a, b) => r.breakdown[b].points - r.breakdown[a].points)
      .map((k) => {
        const v = r.breakdown[k];
        return '<div class="whyrow"><span class="whyname">' + (names[k] || k) + "</span>" +
          '<div class="whybar"><div style="width:' +
          Math.min(100, v.points * 100 / maxPts) + '%"></div></div>' +
          '<span class="whyval">+' + (v.points * 100).toFixed(1) + "</span></div>";
      });
    return rows.length ? rows.join("") :
      '<p class="dim">This note appeared through the fallback (nothing matched directly), so its score is 0.</p>';
  }

  /* ================= TAGS (independent, editable) ================= */

  SB.views.tags = async function () {
    const data = await SB.api.get("/api/tags");
    const rows = data.rows || [];
    const byMajor = {};
    rows.forEach((r) => {
      (byMajor[r.major || "other"] = byMajor[r.major || "other"] || []).push(r);
    });
    const majors = Object.keys(byMajor).sort((a, b) => a.toLowerCase().localeCompare(b.toLowerCase()));

    document.getElementById("main").innerHTML =
      '<div class="tagspage">' +
      '<div class="pagehead"><div><h2>' + SB.icon("tag") + " Tags</h2>" +
      '<div class="sub">Every tag is independent — no sub-tags, no hierarchy, always in sync with the notes. ' +
      "Click a tag to search it; use the buttons to rename, merge or remove it everywhere.</div></div></div>" +
      '<div class="tagmanage">' +
      '<input id="tag-search" placeholder="FILTER TAGS…">' +
      '<button class="btn" id="tg-add">' + SB.icon("plus") + " Add tag</button>" +
      '<button class="btn" id="tg-rename">' + SB.icon("edit") + " Rename / merge</button>" +
      '<button class="btn danger" id="tg-remove">' + SB.icon("trash") + " Remove everywhere</button>" +
      "</div>" +
      majors.map((mj) =>
        '<div class="majorgroup">' + esc(mj) + '<span class="badge">' + byMajor[mj].length + "</span></div>" +
        '<div class="tagcloud">' + byMajor[mj].map((r) =>
          '<span class="tagpill" data-tag="' + esc(r.tag) + '">' +
          SB.chip(r.tag, "", !r.approved) +
          '<span class="badge">' + r.count + "</span>" +
          '<button class="ghost tiny tag-edit" data-tag="' + esc(r.tag) + '" title="Edit this tag">' +
          SB.icon("edit", 11) + "</button>" +
          "</span>").join("") + "</div>").join("") +
      (data.unapproved.length ? '<div class="notice warn"><b>Tags not yet in _tags.md</b> (marked with a dot): ' +
        data.unapproved.map(esc).join(", ") +
        ' — <button class="btn tiny" id="tg-approve">Add all to _tags.md</button></div>' : "") +
      (data.proposed.length ? '<div class="notice"><b>Proposed by the AI (awaiting approval):</b> ' +
        data.proposed.map(esc).join(", ") + "</div>" : "") +
      '<div id="tag-notes-box"></div>' +
      "</div>";

    const paint = (q) => {
      const ql = (q || "").toLowerCase();
      document.querySelectorAll(".tagpill").forEach((el) => {
        el.style.display = !ql || el.dataset.tag.toLowerCase().includes(ql) ? "" : "none";
      });
    };
    document.getElementById("tag-search").addEventListener("input", (e) => paint(e.target.value));

    document.getElementById("tg-add").onclick = () => masterEditor();
    document.getElementById("tg-rename").onclick = () => renameMerge();
    document.getElementById("tg-remove").onclick = () => removeTag();
    const ap = document.getElementById("tg-approve");
    if (ap) ap.onclick = async () => {
      await SB.api.post("/api/tags/master/add", { tags: data.unapproved, reason: "approved from the tag browser" });
      SB.toast("Added to _tags.md. Global index and notes are in sync.");
      SB.views.tags();
    };

    // per-tag editor: opens on the pencil
    document.querySelectorAll(".tag-edit").forEach((b) => (b.onclick = (e) => {
      e.preventDefault();
      tagEditor(b.dataset.tag, data);
    }));
  };

  function tagEditor(tag) {
    SB.api.post("/api/tags/rename", { from: tag, to: tag }).then((pv) => {
      const affected = pv.notes || [];
      SB.modal("Tag: " + tag,
        "<p class='dim'>Independent tag · used by " + affected.length + " note(s) in the wiki.</p>" +
        '<div class="btnrow">' +
        "<button class='btn' id='te-rename'>" + SB.icon("edit") + " Rename</button>" +
        "<button class='btn' id='te-merge'>" + SB.icon("graph") + " Merge into another tag</button>" +
        "<button class='btn danger' id='te-remove'>" + SB.icon("trash") + " Remove everywhere</button>" +
        "</div>" +
        "<h3>Notes with this tag</h3>" +
        "<ul class='previewlist' id='te-notes'><li class='dim'>loading…</li></ul>", [
        { label: "Close" },
      ]);
      if (affected.length) {
        document.querySelector("#te-notes").innerHTML = affected.map((n) => {
          const name = n.file.split("/").slice(-2)[0];
          return "<li><a href='#/note/" + encodeURIComponent(name) + "'>" + esc(name) + "</a> — " +
            "<span class='dim'>" + esc(n.old.join(", ")) + "</span></li>";
        }).join("");
      } else document.querySelector("#te-notes").innerHTML = "<li class='dim'>No notes carry this tag yet (it may exist only in _tags.md).</li>";
      document.getElementById("te-rename").onclick = () => { SB.closeModal(); renameMerge(tag); };
      document.getElementById("te-merge").onclick = () => { SB.closeModal(); renameMerge(tag, true); };
      document.getElementById("te-remove").onclick = async () => {
        SB.closeModal();
        SB.confirm("Remove the tag " + tag + " from every note and from _tags.md?", async () => {
          await SB.api.post("/api/tags/remove", { tag, run: true });
          SB.toast("Tag removed everywhere. Log recorded.");
          SB.views.tags();
        });
      };
    });
  }

  async function masterEditor() {
    const m = await SB.api.get("/api/master_tags");
    SB.modal("Edit _tags.md (master tag list)",
      "<p class='dim'>One tag per line under a ### category (categories are display only — tags are independent).</p>" +
      "<textarea id='master-text' rows='16'>" + esc(m.text) + "</textarea>", [
      { label: "Cancel" },
      { label: "Save master list", primary: true, onclick: async (w) => {
        await SB.api.post("/api/tags/master", { text: w.querySelector("#master-text").value });
        SB.toast("_tags.md saved; affected notes keep working, new tags are now pickable.");
        SB.views.tags();
      }},
    ]);
  }

  function renameMerge(from, merge) {
    SB.modal(merge ? "Merge a tag" : "Rename or merge a tag",
      "<p class='dim'>One action renames or merges a tag across all notes and _tags.md. " +
      "You will see a preview of every note that changes before anything is written.</p>" +
      "<label>From</label><input id='rt-from' value=\"" + esc(from || "") + "\" placeholder='FOOD-pasta'>" +
      "<label>" + (merge ? "Merge into" : "To") + "</label>" +
      "<input id='rt-to' placeholder='" + (merge ? "the tag that absorbs it" : "new name, or an existing tag to merge") + "'>", [
      { label: "Cancel" },
      { label: merge ? "Preview merge" : "Preview rename", primary: true, onclick: async (w) => {
        const f = w.querySelector("#rt-from").value.trim();
        const t = w.querySelector("#rt-to").value.trim();
        const res = merge
          ? await SB.api.post("/api/tags/merge", { from: f, into: t })
          : await SB.api.post("/api/tags/rename", { from: f, to: t });
        showTagPreview(f, t, res, merge);
        return false;
      }},
    ]);
    setTimeout(() => document.getElementById("rt-to").focus(), 60);
  }

  function showTagPreview(from, to, res, merge) {
    const rows = (res.notes || []).map((n) =>
      "<li><b>" + esc(n.file.split("/").slice(-2)[0]) + "</b><br>" + esc(n.old.join(", ")) +
      " &nbsp;→&nbsp; " + esc(n.new.join(", ")) + "</li>").join("");
    SB.modal("Preview: " + (merge ? "merge " : "rename ") + from + (merge ? " into " : " → ") + to,
      "<p>" + (res.notes || []).length + " note(s) will change.</p><ul class='previewlist'>" + rows +
      "</ul><p class='dim'>_tags.md is updated in the same change, so the global index stays in sync.</p>", [
      { label: "Cancel" },
      { label: "Apply to every note listed", primary: true, onclick: async () => {
        if (merge) await SB.api.post("/api/tags/merge", { from, into: to, run: true });
        else await SB.api.post("/api/tags/rename", { from, to, run: true });
        SB.toast("Done. Every change is logged and can be undone.");
        SB.views.tags();
      }},
    ]);
  }

  function removeTag() {
    SB.modal("Remove a tag everywhere",
      "<p class='dim'>Removes the tag from every tags.txt and from _tags.md. A preview is shown first.</p>" +
      "<label>Tag</label><input id='rm-tag' placeholder='FOOD-pasta'>", [
      { label: "Cancel" },
      { label: "Preview", primary: true, onclick: async (w) => {
        const t = w.querySelector("#rm-tag").value.trim();
        const res = await SB.api.post("/api/tags/remove", { tag: t });
        SB.closeModal();
        SB.confirm("Remove " + t + " from " + res.notes.length + " note(s)?", async () => {
          await SB.api.post("/api/tags/remove", { tag: t, run: true });
          SB.toast("Removed everywhere.");
          SB.views.tags();
        });
        return false;
      }},
    ]);
  }

  /* ================= FILES: full folder browser ================= */

  SB.views.files = async function (path) {
    // accept "#/files", "#/files/Recipes", "#/files/database/Recipes"
    path = decodeURIComponent((path || "").replace(/^(folder\/|database\/)+/, ""));
    let data;
    try {
      data = await SB.api.get("/api/folder/browse?path=" + encodeURIComponent(path));
    } catch (e) {
      document.getElementById("main").innerHTML =
        '<div class="notice warn">That folder does not exist: ' + esc(e.message) +
        ' <a href="#/files">Back to database root</a></div>';
      return;
    }
    const crumbs = ['<a href="#/files">' + SB.icon("folderopen") + " database</a>"];
    if (path) {
      let acc = "";
      const bits = path.split("/").filter(Boolean);
      bits.forEach((bit, bi) => {
        acc += (acc ? "/" : "") + bit;
        if (bi < bits.length - 1) {
          crumbs.push('<span class="sep">›</span><a href="#/files/' + encodeURIComponent(acc) + '">' + esc(bit) + "</a>");
        }
      });
      crumbs.push('<span class="sep">›</span><span class="here">' + esc(data.name) + "</span>");
    }
    document.getElementById("main").innerHTML =
      '<div class="browserpage">' +
      '<div class="pagehead"><div><h2>' + SB.icon("folderopen") + " Folders</h2>" +
      (data.subject_md ? '<div class="sub">' + esc(data.subject_md.split("\n")[0]) + "</div>" : "") +
      "</div>" +
      '<div class="head-actions">' +
      '<button class="btn accent" id="f-newnote">' + SB.icon("plus") + " New note here</button>" +
      '<button class="btn" id="f-newfolder">' + SB.icon("plus") + " New subfolder</button>" +
      (path ? '<button class="btn" id="f-edit-subject">' + SB.icon("edit") + " _subject.md</button>" : "") +
      "</div></div>" +
      "<div class='browser-crumbs'>" + crumbs.join("") + "</div>" +
      "<div class='fgrid'>" +
      data.subfolders.map((f) =>
        '<div class="fcard" data-nav="' + esc(f.path) + '">' +
        '<div class="fc-actions">' +
        '<button class="ghost tiny f-rename" data-p="' + esc(f.path) + '" data-n="' + esc(f.name) + '" title="Rename folder">' + SB.icon("edit", 12) + "</button>" +
        '<button class="ghost tiny f-delete" data-p="' + esc(f.path) + '" data-n="' + esc(f.name) + '" title="Delete folder (must be empty)">' + SB.icon("trash", 12) + "</button></div>" +
        '<div class="fc-name">' + SB.icon("folder") + " " + esc(f.name) + "</div>" +
        '<div class="fc-meta"><span>folder</span></div></div>').join("") +
      data.notes.map((n) =>
        '<div class="fcard ncard" data-note="' + esc(n.name) + '">' +
        '<div class="fc-actions">' +
        '<button class="ghost tiny n-rename" data-p="' + esc(n.path) + '" data-n="' + esc(n.name) + '" title="Rename note">' + SB.icon("edit", 12) + "</button>" +
        '<button class="ghost tiny n-move" data-p="' + esc(n.path) + '" data-n="' + esc(n.name) + '" title="Move note">' + SB.icon("folder", 12) + "</button>" +
        '<button class="ghost tiny n-delete" data-p="' + esc(n.path) + '" data-n="' + esc(n.name) + '" title="Delete note">' + SB.icon("trash", 12) + "</button></div>" +
        '<div class="fc-name">' + SB.icon("note") + " <a href='#/note/" + encodeURIComponent(n.name) + "'>" + esc(n.name) + "</a>" +
        (n.pinned ? " " + SB.icon("pinfilled", 12) : "") + "</div>" +
        '<div class="fc-meta"><span>updated ' + esc(SB.fmtDate(n.updated)) + "</span>" +
        (n.attachments.length ? "<span>" + SB.icon("img", 11) + " " + n.attachments.length + "</span>" : "") +
        "</div>" +
        (n.tags && n.tags.length ? '<div class="fc-tags">' + n.tags.map((t) => SB.chip(t)).join("") + "</div>" : "") +
        "</div>").join("") +
      (!data.subfolders.length && !data.notes.length
        ? '<p class="dim">Empty folder — create a note or a subfolder above.</p>' : "") +
      "</div></div>";

    document.querySelectorAll(".fcard[data-nav]").forEach((el) => {
      el.onclick = (e) => {
        if (e.target.closest("button")) return;
        location.hash = "#/files/" + encodeURIComponent(el.dataset.nav);
      };
    });
    document.querySelectorAll(".fcard[data-note]").forEach((el) => {
      el.onclick = (e) => {
        if (e.target.closest("button") || e.target.closest("a")) return;
        location.hash = "#/note/" + encodeURIComponent(el.dataset.note);
      };
    });
    document.getElementById("f-newnote").onclick = () => SB.newNoteDialog(path);
    document.getElementById("f-newfolder").onclick = () => folderDialog(path);
    const subj = document.getElementById("f-edit-subject");
    if (subj) subj.onclick = () => subjectEditor(path, data.subject_md);

    document.querySelectorAll(".f-rename").forEach((b) => (b.onclick = () => {
      SB.modal("Rename folder", "<label>New name</label><input id='fr-name' value=\"" + esc(b.dataset.n) + "\">", [
        { label: "Cancel" },
        { label: "Rename", primary: true, onclick: async (w) => {
          try {
            await SB.api.post("/api/folder/rename", { path: b.dataset.p, name: w.querySelector("#fr-name").value });
            SB.toast("Renamed.");
            SB.views.files(path);
          } catch (e) { SB.toast(e.message, "err"); return false; }
        }},
      ]);
    }));
    document.querySelectorAll(".f-delete").forEach((b) => (b.onclick = () => {
      SB.confirm("Delete folder " + b.dataset.n + "? Only empty folders can be deleted.", async () => {
        try {
          await SB.api.post("/api/folder/delete", { path: b.dataset.p });
          SB.toast("Deleted (it was empty).");
          SB.views.files(path);
        } catch (e) { SB.toast(e.message, "err"); }
      });
    }));
    document.querySelectorAll(".n-rename").forEach((b) => (b.onclick = () => {
      SB.modal("Rename note", "<label>New name (links everywhere are rewritten)</label><input id='nr-name' value=\"" + esc(b.dataset.n) + "\">", [
        { label: "Cancel" },
        { label: "Rename", primary: true, onclick: async (w) => {
          try {
            await SB.api.post("/api/note/move", { path: b.dataset.p, name: w.querySelector("#nr-name").value });
            SB.toast("Renamed; every link rewritten.");
            SB.views.files(path);
          } catch (e) { SB.toast(e.message, "err"); return false; }
        }},
      ]);
    }));
    document.querySelectorAll(".n-move").forEach((b) => (b.onclick = () => {
      SB.modal("Move note", "<label>Target folder (empty = database root)</label>" +
        "<input id='nm-folder' value=\"" + esc(path) + "\" placeholder='e.g. Recipes/Desserts'>", [
        { label: "Cancel" },
        { label: "Move", primary: true, onclick: async (w) => {
          try {
            await SB.api.post("/api/note/move", { path: b.dataset.p, folder: w.querySelector("#nm-folder").value });
            SB.toast("Moved.");
            SB.views.files(path);
          } catch (e) { SB.toast(e.message, "err"); return false; }
        }},
      ]);
    }));
    document.querySelectorAll(".n-delete").forEach((b) => (b.onclick = () => {
      SB.confirm("Delete the note " + b.dataset.n + " with its tags and attachments? " +
        "The log keeps everything, so Undo restores it.", async () => {
        try {
          await SB.api.post("/api/note/delete", { path: b.dataset.p });
          SB.toast("Note deleted (undoable from Health → Logs).");
          SB.views.files(path);
        } catch (e) { SB.toast(e.message, "err"); }
      });
    }));

    function folderDialog(parent) {
      SB.modal("Create a subfolder",
        "<p class='dim'>Subjects nest to any depth. An optional _subject.md describes its purpose.</p>" +
        "<label>Name</label><input id='nf-name' placeholder='e.g. Home Repair'>" +
        "<label>Optional _subject.md content</label><textarea id='nf-subject' rows='4' " +
        "placeholder='Purpose: ...'></textarea>", [
        { label: "Cancel" },
        { label: "Create", primary: true, onclick: async (w) => {
          try {
            await SB.api.post("/api/folder/create", {
              parent, name: w.querySelector("#nf-name").value,
              subject_md: w.querySelector("#nf-subject").value || null,
            });
            SB.toast("Folder created.");
            SB.views.files(path);
          } catch (e) { SB.toast(e.message, "err"); return false; }
        }},
      ]);
    }

    function subjectEditor(p, currentText) {
      SB.modal("_subject.md for " + (p || "database"),
        "<p class='dim'>Optional fields: Purpose, Template, Inherits.</p>" +
        "<textarea id='subj-text' rows='7'>" + esc(currentText || "") + "</textarea>", [
        { label: "Cancel" },
        { label: "Save", primary: true, onclick: async (w) => {
          try {
            await SB.api.post("/api/subject/save", { path: p, text: w.querySelector("#subj-text").value });
            SB.toast("_subject.md saved.");
            SB.views.files(p);
          } catch (e) { SB.toast(e.message, "err"); return false; }
        }},
      ]);
    }
  };

  /* ================= TOOLS (folder table, kept simple) ================= */

  SB.views.tools = async function () {
    const f = await SB.api.get("/api/folders");
    const rows = [];
    const walk = (n, depth) => {
      if (n.path !== "") {
        rows.push("<tr><td><span class='indent" + Math.min(depth, 4) + "'></span>" +
          SB.icon("folder") + " " + esc(n.name) +
          "</td><td class='dim mono'>" + esc(n.path) + "</td><td>" +
          "<a class='btn tiny' href='#/files/" + encodeURIComponent(n.path) + "'>open</a> " +
          "<button class='ghost tiny f-rename' data-p='" + esc(n.path) + "'>rename</button> " +
          "<button class='ghost tiny f-move' data-p='" + esc(n.path) + "'>move</button> " +
          "<button class='ghost tiny f-delete' data-p='" + esc(n.path) + "'>delete</button></td></tr>");
      }
      (n.children || []).forEach((c) => walk(c, depth + 1));
    };
    walk(f.tree, 0);
    document.getElementById("main").innerHTML =
      '<div class="toolspage">' +
      '<div class="pagehead"><div><h2>' + SB.icon("gear") + " Notes & folders</h2>" +
      '<div class="sub">A folder is a subject; subjects nest to any depth. The Folders page gives you the full browser with per-folder actions.</div></div>' +
      '<div class="head-actions"><button class="btn accent" id="t-newnote">' + SB.icon("plus") +
      " New note</button><button class='btn' id='t-newfolder'>" + SB.icon("plus") +
      " New folder</button></div></div>" +
      '<div class="tablewrap"><table class="logtable"><thead><tr><th>Folder</th><th>Path</th><th>Actions</th></tr></thead>' +
      "<tbody>" + rows.join("") + "</tbody></table></div></div>";
    document.getElementById("t-newnote").onclick = () => SB.newNoteDialog("");
    document.getElementById("t-newfolder").onclick = () => folderDialog("");
    document.querySelectorAll(".f-rename").forEach((b) => (b.onclick = () => {
      SB.modal("Rename folder", "<label>New name</label><input id='fr-name'>", [
        { label: "Cancel" },
        { label: "Rename", primary: true, onclick: async (w) => {
          try {
            await SB.api.post("/api/folder/rename", { path: b.dataset.p, name: w.querySelector("#fr-name").value });
            SB.toast("Renamed. Wiki links use file names, so nothing else needed rewriting.");
            SB.views.tools();
          } catch (e) { SB.toast(e.message, "err"); return false; }
        }},
      ]);
    }));
    document.querySelectorAll(".f-move").forEach((b) => (b.onclick = () => {
      SB.modal("Move folder", "<label>New parent (empty = database root)</label>" +
        "<input id='fm-parent' placeholder='database/Recipes … or leave empty'>", [
        { label: "Cancel" },
        { label: "Move", primary: true, onclick: async (w) => {
          try {
            await SB.api.post("/api/folder/move", { path: b.dataset.p, parent: w.querySelector("#fm-parent").value });
            SB.toast("Moved.");
            SB.views.tools();
          } catch (e) { SB.toast(e.message, "err"); return false; }
        }},
      ]);
    }));
    document.querySelectorAll(".f-delete").forEach((b) => (b.onclick = () => {
      SB.confirm("Delete this folder? Only empty folders can be deleted.", async () => {
        try {
          await SB.api.post("/api/folder/delete", { path: b.dataset.p });
          SB.toast("Deleted (it was empty).");
          SB.views.tools();
        } catch (e) { SB.toast(e.message, "err"); }
      });
    }));

    function folderDialog(parent) {
      SB.modal("Create a folder (a new subject)",
        "<p class='dim'>Folder trees can be any depth. An optional _subject.md describes its purpose.</p>" +
        "<label>Parent</label><input id='nf-parent' value='" + esc(parent) + "' placeholder='empty = database root'>" +
        "<label>Name</label><input id='nf-name' placeholder='e.g. Home Repair'>" +
        "<label>Optional _subject.md content</label><textarea id='nf-subject' rows='4' " +
        "placeholder='Purpose: ...'></textarea>", [
        { label: "Cancel" },
        { label: "Create", primary: true, onclick: async (w) => {
          try {
            await SB.api.post("/api/folder/create", {
              parent: w.querySelector("#nf-parent").value.trim(),
              name: w.querySelector("#nf-name").value,
              subject_md: w.querySelector("#nf-subject").value || null,
            });
            SB.toast("Folder created.");
            SB.views.tools();
          } catch (e) { SB.toast(e.message, "err"); return false; }
        }},
      ]);
    }
  };

  /* ================= HEALTH (with one-click fixes) ================= */

  SB.views.health = async function () {
    const h = await SB.api.get("/api/health");
    const logs = (await SB.api.get("/api/logs?limit=30")).logs;
    const sum = h.summary;

    const card = (icon, title, items, fmt, fixNote) =>
      '<div class="hcard"><h3>' + SB.icon(icon, 14) + " " + title +
      ' <span class="badge">' + items.length + "</span></h3>" +
      (items.length ? "<ul class='healthlist'>" + items.map(fmt).join("") + "</ul>"
        : "<p class='dim'>Nothing to fix.</p>") +
      (fixNote ? "<p class='dim'>" + fixNote + "</p>" : "") + "</div>";

    const noteLink = (p) =>
      "<a href='#/note/" + encodeURIComponent(p.split("/").slice(-2)[0]) + "'>" +
      esc(p.split("/").slice(-2)[0]) + "</a>";

    document.getElementById("main").innerHTML =
      '<div class="healthpage">' +
      '<div class="pagehead"><div><h2>' + SB.icon("health") + " Health check</h2>" +
      '<div class="sub">Every issue costs a few points. Fix items below; each fix is logged and undoable.</div></div></div>' +
      '<div class="scorebig"><div class="dial" style="--pct:' + sum.score + '"><span>' + sum.score + "</span></div>" +
      "<div><b style='font-size:18px'>Health score / 100</b>" +
      "<p class='dim'>" + sum.notes + " notes · " + sum.broken_links + " broken links · " +
      sum.notes_without_tags + " untagged · " + sum.notes_without_connections + " unconnected</p></div></div>" +
      '<div class="hgrid">' +
      card("link", "Broken links", h.broken_links, (b) =>
        "<li>" + noteLink(b.note) + " → missing <b>" + esc(b.link) + "</b> " +
        "<button class='btn tiny fix-broken' data-n='" + esc(b.note) + "' data-l='" + esc(b.link) + "'>remove link</button></li>") +
      card("tag", "Notes with no tags", h.notes_without_tags, (p) =>
        "<li>" + noteLink(p.path) + " <a class='btn tiny' href='#/note/" +
        encodeURIComponent(p.path.split("/").slice(-2)[0]) + "'>open & tag</a></li>") +
      card("graph", "Notes with no connections", h.notes_without_connections, (p) =>
        "<li>" + noteLink(p.path) + "</li>") +
      card("tag", "Tags used once", h.tags_used_once, (t) => "<li>" + esc(t) + "</li>") +
      card("copy", "Near-duplicate tags", h.near_duplicate_tags, (n) =>
        "<li>" + n.tags.map(esc).join(" ↔ ") +
        " <button class='btn tiny fix-dup' data-a='" + esc(n.tags[0]) + "' data-b='" + esc(n.tags[1] || "") + "'>merge</button></li>") +
      card("tag", "Unapproved tags", h.unapproved_tags, (t) =>
        "<li>" + esc(t) + " <button class='btn tiny fix-approve' data-t='" + esc(t) + "'>add to _tags.md</button></li>") +
      card("img", "Unreferenced attachments", h.unreferenced_attachments, (a) =>
        "<li>" + noteLink(a.note) + " — <b>" + esc(a.file) + "</b> " +
        "<button class='btn tiny fix-att' data-n='" + esc(a.note) + "' data-f='" + esc(a.file) + "'>delete file</button></li>") +
      card("folder", "Files outside the allowed structure", h.structure_problems, (p) =>
        "<li><b>" + esc(p.path) + "</b> — " + esc(p.problem) +
        ((p.problem.startsWith("File not allowed") || p.problem.startsWith("Unexpected file") || p.problem.startsWith("Only .md")) ?
          " <button class='btn tiny fix-file' data-p='" + esc(p.path) + "'>delete file</button>" : "") +
        "</li>") +
      card("note", "Notes missing dates", h.notes_without_dates, (p) =>
        "<li>" + noteLink(p.path) + "</li>") +
      "</div>" +
      '<div class="pagehead"><div><h2>' + SB.icon("undo") + " Logs</h2>" +
      '<div class="sub">One new log file after every edit, written by User or AI only — never edited or deleted. Undo is always your own click.</div></div></div>' +
      '<div class="tablewrap"><table class="logtable"><thead><tr><th>When</th><th>Who</th><th>Title</th><th>Actions</th></tr></thead><tbody>' +
      logs.map((l) => "<tr><td class='mono'>" + esc(l.date) + "</td><td>" + esc(l.who) + "</td><td>" +
        esc(l.title) + "</td><td>" +
        "<button class='ghost tiny log-view' data-f='" + esc(l.file) + "'>view</button> " +
        (l.undoable ? "<button class='ghost tiny log-undo' data-f='" + esc(l.file) + "'>undo</button>" : "") +
        "</td></tr>").join("") + "</tbody></table></div></div>";

    const rerun = () => SB.views.health();
    document.querySelectorAll(".fix-broken").forEach((b) => (b.onclick = async () => {
      try {
        await SB.api.post("/api/fix/broken_link", { path: b.dataset.n, link: b.dataset.l });
        SB.toast("Broken link removed (the words stay). Undo from Logs.");
        rerun();
      } catch (e) { SB.toast(e.message, "err"); }
    }));
    document.querySelectorAll(".fix-dup").forEach((b) => (b.onclick = () => {
      SB.confirm("Merge " + b.dataset.a + " into " + b.dataset.b + "?", async () => {
        try {
          await SB.api.post("/api/tags/merge", { from: b.dataset.a, into: b.dataset.b, run: true });
          SB.toast("Merged.");
          rerun();
        } catch (e) { SB.toast(e.message, "err"); }
      });
    }));
    document.querySelectorAll(".fix-approve").forEach((b) => (b.onclick = async () => {
      try {
        await SB.api.post("/api/tags/master/add", { tags: [b.dataset.t], reason: "approved from health page" });
        SB.toast("Added to _tags.md.");
        rerun();
      } catch (e) { SB.toast(e.message, "err"); }
    }));
    document.querySelectorAll(".fix-att").forEach((b) => (b.onclick = () => {
      SB.confirm("Delete the image file " + b.dataset.f + "? It is kept in backup history.", async () => {
        try {
          await SB.api.post("/api/image/delete", { path: b.dataset.n, filename: b.dataset.f });
          SB.toast("Image deleted.");
          rerun();
        } catch (e) { SB.toast(e.message, "err"); }
      });
    }));
    document.querySelectorAll(".fix-file").forEach((b) => (b.onclick = () => {
      SB.confirm("Delete this stray file? Its content is kept in the log for undo.", async () => {
        try {
          await SB.api.post("/api/fix/delete_file", { path: b.dataset.p });
          SB.toast("File deleted.");
          rerun();
        } catch (e) { SB.toast(e.message, "err"); }
      });
    }));

    document.querySelectorAll(".log-view").forEach((b) => {
      b.onclick = async () => {
        const t = await SB.api.get("/api/log?name=" + encodeURIComponent(b.dataset.f));
        SB.modal(b.dataset.f, "<pre class='logpre'>" + esc(t.text) + "</pre>", [{ label: "Close" }]);
      };
    });
    document.querySelectorAll(".log-undo").forEach((b) => {
      b.onclick = () => {
        SB.confirm("Undo the change recorded in this log?", async () => {
          try {
            await SB.api.post("/api/undo", { log: b.dataset.f });
            SB.toast("Change undone (a new log entry records your undo).");
            rerun();
          } catch (e) { SB.toast(e.message, "err"); }
        });
      };
    });
  };

  /* ================= BACKUP (identical copy + per-file hashes) ========== */

  SB.views.backup = async function () {
    document.getElementById("main").innerHTML =
      '<div class="backuppage">' +
      '<div class="pagehead"><div><h2>' + SB.icon("backup") + " Backup & restore</h2>" +
      '<div class="sub">Point it at any folder <b>outside the project</b> (an old backup works — the run edits that folder until it is byte-for-byte identical to the project, verified by a SHA-256 hash for every single file). The live project is never modified during a backup. Replaced files are kept in a dated .versions/ folder.</div></div></div>' +
      '<div class="card bform">' +
      '<label class="wide">' + SB.icon("folder", 13) + " Backup folder (absolute path)</label>" +
      '<input class="wide mono" id="b-dir" placeholder="/path/to/backup" value="' +
      esc(localStorage.getItem("sb-backup-dir") || "") + '">' +
      "<label>Scope</label><select id='b-scope'>" +
      ["whole", "database", "inbox", "logs"].map((x) => "<option>" + x + "</option>").join("") +
      "</select>" +
      "<label>Direction</label><select id='b-dirn'>" +
      "<option value='backup'>backup: update the backup from the project</option>" +
      "<option value='restore'>restore: rebuild the project from the backup</option></select>" +
      "</div>" +
      '<div class="btnrow" style="margin-top:var(--grid-gap)">' +
      '<button class="btn" id="b-preview">Preview changes</button>' +
      '<button class="btn accent" id="b-run">Make identical & verify</button>' +
      '<button class="btn" id="b-verify">Verify hashes only</button></div>' +
      '<div id="b-out" style="margin-top:var(--grid-gap)"></div></div>';
    const out = document.getElementById("b-out");
    const getArgs = () => {
      const a = {
        to: document.getElementById("b-dir").value.trim(),
        scope: document.getElementById("b-scope").value,
        direction: document.getElementById("b-dirn").value,
      };
      localStorage.setItem("sb-backup-dir", a.to);
      return a;
    };
    document.getElementById("b-preview").onclick = async () => {
      try {
        const a = getArgs();
        if (!a.to) return SB.toast("Choose the backup folder first.", "err");
        const r = await SB.api.post("/api/backup/preview", a);
        out.innerHTML = "<h3 class='sectitle' style='margin-top:0'>Preview</h3><pre class='logpre'>" + esc(r.preview) + "</pre>";
      } catch (e) { out.innerHTML = ""; SB.toast(e.message, "err"); }
    };
    document.getElementById("b-run").onclick = () => {
      const a = getArgs();
      if (!a.to) return SB.toast("Choose the backup folder first.", "err");
      SB.confirm("Run the " + a.direction + " now? The target folder is edited until it matches " +
        "the source byte for byte; every written file is re-hashed.", async () => {
        try {
          const r = await SB.api.post("/api/backup/run", a);
          out.innerHTML = "<h3 class='sectitle' style='margin-top:0'>Result</h3>" + backupReport(r);
        } catch (e) { SB.toast(e.message, "err"); }
      });
    };
    document.getElementById("b-verify").onclick = async () => {
      try {
        const a = getArgs();
        if (!a.to) return SB.toast("Choose the backup folder first.", "err");
        const r = await SB.api.post("/api/backup/verify", a);
        out.innerHTML = "<h3 class='sectitle' style='margin-top:0'>Verification — SHA-256 of every file</h3>" + verifyReport(r);
      } catch (e) { SB.toast(e.message, "err"); }
    };
  };

  function backupReport(r) {
    if (r.cancelled) return "<p class='dim'>Cancelled.</p>";
    return "<pre class='logpre'>" + esc(JSON.stringify({
      ok: r.ok, compared: r.compared, unchanged: r.unchanged, changed: r.changed,
      new: r.new, removed: r.removed, moved: r.moved,
      hash_mismatches: r.hash_mismatches,
    }, null, 1)) + "</pre>" +
      (r.ok ? "<p class='ok'>Every hash verified — the copy is identical.</p>"
            : "<p class='err'>Hash mismatch — see above.</p>");
  }

  function verifyReport(r) {
    const rows = (r.files || []).map((f) =>
      "<tr><td>" + (f.status === "identical" ? "<span class='pill-ok'>✓ identical</span>" :
        "<span class='pill-bad'>✗ " + esc(f.status) + "</span>") + "</td>" +
      "<td>" + esc(f.path) + "</td><td class='mono'>" + esc((f.project_sha256 || "").slice(0, 16)) + "…</td></tr>").join("");
    return "<p class='" + (r.ok ? "ok" : "err") + "'>" +
      (r.ok ? "Backup verified: " : "Not in sync: ") +
      (r.compared || 0) + " file(s) compared, " +
      ((r.mismatched || []).length + (r.missing || []).length + (r.extra || []).length) +
      " problem(s).</p>" +
      "<div style='max-height:340px;overflow:auto'><table class='verifytable'><thead>" +
      "<tr><th>Status</th><th>File</th><th>SHA-256 (project)</th></tr></thead><tbody>" +
      rows + "</tbody></table></div>";
  }
})();
