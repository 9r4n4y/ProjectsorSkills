/* SecondBrain v2.1 note view + edit (note.js)
 *
 * View: breadcrumb row, title + action grid, quick info card, rendered
 * body with ONE-CLICK checklist ticking, then — in order — Connected
 * notes (THE reference list: every note linked from this one, add/remove
 * by searching NOTES ONLY — never tags or folders), Reference sources,
 * Tags, Metadata.
 *
 * Edit: raw Markdown editor with a smart toolbar (nothing stays selected
 * after an insert; the cursor lands in the best spot; select a word and
 * tap a button; Link-note searches notes only; auto-https web links;
 * visual table editor; Find works in edit AND preview mode).
 */
(function () {
  "use strict";
  const SB = window.SB;
  const esc = SB.esc;
  let current = null;          // note view payload
  let editMode = false;
  let draft = null;            // unsaved editor text while previewing
  let findState = null;        // in-note search state

  /* ---------------- renderer context ---------------- */

  let titleSet = new Set();
  async function refreshTitles() {
    const g = await SB.api.get("/api/graph");
    titleSet = new Set(g.nodes.map((n) => n.title));
  }

  function bodyOffset() {
    if (!editMode && current && current.body_offset != null) return current.body_offset;
    const raw = current.raw.split("\n");
    let i = 0;
    if (raw[0] && raw[0].startsWith("# ")) i = 1;
    while (i < raw.length && !raw[i].trim()) i++;
    if (raw[i] && raw[i].trim() === ":::quick-info") {
      i++;
      while (i < raw.length && raw[i].trim() !== ":::") i++;
      i++;
    }
    while (i < raw.length && !raw[i].trim()) i++;
    return i;
  }

  function ctx(srcBase) {
    return {
      src: (p) => {
        if (/^https?:/.test(p)) return p;
        const np = p.replace(/^\.?\//, "");
        return "/files/" + current.path.split("/").slice(0, -1).join("/") + "/" + np;
      },
      missing: (t) => !titleSet.has(t.trim()),
      math: (tex, display) => renderMath(tex, display),
    };
  }

  function renderMath(tex, display) {
    if (window.katex) {
      try {
        return katex.renderToString(tex, { displayMode: display, throwOnError: false });
      } catch (e) { /* fall through */ }
    }
    return display ? '<div class="math-fallback">$$' + esc(tex) + "$$</div>"
      : "<em>" + esc(tex) + "</em>";
  }

  /* ---------------- route entry ---------------- */

  SB.views = SB.views || {};

  SB.views.note = async function (name) {
    editMode = false;
    draft = null;
    findState = null;
    current = await SB.api.get("/api/note?path=" + encodeURIComponent(name));
    await refreshTitles();
    renderView();
  };

  async function reload() {
    current = await SB.api.get("/api/note?path=" + encodeURIComponent(current.path));
    await refreshTitles();
    renderView();
  }
  SB._reloadNote = reload;

  /* ---------------- view mode ---------------- */

  function renderView(anchor) {
    closeFind();
    const el = document.getElementById("main");
    const c = ctx();
    const qi = current.quick_info_rows || [];
    const qiHTML = qi.length ? quickInfoCard(qi, c) : "";
    const folderBits = (current.folder || "").split("/").filter(Boolean);

    el.innerHTML =
      '<div class="note-page">' +
      '<div class="crumbs">' +
      '<a href="#/files">' + SB.icon("folderopen") + " database</a>" +
      folderBits.map((f) => '<span class="sep">›</span><a href="#/files/' + encodeURIComponent(current.folder) + '">' + esc(f) + "</a>").join("") +
      '<span class="sep">›</span><b>' + esc(current.title) + "</b>" +
      '<span class="spacer"></span>' +
      '<button class="ghost" id="btn-find" title="Find in note (Ctrl+F)">' + SB.icon("find") + " Find</button>" +
      '<button class="ghost" id="btn-pin" title="Pin to home">' +
      SB.icon(current.pinned ? "pinfilled" : "pin") + (current.pinned ? " Pinned" : " Pin") + "</button>" +
      "</div>" +
      '<div class="note-head"><h1 class="note-title">' + esc(current.title) + "</h1>" +
      '<div class="note-actions">' +
      '<button class="btn accent" id="btn-edit">' + SB.icon("edit") + " Edit</button>" +
      '<button class="btn" id="btn-copy">' + SB.icon("copy") + " Copy</button>" +
      '<button class="btn" id="btn-export">' + SB.icon("download") + " Export</button>" +
      '<button class="btn" id="btn-print">' + SB.icon("print") + " Print</button>" +
      "</div></div>" +
      '<div id="findholder"></div>' +
      qiHTML +
      '<article id="note-body" style="font-size:var(--note-size)">' +
      SB.md.render(current.body, c) +
      "</article>" +
      '<div style="margin-top:var(--grid-gap)">' +
      '<section class="panel" id="panel-connections"></section>' +
      '<div class="grid cols-2">' +
      '<section class="panel" id="panel-references" style="margin-bottom:0"></section>' +
      '<section class="panel" id="panel-tags" style="margin-bottom:0"></section>' +
      "</div>" +
      '<section class="panel" id="panel-meta" style="margin-top:var(--grid-gap)"></section>' +
      "</div></div>";

    wireView();
    renderConnectionsPanel();
    renderReferencesPanel();
    renderTagsPanel();
    renderMetaPanel();
    if (anchor) restoreAnchor(anchor);
  }

  function quickInfoCard(rows, c) {
    let html = '<div class="qicard"><div class="qicard-title">' + SB.icon("note") + " Quick info</div>";
    let group = null;
    rows.forEach((r) => {
      if (r.group && r.group !== group) {
        group = r.group;
        html += '<div class="qi-group">' + esc(group) + "</div>";
      }
      if (r.label.toLowerCase() === "image") {
        html += '<div class="qi-img"><img src="' + c.src(r.value) + '" loading="lazy" data-path="' + esc(r.value) + '"></div>';
      } else {
        html += '<div class="qi-row"><span class="qi-label">' + esc(r.label) +
          '</span><span class="qi-value">' + SB.md.inline(r.value, c) + "</span></div>";
      }
    });
    html += '<button class="ghost qi-edit">' + SB.icon("edit") + " Edit card</button></div>";
    return html;
  }

  /* ------------- connected notes (the reference list) -------------
   * Search finds NOTES ONLY — typing shows note titles + folders, so a
   * connection is always a real note. No tags, no folder names. */

  function renderConnectionsPanel() {
    const panel = document.getElementById("panel-connections");
    const conns = current.connected || [];
    const cards = conns.map((t) =>
      '<div class="conn-card" data-name="' + esc(t) + '">' +
      '<a class="cc-name" href="#/note/' + encodeURIComponent(t) + '">' + esc(t) + "</a>" +
      '<div class="cc-meta"><span class="badge">' + SB.icon("note", 11) + " reference</span>" +
      '<span class="spacer"></span>' +
      '<button class="ghost tiny conn-branch" data-name="' + esc(t) + '" title="Show this branch">' +
      SB.icon("branch", 12) + " branch</button>" +
      '<button class="ghost tiny conn-rm" data-t="' + esc(t) + '" title="Remove connection">' + SB.icon("x", 12) + "</button></div>" +
      "</div>");
    panel.innerHTML =
      '<div class="panel-title">' + SB.icon("graph") + ' Connected notes <span class="count-badge">' +
      conns.length + "</span></div>" +
      (conns.length
        ? '<div class="conn-grid">' + cards.join("") + "</div><div id='branch-box'></div>"
        : '<p class="dim" style="padding:14px">No connected notes yet — these are the notes this one uses as reference. Add one below.</p>') +
      '<div class="panel-add suggest-inline">' +
      '<input id="conn-input" placeholder="Search a note to connect — type a name…" autocomplete="off">' +
      '<button class="btn" id="conn-add">' + SB.icon("plus") + " Connect</button></div>";

    panel.querySelectorAll(".conn-rm").forEach((b) => (b.onclick = async () => {
      await SB.api.post("/api/connections", { path: current.path, remove: [b.dataset.t] });
      SB.toast("Connection removed.");
      reload();
    }));
    panel.querySelectorAll(".conn-branch").forEach((b) => (b.onclick = (e) => {
      e.stopPropagation();
      showBranch(b.dataset.name);
    }));
    const inp = panel.querySelector("#conn-input");
    // NOTES ONLY: the dropdown lists note titles (+ their folder)
    SB.noteSuggest(inp, (name) => connectTo(name));
    panel.querySelector("#conn-add").onclick = () => {
      const t = inp.value.trim();
      if (!t) return SB.toast("Type a note name — suggestions appear as you type.", "err");
      // exact title match required; suggest the closest notes otherwise
      if (titleSet.has(t)) return connectTo(t);
      SB.api.get("/api/suggest?q=" + encodeURIComponent(t) + "&type=note").then((res) => {
        const first = (res.suggestions || [])[0];
        if (first) connectTo(first.name);
        else SB.toast("No note matches that name.", "err");
      });
    };
  }

  async function connectTo(name) {
    try {
      await SB.api.post("/api/connections", { path: current.path, add: [name] });
      SB.toast("Connected to " + name + ".");
      reload();
    } catch (e) { SB.toast(e.message, "err"); }
  }

  async function showBranch(name, depth, box) {
    depth = depth || 0;
    const holder = box || document.getElementById("branch-box");
    if (!holder) return;
    if (depth === 0 && holder.dataset.open === name) { holder.innerHTML = ""; holder.dataset.open = ""; return; }
    if (depth === 0) holder.dataset.open = name;
    const res = await SB.api.get("/api/connections?path=" + encodeURIComponent(name));
    const conns = (res.connections || []).filter((c) => c.exists);
    const wrap = document.createElement("div");
    wrap.className = "branch";
    wrap.innerHTML =
      '<div class="branch-node">' + SB.icon("branch", 13) +
      '<a href="#/note/' + encodeURIComponent(name) + '">' + esc(name) + "</a>" +
      ' <span class="dim">' + conns.length + " connection(s)</span></div>" +
      (conns.length ? "" : '<div class="branch-node dim">— end of branch</div>') +
      (conns.map((c) =>
        '<div class="branch-node" style="margin-left:14px">' + SB.icon("note", 12) +
        '<a href="#/note/' + encodeURIComponent(c.name) + '">' + esc(c.name) + "</a>" +
        '<button class="ghost tiny br-next" data-n="' + esc(c.name) + '">expand</button></div>'
      ).join(""));
    holder.appendChild(wrap);
    wrap.querySelectorAll(".br-next").forEach((b) => (b.onclick = () => {
      if (b.dataset.done) return;
      b.dataset.done = "1";
      b.textContent = "…";
      showBranch(b.dataset.n, depth + 1, wrap);
    }));
  }

  /* ---------------- references (auto-https) ---------------- */

  function renderReferencesPanel() {
    const panel = document.getElementById("panel-references");
    const refs = current.references || [];
    panel.innerHTML =
      '<div class="panel-title">' + SB.icon("link") + ' Reference sources <span class="count-badge">' +
      refs.length + "</span></div>" +
      (refs.length
        ? '<ul class="ref-list">' + refs.map((r) =>
            '<li><a class="weblink" href="' + esc(r.url) + '" target="_blank" rel="noopener">' +
            esc(r.title || r.url) + "</a>" +
            (r.accessed ? ' <span class="dim">— ' + esc(r.accessed) + "</span>" : "") +
            '<button class="ghost tiny ref-rm" data-u="' + esc(r.url) + '">' + SB.icon("x", 12) + "</button></li>").join("") + "</ul>"
        : '<p class="dim" style="padding:14px">No external reference sources yet.</p>') +
      '<div class="panel-add">' +
      '<input id="ref-title" placeholder="Title (optional — domain used if empty)">' +
      '<input id="ref-url" placeholder="domain.com — https:// added automatically">' +
      '<button class="btn" id="ref-add">' + SB.icon("plus") + " Add</button></div>" +
      '<p class="dim mono" id="ref-preview" style="font-size:11px;padding:0 14px 12px"></p>';
    const url = panel.querySelector("#ref-url");
    url.addEventListener("input", () => {
      const u = url.value.trim();
      panel.querySelector("#ref-preview").textContent =
        u && !/^https?:/i.test(u) ? "will be saved as https://" + u : "";
    });
    panel.querySelector("#ref-add").onclick = async () => {
      const title = panel.querySelector("#ref-title").value.trim();
      let u = url.value.trim();
      if (!u) return SB.toast("Give the address (domain.com is enough).", "err");
      u = SB.normalizeUrl(u);
      if (!/^https?:/i.test(u)) return SB.toast("That does not look like a web address.", "err");
      try {
        await SB.api.post("/api/references", { path: current.path, add: { title, url: u } });
        SB.toast("Reference source added.");
        reload();
      } catch (e) { SB.toast(e.message, "err"); }
    };
    panel.querySelectorAll(".ref-rm").forEach((b) => (b.onclick = async () => {
      await SB.api.post("/api/references", { path: current.path, remove_url: b.dataset.u });
      reload();
    }));
  }

  /* ---------------- tags panel (independent, synced) ---------------- */

  function renderTagsPanel() {
    const panel = document.getElementById("panel-tags");
    const tags = current.tags || [];
    panel.innerHTML =
      '<div class="panel-title">' + SB.icon("tag") + ' Tags <span class="count-badge">' +
      tags.length + "</span></div>" +
      '<div class="tagcloud" style="padding:14px">' +
      (tags.length
        ? tags.map((t) => '<span class="chip chipx" data-t="' + esc(t) + '">' + SB.esc(t) +
            "<button title='Remove tag'>" + SB.icon("x", 11) + "</button></span>").join("")
        : '<span class="dim">No tags yet.</span>') +
      "</div>" +
      '<div class="panel-add suggest-inline">' +
      '<input id="tag-input" placeholder="Add a tag — existing ones appear as you type…">' +
      '<button class="btn" id="tag-add">' + SB.icon("plus") + " Add</button></div>";
    panel.querySelectorAll(".chipx button").forEach((b) => (b.onclick = async () => {
      const t = b.parentElement.dataset.t;
      await SB.api.post("/api/tags/edit", { path: current.path, remove: [t] });
      SB.toast("Tag removed.");
      reload();
    }));
    const inp = panel.querySelector("#tag-input");
    const add = async (t) => {
      try {
        const out = await SB.api.post("/api/tags/edit", { path: current.path, add: [t] });
        SB.toast(out.proposed && out.proposed.length
          ? "Tag added and filed in _tags.md." : "Tag added.");
        reload();
      } catch (e) { SB.toast(e.message, "err"); }
    };
    panel.querySelector("#tag-add").onclick = () => { if (inp.value.trim()) add(inp.value.trim()); };
    SB.tagSuggest(inp, (type, name) => add(name), { type: "tag", enterType: "tag" });
  }

  /* ---------------- metadata ---------------- */

  function renderMetaPanel() {
    const panel = document.getElementById("panel-meta");
    const m = current.meta || {};
    const row = (k) => "<div class='qi-row'><span class='qi-label'>" + k +
      "</span><span>" + esc(m[k] || "—") + "</span></div>";
    panel.innerHTML =
      '<div class="panel-title">' + SB.icon("gear") + " Metadata</div>" +
      '<div style="padding:8px 0 10px">' +
      row("created") + row("updated") + row("pinned") + "</div>" +
      '<div class="panel-add">' +
      '<button class="btn" id="meta-edit">' + SB.icon("edit") + " Edit as form</button>" +
      '<button class="btn" id="meta-raw">' + SB.icon("edit") + " Edit raw block</button></div>" +
      '<p class="dim" style="padding:0 14px 12px;font-size:12px">Tags live in tags.txt beside the note; the master list is _tags.md.</p>';
    panel.querySelector("#meta-edit").onclick = () => metaForm();
    panel.querySelector("#meta-raw").onclick = () => metaRaw();
  }

  function metaForm() {
    const m = current.meta || {};
    const field = (k) =>
      "<label>" + k + '</label><input id="mf-' + k + '" value="' + esc(m[k] || "") + '">';
    SB.modal("Edit metadata",
      field("Created") + field("Updated") + field("Pinned (yes/no)"), [
      { label: "Cancel" },
      { label: "Save", primary: true, onclick: async (w) => {
        const g = (k) => w.querySelector("#mf-" + k).value;
        await SB.api.post("/api/metadata", { path: current.path,
          meta: { created: g("Created"), updated: g("Updated"), pinned: g("Pinned (yes/no)") } });
        SB.toast("Metadata saved.");
        reload();
      }},
    ]);
  }

  function metaRaw() {
    const m = current.meta || {};
    const text = Object.keys(m).filter((k) => k !== "status")
      .map((k) => k.charAt(0).toUpperCase() + k.slice(1) + ": " + m[k]).join("\n");
    SB.modal("Metadata block (raw)", "<textarea id='meta-raw-text' rows='6'>" + esc(text) + "</textarea>", [
      { label: "Cancel" },
      { label: "Save", primary: true, onclick: async (w) => {
        const meta = {};
        w.querySelector("#meta-raw-text").value.split("\n").forEach((ln) => {
          const mm = ln.match(/^([A-Za-z][A-Za-z0-9 _-]*):\s*(.*)$/);
          if (mm) meta[mm[1].toLowerCase()] = mm[2];
        });
        await SB.api.post("/api/metadata", { path: current.path, meta });
        SB.toast("Metadata saved.");
        reload();
      }},
    ]);
  }

  /* ---------------- view wiring ---------------- */

  function wireView() {
    document.getElementById("btn-edit").onclick = () => switchMode(true);
    document.getElementById("btn-copy").onclick = async () => {
      const withoutMeta = current.raw.replace(/:::meta\n[\s\S]*?:::\s*$/, "").trimEnd();
      try {
        await navigator.clipboard.writeText(withoutMeta);
        SB.toast("Note copied as raw Markdown.");
      } catch (e) {
        SB.toast("Clipboard blocked by the browser; copy from Edit mode instead.", "err");
      }
    };
    document.getElementById("btn-export").onclick = () => {
      window.location.href = "/api/export?path=" + encodeURIComponent(current.path);
    };
    document.getElementById("btn-print").onclick = () => window.print();
    document.getElementById("btn-pin").onclick = async () => {
      await SB.api.post("/api/pin", { path: current.path });
      SB.toast(current.pinned ? "Unpinned." : "Pinned to home.");
      reload();
    };
    document.getElementById("btn-find").onclick = () => openFind("view");

    // tick checklists straight from the rendered page
    document.querySelectorAll("#note-body .tick").forEach((tk, idx) => {
      tk.onclick = async () => {
        try {
          await SB.api.post("/api/note/toggle_task", { path: current.path, index: idx });
          reload();
        } catch (e) { SB.toast(e.message, "err"); }
      };
    });

    // edit any table from the rendered page
    document.querySelectorAll("#note-body .tbl-edit").forEach((b) => {
      b.onclick = () => {
        draft = null;
        switchMode(true, { thenTable: [+b.dataset.tsl, +b.dataset.tel] });
      };
    });

    // images: click opens full screen
    document.querySelectorAll("#note-body img.md-img, .qi-img img").forEach((img) => {
      img.onclick = () => fullscreenImage(img);
      applySavedSize(img);
    });

    const qiEdit = document.querySelector(".qi-edit");
    if (qiEdit) qiEdit.onclick = () => quickInfoEditor();
  }

  /* ---------------- anchor (edit <-> preview keeps your place) ------------- */

  function captureAnchor() {
    const body = document.getElementById("note-body");
    const editor = document.getElementById("editor");
    const container = body || editor;
    if (!container) return null;
    const top = container.getBoundingClientRect().top;
    if (body && body.style.display !== "none") {
      const blocks = body.querySelectorAll(".blk");
      for (const b of blocks) {
        const r = b.getBoundingClientRect();
        if (r.bottom > top + 1) {
          const frac = Math.min(1, Math.max(0, (top - r.top) / Math.max(1, r.height)));
          return { kind: "view", sl: +b.dataset.sl, frac, off: top };
        }
      }
      return { kind: "view", sl: 0, frac: 0, off: top };
    }
    const lh = parseFloat(getComputedStyle(editor).lineHeight) || 21;
    const line = Math.floor(editor.scrollTop / lh);
    return { kind: "edit", line, off: top };
  }

  function restoreAnchor(a) {
    const body = document.getElementById("note-body");
    const editor = document.getElementById("editor");
    if (a.kind === "edit" && editor) {
      const lh = parseFloat(getComputedStyle(editor).lineHeight) || 21;
      editor.scrollTop = a.line * lh;
      return;
    }
    if (!body || body.style.display === "none") return;
    const top = body.getBoundingClientRect().top;
    const blocks = body.querySelectorAll(".blk");
    let target = null, best = -1;
    for (const b of blocks) {
      const sl = +b.dataset.sl;
      if (sl <= a.sl || best < 0) { if (sl <= a.sl) { target = b; best = sl; } }
      if (!target) target = b;
    }
    if (!target) return;
    const r = target.getBoundingClientRect();
    window.scrollTo({ top: window.scrollY + (r.top + a.frac * r.height - top), behavior: "instant" });
  }

  /* ---------------- mode switching ---------------- */

  async function switchMode(toEdit, opts) {
    const anchor = opts && opts.noAnchor ? null : captureAnchor();
    if (toEdit) {
      editMode = true;
      const el = document.getElementById("main");
      el.innerHTML = editSkeleton();
      const ed = document.getElementById("editor");
      ed.value = current.raw;
      wireEditor();
      if (anchor && anchor.kind === "edit") { /* staying in edit */ }
      else if (anchor) {
        const lh = parseFloat(getComputedStyle(ed).lineHeight) || 21;
        const lines = current.raw.split("\n");
        let line = 0;
        for (let i = 0; i < lines.length; i++) {
          if (i >= anchor.sl) { line = i; break; }
        }
        ed.scrollTop = line * lh;
      }
      ed.focus();
      if (opts && opts.thenTable && SB._openTableEditor) {
        SB._openTableEditor(opts.thenTable[0], opts.thenTable[1]);
      }
    } else {
      editMode = false;
      renderView(anchor);
    }
  }
  SB.switchNoteMode = switchMode;

  function editSkeleton() {
    return '<div class="note-page"><div class="crumbs">' +
      '<a href="#/files">' + SB.icon("folderopen") + " database</a> <span class='sep'>›</span> <b>" +
      esc(current.title) + '</b><span class="spacer"></span>' +
      '<button class="ghost" id="btn-find-e" title="Find in note (Ctrl+F)">' + SB.icon("find") + " Find</button>" +
      '<span id="save-state" class="dim mono"></span></div>' +
      '<div class="note-head"><h1 class="note-title">' + esc(current.title) + "</h1>" +
      '<div class="note-actions">' +
      '<button class="btn accent" id="btn-save">' + SB.icon("check") + " Save</button>" +
      '<button class="btn" id="btn-preview">' + SB.icon("eye") + " Preview</button>" +
      '<button class="btn" id="btn-cancel-edit">Cancel</button>' +
      "</div></div>" +
      '<div id="findholder"></div>' +
      '<div class="edit-toolbar" id="toolbar"></div>' +
      '<textarea id="editor" spellcheck="false"></textarea>' +
      '<p class="dim" style="font-size:12px;margin-top:8px">Raw Markdown — what you type is exactly what is saved. ' +
      "Shortcuts: <b>e</b> toggles edit/preview, <b>Ctrl/Cmd+S</b> saves, <b>Ctrl/Cmd+F</b> finds in this note. " +
      "Select a word, then tap a toolbar button to format it.</p></div>";
  }

  /* ---------------- the smart toolbar ---------------- */

  function wireEditor() {
    const ed = document.getElementById("editor");
    const tb = document.getElementById("toolbar");
    const T = [
      ["Bold", "bold"], ["Italic", "italic"], ["Code", "code"],
      ["Heading", "heading"], ["List", "list"], ["Task", "task"],
      ["Quote", "quote"], ["Table", "table"], ["Math", "math"],
      ["Footnote", "footnote"], ["Rule", "hrule"],
    ];
    tb.innerHTML =
      T.map((t) => '<button class="tool" data-tool="' + t[1] + '" title="' + t[0] + '">' +
        SB.icon(t[1], 14) + "</button>").join("") +
      '<span class="vr"></span>' +
      '<button class="tool" id="tool-wikilink" title="Link to a note">' + SB.icon("note", 14) + " Link note</button>" +
      '<button class="tool" id="tool-weblink" title="Link to a web page">' + SB.icon("link", 14) + " Link web</button>" +
      '<button class="tool" id="tool-image" title="Insert an image">' + SB.icon("img", 14) + " Image</button>" +
      '<span class="vr"></span>' +
      '<button class="tool" id="tool-find" title="Find in note">' + SB.icon("find", 14) + " Find</button>";

    tb.querySelectorAll(".tool[data-tool]").forEach((b) => {
      b.onclick = () => applyTool(b.dataset.tool);
    });
    document.getElementById("tool-wikilink").onclick = () => linkDialog(true);
    document.getElementById("tool-weblink").onclick = () => linkDialog(false);
    document.getElementById("tool-image").onclick = imageDialog;
    document.getElementById("tool-find").onclick = () => openFind("edit");
    document.getElementById("btn-find-e").onclick = () => openFind("edit");

    ed.addEventListener("keydown", (e) => {
      if ((e.ctrlKey || e.metaKey) && e.key === "s") { e.preventDefault(); saveNote(); }
      if (e.key === "Tab") {
        e.preventDefault();
        insertAtCursor("  ", "");
      }
    });

    /* ---------- tool implementations ---------- */

    function selection() {
      const s = ed.selectionStart, e2 = ed.selectionEnd;
      return { s, e: e2, text: ed.value.slice(s, e2) };
    }

    /* never leave the inserted markup selected; drop the cursor in the
     * most useful place: between wrap marks with no selection, right
     * after the text with a selection, at the end for line prefixes. */
    function insertAtCursor(before, after, opts) {
      const o = opts || {};
      const sel = selection();
      const has = sel.text.length > 0;
      const payload = before + sel.text + (after || "");
      ed.setRangeText(payload, sel.s, sel.e, "end");
      let pos;
      if (after) {
        pos = has ? sel.s + before.length + sel.text.length
                  : sel.s + before.length;
        if (o.cursor === "end") pos = sel.s + payload.length;
      } else {
        pos = sel.s + payload.length;
      }
      ed.setSelectionRange(pos, pos);
      ed.focus();
    }

    function currentLine() {
      const sel = selection();
      const val = ed.value;
      const ls = val.lastIndexOf("\n", sel.s - 1) + 1;
      let le = val.indexOf("\n", sel.e);
      if (le === -1) le = val.length;
      return { start: ls, end: le, text: val.slice(ls, le) };
    }

    function togglePrefix(prefix, plainRe) {
      const ln = currentLine();
      const sel = selection();
      if (ln.text.startsWith(prefix)) {
        ed.setSelectionRange(ln.start, ln.end);
        ed.setRangeText(ln.text.slice(prefix.length), ln.start, ln.end, "end");
        ed.setSelectionRange(ln.start + Math.min(prefix.length, sel.s - ln.start),
                             ln.start + Math.min(prefix.length, sel.s - ln.start));
      } else {
        // strip ANY existing line marker before adding the new one
        const cleaned = ln.text.replace(plainRe, "");
        ed.setSelectionRange(ln.start, ln.end);
        ed.setRangeText(prefix + cleaned, ln.start, ln.end, "end");
        ed.setSelectionRange(ln.start + prefix.length + cleaned.length,
                             ln.start + prefix.length + cleaned.length);
      }
      ed.focus();
    }

    const ANY_MARKER = /^(#{1,6}\s+|[-*]\s+(\[[ xX]\]\s+)?|\d+[.)]\s+|>\s+)+/;

    function applyTool(tool) {
      const sel = selection();
      switch (tool) {
        case "bold": insertAtCursor("**", "**"); break;
        case "italic": insertAtCursor("*", "*"); break;
        case "code": insertAtCursor("`", "`"); break;
        case "heading": togglePrefix("## ", ANY_MARKER); break;
        case "list": togglePrefix("- ", ANY_MARKER); break;
        case "task": togglePrefix("- [ ] ", ANY_MARKER); break;
        case "quote": togglePrefix("> ", ANY_MARKER); break;
        case "hrule": insertAtCursor("\n\n---\n\n", "", { cursor: "end" }); break;
        case "footnote": insertAtCursor("[^1]", "", { cursor: "end" }); break;
        case "math":
          if (sel.text) insertAtCursor("$", "$");
          else insertAtCursor("\n$$\n", "\n$$\n", { cursor: "end" });
          break;
        case "table": openTableEditor(null); break;
      }
    }

    /* ---------- links (note or web, https auto) ----------
     * Link-note searches NOTES ONLY — same picker as connected notes. */

    function linkDialog(isNote) {
      const sel = selection();
      const word = sel.text.trim();
      if (isNote) {
        SB.modal("Link to a note",
          "<p class='dim'>The selected word becomes the link text. Only existing notes can be chosen — type to search notes.</p>" +
          "<label>Link text</label><input id='wl-word' value=\"" + esc(word || "") + "\" placeholder='word'>" +
          "<label>Target note</label><div class='suggest-inline'><input id='wl-target' placeholder='Type a note name…' autocomplete='off'></div>", [
          { label: "Cancel" },
          { label: "Insert [[Target|word]]", primary: true, onclick: (w) => {
            const wordV = w.querySelector("#wl-word").value.trim() || "word";
            const target = w.querySelector("#wl-target").value.trim();
            if (!titleSet.has(target)) { SB.toast("No such note in this wiki — pick one from the list.", "err"); return false; }
            ed.setRangeText("[[" + target + "|" + wordV + "]]", sel.s, sel.e, "end");
            ed.setSelectionRange(sel.s + ("[[" + target + "|" + wordV + "]]").length,
                                 sel.s + ("[[" + target + "|" + wordV + "]]").length);
            ed.focus();
          }},
        ]);
        const tin = document.querySelector("#wl-target");
        SB.noteSuggest(tin, (name) => { tin.value = name; }, { keepValue: true });
        setTimeout(() => (word ? document.querySelector("#wl-target") : document.querySelector("#wl-word")).focus(), 60);
      } else {
        SB.modal("Link to a web page",
          "<p class='dim'>The selected word becomes the link text. Just type <b>domain.com</b> — https:// is added for you.</p>" +
          "<label>Link text</label><input id='we-word' value=\"" + esc(word || "") + "\" placeholder='word'>" +
          "<label>Address</label><input id='we-url' placeholder='example.com/page' " +
          "value=\"" + esc(word && SB.isProbablyUrl(word) ? word : "") + "\">" +
          "<p class='dim mono' id='we-preview' style='font-size:11px'></p>", [
          { label: "Cancel" },
          { label: "Insert link", primary: true, onclick: (w) => {
            const wordV = w.querySelector("#we-word").value.trim();
            const url = SB.normalizeUrl(w.querySelector("#we-url").value.trim());
            if (!/^https?:/i.test(url)) { SB.toast("Needs an address like domain.com.", "err"); return false; }
            const text = wordV || url;
            ed.setRangeText("[" + text + "](" + url + ")", sel.s, sel.e, "end");
            ed.setSelectionRange(sel.s + ("[" + text + "](" + url + ")").length,
                                 sel.s + ("[" + text + "](" + url + ")").length);
            ed.focus();
          }},
        ]);
        const urlIn = document.querySelector("#we-url");
        const wordIn = document.querySelector("#we-word");
        urlIn.addEventListener("input", () => {
          const u = SB.normalizeUrl(urlIn.value.trim());
          document.querySelector("#we-preview").textContent =
            urlIn.value.trim() ? "will be saved as " + u : "";
          if (!wordIn.value.trim()) wordIn.value = urlIn.value.trim();
        });
        setTimeout(() => (urlIn.focus()), 60);
      }
    }

    function imageDialog() {
      const inp = document.createElement("input");
      inp.type = "file";
      inp.accept = "image/*";
      inp.onchange = async () => {
        const f = inp.files[0];
        if (!f) return;
        const b64 = await new Promise((res) => {
          const r = new FileReader();
          r.onload = () => res(r.result.split(",")[1]);
          r.readAsDataURL(f);
        });
        try {
          const out = await SB.api.post("/api/image/add", {
            path: current.path, filename: f.name, data_base64: b64,
          });
          const sel = selection();
          const payload = "\n![" + f.name.replace(/\.[a-z]+$/i, "") + "](" + out.file + ")\n";
          ed.setRangeText(payload, sel.s, sel.e, "end");
          ed.setSelectionRange(sel.s + payload.length, sel.s + payload.length);
          ed.focus();
          SB.toast("Image added to attachments/ and placed in the note.");
        } catch (e) { SB.toast(e.message, "err"); }
      };
      inp.click();
    }

    /* ---------- visual table editor ---------- */

    function parseTableRange(a, b) {
      const lines = ed.value.split("\n").slice(a, b + 1);
      const rows = lines.filter((l) => /^\s*\|.*\|\s*$/.test(l))
        .map((l) => l.trim().replace(/^\|/, "").replace(/\|$/, "")
          .split(/\s*\|\s*(?![^[]*\])/).map((c) => c.trim()));
      if (rows.length >= 2) rows.splice(1, 1);   // drop the |---|---| separator
      return rows;
    }

    function openTableEditor(a, b) {
      const isRange = a != null && b != null;
      const rows = isRange ? parseTableRange(a, b) : [["Header", "Header"], ["", ""]];
      const ncols = Math.max(...rows.map((r) => r.length), 1);
      while (rows.length < 2) rows.push(new Array(ncols).fill(""));

      const gridHTML = () => {
        let h = '<div class="table-editor" id="te-grid">';
        rows.forEach((r, ri) => {
          h += '<div class="te-row' + (ri === 0 ? " te-head" : "") + '">';
          r.forEach((c, ci) => {
            h += '<input data-r="' + ri + '" data-c="' + ci + '" value="' + esc(c) + '">';
          });
          h += '<button class="ghost tiny te-delrow" data-r="' + ri + '" title="Delete row">' + SB.icon("x", 11) + "</button></div>";
        });
        h += "</div>";
        return h;
      };

      const w = SB.modal("Table editor",
        "<p class='dim'>Edit every cell. Add or remove rows and columns — " +
        "Apply writes the Markdown back exactly where the table was.</p>" +
        '<div class="te-tools">' +
        '<button class="btn tiny" id="te-addrow">' + SB.icon("plus", 12) + " Row</button>" +
        '<button class="btn tiny" id="te-addcol">' + SB.icon("plus", 12) + " Column</button>" +
        '<button class="btn tiny" id="te-delcol">Delete last column</button>' +
        "</div>" + gridHTML(), [
        { label: "Cancel" },
        { label: "Apply to note", primary: true, onclick: () => {
          document.querySelectorAll("#te-grid input").forEach((inp) => {
            rows[+inp.dataset.r][+inp.dataset.c] = inp.value;
          });
          const width = Math.max(...rows.map((r) => r.length));
          rows.forEach((r) => { while (r.length < width) r.push(""); });
          const md = ["| " + rows[0].join(" | ") + " |",
                      "| " + rows[0].map(() => "---").join(" | ") + " |"]
            .concat(rows.slice(1).map((r) => "| " + r.join(" | ") + " |"))
            .join("\n");
          const lines = ed.value.split("\n");
          if (isRange) {
            lines.splice(a, b - a + 1, md);
            const newText = lines.join("\n");
            const sel = selection();
            ed.value = newText;
            const pos = lines.slice(0, a).join("\n").length + (a ? 1 : 0);
            ed.setSelectionRange(pos + md.length, pos + md.length);
          } else {
            const sel = selection();
            ed.setRangeText("\n" + md + "\n", sel.s, sel.e, "end");
            ed.setSelectionRange(sel.s + md.length + 2, sel.s + md.length + 2);
          }
          ed.focus();
          SB.toast("Table written into the note.");
        }},
      ]);

      const paint = () => {
        w.querySelector("#te-grid").outerHTML = gridHTML();
        wireGrid();
      };
      const wireGrid = () => {
        w.querySelectorAll(".te-delrow").forEach((btn) => (btn.onclick = () => {
          if (rows.length <= 1) return;
          rows.splice(+btn.dataset.r, 1);
          paint();
        }));
      };
      wireGrid();
      w.querySelector("#te-addrow").onclick = () => {
        rows.push(new Array(rows[0].length).fill(""));
        paint();
      };
      w.querySelector("#te-addcol").onclick = () => {
        rows.forEach((r) => r.push(""));
        paint();
      };
      w.querySelector("#te-delcol").onclick = () => {
        if (rows[0].length <= 1) return;
        rows.forEach((r) => r.pop());
        paint();
      };
    }
    SB._openTableEditor = openTableEditor;

    /* ---------- save / preview / cancel ---------- */

    document.getElementById("btn-save").onclick = saveNote;
    document.getElementById("btn-preview").onclick = () => {
      draft = document.getElementById("editor").value;
      const parsed = stripBlocks(draft);
      current = Object.assign({}, current, {
        raw: draft, body: parsed.body,
        quick_info_rows: parsed.qiRows, quick_info_raw: parsed.qiRows.length ?
          parsed.qiRows.map((r) => r.label + ": " + r.value).join("\n") : null,
        meta: parsed.meta,
      });
      editMode = false;
      renderView(captureAnchor());
    };
    document.getElementById("btn-cancel-edit").onclick = () => {
      draft = null;
      editMode = false;
      reload();
    };
  }

  function stripBlocks(text) {
    let body = text.replace(/^# .*\n/, "");
    const qiM = body.match(/:::quick-info\n([\s\S]*?)\n:::/);
    let qiRows = [];
    if (qiM) {
      body = body.replace(qiM[0], "");
      let group = null;
      qiM[1].split("\n").forEach((ln) => {
        ln = ln.trim();
        if (!ln) return;
        if (ln.startsWith("##")) { group = ln.replace(/^#+\s*/, ""); return; }
        const m = ln.match(/^([^:]{1,60}):\s*(.*)$/);
        if (m) qiRows.push({ label: m[1], value: m[2], group });
      });
    }
    const metaM = body.match(/:::meta\n([\s\S]*?)\n:::/);
    const meta = {};
    if (metaM) {
      body = body.replace(metaM[0], "");
      metaM[1].split("\n").forEach((ln) => {
        const m = ln.match(/^([A-Za-z]+):\s*(.*)$/);
        if (m) meta[m[1].toLowerCase()] = m[2];
      });
    }
    return { body: body.trim(), qiRows, meta };
  }

  async function saveNote() {
    const ed = document.getElementById("editor");
    const state = document.getElementById("save-state");
    state.textContent = "Saving…";
    try {
      const out = await SB.api.post("/api/note/save", {
        path: current.path, text: ed.value, base_hash: current.hash,
      });
      if (out.conflict) {
        SB.modal("The file changed while it was open",
          "<p>" + esc(out.message) + "</p>", [
          { label: "Cancel" },
          { label: "Reload my editor with the new file", onclick: () => reload() },
          { label: "Overwrite with my version", primary: true, onclick: async () => {
            await SB.api.post("/api/note/save", {
              path: current.path, text: ed.value, base_hash: out.current_hash,
              force: true,
            });
            SB.toast("Overwritten. The previous text is in the log.");
            reload();
          }},
        ]);
        state.textContent = "";
        return;
      }
      current.hash = out.hash;
      draft = null;
      state.textContent = "Saved " + new Date().toLocaleTimeString();
      SB.toast("Saved. One log file recorded the change.");
    } catch (e) {
      state.textContent = "";
      SB.toast(e.message, "err");
    }
  }

  /* ---------------- find in note (edit AND preview) ---------------- */

  function openFind(mode) {
    closeFind();
    const holder = document.getElementById("findholder");
    if (!holder) return;
    findState = { mode: mode || (editMode ? "edit" : "view"), term: "", idx: 0, hits: [] };
    holder.innerHTML =
      '<div class="findbar">' + SB.icon("find") +
      '<input id="find-input" placeholder="Find in this note…">' +
      '<span class="count mono" id="find-count"></span>' +
      '<button class="btn tiny" id="find-prev">↑ Prev</button>' +
      '<button class="btn tiny" id="find-next">↓ Next</button>' +
      '<button class="ghost tiny" id="find-close">' + SB.icon("x", 12) + "</button></div>";
    const inp = holder.querySelector("#find-input");
    inp.focus();
    inp.addEventListener("input", SB.debounce(() => runFind(inp.value), 140));
    inp.addEventListener("keydown", (e) => {
      if (e.key === "Enter") { e.preventDefault(); nextFind(e.shiftKey ? -1 : 1); }
      if (e.key === "Escape") closeFind();
    });
    holder.querySelector("#find-next").onclick = () => nextFind(1);
    holder.querySelector("#find-prev").onclick = () => nextFind(-1);
    holder.querySelector("#find-close").onclick = closeFind;
    if (editMode) document.getElementById("editor").focus();
  }

  function closeFind() {
    findState = null;
    const holder = document.getElementById("findholder");
    if (holder) holder.innerHTML = "";
    const body = document.getElementById("note-body");
    if (body && body.dataset.origHtml) {
      body.innerHTML = body.dataset.origHtml;
      delete body.dataset.origHtml;
      wireView();
    }
  }

  function runFind(term) {
    if (!findState) return;
    findState.term = term;
    findState.idx = 0;
    findState.hits = [];
    const count = document.getElementById("find-count");
    if (!term) { count.textContent = ""; if (findState.mode === "view") restorePlain(); return; }
    if (findState.mode === "edit") {
      const ed = document.getElementById("editor");
      const val = ed.value.toLowerCase();
      const t = term.toLowerCase();
      let i = val.indexOf(t);
      while (i !== -1) { findState.hits.push(i); i = val.indexOf(t, i + t.length); }
      count.textContent = findState.hits.length ? "1 / " + findState.hits.length : "0 found";
      if (findState.hits.length) showEditHit(0);
    } else {
      highlightInPreview(term);
      count.textContent = findState.hits.length
        ? "1 / " + findState.hits.length : "0 found";
      if (findState.hits.length) showPreviewHit(0);
    }
  }

  function restorePlain() {
    const body = document.getElementById("note-body");
    if (body && body.dataset.origHtml) {
      body.innerHTML = body.dataset.origHtml;
      delete body.dataset.origHtml;
      wireView();
    }
  }

  function highlightInPreview(term) {
    const body = document.getElementById("note-body");
    if (!body) return;
    if (!body.dataset.origHtml) body.dataset.origHtml = body.innerHTML;
    const html = body.dataset.origHtml;
    const re = new RegExp("(" + term.replace(/[.*+?^${}()|[\]\\]/g, "\\$&") + ")", "gi");
    body.innerHTML = html.replace(/>([^<]+)</g, (m, text) => {
      if (!re.test(text)) return m;
      re.lastIndex = 0;
      return ">" + text.replace(re, '<mark class="find-hit">$1</mark>') + "<";
    });
    findState.hits = Array.from(body.querySelectorAll("mark.find-hit"));
  }

  function showPreviewHit(i) {
    findState.idx = (i + findState.hits.length) % findState.hits.length;
    findState.hits.forEach((m, k) => m.classList.toggle("current", k === findState.idx));
    const el = findState.hits[findState.idx];
    if (el) el.scrollIntoView({ block: "center", behavior: "smooth" });
    const count = document.getElementById("find-count");
    if (count) count.textContent = (findState.idx + 1) + " / " + findState.hits.length;
  }

  function showEditHit(i) {
    const ed = document.getElementById("editor");
    const t = findState.term.length;
    findState.idx = (i + findState.hits.length) % findState.hits.length;
    const start = findState.hits[findState.idx];
    ed.focus();
    ed.setSelectionRange(start, start + t);
    const lh = parseFloat(getComputedStyle(ed).lineHeight) || 21;
    const line = ed.value.slice(0, start).split("\n").length;
    ed.scrollTop = Math.max(0, (line - 4) * lh);
    const count = document.getElementById("find-count");
    if (count) count.textContent = (findState.idx + 1) + " / " + findState.hits.length;
  }

  function nextFind(dir) {
    if (!findState || !findState.hits.length) return;
    if (findState.mode === "edit") showEditHit(findState.idx + dir);
    else showPreviewHit(findState.idx + dir);
  }

  /* Ctrl/Cmd+F inside a note opens OUR find bar */
  document.addEventListener("keydown", (e) => {
    if ((e.ctrlKey || e.metaKey) && (e.key === "f" || e.key === "F")) {
      if (SB.state.route === "note" && !e.shiftKey) {
        e.preventDefault();
        openFind(editMode ? "edit" : "view");
      }
    }
  });

  /* ---------------- metadata editors ---------------- */

  function quickInfoEditor() {
    SB.modal("Edit quick info card",
      "<p class='dim'>One line per fact, <b>Label: value</b>. A line starting with " +
      "<b>##</b> begins a named group. Raw editing shows the same text the file holds.</p>" +
      "<textarea id='qi-text' rows='10'>" + esc(current.quick_info_raw || "") + "</textarea>", [
      { label: "Cancel" },
      { label: "Save card", primary: true, onclick: async (w) => {
        try {
          await SB.api.post("/api/quick_info", { path: current.path, text: w.querySelector("#qi-text").value });
          SB.toast("Quick info saved.");
          reload();
        } catch (e) { SB.toast(e.message, "err"); return false; }
      }},
    ]);
  }

  /* ---------------- images ---------------- */

  function applySavedSize(img) {
    const key = "imgsize:" + current.path + ":" + img.dataset.path;
    const w = localStorage.getItem(key);
    if (w && !img.closest(".md-imggrid")) img.style.width = w;
  }

  function fullscreenImage(img) {
    const path = img.dataset.path;
    const src = img.src;
    const wrap = document.createElement("div");
    wrap.className = "fullscreen-img";
    wrap.innerHTML =
      '<div class="fs-tools">' +
      '<button class="btn" id="fs-crop">' + SB.icon("crop") + " Crop</button>" +
      '<a class="btn" id="fs-download" download="' + esc(path.split("/").pop()) + '" href="' + src + '">' +
      SB.icon("download") + " Download</a>" +
      '<button class="btn danger" id="fs-delete">' + SB.icon("trash") + " Delete</button>" +
      '<span class="spacer"></span>' +
      '<button class="btn" id="fs-close">' + SB.icon("x") + " Close</button></div>" +
      '<div class="fs-stage"><img id="fs-img" src="' + src + '"></div>';
    document.body.appendChild(wrap);
    wrap.querySelector("#fs-close").onclick = () => wrap.remove();
    wrap.addEventListener("mousedown", (e) => { if (e.target === wrap) wrap.remove(); });

    wrap.querySelector("#fs-delete").onclick = () => {
      SB.confirm("Delete this image? The file is kept in backup history and you will be warned if the note still points to it.", async () => {
        try {
          const out = await SB.api.post("/api/image/delete", { path: current.path, filename: path.split("/").pop() });
          SB.toast(out.warning ? out.message : "Deleted; the file is kept in backup history.", out.warning ? "err" : "");
          wrap.remove();
          reload();
        } catch (e) { SB.toast(e.message, "err"); }
      });
    };

    wrap.querySelector("#fs-crop").onclick = () => startCrop(wrap, path, src);
  }

  function startCrop(wrap, path, src) {
    const stage = wrap.querySelector(".fs-stage");
    const img = wrap.querySelector("#fs-img");
    stage.style.cursor = "crosshair";
    let x0 = 0, y0 = 0, x1 = 0, y1 = 0, drawing = false;
    let box = document.createElement("div");
    box.className = "crop-box";
    stage.appendChild(box);

    const toImgCoords = (e) => {
      const r = img.getBoundingClientRect();
      const sx = img.naturalWidth / r.width, sy = img.naturalHeight / r.height;
      return {
        x: Math.max(0, Math.min(img.naturalWidth, (e.clientX - r.left) * sx)),
        y: Math.max(0, Math.min(img.naturalHeight, (e.clientY - r.top) * sy)),
        r,
      };
    };
    const onDown = (e) => {
      const c = toImgCoords(e);
      x0 = c.x; y0 = c.y; drawing = true;
    };
    const onMove = (e) => {
      if (!drawing) return;
      const c = toImgCoords(e);
      x1 = c.x; y1 = c.y;
      const sr = stage.getBoundingClientRect();
      const ir = img.getBoundingClientRect();
      const scale = ir.width / img.naturalWidth;
      box.style.left = (ir.left - sr.left + Math.min(x0, x1) * scale) + "px";
      box.style.top = (ir.top - sr.top + Math.min(y0, y1) * scale) + "px";
      box.style.width = (Math.abs(x1 - x0) * scale) + "px";
      box.style.height = (Math.abs(y1 - y0) * scale) + "px";
    };
    const onUp = () => {
      if (!drawing) return;
      drawing = false;
      const w = Math.round(Math.abs(x1 - x0)), h = Math.round(Math.abs(y1 - y0));
      if (w < 5 || h < 5) return;
      const rect = { x: Math.round(Math.min(x0, x1)), y: Math.round(Math.min(y0, y1)), w, h };
      SB.modal("Crop is saved as a new image",
        "<p>Rectangle " + rect.w + " × " + rect.h + " px. What should happen to the original?</p>", [
        { label: "Cancel" },
        { label: "Keep both", onclick: async () => finishCrop("keep_both") },
        { label: "Replace the original (old one is backed up first)", primary: true,
          onclick: async () => finishCrop("replace") },
      ]);
      async function finishCrop(mode) {
        try {
          const out = await SB.api.post("/api/image/crop", {
            path: current.path, filename: path.split("/").pop(), rect, mode,
          });
          SB.toast(mode === "replace"
            ? "Replaced; the original is backed up as " + out.original_backed_up_as
            : "New image saved: " + out.new_image);
          wrap.remove();
          reload();
        } catch (e) { SB.toast(e.message, "err"); }
      }
    };
    stage.onmousedown = onDown;
    stage.onmousemove = onMove;
    stage.onmouseup = onUp;
  }

  /* resize handles in the viewer */
  document.addEventListener("click", (e) => {
    const img = e.target.closest("img.md-img");
    if (!img || editMode) return;
    if (e.altKey) {
      const widths = ["40%", "60%", "80%", "100%"];
      const cur = img.style.width || "100%";
      const next = widths[(widths.indexOf(cur) + 1) % widths.length];
      img.style.width = next;
      localStorage.setItem("imgsize:" + current.path + ":" + img.dataset.path, next);
      SB.toast("Image width " + next + " (Alt+click to change).");
    }
  });
})();
