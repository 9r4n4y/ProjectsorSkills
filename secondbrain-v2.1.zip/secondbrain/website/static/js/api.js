/* SecondBrain v2.1 frontend helpers (api.js): fetch wrapper, state, icons,
 * toasts, modals, tag chips, theme, and the two typeaheads:
 *  - tagSuggest  (tags + folders) for search filters and tag inputs;
 *  - noteSuggest (NOTES ONLY) for connecting notes and linking notes —
 *    typing finds real notes, never tags or folder names.
 * Neutral brutalist styling lives in style.css. */
(function () {
  "use strict";

  const SB = (window.SB = window.SB || {});

  /* ---------------- API ---------------- */

  async function get(url) {
    const r = await fetch(url);
    const j = await r.json();
    if (!r.ok || j.error) throw new Error(j.error || r.statusText);
    return j;
  }
  async function post(url, body) {
    const r = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body || {}),
    });
    const j = await r.json();
    if (!r.ok || j.error) throw new Error(j.error || r.statusText);
    return j;
  }
  SB.api = { get, post };

  /* ---------------- state ---------------- */

  SB.state = {
    theme: localStorage.getItem("sb-theme") === "dark" ? "dark" : "light",
    noteSize: parseInt(localStorage.getItem("sb-note-size") || "17", 10),
    route: "",
    lastSearch: null,
  };

  SB.setTheme = function (t) {
    if (t !== "dark") t = "light";
    SB.state.theme = t;
    localStorage.setItem("sb-theme", t);
    document.body.className = "theme-" + t;
    const mc = document.querySelector('meta[name="theme-color"]');
    if (mc) mc.setAttribute("content", t === "dark" ? "#101010" : "#f4f1ea");
    document.dispatchEvent(new CustomEvent("sb-theme"));
  };
  SB.setNoteSize = function (n) {
    SB.state.noteSize = n;
    localStorage.setItem("sb-note-size", n);
    document.documentElement.style.setProperty("--note-size", n + "px");
  };

  /* ---------------- auto-https ----------------
   * The user never types https:// — domain.com is enough everywhere. */
  SB.normalizeUrl = function (url) {
    const u = (url || "").trim();
    if (!u) return u;
    if (/^(https?:\/\/|mailto:|ftp:\/\/)/i.test(u)) return u;
    return "https://" + u;
  };
  SB.isProbablyUrl = function (u) {
    return /^[\w-]+(\.[\w-]+)+([\/?#].*)?$/i.test((u || "").trim());
  };

  /* ---------------- icons (16px line icons) ---------------- */

  const I = {
    search: '<circle cx="7" cy="7" r="4.5"/><path d="M10.5 10.5 L14 14"/>',
    home: '<path d="M2.5 7.5 L8 2.5 L13.5 7.5"/><path d="M4 7v6h8V7"/>',
    note: '<path d="M4 2.5h6.5L13 5v8.5H4z"/><path d="M10 2.5V5h3M6 8h5M6 10.5h5"/>',
    tag: '<path d="M8.5 2.5H13.5V7.5L7.5 13.5L2.5 8.5z"/><circle cx="10.8" cy="5.2" r="1"/>',
    folder: '<path d="M2.5 4.5v8h11v-6.5H8L6.5 4.5z"/>',
    folderopen: '<path d="M2.5 12.5v-8h4l1.5 1.5h5v1.5"/><path d="M2.5 12.5l1.8-5h10.2l-1.8 5z"/>',
    graph: '<circle cx="4" cy="4" r="1.8"/><circle cx="12" cy="6" r="1.8"/><circle cx="7" cy="12" r="1.8"/><path d="M5.5 5l4.8 .8M11 7.5L8 10.6M5.7 4.8L6.4 10.4"/>',
    health: '<path d="M2.5 8.5h2.5l1.5-3.5 2 6 1.5-2.5h3.5"/><path d="M8 14A6 6 0 1 1 14 8"/>',
    backup: '<rect x="3" y="3" width="10" height="4" rx="0"/><rect x="3" y="9" width="10" height="4" rx="0"/><circle cx="5" cy="5" r=".4"/><circle cx="5" cy="11" r=".4"/>',
    edit: '<path d="M3 13l.8-3L10.5 3.3a1.4 1.4 0 0 1 2 2L5.8 12 3 13z"/>',
    copy: '<rect x="5.5" y="5.5" width="8" height="8" rx="0"/><path d="M10.5 5.5v-2a1 1 0 0 0-1-1h-6a1 1 0 0 0-1 1v6a1 1 0 0 0 1 1h2"/>',
    print: '<path d="M4.5 6V2.5h7V6M4.5 11h-2V6h11v5h-2M4.5 9.5h7V14h-7z"/>',
    download: '<path d="M8 2.5v7M5 7l3 3 3-3M3 13.5h10"/>',
    crop: '<path d="M4 2v10h10M2 4h10v10"/>',
    trash: '<path d="M3.5 4.5h9M6.5 4.5v-2h3v2M5 4.5l.6 9h4.8l.6-9"/>',
    link: '<path d="M6.5 9.5l3-3M5 7L3.6 8.4a2.5 2.5 0 0 0 3.5 3.5L8.5 10.5M7.5 5.5L9 4a2.5 2.5 0 0 1 3.5 3.5L11 9"/>',
    plus: '<path d="M8 3v10M3 8h10"/>',
    pin: '<path d="M9.4 2.2l4.4 4.4-1.2 1.2-.9-.3-2.5 2.5.3 2.1-1.1 1.1-2.4-2.4L3 14l-1-1 3.2-3.4L2.8 7.2l1.1-1.1 2.1.3 2.5-2.5-.3-.9z" stroke-linejoin="round"/>',
    pinfilled: '<path fill="currentColor" stroke="none" d="M9.4 2.2l4.4 4.4-1.2 1.2-.9-.3-2.5 2.5.3 2.1-1.1 1.1-2.4-2.4L3 14l-1-1 3.2-3.4L2.8 7.2l1.1-1.1 2.1.3 2.5-2.5-.3-.9z"/>',
    check: '<path d="M3 8.5l3.5 3.5L13 5"/>',
    x: '<path d="M4 4l8 8M12 4l-8 8"/>',
    gear: '<circle cx="8" cy="8" r="2.2"/><path d="M8 2v2M8 12v2M2 8h2M12 8h2M3.8 3.8l1.4 1.4M10.8 10.8l1.4 1.4M12.2 3.8l-1.4 1.4M5.2 10.8l-1.4 1.4"/>',
    eye: '<path d="M1.8 8S4 4 8 4s6.2 4 6.2 4S12 12 8 12 1.8 8 1.8 8z"/><circle cx="8" cy="8" r="1.8"/>',
    undo: '<path d="M3 6h6.5a3.5 3.5 0 1 1 0 7H6"/><path d="M5.5 3.5L3 6l2.5 2.5"/>',
    chev: '<path d="M6 4l4 4-4 4"/>',
    chevdown: '<path d="M4 6l4 4 4-4"/>',
    back: '<path d="M10.5 3.5L6 8l4.5 4.5"/>',
    img: '<rect x="2.5" y="3" width="11" height="10" rx="0"/><circle cx="5.8" cy="6.2" r="1.1"/><path d="M3 11l3.5-3 2.5 2 2-1.5 3 2.5"/>',
    table: '<rect x="2.5" y="3" width="11" height="10" rx="0"/><path d="M2.5 6.5h11M2.5 10h11M7 3v10M11 3v10"/>',
    find: '<circle cx="7" cy="7" r="4.5"/><path d="M10.5 10.5 L14 14"/><path d="M5 7h4M7 5v4"/>',
    branch: '<circle cx="4.5" cy="3.8" r="1.6"/><circle cx="4.5" cy="12.2" r="1.6"/><circle cx="11.5" cy="8" r="1.6"/><path d="M4.5 5.4v5.2M6 4.3c3 0 4 1.2 4.2 2.4M6 11.7c3 0 4-1.2 4.2-2.4"/>',
    file: '<path d="M4 2.5h6.5L13 5v8.5H4z"/><path d="M10 2.5V5h3"/>',
    help: '<circle cx="8" cy="8" r="6"/><path d="M6.2 6.2c0-1 .8-1.8 1.8-1.8s1.8.7 1.8 1.6c0 1.3-1.8 1.4-1.8 2.7"/><circle cx="8" cy="11.4" r=".5" fill="currentColor"/>',
    bold: '<path d="M5.5 3h3.2a2.4 2.4 0 0 1 0 4.8H5.5zM5.5 7.8h3.7a2.4 2.4 0 0 1 0 4.8H5.5z"/>',
    italic: '<path d="M6.5 3h5M4.5 13h5M9.5 3l-3 10"/>',
    code: '<path d="M5.5 5L3 8l2.5 3M10.5 5L13 8l-2.5 3"/>',
    quote: '<path d="M3.5 6.5h4M3.5 9.5h4M11.5 6.5h1M11.5 9.5h1"/><path d="M10.5 4.5h2.5v7H10.5z"/>',
    list: '<path d="M5.5 4.5h8M5.5 8h8M5.5 11.5h8"/><circle cx="3" cy="4.5" r=".7" fill="currentColor"/><circle cx="3" cy="8" r=".7" fill="currentColor"/><circle cx="3" cy="11.5" r=".7" fill="currentColor"/>',
    task: '<rect x="2.5" y="2.5" width="11" height="11" rx="0"/><path d="M5.5 8l2 2 3.5-4"/>',
    heading: '<path d="M3.5 3v10M12.5 3v10M3.5 8h9"/>',
    hrule: '<path d="M2.5 8h11"/><path d="M4 5h8M4 11h8" opacity=".35"/>',
    math: '<path d="M4 12L8 8 4 4M9 6.5h4M11 4.5v4.5"/>',
    footnote: '<path d="M3.5 12.5h9M5 3.5v6M5 3.5c2 0 3 .7 3 2M11 3.5v6M11 3.5c-2 0-3 .7-3 2"/>',
    sun: '<circle cx="8" cy="8" r="3.2"/><path d="M8 1.5v2M8 12.5v2M1.5 8h2M12.5 8h2M3.4 3.4l1.4 1.4M11.2 11.2l1.4 1.4M12.6 3.4l-1.4 1.4M4.8 11.2l-1.4 1.4"/>',
    moon: '<path d="M13 9.5A5.5 5.5 0 1 1 6.5 3 4.5 4.5 0 0 0 13 9.5z"/>',
  };

  SB.icon = function (name, size) {
    return '<svg class="icon" width="' + (size || 16) + '" height="' + (size || 16) +
      '" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">' +
      (I[name] || "") + "</svg>";
  };

  /* ---------------- toasts + modal ---------------- */

  SB.toast = function (msg, kind) {
    let t = document.querySelector(".toast");
    if (!t) {
      t = document.createElement("div");
      t.className = "toast";
      document.body.appendChild(t);
    }
    t.textContent = msg;
    t.className = "toast show " + (kind || "");
    clearTimeout(t._h);
    t._h = setTimeout(() => t.classList.remove("show"), 3200);
  };

  SB.modal = function (title, bodyHTML, buttons) {
    closeModal();
    const wrap = document.createElement("div");
    wrap.className = "modal-wrap";
    wrap.innerHTML =
      '<div class="modal"><div class="modal-head"><span>' + SB.esc(title) +
      '</span><button class="modal-x" aria-label="Close">' + SB.icon("x") + "</button></div>" +
      '<div class="modal-body">' + bodyHTML + "</div>" +
      '<div class="modal-foot"></div></div>';
    const foot = wrap.querySelector(".modal-foot");
    (buttons || []).forEach((b) => {
      const el = document.createElement("button");
      el.className = "btn" + (b.primary ? " primary" : "") + (b.brand ? " accent" : "") + (b.danger ? " danger" : "");
      el.textContent = b.label;
      el.onclick = () => {
        const keep = b.onclick && b.onclick(wrap) === false;
        if (!keep) closeModal();
      };
      foot.appendChild(el);
    });
    wrap.querySelector(".modal-x").onclick = closeModal;
    wrap.addEventListener("mousedown", (e) => {
      if (e.target === wrap) closeModal();
    });
    document.body.appendChild(wrap);
    return wrap;
  };
  function closeModal() {
    document.querySelectorAll(".modal-wrap").forEach((m) => m.remove());
  }
  SB.closeModal = closeModal;

  SB.confirm = function (text, onYes) {
    SB.modal("Confirm", "<p>" + SB.esc(text) + "</p>", [
      { label: "Cancel" },
      { label: "Yes, do it", primary: true, onclick: onYes },
    ]);
  };

  /* ---------------- misc ---------------- */

  SB.esc = function (s) {
    return (s == null ? "" : "" + s).replace(/&/g, "&amp;").replace(/</g, "&lt;")
      .replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#39;");
  };
  SB.debounce = function (fn, ms) {
    let h;
    return function () {
      clearTimeout(h);
      const a = arguments, self = this;
      h = setTimeout(() => fn.apply(self, a), ms);
    };
  };

  /* Tags are neutral mono chips (no per-major rainbow colors any more). */
  SB.chip = function (tag, extra, unapproved) {
    return '<a class="chip ' + (extra || "") + (unapproved ? " unapproved" : "") +
      '" href="#/search?tags=' + encodeURIComponent(tag) + '" title="' +
      (unapproved ? "not in _tags.md yet — click to search" : tag) + '">' +
      (unapproved ? '<span class="unapproved-dot"></span>' : "") +
      SB.esc(tag) + "</a>";
  };

  SB.fmtDate = function (d) {
    return d ? d : "—";
  };

  /* ---------------- shared dropdown machinery ---------------- */

  function attachDropdown(input) {
    let box = input.parentElement.querySelector(".suggest");
    if (!box) {
      box = document.createElement("div");
      box.className = "suggest";
      box.style.display = "none";
      input.parentElement.appendChild(box);
    }
    return box;
  }

  function wireKeys(input, box, onPick, enterType) {
    input.addEventListener("keydown", (e) => {
      if (e.key === "Enter") {
        e.preventDefault();
        const first = box.querySelector(".sug");
        if (first) first.click();
        else if (input.value.trim()) onPick(enterType, input.value.trim());
        input.value = "";
        box.style.display = "none";
      }
    });
    document.addEventListener("click", (e) => {
      if (!input.parentElement.contains(e.target)) box.style.display = "none";
    });
  }

  /* tagSuggest: tags and folders ONLY (used by search filters, tag inputs,
   * new-note tags). Enter with no match adds the typed text as a tag.
   * Note suggestions never appear here — that is noteSuggest's job. */
  SB.tagSuggest = function (input, onSelect, opts) {
    const o = opts || {};
    const box = attachDropdown(input);
    const render = (all) => {
      const items = all.filter((r) => r.type !== "note");
      if (!items.length) {
        box.innerHTML = '<div class="sug-empty dim">' +
          "No tag or folder matches — Enter uses what you typed.</div>";
        box.style.display = "";
        return;
      }
      box.innerHTML = items.map((r) =>
        '<button class="sug" data-type="' + r.type + '" data-name="' + SB.esc(r.name) + '">' +
        SB.icon(r.type === "tag" ? "tag" : "folder") + " " + SB.esc(r.name) +
        '<span class="dim">' + (r.type === "tag" ? " · tag" : " · folder") +
        " · " + (r.count != null ? r.count + " notes" : (r.folder || "")) + "</span></button>").join("");
      box.querySelectorAll(".sug").forEach((b) => {
        b.onclick = () => {
          onSelect(b.dataset.type, b.dataset.name);
          input.value = "";
          box.style.display = "none";
        };
      });
      box.style.display = "";
    };
    input.addEventListener("input", SB.debounce(async () => {
      const q = input.value.trim();
      if (!q) { box.style.display = "none"; return; }
      try {
        const res = await SB.api.get("/api/suggest?q=" + encodeURIComponent(q) +
          "&type=" + (o.type || "all"));
        render(res.suggestions);
      } catch (e) { /* offline: keep silent */ }
    }, 110));
    wireKeys(input, box, onSelect, o.enterType || "tag");
  };

  /* noteSuggest: NOTES ONLY. Typing finds real notes to connect or link.
   * The dropdown shows the note title + its folder; Enter picks the best
   * match. Free text that matches no note is rejected with a message.
   * opts.keepValue: leave the picked name in the input (Link-note dialog
   * reads it when Insert is pressed). */
  SB.noteSuggest = function (input, onSelect, opts) {
    const o = opts || {};
    const box = attachDropdown(input);
    const render = (items) => {
      if (!items.length) {
        box.innerHTML = '<div class="sug-empty dim">No note matches "' +
          SB.esc(input.value.trim()) + '"</div>';
        box.style.display = "";
        return;
      }
      box.innerHTML = items.map((r) =>
        '<button class="sug" data-name="' + SB.esc(r.name) + '">' +
        SB.icon("note") + " " + SB.esc(r.name) +
        '<span class="dim"> · ' + SB.esc(r.folder || "database") + "</span></button>").join("");
      box.querySelectorAll(".sug").forEach((b) => {
        b.onclick = () => {
          onSelect(b.dataset.name);
          if (!o.keepValue) input.value = "";
          box.style.display = "none";
        };
      });
      box.style.display = "";
    };
    input.addEventListener("input", SB.debounce(async () => {
      const q = input.value.trim();
      if (!q) { box.style.display = "none"; return; }
      try {
        const res = await SB.api.get("/api/suggest?q=" + encodeURIComponent(q) +
          "&type=note");
        render(res.suggestions);
      } catch (e) { /* offline */ }
    }, 110));
    input.addEventListener("keydown", (e) => {
      if (e.key === "Enter") {
        e.preventDefault();
        const first = box.querySelector(".sug[data-name]");
        if (first) first.click();
        else SB.toast("No note matches that name.", "err");
      }
    });
    document.addEventListener("click", (e) => {
      if (!input.parentElement.contains(e.target)) box.style.display = "none";
    });
  };
})();
