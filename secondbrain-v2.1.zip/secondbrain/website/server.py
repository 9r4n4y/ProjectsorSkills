"""SecondBrain local website (spec 4, 9, 10, 11, 12).

A thin layer over the core engine: one search engine serves the website and
the MCP server, so results are identical. The website scans the Markdown
files through the index and exposes a JSON API for everything the user can
do - search with modes and filters, reading, editing, tags, folders, images,
quick info, connections, references, metadata, logs and undo, health check,
saved searches and the backup tool.

Local only: the server listens on this computer by default (server_bind in
core/settings.json). Opening it to the home network is an explicit setting.

Run:  python3 website/server.py [--port 8765] [--no-browser] [--rebuild]
"""
from __future__ import annotations

import argparse
import base64
import json
import sys
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse, parse_qs, unquote

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from core import healthcheck, images, indexer, logger, paths, search, store  # noqa: E402
from core import tags as tags_mod  # noqa: E402

STATIC = Path(__file__).resolve().parent / "static"
MIME = {".html": "text/html", ".css": "text/css", ".js": "application/javascript",
        ".json": "application/json", ".png": "image/png", ".jpg": "image/jpeg",
        ".jpeg": "image/jpeg", ".gif": "image/gif", ".webp": "image/webp",
        ".svg": "image/svg+xml", ".woff": "font/woff", ".woff2": "font/woff2",
        ".ttf": "font/ttf", ".txt": "text/plain", ".map": "application/json"}


def jdump(obj) -> bytes:
    return json.dumps(obj, ensure_ascii=False).encode("utf-8")


def _body_line_offset(raw: str) -> int:
    """The 0-based line in the full file where the main body starts (the
    title and the quick-info block sit above it). The rendered blocks carry
    body-relative line numbers; adding this offset maps them to file lines
    for checklist ticking."""
    lines = raw.split("\n")
    i = 0
    if lines and lines[0].startswith("# "):
        i = 1
    while i < len(lines) and not lines[i].strip():
        i += 1
    if i < len(lines) and lines[i].strip() == ":::quick-info":
        i += 1
        while i < len(lines) and lines[i].strip() != ":::":
            i += 1
        i += 1  # the closing :::
    while i < len(lines) and not lines[i].strip():
        i += 1
    return i


def note_view(md_path: Path) -> dict:
    """Everything the note page needs: parsed blocks, panels, connected
    notes, references, tags and the raw text with its hash for safe
    editing."""
    rp = paths.rel(md_path)
    doc = store.parse_note(md_path.read_text(encoding="utf-8"), rp)
    idx = indexer.load_index()
    atts = []
    att_dir = md_path.parent / "attachments"
    if att_dir.exists():
        atts = sorted(p.name for p in att_dir.iterdir() if p.is_file())
    tags_file = md_path.parent / "tags.txt"
    note_tags = tags_mod.parse_tags_txt(tags_file.read_text(encoding="utf-8")) \
        if tags_file.exists() else []
    return {
        "path": rp,
        "folder": md_path.parent.parent.relative_to(paths.DATABASE).as_posix()
        if md_path.parent.parent != paths.DATABASE else "",
        "title": doc.title,
        "raw": doc.raw,
        "hash": store.text_sha256(doc.raw),
        "body_offset": _body_line_offset(doc.raw),
        "quick_info_raw": doc.quick_info_raw,
        "quick_info_rows": [{"label": r.label, "value": r.value, "group": r.group}
                            for r in doc.quick_info_rows],
        "headings": doc.headings,
        "body": doc.body,
        "connected": doc.connected,
        "linked_in_text": [{"target": t, "word": w} for t, w in doc.linked_in_text],
        "references": doc.references,
        "meta": doc.meta,
        "my_notes": doc.my_notes,
        "tags": note_tags,
        "attachments": atts,
        "pinned": doc.meta.get("pinned", "no").lower() == "yes",
    }


class Handler(BaseHTTPRequestHandler):
    server_version = "SecondBrain/1.0"

    # ------------------------------------------------------------ plumbing
    def log_message(self, fmt, *args):        # quiet
        pass

    def _json(self, obj, status=200):
        data = jdump(obj)
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(data)

    def _err(self, e: Exception, status=400):
        self._json({"error": str(e), "type": type(e).__name__}, status)

    def _body(self) -> dict:
        n = int(self.headers.get("Content-Length") or 0)
        if n <= 0:
            return {}
        raw = self.rfile.read(min(n, 64 * 1024 * 1024))
        return json.loads(raw.decode("utf-8"))

    def _file(self, p: Path, cache=False):
        if not p.exists() or not p.is_file():
            self._json({"error": "not found"}, 404)
            return
        data = p.read_bytes()
        self.send_response(200)
        self.send_header("Content-Type",
                         MIME.get(p.suffix.lower(), "application/octet-stream"))
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control",
                         "no-cache" if cache else "no-store")
        self.end_headers()
        self.wfile.write(data)

    # -------------------------------------------------------------- routes
    def do_GET(self):
        try:
            u = urlparse(self.path)
            route = unquote(u.path)
            q = {k: v for k, v in parse_qs(u.query).items()}
            one = lambda k, d="": (q.get(k, [d])[0] if q.get(k) else d)  # noqa: E731
            many = lambda k: q.get(k, [])[0].split(",") if q.get(k) else []  # noqa: E731

            if route == "/" or route == "/index.html":
                return self._file(STATIC / "index.html")
            if route.startswith("/static/"):
                rp = (STATIC / route.removeprefix("/static/")).resolve()
                if not str(rp).startswith(str(STATIC)):
                    return self._json({"error": "forbidden"}, 403)
                return self._file(rp, cache=True)
            if route.startswith("/files/"):
                # note attachments, addressed through the database
                rel = route.removeprefix("/files/")
                p = (paths.ROOT / rel).resolve()
                db = paths.DATABASE.resolve()
                if not str(p).startswith(str(db)):
                    return self._json({"error": "forbidden"}, 403)
                return self._file(p, cache=True)

            if route == "/thumb":
                # the image grid uses thumbnails; the full file loads only
                # in full screen (spec 17)
                rel = one("path")
                p = (paths.ROOT / rel).resolve()
                db = paths.DATABASE.resolve()
                if not str(p).startswith(str(db)) or not p.exists():
                    return self._json({"error": "not found"}, 404)
                try:
                    tp = images.thumbnail(p, int(one("w", "480") or 480))
                except Exception:      # noqa: BLE001 - a broken image is not fatal
                    tp = p
                return self._file(tp, cache=True)

            if route == "/api/state":
                idx = indexer.load_index()
                recent = sorted(idx["files"].items(),
                                key=lambda kv: kv[1]["updated"], reverse=True)[:8]
                settings = store.load_settings()
                return self._json({
                    "notes": idx["N"],
                    "recent": [{"path": rp, "title": e["title"], "folder": e["folder"],
                                "updated": e["updated"]} for rp, e in recent],
                    "pinned": [{"path": rp, "title": e["title"], "folder": e["folder"]}
                               for rp, e in idx["files"].items() if e["pinned"]],
                    "saved_searches": settings.get("saved_searches", []),
                    "themes": ["light", "dark", "coffee", "orange"],
                    "port": settings.get("server_port"),
                    "bind": settings.get("server_bind"),
                })

            if route == "/api/search":
                idx = indexer.load_index()
                res = search.search(
                    idx=idx, q=one("q"),
                    mode=one("mode", "rank"),
                    tags_sel=many("tags"),
                    folders=many("folders"),
                    folder_only=one("folder_only") == "1",
                    scope=many("scope") or ["everything"],
                    tag_mode=one("tag_mode", "rank"),
                    kw_mode=one("kw_mode", "rank"),
                    include_connected=one("include_connected") == "1",
                    status=one("status") or None,
                    date_from=one("date_from") or None,
                    date_to=one("date_to") or None,
                    limit_to=[x for x in many("limit_to") if x],
                    offset=int(one("offset", "0") or 0),
                )
                return self._json(res)

            if route == "/api/suggest":
                idx = indexer.load_index()
                return self._json(suggest(idx, one("q"), one("type", "all")))

            if route == "/api/tags":
                ext = tags_mod.extract_all_notes_tags()
                mt = tags_mod.load_master()
                return self._json({
                    "rows": ext["rows"],
                    "tags": ext["tags"],
                    "counts": ext["counts"],
                    "majors": sorted({v["major"] for v in mt.approved.values()}
                                     | set(ext["majors"])),
                    "approved": mt.all_tags(),
                    "unapproved": ext["unapproved"],
                    "proposed": ext["proposed"],
                    "near_duplicates": ext["near_duplicates"],
                    "used_once": ext["used_once"],
                    "tag_synonyms": {v["tag"]: v["synonyms"]
                                     for v in mt.approved.values()},
                    "general_synonyms": mt.general_synonyms,
                })

            if route == "/api/folders":
                return self._json({"tree": store.folder_tree(),
                                   "subjects": store.list_subjects()})

            if route == "/api/folder/browse":
                return self._json(store.browse_folder(one("path")))

            if route == "/api/connections":
                # Everything the connected-notes panel needs: each target
                # with its own tags and folder for the branch view.
                p = store.note_md_path(one("path"))
                if not p.exists():
                    found = store.note_exists(one("path"))
                    p = found or p
                doc = store.parse_note(p.read_text(encoding="utf-8"), paths.rel(p))
                idx = indexer.load_index()
                out = []
                for t in doc.connected:
                    tgt = store.note_exists(t)
                    if tgt:
                        e = idx["files"].get(paths.rel(tgt), {})
                        td = store.parse_note(tgt.read_text(encoding="utf-8"),
                                              paths.rel(tgt))
                        out.append({"name": tgt.stem, "path": paths.rel(tgt),
                                    "folder": e.get("folder", ""),
                                    "tags": e.get("tags", []),
                                    "updated": e.get("updated", ""),
                                    "connected": td.connected,
                                    "exists": True})
                    else:
                        out.append({"name": t, "exists": False})
                return self._json({"note": paths.rel(p), "connections": out})

            if route == "/api/graph":
                idx = indexer.load_index()
                nodes = [{"id": rp, "title": e["title"], "folder": e["folder"],
                          "tags": e["tags"][:1]} for rp, e in idx["files"].items()]
                edges = sorted({tuple(sorted((a, b)))
                                for a, ts in idx["graph"].items() for b in ts})
                return self._json({"nodes": nodes, "edges": [list(e) for e in edges]})

            if route == "/api/note":
                p = store.note_md_path(one("path"))
                if not p.exists():
                    # allow lookup by note name
                    found = store.note_exists(one("path"))
                    if not found:
                        return self._json({"error": f"Note {one('path')!r} not found."}, 404)
                    p = found
                return self._json(note_view(p))

            if route == "/api/export":
                p = store.note_md_path(one("path"))
                if not p.exists():
                    found = store.note_exists(one("path"))
                    if not found:
                        return self._json({"error": f"Note {one('path')!r} not found."}, 404)
                    p = found
                text = store.export_metadata(paths.rel(p))
                data = text.encode("utf-8")
                self.send_response(200)
                self.send_header("Content-Type", "text/plain; charset=utf-8")
                self.send_header("Content-Disposition",
                                 f'attachment; filename="{p.stem}.metadata.txt"')
                self.send_header("Content-Length", str(len(data)))
                self.end_headers()
                return self.wfile.write(data)

            if route == "/api/health":
                return self._json(healthcheck.health_check())

            if route == "/api/logs":
                return self._json({"logs": logger.list_logs(int(one("limit", "100")))})

            if route == "/api/log":
                return self._json({"name": one("name"),
                                   "text": logger.read_log(one("name"))})

            if route == "/api/master_tags":
                return self._json({
                    "text": (paths.ROOT / "_tags.md").read_text(encoding="utf-8")})

            return self._json({"error": f"Unknown route {route}"}, 404)
        except Exception as e:                     # noqa: BLE001
            return self._err(e, 500)

    do_HEAD = do_GET

    def do_POST(self):
        try:
            u = urlparse(self.path)
            route = unquote(u.path)
            b = self._body()
            who = b.get("who", "user")

            def rp(key="path") -> str:
                """Resolve a note given as a rel path OR a bare note name,
                so every route accepts exactly what /api/note accepts."""
                raw = b.get(key, "")
                p = store.note_md_path(raw)
                if p.exists():
                    return paths.rel(p)
                found = store.note_exists(raw)
                if found:
                    return paths.rel(found)
                return raw

            if route == "/api/note/create":
                return self._json(store.create_note(
                    b.get("folder", ""), b["name"], b.get("tags") or [],
                    b.get("text"), b.get("quick_info"), who, b.get("reason", "")))

            if route == "/api/note/save":
                return self._json(store.save_note_text(
                    rp(), b["text"], b.get("base_hash"), who,
                    b.get("force", False), b.get("reason", "")))

            if route == "/api/note/move":
                return self._json(store.move_note(
                    rp(), b.get("folder", ""), b.get("name"), who))

            if route == "/api/note/append_my_notes":
                return self._json(store.append_to_my_notes(
                    rp(), b["text"], who, b.get("reason", "")))

            if route == "/api/note/delete":
                return self._json(store.delete_note(rp(), who))

            if route == "/api/note/toggle_task":
                return self._json(store.toggle_task(
                    rp(), int(b["index"]), who))

            if route == "/api/fix/broken_link":
                return self._json(store.remove_broken_link(
                    rp(), b["link"], who))

            if route == "/api/fix/delete_file":
                p = (paths.ROOT / b["path"]).resolve()
                allowed = {paths.DATABASE.resolve(), paths.INBOX.resolve()}
                if not any(str(p).startswith(str(a)) for a in allowed):
                    raise ValueError("Only files inside database/ or inbox/ can "
                                     "be removed from the website.")
                if not p.is_file():
                    raise FileNotFoundError("File not found.")
                old = p.read_text(encoding="utf-8")
                p.unlink()
                logger.new_log(who, f"Deleted file {p.name}",
                               f"- Removed `{paths.rel(p)}` (health fix).",
                               undo={"title": f"Delete file {p.name}", "steps": [
                                   {"op": "write", "path": paths.rel(p), "before": old}]})
                return self._json({"ok": True})

            if route == "/api/tags/master/add":
                return self._json(store.add_master_tags(
                    b.get("tags") or [], who, b.get("reason", "")))

            if route == "/api/folder/create":
                return self._json(store.create_folder(
                    b.get("parent", ""), b["name"], who, b.get("subject_md")))

            if route == "/api/folder/rename":
                return self._json(store.rename_folder(b["path"], b["name"], who))

            if route == "/api/folder/move":
                return self._json(store.move_folder(
                    b["path"], b.get("parent", ""), who))

            if route == "/api/folder/delete":
                return self._json(store.delete_folder(b["path"], who))

            if route == "/api/subject/save":
                p = paths.safe_join(paths.DATABASE, *b["path"].split("/")) \
                    if b.get("path") else paths.DATABASE
                text = (b.get("text") or "").strip()
                target = p / "_subject.md"
                if not text:
                    if target.exists():
                        old = target.read_text(encoding="utf-8")
                        target.unlink()
                        logger.new_log(who, f"Removed _subject.md of {p.name}",
                                       f"- Removed `{paths.rel(target)}`.",
                                       undo={"title": "Remove _subject.md", "steps": [
                                           {"op": "write", "path": paths.rel(target), "before": old}]})
                    return self._json({"ok": True})
                old_subject = target.read_text(encoding="utf-8") if target.exists() else None
                store.atomic_write(target, text.rstrip() + "\n")
                logger.new_log(who, f"Edited _subject.md of {p.name}",
                               f"- File: `{paths.rel(target)}`",
                               undo={"title": "Edit _subject.md", "steps": [
                                   {"op": "write", "path": paths.rel(target),
                                    "before": old_subject}]})
                return self._json({"ok": True})

            if route == "/api/tags/edit":
                return self._json(store.edit_tags(
                    rp(), b.get("add"), b.get("remove"), who))

            if route == "/api/tags/rename":
                return self._json(store.rename_tag(
                    b["from"], b["to"], who, run=b.get("run", False)))

            if route == "/api/tags/merge":
                return self._json(store.merge_tags(
                    b["from"], b["into"], who, run=b.get("run", False)))

            if route == "/api/tags/remove":
                return self._json(store.remove_tag_everywhere(
                    b["tag"], who, run=b.get("run", False)))

            if route == "/api/tags/master":
                return self._json(store.edit_master_tags(b["text"], who))

            if route == "/api/quick_info":
                return self._json(store.set_quick_info(rp(), b.get("text"), who))

            if route == "/api/metadata":
                return self._json(store.set_metadata(rp(), b.get("meta", {}), who))

            if route == "/api/pin":
                return self._json(store.toggle_pin(rp(), who))

            if route == "/api/connections":
                return self._json(store.edit_connections(
                    rp(), b.get("add"), b.get("remove"),
                    b.get("edit_link"), who))

            if route == "/api/references":
                return self._json(store.edit_references(
                    rp(), b.get("add"), b.get("remove_url"), who))

            if route == "/api/links":
                return self._json(store.edit_links(
                    rp(), b["word"], b.get("target"),
                    b.get("make_note", True), who))

            if route == "/api/image/add":
                data = base64.b64decode(b["data_base64"])
                return self._json(images.add_attachment(
                    rp(), b["filename"], data, who))

            if route == "/api/image/crop":
                return self._json(images.crop_image(
                    rp(), b["filename"], b["rect"], b.get("mode", "keep_both"), who))

            if route == "/api/image/delete":
                return self._json(images.delete_image(rp(), b["filename"], who))

            if route == "/api/undo":
                return self._json({"log": logger.apply_undo(b["log"], who)})

            if route == "/api/saved_searches/save":
                return self._json(store.save_search(b["name"], b["params"], who))

            if route == "/api/saved_searches/delete":
                return self._json(store.delete_saved_search(b["name"]))

            if route == "/api/backup/preview":
                from backup import backup as bk
                target = Path(b["to"]).expanduser().resolve()
                if b.get("direction", "backup") == "backup":
                    src_m, dst_m = bk.manifest(paths.ROOT, b.get("scope", "whole")), \
                        bk.manifest(target, b.get("scope", "whole"))
                else:
                    src_m, dst_m = bk.manifest(target, b.get("scope", "whole")), \
                        bk.manifest(paths.ROOT, b.get("scope", "whole"))
                return self._json({"compare": bk.compare(src_m, dst_m),
                                   "preview": bk.preview(bk.compare(src_m, dst_m))})

            if route == "/api/backup/run":
                from backup import backup as bk
                rep = bk.run(b.get("direction", "backup"),
                             Path(b["to"]).expanduser().resolve(),
                             b.get("scope", "whole"), approve=True,
                             keep_versions=int(b.get("keep", 10)),
                             log_fn=lambda m: None)
                return self._json(rep)

            if route == "/api/backup/verify":
                from backup import backup as bk
                target = Path(b["to"]).expanduser().resolve()
                rep = bk.verify_detailed(target, b.get("scope", "whole"),
                                         log_fn=lambda m: None)
                return self._json(rep)

            if route == "/api/index/rebuild":
                idx = indexer.rebuild_index()
                return self._json({"ok": True, "notes": idx["N"]})

            if route == "/api/settings":
                s = store.load_settings()
                for k, v in (b.get("settings") or {}).items():
                    s[k] = v
                store.save_settings(s)
                return self._json({"ok": True, "settings": s})

            return self._json({"error": f"Unknown route {route}"}, 404)
        except Exception as e:                     # noqa: BLE001
            return self._err(e, 400)


def suggest(idx: dict, q: str, kind: str) -> dict:
    """Type-ahead over existing NOTES, tags and folders. Only things that
    really exist can be chosen; the closest names are offered.
    kind="note" returns notes only (title + folder + updated) — used by
    the connected-notes picker and the Link-note editor, so typing finds
    real notes to connect, never tags or folder names.
    Tags are independent (v2): one flat list of every tag in use, counts."""
    qn = (q or "").strip().lower().replace(" ", "-")
    out = []
    if kind in ("all", "note"):
        ql = (q or "").strip().lower()
        for rp, e in idx["files"].items():
            tl = e["title"].lower()
            starts = tl.startswith(ql)
            contains = ql in tl if ql else True
            if not ql or starts or contains:
                out.append({"type": "note", "name": e["title"],
                            "folder": e["folder"] or "database",
                            "updated": e.get("updated", ""),
                            "starts": starts})
        # also match on folder + tags so a word like "recipes" still finds
        # the notes inside the Recipes folder
        if ql:
            for rp, e in idx["files"].items():
                hit = ql in e["folder"].lower() or \
                    any(ql in t.lower() for t in e["tags"])
                if hit and not any(o["type"] == "note" and o["name"] == e["title"]
                                   for o in out):
                    out.append({"type": "note", "name": e["title"],
                                "folder": e["folder"] or "database",
                                "updated": e.get("updated", ""),
                                "starts": False})
        out.sort(key=lambda r: (not r["starts"], r["name"].lower()))
        if kind == "note":
            return {"suggestions": out[:12]}
    if kind in ("all", "tag"):
        ext = tags_mod.extract_all_notes_tags()
        for t in ext["tags"]:
            tl = t.lower()
            starts, contains = tl.startswith(qn), (qn in tl) if qn else True
            if not qn or starts or contains:
                out.append({"type": "tag", "name": t,
                            "major": tags_mod.major_of(t),
                            "approved": t not in ext["unapproved"],
                            "count": ext["counts"].get(t, 0),
                            "starts": starts})
    if kind in ("all", "folder"):
        for s in store.list_subjects():
            sl = s["name"].lower()
            starts, contains = sl.startswith(qn), (qn in sl) if qn else True
            if not qn or starts or contains:
                out.append({"type": "folder", "name": s["name"],
                            "parent": s["path"].rsplit("/", 1)[0]
                            if "/" in s["path"] else "database",
                            "count": note_count(s["path"]),
                            "starts": starts})
    out.sort(key=lambda r: (not r["starts"], r["type"] == "note" and 0 or 1,
                            r["name"].lower()))
    return {"suggestions": out[:12]}


def note_count(subject_rel: str) -> int:
    base = paths.DATABASE / subject_rel
    if not base.exists():
        return 0
    return sum(1 for md in base.rglob("*.md")
               if md.name != "_subject.md" and md.parent.name == md.stem)


def main():
    ap = argparse.ArgumentParser(description="SecondBrain local website")
    ap.add_argument("--port", type=int, default=None)
    ap.add_argument("--no-browser", action="store_true")
    ap.add_argument("--rebuild", action="store_true",
                    help="rebuild the index from the files, then start")
    args = ap.parse_args()

    settings = store.load_settings()
    if args.rebuild:
        idx = indexer.rebuild_index()
        print(f"Index rebuilt: {idx['N']} notes.")
    port = args.port or int(settings.get("server_port", 8765))
    bind = settings.get("server_bind", "127.0.0.1")

    server = ThreadingHTTPServer((bind, port), Handler)
    url = f"http://{'localhost' if bind == '127.0.0.1' else bind}:{port}/"
    print(f"SecondBrain website running at {url}  (local only, bind {bind})")
    print("Press Ctrl+C to stop.")
    if not args.no_browser and settings.get("open_browser_on_start", True):
        try:
            webbrowser.open(url)
        except Exception:
            pass
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nStopped.")


if __name__ == "__main__":
    main()
