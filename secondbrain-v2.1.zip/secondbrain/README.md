# SecondBrain — a universal personal notes system

## Quick explanation (read this first)

SecondBrain is a single-user notes system that keeps **all knowledge as plain
Markdown files in plain folders**. There is no database, no cloud and no
vendor lock-in — the files outlive any app. A **local website** reads those
files and presents them in a clean, searchable interface, an **AI librarian**
(MCP server) can search, read and file notes for you under strict safety
rules, and a **ranking search engine** finds notes by tags, keywords,
synonyms and links — no semantic model, no embeddings, fast enough to run
instantly on a personal collection.

Knowledge is organized in three ways at once: **folders** (each note has one
home, called its subject), **global tags** (many per note, all *independent
labels* — no sub-tag hierarchy in v2, searchable across all folders), and
**wiki links** (`[[File Name]]`, shown as Connected notes — no backlinks).

This is **v2.1** of the project. The big changes: a total **neo-brutalist
UI remaster** (strict grids, 2px ink borders, one orange accent, no
purple; mobile bottom tab bar for Android), **search everywhere** in the
top bar, connected-notes search that finds **notes only** (never tags or
folder names), **no graph page** (connected notes on each note page are
the reference list), **no hidden notes** (every note is always indexed
and searchable), a real **Back** button, a full **folder
browser**, auto-**https** everywhere (type `domain.com`), a fixed Markdown
**toolbar** (no accidental selections; the cursor always lands in the best
spot; select a word and tap a button), a visual **table editor**, one-click
**checklist ticking** in the rendered page, **find in note** that works in
edit *and* preview mode, **independent tags** with a synced global index,
**no verification status**, **no backlinks**, a health page with
**one-click fixes**, a **byte-identical backup** with per-file SHA-256
verification, and logs written only by **User** or **AI**, never reversed
automatically. See `FIXES.md` for the complete list with proof.

The project is one folder, `secondbrain/`, with 5 files and 8 folders at the
top level:

```
secondbrain/
├── README.md               this file
├── SKILL.md                the complete manual for the AI librarian
├── StructureOFnotes.md     the exact rulebook for how notes are written
├── _tags.md                the master tag vocabulary (approved, synonyms, proposed)
├── FIXES.md                the v2 change list with test proof
├── database/               every note lives here, as <Subject>/.../<Note Name>/
├── inbox/                  raw unsorted notes waiting to be filed
├── logs/                   one log file per change, never edited or deleted
├── core/                   the shared engine (parser, index, search, tags, checks)
├── mcp/                    the AI tool server (a thin layer over core)
├── website/                the local viewer and editor (a thin layer over core)
├── backup/                 the backup, sync and restore tool
└── scripts/                the automated test suites (see FIXES.md)
```

**How to start**

1.  `python3 website/server.py` — opens `http://localhost:8765` in your
    browser. Everything is on this computer; nothing leaves it.
2.  Look at the example notes under `database/`. Each note is a folder
    holding `<Note Name>.md`, `tags.txt` and an `attachments/` folder.
3.  Drop messy thoughts into `inbox/` and let the AI librarian file them,
    or create notes directly on the website ("New note").
4.  Back up with `python3 backup/backup.py --to /path/to/backup --yes`
    (the backup folder must live **outside** the project).
5.  To connect an AI assistant, point its MCP client at
    `mcp/server.py` — see "The AI tools" below.

Everything else on this page is the deep explanation.

---

## Purpose

SecondBrain exists to keep a person's knowledge in a form that is:

- **Minimal effort** — a note is a text file in a folder; nothing else is
  required.
- **Universally extensible** — any new subject, tag or note type can be
  added without changing the system. New subject = new folder. New tag =
  one line in `_tags.md`.
- **Searchable, taggable and connected** — the ranking engine orders notes
  by how well they match, the tag system is global, and wiki links tie
  notes together as Connected notes.
- **Durable** — plain UTF-8 Markdown with LF line endings, readable in any
  editor, on any operating system, forever.
- **Auditable** — every change, by you or by the AI, writes one log file in
  `logs/` naming **User** or **AI**. The AI can never overwrite your words
  and never invents facts. Nothing ever reverses itself automatically;
  undo happens only when you press Undo.
- **Recoverable** — the backup tool brings an old copy up to date without
  copying everything again, keeps every replaced file in a dated
  `.versions/` folder, and verifies every hash before it calls a run
  successful.

## The folder structure and every fixed file

The structure is strict on purpose: the health check reports anything that
is not on the allowed list, and the tools refuse to create anything outside
it (spec 16). Anything new needs your approval and an update to the
structure files.

### Top level — 5 files, 7 folders

| Path | What it is |
| --- | --- |
| `README.md` | this file |
| `SKILL.md` | the complete AI manual (vocabulary, rules, tools, examples) |
| `StructureOFnotes.md` | the exact note format rulebook |
| `_tags.md` | master tag vocabulary: approved tags, per-tag synonyms, general synonyms, proposed tags |
| `FIXES.md` | the v2 change list with test proof |
| `database/` | every note, as subject folders to any depth |
| `inbox/` | raw notes waiting for the AI librarian (plain `.md`/`.txt`) |
| `logs/` | `YYYY-MM-DD_HH-MM-SS_<title>.md`, one per change, append-only history |
| `core/` | the shared engine, listed below, plus `settings.json` and `.cache/` |
| `mcp/` | the MCP tool server |
| `website/` | the local website |
| `backup/` | the backup tool |
| `scripts/` | the automated test suites: `test_engine.py`, `test_website_api.py`, `test_mcp.py` |

### Inside `database/`

Subject folders nest to any depth (`Learning › Languages › Vocabulary`). A
subject folder may contain an optional `_subject.md` with two fields:

```
Purpose: coffee and tea
Template: Tasting Note
```

`Template` names a note whose body is used when creating notes here.
(There is no `Sensitivity` any more: v2.1 removed the hidden-notes
feature — every folder and every note is always visible, indexed and
searchable.)

Each note lives in its **own folder**, named exactly like the note:

```
database/Recipes/Quick Vegetable Pasta for Weeknights/
├── Quick Vegetable Pasta for Weeknights.md   the note itself
├── tags.txt                                  its tags, comma separated
└── attachments/                              images used by the note
```

File names are detailed and descriptive (they are the wiki links) and are
unique across the whole wiki, even ignoring capital letters.

### The fixed source files (each named here, as the structure requires)

**`core/` — the one engine shared by the website, the MCP server and the
backup tool:**

| File | Role |
| --- | --- |
| `__init__.py` | marks `core` as a Python package |
| `paths.py` | project layout, safe names, the allowed-structure check |
| `textutil.py` | normalization, tokenizer, stemmer, edit distance, typo buckets |
| `tags.py` | tag notation, `tags.txt`, the `_tags.md` master, the auto tag extractor |
| `parser.py` | the ONE note parser: quick info, sections, links, references, metadata |
| `store.py` | every write operation (create/edit/move, tags, connections, images, inbox filing) |
| `logger.py` | writes the log files and executes undo from them |
| `indexer.py` | the incremental index (only re-parses notes whose hash changed) |
| `search.py` | the ranking search pipeline (spec 3) |
| `healthcheck.py` | broken links, untagged notes, near-duplicate tags, stray files |
| `images.py` | attachments: add, crop (optional Pillow), delete with backup history |
| `test_ranking.py` | the fixed test set of queries with expected top results |
| `settings.json` | ranking weights, page size, defaults — tunable |
| `.cache/` | generated index, safe to delete; rebuilt from the files at any time |

**`website/` — the local site:**

| File | Role |
| --- | --- |
| `server.py` | local HTTP server: the JSON API + static files (standard library only) |
| `static/index.html` | the single-page app shell |
| `static/style.css` | the two themes (light/dark), layout, print stylesheet |
| `static/js/md.js` | the Markdown renderer (blocks carry their source lines) |
| `static/js/api.js` | fetch wrapper, icons, toasts, modals, tag chips, theme |
| `static/js/note.js` | note view + editor, image viewer, crop, anchors |
| `static/js/views.js` | home, search, tag browser, files, health, tools, backup pages |
| `static/js/app.js` | router, top bar, keyboard shortcuts |
| `static/vendor/katex/` | bundled KaTeX (offline LaTeX math; no CDN is ever contacted) |

**`mcp/server.py`** — the MCP server: newline-delimited JSON-RPC 2.0 on
stdio; exposes the full tool set (below).

**`backup/backup.py`** — the backup, sync and restore tool (CLI and API).

## The tag notation

Tags are plain text a non-coder can edit:

- A note's `tags.txt` holds comma-separated entries:
  `COOKING-weeknight, FOOD-pasta-vegetarian, METHOD-stovetop-one_pot`
- **Every tag is an independent label (v2).** A dash is simply part of the
  name — there are no sub-tags and no hierarchy. `FOOD-pasta-vegetarian`
  and `FOOD-pasta` are two unrelated tags; each matches only itself
  (capitals ignored).
- A space inside a tag name is written as an underscore
  (`HOME_REPAIR-wall_painting`); commas never appear inside a tag.
- `_tags.md` is the master vocabulary. Under `## Approved tags` every tag
  is listed (grouped under `### MAJOR` headings that are **display
  categories only**, each line optionally `TAG: synonym, synonym`). The
  `## Synonyms` section maps general search words (`quick: fast, rapid,
  speedy`). `## Proposed tags` holds tags the AI wants to add; they become
  usable when you move them up (or approve them in the tag browser).
- **Sync guarantee (v2):** a tag you apply on any note is added to
  `_tags.md` at the same moment, so the global index and the per-note
  tags can never drift apart. (Tags the AI applies still wait for your
  approval under *Proposed tags*.)
- **Tag preview:** typing in any tag field shows the tags that already
  exist, with their note counts, before you commit.

## Search: modes, scopes and ranking

The engine (spec 3) has **no semantic model**. It ranks *notes*, never text
chunks; tags and keywords are boosters, not filters. Three modes:

- **Ranking only** (default) — nothing is excluded; signals only order.
- **Strict keyword** — only notes containing *every* query word (any
  order; synonyms satisfy it; `"quoted words"` are an exact phrase).
- **Strict tag** — only notes carrying *all* selected tags.

You can also pick subjects (a hard boundary — the search never looks
outside, sub-folders included, with a *this folder only* toggle), pick tags
(major tags first in the filter bar; only real tags can be chosen), choose
the scope (file name / tags / headings / body / folder path), and filter by
date. The search page is structured into labeled sections — Mode, Narrow
by, Advanced, Results — with a **How to use** button that explains every
switch in plain words.

Every query is understood the same way on the website and from the AI:
lowercased, accents stripped, dashes/underscores as spaces, filler words
dropped but negations kept, words stemmed so endings match, one wrong
letter tolerated for words of five or more letters, words matching an
approved tag (or a tag synonym) becoming query tags. Query words expand
into concept groups (the word, its stem, its synonyms — your words count
fully, synonyms 0.7, and a note earns a group once through its best term).

Candidates come from tag hits, keyword hits, neighbors (notes sharing at
least two tags with a top-5 hit or connected to one) and a fallback that
keeps results from ever being blank. Every candidate is scored:

| Signal | Weight |
| --- | --- |
| Tags (exact match, rarer counts more) | 34% |
| Title and aliases (share of groups found; full-phrase title = perfect) | 24% |
| Headings and quick-info labels (BM25) | 14% |
| Neighbors | 12% |
| Body (BM25, length-normalized) | 10% |
| Closeness (words near each other / same section) | 6% |

`final = 100 × weighted sum × coverage`, where coverage is
`0.4 + 0.6 × (share of query groups matched)` — matching every part of the
query beats matching one part many times. Title matching is prefix-aware
(`garl` finds *Garlic Bread*) and a title containing the whole query
phrase ranks as a perfect title match. Signals that do not apply simply
earn nothing (the *Why this result* panel shows only the signals that
earned points, in plain words); each signal is scaled against the best
candidate; an exact title or alias match ranks first; a neighbor-only note
never outranks a direct match; ties break by more groups matched, more
recently updated, then title A–Z — identical on every run. Results come 20
at a time (*Show 20 more* continues the same list).

The weights live in `core/settings.json`. `python3 core/test_ranking.py`
runs the fixed query set and fails loudly if ranking regresses.

## The website

Run `python3 website/server.py` (options: `--port`, `--no-browser`,
`--rebuild`). It listens on this computer only; opening it to the home
network is an explicit setting (`server_bind` in `core/settings.json`).
The whole interface was remastered in **v2.1 as a strict-grid
neo-brutalist UI**: paper background, 2px ink borders, hard offset
shadows, one orange accent, monospace uppercase labels — no gradients,
no purple, two themes (**Light** and **Dark**), and a mobile layout with
a bottom tab bar for Android phones.

- **Top bar** — a real **Back** button (one step back, like the browser;
  also `Alt/⌘+←`), the SB mark, a **global search box that works on every
  page**, and *New note*. On phones the top bar compacts to icons and the
  main sections move to a fixed bottom tab bar.
- **Home** — search, stats, pinned notes, recently updated, saved searches.
- **Search** — structured into labeled sections (Mode / Narrow by /
  Advanced / Results) with a **How to use** guide. All modes, switches,
  scopes, chips, date filters, *Show 20 more*, and the per-result *Why
  this result* panel in plain words. Require-mode notices say which switch
  removed the notes and offer to relax it.
- **Folders** — a full folder browser: walk into any subject, see notes
  with tags and dates, create a note or a subfolder *right there*, rename,
  move, delete (deletes are logged and undoable), edit `_subject.md`.
- **Note page** — breadcrumbs; the quick info card; the rendered note with
  **clickable checklists** (tick straight from the page — the file is
  updated); **Connected notes** — THE reference list: every note this one
  links to, added by **searching notes only** (never tags or folder names),
  with an expandable branch view and **no backlinks**; **Reference sources**
  (type `domain.com` — https:// is added); **Tags** (add/remove with live
  preview of existing tags, synced with `_tags.md`); **Metadata**. Plus
  Find in note, Copy note, Export metadata (flat tags, no backlinks),
  Print/PDF, pin. *(The old connection-graph page was removed in v2.1 —
  connected notes on the note page replace it.)*
- **Editing** — raw Markdown with a smart toolbar: nothing stays selected
  after an insert (the old bug is gone); the cursor lands inside `**…**`,
  right after `## `, at the end of a prefixed line; **select a word and tap
  any button** to format it; *Link note* / *Link web* work on the selected
  word (auto-https for web); a visual **table editor** (add/remove rows and
  columns, edit every cell, also opened from any rendered table's *Edit
  table* button); **Find in note** (Ctrl/Cmd+F) works in edit **and**
  preview mode, cycling through matches with highlight and auto-scroll.
  Saving checks the file's hash first and asks before overwriting;
  switching edit/preview never throws your place.
- **Images** — render exactly where their Markdown sits; many images
  arrange into a tidy grid; click for full screen with **crop** (saved as a
  new image, then replace-with-backup or keep both), **delete**
  (confirmation, warning, backup history) and **download**; resize each
  image in the viewer.
- **Tags page** — the vocabulary as independent tags grouped by display
  category, with a filter field, per-tag editor (rename, merge, remove
  everywhere, list the notes), add-to-master for unapproved tags, and the
  `_tags.md` raw editor.
- **Health** — a 0–100 score, every finding explained with a **one-click
  fix** where one exists (remove a broken link, approve a tag into
  `_tags.md`, merge near-duplicates, delete stray files and unreferenced
  images), plus the log history with **Undo this** buttons.
- **Backup** — point at any folder outside the project; preview, run
  (makes it byte-identical), and **Verify hashes** showing the SHA-256 of
  every file. The project itself is never modified during a backup.
- **Tools** — the folder table, rebuild the index, edit settings (weights,
  port, backup destination).

Reading font and text size adjustable. Keyboard: `/` opens search, `e`
toggles edit on a note, `Ctrl/Cmd+S` saves in the editor, `Ctrl/Cmd+F`
finds in the note, `Alt/⌘+←` goes back.

## The AI tools (MCP)

Point any MCP client at:

```json
{"command": "python3", "args": ["/absolute/path/to/secondbrain/mcp/server.py"]}
```

The AI gets 35 tools — everything the website can do, nothing hidden:
`search_notes`, `suggest_tags`, `list_tags`, `list_folders` /
`list_subjects`, `read_note`, `get_connections`, `remove_broken_link`,
`file_note`, `create_note`, `edit_note`, `append_my_notes`, `move_note`,
`rename_note`, `edit_tags`, `connect_notes`, `add_reference`,
`edit_quick_info`, `add_attachment`, `edit_links`, `edit_metadata`,
`export_metadata`, `crop_image`, `delete_image`, `rename_tag`,
`merge_tags`, `approve_tags`, `health_check`, `backup_preview`,
`backup_run`, `backup_restore`, `backup_verify`, `undo_change`,
`saved_searches`, `get_structure`.

The librarian rules are enforced in the engine, not in prompts: paths
outside the structure are refused; only existing tags can be applied (new
ones are proposed under *Proposed tags*); every write logs itself naming
**AI**; *My notes* is append-only; and the AI must ask before creating a
new folder — the tools return `needs_approval` until the request carries
`approve_new_folder=true`, which only happens after you agreed. There is
no verification status anywhere (v2): notes carry no approved/unapproved
state.

## Backup and restore

`python3 backup/backup.py --to <folder outside the project> [--direction
backup|restore] [--scope whole|database|inbox|logs|<relative path>]
[--yes] [--keep 10]` and `--verify` to check a copy.

1.  Manifests both sides: path, size, SHA-256 for every file.
2.  Sorts each file: unchanged, changed (even by one word), new, removed,
    moved (same hash, new path).
3.  Shows a preview with counts and waits for approval (unless `--yes`).
4.  Copies only changed and new files, moves renamed ones, and keeps every
    replaced or removed file in a dated `.versions/` folder.
5.  Re-hashes everything it wrote — a run is not successful until every
    hash matches, and it says so.

**Byte-identical guarantee (v2):** run it against an old backup folder and
the run edits *that folder* until it matches the project byte for byte —
`Verify hashes` shows the SHA-256 of every single file on both sides.
During a `backup` run the live project is read-only: not one byte of it is
touched (the run even refuses to write inside the project by mistake).

Every copy lands via a temporary file first, so an interrupted run leaves
nothing half-written. Retention prunes old `.versions/` folders. Every run
writes a log file. The same preview and hash check serve both directions
(update the backup from the project, or restore the project from the
backup). Paths behave the same on Windows, macOS and Linux.

## How to extend the project

- **New subject** — create a folder (website: Tools, or your file
  manager); optionally add `_subject.md`.
- **New tag** — one line under `## Approved tags` in `_tags.md` (or Add
  tag on the Tags page); then use it in any `tags.txt`.
- **New synonym** — one line in `## Synonyms`.
- **A structural change** (new folder or file type, renamed section, new
  tool, changed notation) — needs your approval, an update to the
  structure files (`README.md`, and `SKILL.md` /
  `StructureOFnotes.md` where affected), and its log entry lists those
  updates. Any file created by a build step must be named in this
  README.

## Performance and portability

Local only, no accounts, no tracking, nothing leaves the machine. UTF-8
with LF line endings; no file-name characters any system forbids; names
unique even ignoring capitals. The index is a cache — it updates only
notes whose hash changed and can always be rebuilt from the files
(`python3 website/server.py --rebuild`). Search targets well under 100 ms
on 10,000 notes; the grid uses thumbnails; long lists load as you scroll.
The smallest set of dependencies does the job: **none** are required
(Python standard library only); Pillow is optional, only for AI-side image
cropping; KaTeX is bundled for offline math rendering.
