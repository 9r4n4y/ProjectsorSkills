"""SecondBrain backup, sync and restore tool (spec 7).

Brings an old backup copy up to date without copying everything again:

1. Records every file's path, size and SHA-256 hash on both sides.
2. Sorts each file as unchanged, changed, new, removed or moved.
3. Shows a preview with counts and waits for approval.
4. Copies only changed and new files, moves renamed ones, and keeps every
   replaced or removed file in a dated .versions/ folder.
5. Re-hashes everything it wrote; a run is not successful until every hash
   matches.

Both directions share the same preview and the same hash check: update the
backup from the project, or restore the project from a backup.

Usage:
  python3 backup/backup.py --to /path/to/backup --direction backup --scope whole
  python3 backup/backup.py --to /path/to/backup --direction restore --yes
  python3 backup/backup.py --to /path/to/backup --verify

Scopes: whole | database | inbox | logs | a relative folder or file path.
"""
from __future__ import annotations

import argparse
import datetime as _dt
import hashlib
import json
import shutil
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
EXCLUDE = {".cache", "__pycache__", ".tmp", ".tmp-write"}
VERSIONS = ".versions"


def sha256_of(p: Path) -> str:
    h = hashlib.sha256()
    with open(p, "rb") as fh:
        for chunk in iter(lambda: fh.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def manifest(base: Path, scope: str) -> dict[str, dict]:
    """{relative path: {size, sha256}} for every file under base+scope."""
    root = base if scope in ("whole", "", ".") else base / scope
    out: dict[str, dict] = {}
    if not root.exists():
        return out
    for p in sorted(root.rglob("*")):
        if not p.is_file() or p.is_symlink():
            continue
        if any(part in EXCLUDE or part == VERSIONS for part in p.parts):
            continue
        rel = p.relative_to(base).as_posix()
        st = p.stat()
        out[rel] = {"size": st.st_size, "sha256": sha256_of(p)}
    return out


def compare(live_m: dict, old_m: dict) -> dict[str, list[str]]:
    cmp = {"unchanged": [], "changed": [], "new": [], "removed": [], "moved": []}
    old_by_hash: dict[str, list[str]] = {}
    for path, meta in old_m.items():
        old_by_hash.setdefault(meta["sha256"], []).append(path)
    live_by_hash: dict[str, list[str]] = {}
    for path, meta in live_m.items():
        live_by_hash.setdefault(meta["sha256"], []).append(path)
    for path, meta in live_m.items():
        if path in old_m:
            if old_m[path]["sha256"] == meta["sha256"]:
                cmp["unchanged"].append(path)
            else:
                cmp["changed"].append(path)
        else:
            cmp["new"].append(path)
    for path in old_m:
        if path not in live_m:
            # removed here - unless the same content moved somewhere new
            h = old_m[path]["sha256"]
            moved = False
            if h in live_by_hash:
                for new_path in live_by_hash[h]:
                    if new_path not in old_m:
                        cmp["moved"].append(f"{path} -> {new_path}")
                        moved = True
                        break
            if not moved:
                cmp["removed"].append(path)
    return cmp


def preview(cmp: dict) -> str:
    lines = [
        f"  unchanged: {len(cmp['unchanged'])}",
        f"  changed:   {len(cmp['changed'])}",
        f"  new:       {len(cmp['new'])}",
        f"  removed:   {len(cmp['removed'])}",
        f"  moved:     {len(cmp['moved'])}",
    ]
    for k in ("changed", "new", "removed", "moved"):
        for p in cmp[k][:40]:
            lines.append(f"    [{k}] {p}")
        if len(cmp[k]) > 40:
            lines.append(f"    [{k}] ... and {len(cmp[k]) - 40} more")
    return "\n".join(lines)


def _atomic_copy(src: Path, dst: Path):
    dst.parent.mkdir(parents=True, exist_ok=True)
    tmp = dst.with_name(dst.name + ".tmp-backup")
    shutil.copy2(src, tmp)
    tmp.replace(dst)


def keep_old(dst: Path, backup_root: Path) -> str | None:
    """Move the file that is about to be replaced/removed into the dated
    .versions/ folder. Nothing is overwritten or deleted without first
    being kept (spec 7 Safety)."""
    if not dst.exists():
        return None
    stamp = _dt.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    rel = dst.relative_to(backup_root)
    keep_path = backup_root / VERSIONS / stamp / rel
    keep_path.parent.mkdir(parents=True, exist_ok=True)
    shutil.move(str(dst), str(keep_path))
    return str(keep_path.relative_to(backup_root))


def prune_versions(backup_root: Path, keep: int):
    versions = backup_root / VERSIONS
    if not versions.exists() or keep <= 0:
        return
    stamps = sorted((d for d in versions.iterdir() if d.is_dir()),
                    key=lambda d: d.name, reverse=True)
    for old in stamps[keep:]:
        shutil.rmtree(old, ignore_errors=True)


def run(direction: str, target: Path, scope: str, approve: bool,
        keep_versions: int, log_fn=print) -> dict:
    """direction 'backup': project -> target. 'restore': target -> project.
    Returns a report dict; raises SystemExit on hash mismatch.
    GUARANTEE (v2): a 'backup' run never writes a single byte inside the
    project - the live project is read-only for this direction."""
    if direction == "backup":
        src_base, dst_base = ROOT, target
    else:
        src_base, dst_base = target, ROOT
    t_src, t_dst = Path(src_base).resolve(), Path(dst_base).resolve()
    if t_src == t_dst or t_src in t_dst.parents or t_dst in t_src.parents:
        raise ValueError("The backup copy must live OUTSIDE the project folder.")
    if direction == "backup":
        protect = t_src
    else:
        protect = t_dst      # restore writes the project on purpose
    src_m = manifest(src_base, scope)
    dst_m = manifest(dst_base, scope)
    cmp = compare(src_m, dst_m)

    log_fn("Preview")
    log_fn(preview(cmp))
    todo = cmp["changed"] + cmp["new"]
    moves = [tuple(m.split(" -> ", 1)) for m in cmp["moved"]]
    if not todo and not moves and not cmp["removed"]:
        log_fn("Nothing to do - everything is already up to date.")
        return {"ok": True, "compared": len(src_m), "written": 0}

    if not approve:
        answer = input(f"\nApply these changes ({direction}, scope={scope})? [y/N] ")
        if answer.strip().lower() not in {"y", "yes"}:
            log_fn("Cancelled. Nothing was written.")
            return {"ok": False, "cancelled": True}

    written: list[str] = []
    kept: list[str] = []
    # Changed and new files: copy to a temporary file, then rename.
    for rel in todo:
        dst = dst_base / rel
        if direction == "backup" and (protect in dst.resolve().parents
                                      or dst.resolve() == protect):
            raise ValueError("Refusing to write inside the project during a backup.")
        if dst.exists():
            kept.append(keep_old(dst, dst_base))
        _atomic_copy(src_base / rel, dst)
        written.append(rel)
    # Moved: rename on the destination side.
    for old_rel, new_rel in moves:
        dst_old, dst_new = dst_base / old_rel, dst_base / new_rel
        if dst_old.exists() and not dst_new.exists():
            dst_new.parent.mkdir(parents=True, exist_ok=True)
            shutil.move(str(dst_old), str(dst_new))
            written.append(f"{old_rel} -> {new_rel}")
    # Removed on the source side: keep in .versions/, then delete.
    for rel in cmp["removed"]:
        dst = dst_base / rel
        if dst.exists():
            kept.append(keep_old(dst, dst_base))
            dst.unlink()

    prune_versions(dst_base, keep_versions)

    # Re-hash everything that was written; a run is not successful until
    # every hash matches (spec 7 step 6).
    mismatches = []
    for rel in written:
        if " -> " in rel:
            rel = rel.split(" -> ")[1]
        got = sha256_of(dst_base / rel)
        if got != src_m[rel]["sha256"]:
            mismatches.append(rel)

    report = {
        "ok": not mismatches,
        "direction": direction,
        "scope": scope,
        "compared": len(src_m),
        "unchanged": len(cmp["unchanged"]),
        "changed": len(cmp["changed"]),
        "new": len(cmp["new"]),
        "removed": len(cmp["removed"]),
        "moved": len(moves),
        "written": written,
        "kept_in_versions": [k for k in kept if k],
        "hash_mismatches": mismatches,
    }
    log_fn("\nResult")
    log_fn(f"  written: {len(written)} file(s), kept in .versions/: "
           f"{len(report['kept_in_versions'])}, unchanged: {report['unchanged']}")
    if mismatches:
        log_fn(f"  HASH MISMATCH for {len(mismatches)} file(s): the run FAILED:")
        for m in mismatches:
            log_fn(f"    {m}")
        raise SystemExit(1)
    log_fn("  Every hash verified. Run successful.")
    log_name = _write_run_log(report, direction, cmp)
    # Mirror the run log into the backup copy so verify is clean right away.
    try:
        _atomic_copy(ROOT / "logs" / log_name, target / "logs" / log_name)
    except Exception:  # noqa: BLE001 - the mirror is a convenience
        pass
    return report


def _write_run_log(report: dict, direction: str, cmp: dict) -> str:
    """Every run creates a log file listing what was compared, copied,
    moved, kept and verified (spec 7 Safety). Returns the file name."""
    logs = ROOT / "logs"
    logs.mkdir(exist_ok=True)
    stamp = _dt.datetime.now()
    name = stamp.strftime("%Y-%m-%d_%H-%M-%S") + "_Backup_" + direction + ".md"
    body = [
        f"# Backup {direction}",
        "",
        f"- **When:** {stamp.strftime('%Y-%m-%d %H:%M:%S')}",
        "- **Who:** User",
        f"- **Title:** Backup {direction} (scope {report['scope']})",
        "",
        "## What was done",
        "",
        f"- Compared {report['compared']} files with the {'backup copy' if direction == 'backup' else 'backup source'}.",
        f"- Unchanged: {report['unchanged']}, changed: {report['changed']}, "
        f"new: {report['new']}, removed: {report['removed']}, moved: {report['moved']}.",
        f"- Written files: {len(report['written'])}.",
        f"- Kept in .versions/: {len(report['kept_in_versions'])}.",
        f"- Hash verification: "
        + ("all matched." if report["ok"] else "MISMATCH - run failed."),
        "",
        "## File list",
        "",
        "```",
        preview(cmp),
        "```",
        "",
    ]
    tmp = logs / (name + ".tmp")
    tmp.write_text("\n".join(body), encoding="utf-8", newline="\n")
    tmp.replace(logs / name)
    return name


def verify(target: Path, scope: str, log_fn=print) -> bool:
    """Verify that the backup copy matches the live project right now."""
    return verify_detailed(target, scope, log_fn)["ok"]


def verify_detailed(target: Path, scope: str, log_fn=print) -> dict:
    """Byte-for-byte verification: SHA-256 for EVERY file on both sides.
    Returns the full per-file report the website shows."""
    live_m, old_m = manifest(ROOT, scope), manifest(target, scope)
    files = []
    mismatched, missing, extra = [], [], []
    for path, meta in sorted(live_m.items()):
        if path not in old_m:
            missing.append(path)
            files.append({"path": path, "status": "missing in backup",
                          "project_sha256": meta["sha256"], "backup_sha256": ""})
        elif old_m[path]["sha256"] != meta["sha256"]:
            mismatched.append(path)
            files.append({"path": path, "status": "hash mismatch",
                          "project_sha256": meta["sha256"],
                          "backup_sha256": old_m[path]["sha256"]})
        else:
            files.append({"path": path, "status": "identical",
                          "project_sha256": meta["sha256"],
                          "backup_sha256": old_m[path]["sha256"]})
    for path in sorted(old_m):
        if path not in live_m:
            extra.append(path)
            files.append({"path": path, "status": "extra in backup (not in project)",
                          "project_sha256": "", "backup_sha256": old_m[path]["sha256"]})
    ok = not (mismatched or missing or extra)
    if not ok:
        log_fn(f"Not in sync: {len(mismatched)} changed, {len(missing)} missing, "
               f"{len(extra)} extra (of {len(live_m)} project files).")
    else:
        log_fn(f"Backup verified: {len(live_m)} files match by SHA-256, byte for byte.")
    return {"ok": ok, "compared": len(live_m),
            "mismatched": mismatched, "missing": missing, "extra": extra,
            "files": files}


def main():
    ap = argparse.ArgumentParser(description="SecondBrain backup tool")
    ap.add_argument("--to", required=True, help="backup folder (outside the project)")
    ap.add_argument("--direction", choices=["backup", "restore"], default="backup")
    ap.add_argument("--scope", default="whole",
                    help="whole | database | inbox | logs | a relative path")
    ap.add_argument("--yes", action="store_true", help="apply without asking")
    ap.add_argument("--keep", type=int, default=10,
                    help="how many dated .versions/ folders to keep")
    ap.add_argument("--verify", action="store_true",
                    help="only verify, change nothing")
    args = ap.parse_args()

    target = Path(args.to).expanduser().resolve()
    if target.resolve() == ROOT or ROOT in target.parents or target in ROOT.parents:
        print("The backup copy must live OUTSIDE the project folder.", file=sys.stderr)
        raise SystemExit(2)
    if not target.exists():
        if args.verify:
            print(f"Backup folder {target} does not exist.", file=sys.stderr)
            raise SystemExit(2)
        target.mkdir(parents=True)
        print(f"Created backup folder {target}")

    if args.verify:
        raise SystemExit(0 if verify(target, args.scope) else 1)
    run(args.direction, target, args.scope, args.yes, args.keep)


if __name__ == "__main__":
    main()
