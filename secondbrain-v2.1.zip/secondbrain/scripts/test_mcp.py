"""Rigorous SecondBrain MCP test suite.

Spawns mcp/server.py as a REAL subprocess, speaks newline-delimited
JSON-RPC 2.0 over stdio (exactly like an MCP client), and exercises every
tool: initialize, tools/list, then every tool call including error paths,
the folder-creation approval gate, tag proposals, search, backup and undo.

Run:  python3 scripts/test_mcp.py
"""
from __future__ import annotations

import json
import shutil
import subprocess
import sys
import tempfile
import time
from pathlib import Path

SRC = Path(__file__).resolve().parent.parent
if not (SRC / "core").exists() or not (SRC / "database").exists():
    SRC = Path("/home/z/my-project/secondbrain")  # developer fallback
RESULTS = []


def check(name, ok, detail=""):
    RESULTS.append((ok, name, detail))
    print(f"[{'PASS' if ok else 'FAIL'}] {name}" + (f" -> {detail}" if detail else ""))


class Client:
    def __init__(self, root: Path):
        self.proc = subprocess.Popen(
            [sys.executable, str(root / "mcp" / "server.py")],
            stdin=subprocess.PIPE, stdout=subprocess.PIPE,
            stderr=subprocess.PIPE, text=True, cwd=str(root))
        self._id = 0

    def call(self, method, params=None, timeout=30):
        self._id += 1
        msg = {"jsonrpc": "2.0", "id": self._id, "method": method}
        if params is not None:
            msg["params"] = params
        self.proc.stdin.write(json.dumps(msg) + "\n")
        self.proc.stdin.flush()
        line = self._readline(timeout)
        return json.loads(line)

    def tool(self, name, args=None, timeout=30):
        r = self.call("tools/call", {"name": name,
                                     "arguments": args or {}}, timeout)
        if "error" in r:
            return {"__rpc_error__": r["error"]}
        payload = json.loads(r["result"]["content"][0]["text"])
        payload["__isError__"] = r["result"].get("isError", False)
        return payload

    def _readline(self, timeout):
        end = time.time() + timeout
        # stdout is block-buffered by the child? We forced text mode with
        # line writes from the server; use a select-less simple reader.
        line = self.proc.stdout.readline()
        if not line:
            err = self.proc.stderr.read() if self.proc.poll() is not None else ""
            raise RuntimeError(f"server closed stdout. stderr: {err[:400]}")
        return line

    def close(self):
        try:
            self.proc.stdin.close()
        except Exception:
            pass
        self.proc.terminate()
        self.proc.wait(timeout=5)


def main() -> int:
    tmp = Path(tempfile.mkdtemp(prefix="sb-mcp-"))
    work = tmp / "secondbrain"
    shutil.copytree(SRC, work, ignore=shutil.ignore_patterns(
        ".cache", "__pycache__", ".versions"))
    for f in (work / "logs").iterdir():
        f.unlink()

    c = Client(work)

    # --- protocol handshake ---
    r = c.call("initialize", {"protocolVersion": "2024-11-05",
                              "capabilities": {}, "clientInfo": {"name": "test"}})
    check("initialize returns protocol version",
          "protocolVersion" in r.get("result", {}), str(r.get("result", {}))[:80])
    r = c.call("tools/list")
    tools = {t["name"] for t in r["result"]["tools"]}
    check("tools/list exposes 35 tools", len(tools) == 35, str(len(tools)))
    expected = {"search_notes", "suggest_tags", "list_tags", "list_folders",
                "list_subjects", "read_note", "get_connections",
                "remove_broken_link", "file_note", "create_note", "edit_note",
                "append_my_notes", "move_note", "rename_note", "edit_tags",
                "connect_notes", "add_reference", "edit_quick_info",
                "add_attachment", "edit_links", "edit_metadata",
                "export_metadata", "crop_image", "delete_image", "rename_tag",
                "merge_tags", "approve_tags", "health_check", "backup_preview",
                "backup_run", "backup_restore", "backup_verify", "undo_change",
                "saved_searches", "get_structure"}
    check("all documented tools are present", expected <= tools,
          str(sorted(expected - tools)))
    r = c.call("ping")
    check("ping answers", "result" in r)

    # --- search ---
    out = c.tool("search_notes", {"query": "quick pasta"})
    check("search_notes ranks the pasta note first",
          out["results"][0]["title"] == "Quick Vegetable Pasta for Weeknights")
    check("search_notes returns a score breakdown",
          "breakdown" in out["results"][0] and "tags" in out["results"][0]["breakdown"])
    out = c.tool("search_notes", {"query": "lentil garlic", "mode": "strict_keyword"})
    check("strict keyword mode filters", "results" in out and out["results"])
    out = c.tool("search_notes", {"query": "", "tags": ["FOOD-pasta-vegetarian"],
                                  "mode": "strict_tag"})
    check("strict tag mode filters by exact independent tag",
          len(out["results"]) == 1)
    out = c.tool("suggest_tags", {"query": "pas"})
    check("suggest_tags finds existing tags",
          any(s["name"].startswith("FOOD") for s in out["suggestions"]))

    # --- reading ---
    out = c.tool("read_note", {"path": "Garlic Bread"})
    check("read_note resolves by bare name", out["name"] == "Garlic Bread"
          and "raw" in out and "hash" in out)
    check("read_note has NO backlinks key (v2)", "backlinks" not in out)
    out = c.tool("get_connections", {"path": "Garlic Bread"})
    check("get_connections returns connected + references, no backlinks",
          "connected" in out and "references" in out and "backlinks" not in out)
    out = c.tool("list_tags")
    check("list_tags returns flat tags with counts",
          "counts" in out and "unapproved" in out and "rows" in out
          and "tree" not in out)
    out = c.tool("list_folders")
    check("list_folders returns a tree with aggregated counts",
          "tree" in out and out["tree"].get("total_notes", 0) >= 6,
          str(out.get("tree", {}).get("total_notes")))
    out = c.tool("get_structure")
    check("get_structure returns README + rulebook",
          "README.md" in out and "StructureOFnotes.md" in out)

    # --- folder gate ---
    out = c.tool("create_note", {"name": "MCP Test Note", "folder": "Does Not Exist",
                                 "text": "# MCP Test Note"})
    check("creating a note in a missing folder returns needs_approval",
          out.get("needs_approval") is True and "__isError__" in out)
    out = c.tool("create_note", {"name": "MCP Test Note", "folder": "Does Not Exist",
                                 "text": "# MCP Test Note", "approve_new_folder": True})
    check("with approve_new_folder=true the note is created",
          "path" in out and (work / out["path"]).exists())

    # --- tag proposal flow ---
    out = c.tool("edit_tags", {"path": "MCP Test Note", "add": ["MOOD-testy"]})
    check("AI tag is proposed, not applied silently",
          "MOOD-testy" in out.get("proposed", []))
    master = (work / "_tags.md").read_text(encoding="utf-8")
    check("proposed tag lands under Proposed tags",
          "## Proposed tags" in master and "MOOD-testy" in master.split("## Proposed tags")[1])
    out = c.tool("approve_tags", {"tags": ["MOOD-testy"]})
    master = (work / "_tags.md").read_text(encoding="utf-8")
    approved_section = master.split("## Approved tags")[1].split("## Synonyms")[0]
    check("approve_tags moves the tag to Approved",
          "MOOD-testy" in approved_section
          and "MOOD-testy" not in master.split("## Proposed tags")[1])

    # --- writes ---
    out = c.tool("edit_note", {"path": "MCP Test Note",
                               "text": "# MCP Test Note\n\nEdited by the suite."})
    check("edit_note succeeds", out.get("ok") is True)
    out = c.tool("append_my_notes", {"path": "MCP Test Note",
                                     "text": "- suite was here"})
    check("append_my_notes appends", out.get("ok") is True)
    raw = (work / "database/Does Not Exist/MCP Test Note/MCP Test Note.md").read_text()
    check("append landed in the My notes section", "- suite was here" in raw)
    out = c.tool("connect_notes", {"path": "MCP Test Note", "add": ["Garlic Bread"]})
    check("connect_notes adds a connection",
          "Garlic Bread" in out.get("connected", []))
    out = c.tool("add_reference", {"path": "MCP Test Note",
                                   "add": {"url": "example.com/mcp"}})
    check("add_reference auto-https", any(
        r["url"] == "https://example.com/mcp" for r in out["references"]),
        str([r["url"] for r in out["references"]]))
    out = c.tool("edit_metadata", {"path": "MCP Test Note",
                                   "meta": {"pinned": "yes"}})
    check("edit_metadata sets pinned (no status anywhere)",
          out.get("meta", {}).get("pinned") == "yes"
          and "status" not in out.get("meta", {}))
    out = c.tool("export_metadata", {"path": "MCP Test Note"})
    check("export_metadata has no Backlinks/Status",
          "Backlinks" not in out["text"] and "Status" not in out["text"])

    # --- rename propagates to links that point AT the renamed note ---
    out = c.tool("connect_notes", {"path": "Garlic Bread", "add": ["MCP Test Note"]})
    check("backlink setup: Garlic Bread now connects to the test note",
          "MCP Test Note" in out.get("connected", []))
    out = c.tool("rename_note", {"path": "MCP Test Note", "name": "MCP Renamed Note"})
    import glob as _glob
    print("   [debug] folder tree:", _glob.glob(str(work / "database/Does Not Exist/**"), recursive=True))
    check("rename_note succeeds and rewrites incoming links",
          out.get("path") and any(r["links_updated"] for r in out.get("rewrites", [])),
          str(out.get("rewrites")))
    check("rename keeps the note in its folder (v2 fix)",
          (work / "database/Does Not Exist/MCP Renamed Note/MCP Renamed Note.md").exists())
    garlic = (work / "database/Recipes/Garlic Bread/Garlic Bread.md").read_text()
    check("the other note now points at the new name",
          "[[MCP Renamed Note]]" in garlic and "[[MCP Test Note]]" not in garlic)

    # --- health + broken-link helper ---
    (work / "database/Does Not Exist/MCP Renamed Note/MCP Renamed Note.md").write_text(
        (work / "database/Does Not Exist/MCP Renamed Note/MCP Renamed Note.md")
        .read_text().replace("[[Garlic Bread]]", "[[Garlic Bread]]\n[[Phantom Note]]"))
    out = c.tool("health_check", {})
    check("health_check reports broken links", out["summary"]["broken_links"] >= 1)
    out = c.tool("remove_broken_link", {"path": "MCP Renamed Note",
                                        "link": "Phantom Note"})
    check("remove_broken_link fixes it", out.get("removed") == 1)

    # --- backup via MCP ---
    target = tmp / "mcp-backup"
    target.mkdir()
    out = c.tool("backup_preview", {"to": str(target)})
    check("backup_preview returns counts", "counts" in out)
    out = c.tool("backup_run", {"to": str(target)})
    check("backup_run verifies every hash", out.get("ok") is True)
    out = c.tool("backup_verify", {"to": str(target)})
    check("backup_verify returns per-file SHA-256 report",
          out.get("ok") is True and isinstance(out.get("files"), list)
          and all("project_sha256" in f for f in out["files"]))
    out = c.tool("backup_run", {"to": str(work)})
    check("backup refuses a target inside the project",
          "__rpc_error__" in out or out.get("__isError__") is True,
          str(out)[:90])

    # --- undo ---
    logs = sorted((work / "logs").glob("*.md"))
    undoable = [l for l in logs if ":::undo" in l.read_text()]
    out = c.tool("undo_change", {"log": undoable[-1].name})
    check("undo_change reverses the logged change", "log" in out)

    # --- error surface ---
    out = c.tool("read_note", {"path": "No Such Note Anywhere"})
    check("unknown note returns isError with a message",
          out.get("__isError__") is True and "error" in out)
    r = c.call("tools/call", {"name": "no_such_tool", "arguments": {}})
    check("unknown tool returns a JSON-RPC error",
          "error" in r and r["error"]["code"] == -32602)

    c.close()
    print()
    fails = [r for r in RESULTS if not r[0]]
    print(f"{len(RESULTS) - len(fails)}/{len(RESULTS)} MCP expectations hold.")
    if fails:
        print("FAILED:")
        for _, name, detail in fails:
            print("  -", name, detail)
    shutil.rmtree(tmp, ignore_errors=True)
    return 1 if fails else 0


if __name__ == "__main__":
    sys.exit(main())
