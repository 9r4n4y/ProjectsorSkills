"""SecondBrain v2 engine test suite.

Proves every v2 engine change with real file operations on a THROWAWAY copy
of the project (the real project is never modified). Run:
    python3 scripts/test_engine.py
Prints one PASS/FAIL line per expectation and exits non-zero on failure.
"""
from __future__ import annotations

import importlib
import shutil
import sys
import tempfile
from pathlib import Path

SRC = Path(__file__).resolve().parent.parent
if not (SRC / "core").exists() or not (SRC / "database").exists():
    SRC = Path("/home/z/my-project/secondbrain")  # developer fallback

RESULTS = []


def check(name, ok, detail=""):
    RESULTS.append((ok, name, detail))
    print(f"[{'PASS' if ok else 'FAIL'}] {name}" + (f" -> {detail}" if detail else ""))


def main() -> int:
    tmp = Path(tempfile.mkdtemp(prefix="sb-test-"))
    work = tmp / "secondbrain"
    shutil.copytree(SRC, work, ignore=shutil.ignore_patterns(
        ".cache", "__pycache__", ".versions"))
    # clean the sample logs so counts are predictable
    for f in (work / "logs").iterdir():
        f.unlink()

    sys.path.insert(0, str(work))
    import core.paths as paths
    importlib.reload(paths)
    assert str(paths.ROOT) == str(work), f"paths.ROOT is {paths.ROOT}"
    from core import healthcheck, indexer, logger, search, store, tags as tags_mod  # noqa

    idx = indexer.rebuild_index()

    # ---------------------------------------------------------------- health
    h = healthcheck.health_check(idx)
    check("health check runs without NameError (the 'add' bug)",
          "structure_problems" in h.get("summary", {}))
    check("health summary has a 0-100 score",
          isinstance(h["summary"].get("score"), int) and 0 <= h["summary"]["score"] <= 100)
    check("health summary has no verification fields",
          "unverified_notes" not in h["summary"])

    # ------------------------------------------------------------ flat tags
    rel = tags_mod.relation("FOOD-pasta-vegetarian", "FOOD-pasta")
    check("tags are independent: a longer tag does NOT match a shorter one",
          rel is None, f"relation={rel}")
    check("tags are independent: exact match is 1.0",
          tags_mod.relation("food-PASTA", "FOOD-pasta") == 1.0)
    ext = tags_mod.extract_all_notes_tags()
    check("tag extractor returns a flat rows list with a major category",
          isinstance(ext.get("rows"), list) and ext["rows"]
          and all("major" in r for r in ext["rows"]))
    check("tag extractor no longer builds a hierarchy tree", "tree" not in ext)
    check("indexer tag_map indexes only exact tags",
          idx["tag_map"].get("food-pasta-vegetarian")
          and not idx["tag_map"].get("food-pasta"))

    # ------------------------------------------------------- user tag sync
    note_rel = "database/Recipes/Garlic Bread/Garlic Bread.md"
    out = store.edit_tags(note_rel, add=["MOOD-cozy"], who="user")
    master = (work / "_tags.md").read_text(encoding="utf-8")
    check("a tag the USER adds is applied", "MOOD-cozy" in out["tags"])
    check("...and auto-synced into _tags.md (global index in sync)",
          "MOOD-cozy" in master and out["proposed"] == [])
    out2 = store.edit_tags(note_rel, add=["MOOD-cuddled-up"], who="ai")
    master2 = (work / "_tags.md").read_text(encoding="utf-8")
    check("a tag the AI adds is proposed, not approved",
          "MOOD-cuddled-up" not in master2 and "MOOD-cuddled-up" in out2["proposed"])
    store.edit_tags(note_rel, remove=["MOOD-cozy"], who="user")

    # --------------------------------------------------------- rename/merge
    store.rename_tag("FOOD-garlic", "FOOD-garlic-clove", run=True)
    tf = (work / "database/Recipes/Garlic Bread/tags.txt").read_text(encoding="utf-8")
    check("rename_tag renames the exact tag everywhere",
          "FOOD-garlic-clove" in tf, tf.strip())
    check("rename_tag updated _tags.md too",
          "FOOD-garlic-clove" in (work / "_tags.md").read_text(encoding="utf-8"))
    store.rename_tag("FOOD-garlic-clove", "FOOD-garlic", run=True)

    # ----------------------------------------------------------- auto-https
    store.edit_references(note_rel, add={"title": "", "url": "example.com/recipes"})
    saved = store.parse_note((work / note_rel).read_text(encoding="utf-8"), note_rel)
    check("auto-https: domain.com is stored as https://domain.com",
          saved.references[-1]["url"] == "https://example.com/recipes",
          saved.references[-1]["url"])
    check("auto-https: empty title falls back to the domain",
          saved.references[-1]["title"] == "example.com", saved.references[-1]["title"])
    try:
        store.edit_references(note_rel, add={"url": saved.references[-1]["url"]})
        dup_ok = False
    except ValueError:
        dup_ok = True
    check("duplicate reference is refused", dup_ok)
    store.edit_references(note_rel, remove_url="https://example.com/recipes")
    store.edit_links(note_rel, "garlic", "example.com/garlic", make_note=False, who="user")
    body = (work / note_rel).read_text(encoding="utf-8")
    check("edit_links web target is auto-https",
          "https://example.com/garlic" in body)
    store.edit_links(note_rel, "https://example.com/garlic", None)

    # ---------------------------------------------- no verification status
    md = store.note_template("Test Note")
    check("note template has no Status line", "Status" not in md)
    created = store.create_note("Recipes", "V2 Test Note", tags=["FOOD-pasta"], who="user")
    test_rel = created["path"]
    txt = (work / test_rel).read_text(encoding="utf-8")
    check("a new note carries no Status meta", "Status" not in txt)
    store.set_metadata(test_rel, {"status": "verified"}, who="ai")
    txt2 = (work / test_rel).read_text(encoding="utf-8")
    check("set_metadata drops any Status key someone tries to set",
          "Status" not in txt2)

    # ---------------------------------------------------------- toggle task
    body_text = (work / test_rel).read_text(encoding="utf-8")
    body_text = body_text.replace("## My notes",
                                  "## My notes\n\n- [ ] buy oregano\n- [x] boil water", 1)
    store.atomic_write(work / test_rel, body_text)
    res = store.toggle_task(test_rel, 0, who="user")
    new_text = (work / test_rel).read_text(encoding="utf-8")
    check("toggle_task ticks the first checklist item by ordinal",
          "- [x] buy oregano" in new_text and res["checked"] is True)
    res2 = store.toggle_task(test_rel, 1, who="user")
    check("toggle_task unticks the second item",
          "- [ ] boil water" in (work / test_rel).read_text(encoding="utf-8"))

    # ------------------------------------------------------ broken link fix
    t = (work / test_rel)
    t.write_text(t.read_text(encoding="utf-8").replace(
        "## Connected notes", "## Connected notes\n\n[[Ghost Note]] [[Garlic Bread]]", 1),
        encoding="utf-8")
    idx2 = indexer.load_index()
    h2 = healthcheck.health_check(idx2)
    check("health check catches the broken link",
          any(b["link"] == "Ghost Note" for b in h2["broken_links"]))
    store.remove_broken_link(test_rel, "Ghost Note", who="user")
    fixed = (work / test_rel).read_text(encoding="utf-8")
    check("remove_broken_link drops the missing target, keeps other links",
          "Ghost Note" not in fixed and "[[Garlic Bread]]" in fixed)

    # ------------------------------------------------------ export metadata
    export = store.export_metadata(test_rel)
    check("metadata export has no Backlinks section", "Backlinks" not in export)
    check("metadata export has no Status line", "Status" not in export)
    check("metadata export lists flat tags", "Tags: FOOD-pasta" in export)

    # ------------------------------------------------------------- logs who
    store.delete_note(test_rel, who="user")
    logs = logger.list_logs(limit=50)
    whos = {l["who"] for l in logs}
    check("logs only name User or AI (never tool/website)",
          whos <= {"User", "AI"}, str(whos))
    check("delete_note wrote an undoable log", any(l["undoable"] for l in logs))

    # ------------------------------------------------------------- backup
    sys.path.insert(0, str(work))
    from backup import backup as bk
    target = tmp / "backup-copy"
    target.mkdir()
    rep = bk.run("backup", target, "whole", approve=True, keep_versions=2,
                 log_fn=lambda m: None)
    check("backup run succeeds with every hash verified", rep["ok"] is True,
          f"compared={rep['compared']}")
    ver = bk.verify_detailed(target, "whole", log_fn=lambda m: None)
    check("verify_detailed reports every file identical",
          ver["ok"] and all(f["status"] == "identical" for f in ver["files"]),
          f"{ver['compared']} files")
    # change one byte in the backup: verify must fail, then a run must fix it
    probe = target / "README.md"
    probe.write_text(probe.read_text(encoding="utf-8") + "\nstray\n")
    ver2 = bk.verify_detailed(target, "whole", log_fn=lambda m: None)
    check("verify catches a one-byte difference", not ver2["ok"])
    before_root = {str(p): p.stat().st_mtime_ns for p in work.rglob("*") if p.is_file()}
    rep2 = bk.run("backup", target, "whole", approve=True, keep_versions=2,
                  log_fn=lambda m: None)
    ver3 = bk.verify_detailed(target, "whole", log_fn=lambda m: None)
    check("a second run makes the copy byte-identical again",
          rep2["ok"] and ver3["ok"])
    after_root = {str(p): p.stat().st_mtime_ns for p in work.rglob("*") if p.is_file()}
    changed_root = {k for k in before_root if after_root.get(k) != before_root[k]}
    new_root = {k for k in after_root if k not in before_root}
    # the only legit project-side change is the run's own log file
    check("backup direction never edits project files (except its own log)",
          all(p.startswith(str(work / "logs")) for p in changed_root | new_root),
          str(sorted(changed_root | new_root))[:120])
    try:
        bk.run("backup", work / "database", "whole", approve=True, keep_versions=1,
               log_fn=lambda m: None)
        inside_ok = False
    except ValueError:
        inside_ok = True
    check("backup refuses a target inside the project", inside_ok)

    # ---------------------------------------------------------- search rank
    r1 = search.search(idx=idx, q="quick pasta")
    check("search: 'quick pasta' top result is the pasta note",
          r1["results"][0]["title"] == "Quick Vegetable Pasta for Weeknights",
          r1["results"][0]["title"])
    r2 = search.search(idx=idx, q="garl")
    check("ranking is prefix-aware: 'garl' finds Garlic Bread",
          r2["results"] and r2["results"][0]["title"] == "Garlic Bread",
          r2["results"][0]["title"] if r2["results"] else "(none)")
    check("why-breakdown note text is plain ('signal not used...')",
          all(v.get("note") != "not applicable for this query"
              for x in r1["results"] for v in x["breakdown"].values()))
    rt = search.search(idx=idx, q="", tags_sel=["FOOD-pasta-vegetarian"],
                       mode="strict_tag")
    check("strict tag filters by the exact independent tag",
          len(rt["results"]) == 1
          and rt["results"][0]["title"] == "Quick Vegetable Pasta for Weeknights")

    print()
    fails = [r for r in RESULTS if not r[0]]
    print(f"{len(RESULTS) - len(fails)}/{len(RESULTS)} engine expectations hold.")
    if fails:
        print("FAILED:")
        for _, name, detail in fails:
            print("  -", name, detail)
    shutil.rmtree(tmp, ignore_errors=True)
    return 1 if fails else 0


if __name__ == "__main__":
    sys.exit(main())
