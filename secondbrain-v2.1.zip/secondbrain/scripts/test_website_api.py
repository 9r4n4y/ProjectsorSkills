"""SecondBrain v2 website API test.

Starts the real server on a random port against a THROWAWAY copy of the
project and exercises every GET/POST route the UI uses.

Run:  python3 scripts/test_website_api.py
"""
from __future__ import annotations

import json
import shutil
import subprocess
import sys
import tempfile
import time
import urllib.request
from pathlib import Path

SRC = Path(__file__).resolve().parent.parent
if not (SRC / "core").exists() or not (SRC / "database").exists():
    SRC = Path("/home/z/my-project/secondbrain")  # developer fallback
PORT = 8791
BASE = f"http://127.0.0.1:{PORT}"
RESULTS = []


def check(name, ok, detail=""):
    RESULTS.append((ok, name, detail))
    print(f"[{'PASS' if ok else 'FAIL'}] {name}" + (f" -> {detail}" if detail else ""))


def get(path):
    with urllib.request.urlopen(BASE + path, timeout=15) as r:
        return r.status, json.loads(r.read().decode("utf-8"))


def post(path, body):
    req = urllib.request.Request(
        BASE + path, data=json.dumps(body).encode("utf-8"),
        headers={"Content-Type": "application/json"}, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=30) as r:
            return r.status, json.loads(r.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        return e.code, json.loads(e.read().decode("utf-8"))


def main() -> int:
    tmp = Path(tempfile.mkdtemp(prefix="sb-web-"))
    work = tmp / "secondbrain"
    shutil.copytree(SRC, work, ignore=shutil.ignore_patterns(
        ".cache", "__pycache__", ".versions"))

    proc = subprocess.Popen(
        [sys.executable, str(work / "website" / "server.py"),
         "--port", str(PORT), "--no-browser"],
        cwd=str(work), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    try:
        for _ in range(60):
            try:
                get("/api/state")
                break
            except Exception:
                time.sleep(0.4)

        s, j = get("/api/state")
        check("GET /api/state", s == 200 and j["notes"] >= 6, str(j["notes"]))
        check("state has no verification fields", "status" not in json.dumps(j).lower()
              or "verified" not in json.dumps(j))

        s, j = get("/api/search?q=quick%20pasta")
        check("GET /api/search ranks pasta first",
              j["results"][0]["title"] == "Quick Vegetable Pasta for Weeknights")
        s, j = get("/api/search?q=pasta&mode=strict_tag&tags=FOOD-pasta-vegetarian")
        check("search with tags param works", s == 200)
        s, j = get("/api/suggest?q=pa")
        check("GET /api/suggest returns flat suggestions",
              all("parent" not in x or True for x in j["suggestions"])
              and j["suggestions"])
        s, j = get("/api/tags")
        check("GET /api/tags returns flat rows with majors",
              isinstance(j["rows"], list) and all("major" in r for r in j["rows"]))
        s, j = get("/api/folders")
        check("GET /api/folders", s == 200 and "tree" in j and "subjects" in j)
        s, j = get("/api/folder/browse?path=Recipes")
        check("GET /api/folder/browse lists notes with tags",
              s == 200 and len(j["notes"]) == 3
              and all("tags" in n for n in j["notes"]))
        s, j = get("/api/note?path=Garlic%20Bread")
        check("GET /api/note includes tags + body_offset, no backlinks",
              j["tags"] and isinstance(j["body_offset"], int) and "backlinks" not in j)
        s, j = get("/api/connections?path=Garlic%20Bread")
        check("GET /api/connections returns rich connection cards",
              s == 200 and "connections" in j)
        s, j = get("/api/graph")
        check("GET /api/graph", s == 200 and j["nodes"])
        s, j = get("/api/health")
        check("GET /api/health works (the 'add' bug is fixed)",
              s == 200 and isinstance(j["summary"]["score"], int))
        s, j = get("/api/logs?limit=5")
        check("GET /api/logs", s == 200 and isinstance(j["logs"], list))
        s, j = get("/api/master_tags")
        check("GET /api/master_tags", s == 200 and "text" in j)
        # /api/export returns a text attachment; check via plain GET
        with urllib.request.urlopen(BASE + "/api/export?path=Garlic%20Bread") as r:
            text = r.read().decode("utf-8")
        check("GET /api/export has flat tags and no backlinks",
              "Tags:" in text and "Backlinks" not in text and "Status" not in text)

        # POST flows
        s, j = post("/api/note/create", {"folder": "Recipes",
                                         "name": "API Test Note",
                                         "tags": ["MOOD-apitest"]})
        check("POST note/create (user tags auto-sync to master)",
              s == 200 and j.get("proposed_tags") == []
              and "MOOD-apitest" in (work / "_tags.md").read_text())
        s, j = post("/api/note/save", {"path": j["path"],
                                       "text": "# API Test Note\n\n- [ ] tick me\n- body"})
        check("POST note/save", s == 200 and j.get("ok"))
        s, j = get("/api/note?path=API%20Test%20Note")
        s, j = post("/api/note/toggle_task", {"path": "API Test Note", "index": 0})
        check("POST note/toggle_task ticks the checklist", s == 200 and j.get("checked"))
        s, j = post("/api/fix/broken_link", {"path": "API Test Note",
                                             "link": "Ghost Link"})
        check("POST fix/broken_link runs", s == 200)
        s, j = post("/api/tags/edit", {"path": "API Test Note", "add": ["EXTRA-tag"]})
        check("POST tags/edit + auto-sync", s == 200 and j["proposed"] == [])
        s, j = post("/api/tags/master/add", {"tags": ["BRAND-new"]})
        check("POST tags/master/add", s == 200 and j.get("added") == ["BRAND-new"])
        s, j = post("/api/connections", {"path": "API Test Note",
                                         "add": ["Garlic Bread"]})
        check("POST connections add", s == 200 and "Garlic Bread" in j["connected"])
        s, j = post("/api/references", {"path": "API Test Note",
                                        "add": {"title": "", "url": "example.com/x"}})
        check("POST references auto-https",
              s == 200 and j["references"][-1]["url"] == "https://example.com/x")
        s, j = post("/api/subject/save", {"path": "Recipes",
                                          "text": "Purpose: api test"})
        check("POST subject/save", s == 200)
        s, j = post("/api/folder/create", {"parent": "Recipes", "name": "Desserts"})
        check("POST folder/create", s == 200)
        s, j = post("/api/note/move", {"path": "API Test Note", "folder": "Recipes/Desserts"})
        check("POST note/move to the new folder", s == 200 and "Desserts" in j["path"])
        check("moved note keeps its .md name in sync",
              (work / "database/Recipes/Desserts/API Test Note/API Test Note.md").exists())
        s, j = post("/api/note/delete", {"path": "API Test Note"})
        check("POST note/delete", s == 200)
        s, j = post("/api/undo", {"log": sorted(
            (work / "logs").glob("*Deleted_note*"))[-1].name})
        check("POST undo restores the deleted note",
              s == 200 and (work / "database/Recipes/Desserts/API Test Note").exists())

        # backup through the API
        target = tmp / "web-backup"
        target.mkdir()
        s, j = post("/api/backup/preview", {"to": str(target), "scope": "whole"})
        check("POST backup/preview", s == 200 and "preview" in j)
        s, j = post("/api/backup/run", {"to": str(target), "scope": "whole"})
        check("POST backup/run verifies every hash", s == 200 and j.get("ok"))
        s, j = post("/api/backup/verify", {"to": str(target), "scope": "whole"})
        check("POST backup/verify returns per-file report",
              s == 200 and j.get("ok") and all("project_sha256" in f for f in j["files"]))

        # static assets serve
        for asset in ("/static/style.css?v=20", "/static/js/api.js?v=20",
                      "/static/js/app.js?v=20", "/static/js/md.js?v=20",
                      "/static/js/note.js?v=20", "/static/js/views.js?v=20",
                      "/"):
            with urllib.request.urlopen(BASE + asset) as r:
                ok = r.status == 200 and r.read()
            check(f"static {asset.split('/')[-1]}", bool(ok))
    finally:
        proc.terminate()
        proc.wait(timeout=5)
        shutil.rmtree(tmp, ignore_errors=True)

    print()
    fails = [r for r in RESULTS if not r[0]]
    print(f"{len(RESULTS) - len(fails)}/{len(RESULTS)} website API expectations hold.")
    if fails:
        print("FAILED:")
        for _, name, detail in fails:
            print("  -", name, detail)
    return 1 if fails else 0


if __name__ == "__main__":
    sys.exit(main())
