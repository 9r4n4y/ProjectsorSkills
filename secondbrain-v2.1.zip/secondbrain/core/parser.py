"""SecondBrain core: note file parser.

Standard note layout (StructureOFnotes.md):

    # Title
    :::quick-info ... :::          (optional quick info card)
    body text (any Markdown), optional '## My notes' (append-only)
    ## Connected notes             (one [[File Name]] per line)
    ## Reference sources           (one [Title](url) - accessed date per line)
    :::meta ... :::                (Status/Created/Updated/Pinned/AI)

The parser is the ONE parser shared by the website, the MCP server and the
backup tool (spec 17).
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field

from .textutil import normalize

WIKI_LINK_RE = re.compile(r"\[\[([^\]|]+)(?:\|([^\]]+))?\]\]")
MD_LINK_RE = re.compile(r"\[([^\]]+)\]\((https?://[^)\s]+)\)")
META_LINE_RE = re.compile(r"^([A-Za-z][A-Za-z0-9 _-]*):\s*(.*)$")

STANDARD_SECTIONS = ["My notes", "Connected notes", "Reference sources"]
ALIAS_LABELS = {"common name", "aliases", "also known as", "aka", "title aliases"}


@dataclass
class QuickInfoRow:
    label: str
    value: str
    group: str | None = None


@dataclass
class NoteDoc:
    rel_path: str = ""                 # database/<Subject>/.../<Name>/<Name>.md
    title: str = ""                    # file stem = note name
    raw: str = ""
    body: str = ""                     # main text without blocks/panels
    quick_info_raw: str | None = None
    quick_info_rows: list[QuickInfoRow] = field(default_factory=list)
    headings: list[tuple[int, str]] = field(default_factory=list)   # body headings
    connected: list[str] = field(default_factory=list)              # explicit [[links]]
    linked_in_text: list[tuple[str, str]] = field(default_factory=list)  # (target, word)
    references: list[dict] = field(default_factory=list)            # {title,url,accessed}
    meta: dict = field(default_factory=dict)                        # status, created, ...
    my_notes: str = ""
    has_quick_info: bool = False


# --------------------------------------------------------------------------
# Block extraction
# --------------------------------------------------------------------------

_BLOCK_RE = re.compile(r"^:::(quick-info|meta)[ \t]*\n(.*?)\n:::[ \t]*$",
                       re.MULTILINE | re.DOTALL)


def extract_blocks(text: str) -> tuple[str, str | None, dict]:
    """Return (remaining_text, quick_info_raw, meta_dict)."""
    qi = None
    meta: dict = {}

    def repl(m):
        nonlocal qi, meta
        kind, content = m.group(1), m.group(2)
        if kind == "quick-info" and qi is None:
            qi = content
        elif kind == "meta":
            meta.update(parse_meta(content))
        return ""      # remove from body

    remaining = _BLOCK_RE.sub(repl, text)
    return remaining, qi, meta


def parse_meta(content: str) -> dict:
    meta: dict = {}
    for line in content.splitlines():
        m = META_LINE_RE.match(line.strip())
        if m:
            meta[m.group(1).strip().lower()] = m.group(2).strip()
    return meta


def render_meta(meta: dict) -> str:
    order = ["status", "created", "updated", "pinned", "ai"]
    lines = []
    for k in order:
        if k in meta and meta[k] != "":
            lines.append(f"{k.capitalize()}: {meta[k]}")
    for k, v in meta.items():
        lk = k.lower()
        if lk not in order and v != "":
            lines.append(f"{k}: {v}")
    return ":::meta\n" + "\n".join(lines) + "\n:::"


# --------------------------------------------------------------------------
# Quick info
# --------------------------------------------------------------------------

def parse_quick_info(content: str) -> list[QuickInfoRow]:
    rows: list[QuickInfoRow] = []
    group = None
    for raw in (content or "").splitlines():
        line = raw.strip()
        if not line:
            continue
        if line.startswith("##"):
            group = line.lstrip("#").strip()
            continue
        if re.match(r"^Image:\s*", line, re.IGNORECASE):
            rows.append(QuickInfoRow("Image", re.sub(r"^Image:\s*", "", line, flags=re.IGNORECASE), group))
            continue
        m = re.match(r"^([^:]{1,60}):\s*(.*)$", line)
        if m:
            rows.append(QuickInfoRow(m.group(1).strip(), m.group(2).strip(), group))
        else:
            if rows:
                rows[-1].value += " " + line
    return rows


def qi_label_rows(rows: list[QuickInfoRow]) -> list[str]:
    """Labels count like headings in search (spec 13)."""
    out = []
    for r in rows:
        if r.label.lower() != "image":
            out.append(r.label)
            if r.group:
                out.append(r.group)
    return out


def qi_value_rows(rows: list[QuickInfoRow]) -> list[str]:
    return [r.value for r in rows if r.label.lower() != "image"]


def qi_aliases(rows: list[QuickInfoRow]) -> list[str]:
    out = []
    for r in rows:
        if r.label.lower() in ALIAS_LABELS:
            out.append(r.value)
    return out


def qi_image(rows: list[QuickInfoRow]) -> str | None:
    for r in rows:
        if r.label.lower() == "image" and r.value.strip():
            return r.value.strip()
    return None


# --------------------------------------------------------------------------
# Sections and panels
# --------------------------------------------------------------------------

def split_sections(text: str) -> tuple[list[tuple[int, str, list[str]]], str]:
    """Split body into (level, title, lines) sections. Returns
    (sections, before_first_heading). Level 2+ only (# title excluded)."""
    sections: list[tuple[int, str, list[str]]] = []
    current: tuple | None = None
    before: list[str] = []
    for line in text.splitlines():
        m = re.match(r"^(#{2,6})\s+(.*?)\s*#*\s*$", line)
        if m:
            if current:
                sections.append(current)
            current = (len(m.group(1)), m.group(2), [])
        elif current is None:
            before.append(line)
        else:
            current[2].append(line)
    if current:
        sections.append(current)
    return sections, "\n".join(before)


def parse_connected(lines: list[str]) -> list[str]:
    out = []
    for line in lines:
        for m in WIKI_LINK_RE.finditer(line):
            target = m.group(1).strip()
            if target and target not in out:
                out.append(target)
    return out


def parse_references(lines: list[str]) -> list[dict]:
    refs = []
    for line in lines:
        line = line.strip().lstrip("-* ").strip()
        m = MD_LINK_RE.search(line)
        if m:
            accessed = ""
            am = re.search(r"[-—–]\s*(?:accessed\s*)?(\d{4}-\d{2}-\d{2}.*)$", line)
            if am:
                accessed = am.group(1).strip()
            refs.append({"title": m.group(1).strip(), "url": m.group(2).strip(),
                         "accessed": accessed})
    return refs


# --------------------------------------------------------------------------
# Full parse
# --------------------------------------------------------------------------

def parse_note(text: str, rel_path: str = "") -> NoteDoc:
    doc = NoteDoc(rel_path=rel_path, raw=text)
    name = rel_path.rsplit("/", 1)[-1]
    doc.title = name[:-3] if name.endswith(".md") else name

    remaining, qi_raw, meta = extract_blocks(text)
    doc.quick_info_raw = qi_raw
    doc.meta = meta
    if qi_raw is not None:
        doc.has_quick_info = True
        doc.quick_info_rows = parse_quick_info(qi_raw)

    sections, before = split_sections(remaining)
    doc.headings = [(lvl, title) for lvl, title, _ in sections]

    connected_lines: list[str] = []
    reference_lines: list[str] = []
    my_lines: list[str] = []
    body_parts: list[str] = [before.strip()] if before.strip() else []

    for lvl, title, lines in sections:
        low = normalize(title)
        if low == "connected notes":
            connected_lines = lines
        elif low == "reference sources":
            reference_lines = lines
        elif low == "my notes":
            my_lines = lines
            body_parts.append("## " + title + "\n" + "\n".join(lines))
        else:
            body_parts.append("## " + title + "\n" + "\n".join(lines))

    doc.body = "\n\n".join(body_parts).strip()
    doc.my_notes = "\n".join(my_lines).strip()
    doc.connected = parse_connected(connected_lines)
    doc.references = parse_references(reference_lines)

    # Wiki links written inside the text (linked in text) with their word.
    for m in WIKI_LINK_RE.finditer(doc.body):
        target = m.group(1).strip()
        word = (m.group(2) or target).strip()
        if target and target != doc.title:
            doc.linked_in_text.append((target, word))

    return doc


def read_note(path) -> NoteDoc:
    from . import paths
    p = paths.ROOT / path if not str(path).startswith("/") else None
    text = (p or path).read_text(encoding="utf-8")
    rp = paths.rel(p or path)
    return parse_note(text, rp)
