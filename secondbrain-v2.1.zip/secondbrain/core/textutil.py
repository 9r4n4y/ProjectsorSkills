"""SecondBrain core: text utilities.

Normalization, tokenizer, a small deterministic stemmer, edit distance and
deletion buckets for typo tolerance. Pure standard library.
"""
from __future__ import annotations

import re
import unicodedata

# Filler words are dropped from queries. Negations are NEVER dropped because
# they change meaning (spec 3.3 step 1).
FILLER = {
    "the", "a", "an", "of", "and", "or", "to", "in", "on", "at", "for",
    "with", "is", "are", "was", "were", "be", "been", "it", "its", "that",
    "this", "these", "those", "my", "i", "me", "we", "our", "you", "your",
}
KEEP_WORDS = {"no", "not", "without", "never", "nor"}

_WORD_RE = re.compile(r"[a-z0-9]+")


def strip_accents(s: str) -> str:
    """Remove accents: e-acute -> e (NFKD then drop combining marks)."""
    return "".join(c for c in unicodedata.normalize("NFKD", s or "")
                   if not unicodedata.combining(c))


def normalize(s: str) -> str:
    """Lowercase, strip accents, treat underscores and dashes as spaces,
    drop everything that is not a letter or digit, squeeze spaces."""
    s = strip_accents(s or "").lower()
    s = re.sub(r"[_\-\u2010-\u2015]+", " ", s)
    s = "".join(ch if (ch.isalnum() and ch.isascii()) or ch == " " else " " for ch in s)
    return re.sub(r"\s+", " ", s).strip()


def normalize_keep_case(s: str) -> str:
    s = strip_accents(s or "")
    s = re.sub(r"[_\-]+", " ", s)
    return re.sub(r"\s+", " ", s).strip()


def tokenize(s: str) -> list[str]:
    """Split already-normalized text into word tokens."""
    return _WORD_RE.findall(normalize(s))


def stem(w: str) -> str:
    """Small, deterministic stemmer so plurals and endings match
    (recipe/recipes, dish/dishes, cook/cooking/cooked)."""
    if len(w) <= 3:
        return w
    if w.endswith("ies") and len(w) > 4:
        w = w[:-3] + "y"
    elif w.endswith("sses") and len(w) > 4:
        w = w[:-2]
    elif w.endswith(("ches", "shes", "xes", "zes", "ses")) and len(w) > 4:
        w = w[:-2]                      # dishes -> dish, boxes -> box
    elif w.endswith("s") and len(w) > 3 and not w.endswith(("ss", "us", "is")):
        w = w[:-1]                      # recipes -> recipe
    if len(w) > 5 and w.endswith("ing"):
        w = w[:-3]
        w = _restore_e(w)
    elif len(w) > 4 and w.endswith("ed"):
        w = w[:-2]
        w = _restore_e(w)
    if len(w) > 3 and w[-1] == w[-2] and w[-1] not in "lsf":
        w = w[:-1]                      # stopped -> stop, planning -> plan
    return w


def _restore_e(w: str) -> str:
    """baking -> bake (consonant-vowel-consonant gets a silent e back)."""
    if len(w) >= 3 and w[-1] not in "aeiouwxy" and w[-2] in "aeiou" and w[-3] not in "aeiou":
        return w + "e"
    return w


def stem_tokens(tokens: list[str]) -> list[str]:
    return [stem(t) for t in tokens]


def levenshtein_leq1(a: str, b: str) -> bool:
    """True when a and b differ by at most one letter
    (one substitution, insertion or deletion)."""
    if a == b:
        return True
    la, lb = len(a), len(b)
    if abs(la - lb) > 1:
        return False
    if la > lb:
        a, b, la, lb = b, a, lb, la
    i = j = diff = 0
    while i < la and j < lb:
        if a[i] == b[j]:
            i += 1
            j += 1
        else:
            diff += 1
            if diff > 1:
                return False
            if la == lb:
                i += 1
                j += 1
            else:
                j += 1          # skip one char in the longer word
    return True


def deletion_variants(w: str) -> set[str]:
    """The word itself plus every one-letter deletion. Two words within
    edit distance 1 always share at least one variant."""
    return {w} | {w[:i] + w[i + 1:] for i in range(len(w))}


def jaccard(a: set, b: set) -> float:
    if not a and not b:
        return 0.0
    if not a or not b:
        return 0.0
    return len(a & b) / len(a | b)


def key_of(name: str) -> str:
    """Case-insensitive uniqueness key (accent-normalized)."""
    return unicodedata.normalize("NFKD", (name or "").strip().casefold())


def truncate(s: str, n: int = 160) -> str:
    s = (s or "").strip()
    return s if len(s) <= n else s[: n - 1].rstrip() + "…"
