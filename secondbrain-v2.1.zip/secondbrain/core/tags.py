"""SecondBrain core: tags.

Tags are INDEPENDENT labels (v2 change): there is no sub-tag hierarchy any
more. A tag is one plain name such as FOOD-pasta or garden; the dash is
just part of the name, nothing to the right of it is "inside" anything.
Matching ignores case. _tags.md is the master vocabulary with approved
tags (the ### headings are display categories only), per-tag synonyms, a
general synonym map and a Proposed tags section.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path

from . import paths
from .textutil import key_of, levenshtein_leq1, normalize

TAG_RE = re.compile(r"^[A-Za-z0-9_]+(?:-[A-Za-z0-9_]+)*$")


class TagError(ValueError):
    pass


def validate_tag(tag: str) -> str:
    tag = (tag or "").strip()
    if not tag:
        raise TagError("Empty tag.")
    if not TAG_RE.match(tag):
        raise TagError(
            f"Tag {tag!r} is not valid. Use letters, digits and underscores; "
            "dashes separate levels; spaces are written as underscores; no commas.")
    return tag


def tag_parts(tag: str) -> list[str]:
    return [p for p in validate_tag(tag).split("-") if p]


def major_of(tag: str) -> str:
    """Display category of a tag: the part before the first dash.
    Purely cosmetic grouping for the tag browser; the tag itself stays
    independent."""
    return tag_parts(tag)[0] if tag_parts(tag) else tag


def norm_tag(tag: str) -> str:
    """Canonical form for matching: case is ignored, so we keep the written
    form but compare through key_of."""
    return (tag or "").strip()


def same_tag(a: str, b: str) -> bool:
    return key_of(a) == key_of(b)


def is_descendant(tag: str, ancestor: str) -> bool:
    """Backwards-compatible alias: with independent tags a tag only
    "descends" from itself."""
    return key_of(tag) == key_of(ancestor)


def relation(note_tag: str, query_tag: str) -> float | None:
    """Score of a (note tag, query tag) pair. Tags are independent, so
    only an exact (case-insensitive) match counts: 1.0, otherwise None."""
    return 1.0 if key_of(note_tag) == key_of(query_tag) else None


# --------------------------------------------------------------------------
# tags.txt
# --------------------------------------------------------------------------

def parse_tags_txt(text: str) -> list[str]:
    """Parse a tags.txt body: comma separated tags, one or more per line."""
    tags: list[str] = []
    seen: set[str] = set()
    for chunk in re.split(r"[,\n]", text or ""):
        t = chunk.strip()
        if not t:
            continue
        validate_tag(t)
        k = key_of(t)
        if k not in seen:
            seen.add(k)
            tags.append(t)
    return tags


def render_tags_txt(tags: list[str]) -> str:
    return ", ".join(tags) + "\n"


# --------------------------------------------------------------------------
# _tags.md master vocabulary
# --------------------------------------------------------------------------

@dataclass
class MasterTags:
    approved: dict[str, dict] = field(default_factory=dict)   # key -> {tag, synonyms, major}
    proposed: list[str] = field(default_factory=list)
    general_synonyms: dict[str, list[str]] = field(default_factory=dict)
    order: list[str] = field(default_factory=list)            # approved tags in file order

    def has(self, tag: str) -> bool:
        return key_of(tag) in self.approved

    def all_tags(self) -> list[str]:
        return [v["tag"] for v in self.approved.values()]


def parse_master(text: str) -> MasterTags:
    mt = MasterTags()
    section = None
    current_major = None
    for raw in (text or "").splitlines():
        line = raw.strip()
        if not line:
            continue
        low = line.lower()
        if low.startswith("## "):
            title = low[3:].strip()
            section = ("proposed" if "proposed" in title
                       else "synonyms" if "synonym" in title
                       else "approved")
            current_major = None
            continue
        if section == "approved":
            if low.startswith("### "):
                current_major = line[4:].strip()
                continue
            if line.startswith("- "):
                entry = line[2:].strip()
                tag, syn = entry, []
                if ":" in entry:
                    tag, syn_part = entry.split(":", 1)
                    tag = tag.strip()
                    syn = [s.strip() for s in syn_part.split(",") if s.strip()]
                try:
                    validate_tag(tag)
                except TagError:
                    continue
                k = key_of(tag)
                if k not in mt.approved:
                    mt.approved[k] = {
                        "tag": tag, "synonyms": syn,
                        "major": current_major or tag_parts(tag)[0],
                    }
                    mt.order.append(k)
            continue
        if section == "proposed":
            if line.startswith("- "):
                t = line[2:].strip().split(":")[0].strip()
                try:
                    validate_tag(t)
                    if t not in mt.proposed:
                        mt.proposed.append(t)
                except TagError:
                    pass
            continue
        if section == "synonyms":
            if ":" in line and not line.startswith(("#", "<")):
                word, syn = line.split(":", 1)
                w = normalize(word)
                syns = [normalize(s) for s in syn.split(",") if normalize(s)]
                if w and syns:
                    mt.general_synonyms.setdefault(w, [])
                    for s in syns:
                        if s not in mt.general_synonyms[w]:
                            mt.general_synonyms[w].append(s)
    return mt


def load_master() -> MasterTags:
    return parse_master((paths.ROOT / "_tags.md").read_text(encoding="utf-8"))


def tag_synonym_to_tag(mt: MasterTags) -> dict[str, str]:
    """Map every approved tag name and every per-tag synonym (normalized) to
    the canonical tag."""
    out: dict[str, str] = {}
    for v in mt.approved.values():
        names = [v["tag"]] + list(v["synonyms"])
        for name in names:
            n = normalize(name).replace(" ", "-")
            out.setdefault(n, v["tag"])
            out.setdefault(normalize(name).replace(" ", "_"), v["tag"])
    return out


# --------------------------------------------------------------------------
# Auto tag extractor (spec 3.5)
# --------------------------------------------------------------------------

def extract_all_notes_tags() -> dict:
    """Scan the whole wiki and build the live list of every tag in use,
    with counts and hierarchy; flag unapproved tags, near-duplicates and
    tags missing from _tags.md."""
    mt = load_master()
    used: dict[str, int] = {}
    per_note: dict[str, list[str]] = {}
    for tags_file in sorted(paths.DATABASE.rglob("tags.txt")):
        tags = parse_tags_txt(tags_file.read_text(encoding="utf-8"))
        note_dir = tags_file.parent.name
        per_note[str(tags_file.parent.relative_to(paths.DATABASE))] = tags
        for t in tags:
            used[t] = used.get(t, 0) + 1

    unapproved = sorted(t for t in used if not mt.has(t))
    approved_used = [t for t in used if mt.has(t)]

    # Near-duplicates: two different tags within one letter of each other.
    near: list[dict] = []
    keys = sorted(used)
    norm_of = {t: normalize(t.replace("_", " ").replace("-", " ")) for t in keys}
    for i, a in enumerate(keys):
        for b in keys[i + 1:]:
            if key_of(a) == key_of(b):
                continue
            if levenshtein_leq1(norm_of[a].replace(" ", ""),
                                norm_of[b].replace(" ", "")):
                near.append({"tags": [a, b]})

    # Flat, independent tag list (v2): no hierarchy, one row per tag.
    rows = [{"tag": t, "count": used[t], "major": major_of(t), "approved": mt.has(t)}
            for t in sorted(used, key=lambda x: key_of(x))]

    missing_master = sorted(t for t in used if not mt.has(t))
    used_once = sorted(t for t, c in used.items() if c == 1)
    return {
        "tags": sorted(used, key=lambda x: key_of(x)),
        "counts": used,
        "rows": rows,
        "majors": sorted({major_of(t) for t in used}),
        "unapproved": unapproved,
        "near_duplicates": near,
        "missing_from_master": missing_master,
        "used_once": used_once,
        "proposed": mt.proposed,
        "per_note": per_note,
        "approved_unused": [v["tag"] for v in mt.approved.values()
                            if not any(key_of(t) == k for t in used for k in [key_of(t)])],
    }


def tags_list_for_ui() -> list[dict]:
    """Flat tag rows for the website: every tag in use with its count and
    display category. Independent tags, nothing nested."""
    ext = extract_all_notes_tags()
    return ext["rows"]
