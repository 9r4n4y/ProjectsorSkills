"""SecondBrain core: images (spec 11).

Images live in a note's attachments/ folder. The website does cropping in
the browser (canvas) and uploads the result; the MCP crop_image tool uses
Pillow when it is installed and reports a clear error when it is not. A crop
is saved as a NEW image - the original is backed up first, never silently
overwritten (spec 19, decision 7).
"""
from __future__ import annotations

import datetime as _dt
import re
import shutil

from . import logger, paths, store

try:
    from PIL import Image  # type: ignore
    HAS_PIL = True
except Exception:            # pragma: no cover
    HAS_PIL = False


def attachment_path(note_rel: str, filename: str) -> paths.Path:
    note_md = store.note_md_path(note_rel)
    att = note_md.parent / "attachments"
    name = paths.Path(filename).name
    if not paths.is_image(name):
        raise ValueError("attachments/ holds image files only.")
    return att / name


def add_attachment(note_rel: str, filename: str, data: bytes,
                   who: str = "user") -> dict:
    """Add an image to a note's attachments/ folder."""
    target = attachment_path(note_rel, filename)
    target.parent.mkdir(parents=True, exist_ok=True)
    if target.exists():
        stem, ext = target.stem, target.suffix
        target = target.with_name(f"{stem}-{_dt.datetime.now().strftime('%H%M%S')}{ext}")
    tmp = target.with_suffix(target.suffix + ".tmp")
    tmp.write_bytes(data)
    tmp.replace(target)
    logger.new_log(who, f"Added attachment {target.name}",
                   f"- Note: `{note_rel}`\n- File: `{paths.rel(target)}` "
                   f"({len(data)} bytes)",
                   undo={"title": f"Add attachment {target.name}", "steps": [
                       {"op": "write", "path": paths.rel(target), "before": None}]})
    return {"file": f"attachments/{target.name}", "bytes": len(data)}


def crop_image(note_rel: str, filename: str, rect: dict,
               mode: str = "keep_both", who: str = "user") -> dict:
    """Crop = save as a new image, then either replace the original in this
    note (the old image is backed up first) or keep both (spec 11)."""
    if not HAS_PIL:
        raise RuntimeError("crop_image needs the optional Pillow package "
                           "(pip install Pillow). The website crops images "
                           "in the browser and does not need it.")
    src = attachment_path(note_rel, filename)
    if not src.exists():
        raise FileNotFoundError(f"Image {filename} not found in {note_rel}.")
    x, y = max(0, int(rect.get("x", 0))), max(0, int(rect.get("y", 0)))
    w, h = int(rect.get("w", 0)), int(rect.get("h", 0))
    with Image.open(src) as im:
        W, H = im.size
        x, y = min(x, W - 1), min(y, H - 1)
        w, h = min(w, W - x), min(h, H - y)
        if w < 2 or h < 2:
            raise ValueError("Crop rectangle is too small.")
        cropped = im.crop((x, y, x + w, y + h))
        stamp = _dt.datetime.now().strftime("%Y%m%d-%H%M%S")
        stem, ext = src.stem, src.suffix.lower()
        new_name = f"{stem}-crop-{stamp}{ext if ext != '.jpg' else '.jpg'}"
        new_path = src.parent / new_name
        tmp = new_path.with_suffix(new_path.suffix + ".tmp")
        convert = {"jpg": "JPEG", "jpeg": "JPEG", "png": "PNG", "webp": "WEBP",
                   "gif": "GIF", "bmp": "BMP"}
        fmt = convert.get(ext.lstrip("."), "PNG")
        cropped.save(tmp, format=fmt)
        tmp.replace(new_path)

        old_renamed = None
        if mode == "replace":
            # back up the original inside attachments/ (kept, never deleted)
            old_renamed = f"{stem}.pre-crop-{stamp}{ext}"
            shutil.move(str(src), str(src.parent / old_renamed))
            shutil.move(str(new_path), str(src))
    logger.new_log(who, f"Cropped image {filename} in {store.note_md_path(note_rel).stem}",
                   f"- Note: `{note_rel}`\n- Source: `{paths.rel(src)}`\n"
                   f"- Rectangle: x={x}, y={y}, w={w}, h={h}\n"
                   f"- New image: `{paths.rel(new_path)}`\n"
                   f"- Mode: {'replace (original kept as ' + old_renamed + ')' if mode == 'replace' else 'keep both'}",
                   undo={"title": f"Crop {filename}", "steps": [
                       {"op": "write", "path": paths.rel(new_path), "before": None}]})
    out = {"new_image": f"attachments/{new_name}", "w": w, "h": h}
    if old_renamed:
        out["original_backed_up_as"] = f"attachments/{old_renamed}"
    return out


def thumb_path(src, width: int):
    """Cache location for a thumbnail (core/.cache/thumbs/, generated)."""
    stamp = f"{src.stat().st_size}-{int(src.stat().st_mtime)}"
    return paths.CACHE / "thumbs" / f"{src.stem}-{stamp}-w{width}.png"


def thumbnail(src, width: int = 480):
    """The image grid uses thumbnails; the full file loads only in full
    screen (spec 17). Returns a thumbnail path, or the original when no
    Pillow is available (the browser scales it down instead)."""
    if not HAS_PIL:
        return src
    width = max(80, min(int(width), 1600))
    out = thumb_path(src, width)
    if out.exists():
        return out
    with Image.open(src) as im:
        ratio = width / im.width if im.width else 1
        small = im.convert("RGB") if src.suffix.lower() in {".jpg", ".jpeg"} else im
        small = small.resize((width, max(1, int(im.height * ratio))),
                             Image.LANCZOS)
        out.parent.mkdir(parents=True, exist_ok=True)
        tmp = out.with_suffix(".tmp")
        small.save(tmp, format="PNG")
        tmp.replace(out)
    return out


def delete_image(note_rel: str, filename: str, who: str = "user") -> dict:
    """Delete asks for confirmation in the UI; the file itself is kept in
    backup history by renaming it inside attachments/ (spec 11)."""
    src = attachment_path(note_rel, filename)
    if not src.exists():
        raise FileNotFoundError(f"Image {filename} not found in {note_rel}.")
    md = store.note_md_path(note_rel)
    text = md.read_text(encoding="utf-8")
    if re.search(re.escape(filename), text):
        return {"warning": True,
                "message": "This note still points to the image in its text. "
                           "Remove or change that image Markdown first, or "
                           "confirm you want to delete it anyway."}
    stamp = _dt.datetime.now().strftime("%Y%m%d-%H%M%S")
    kept = src.with_name(f"{src.stem}.deleted-{stamp}{src.suffix}")
    shutil.move(str(src), str(kept))
    logger.new_log(who, f"Deleted image {filename}",
                   f"- Note: `{note_rel}`\n- Removed `{paths.rel(src)}`\n"
                   f"- Kept in backup history as `{paths.rel(kept)}`",
                   undo={"title": f"Delete image {filename}", "steps": [
                       {"op": "move", "from": paths.rel(src), "to": paths.rel(kept)}]})
    return {"deleted": True, "kept_as": f"attachments/{kept.name}"}
