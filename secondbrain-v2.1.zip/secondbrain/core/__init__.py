# SecondBrain core engine: parser, index, search, tag extractor, checks.
# One engine shared by the website, the MCP server and the backup tool.
