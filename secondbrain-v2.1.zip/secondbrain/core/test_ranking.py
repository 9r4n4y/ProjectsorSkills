"""SecondBrain core: the fixed ranking test set (spec 3.4).

"A fixed test set of queries with expected top results protects against
ranking regressions."  Run:  python3 core/test_ranking.py
(returns non-zero exit code when any expectation fails)
"""
from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from core import indexer, search  # noqa: E402

PASTA = "database/Recipes/Quick Vegetable Pasta for Weeknights/Quick Vegetable Pasta for Weeknights.md"
GARLIC = "database/Recipes/Garlic Bread/Garlic Bread.md"
SOUP = "database/Recipes/Lentil Soup for Cold Evenings/Lentil Soup for Cold Evenings.md"
SPANISH = "database/Learning/Languages/Vocabulary/Spanish Kitchen Words/Spanish Kitchen Words.md"
SETUP = "database/Projects/SecondBrain Setup/SecondBrain Setup.md"
GARDEN = "database/Projects/Garden Plan 2026/Garden Plan 2026.md"

CASES = [
    # (name, kwargs, expected first result)
    ("quick vegetable pasta",
     dict(q="quick vegetable pasta"), PASTA),
    ("single word pasta",
     dict(q="pasta"), PASTA),
    ("garlic side",
     dict(q="garlic"), GARLIC),
    ("synonyms: fast veggie meal",
     dict(q="fast veggie meal"), PASTA),
    ("synonyms: speedy dish",
     dict(q="speedy dish"), PASTA),
    ("typo tolerance: pastha",
     dict(q="pastha"), PASTA),
    ("typo tolerance: lental",
     dict(q="lental"), SOUP),
    ("word endings: recipes matches recipe notes",
     dict(q="recipes"), ("in_top3", PASTA)),
    ("vocabulary words",
     dict(q="vocabulary words"), SPANISH),
    ("project search",
     dict(q="secondbrain setup"), SETUP),
    ("garden tomatoes",
     dict(q="garden tomatoes"), GARDEN),
    ("folder boundary keeps other subjects out",
     dict(q="pasta", folders=["Learning"]), None),
    ("strict keyword mode drops partial matches",
     dict(q="lentil garlic", mode="strict_keyword"), SOUP),
    ("strict tag mode requires all tags",
     dict(q="", tags_sel=["FOOD-pasta-vegetarian"], mode="strict_tag"), PASTA),
    ("strict tag is exact - a different independent tag does not match",
     dict(q="", tags_sel=["FOOD-pasta"], mode="strict_tag"), None),
    ("empty query with tag ranks by tags",
     dict(q="", tags_sel=["INGREDIENT-lentils"]), SOUP),
    ("scope file name only",
     dict(q="bread", scope=["file name"]), GARLIC),
    ("coverage: both groups beat one",
     dict(q="quick pasta"), PASTA),
]

FAILURES = []


def run():
    idx = indexer.load_index()
    for name, kwargs, expected in CASES:
        res = search.search(idx=idx, **kwargs)
        paths = [r["path"] for r in res["results"]]
        if not paths:
            ok = expected is None
            got = "(no results)"
        else:
            if isinstance(expected, tuple) and expected[0] == "in_top3":
                ok = expected[1] in paths[:3]
            elif expected is None:
                # the folder boundary case: result must not be outside folder
                ok = all(p.startswith("database/Learning") for p in paths)
                got = paths[:2]
            else:
                ok = paths[0] == expected
                got = paths[:3]
        status = "PASS" if ok else "FAIL"
        print(f"[{status}] {name:45s} -> {got}")
        if not ok:
            FAILURES.append((name, expected, got))

    # Behavior rules that are not simple top-1 checks.
    res = search.search(idx=idx, q="lentil garlic", mode="strict_keyword")
    only = {r["path"] for r in res["results"]}
    print(f"[{'PASS' if GARLIC not in only else 'FAIL'}] strict keyword removed note "
          f"without every word -> {sorted(only)}")
    if GARLIC in only:
        FAILURES.append(("strict keyword completeness", "only soup", only))

    res = search.search(idx=idx, q="", tags_sel=["FOOD-pasta-vegetarian"], mode="strict_tag")
    only = {r["path"] for r in res["results"]}
    ok = only == {PASTA}
    print(f"[{'PASS' if ok else 'FAIL'}] strict tag FOOD-pasta-vegetarian -> {sorted(only)}")
    if not ok:
        FAILURES.append(("strict tag", {PASTA}, only))

    res = search.search(idx=idx, q="zzzqqq xyzzyq")
    ok = len(res["results"]) > 0 and res["fallback_used"]
    print(f"[{'PASS' if ok else 'FAIL'}] fallback: result never blank -> "
          f"{len(res['results'])} results, fallback={res['fallback_used']}")
    if not ok:
        FAILURES.append(("fallback", "non-empty", res["results"]))

    res = search.search(idx=idx, q="pasta", tags_sel=["FOOD-soup", "FOOD-pasta"],
                        tag_mode="require")
    ok = not res["results"] and res["notice"] and "Require switch on tags" in res["notice"]
    print(f"[{'PASS' if ok else 'FAIL'}] require-mode notice explains removal -> {res['notice']}")
    if not ok:
        FAILURES.append(("require notice", "notice", res.get("notice")))

    r1 = search.search(idx=idx, q="pasta")
    r2 = search.search(idx=idx, q="pasta")
    same = [x["path"] for x in r1["results"]] == [x["path"] for x in r2["results"]]
    print(f"[{'PASS' if same else 'FAIL'}] deterministic order across runs")
    if not same:
        FAILURES.append(("deterministic", "same", "different"))

    bd = r1["results"][0]["breakdown"]
    total = sum(v["points"] for v in bd.values())
    cov = r1["results"][0]["coverage"]
    ok = abs(r1["results"][0]["score"] - 100 * total * cov) < 0.5
    print(f"[{'PASS' if ok else 'FAIL'}] score = 100 x weighted signals x coverage "
          f"(score={r1['results'][0]['score']}, signals={total:.3f}, coverage={cov})")
    if not ok:
        FAILURES.append(("score formula", "match", (r1['results'][0]['score'], total, cov)))

    print()
    if FAILURES:
        print(f"{len(FAILURES)} expectation(s) failed:")
        for name, exp, got in FAILURES:
            print(f"  - {name}: expected {exp!r}, got {got!r}")
        return 1
    print("All ranking expectations hold.")
    return 0


if __name__ == "__main__":
    sys.exit(run())
