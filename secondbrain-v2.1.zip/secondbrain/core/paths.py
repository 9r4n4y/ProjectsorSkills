"""SecondBrain core: project layout, name rules and allowed structure.

The allowed structure (spec 16) is enforced here. Every tool refuses to
create anything outside it, and the health check reports violations.
"""
from __future__ import annotations

import re
import unicodedata
from pathlib import Path

from .textutil import key_of  # noqa: F401  (re-exported for convenience)

# --------------------------------------------------------------------------
# Project layout
# --------------------------------------------------------------------------

def project_root() -> Path:
    """secondbrain/ root (the folder that contains core/)."""
    here = Path(__file__).resolve().parent      # .../secondbrain/core
    root = here.parent
    if (root / "core").exists() and (root / "database").exists():
        return root
    for cand in [here, *here.parents]:
        if (cand / "core").exists() and (cand / "database").exists():
            return cand
    return root


ROOT = project_root()
DATABASE = ROOT / "database"
INBOX = ROOT / "inbox"
LOGS = ROOT / "logs"
CORE = ROOT / "core"
MCP = ROOT / "mcp"
WEBSITE = ROOT / "website"
BACKUP = ROOT / "backup"
CACHE = CORE / ".cache"

ROOT_FILES = ["README.md", "SKILL.md", "StructureOFnotes.md", "_tags.md",
              "FIXES.md"]
TOP_FOLDERS = ["database", "inbox", "logs", "core", "mcp", "website", "backup", "scripts"]

IMAGE_EXTS = {".png", ".jpg", ".jpeg", ".gif", ".webp", ".svg", ".bmp"}

FORBIDDEN_NAME_CHARS = re.compile(r'[\\/:*?"<>|\x00-\x1f]')

# Source files of the project (named in README.md). Everything else in these
# folders is a structure violation.
CORE_FILES = [
    "__init__.py", "paths.py", "textutil.py", "tags.py", "parser.py",
    "store.py", "logger.py", "indexer.py", "search.py", "healthcheck.py",
    "images.py", "test_ranking.py", "settings.json",
]
WEBSITE_FILES = ["server.py"]
WEBSITE_STATIC = ["index.html", "style.css"]
WEBSITE_JS = ["md.js", "api.js", "views.js", "note.js", "app.js"]
MCP_FILES = ["server.py"]
BACKUP_FILES = ["backup.py"]


# --------------------------------------------------------------------------
# Name rules (spec 17: safe on Windows, macOS, Linux)
# --------------------------------------------------------------------------

def clean_name(name: str) -> str:
    """Normalize a note/folder display name. Raises ValueError when the
    name cannot be used on every operating system."""
    name = unicodedata.normalize("NFC", (name or "").strip())
    name = re.sub(r"\s+", " ", name)
    if not name or name in {".", ".."}:
        raise ValueError("Empty name is not allowed.")
    if FORBIDDEN_NAME_CHARS.search(name):
        raise ValueError('Names may not contain \\ / : * ? " < > | or control characters.')
    if name.endswith((" ", ".", ":")):
        name = name.rstrip(" .:")
    if not name:
        raise ValueError("Empty name is not allowed.")
    if len(name) > 120:
        raise ValueError("Name is longer than 120 characters.")
    return name


def rel(path: Path) -> str:
    """Path relative to the project root, always with forward slashes."""
    try:
        return path.resolve().relative_to(ROOT).as_posix()
    except ValueError:
        return str(path)


def safe_join(base: Path, *parts: str) -> Path:
    """Join parts under base and refuse any escape from base (no ..)."""
    p = base
    for part in parts:
        part = (part or "").strip().strip("/")
        if not part or part == "." or part == ".." or FORBIDDEN_NAME_CHARS.search(part):
            raise ValueError(f"Unsafe path element: {part!r}")
        p = p / part
    return p


# --------------------------------------------------------------------------
# Allowed-structure check
# --------------------------------------------------------------------------

def is_image(name: str) -> bool:
    return Path(name).suffix.lower() in IMAGE_EXTS


def check_structure() -> list[dict]:
    """Return a list of {path, problem} for every file or folder that is not
    on the allowed list. Used by the health check page and health_check tool."""
    problems: list[dict] = []

    for child in sorted(ROOT.iterdir()):
        name = child.name
        if child.is_file():
            if name not in ROOT_FILES:
                _add(problems, child, "File not allowed at the top level (allowed: " + ", ".join(ROOT_FILES) + ")")
        elif child.is_dir():
            if name not in TOP_FOLDERS:
                _add(problems, child, "Folder not allowed at the top level (allowed: " + ", ".join(TOP_FOLDERS) + ")")
        else:
            _add(problems, child, "Symlinks and special files are not part of the structure")

    _check_database(problems)
    _check_flat(INBOX, problems)
    _check_logs(problems)
    _check_code_folder(CORE, CORE_FILES, {".cache"}, problems)
    _check_code_folder(MCP, MCP_FILES, set(), problems)
    _check_code_folder(BACKUP, BACKUP_FILES, set(), problems)
    _check_website(problems)
    return problems


def _add(problems: list[dict], p: Path, problem: str):
    """One shared problem recorder - every check below uses this (the old
    code redefined 'add' inside one function only, which crashed the health
    check with NameError: name 'add' is not defined)."""
    problems.append({"path": rel(p), "problem": problem})


def _check_website(problems: list[dict]):
    for child in sorted(WEBSITE.iterdir()):
        if child.name == "__pycache__":
            continue          # Python bytecode cache, not part of the project
        if child.is_dir():
            if child.name != "static":
                _add(problems, child, "Only static/ is allowed inside website/")
            else:
                for f in sorted(child.rglob("*")):
                    rp = f.relative_to(WEBSITE).as_posix()
                    if f.is_dir():
                        if not (rp == "static/vendor" or rp.startswith("static/vendor/")
                                or rp == "static/js"):
                            _add(problems, f, "Unexpected folder inside website/static/")
                    else:
                        if rp in {"static/" + n for n in WEBSITE_STATIC}:
                            continue
                        if rp.startswith("static/js/") and f.suffix == ".js":
                            continue
                        if rp.startswith("static/vendor/") and f.suffix in {
                                ".css", ".js", ".woff", ".woff2", ".ttf", ".map"}:
                            continue
                        _add(problems, f, "Unexpected file inside website/")
        else:
            if child.name not in WEBSITE_FILES:
                _add(problems, child, "Unexpected file inside website/ (allowed: " + ", ".join(WEBSITE_FILES) + ")")


def _check_code_folder(folder: Path, allowed: list[str], allowed_dirs: set, problems: list[dict]):
    if not folder.exists():
        return
    for child in sorted(folder.iterdir()):
        if child.name == "__pycache__":
            continue          # Python bytecode cache, not part of the project
        if child.is_dir():
            if child.name not in allowed_dirs:
                problems.append({"path": rel(child),
                                 "problem": f"Folder not allowed inside {folder.name}/"})
        elif child.name not in allowed:
            problems.append({"path": rel(child),
                             "problem": "File not named in README.md (allowed here: "
                                        + ", ".join(allowed) + ")"})


def _check_database(problems: list[dict]):
    if not DATABASE.exists():
        return
    _check_subject_folder(DATABASE, problems)


def _check_subject_folder(folder: Path, problems: list[dict]):
    """Subject folders nest to any depth (spec 2.1). A folder that holds a
    '<name>.md' file named after itself is a note folder; anything else is a
    subject folder and is recursed into."""

    for child in sorted(folder.iterdir()):
        if child.is_file():
            if child.name == "_subject.md":
                continue
            _add(problems, child, "Only note folders and _subject.md are allowed inside a subject folder")
        elif child.is_dir():
            if (child / (child.name + ".md")).exists():
                _check_note_folder(child, problems)
            else:
                _check_subject_folder(child, problems)


def _check_note_folder(note_dir: Path, problems: list[dict]):
    expected_md = note_dir.name + ".md"
    found_md = False
    for child in sorted(note_dir.iterdir()):
        if child.is_file():
            if child.name == expected_md:
                found_md = True
            elif child.name == "tags.txt":
                continue
            else:
                _add(problems, child, "A note folder may only contain '<Note Name>.md' and 'tags.txt'")
        elif child.is_dir():
            if child.name == "attachments":
                for img in sorted(child.iterdir()):
                    if img.is_file() and not is_image(img.name):
                        _add(problems, img, "attachments/ holds image files only")
                    elif img.is_dir():
                        _add(problems, img, "Folders are not allowed inside attachments/")
            else:
                _add(problems, child, "Only attachments/ is allowed inside a note folder")
    if not found_md and any(note_dir.iterdir()):
        _add(problems, note_dir, "Note folder is missing its '<Note Name>.md' file")


def _check_flat(folder: Path, problems: list[dict]):
    if not folder.exists():
        return
    for child in sorted(folder.rglob("*")):
        if child.is_dir():
            _add(problems, child, "Folders are not allowed inside inbox/")
        elif child.suffix.lower() not in {".md", ".txt"}:
            _add(problems, child, "Only .md and .txt files are allowed inside inbox/")


def _check_logs(problems: list[dict]):
    if not LOGS.exists():
        return
    pat = re.compile(r"^\d{4}-\d{2}-\d{2}_\d{2}-\d{2}-\d{2}_.+\.md$")
    for child in sorted(LOGS.iterdir()):
        if child.is_file() and pat.match(child.name):
            continue
        _add(problems, child, "logs/ holds only files named YYYY-MM-DD_HH-MM-SS_<title>.md")
