"""SecondBrain core: the ranking search engine (spec 3, 9).

No semantic or embedding model. Everything is computed from tags, keywords,
synonyms and links. Search ranks notes; it never returns text chunks. Tags
and keywords are boosters, not filters (except in the two Require modes).
Tags boost more than keywords. One engine serves the website and the MCP
server, so results are identical.
"""
from __future__ import annotations

import math
import re
import time

from . import indexer, paths, store, tags as tags_mod
from .textutil import (FILLER, KEEP_WORDS, jaccard, key_of, levenshtein_leq1,
                       normalize, stem, tokenize)

# --------------------------------------------------------------------------
# Built-in general synonyms (the master file can add more, spec 3.3 step 2)
# --------------------------------------------------------------------------

BUILTIN_SYNONYMS: dict[str, list[str]] = {
    "quick": ["fast", "rapid", "speedy"],
    "fast": ["quick", "rapid", "speedy"],
    "rapid": ["quick", "fast", "speedy"],
    "speedy": ["quick", "fast", "rapid"],
    "recipe": ["dish", "meal"],
    "dish": ["recipe", "meal"],
    "meal": ["recipe", "dish"],
    "dinner": ["supper", "evening meal", "meal"],
    "lunch": ["midday meal", "meal"],
    "veggie": ["vegetable"],
    "vegetable": ["veggie"],
    "picture": ["image", "photo"],
    "photo": ["image", "picture"],
    "image": ["picture", "photo"],
    "word": ["vocabulary", "term"],
    "vocabulary": ["words", "terms"],
    "plan": ["planning", "idea"],
    "make": ["cook", "prepare"],
    "cook": ["make", "prepare"],
    "prepare": ["make", "cook"],
    "note": ["notes"],
    "soup": ["broth", "stew"],
    "stew": ["soup"],
    "fix": ["repair", "mend"],
    "repair": ["fix", "mend"],
}


# --------------------------------------------------------------------------
# Step 1: understand the query
# --------------------------------------------------------------------------

def parse_query(q: str, master: tags_mod.MasterTags, settings: dict):
    """Return (groups, query_tags, phrases, kept_as_typed).
    A group = {terms: [(term, weight)], phrase: bool, text: str}."""
    q = (q or "").strip()
    phrases = re.findall(r'"([^"]+)"', q)
    q_no_quotes = re.sub(r'"[^"]*"', " ", q)
    norm = normalize(q_no_quotes)
    words = tokenize(norm)

    only_fillers = bool(words) and all(w in FILLER and w not in KEEP_WORDS
                                       for w in words)
    if only_fillers:
        # A query made only of filler words is kept as typed (guard rail).
        words = tokenize(norm)
    else:
        words = [w for w in words if w not in FILLER or w in KEEP_WORDS]

    max_groups = int(settings.get("max_word_groups", 12))
    groups: list[dict] = []

    tag_lookup = tags_mod.tag_synonym_to_tag(master)
    query_tags: list[str] = []

    def detect_tags(seq: list[str]):
        """A word (or short run of words) matching an approved tag or a tag
        synonym also becomes a query tag (spec 3.3 step 1)."""
        for n in (4, 3, 2):
            i = 0
            while i + n <= len(seq):
                run = " ".join(seq[i:i + n])
                for form in (run.replace(" ", "-"), run.replace(" ", "-")):
                    hit = tag_lookup.get(run.replace(" ", "-"))
                    if hit:
                        query_tags.append(hit)
                        return
                i += 1
        for w in seq:
            hit = tag_lookup.get(w)
            if hit:
                query_tags.append(hit)

    detect_tags(words)

    gen_syn = dict(master.general_synonyms)
    for k, v in BUILTIN_SYNONYMS.items():
        gen_syn.setdefault(k, v)

    for w in words:
        if len(groups) >= max_groups:
            break
        s = stem(w)
        terms = [(w, 1.0), (s, 1.0)]
        for syn in gen_syn.get(w, []):
            for t in tokenize(syn):
                terms.append((t, float(settings.get("synonym_weight", 0.7))))
                terms.append((stem(t), float(settings.get("synonym_weight", 0.7))))
        seen: set[str] = set()
        uniq = [(t, wt) for t, wt in terms if not (t in seen or seen.add(t))]
        groups.append({"terms": uniq, "phrase": False, "text": w})
    for ph in phrases:
        if len(groups) >= max_groups:
            break
        toks = tokenize(ph)
        groups.append({"terms": [(toks[0], 1.0)] if toks else [],
                       "phrase": True, "text": ph.strip(), "phrase_tokens": toks})

    # de-duplicate query tags, keep order
    seen: set[str] = set()
    query_tags = [t for t in query_tags if not (key_of(t) in seen or seen.add(key_of(t)))]
    return groups, query_tags, phrases, only_fillers


# --------------------------------------------------------------------------
# Candidate collection
# --------------------------------------------------------------------------

def _scope_text(e: dict, scope: list[str]) -> dict[str, str]:
    """Which fields the query words are looked in (spec 9.3)."""
    everything = not scope or "everything" in scope
    fields: dict[str, str] = {}
    if everything or "file name" in scope or "filename" in scope:
        fields["title"] = normalize(" ".join(e["title_tokens"]))
    if everything or "tags" in scope:
        fields["tags"] = e["tag_text"]
    if everything or "headings" in scope:
        fields["headings"] = e["heading_text"]
    if everything or "body" in scope:
        fields["body"] = e["snippet_text"]
    if everything or "folder path" in scope:
        fields["folder"] = e["folder_path"]
    return fields


def _typo_words(idx: dict, w: str, min_len: int) -> list[str]:
    """Words in the vocabulary within one wrong letter of w (5+ letters)."""
    if len(w) < min_len:
        return []
    buckets = idx.get("typo_buckets", {})
    cands: set[str] = set()
    variants = {w}
    for i in range(len(w)):
        variants.add(w[:i] + w[i + 1:])
    for v in variants:
        for cand in buckets.get(v, []):
            if cand != w and levenshtein_leq1(w, cand):
                cands.add(cand)
    return sorted(cands)


def _keyword_hits(idx: dict, groups: list[dict], scope: list[str],
                  settings: dict) -> set[str]:
    """B. Keyword hits: notes found in the word index, allowing one wrong
    letter for words of five or more letters."""
    min_len = int(settings.get("typo_min_length", 5))
    use_typo = bool(settings.get("typo_tolerance", True))
    hits: set[str] = set()
    for g in groups:
        for term, _wt in g["terms"]:
            if g.get("phrase"):
                continue        # phrases checked textually later
            if term in idx["df"] or term in idx["h_df"] or _term_in_titles(idx, term) \
                    or _term_in_tags(idx, term) or _term_in_folders(idx, term):
                for rp in _notes_with_term(idx, term, scope):
                    hits.add(rp)
            if use_typo:
                for tw in _typo_words(idx, term, min_len):
                    for rp in _notes_with_term(idx, tw, scope):
                        hits.add(rp)
    return hits


def _notes_with_term(idx: dict, term: str, scope: list[str]) -> list[str]:
    everything = not scope or "everything" in scope
    out: list[str] = []
    if everything or "body" in scope:
        pass
    files = idx["files"]
    # cheap: iterate the (small) posting lists kept in files' tf maps
    for rp, e in files.items():
        if everything or "body" in scope:
            if term in e["words"]:
                out.append(rp)
                continue
        if everything or "headings" in scope:
            if term in e["heading_words"]:
                out.append(rp)
                continue
        if everything or "file name" in scope or "filename" in scope:
            if term in e["title_tokens"]:
                out.append(rp)
                continue
        if everything or "tags" in scope:
            if term in tokenize(e["tag_text"]):
                out.append(rp)
                continue
        if everything or "folder path" in scope:
            if term in tokenize(e["folder_path"]):
                out.append(rp)
                continue
    return out


def _term_in_titles(idx: dict, term: str) -> bool:
    return any(term in e["title_tokens"] for e in idx["files"].values())


def _term_in_tags(idx: dict, term: str) -> bool:
    return any(term in e["tag_text"].split() for e in idx["files"].values())


def _term_in_folders(idx: dict, term: str) -> bool:
    return any(term in e["folder_path"].split() for e in idx["files"].values())


def _tag_hits(idx: dict, query_tags: list[str], selected_tags: list[str]) -> set[str]:
    """A. Tag hits: the exact (case-insensitive) tag only. Tags are
    independent, so there is no parent/child expansion (v2)."""
    hits: set[str] = set()
    tag_map = idx["tag_map"]
    for qt in query_tags + selected_tags:
        hits.update(tag_map.get(key_of(qt), []))
    return hits


def _apply_typo_corrections(idx: dict, groups: list[dict], settings: dict) -> bool:
    """Typo tolerance (spec 3.3 B): a query word of five or more letters
    that is not in the vocabulary gains its corrections as extra group terms
    (weight like synonyms), so they also credit titles, headings and tags."""
    min_len = int(settings.get("typo_min_length", 5))
    if not settings.get("typo_tolerance", True):
        return False
    vocab = set(idx["df"]) | set(idx["h_df"])
    added = False
    for g in groups:
        if g.get("phrase") or len(g["text"]) < min_len:
            continue
        if any(t in vocab for t, _wt in g["terms"]):
            continue                    # a real word is already in the group
        for c in _typo_words(idx, g["text"], min_len):
            w = float(settings.get("synonym_weight", 0.7))
            g["terms"].append((c, w))
            g["terms"].append((stem(c), w))
            added = True
        seen: set[str] = set()
        g["terms"] = [(t, wt) for t, wt in g["terms"]
                      if not (t in seen or seen.add(t))]
    return added


def _neighbor_candidates(idx: dict, top_hits: list[str]) -> dict[str, str]:
    """C. Neighbors: notes sharing at least two tags with a top-5 hit, or
    connected to one."""
    out: dict[str, str] = {}
    files = idx["files"]
    for hit in top_hits:
        he = files.get(hit)
        if he is None:
            continue
        for linked in idx["graph"].get(hit, []) + idx["backlinks"].get(hit, []):
            if linked != hit:
                out.setdefault(linked, "connected")
        htags = {key_of(t) for t in he["tags"]}
        for rp, e in files.items():
            if rp == hit or rp in out:
                continue
            shared = 0
            for t in e["tags"]:
                kt = key_of(t)
                if kt in htags:
                    shared += 1
                    if shared >= 2:
                        out[rp] = "shared tags"
                        break
    return out


def _fallback_candidates(idx: dict, groups: list[dict], k: int = 20) -> list[str]:
    """D. Fallback: the closest notes by tag and title similarity, so the
    result is never blank."""
    qwords = set()
    for g in groups:
        qwords.add(stem(g["text"]))
    scored = []
    for rp, e in idx["files"].items():
        note_tags = {key_of(t) for t in e["tags"]}
        title_stems = {stem(t) for t in e["title_tokens"]}
        s = 0.5 * jaccard(qwords, title_stems)
        # tag similarity via shared non-empty groups is not defined without
        # query tags; fall back to title + tag spread
        s += 0.25 * min(1.0, len(note_tags) / 3)
        scored.append((s, rp))
    scored.sort(key=lambda x: (-x[0], x[1]))
    return [rp for _s, rp in scored[:k] if _s > 0] or \
        [rp for _s, rp in scored[:k]]


# --------------------------------------------------------------------------
# Scoring
# --------------------------------------------------------------------------

def _bm25(tf: dict[str, int], dl: int, avgdl: float, N: int, df: dict[str, int],
          terms: list[tuple[str, float]], k1: float, b: float) -> float:
    score = 0.0
    for term, weight in terms:
        f = tf.get(term, 0)
        if not f:
            continue
        n = df.get(term, 0)
        idf = math.log(1 + (N - n + 0.5) / (n + 0.5))
        score += weight * idf * (f * (k1 + 1)) / (f + k1 * (1 - b + b * (dl / avgdl if avgdl else 1)))
    return score


def _group_in_text(g: dict, texts: list[str], prefix_ok: bool = False) -> bool:
    """True when the group is found in one of the field texts. Both sides
    are compared as stems so endings match (recipe/recipes). With
    prefix_ok=True (used for titles) a title word that STARTS with the
    term also counts, so 'garl' finds 'Garlic Bread'."""
    if g.get("phrase"):
        toks = [stem(t) for t in (g.get("phrase_tokens") or [])]
        joined = " ".join(toks)
        return bool(joined) and any(
            joined in " ".join(stem(x) for x in tokenize(t)) for t in texts)
    for term, _wt in g["terms"]:
        s = stem(term)
        for t in texts:
            if not t:
                continue
            if term in t.split() or s in t.split():
                return True
            if prefix_ok and any(x.startswith(s) and len(s) >= 3
                                 for x in tokenize(t)):
                return True
            if s in [stem(x) for x in tokenize(t)]:
                return True
    return False


def _group_positions(g: dict, tokens: list[str]) -> list[int]:
    if g.get("phrase"):
        toks = g.get("phrase_tokens") or []
        out = []
        if toks:
            for i in range(len(tokens) - len(toks) + 1):
                if tokens[i:i + len(toks)] == toks:
                    out.append(i)
        return out
    return [i for i, t in enumerate(tokens) for term, _wt in g["terms"] if t == term]


def _score_note(idx: dict, rp: str, groups: list[dict], query_tags: list[str],
                selected_tags: list[str], direct: bool, neighbor_kind: str | None,
                settings: dict, q_text: str = "") -> dict:
    e = idx["files"][rp]
    bm = settings.get("bm25", {"k1": 1.5, "b": 0.75})
    N = idx["N"]

    matched_groups = 0
    # ---- Tags signal ----
    tag_score_raw = 0.0
    matched_tag_pairs = []
    note_tag_keys = {}
    for t in e["tags"]:
        note_tag_keys[key_of(t)] = t
    if query_tags or selected_tags:
        for qt in query_tags + selected_tags:
            best = None
            for nt in e["tags"]:
                rel_w = tags_mod.relation(nt, qt)
                if rel_w is None:
                    continue
                dfc = len(idx["tag_map"].get(key_of(nt), [])) or 1
                rarity = min(1.0, math.log(1 + N / dfc) / math.log(1 + max(N, 2)))
                val = rel_w * rarity
                if best is None or val > best[0]:
                    best = (val, qt, nt, rel_w)
            if best:
                tag_score_raw += best[0]
                matched_tag_pairs.append({"query_tag": best[1], "note_tag": best[2],
                                          "relation": best[3]})
                matched_groups += 0   # groups counted below

    # ---- Title and aliases: share of query groups found + phrase bonus ----
    title_texts = [normalize(e["title"])] + list(e["aliases"]) + \
        [normalize(" ".join(e["title_tokens"]))]
    title_hit = sum(1 for g in groups if _group_in_text(g, title_texts, prefix_ok=True))
    title_share = (title_hit / len(groups)) if groups else 0.0
    # A title that contains the whole query phrase (or every group) is a
    # perfect title match - this is what 'super intelligent' ranking means
    # for titles: the note named like the query floats to the top.
    if groups and title_hit == len(groups):
        title_share = 1.0
    qnorm_stem = " ".join(stem(x) for x in tokenize(normalize(q_text)))
    if qnorm_stem and qnorm_stem in " ".join(stem(x) for x in tokenize(normalize(e["title"]))):
        title_share = 1.0

    # ---- Headings (BM25) ----
    h_terms = []
    for g in groups:
        if g.get("phrase"):
            for t in g.get("phrase_tokens", []):
                h_terms.append((t, 1.0))
        else:
            h_terms.extend(g["terms"])
    h_dl = len(tokenize(e["heading_text"]))
    h_score = _bm25(e["heading_words"], h_dl, idx.get("h_avgdl", 1.0) or 1.0,
                    N, idx.get("h_df", {}), h_terms,
                    bm["k1"], bm["b"]) if h_terms else 0.0

    # ---- Body (BM25) ----
    b_terms = []
    for g in groups:
        if g.get("phrase"):
            for t in g.get("phrase_tokens", []):
                b_terms.append((t, 1.0))
        else:
            b_terms.extend(g["terms"])
    b_score = _bm25(e["words"], len(e["tokens"]), idx.get("avgdl", 1.0) or 1.0,
                    N, idx.get("df", {}), b_terms, bm["k1"], bm["b"]) if b_terms else 0.0

    # ---- Neighbors ----
    nb_score = 1.0 if neighbor_kind == "connected" else \
        (0.8 if neighbor_kind == "shared tags" else 0.0)

    # ---- Closeness ----
    close = 0.0
    if len(groups) >= 2:
        positions = [_group_positions(g, e["tokens"]) for g in groups]
        positions = [p for p in positions if p]
        window = int(settings.get("closeness_window_tokens", 40))
        same_section = False
        near = False
        spans = e["section_spans"]
        for i in range(len(positions)):
            for j in range(i + 1, len(positions)):
                for a in positions[i]:
                    for b in positions[j]:
                        if abs(a - b) <= window:
                            near = True
                        for (s0, s1) in spans:
                            if s0 <= a < s1 and s0 <= b < s1:
                                same_section = True
        close = 1.0 if near else (0.7 if same_section else 0.0)

    # ---- Groups matched (for coverage) ----
    all_texts = title_texts + [e["heading_text"], e["snippet_text"], e["tag_text"],
                               e["folder_path"]]
    matched_groups = sum(1 for g in groups if _group_in_text(g, all_texts))

    raw = {
        "tags": tag_score_raw,
        "title": title_share,
        "headings": h_score,
        "neighbors": nb_score,
        "body": b_score,
        "closeness": close,
    }
    return {"raw": raw, "matched_groups": matched_groups,
            "matched_tag_pairs": matched_tag_pairs,
            "title_hit": title_hit,
            "rp": rp, "direct": direct, "neighbor_kind": neighbor_kind}


def _finalize_scores(scored: list[dict], groups: list[dict],
                     weights: dict, settings: dict) -> None:
    """Scale each signal against the best candidate, redistribute the weight
    of signals that do not apply, apply the coverage factor, and enforce the
    stability rules (spec 3.4)."""
    if not scored:
        return
    N = len(groups)
    applicable = {}
    applicable["tags"] = any(x["raw"]["tags"] > 0 for x in scored) or \
        _query_has_tags(scored)
    applicable["title"] = True
    applicable["headings"] = bool(groups) and \
        any(x["raw"]["headings"] > 0 for x in scored)
    applicable["neighbors"] = any(x["neighbor_kind"] for x in scored)
    applicable["body"] = bool(groups) and any(x["raw"]["body"] > 0 for x in scored)
    applicable["closeness"] = bool(groups) and \
        any(x["raw"]["closeness"] > 0 for x in scored)
    if not groups:
        # empty query with tags ranks by tags (guard rail)
        applicable["title"] = applicable["headings"] = False
        applicable["body"] = applicable["closeness"] = False

    # Redistribute weights of non-applicable signals among the rest.
    active = [k for k, v in applicable.items() if v]
    if not active:
        active = ["title"]
        applicable["title"] = True
    total_w = sum(weights.get(k, 0) for k in active)
    used = {k: (weights.get(k, 0) / total_w if total_w else 1 / len(active))
            for k in active}

    # Scale each signal against the best candidate for that signal.
    scales = {}
    for k in active:
        m = max((x["raw"][k] for x in scored), default=0.0)
        scales[k] = (1.0 / m) if m > 0 else 0.0

    coverage_base = float(settings.get("coverage_base", 0.4))
    for x in scored:
        breakdown = {}
        wsum = 0.0
        for k in active:
            scaled = min(1.0, x["raw"][k] * scales[k]) if scales[k] else 0.0
            points = used[k] * scaled
            wsum += points
            breakdown[k] = {"weight": round(used[k], 4), "raw": round(x["raw"][k], 4),
                            "scaled": round(scaled, 4), "points": round(points, 4)}
        for k in weights:
            if k not in breakdown:
                breakdown[k] = {"weight": 0.0, "raw": round(x["raw"].get(k, 0.0), 4),
                                "scaled": 0.0, "points": 0.0,
                                "note": "signal not used for this query"}
        coverage = 1.0 if not groups else \
            (coverage_base + (1 - coverage_base) * (x["matched_groups"] / N))
        x["coverage"] = round(coverage, 4)
        x["score"] = round(100.0 * wsum * coverage, 2)
        x["breakdown"] = breakdown


def _query_has_tags(scored: list[dict]) -> bool:
    return any(x.get("_query_has_tags") for x in scored)


# --------------------------------------------------------------------------
# Main entry
# --------------------------------------------------------------------------

def search(idx: dict | None = None, q: str = "", mode: str = "rank",
           tags_sel: list[str] | None = None, folders: list[str] | None = None,
           folder_only: bool = False, scope: list[str] | None = None,
           tag_mode: str = "rank", kw_mode: str = "rank",
           include_connected: bool = False, status: str | None = None,
           date_from: str | None = None, date_to: str | None = None,
           limit_to: list[str] | None = None,
           offset: int = 0, limit: int | None = None) -> dict:
    """The full pipeline (spec 3.3): understand, expand, collect, score,
    rank, return. Deterministic: the order is identical on every run."""
    t0 = time.perf_counter()
    settings = store.load_settings()
    weights = settings["ranking_weights"]
    page_size = int(settings.get("page_size", 20))
    limit = limit or page_size
    tags_sel = tags_sel or []
    folders = folders or []
    scope = scope or ["everything"]
    if idx is None:
        idx = indexer.load_index()
    master = tags_mod.load_master()

    groups, query_tags, phrases, only_fillers = parse_query(q, master, settings)
    if _apply_typo_corrections(idx, groups, settings):
        # A corrected word can also be a query tag: pastha -> pasta -> FOOD-pasta.
        tag_lookup = tags_mod.tag_synonym_to_tag(master)
        for g in groups:
            for t, wt in g["terms"]:
                hit = tag_lookup.get(t)
                if hit and wt < 1.0:
                    query_tags.append(hit)
        seen: set[str] = set()
        query_tags = [t for t in query_tags
                      if not (key_of(t) in seen or seen.add(key_of(t)))]
    if mode == "strict_tag":
        tag_mode = "require"
    if mode == "strict_keyword":
        kw_mode = "require"

    # Folder boundary: a hard boundary, the search never looks outside it.
    universe = list(idx["files"].keys())
    if folders:
        def in_scope(rp: str) -> bool:
            for f in folders:
                f = f.strip("/")
                if f == "" and not folder_only:
                    return True
                if rp.startswith("database/" + f + "/") or rp == "database/" + f:
                    p = paths.ROOT / rp
                    note_folder = p.parent
                    rel_folder = paths.rel(note_folder).removeprefix("database/")
                    if folder_only:
                        if rel_folder == f:
                            return True
                    else:
                        if rel_folder == f or rel_folder.startswith(f + "/"):
                            return True
            return False
        universe = [rp for rp in universe if in_scope(rp)]

    # Status and date filters (advanced filters, spec 4).
    def meta_ok(rp: str) -> bool:
        e = idx["files"][rp]
        if status and e["status"] != status:
            return False
        if date_from and (e["updated"] or "0000") < date_from:
            return False
        if date_to and (e["updated"] or "9999") > date_to:
            return False
        return True
    universe = [rp for rp in universe if meta_ok(rp)]

    # Search within a chosen group of notes (spec 10: search within
    # connected notes). Notes are named by title or rel path.
    if limit_to:
        wanted = {key_of(x) for x in limit_to}
        wanted |= {key_of(x) for x in limit_to if "/" in x}
        universe = [rp for rp in universe
                    if key_of(idx["files"][rp]["title"]) in wanted or rp in limit_to]

    removed_by = {"tags": 0, "keywords": 0}

    # ---- Strict tag mode (hard filter): must carry all selected tags ----
    if tag_mode == "require" and tags_sel:
        keep = []
        for rp in universe:
            e = idx["files"][rp]
            carried = {key_of(t) for t in e["tags"]}
            if all(key_of(st) in carried for st in tags_sel):
                keep.append(rp)
        removed_by["tags"] = len(universe) - len(keep)
        universe = keep

    # ---- Collect candidates ----
    uni = set(universe)
    direct: set[str] = set()
    if q.strip():
        direct = (_tag_hits(idx, query_tags, tags_sel if tag_mode == "rank" else [])
                  | _keyword_hits(idx, groups, scope, settings)) & uni
    elif tags_sel:
        direct = set(_tag_hits(idx, [], tags_sel)) & uni

    # ---- Strict keyword mode (hard filter): every query word, any order ----
    if kw_mode == "require" and (groups or phrases):
        keep = []
        for rp in universe:
            e = idx["files"][rp]
            texts = list(_scope_text(e, scope).values())
            ok = all(_group_in_text(g, texts) for g in groups)
            for ph in phrases:
                toks = " ".join(stem(x) for x in tokenize(ph))
                ok = ok and any(toks in " ".join(stem(x) for x in tokenize(t))
                                for t in texts)
            if ok:
                keep.append(rp)
        removed_by["keywords"] = len(universe) - len(keep)
        universe = keep
        direct &= set(universe)

    # ---- Neighbors of the top-5 direct hits ----
    pre_top = sorted(direct, key=lambda rp: (-len(idx["files"][rp]["tags"]), rp))[:5]
    neighbors = _neighbor_candidates(idx, pre_top) if direct else {}
    neighbors = {rp: kind for rp, kind in neighbors.items()
                 if rp in set(universe) and rp not in direct}

    # ---- Fallback: never blank ----
    fallback_used = False
    if not direct and not neighbors and universe:
        direct = set(_fallback_candidates(idx, groups)) & set(universe)
        fallback_used = True
        neighbors = {}

    candidates = [(rp, True, None) for rp in direct] + \
                 [(rp, False, kind) for rp, kind in neighbors.items()]

    scored = []
    for rp, is_direct, kind in candidates:
        sc = _score_note(idx, rp, groups, query_tags,
                         tags_sel if tag_mode == "rank" else [],
                         is_direct, kind, settings, q_text=q)
        sc["_query_has_tags"] = bool(query_tags or tags_sel)
        sc["_has_groups"] = bool(groups)
        e = idx["files"][rp]
        sc.update({"title": e["title"], "status": e["status"],
                   "updated": e["updated"], "tags": e["tags"],
                   "folder": e["folder"], "rel_path": rp})
        scored.append(sc)

    _finalize_scores(scored, groups, weights, settings)

    # Neighbor-only notes can never outrank notes that match directly.
    # Ties break in this order: more groups matched, more recently updated,
    # then title A to Z (verification removed in v2 - every note is equal).
    for x in scored:
        x["direct"] = bool(x["direct"])
    scored.sort(key=lambda x: (
        0 if x["direct"] else 1,                       # direct matches first
        -x["score"],
        -x["matched_groups"],
        _date_key(x["updated"]),
        x["title"].lower(),
    ))

    # Exact title or alias match always ranks first (within direct matches).
    qnorm = normalize(q)
    exact = [x for x in scored if x["direct"] and qnorm and
             (qnorm == normalize(x["title"]) or
              any(qnorm == a for a in idx["files"][x["rel_path"]]["aliases"]))]
    if exact:
        rest = [x for x in scored if x not in exact]
        exact.sort(key=lambda x: (-x["score"], x["title"].lower()))
        rest.sort(key=lambda x: (0 if x["direct"] else 1, -x["score"],
                                 -x["matched_groups"],
                                 _date_key(x["updated"]), x["title"].lower()))
        scored = exact + rest

    results = [_present(idx, x, groups) for x in scored]

    # ---- Include connected notes as extra results (spec 9.5) ----
    if include_connected and scored:
        top_hits = [x["rel_path"] for x in scored[:5]]
        extra = []
        seen = {x["rel_path"] for x in scored}
        for hit in top_hits:
            for nb in idx["graph"].get(hit, []) + idx["backlinks"].get(hit, []):
                if nb not in seen and nb in set(universe):
                    seen.add(nb)
                    e = idx["files"][nb]
                    extra.append({
                        "path": nb, "title": e["title"], "folder": e["folder"],
                        "tags": e["tags"], "status": e["status"],
                        "updated": e["updated"], "score": None,
                        "connected_to": hit,
                        "snippet": _snippet(e, groups),
                    })
        results = results + extra

    page = results[offset: offset + limit]
    elapsed = round((time.perf_counter() - t0) * 1000, 1)

    notice = None
    if not results:
        if tag_mode == "require" and removed_by["tags"]:
            notice = ("No results: the Require switch on tags removed all notes "
                      "(every note must carry all of the selected tags). "
                      "Relax it to Rank to see boosted results instead.")
        elif kw_mode == "require" and removed_by["keywords"]:
            notice = ("No results: the Require switch on keywords removed all notes "
                      "(every note must contain every query word). Relax it to Rank.")
        elif folders:
            notice = ("No results inside the selected folder boundary. "
                      "Search never looks outside chosen folders - widen the "
                      "folder selection or clear it.")
    return {
        "total": len(results),
        "offset": offset,
        "results": page,
        "notice": notice,
        "removed_by": removed_by,
        "fallback_used": fallback_used,
        "query": {"groups": [g["text"] for g in groups],
                  "query_tags": query_tags, "phrases": phrases},
        "elapsed_ms": elapsed,
    }


def _date_key(d: str) -> str:
    d = d or ""
    # more recent first in ascending sort -> invert lexicographic order by
    # padding to fixed width and negating via transformation
    return "".join(chr(0x10FFFF - ord(c)) for c in d.ljust(10))


def _snippet(e: dict, groups: list[dict]) -> str:
    text = e.get("snippet_text", "")
    if not groups:
        return text[:200]
    best_i = 0
    for g in groups:
        pos = _group_positions(g, e["tokens"])
        if pos:
            best_i = pos[0]
            break
    toks = text.split()
    a, b = max(0, best_i - 12), min(len(toks), best_i + 24)
    return " ".join(toks[a:b])


def _present(idx: dict, x: dict, groups: list[dict]) -> dict:
    e = idx["files"][x["rel_path"]]
    return {
        "path": x["rel_path"],
        "title": e["title"],
        "folder": e["folder"],
        "tags": e["tags"],
        "status": e["status"],
        "updated": e["updated"],
        "pinned": e["pinned"],
        "score": x["score"],
        "coverage": x.get("coverage"),
        "direct": x["direct"],
        "neighbor_kind": x.get("neighbor_kind"),
        "matched_groups": x.get("matched_groups", 0),
        "breakdown": x.get("breakdown", {}),
        "snippet": _snippet(e, groups),
    }
