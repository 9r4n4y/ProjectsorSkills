# FIXES.md — SecondBrain v2 change list, with proof

Every item below was reported, fixed, and **verified by an automated test
suite or a real browser session**. Re-run the proof any time:

```
python3 core/test_ranking.py        # the fixed ranking test set
python3 scripts/test_engine.py      # 39 engine expectations (throwaway copy)
python3 scripts/test_website_api.py # 39 website API expectations (real server)
python3 scripts/test_mcp.py         # 40 MCP expectations (real stdio subprocess)
```

Final run: **ranking all pass · engine 39/39 · website API 39/39 · MCP 40/40.**

---

# v2.1 — the neo-brutalist remaster (UI + architecture)

The v2.1 pass replaces the whole front end with a **strict-grid
neo-brutalist UI**, removes the graph page and the hidden-notes feature,
and fixes the connected-notes search (notes only — never tags or folder
names). All four suites re-run green after the changes, and every page was
driven through a real browser (desktop 1280×900 and Android 412×915) with
zero console errors and zero horizontal overflow.

| # | Change | Detail | Proof |
|---|---|---|---|
| 1 | **100% new UI — neo-brutalist, non-purple** | Complete rewrite of `style.css`, `index.html`, and all view markup: paper background, 2px ink borders, hard 4px offset shadows, ONE accent (international orange `#ff4d00`), mono uppercase labels, no gradients, no purple, no blur. Two themes only: Light + Dark (coffee/orange removed) | VLM screenshot review: "No purple. No gradients. Strictly neo-brutalist" on every page |
| 2 | **Everything on a grid** | Every page is a CSS grid: 4-up stat boxes, 2-col pinned/recent, auto-fill folder/note/connected-note card grids, panel grids, form grids (`repeat(auto-fill, minmax(…))`), boxed table headers | screenshots + `grid-cols-*` classes; VLM: "grid alignment excellent" |
| 3 | **Android / mobile first** | Fixed **bottom tab bar** (Home/Folders/Tags/Health/Backup) with 60px targets, compact icon-only top bar, 44px minimum touch targets everywhere, safe-area insets, single-column stacking, `viewport-fit=cover`, `theme-color` meta. Verified **zero horizontal overflow** on all 8 pages at 412px | per-page overflow eval: "no overflow ✓"; VLM mobile review PASS ×3 |
| 4 | **Search everywhere** | A **global search box in the top bar works on every page** (desktop); `/` focuses it (or jumps to the search page on mobile). Home hero keeps the big search. Search page restructured into boxed MODE / NARROW BY / ADVANCED / RESULTS sections | browser eval: typed "pasta" in top bar on a note page → 6 results |
| 5 | **Connected-notes search finds NOTES ONLY** | New `/api/suggest?type=note` (title + folder + tag matching) and a new `SB.noteSuggest` dropdown. The Connect-an-existing-note input and the editor's *Link note* dialog now list real notes with their folder — **no tags, no folder names**. Free text that matches nothing is rejected with a message instead of silently connecting junk | browser eval: typing "gar" lists `Garden Plan 2026 · Projects`, `Garlic Bread · Recipes`…; connect via click works and is undoable |
| 6 | **Graph page removed** | The canvas force-graph, its route, nav link and home card are gone; `#/graph` now lands on Home. Connected notes on each note page are THE way to see (and use as references) everything linked to a note, with the expandable branch view kept | browser eval: `#/graph` → home; nav has no Graph |
| 7 | **Hidden notes feature removed** | `Sensitivity: private` no longer hides anything: the indexer indexes every note, `folder_tree`/`browse_folder` no longer mark folders private, the UI shows no private badges/notices, and the sample `database/Journal/_subject.md` was cleaned. The previously hidden **October Reflections** is now indexed and searchable | index went 6 → 7 notes; Journal note appears in recent list and search |
| 8 | Tags fixed & de-rainbowed | Tag chips are neutral mono uppercase chips (dashed border when unapproved) — the per-major hue rainbow is gone. Tag browser gridded, filter box first, rename/merge/remove flows retested | browser eval: 22 tags in 11 groups; add/remove tag on a note verified against tags.txt |
| 9 | Backup page fixed & gridded | Form is a boxed grid, empty-path guarded on all three actions, direction wording made explicit, verify table truncated hashes for readability. Full preview → run → verify cycle retested end-to-end | curl: run `ok:true` 127 files, verify `ok:true`; browser buttons wired |
| 10 | New-note dialog bug | The rewritten dialog lost its modal handle (`w`), so live tag suggestions never attached — fixed and retested | browser eval: typing "soup" suggests `FOOD-soup`; note created + deleted cleanly |
| 11 | Suggest split cleanly | `tagSuggest` = tags + folders only (search filters, tag inputs); `noteSuggest` = notes only (connect, link). Empty dropdowns show a plain hint and Enter falls back correctly instead of dead-ending | browser evals on both inputs |
| 12 | Print / dark / a11y | Print stylesheet prints the note only; focus-visible outlines; dark theme contrast checked | VLM dark review: "AAA contrast, no purple" |

---

## 1. Bugs you reported, fixed

| # | Problem | Fix | Proof |
|---|---|---|---|
| 1 | Health page: `Something went wrong: name 'add' is not defined` | `core/paths.py` used a helper `add()` that existed only inside another function (in TWO places: `_check_code_folder` and `_check_website`). One shared `_add(problems, …)` now serves every check | engine test "health check runs without NameError"; health page loads and scores |
| 2 | Metadata export includes hierarchy / sub-tags | Tags are now independent labels; the export lists them flat, with no Backlinks and no Status section | engine tests "metadata export …" ×3; API test on `/api/export` |
| 3 | Sub-tags / hierarchy | **Tags are independent** — a dash is just part of a name; `FOOD-pasta` and `FOOD-pasta-vegetarian` are unrelated. Search, the tag map, rename, merge and the tag browser all use exact matching only | engine tests "tags are independent…" ×5; ranking test "strict tag is exact…"; tag browser shows a flat list |
| 4 | No back button (only "go back to notes") | A real **Back** button in the top bar (history.back one step), plus `Alt/⌘+←` and an in-page "Go back" on error panels | browser session; button in every screenshot |
| 5 | Having to type `https://` everywhere | **Auto-https**: type `domain.com` — references, web links (editor + dialog), the website API and the MCP tools all store `https://domain.com`. A live preview shows "will be saved as https://…" while typing | engine tests "auto-https…" ×4; MCP test "add_reference auto-https"; API test "POST references auto-https"; browser ref panel |
| 6 | Markdown toolbar auto-selects `**`/`##` and the next keystroke deletes it | Rewritten `insertAtCursor`: **nothing is ever left selected**; the cursor lands *inside* `**…**` when empty, right *after* the close when a word was wrapped, at the end of the text for `## `/`- `/`> `, after inserted blocks | browser evals: `selection:[22,22] nothingSelected:true cursorInside:true`; `afterBold:"y **backup**"` |
| 7 | Select a word, tap a button → make it that markdown | Selection-aware tools: Bold/Italic/Code/Math wrap the selection; Heading/List/Task/Quote re-prefix the line; markers never stack (intelligent arrangement replaces `## - [x] …` with one marker) | browser evals incl. `- [x] … + Heading → "## Decide the folder structure…"` |
| 8 | Table editing in the UI (rows, columns, text) | **Table editor**: the Table button opens a visual grid — edit every cell, add/delete rows and columns — and writes the Markdown back exactly where the table was. Every rendered table also shows an *Edit table* button | browser evals: rows 7→8, columns 2→3, applied `\| Español \|` to the editor |
| 9 | Select word + tap link → connect to any site or note | *Link note* and *Link web* buttons use the selected word as the link text; note targets use type-ahead of real notes; web targets are auto-https | browser session; `linkDialog` code |
| 10 | No backlinks — only Connected notes + Reference links | Backlinks removed from the note page, the metadata export, and the MCP `read_note`/`get_connections` outputs. The Connected notes panel says "no backlinks — only what this note connects to" | engine/API/MCP tests assert the keys are gone; screenshot of the panel |
| 11 | Connected notes UI showing connections, show one branch | Connection **cards** with an expandable **branch** view: press *branch* to walk that note's connections level by level ("expand" walks deeper) | browser eval: branch shows Garlic Bread → … |
| 12 | Tick checklists by tapping from the UI | One-click ticking in the rendered page: the Nth rendered checkbox is the Nth task line in the file (code fences skipped server-side); the file is updated and the note re-renders | browser: clicked tick #5 → file shows `- [x] Move the first hundred notes…`; engine + API tests |
| 13 | Health: catch things, show properly, offer fixes | New health page: 0–100 **score dial**, every finding explained, with one-click fixes: remove a broken link, add an unapproved tag to `_tags.md`, merge near-duplicates, delete stray files, delete unreferenced images. Logs below with view/undo | browser: planted `[[Ghost Recipe]]` → fixed via the button → score rose 50 → 57 |
| 14 | Advanced search confusing | Structured into labeled sections — **Mode / Narrow by / Advanced / Results** — with a **How to use** button explaining everything in plain words | screenshot 04-search.png; modal title "How to use search" |
| 15 | Ranking UI broken / "not applicable — weight shared" | The *Why this result* panel now lists only the signals that earned points, sorted, with `+points` in plain words; the confusing phrase is gone from the engine too | browser eval `noConfusingText:true`, whyRows `Title match +27.9 …` |
| 16 | Remove note verification | **Verification removed everywhere**: no Status in templates, new notes, metadata forms, health, search tie-breaks, MCP rules, or docs; any `Status:` someone tries to set is dropped; old sample notes cleaned | engine tests ×4; MCP test "edit_metadata sets pinned (no status anywhere)" |
| 17 | Total UI remaster (shadcn/ui, 21st.dev, Aceternity, Magic UI, React Bits style) | Full design-system rewrite: neutral surfaces, hairline borders, focus rings, gradient brand accents, hover/press motion, pop-in modals, score dial, connection cards, halo hero — four themes kept (Light, Dark, Coffee, Orange) | every screenshot; dark-mode screenshot |
| 18 | Fix pin SVG; brain SVG with black background instead of emoji | Redrawn pushpin icon (classic angled pin, filled variant when pinned); a hand-drawn **brain circuit SVG on a black rounded square** is now the favicon, top-bar logo and home hero — no emoji anywhere | all screenshots; index.html favicon |
| 19 | Logs: only AI or user with names, no auto-reverse | Every entry is named **User** or **AI** (backup runs and website actions count as User; old log files display normalized too). Nothing reverses itself — undo only happens when you press Undo, and it writes its own entry | engine test "logs only name User or AI"; API/MCP suites |
| 20 | Backup must match an old backup byte-for-byte, hash-verify every file, never touch the live project | **Byte-identical backup**: run against any folder (an old backup included) and it is edited until it matches the project byte for byte; *Verify hashes* lists the SHA-256 of **every file** on both sides; a backup run is physically unable to write inside the project (guarded) and refuses targets inside it | engine tests ×5 (one-byte difference caught, second run re-identical, project untouched); MCP ×2; API ×2; browser run "Every hash verified — the copy is identical" (119 files) |
| 21 | New note sometimes "folder does not exist" / weird glitches | Rebuilt dialog: always fetches fresh folders, includes **database (top level)**, preselects the folder you opened it from, keeps open on error, and the root cause of the glitches — apostrophes breaking single-quoted HTML — is fixed (`esc()` now escapes `'`) | browser: created **Sara's Film Picks** (apostrophe) with no glitch; dialog prefill test |
| 22 | Full folder UI: enter any folder, add files there, browse | New **Folders** page: breadcrumb navigation into any depth, note cards with tags/dates/attachments, *New note here*, *New subfolder*, rename/move/delete notes (delete is logged + undoable), edit `_subject.md` | screenshot 09; browser walkthrough incl. create + delete |
| 23 | Tag edit UI inside all tags; global index always synced | Tag browser: per-tag **editor** (rename, merge, remove everywhere, list the notes), add-to-master for unapproved tags, raw `_tags.md` editor. **Sync guarantee**: a tag you apply anywhere is added to `_tags.md` the same moment | tag editor browser test (listed 2 notes for FOOD-garlic); engine sync tests ×3 |
| 24 | Tag preview of already-available tags when adding | Every tag field (note page, new-note dialog, search filter) shows live type-ahead of existing tags with note counts and a new-tag marker | browser: typed FOOD → FOOD-bread, FOOD-garlic, FOOD-pasta-vegetarian, FOOD-soup |
| 25 | In-note search: find, next, works in edit AND preview, auto-scroll + highlight | **Find bar** (toolbar button or Ctrl/Cmd+F): preview mode wraps matches with highlights and cycles the current one with smooth scroll; edit mode selects each match and scrolls the textarea; Prev/Next + "n / m" counter; closing restores the page | browser evals: preview `hits:2, 1/2 → current 1, scrolled:true, clean close`; edit `sel:"structure", scrolled:true` |
| 26 | Ranking super intelligent | Prefix-aware titles (`garl` → *Garlic Bread*), whole-phrase-in-title = perfect title match, exact-tag-only scoring with rarity, deterministic tie-breaks, smarter fallback | engine tests; all ranking expectations hold |
| 27 | Do more testing / rigorous MCP testing / update SKILL.md, README, MCP | 4 automated suites (117 checks total) + a full browser walkthrough; MCP tested as a real subprocess over stdio (handshake, 35 tools, approval gate, tag proposals, backup, undo, error paths). README.md, SKILL.md, StructureOFnotes.md and `_tags.md` rewritten for v2 | this file; suites above |

## 2. Extra bugs found and fixed while testing

- `rename_note` (MCP) **moved the note to the database root** instead of renaming in place — fixed, it now stays in its folder.
- `move_note` renamed the note **folder but left the inner `.md` with the old name**, breaking every reader — fixed, the `.md` is renamed with it.
- `/api/export` 500-ed for bare note names — now resolves names like `/api/note`.
- Apostrophes in note/folder names broke dialogs and lists (unescaped `'` in single-quoted attributes) — `SB.esc` now escapes them.
- All note-level POST routes now accept a bare note name as well as a path.
- `add_master_tags` could delete the tag line it had just added to *Approved tags* (over-broad regex) — removal is now scoped to the *Proposed tags* section only.
- `folder_tree` now also reports `total_notes` (whole subtree) for the browser cards; `__pycache__` is no longer flagged as a structure problem; backup logs are written as **User**.

## 3. Data note

Your notes, folders, attachments, inbox and original logs are untouched
(sample notes lost only their obsolete `Status:` line, per the verification
removal). The `core/.cache` index rebuilds itself from the files.
