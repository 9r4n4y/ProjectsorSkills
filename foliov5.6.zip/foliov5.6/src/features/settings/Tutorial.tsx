import { useState } from "react";
import { BookOpen, ChevronDown, Download, FolderTree, HelpCircle, Layers, Lock, ShieldCheck, Sliders, Tag } from "lucide-react";
import { Card } from "@/components/PageShell";
import { cn } from "@/utils/cn";

interface Section {
  id: string;
  icon: React.ElementType;
  title: string;
  steps: string[];
}

const SECTIONS: Section[] = [
  {
    id: "start",
    icon: FolderTree,
    title: "1. Getting Started & Edge Panel",
    steps: [
      "Choose your Mother folder in Settings (or on first launch). Every subfolder containing image files becomes a comic automatically.",
      "Tap or swipe left on the slim lilac Edge Panel tab on the right edge of the screen to open navigation, folders, and Page top / Page bottom shortcuts.",
      "Tap outside the Edge Panel, swipe right, or press Back to close it.",
    ],
  },
  {
    id: "browse",
    icon: Sliders,
    title: "2. Search, Filters & Unlimited Scroll",
    steps: [
      "The search card at the top scrolls away smoothly as you browse so your covers get the full screen.",
      "Tap the Tag button in the search bar to switch between Tags and Authors. Authors are dedicated author tags you assign (completely separate from folders)—add them anytime via a comic's Tag editor → Authors tab or the Tags & Authors screen.",
      "In Settings → Appearance and reading → Comics per page, pick 20 / 50 / 100 for paged browsing (with top and bottom page buttons) or choose Unlimited for continuous scrolling with no page breaks.",
    ],
  },
  {
    id: "mass",
    icon: Tag,
    title: "3. Mass Select, Folder Tagging & Tag-Group Tagging",
    steps: [
      "Tap the Select icon in the search bar (or long-press any comic card) to enter Select mode.",
      "Tap 'Select all (N)' in the bottom toolbar to select EVERY matching comic across all pages—even across 14+ pages—then tap Tags to add or remove tags (comma-separated supported), Favorite, or Move them together.",
      "To tag an entire folder at once, open the Edge Panel or Filter by folder and tap the Tag button next to any folder.",
      "To add more tags to every comic that already has a specific tag, open Tags (or Filter by tag) and tap the bulk-tag or select-all icon next to that tag. All tags save in the exact same standard metadata format.",
    ],
  },
  {
    id: "reader",
    icon: BookOpen,
    title: "4. Comic Reader: Instant Edge Tap, Scroll Zoom & Lock Mode",
    steps: [
      "Quick Look preview: tap any comic to inspect info, choose how many preview thumbnails appear per row (2–6), or tap any page thumbnail to jump straight to that exact page.",
      "Tap pages mode: tap the narrow invisible left edge for the previous page or the right edge for the next page—sized comfortably for any thumb with zero swipe interference, instant 120Hz switching, and preloaded pages (works both normal and zoomed in). Tap the center to show/hide reader controls.",
      "Scroll mode: pages are separated by thick black dividers. Pinch with two fingers, double-tap, or use +/- to zoom smoothly with zero flicker; while zoomed, scrolling keeps constant speed and smooth inertia.",
      "In Settings → Appearance and reading, customize Zoom pan sensitivity (0.5×–2.5×), Always keep screen awake, Show reading progress bar on covers (off by default), and whether comics open at your Last page or From start.",
      "Connect Comic Parts: open any comic (in Quick Look or the Reader top bar) and tap Connect parts to link a series as Part 1, 2, 3, 4…. Closest matching comic names appear at the top, you can search by name, tap any comic to inspect its full name and page photos, and jump smoothly between parts at the end/start of Scroll or Tap mode.",
      "Lock Mode: tap the Lock icon in the reader top bar to hide all reader UI and prevent accidental taps. Tap the thin right-edge tab (or press Back) to bring the UI back.",
    ],
  },
  {
    id: "export",
    icon: Download,
    title: "5. Direct Page & Comic (.cbz) Export",
    steps: [
      "Inside the reader top bar, tap the Download icon to export either the current opened page (in its original image format) or the entire comic as a .cbz archive.",
      "You can also export any full comic directly from the Quick Look dialog using its Download button.",
    ],
  },
  {
    id: "extract",
    icon: Layers,
    title: "6. Archive Extraction & Verification",
    steps: [
      "Drop .zip, .cbz, .7z, .rar, or multi-part archives into your Mother folder and rescan.",
      "Open Extraction to unpack them with 10-layer verification (archive integrity, checksums, and magic-byte image decoding). Save recurring archive passwords in Settings so they try automatically.",
    ],
  },
  {
    id: "applock",
    icon: Lock,
    title: "7. App Lock & 3-Password Security",
    steps: [
      "Open Settings → App Lock & Passwords to set up to 3 independent passwords (hashed with PBKDF2-SHA256).",
      "Any one of your 3 passwords unlocks Folio and can be used to verify and reset or remove any of the other password slots.",
      "Choose 'On close' to stay unlocked permanently across app switches until you manually close Folio, or 'After idle' (1, 2, 5, 10, or 30 minutes) with a live countdown timer—auto-locking keeps your exact open comic and page live underneath so unlocking returns you to the exact same spot.",
      "Open Settings → Keyboard shortcuts → Configure to customize every navigation, library, and reader shortcut on a dedicated shortcuts page.",
    ],
  },
  {
    id: "backup",
    icon: ShieldCheck,
    title: "8. Metadata Backup & Recovery",
    steps: [
      "Open Settings → Metadata backup → Export to save all tags, favorites, folders, reading progress, settings, and fingerprints into one checksum-verified JSON file.",
      "Use Import and match on any device to restore your metadata—Folio automatically matches moved or renamed comics by path, fingerprint, name + page count, and fuzzy matching, with an automatic database backup and one-tap Undo.",
    ],
  },
];

export function TutorialCard() {
  const [openId, setOpenId] = useState<string | null>("start");
  return (
    <Card title="How to use Folio" actions={<HelpCircle className="size-4 text-sub" />}>
      <p className="mb-3 text-[13px] text-sub">
        Complete guide to every feature in Folio. Tap any section below to expand.
      </p>
      <div className="flex flex-col divide-y divide-line">
        {SECTIONS.map((sec) => {
          const isOpen = openId === sec.id;
          return (
            <div key={sec.id} className="py-2 first:pt-0 last:pb-0">
              <button
                type="button"
                aria-expanded={isOpen}
                onClick={() => setOpenId(isOpen ? null : sec.id)}
                className="flex w-full items-center gap-2.5 py-1.5 text-left text-sm font-bold text-fg hover:text-accent"
              >
                <sec.icon className="size-4 shrink-0 text-accent" />
                <span className="min-w-0 flex-1">{sec.title}</span>
                <ChevronDown className={cn("size-4 shrink-0 text-sub transition-transform duration-200", isOpen && "rotate-180")} />
              </button>
              {isOpen && (
                <ul className="mt-1.5 flex list-disc flex-col gap-1.5 pl-9 pr-2 pb-2 text-[13px] leading-5 text-sub">
                  {sec.steps.map((step, i) => (
                    <li key={i}>{step}</li>
                  ))}
                </ul>
              )}
            </div>
          );
        })}
      </div>
    </Card>
  );
}
