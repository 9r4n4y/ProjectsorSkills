import { useEffect, useState } from "react";
import { ArrowLeft, Keyboard, RotateCcw, X } from "lucide-react";
import { useStore } from "@/lib/store";
import { DEFAULT_SHORTCUTS, SHORTCUT_DEFS, type ShortcutAction, eventToBinding, formatBinding, getBinding } from "@/lib/shortcuts";
import { Button } from "@/components/ui/button";
import { Card, PageShell } from "@/components/PageShell";
import { cn } from "@/utils/cn";

export function Shortcuts() {
  const settings = useStore((s) => s.settings);
  const setSettings = useStore((s) => s.setSettings);
  const setScreen = useStore((s) => s.setScreen);
  const toast = useStore((s) => s.toast);
  const [recording, setRecording] = useState<ShortcutAction | null>(null);

  useEffect(() => {
    if (!recording) return;
    const onKey = (e: KeyboardEvent) => {
      e.preventDefault();
      e.stopPropagation();
      if (e.key === "Escape" && recording !== "readerClose") {
        setRecording(null);
        return;
      }
      const binding = eventToBinding(e);
      if (!binding) return;

      // Check if another action in the same group already uses this binding
      const currentDef = SHORTCUT_DEFS.find((d) => d.id === recording)!;
      const conflict = SHORTCUT_DEFS.find(
        (d) => d.id !== recording && d.group === currentDef.group && getBinding(settings, d.id) === binding,
      );
      const next = { ...(settings.shortcuts ?? {}), [recording]: binding };
      if (conflict) {
        next[conflict.id] = "";
        toast(`Reassigned ${formatBinding(binding)} from "${conflict.label}" to "${currentDef.label}"`);
      } else {
        toast(`Set "${currentDef.label}" to ${formatBinding(binding)}`);
      }
      setSettings({ shortcuts: next });
      setRecording(null);
    };
    window.addEventListener("keydown", onKey, true);
    return () => window.removeEventListener("keydown", onKey, true);
  }, [recording, settings, setSettings, toast]);

  const clearOne = (id: ShortcutAction) => {
    setSettings({ shortcuts: { ...(settings.shortcuts ?? {}), [id]: "" } });
  };

  const resetOne = (id: ShortcutAction) => {
    const next = { ...(settings.shortcuts ?? {}) };
    delete next[id];
    setSettings({ shortcuts: next });
  };

  const resetAll = () => {
    setSettings({ shortcuts: {} });
    setRecording(null);
    toast("Keyboard shortcuts reset to defaults");
  };

  const groups: ("Navigation & Library" | "Comic Reader")[] = ["Navigation & Library", "Comic Reader"];

  return (
    <PageShell
      title="Keyboard shortcuts"
      description="Tap any shortcut and press a key combination to customize it."
      actions={
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" onClick={() => setScreen("settings")}>
            <ArrowLeft />Back to Settings
          </Button>
          <Button variant="ghost" size="sm" onClick={resetAll}>
            <RotateCcw />Reset all
          </Button>
        </div>
      }
    >
      {groups.map((group) => (
        <Card key={group} title={group} actions={<Keyboard className="size-4 text-sub" />}>
          <ul className="flex flex-col divide-y divide-line">
            {SHORTCUT_DEFS.filter((d) => d.group === group).map((d) => {
              const val = getBinding(settings, d.id);
              const isRec = recording === d.id;
              const isCustom = val !== DEFAULT_SHORTCUTS[d.id];
              return (
                <li key={d.id} className="flex flex-wrap items-center justify-between gap-3 py-3 first:pt-0 last:pb-0">
                  <div className="min-w-0 flex-1">
                    <div className="text-sm font-bold">{d.label}</div>
                    <div className="text-[13px] text-sub">{d.description}</div>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <button
                      type="button"
                      onClick={() => setRecording(isRec ? null : d.id)}
                      className={cn(
                        "flex h-9 min-w-[92px] items-center justify-center rounded-full border-2 border-ink px-3.5 text-xs font-bold shadow-[0_2px_0_var(--ink)] transition-colors",
                        isRec ? "animate-pulse bg-peach text-on" : val ? "bg-butter text-on" : "bg-muted text-sub",
                      )}
                    >
                      {isRec ? "Press key..." : formatBinding(val)}
                    </button>
                    {val && (
                      <Button variant="ghost" size="icon" aria-label={`Clear ${d.label}`} title="Unbind" onClick={() => clearOne(d.id)}>
                        <X />
                      </Button>
                    )}
                    {isCustom && (
                      <Button variant="ghost" size="icon" aria-label={`Reset ${d.label}`} title="Reset to default" onClick={() => resetOne(d.id)}>
                        <RotateCcw />
                      </Button>
                    )}
                  </div>
                </li>
              );
            })}
          </ul>
        </Card>
      ))}
    </PageShell>
  );
}
