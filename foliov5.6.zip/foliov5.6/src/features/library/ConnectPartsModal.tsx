import { useEffect, useMemo, useState } from "react";
import { ArrowDown, ArrowUp, BookOpen, Eye, Link2, Plus, Search, Sparkles, Trash2, Unlink, X } from "lucide-react";
import { type ComicRecord, type PageInfo, authorTagsOf } from "@comiclib/shared";
import { api } from "@/lib/backend";
import { useStore } from "@/lib/store";
import {
  dissolveSeries,
  findSeriesForComic,
  moveSeriesPart,
  rankCandidatesByName,
  removeSeriesPart,
  renameSeries,
  setComicPartPosition,
  stripPartTokens,
} from "@/lib/series";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge, Input } from "@/components/ui/controls";
import { PageImage } from "@/features/reader/PageImage";
import { Thumb } from "./ComicCard";
import { cn } from "@/utils/cn";

interface Props {
  anchorComic: ComicRecord;
  onClose: () => void;
  onJumpToPart?: (comic: ComicRecord) => void;
  zIndex?: number;
}

const PAGE_BATCH = 50;

export function ConnectPartsModal({ anchorComic, onClose, onJumpToPart, zIndex = 80 }: Props) {
  const comics = useStore((s) => s.comics);
  const settings = useStore((s) => s.settings);
  const setSettings = useStore((s) => s.setSettings);
  const toast = useStore((s) => s.toast);

  const [query, setQuery] = useState("");
  const [limit, setLimit] = useState(PAGE_BATCH);
  const [previewComic, setPreviewComic] = useState<ComicRecord | null>(null);
  const [previewPages, setPreviewPages] = useState<PageInfo[] | null>(null);
  const [seriesNameDraft, setSeriesNameDraft] = useState<string>("");

  const resolved = useMemo(
    () => findSeriesForComic(settings.series, anchorComic.id, comics),
    [settings.series, anchorComic.id, comics],
  );

  useEffect(() => {
    setSeriesNameDraft(resolved?.series.name ?? stripPartTokens(anchorComic.name));
  }, [resolved?.series.id, resolved?.series.name, anchorComic.name]);

  const connectedParts: ComicRecord[] = useMemo(
    () => (resolved ? resolved.parts : [anchorComic]),
    [resolved, anchorComic],
  );
  const connectedSet = useMemo(() => new Set(connectedParts.map((c) => c.id)), [connectedParts]);

  const ranked = useMemo(
    () => rankCandidatesByName(anchorComic, comics, query, connectedSet),
    [anchorComic, comics, query, connectedSet],
  );

  useEffect(() => {
    setLimit(PAGE_BATCH);
  }, [query]);

  useEffect(() => {
    if (!previewComic) {
      setPreviewPages(null);
      return;
    }
    let live = true;
    setPreviewPages(null);
    void api
      .pages(previewComic.id)
      .then((list) => {
        if (live) setPreviewPages(Array.isArray(list) ? list.slice(0, 8) : []);
      })
      .catch(() => {
        if (live) setPreviewPages([]);
      });
    return () => {
      live = false;
    };
  }, [previewComic]);

  const nextPartNumber = connectedParts.length + 1;

  const handleAssignPart = (target: ComicRecord, partNumber: number) => {
    const nextSeries = setComicPartPosition(settings.series, anchorComic, target, partNumber);
    setSettings({ series: nextSeries });
    toast(`Set "${target.name}" as Part ${partNumber}`);
  };

  const handleMovePart = (fromIdx: number, toIdx: number) => {
    if (!resolved) return;
    setSettings({ series: moveSeriesPart(settings.series, resolved.series.id, fromIdx, toIdx) });
  };

  const handleRemovePart = (comicId: string) => {
    if (!resolved) return;
    setSettings({ series: removeSeriesPart(settings.series, resolved.series.id, comicId) });
    toast("Removed part from series");
  };

  const handleRenameSeries = () => {
    if (!resolved) return;
    const trimmed = seriesNameDraft.trim();
    if (!trimmed || trimmed === resolved.series.name) return;
    setSettings({ series: renameSeries(settings.series, resolved.series.id, trimmed) });
    toast("Updated series name");
  };

  const handleDissolve = () => {
    if (!resolved) return;
    setSettings({ series: dissolveSeries(settings.series, resolved.series.id) });
    toast("Disconnected all parts");
  };

  const visibleCandidates = ranked.slice(0, limit);
  const partChoices = Array.from({ length: Math.min(20, nextPartNumber) }, (_, i) => i + 1);

  return (
    <Dialog open onOpenChange={(o) => !o && onClose()}>
      <DialogContent
        title="Connect Comic Parts"
        description="Link related comics in order (Part 1, 2, 3, 4…). Tap any cover or title to inspect its full name and page photos."
        size="lg"
        zIndex={zIndex}
        className="sm:h-[min(800px,90dvh)]"
      >
        <div className="relative flex min-h-0 flex-1 flex-col overflow-hidden">
          <div className="min-h-0 flex-1 overflow-y-auto overscroll-contain p-3.5 sm:p-4">
            {/* Section 1: Connected Series Parts */}
            <section className="mb-5 rounded-[22px] border-2 border-ink bg-muted/60 p-3">
              <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
                <div className="flex min-w-0 flex-1 items-center gap-2">
                  <Link2 className="size-4 shrink-0 text-accent" />
                  {resolved ? (
                    <Input
                      value={seriesNameDraft}
                      onChange={(e) => setSeriesNameDraft(e.target.value)}
                      onBlur={handleRenameSeries}
                      onKeyDown={(e) => {
                        if (e.key === "Enter") (e.target as HTMLInputElement).blur();
                      }}
                      aria-label="Series name"
                      className="h-9 min-w-[140px] flex-1 text-sm font-bold sm:max-w-xs"
                    />
                  ) : (
                    <span className="text-sm font-bold text-fg">Series order</span>
                  )}
                </div>
                <div className="flex shrink-0 items-center gap-1.5">
                  <Badge tone={resolved ? "ok" : undefined}>
                    {connectedParts.length} {connectedParts.length === 1 ? "part" : "parts"}
                  </Badge>
                  {resolved && (
                    <Button type="button" size="sm" variant="ghost" onClick={handleDissolve} title="Disconnect all parts">
                      <Unlink />Unlink all
                    </Button>
                  )}
                </div>
              </div>

              <ol className="flex flex-col gap-2.5">
                {connectedParts.map((c, idx) => {
                  const isAnchor = c.id === anchorComic.id;
                  const cAuthors = authorTagsOf(c.tags);
                  return (
                    <li
                      key={c.id}
                      className={cn(
                        "flex flex-col gap-2.5 rounded-[18px] border-2 border-ink bg-surface p-3 shadow-[0_2px_0_var(--ink)]",
                        isAnchor && "ring-2 ring-accent/45",
                      )}
                    >
                      {/* Row 1: Cover thumbnail + full-width readable title & metadata */}
                      <div className="flex items-start gap-3">
                        <button
                          type="button"
                          onClick={() => setPreviewComic(c)}
                          className="w-14 shrink-0 transition-transform active:scale-95"
                          aria-label={`Preview ${c.name}`}
                        >
                          <Thumb comic={c} size="s" className="rounded-[10px] border-2 shadow-none" />
                        </button>

                        <button
                          type="button"
                          onClick={() => setPreviewComic(c)}
                          className="min-w-0 flex-1 text-left"
                        >
                          <div className="mb-1 flex flex-wrap items-center gap-1.5">
                            <span
                              className={cn(
                                "inline-flex shrink-0 items-center whitespace-nowrap rounded-full border-2 border-ink px-2.5 py-0.5 text-[11px] font-extrabold leading-none tabular-nums",
                                isAnchor ? "bg-butter text-on" : "bg-lilac text-on",
                              )}
                            >
                              Part {idx + 1}
                            </span>
                            {isAnchor && (
                              <span className="inline-flex shrink-0 whitespace-nowrap rounded-full border border-ink/30 bg-muted px-2 py-0.5 text-[10px] font-bold text-accent">
                                Opened
                              </span>
                            )}
                            <span className="shrink-0 whitespace-nowrap text-[11px] font-semibold tabular-nums text-sub">
                              {c.pages} pages
                            </span>
                          </div>
                          <div className="break-words text-[14px] font-bold leading-snug text-fg">
                            {c.name}
                          </div>
                          {cAuthors.length > 0 && (
                            <div className="mt-0.5 truncate text-[11px] font-semibold text-sub">
                              Author: {cAuthors.join(", ")}
                            </div>
                          )}
                        </button>
                      </div>

                      {/* Row 2: Crisp, geometrically balanced action controls */}
                      {(resolved || (onJumpToPart && !isAnchor)) && (
                        <div className="flex flex-wrap items-center justify-between gap-2 border-t border-line/70 pt-2">
                          <div className="flex items-center gap-1.5">
                            {resolved && (
                              <>
                                <select
                                  aria-label={`Part number for ${c.name}`}
                                  value={idx + 1}
                                  onChange={(e) => handleMovePart(idx, Number(e.target.value) - 1)}
                                  className="h-8 rounded-full border-2 border-ink bg-muted px-2.5 text-xs font-bold text-fg"
                                >
                                  {connectedParts.map((_, n) => (
                                    <option key={n + 1} value={n + 1}>
                                      Part {n + 1}
                                    </option>
                                  ))}
                                </select>
                                <Button
                                  type="button"
                                  size="icon"
                                  variant="outline"
                                  disabled={idx === 0}
                                  aria-label="Move part up"
                                  onClick={() => handleMovePart(idx, idx - 1)}
                                  className="size-8"
                                >
                                  <ArrowUp className="size-3.5" />
                                </Button>
                                <Button
                                  type="button"
                                  size="icon"
                                  variant="outline"
                                  disabled={idx === connectedParts.length - 1}
                                  aria-label="Move part down"
                                  onClick={() => handleMovePart(idx, idx + 1)}
                                  className="size-8"
                                >
                                  <ArrowDown className="size-3.5" />
                                </Button>
                              </>
                            )}
                          </div>

                          <div className="flex items-center gap-1.5">
                            <Button
                              type="button"
                              size="sm"
                              variant="ghost"
                              onClick={() => setPreviewComic(c)}
                            >
                              <Eye className="size-3.5" />Preview
                            </Button>
                            {onJumpToPart && !isAnchor && (
                              <Button
                                type="button"
                                size="sm"
                                variant="secondary"
                                onClick={() => {
                                  onClose();
                                  onJumpToPart(c);
                                }}
                              >
                                <BookOpen className="size-3.5" />Open
                              </Button>
                            )}
                            {resolved && (
                              <Button
                                type="button"
                                size="icon"
                                variant="ghost"
                                aria-label={`Remove ${c.name} from series`}
                                onClick={() => handleRemovePart(c.id)}
                                className="size-8 text-sub hover:text-bad"
                              >
                                <Trash2 className="size-3.5" />
                              </Button>
                            )}
                          </div>
                        </div>
                      )}
                    </li>
                  );
                })}
              </ol>
            </section>

            {/* Section 2: Smart Recommendations & Search */}
            <section className="flex flex-col gap-3">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="flex items-center gap-1.5 text-sm font-bold">
                  <Sparkles className="size-4 text-accent" />
                  <span>Recommended & all comics</span>
                </div>
                <span className="text-xs text-sub">Best name & part-number matches first</span>
              </div>

              <div className="relative">
                <Search className="pointer-events-none absolute left-3.5 top-1/2 size-4 -translate-y-1/2 text-sub" />
                <Input
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  placeholder="Search comics by name or author"
                  aria-label="Search comics to connect"
                  className="pl-10 pr-10"
                />
                {query && (
                  <button
                    type="button"
                    aria-label="Clear search"
                    onClick={() => setQuery("")}
                    className="absolute right-1.5 top-1/2 flex size-8 -translate-y-1/2 items-center justify-center rounded-full text-sub hover:bg-muted hover:text-fg"
                  >
                    <X className="size-4" />
                  </button>
                )}
              </div>

              {visibleCandidates.length === 0 ? (
                <div className="rounded-[18px] border-2 border-dashed border-line p-6 text-center text-[13px] text-sub">
                  {query ? `No other comics match "${query}".` : "All comics in your library are already connected here."}
                </div>
              ) : (
                <ul className="flex flex-col gap-2.5">
                  {visibleCandidates.map(({ comic: c, isStrongMatch, hint }) => {
                    const cAuthors = authorTagsOf(c.tags);
                    return (
                      <li
                        key={c.id}
                        className={cn(
                          "flex flex-col gap-2.5 rounded-[18px] border-2 p-3 transition-colors",
                          isStrongMatch ? "border-ink bg-mint/15 shadow-[0_2px_0_var(--ink)]" : "border-line bg-surface hover:border-ink/60",
                        )}
                      >
                        {/* Row 1: Cover thumbnail + full-width readable title & smart match hint */}
                        <div className="flex items-start gap-3">
                          <button
                            type="button"
                            onClick={() => setPreviewComic(c)}
                            className="w-14 shrink-0 transition-transform active:scale-95"
                            aria-label={`Preview ${c.name}`}
                          >
                            <Thumb comic={c} size="s" className="rounded-[10px] border-2 shadow-none" />
                          </button>

                          <button
                            type="button"
                            onClick={() => setPreviewComic(c)}
                            className="min-w-0 flex-1 text-left"
                          >
                            <div className="mb-1 flex flex-wrap items-center gap-1.5">
                              {hint && (
                                <span
                                  className={cn(
                                    "inline-flex shrink-0 items-center whitespace-nowrap rounded-full border border-ink px-2 py-0.5 text-[10px] font-extrabold leading-none text-on",
                                    isStrongMatch ? "bg-mint" : "bg-butter",
                                  )}
                                >
                                  {hint}
                                </span>
                              )}
                              <span className="shrink-0 whitespace-nowrap text-[11px] font-semibold tabular-nums text-sub">
                                {c.pages} pages
                              </span>
                            </div>
                            <div className="break-words text-[14px] font-bold leading-snug text-fg">
                              {c.name}
                            </div>
                            {cAuthors.length > 0 && (
                              <div className="mt-0.5 truncate text-[11px] font-semibold text-sub">
                                Author: {cAuthors.join(", ")}
                              </div>
                            )}
                          </button>
                        </div>

                        {/* Row 2: Clean action bar — Preview | Pick exact part # | Quick + Part N */}
                        <div className="flex flex-wrap items-center justify-between gap-2 border-t border-line/60 pt-2">
                          <Button
                            type="button"
                            size="sm"
                            variant="ghost"
                            onClick={() => setPreviewComic(c)}
                          >
                            <Eye className="size-3.5" />Preview
                          </Button>
                          <div className="flex items-center gap-1.5">
                            <select
                              aria-label={`Pick part number for ${c.name}`}
                              value=""
                              onChange={(e) => {
                                const val = Number(e.target.value);
                                if (val >= 1) handleAssignPart(c, val);
                              }}
                              className="h-8 rounded-full border-2 border-ink bg-surface px-2.5 text-xs font-bold text-fg"
                            >
                              <option value="" disabled>
                                Set part…
                              </option>
                              {partChoices.map((n) => (
                                <option key={n} value={n}>
                                  Part {n}
                                </option>
                              ))}
                            </select>
                            <Button
                              type="button"
                              size="sm"
                              onClick={() => handleAssignPart(c, nextPartNumber)}
                              title={`Add as Part ${nextPartNumber}`}
                            >
                              <Plus className="size-3.5" />Part {nextPartNumber}
                            </Button>
                          </div>
                        </div>
                      </li>
                    );
                  })}
                </ul>
              )}

              {ranked.length > limit && (
                <div className="flex justify-center pt-1">
                  <Button type="button" variant="outline" size="sm" onClick={() => setLimit((l) => l + PAGE_BATCH)}>
                    Show more ({ranked.length - limit} remaining)
                  </Button>
                </div>
              )}
            </section>
          </div>

          {/* Inline Photo & Full-Name Preview Sheet when tapping any comic */}
          {previewComic && (
            <div
              className="absolute inset-0 z-20 flex flex-col bg-surface"
              role="region"
              aria-label={`Preview of ${previewComic.name}`}
            >
              <div className="flex items-start justify-between gap-3 border-b-2 border-ink bg-muted/60 p-4">
                <div className="min-w-0 flex-1">
                  <div className="text-[11px] font-bold uppercase tracking-wide text-accent">Comic Preview</div>
                  <h3 className="mt-0.5 break-words font-display text-base font-extrabold leading-snug text-fg">
                    {previewComic.name}
                  </h3>
                  <div className="mt-1 flex flex-wrap items-center gap-2 text-xs text-sub">
                    <span>{previewComic.pages} pages</span>
                    {authorTagsOf(previewComic.tags).length > 0 && (
                      <span>· Author: {authorTagsOf(previewComic.tags).join(", ")}</span>
                    )}
                  </div>
                </div>
                <Button type="button" size="icon" variant="outline" aria-label="Close preview" onClick={() => setPreviewComic(null)}>
                  <X />
                </Button>
              </div>

              <div className="min-h-0 flex-1 overflow-y-auto p-4">
                <div className="mb-4 flex flex-wrap items-center gap-2 rounded-[16px] border-2 border-ink bg-muted p-3">
                  <span className="text-xs font-bold text-sub">Assign as:</span>
                  {Array.from({ length: Math.min(8, nextPartNumber) }, (_, i) => i + 1).map((num) => {
                    const currentIdx = connectedParts.findIndex((x) => x.id === previewComic.id);
                    const isCurrentPart = currentIdx === num - 1;
                    return (
                      <Button
                        key={num}
                        type="button"
                        size="sm"
                        variant={isCurrentPart ? "default" : "outline"}
                        onClick={() => {
                          handleAssignPart(previewComic, num);
                          setPreviewComic(null);
                        }}
                      >
                        Part {num}
                      </Button>
                    );
                  })}
                  {nextPartNumber > 8 && (
                    <Button
                      type="button"
                      size="sm"
                      onClick={() => {
                        handleAssignPart(previewComic, nextPartNumber);
                        setPreviewComic(null);
                      }}
                    >
                      + Part {nextPartNumber}
                    </Button>
                  )}
                </div>

                {previewPages === null ? (
                  <div className="grid grid-cols-2 gap-2.5 sm:grid-cols-4">
                    {Array.from({ length: 4 }, (_, i) => (
                      <div key={i} className="skeleton aspect-[2/3] rounded-md" />
                    ))}
                  </div>
                ) : previewPages.length === 0 ? (
                  <div className="mx-auto max-w-[200px]">
                    <Thumb comic={previewComic} size="m" />
                  </div>
                ) : (
                  <div className="grid grid-cols-2 gap-2.5 sm:grid-cols-4">
                    {previewPages.map((p, i) => (
                      <div key={p.name} className="relative aspect-[2/3] overflow-hidden rounded-[12px] border-2 border-ink bg-muted">
                        <PageImage url={p.url} fallbackUrl={p.fallbackUrl} className="size-full object-cover" lazy={i > 3} />
                        <span className="absolute bottom-1 right-1 rounded-sm bg-black/70 px-1.5 text-[11px] font-bold tabular-nums text-white">
                          {i + 1}
                        </span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
