import type { CapacitorConfig } from "@capacitor/cli";

const config: CapacitorConfig = {
  appId: "app.comiclib.mobile",
  appName: "Folio v3.2",
  webDir: "dist",
  server: { androidScheme: "https", cleartext: false },
  android: { allowMixedContent: false, backgroundColor: "#1d1b3b" } // insets are handled natively in MainActivity.kt,
};

export default config;
