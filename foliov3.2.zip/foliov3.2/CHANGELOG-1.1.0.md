# 1.1.0 (versionCode 2, appId unchanged: app.comiclib.mobile)

- Startup: Android probes FTS5 and uses the FTS4 fallback (`sqlNoFts5` in shared/src/schema.ts) when missing; migration errors name the failing statement; startup errors are shown on screen ("Could not start: ...") instead of crashing; BootReceiver/Application no longer crash on failure.
- Insets: MainActivity is the single owner (edge-to-edge, pads and consumes status/nav/cutout/IME insets); CSS safe-area helpers are disabled in the native app to avoid double padding; bar colours/icon contrast follow the theme.
- Reader: scrubber rewritten (commit on release, no scroll-tracker feedback, 44px target); paged mode centres pages both ways; scroll mode has no gaps and tracks the page under the viewport centre; mode selector has text labels; pointer-cancel no longer fires taps.
- Back: one priority stack (dialogs -> reader -> selection -> nested screen -> minimise via moveTaskToBack, never exit). Native builds don't use history.pushState.
- Build: prepare-android.mjs checks JDK/SDK up front and sets versionCode/versionName from package.json.

## NOT verified (no network/Android SDK/device in the authoring sandbox)
npm install, `npm test`, `npm run typecheck`, Gradle build, APK, any device run. Run them locally and the checklist in docs/ANDROID_TEST_CHECKLIST.md.

## Mochi Nook design (visual refresh)
- Tokens in `src/index.css`: sky/paper/soft/ink palette (light + dark) and the four pastels (butter, peach, mint, lilac). `border-line` is now a quiet divider; `border-ink` is the chunky outline. Text on any pastel always uses `text-on`.
- Primitives restyled once so every screen inherits them: Button (ink base that squeezes on press, spring release; ghost stays flat), Input (pill), Switch, Progress (striped stamp bar), Badge, Segmented, EmptyState, Popover, Dialog (sheet with grab handle on phones), Card (rotated pastel title tag), Stat.
- Chrome: dotted sky background, ink-bordered headers, pill nav with lilac active state, chunky comic covers with press feedback and a stamp progress strip, reader scrubber with peach fill and butter thumb, Android bar colours match the theme.
- Fonts: Quicksand (body) and Bagel Fat One (headings) are bundled, not downloaded at runtime (the app has no INTERNET permission). `npm run setup:fonts` fetches them into `public/fonts/` (needs network once; `build:apk` runs it automatically). If the files are missing the app falls back to system fonts and the build still succeeds. The Electron PC build loads from file:// and will also use system fonts unless fonts are inlined.
- Not verified: nothing was built, rendered or screenshotted in the authoring sandbox. Check every screen in light and dark, at 360 px and tablet width, before release (the checklist now includes this).
