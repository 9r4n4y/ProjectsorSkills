# 1.2.0

- Left edge: a very narrow rail with a three-line button. It pops out the side panel; the panel's hide button returns it to the rail. Page top / Page bottom buttons live in the panel.
- Library is paged (Settings > Comics per page, default 20) with page buttons at the top and bottom. The search bar scrolls away with the page instead of being pinned.
- New "Hide selected / Show selected" button for the active tag and folder chips (filters stay applied).
- Import metadata is now a full "Match metadata" page: smart auto match to the most similar comic without metadata, original name shown for every record, manual search per record, tabs (All, Exact, Auto, Review, Unmatched) each with its own search and paging.
- Every tilted heading, badge and logo is now perfectly straight.
