package app.comiclib.mobile

import net.sf.sevenzipjbinding.ExtractAskMode
import net.sf.sevenzipjbinding.ExtractOperationResult
import net.sf.sevenzipjbinding.IArchiveExtractCallback
import net.sf.sevenzipjbinding.IArchiveOpenCallback
import net.sf.sevenzipjbinding.IArchiveOpenVolumeCallback
import net.sf.sevenzipjbinding.IInArchive
import net.sf.sevenzipjbinding.IInStream
import net.sf.sevenzipjbinding.ISequentialOutStream
import net.sf.sevenzipjbinding.PropID
import net.sf.sevenzipjbinding.SevenZip
import net.sf.sevenzipjbinding.SevenZipException
import net.sf.sevenzipjbinding.impl.RandomAccessFileInStream
import org.apache.commons.compress.archivers.sevenz.SevenZFile
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream
import org.apache.commons.compress.archivers.zip.ZipFile
import java.io.File
import java.io.FileOutputStream
import java.io.RandomAccessFile
import java.security.MessageDigest
import java.util.Locale
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger
import java.util.zip.CRC32

object Util {
    val IMAGE_EXT = setOf("png", "jpg", "jpeg", "webp", "avif", "gif", "bmp")
    private val junk = setOf("thumbs.db", "desktop.ini", ".ds_store", "ehthumbs.db")
    fun ext(n: String) = n.substringAfterLast('.', "").lowercase(Locale.ROOT)
    fun isImage(n: String) = ext(n) in IMAGE_EXT && !isJunk(n)
    fun isJunk(p: String) = p.split('/', '\\').any { val l = it.lowercase(Locale.ROOT); l == "__macosx" || l in junk || l.startsWith("._") || l.startsWith(".comiclib") }
    fun normalize(s: String): String = java.text.Normalizer.normalize(s, java.text.Normalizer.Form.NFKD)
        .replace(Regex("\\p{M}+"), "").lowercase(Locale.ROOT).replace(Regex("['\u2019`]"), "").replace(Regex("[^\\p{L}\\p{N}]+"), " ").trim()
    private val numRe = Regex("(\\d+)|(\\D+)")
    val natural = Comparator<String> { a, b ->
        val x = numRe.findAll(a.lowercase(Locale.ROOT)).map { it.value }.toList()
        val y = numRe.findAll(b.lowercase(Locale.ROOT)).map { it.value }.toList()
        for (i in 0 until minOf(x.size, y.size)) {
            val p = x[i]; val q = y[i]
            val c = if (p[0].isDigit() && q[0].isDigit()) p.trimStart('0').padStart(20, '0').compareTo(q.trimStart('0').padStart(20, '0')) else p.compareTo(q)
            if (c != 0) return@Comparator c
        }
        x.size - y.size
    }
    fun sha256(f: File): Pair<String, Long> {
        val md = MessageDigest.getInstance("SHA-256"); val crc = CRC32(); val buf = ByteArray(1 shl 16)
        f.inputStream().use { s -> while (true) { val n = s.read(buf); if (n < 0) break; md.update(buf, 0, n); crc.update(buf, 0, n) } }
        return md.digest().joinToString("") { "%02x".format(it) } to crc.value
    }
    private val invalid = Regex("[<>:\"|?*\\u0000-\\u001f]")
    private val reserved = Regex("^(con|prn|aux|nul|com[1-9]|lpt[1-9])(\\..*)?$", RegexOption.IGNORE_CASE)
    fun sanitize(seg: String): String {
        var s = java.text.Normalizer.normalize(seg, java.text.Normalizer.Form.NFC).replace(Regex("[\u200e\u200f\u202a-\u202e\u2066-\u2069]"), "").replace(invalid, "_")
        s = s.trimEnd('.', ' ').trimStart(' ')
        if (s.isEmpty()) s = "_"
        if (reserved.matches(s)) s = "_$s"
        return s
    }
    fun archiveExt(n: String): Boolean = Regex("(?i)\\.(zip|7z|rar|cbz|cbr|cb7|tar|tgz|tar\\.gz|tar\\.bz2|tar\\.xz|tbz2|txz|part0*\\d+\\.rar|7z\\.\\d{3}|zip\\.\\d{3}|z\\d{2}|r\\d{2})$").containsMatchIn(n)
}

data class Entry(val index: Int, val path: String, val size: Long, val crc: Long?, val isDir: Boolean, val symlink: Boolean, val encrypted: Boolean)
data class ArchiveGroup(val base: String, val primary: File, val parts: List<File>, val missing: List<String>, val size: Long)
data class ScannedComic(val rel: String, val name: String, val folder: String, val author: String, val pages: Int, val size: Long, val mtime: Long)
data class ScanResult(val comics: List<ScannedComic>, val archives: List<Pair<String, ArchiveGroup>>, val dirs: List<String>)

object Scanner {
    private val partRar = Regex("(?i)^(.*)\\.part0*(\\d+)\\.rar$")
    private val numbered = Regex("(?i)^(.*)\\.(7z|zip|rar|tar)\\.(\\d{3})$")
    private val zipZ = Regex("(?i)^(.*)\\.z(\\d{2})$")
    private val rarR = Regex("(?i)^(.*)\\.r(\\d{2})$")
    private val single = Regex("(?i)^(.*)\\.(zip|7z|rar|cbz|cbr|cb7|tar|tgz|tar\\.gz|tar\\.bz2|tar\\.xz|tbz2|txz)$")

    fun groupArchives(dir: File, files: List<File>): List<ArchiveGroup> {
        val out = mutableListOf<ArchiveGroup>()
        val sets = HashMap<String, MutableList<Pair<Int, File>>>()
        val used = HashSet<File>()
        for (f in files) {
            val n = f.name
            val key = partRar.find(n)?.let { "rp|${it.groupValues[1].lowercase()}" to it.groupValues[2].toInt() }
                ?: numbered.find(n)?.let { "nm|${it.groupValues[1].lowercase()}|${it.groupValues[2].lowercase()}" to it.groupValues[3].toInt() }
                ?: zipZ.find(n)?.let { "zz|${it.groupValues[1].lowercase()}" to it.groupValues[2].toInt() }
                ?: rarR.find(n)?.let { "rr|${it.groupValues[1].lowercase()}" to it.groupValues[2].toInt() + 1 } ?: continue
            sets.getOrPut(key.first) { mutableListOf() }.add(key.second to f); used.add(f)
        }
        for ((k, items) in sets) {
            val kind = k.substringBefore('|'); val sorted = items.sortedBy { it.first }; val max = sorted.last().first
            val base = (partRar.find(sorted[0].second.name) ?: numbered.find(sorted[0].second.name) ?: zipZ.find(sorted[0].second.name) ?: rarR.find(sorted[0].second.name))!!.groupValues[1]
            val parts = sorted.map { it.second }.toMutableList(); val missing = mutableListOf<String>()
            for (i in 1..max) if (sorted.none { it.first == i }) missing += when (kind) { "rp" -> "$base.part$i.rar"; "nm" -> "$base.${k.split('|')[2]}.%03d".format(i); "zz" -> "$base.z%02d".format(i); else -> "$base.r%02d".format(i - 1) }
            var primary = sorted.first().second
            if (kind == "zz" || kind == "rr") {
                val ext = if (kind == "zz") "zip" else "rar"
                val main = files.firstOrNull { it.name.equals("$base.$ext", true) }
                if (main != null) { primary = main; parts.add(0, main); used.add(main) } else missing += "$base.$ext"
            }
            out += ArchiveGroup(base, primary, parts, missing, parts.sumOf { it.length() })
        }
        for (f in files) if (f !in used) single.find(f.name)?.let { out += ArchiveGroup(it.groupValues[1], f, listOf(f), emptyList(), f.length()) }
        return out
    }

    fun scan(root: File, prev: Map<String, Pair<Long, Int>>, progress: (Int, Int) -> Unit): ScanResult {
        val comics = java.util.concurrent.ConcurrentLinkedQueue<ScannedComic>()
        val archives = java.util.concurrent.ConcurrentLinkedQueue<Pair<String, ArchiveGroup>>()
        val dirs = java.util.concurrent.ConcurrentLinkedQueue<String>()
        val pool = Executors.newFixedThreadPool(8)
        val pending = AtomicInteger(0); val seen = AtomicInteger(0); val latch = java.util.concurrent.CountDownLatch(1)
        fun walk(dir: File, rel: String) {
            pending.incrementAndGet()
            pool.execute {
                try {
                    val kids = dir.listFiles() ?: emptyArray()
                    val images = kids.filter { it.isFile && Util.isImage(it.name) }
                    val archFiles = kids.filter { it.isFile && !Util.isImage(it.name) && Util.archiveExt(it.name) && !it.name.startsWith(".") }
                    if (rel.isNotEmpty()) dirs.add(rel)
                    if (images.isNotEmpty()) {
                        val mtime = dir.lastModified(); val p = prev[rel]
                        val size = if (p != null && p.first == mtime && p.second == images.size) -1L else images.sumOf { it.length() }
                        val parts = rel.split('/')
                        comics.add(ScannedComic(rel, parts.last(), parts.dropLast(1).joinToString("/"), if (parts.size > 1) parts[0] else "", images.size, size, mtime))
                    }
                    for (g in groupArchives(dir, archFiles)) archives.add((if (rel.isEmpty()) g.primary.name else "$rel/${g.primary.name}") to g)
                    progress(seen.incrementAndGet(), comics.size)
                    for (k in kids) if (k.isDirectory && !k.name.startsWith(".") && !java.nio.file.Files.isSymbolicLink(k.toPath())) walk(k, if (rel.isEmpty()) k.name else "$rel/${k.name}")
                } finally {
                    if (pending.decrementAndGet() == 0) latch.countDown()
                }
            }
        }
        walk(root, "")
        latch.await(); pool.shutdown()
        return ScanResult(comics.sortedWith { a, b -> Util.natural.compare(a.rel, b.rel) }, archives.toList(), dirs.sortedWith(Util.natural))
    }
}

class WrongPassword : Exception("Wrong password")

/** 7-Zip-JBinding wrapper (7-Zip 16.02 core): ZIP, 7Z, RAR, RAR5, TAR, GZ, BZ2, XZ and multi-volume sets. */
class Sz(private val job: ArchiveFile) : AutoCloseable {
    private var archive: IInArchive? = null
    private val streams = mutableListOf<RandomAccessFile>()

    inner class VolCb(var name: String) : IArchiveOpenVolumeCallback, IArchiveOpenCallback {
        override fun getProperty(p: PropID?): Any? = if (p == PropID.NAME) name else null
        override fun getStream(filename: String?): IInStream? {
            val f = File(job.dir, File(filename ?: return null).name)
            if (!f.exists()) return null
            name = f.name
            return RandomAccessFile(f, "r").also { streams += it }.let { RandomAccessFileInStream(it) }
        }
        override fun setTotal(f: Long?, b: Long?) {}
        override fun setCompleted(f: Long?, b: Long?) {}
    }

    fun open(password: String?): Sz {
        val first = job.primary
        archive = if (job.parts.size > 1) {
            val cb = VolCb(first.name)
            SevenZip.openInArchive(null, cb.getStream(first.name), cb)
        } else {
            val raf = RandomAccessFile(first, "r").also { streams += it }
            if (password != null) SevenZip.openInArchive(null, RandomAccessFileInStream(raf), password) else SevenZip.openInArchive(null, RandomAccessFileInStream(raf))
        }
        return this
    }

    fun entries(): List<Entry> {
        val a = archive!!
        return (0 until a.numberOfItems).map { i ->
            val attr = (a.getProperty(i, PropID.ATTRIBUTES) as? Int) ?: 0
            val unixLink = (attr and 0x8000) != 0 && ((attr ushr 16) and 0xF000) == 0xA000
            Entry(i, (a.getProperty(i, PropID.PATH) as? String) ?: "", (a.getProperty(i, PropID.SIZE) as? Long) ?: 0L,
                (a.getProperty(i, PropID.CRC) as? Int)?.toLong()?.and(0xffffffffL), (a.getProperty(i, PropID.IS_FOLDER) as? Boolean) ?: false,
                unixLink, (a.getProperty(i, PropID.ENCRYPTED) as? Boolean) ?: false)
        }
    }

    /** Layer 1 equivalent of `7z t`. Returns null when fine, otherwise the failure text. */
    fun test(password: String?, cancelled: () -> Boolean): String? {
        var err: String? = null
        archive!!.extract(null, true, object : IArchiveExtractCallback {
            override fun getStream(i: Int, m: ExtractAskMode?): ISequentialOutStream? = null
            override fun prepareOperation(m: ExtractAskMode?) {}
            override fun setOperationResult(r: ExtractOperationResult?) { if (r != null && r != ExtractOperationResult.OK && err == null) err = r.name }
            override fun setTotal(t: Long) {}
            override fun setCompleted(c: Long) { if (cancelled()) throw SevenZipException("cancelled") }
        }.let { cb -> if (password != null) PwCb(cb, password) else cb })
        return err
    }

    /** Streams selected entries straight to their planned destination, hashing as they are written. */
    fun extract(indices: IntArray?, password: String?, dest: (Int) -> File?, onBytes: (Long) -> Unit, cancelled: () -> Boolean): Map<Int, String> {
        val problems = HashMap<Int, String>()
        val cb = object : IArchiveExtractCallback {
            var cur = -1; var out: FileOutputStream? = null
            override fun getStream(i: Int, m: ExtractAskMode?): ISequentialOutStream? {
                if (m != ExtractAskMode.EXTRACT) return null
                cur = i; val f = dest(i) ?: return null
                f.parentFile?.mkdirs(); out = FileOutputStream(f)
                return ISequentialOutStream { data -> out!!.write(data); onBytes(data.size.toLong()); data.size }
            }
            override fun prepareOperation(m: ExtractAskMode?) {}
            override fun setOperationResult(r: ExtractOperationResult?) {
                out?.close(); out = null
                if (r != null && r != ExtractOperationResult.OK) problems[cur] = r.name
            }
            override fun setTotal(t: Long) {}
            override fun setCompleted(c: Long) { if (cancelled()) throw SevenZipException("cancelled") }
        }
        archive!!.extract(indices, false, if (password != null) PwCb(cb, password) else cb)
        return problems
    }

    private class PwCb(private val d: IArchiveExtractCallback, private val pw: String) : IArchiveExtractCallback by d, net.sf.sevenzipjbinding.ICryptoGetTextPassword {
        override fun cryptoGetTextPassword(): String = pw
    }

    override fun close() {
        runCatching { archive?.close() }
        streams.forEach { runCatching { it.close() } }
    }
}

data class ArchiveFile(val id: String, val primary: File, val parts: List<File>, val missing: List<String>, val name: String) {
    val dir: File get() = primary.parentFile!!
}

/** Alternate engine (Apache Commons Compress) used when 7-Zip fails: ZIP, 7Z and TAR, no passwords. */
object Alt {
    fun extractAll(a: ArchiveFile, dest: (String) -> File?, cancelled: () -> Boolean): String? {
        val n = a.primary.name.lowercase(Locale.ROOT)
        try {
            when {
                n.endsWith(".zip") || n.endsWith(".cbz") -> ZipFile(a.primary).use { z ->
                    for (e in z.entries) { if (cancelled()) return "cancelled"; if (e.isDirectory) continue; val f = dest(e.name) ?: continue; f.parentFile?.mkdirs(); z.getInputStream(e).use { i -> FileOutputStream(f).use { o -> i.copyTo(o) } } }
                }
                n.endsWith(".7z") || n.endsWith(".cb7") -> SevenZFile(a.primary).use { z ->
                    while (true) { val e = z.nextEntry ?: break; if (cancelled()) return "cancelled"; if (e.isDirectory) continue; val f = dest(e.name) ?: continue; f.parentFile?.mkdirs(); FileOutputStream(f).use { o -> val b = ByteArray(1 shl 16); while (true) { val r = z.read(b); if (r < 0) break; o.write(b, 0, r) } } }
                }
                n.endsWith(".tar") -> TarArchiveInputStream(a.primary.inputStream().buffered()).use { t ->
                    while (true) { val e = t.nextTarEntry ?: break; if (cancelled()) return "cancelled"; if (e.isDirectory) continue; val f = dest(e.name) ?: continue; f.parentFile?.mkdirs(); FileOutputStream(f).use { o -> t.copyTo(o) } }
                }
                else -> return "alternate engine does not support this format"
            }
        } catch (e: Exception) { return e.message ?: e.javaClass.simpleName }
        return null
    }
}
