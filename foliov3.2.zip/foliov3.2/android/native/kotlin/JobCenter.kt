package app.comiclib.mobile

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.Executors

class Job(val id: String, val kind: String, val title: String, val payload: JSONObject, val group: String?, val createdAt: Long = System.currentTimeMillis()) {
    @Volatile var state = "queued"; @Volatile var progress = 0.0; var done = 0; var total = 1; var bytes = 0L; var totalBytes = 0L
    var speed = 0.0; var eta: Double? = null; var message = "Queued"; var error: String? = null; var attempts = 0; var startedAt = 0L; var finishedAt = 0L
    @Volatile var abort: String? = null
    private var lastT = 0L; private var lastB = 0L
    fun update(fraction: Double, msg: String, b: Long) {
        progress = fraction.coerceIn(0.0, 1.0); message = msg
        val now = System.currentTimeMillis()
        if (b > 0 && now - lastT > 500) { val inst = (b - lastB) * 1000.0 / maxOf(1, now - lastT); speed = if (speed > 0) speed * 0.7 + inst * 0.3 else inst; lastT = now; lastB = b; bytes = b }
        eta = if (speed > 0 && totalBytes > bytes) (totalBytes - bytes) / speed else if (progress in 0.02..0.99) (now - startedAt) / 1000.0 * (1 - progress) / progress else null
    }
    fun json() = JSONObject().put("id", id).put("kind", kind).put("title", title).put("state", state).put("progress", progress).put("done", done).put("total", total)
        .put("bytes", bytes).put("totalBytes", totalBytes).put("speed", speed).put("etaSec", eta ?: JSONObject.NULL).put("message", message).put("error", error ?: JSONObject.NULL)
        .put("attempts", attempts).put("createdAt", createdAt).put("group", group ?: JSONObject.NULL).put("payload", payload)
}

/** Generic job framework: queue, progress, persistence, pause, cancel, retry. The service keeps the process alive. */
object JobCenter {
    lateinit var app: Context; lateinit var db: ComicDb
    private val jobs = LinkedHashMap<String, Job>()
    private val handlers = HashMap<String, (Job) -> Unit>()
    val listeners = CopyOnWriteArrayList<() -> Unit>()
    @Volatile var paused = false; @Volatile var workers = 2
    private val pool = Executors.newCachedThreadPool()
    private var running = 0
    private var seq = 0
    var finishedOk = 0; var finishedBad = 0

    fun init(ctx: Context, database: ComicDb) { if (!::app.isInitialized) { app = ctx.applicationContext; db = database; restore() } }
    fun register(kind: String, h: (Job) -> Unit) { handlers[kind] = h }

    @Synchronized fun add(kind: String, title: String, payload: JSONObject, group: String?, totalBytes: Long = 0): Job {
        val j = Job("job-${System.currentTimeMillis().toString(36)}-${++seq}", kind, title, payload, group); j.totalBytes = totalBytes
        jobs[j.id] = j; changed(); WorkService.ensure(app); pump(); return j
    }
    @Synchronized fun list(): List<Job> = jobs.values.toList()
    fun state(): JSONObject = JSONObject().put("jobs", JSONArray(list().map { it.json() })).put("paused", paused)
    @Synchronized fun active(): Boolean = running > 0 || (!paused && jobs.values.any { it.state == "queued" })
    @Synchronized fun pauseAll() { paused = true; jobs.values.filter { it.state == "running" }.forEach { it.abort = "pause" }; changed() }
    @Synchronized fun resumeAll() { paused = false; jobs.values.filter { it.state == "paused" }.forEach { it.state = "queued" }; changed(); WorkService.ensure(app); pump() }
    @Synchronized fun cancel(id: String?) { for (j in jobs.values) if (id == null || j.id == id) { if (j.state == "running") j.abort = "cancel" else if (j.state == "queued" || j.state == "paused") { j.state = "cancelled"; j.message = "Cancelled" } }; changed() }
    @Synchronized fun retry(id: String) { jobs[id]?.takeIf { it.state == "failed" || it.state == "cancelled" }?.let { it.state = "queued"; it.error = null; it.progress = 0.0; changed(); pump() } }
    @Synchronized fun clearFinished() { jobs.values.removeAll { it.state in listOf("done", "failed", "cancelled") }; changed() }

    @Synchronized private fun pump() {
        while (!paused && running < workers) {
            val j = jobs.values.firstOrNull { it.state == "queued" } ?: break
            running++; j.state = "running"; j.attempts++; j.startedAt = System.currentTimeMillis(); j.abort = null
            pool.execute { run(j) }
        }
        listeners.forEach { it() }
    }

    private fun run(j: Job) {
        try {
            handlers[j.kind]?.invoke(j) ?: throw IllegalStateException("No handler for ${j.kind}")
            when (j.abort) { "cancel" -> { j.state = "cancelled"; j.message = "Cancelled" }; "pause" -> { j.state = "paused"; j.message = "Paused" }; else -> { j.state = "done"; j.progress = 1.0; j.message = "Done"; finishedOk++ } }
        } catch (e: Exception) {
            when (j.abort) { "cancel" -> j.state = "cancelled"; "pause" -> j.state = "paused"; else -> { j.state = "failed"; j.error = e.message; j.message = e.message ?: "Failed"; finishedBad++ } }
        } finally {
            synchronized(this) { running--; j.speed = 0.0; if (j.state != "paused") j.finishedAt = System.currentTimeMillis() }
            changed(); pump()
        }
    }

    private fun changed() {
        runCatching {
            db.tx {
                db.db.execSQL("DELETE FROM jobs")
                for (j in list()) db.db.execSQL("INSERT INTO jobs(id,json,updated_at) VALUES(?,?,?)", arrayOf(j.id, JSONObject().put("kind", j.kind).put("title", j.title).put("payload", j.payload).put("group", j.group ?: JSONObject.NULL).put("state", j.state).put("totalBytes", j.totalBytes).toString(), j.createdAt))
            }
        }
        listeners.forEach { it() }
    }

    /** After the OS killed the process or the phone rebooted, queued and interrupted jobs resume automatically. */
    private fun restore() {
        val rows = db.rows("SELECT id,json FROM jobs ORDER BY updated_at")
        for (i in 0 until rows.length()) {
            val o = JSONObject(rows.getJSONObject(i).getString("json"))
            if (o.getString("state") in listOf("queued", "running", "paused")) {
                val j = Job(rows.getJSONObject(i).getString("id"), o.getString("kind"), o.getString("title"), o.getJSONObject("payload"), o.optString("group").takeIf { it.isNotEmpty() && it != "null" }); j.totalBytes = o.optLong("totalBytes"); j.message = "Resumed after restart"; jobs[j.id] = j
            }
        }
    }
    fun hasWork(): Boolean = synchronized(this) { jobs.values.any { it.state in listOf("queued", "running", "paused") } }
}

class WorkService : Service() {
    private var wake: PowerManager.WakeLock? = null
    private var lastNotify = 0L
    private val tick: () -> Unit = { update() }

    companion object {
        const val CH = "comiclib-work"; const val CH_DONE = "comiclib-done"
        const val A_PAUSE = "app.comiclib.PAUSE"; const val A_RESUME = "app.comiclib.RESUME"; const val A_CANCEL = "app.comiclib.CANCEL"
        fun ensure(ctx: Context) { runCatching { ContextCompat.startForegroundService(ctx, Intent(ctx, WorkService::class.java)) } }
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel(CH, "Background tasks", NotificationManager.IMPORTANCE_LOW))
            nm.createNotificationChannel(NotificationChannel(CH_DONE, "Task summaries", NotificationManager.IMPORTANCE_DEFAULT))
        }
        ComicApp.ensure(this)
        when (intent?.action) { A_PAUSE -> JobCenter.pauseAll(); A_RESUME -> JobCenter.resumeAll(); A_CANCEL -> JobCenter.cancel(null) }
        val n = build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC) else startForeground(1, n)
        if (wake == null) wake = getSystemService(PowerManager::class.java).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "comiclib:work").apply { acquire(6 * 60 * 60 * 1000L) }
        if (!JobCenter.listeners.contains(tick)) JobCenter.listeners.add(tick)
        update()
        return START_STICKY
    }

    private fun summary(): Triple<Int, Int, Job?> {
        val work = JobCenter.list().filter { it.group == "extract" || it.group == "verify" || it.group == "scan" || it.group == "background" }
        val done = work.count { it.state in listOf("done", "failed", "cancelled") }
        return Triple(done, work.size, work.firstOrNull { it.state == "running" } ?: work.firstOrNull { it.state == "queued" || it.state == "paused" })
    }

    private fun build(): Notification {
        val (done, total, cur) = summary()
        val frac = JobCenter.list().filter { it.group != null }.let { l -> if (l.isEmpty()) 0.0 else l.sumOf { if (it.state in listOf("done", "failed", "cancelled")) 1.0 else it.progress } / l.size }
        val pct = (frac * 100).toInt()
        val eta = cur?.eta?.let { val s = it.toInt(); if (s >= 60) "${s / 60}m ${s % 60}s" else "${s}s" } ?: "--"
        fun act(a: String, label: String) = NotificationCompat.Action(0, label, PendingIntent.getService(this, a.hashCode(), Intent(this, WorkService::class.java).setAction(a), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT))
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, CH).setSmallIcon(android.R.drawable.stat_sys_download).setContentTitle("Comic Library")
            .setContentText("${cur?.title ?: "Working"}  |  ${minOf(done + 1, maxOf(total, 1))} of $total  |  ETA $eta")
            .setSubText("$pct%").setProgress(100, pct, total == 0).setOngoing(true).setOnlyAlertOnce(true).setContentIntent(open)
            .addAction(if (JobCenter.paused) act(A_RESUME, "Resume") else act(A_PAUSE, "Pause")).addAction(act(A_CANCEL, "Cancel")).build()
    }

    private fun update() {
        if (!JobCenter.hasWork() && !JobCenter.active()) { finish(); return }
        val now = System.currentTimeMillis(); if (now - lastNotify < 500) return; lastNotify = now
        getSystemService(NotificationManager::class.java).notify(1, build())
    }

    /** The persistent notification stays until the work is complete, then becomes a completion summary. */
    private fun finish() {
        JobCenter.listeners.remove(tick)
        val ok = JobCenter.finishedOk; val bad = JobCenter.finishedBad; JobCenter.finishedOk = 0; JobCenter.finishedBad = 0
        stopForeground(STOP_FOREGROUND_REMOVE)
        if (ok + bad > 0) getSystemService(NotificationManager::class.java).notify(2, NotificationCompat.Builder(this, CH_DONE).setSmallIcon(android.R.drawable.stat_sys_download_done)
            .setContentTitle("Comic Library: tasks finished").setContentText("$ok succeeded, $bad with errors").setAutoCancel(true)
            .setContentIntent(PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)).build())
        wake?.takeIf { it.isHeld }?.release(); wake = null
        stopSelf()
    }

    override fun onDestroy() { wake?.takeIf { it.isHeld }?.release(); super.onDestroy() }
}

/** Resumes the persisted queue after a reboot (where the OS allows starting the service). */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (i.action == Intent.ACTION_BOOT_COMPLETED || i.action == Intent.ACTION_MY_PACKAGE_REPLACED) {
            runCatching { ComicApp.ensure(c); if (JobCenter.hasWork()) WorkService.ensure(c) }
        }
    }
}
