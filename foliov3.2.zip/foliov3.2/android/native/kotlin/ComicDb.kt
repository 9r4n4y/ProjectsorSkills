package app.comiclib.mobile

import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * Native SQLite (WAL, FTS5 when the platform has it, otherwise FTS4). Migrations come from assets/schema.json, generated from the shared TypeScript
 * schema by scripts/prepare-android.mjs, so PC and Android use exactly the same schema versions.
 */
class ComicDb(private val ctx: Context) {
    lateinit var db: SQLiteDatabase
    private val lock = Any()

    init { open() }

    fun open() {
        val f = ctx.getDatabasePath("library.db")
        f.parentFile?.mkdirs()
        db = SQLiteDatabase.openOrCreateDatabase(f, null)
        db.enableWriteAheadLogging()
        db.execSQL("PRAGMA foreign_keys=ON")
        migrate()
    }

    fun close() = db.close()

    /** True only if this device's SQLite can create an FTS5 table. Probed in a throwaway temp table, nothing else is swallowed. */
    private fun hasFts5(): Boolean = try {
        db.execSQL("CREATE VIRTUAL TABLE temp.__fts5_probe USING fts5(x)")
        db.execSQL("DROP TABLE temp.__fts5_probe")
        true
    } catch (e: android.database.sqlite.SQLiteException) {
        val m = e.message ?: ""
        if (m.contains("no such module", ignoreCase = true) || m.contains("fts5", ignoreCase = true)) false else throw e
    }

    private fun migrate() {
        val migs = JSONArray(ctx.assets.open("schema.json").bufferedReader().use { it.readText() })
        val fts5 = hasFts5()
        android.util.Log.i("ComicDb", "SQLite ${scalarString("select sqlite_version()")}, FTS5=$fts5, user_version=${db.version}")
        for (i in 0 until migs.length()) {
            val m = migs.getJSONObject(i)
            val v = m.getInt("version")
            if (v <= db.version) continue
            val sql = if (!fts5 && m.has("sqlNoFts5")) m.getString("sqlNoFts5") else m.getString("sql")
            db.beginTransaction()
            try {
                // each statement is reported with the migration number so a failure in logcat names its cause
                sql.split(";").map { it.trim() }.filter { it.isNotEmpty() }.forEach {
                    try { db.execSQL(it) } catch (e: Exception) { throw IllegalStateException("Migration $v failed on: ${it.take(120)}", e) }
                }
                db.version = v
                db.setTransactionSuccessful()
            } finally {
                db.endTransaction()
            }
        }
    }

    private fun scalarString(sql: String): String = db.rawQuery(sql, null).use { if (it.moveToFirst()) it.getString(0) else "?" }

    fun <T> tx(block: () -> T): T = synchronized(lock) {
        db.beginTransaction()
        try {
            val r = block()
            db.setTransactionSuccessful()
            r
        } finally {
            db.endTransaction()
        }
    }

    fun rows(sql: String, vararg args: String): JSONArray {
        val out = JSONArray()
        db.rawQuery(sql, arrayOf(*args)).use { c ->
            while (c.moveToNext()) {
                val o = JSONObject()
                for (i in 0 until c.columnCount) {
                    val n = c.getColumnName(i)
                    when (c.getType(i)) {
                        Cursor.FIELD_TYPE_INTEGER -> o.put(n, c.getLong(i))
                        Cursor.FIELD_TYPE_FLOAT -> o.put(n, c.getDouble(i))
                        Cursor.FIELD_TYPE_NULL -> o.put(n, JSONObject.NULL)
                        else -> o.put(n, c.getString(i))
                    }
                }
                out.put(o)
            }
        }
        return out
    }

    fun scalar(sql: String, vararg args: String): Long = db.rawQuery(sql, arrayOf(*args)).use { if (it.moveToFirst()) it.getLong(0) else 0L }

    fun setting(key: String): String? = db.rawQuery("SELECT value FROM settings WHERE key=?", arrayOf(key)).use { if (it.moveToFirst()) it.getString(0) else null }
    fun putSetting(key: String, value: String) = db.execSQL("INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value", arrayOf(key, value))

    fun ftsPut(id: String) {
        db.execSQL("DELETE FROM comic_fts WHERE comic_id=?", arrayOf(id))
        db.rawQuery("SELECT name,folder,author FROM comics WHERE id=?", arrayOf(id)).use { c ->
            if (!c.moveToFirst()) return
            val tags = rows("SELECT tag FROM comic_tags WHERE comic_id=?", id).let { a -> (0 until a.length()).joinToString(" ") { a.getJSONObject(it).getString("tag") } }
            db.execSQL(
                "INSERT INTO comic_fts(comic_id,name,folder,author,tags) VALUES(?,?,?,?,?)",
                arrayOf(id, Util.normalize(c.getString(0)), Util.normalize(c.getString(1)), Util.normalize(c.getString(2)), Util.normalize(tags)),
            )
        }
    }

    fun ftsRebuild(): Long {
        tx {
            db.execSQL("DELETE FROM comic_fts")
            rows("SELECT id FROM comics").let { a -> for (i in 0 until a.length()) ftsPut(a.getJSONObject(i).getString("id")) }
        }
        return scalar("SELECT COUNT(*) FROM comic_fts")
    }

    fun integrity(): List<String> = db.rawQuery("PRAGMA integrity_check", null).use { c -> generateSequence { if (c.moveToNext()) c.getString(0) else null }.toList() }

    // ---- passwords are encrypted with an Android Keystore AES-GCM key ----------------------------------------
    private fun key(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey("comiclib-vault", null) as? SecretKey)?.let { return it }
        val g = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        g.init(KeyGenParameterSpec.Builder("comiclib-vault", KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build())
        return g.generateKey()
    }

    fun encrypt(s: String): String {
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, key())
        return Base64.encodeToString(c.iv + c.doFinal(s.toByteArray()), Base64.NO_WRAP)
    }

    fun decrypt(s: String): String {
        val b = Base64.decode(s, Base64.NO_WRAP)
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, b, 0, 12))
        return String(c.doFinal(b, 12, b.size - 12))
    }

    fun passwords(): List<String> = rows("SELECT blob FROM passwords").let { a -> (0 until a.length()).mapNotNull { runCatching { decrypt(a.getJSONObject(it).getString("blob")) }.getOrNull() } }
}
