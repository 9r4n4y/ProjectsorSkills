// @vitest-environment jsdom
import { describe, expect, it } from "vitest";

describe("android Back priority", () => {
  it("dismisses overlays LIFO, then selection, then nested screens, then reports root (so native can minimise)", async () => {
    const { handleBack, useBackClose } = await import("../src/lib/hooks");
    const { useStore } = await import("../src/lib/store");
    expect(typeof (window as any).__comicBack).toBe("function");
    expect(typeof useBackClose).toBe("function");

    useStore.setState({ screen: "settings", selectMode: false });
    expect(handleBack()).toBe(true); // nested screen -> library
    expect(useStore.getState().screen).toBe("library");

    useStore.setState({ selectMode: true });
    expect(handleBack()).toBe(true);
    expect(useStore.getState().selectMode).toBe(false);

    expect(handleBack()).toBe(false); // library root, nothing open: native moves the task to background
  });
});
