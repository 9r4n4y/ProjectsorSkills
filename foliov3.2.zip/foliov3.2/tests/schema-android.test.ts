import { describe, expect, it } from "vitest";
import { COMIC_FTS4_DDL, MIGRATIONS } from "../shared/src/schema";

// Android's platform SQLite may lack FTS5. Any migration that uses it must ship an FTS4-based fallback,
// otherwise the app crashes in ComicApp.ensure() on first launch.
describe("android schema compatibility", () => {
  it("versions are strictly increasing", () => {
    MIGRATIONS.forEach((m, i) => expect(m.version).toBe(i + 1));
  });

  it("every fts5 migration has a fallback with no fts5 and no unsupported FTS features", () => {
    for (const m of MIGRATIONS) {
      if (!/fts5/i.test(m.sql)) continue;
      expect(m.sqlNoFts5, `migration ${m.version} uses fts5 but has no sqlNoFts5 fallback`).toBeTruthy();
      expect(m.sqlNoFts5).not.toMatch(/fts5|UNINDEXED|bm25|highlight\(|snippet\(.*,.*,.*,.*,.*\)/i);
      expect(m.sqlNoFts5).toMatch(/USING fts4/i);
    }
  });

  it("fallback creates the same tables as the primary migration", () => {
    const tables = (sql: string) => [...sql.matchAll(/CREATE (?:VIRTUAL )?TABLE (\w+)/g)].map((x) => x[1]).sort();
    for (const m of MIGRATIONS) if (m.sqlNoFts5) expect(tables(m.sqlNoFts5)).toEqual(tables(m.sql));
  });

  it("FTS4 DDL uses only options present in SQLite 3.8.10 (Android API 23)", () => {
    expect(COMIC_FTS4_DDL).toMatch(/notindexed=comic_id/);
    expect(COMIC_FTS4_DDL).toMatch(/tokenize=unicode61 "remove_diacritics=1"/); // =2 needs SQLite 3.27
    expect(COMIC_FTS4_DDL).not.toMatch(/remove_diacritics=2|contentless|prefix=/);
  });

  it("no migration SQL has a bare semicolon inside a string literal (Kotlin splits on ';')", () => {
    for (const m of MIGRATIONS) for (const sql of [m.sql, m.sqlNoFts5 ?? ""]) expect(sql.replace(/'[^']*'/g, "")).not.toMatch(/'/);
    for (const m of MIGRATIONS) for (const sql of [m.sql, m.sqlNoFts5 ?? ""]) expect([...sql.matchAll(/'([^']*)'/g)].some((x) => x[1].includes(";"))).toBe(false);
  });
});
