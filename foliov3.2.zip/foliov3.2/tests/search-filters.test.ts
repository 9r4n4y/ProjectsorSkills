import { describe, expect, it } from "vitest";
import {
  type ComicRecord,
  EMPTY_FILTERS,
  SearchIndex,
  filterComics,
  naturalCompare,
  normalizeText,
  stem,
  toggleInEx,
} from "@comiclib/shared";

const mk = (id: string, name: string, folder: string, tags: string[] = [], extra: Partial<ComicRecord> = {}): ComicRecord => ({
  id,
  path: "/lib/" + folder + "/" + name,
  relPath: folder + "/" + name,
  name,
  folder,
  author: folder.split("/")[0] ?? "",
  pages: 10,
  size: 1000,
  mtime: 0,
  addedAt: 0,
  favorite: false,
  read: false,
  lastPage: 0,
  lastReadAt: 0,
  tags,
  thumbRev: 0,
  ...extra,
});

const comics = [
  mk("1", "[Sisters] Summer Days (v2)", "Aoki", ["romance", "color"]),
  mk("2", "Sister's Secret", "Aoki", ["drama"]),
  mk("3", "Caf\u00e9 Noir", "Brandt/Series", ["color"]),
  mk("4", "Dragon Quest", "Brandt", ["action", "color"]),
  mk("5", "Dragons of Spring", "Chen", ["action"]),
];

describe("normalization", () => {
  it("ignores brackets, punctuation, case, diacritics and extra spaces", () => {
    expect(normalizeText("[Sisters]  Bon-Bon_(v2).cbz")).toBe("sisters bon bon v2 cbz");
    expect(normalizeText("Caf\u00e9")).toBe("cafe");
    expect(normalizeText("Sister's")).toBe("sisters");
  });
  it("stems plurals", () => {
    expect(stem("sisters")).toBe("sister");
    expect(stem("stories")).toBe("story");
    expect(stem("glass")).toBe("glass");
  });
  it("sorts naturally", () => {
    expect(["page10", "page2", "page1"].sort(naturalCompare)).toEqual(["page1", "page2", "page10"]);
  });
});

describe("search", () => {
  const idx = new SearchIndex();
  idx.build(comics);
  it("matches 'sister' to [Sisters] and sister's", () => {
    const r = idx.search("sister")!;
    expect(r).toContain("1");
    expect(r).toContain("2");
    expect(r).not.toContain("3");
  });
  it("matches diacritics-free queries", () => expect(idx.search("cafe")).toEqual(["3"]));
  it("supports prefix matching", () => expect(idx.search("drag")!.sort()).toEqual(["4", "5"]));
  it("tolerates a small typo", () => expect(idx.search("dragn")).toBeDefined());
  it("fuzzy match finds the typo'd word", () => expect(idx.search("secrat")).toEqual(["2"]));
  it("searches author, folder and tags", () => {
    expect(idx.search("aoki")!.sort()).toEqual(["1", "2"]);
    expect(idx.search("series")).toEqual(["3"]);
    expect(idx.search("action")!.sort()).toEqual(["4", "5"]);
  });
  it("ranks exact before prefix before fuzzy", () => {
    const i = new SearchIndex();
    i.build([
      mk("a", "Dragonfly", "x"),
      mk("b", "Dragon", "x"),
      mk("c", "Dragen", "x"),
    ]);
    const r = i.search("dragon")!;
    expect(r).toEqual(["b", "a"]);
    // fuzzy only applies when exact, prefix and stem find nothing
    expect(i.search("dragn")).toContain("c");
  });
  it("requires every token", () => expect(idx.search("dragon spring")).toEqual(["5"]));
  it("is fast on 10,000 comics", () => {
    const big = Array.from({ length: 10000 }, (_, i) => mk(String(i), `Comic ${i} Alpha${i % 97} Beta${i % 13}`, `Author${i % 50}`, ["t" + (i % 20)]));
    const t0 = performance.now();
    const b = new SearchIndex();
    b.build(big);
    const built = performance.now() - t0;
    const t1 = performance.now();
    b.search("alpha5 comic");
    b.search("autho");
    b.search("bata3");
    const q = (performance.now() - t1) / 3;
    expect(q).toBeLessThan(100);
    expect(built).toBeLessThan(3000);
  });
});

describe("tag and folder include / exclude", () => {
  it("includes with AND by default", () => {
    const r = filterComics(comics, { ...EMPTY_FILTERS, tagsIn: ["color", "action"] }, null);
    expect(r.map((c) => c.id)).toEqual(["4"]);
  });
  it("includes with OR when requested", () => {
    const r = filterComics(comics, { ...EMPTY_FILTERS, tagsIn: ["romance", "drama"], tagMode: "or" }, null);
    expect(r.map((c) => c.id)).toEqual(["1", "2"]);
  });
  it("excludes tags and wins over include", () => {
    const r = filterComics(comics, { ...EMPTY_FILTERS, tagsIn: ["color"], tagsEx: ["action"] }, null);
    expect(r.map((c) => c.id)).toEqual(["1", "3"]);
  });
  it("scopes to folders, including descendants, and excludes folders", () => {
    expect(filterComics(comics, { ...EMPTY_FILTERS, foldersIn: ["Brandt"] }, null).map((c) => c.id)).toEqual(["3", "4"]);
    expect(filterComics(comics, { ...EMPTY_FILTERS, foldersIn: ["Brandt/Series"] }, null).map((c) => c.id)).toEqual(["3"]);
    expect(filterComics(comics, { ...EMPTY_FILTERS, foldersEx: ["Aoki"] }, null).map((c) => c.id)).toEqual(["3", "4", "5"]);
  });
  it("combines text, tags and folders", () => {
    const idx = new SearchIndex();
    idx.build(comics);
    const r = filterComics(comics, { ...EMPTY_FILTERS, tagsIn: ["color"], foldersEx: ["Brandt/Series"] }, idx.search("sister"));
    expect(r.map((c) => c.id)).toEqual(["1"]);
  });
  it("matches tags case and punctuation insensitively", () => {
    expect(filterComics(comics, { ...EMPTY_FILTERS, tagsIn: ["COLOR"] }, null)).toHaveLength(3);
  });
  it("never keeps a value in both include and exclude", () => {
    let s = toggleInEx([], [], "a", "in");
    s = toggleInEx(s.inc, s.exc, "a", "ex");
    expect(s).toEqual({ inc: [], exc: ["a"] });
    s = toggleInEx(s.inc, s.exc, "a", "ex");
    expect(s).toEqual({ inc: [], exc: [] });
  });
});
