import { describe, expect, it } from "vitest";
import {
  type ComicRecord,
  DEFAULT_SETTINGS,
  JobQueue,
  type JobRecord,
  type JobStore,
  buildMetadata,
  decryptSecret,
  encryptSecret,
  matchRecords,
  mergeUserState,
  sha256Hex,
  summarizeMatches,
  validateMetadata,
} from "@comiclib/shared";

const mk = (id: string, relPath: string, pages: number, extra: Partial<ComicRecord> = {}): ComicRecord => ({
  id,
  path: "/" + relPath,
  relPath,
  name: relPath.split("/").pop()!,
  folder: relPath.split("/").slice(0, -1).join("/"),
  author: relPath.split("/")[0],
  pages,
  size: pages * 10,
  mtime: 0,
  addedAt: 0,
  favorite: false,
  read: false,
  lastPage: 0,
  lastReadAt: 0,
  tags: [],
  thumbRev: 0,
  ...extra,
});

const fp = (n: string) => ({ pages: 5, sizes: "s" + n, first: "f" + n, last: "l" + n });

describe("sha256", () => {
  it("matches known vectors", () => {
    expect(sha256Hex("")).toBe("e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855");
    expect(sha256Hex("abc")).toBe("ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad");
  });
});

describe("metadata validation (safety layers 1 and 2)", () => {
  const src = [mk("1", "A/One", 5, { favorite: true, tags: ["x"] })];
  const file = buildMetadata(src, [{ name: "x" }], DEFAULT_SETTINGS);
  it("accepts a good file", () => expect(validateMetadata(JSON.stringify(file)).ok).toBe(true));
  it("rejects non-JSON, wrong schema, newer version and tampering", () => {
    expect(validateMetadata("{nope")).toMatchObject({ ok: false, stage: "parse" });
    expect(validateMetadata('{"schema":"other"}')).toMatchObject({ ok: false, stage: "schema" });
    expect(validateMetadata(JSON.stringify({ ...file, version: 99 }))).toMatchObject({ ok: false, stage: "version" });
    const tampered = JSON.parse(JSON.stringify(file));
    tampered.data.comics[0].favorite = false;
    expect(validateMetadata(JSON.stringify(tampered))).toMatchObject({ ok: false, stage: "checksum" });
  });
});

describe("metadata import matching", () => {
  const records = [
    { relPath: "A/One", name: "One", folder: "A", pages: 5, favorite: true, read: false, lastPage: 2, lastReadAt: 5, tags: ["t"], fp: fp("1") },
    { relPath: "Old/Two", name: "Two", folder: "Old", pages: 5, favorite: false, read: true, lastPage: 0, lastReadAt: 0, tags: [], fp: fp("2") },
    { relPath: "Old/Three", name: "Three", folder: "Old", pages: 9, favorite: false, read: false, lastPage: 0, lastReadAt: 0, tags: [], fp: fp("3") },
    { relPath: "Old/Four Part", name: "Four Part", folder: "Old", pages: 4, favorite: false, read: false, lastPage: 0, lastReadAt: 0, tags: [], fp: fp("4") },
    { relPath: "Old/Nothing Here", name: "Nothing Here", folder: "Old", pages: 4, favorite: false, read: false, lastPage: 0, lastReadAt: 0, tags: [] },
  ];
  const comics = [
    mk("c1", "A/One", 5, { fp: fp("1") }),
    mk("c2", "New/Renamed", 5, { fp: fp("2") }),
    mk("c3", "New/Three", 9),
    mk("c4", "New/Four Part 1", 4),
  ];
  const m = matchRecords(records, comics);
  it("matches by exact path first", () => {
    expect(m[0]).toMatchObject({ status: "matched", method: "path", comicId: "c1" });
  });
  it("then by fingerprint (handles moves and renames)", () => {
    expect(m[1]).toMatchObject({ method: "fingerprint", comicId: "c2" });
  });
  it("then by normalized name plus page count", () => {
    expect(m[2]).toMatchObject({ method: "name+pages", comicId: "c3" });
  });
  it("then by fuzzy name", () => {
    expect(m[3]).toMatchObject({ method: "fuzzy", comicId: "c4" });
  });
  it("reports unmatched records", () => {
    expect(m[4].status).toBe("unmatched");
    expect(summarizeMatches(m)).toMatchObject({ matched: 4, unmatched: 1, ambiguous: 0 });
  });
  it("flags ambiguity when several comics fit", () => {
    const r = matchRecords([{ ...records[2], relPath: "Gone/Three", fp: undefined, name: "Three" }], [mk("x", "P/Three", 9), mk("y", "Q/Three", 9)]);
    expect(r[0].status).toBe("ambiguous");
    expect(r[0].candidates.sort()).toEqual(["x", "y"]);
  });
  it("flags conflicts and merges state without losing data", () => {
    const c = mk("c1", "A/One", 5, { tags: ["mine"], lastPage: 4, lastReadAt: 9 });
    const r = matchRecords([records[0]], [c]);
    expect(r[0].status).toBe("conflict");
    const merged = mergeUserState(c, records[0]);
    expect(merged.tags).toEqual(["mine", "t"]);
    expect(merged.favorite).toBe(true);
    expect(merged.lastPage).toBe(4);
  });
  it("never claims one comic twice", () => {
    const r = matchRecords([records[0], { ...records[0], relPath: "Z/One" }], [mk("c1", "A/One", 5, { fp: fp("1") })]);
    expect(r.filter((x) => x.comicId === "c1")).toHaveLength(1);
  });
});

describe("password encryption", () => {
  it("round-trips with the right passphrase and fails with a wrong one", async () => {
    const blob = await encryptSecret(JSON.stringify(["a", "b"]), "pass", 1000);
    expect(JSON.parse(await decryptSecret(blob, "pass"))).toEqual(["a", "b"]);
    await expect(decryptSecret(blob, "wrong")).rejects.toBeTruthy();
  });
});

describe("job framework", () => {
  const wait = (ms: number) => new Promise((r) => setTimeout(r, ms));
  it("runs jobs with limited concurrency and reports progress", async () => {
    const q = new JobQueue({ concurrency: 2 });
    let active = 0;
    let peak = 0;
    q.register("t", async (ctx) => {
      active++;
      peak = Math.max(peak, active);
      ctx.progress({ done: 1, total: 2 });
      await wait(20);
      active--;
    });
    for (let i = 0; i < 5; i++) q.add("t", "T" + i, {});
    await q.whenIdle();
    expect(peak).toBe(2);
    expect(q.list().every((j) => j.state === "done")).toBe(true);
  });
  it("pauses, resumes, cancels and retries", async () => {
    const q = new JobQueue({ concurrency: 1 });
    q.register("slow", async (ctx) => {
      await new Promise<void>((res, rej) => {
        const t = setTimeout(res, 60);
        ctx.signal.addEventListener("abort", () => {
          clearTimeout(t);
          rej(new Error("aborted"));
        });
      });
    });
    const a = q.add("slow", "A", {});
    await wait(10);
    q.pauseAll();
    await wait(10);
    expect(q.get(a.id)!.state).toBe("paused");
    q.resumeAll();
    await q.whenIdle();
    expect(q.get(a.id)!.state).toBe("done");
    const b = q.add("slow", "B", {});
    await wait(10);
    q.cancel(b.id);
    await q.whenIdle();
    expect(q.get(b.id)!.state).toBe("cancelled");
    q.retry(b.id);
    await q.whenIdle();
    expect(q.get(b.id)!.state).toBe("done");
  });
  it("marks failures and persists and restores the queue after a crash", async () => {
    let saved: JobRecord[] = [];
    const store: JobStore = { load: async () => saved, save: async (j) => void (saved = JSON.parse(JSON.stringify(j))) };
    const q1 = new JobQueue({ concurrency: 1, store });
    q1.register("hang", () => new Promise(() => undefined));
    q1.add("hang", "H", { n: 1 });
    q1.add("hang", "H2", { n: 2 });
    await q1.flush();
    expect(saved.map((j) => j.state)).toEqual(["running", "queued"]);
    const q2 = new JobQueue({ concurrency: 2, store });
    const seen: unknown[] = [];
    q2.register("hang", async (ctx) => void seen.push(ctx.payload));
    expect(await q2.restore()).toBe(2);
    await q2.whenIdle();
    expect(seen).toEqual([{ n: 1 }, { n: 2 }]);
    q2.register("bad", async () => {
      throw new Error("boom");
    });
    const j = q2.add("bad", "Bad", {});
    await q2.whenIdle();
    expect(q2.get(j.id)).toMatchObject({ state: "failed", error: "boom" });
  });
});
