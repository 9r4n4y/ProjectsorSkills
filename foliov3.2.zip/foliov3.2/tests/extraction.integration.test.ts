// Integration tests: the real extraction pipeline, the real 7-Zip binary and generated fixture archives.
// Covers zip, 7z, password-protected, corrupted, split, nested, multi-comic, single-folder, loose files,
// path traversal and symlinks. RAR needs the proprietary encoder to create fixtures, so it is skipped
// unless a `rar` binary is available.

import { execFileSync } from "node:child_process";
import * as fs from "node:fs";
import * as path from "node:path";
import { path7za } from "7zip-bin";
import { afterAll, beforeAll, describe, expect, it } from "vitest";
import { type ArchiveJob, type ExtractOptions, type IndexPort, MANIFEST_NAME, extractArchive, groupArchives } from "@comiclib/shared";
import { NodeFs, SevenZipEngine, StructuralImageCheck } from "../electron/main/ports";
import { binaryWorks, make7z, makePng, makeZip, tmpDir, write } from "./helpers";

const ok7z = binaryWorks(path7za);
const d = ok7z ? describe : describe.skip;
const nodeFs = new NodeFs();
let root: string;

const index: IndexPort = {
  async register(dir) {
    const n = fs.readdirSync(dir).filter((f) => /\.(png|jpe?g|webp|gif|bmp|avif)$/i.test(f)).length;
    return { pageCount: n, thumbOk: true };
  },
};

function job(file: string, id = "t1"): ArchiveJob {
  const dir = path.dirname(file);
  const g = groupArchives(fs.readdirSync(dir).map((n) => ({ name: n, size: fs.statSync(path.join(dir, n)).size })));
  const grp = g.find((x) => path.join(dir, x.primary) === file || x.parts.includes(path.basename(file)))!;
  return { id, path: path.join(dir, grp.primary), name: grp.base, parentDir: dir, parts: grp.parts, missingParts: grp.missing, size: grp.size };
}

function opts(over: Partial<ExtractOptions> = {}): ExtractOptions {
  return {
    engines: [new SevenZipEngine("7za", path7za)],
    fs: nodeFs,
    image: new StructuralImageCheck(),
    index,
    collision: "suffix",
    quarantineDir: path.join(root, ".quarantine"),
    parallelism: 2,
    ...over,
  };
}

const pages = (n: number, prefix = "", ext = "png") =>
  Object.fromEntries(Array.from({ length: n }, (_, i) => [`${prefix}${String(i + 1).padStart(3, "0")}.${ext}`, makePng(32 + i, 32, i)]));

beforeAll(() => {
  root = tmpDir();
});
afterAll(() => fs.rmSync(root, { recursive: true, force: true }));

const fresh = (name: string) => {
  const dir = path.join(root, name);
  fs.mkdirSync(dir, { recursive: true });
  return dir;
};
const leftovers = (dir: string) => fs.readdirSync(dir).filter((n) => n.startsWith(".comiclib-staging"));

d("extraction pipeline with real archives", () => {
  it("single-folder zip: archive_name/pages with no double nesting, all 10 layers pass", async () => {
    const dir = fresh("single");
    const f = path.join(dir, "Comic One.zip");
    make7z(path7za, f, Object.fromEntries(Object.entries(pages(3, "Comic One/"))), ["-tzip"]);
    const r = await extractArchive(job(f), opts());
    expect(r.status).toBe("done");
    expect(r.layers.map((l) => l.status)).toEqual(["pass", "pass", "pass", "pass", "pass", "pass", "pass", "pass", "pass", "pass"]);
    expect(fs.readdirSync(path.join(dir, "Comic One")).sort()).toEqual([MANIFEST_NAME, "001.png", "002.png", "003.png"].sort());
    expect(fs.existsSync(f)).toBe(true);
    expect(leftovers(dir)).toEqual([]);
    expect(r.comics).toHaveLength(1);
    expect(r.comics[0].pageCount).toBe(3);
  });

  it("loose files go inside archive_name/, never into the parent folder", async () => {
    const dir = fresh("loose");
    const f = path.join(dir, "Loose Pages.7z");
    make7z(path7za, f, pages(2));
    const r = await extractArchive(job(f), opts());
    expect(r.status).toBe("done");
    expect(fs.readdirSync(dir).filter((n) => /\.png$/.test(n))).toEqual([]);
    expect(fs.existsSync(path.join(dir, "Loose Pages", "001.png"))).toBe(true);
  });

  it("multiple top-level folders stay inside archive_name/ and each registers as a comic", async () => {
    const dir = fresh("multi");
    const f = path.join(dir, "Pack.zip");
    make7z(path7za, f, { ...pages(2, "Vol A/"), ...pages(3, "Vol B/") }, ["-tzip"]);
    const r = await extractArchive(job(f), opts());
    expect(r.status).toBe("done");
    expect(r.comics.map((c) => [path.basename(c.dir), c.pageCount]).sort()).toEqual([["Vol A", 2], ["Vol B", 3]]);
    expect(fs.existsSync(path.join(dir, "Pack", "Vol A", "001.png"))).toBe(true);
  });

  it("two archives with the same internal names never mix", async () => {
    const dir = fresh("nomix");
    make7z(path7za, path.join(dir, "First.zip"), pages(2), ["-tzip"]);
    make7z(path7za, path.join(dir, "Second.zip"), pages(4), ["-tzip"]);
    await extractArchive(job(path.join(dir, "First.zip"), "a"), opts());
    await extractArchive(job(path.join(dir, "Second.zip"), "b"), opts());
    expect(fs.readdirSync(path.join(dir, "First")).filter((n) => n.endsWith(".png"))).toHaveLength(2);
    expect(fs.readdirSync(path.join(dir, "Second")).filter((n) => n.endsWith(".png"))).toHaveLength(4);
  });

  it("collision: identical folder is marked done, different folder gets a suffix or asks", async () => {
    const dir = fresh("collide");
    const f = path.join(dir, "Same.zip");
    make7z(path7za, f, pages(2), ["-tzip"]);
    expect((await extractArchive(job(f), opts())).status).toBe("done");
    const again = await extractArchive(job(f), opts());
    expect(again.status).toBe("already_extracted");
    fs.writeFileSync(path.join(dir, "Same", "001.png"), makePng(40, 40, 9));
    const ask = await extractArchive(job(f), opts({ collision: "ask" }));
    expect(ask.status).toBe("needs_input");
    const suffix = await extractArchive(job(f), opts());
    expect(suffix.status).toBe("done");
    expect(fs.existsSync(path.join(dir, "Same (2)", "001.png"))).toBe(true);
    expect(fs.readFileSync(path.join(dir, "Same", "001.png")).length).toBe(makePng(40, 40, 9).length);
  });

  it("page gap is reported as an amber warning with the exact missing number", async () => {
    const dir = fresh("gap");
    const p = pages(4);
    delete p["003.png"];
    const f = path.join(dir, "Gap.zip");
    make7z(path7za, f, p, ["-tzip"]);
    const r = await extractArchive(job(f), opts());
    expect(r.status).toBe("done");
    expect(r.layers[5].status).toBe("warn");
    expect(r.layers[5].details.join()).toContain("3");
  });

  it("password-protected: needs a password, uses a saved one, or the supplied one", async () => {
    const dir = fresh("pw");
    const f = path.join(dir, "Secret.7z");
    make7z(path7za, f, pages(2), ["-pSECRET", "-mhe=on"]);
    const none = await extractArchive(job(f), opts());
    expect(none.status).toBe("needs_password");
    expect(leftovers(dir)).toEqual([]);
    const wrong = await extractArchive(job(f), opts({ password: "nope" }));
    expect(wrong.status).toBe("needs_password");
    const saved = await extractArchive(job(f), opts({ savedPasswords: ["x", "SECRET"] }));
    expect(saved.status).toBe("done");
    expect(saved.passwordUsed).toBe("SECRET");
    const dir2 = fresh("pw2");
    const f2 = path.join(dir2, "Zipped.zip");
    make7z(path7za, f2, pages(2), ["-tzip", "-pSECRET"]);
    expect((await extractArchive(job(f2), opts())).status).toBe("needs_password");
    expect((await extractArchive(job(f2), opts({ password: "SECRET" }))).status).toBe("done");
  });

  it("corrupted archive is quarantined, the original is untouched, nothing is left in staging", async () => {
    const dir = fresh("corrupt");
    const f = path.join(dir, "Broken.zip");
    make7z(path7za, f, pages(3, "", "png"), ["-tzip", "-mx=0"]);
    const bytes = fs.readFileSync(f);
    bytes[Math.floor(bytes.length / 3)] ^= 0xff;
    fs.writeFileSync(f, bytes);
    const before = fs.readFileSync(f);
    const r = await extractArchive(job(f), opts());
    expect(["quarantined", "failed"]).toContain(r.status);
    expect(r.layers.some((l) => l.status === "fail")).toBe(true);
    expect(fs.readFileSync(f).equals(before)).toBe(true);
    expect(fs.existsSync(path.join(dir, "Broken"))).toBe(false);
    expect(leftovers(dir)).toEqual([]);
  });

  it("valid archive holding an undecodable image fails layer 5 without wasting retries", async () => {
    const dir = fresh("badimg");
    const f = path.join(dir, "BadImage.zip");
    const good = makePng(10, 10, 1);
    make7z(path7za, f, { "001.png": good, "002.png": good.slice(0, good.length - 30) }, ["-tzip"]);
    const r = await extractArchive(job(f), opts());
    expect(r.status).toBe("quarantined");
    expect(r.layers[4].status).toBe("fail");
    expect(r.attempts).toHaveLength(1);
    expect(fs.existsSync(path.join(dir, "BadImage"))).toBe(false);
    expect(fs.readdirSync(path.join(root, ".quarantine")).length).toBeGreaterThan(0);
  });

  it("split volumes extract; a missing part is reported", async () => {
    const dir = fresh("split");
    const f = path.join(dir, "Big.7z");
    make7z(path7za, f, Object.fromEntries(Array.from({ length: 6 }, (_, i) => [`${i}.png`, makePng(60, 60, i)])), ["-v2k", "-mx=0"]);
    const files = fs.readdirSync(dir).sort();
    expect(files.length).toBeGreaterThan(2);
    const ok = await extractArchive(job(path.join(dir, "Big.7z.001")), opts());
    expect(ok.status).toBe("done");
    const dir2 = fresh("split-missing");
    for (const n of files.filter((n) => n !== "Big.7z.002")) fs.copyFileSync(path.join(dir, n), path.join(dir2, n));
    const j = job(path.join(dir2, "Big.7z.001"));
    expect(j.missingParts).toEqual(["Big.7z.002"]);
    const bad = await extractArchive(j, opts());
    expect(bad.status).toBe("failed");
    expect(bad.reason).toContain("Big.7z.002");
  });

  it("nested archive: extracted into its folder and reported for the next scan", async () => {
    const dir = fresh("nested");
    const inner = tmpDir("inner-");
    make7z(path7za, path.join(inner, "inner.zip"), pages(2), ["-tzip"]);
    const f = path.join(dir, "Outer.zip");
    make7z(path7za, f, { "cover.png": makePng(8, 8, 1), "inner.zip": new Uint8Array(fs.readFileSync(path.join(inner, "inner.zip"))) }, ["-tzip"]);
    const r = await extractArchive(job(f), opts());
    expect(r.status).toBe("done");
    expect(r.nestedArchives.map((p) => path.basename(p))).toEqual(["inner.zip"]);
    expect(fs.existsSync(path.join(dir, "Outer", "inner.zip"))).toBe(true);
  });

  it("archive without images is flagged", async () => {
    const dir = fresh("noimg");
    const f = path.join(dir, "Docs.zip");
    make7z(path7za, f, { "a.txt": new TextEncoder().encode("hello") }, ["-tzip"]);
    expect((await extractArchive(job(f), opts())).status).toBe("no_images");
  });

  it("zip slip and symlink entries are rejected and nothing is written", async () => {
    const dir = fresh("evil");
    const f = path.join(dir, "Evil.zip");
    write(f, makeZip([{ name: "../escaped.png", data: makePng(8, 8, 1) }, { name: "1.png", data: makePng(8, 8, 2) }]));
    const r = await extractArchive(job(f), opts());
    expect(r.status).toBe("failed");
    expect(r.reason).toContain("unsafe");
    expect(fs.existsSync(path.join(root, "escaped.png"))).toBe(false);
    expect(fs.existsSync(path.join(dir, "Evil"))).toBe(false);
    const f2 = path.join(dir, "Link.zip");
    write(f2, makeZip([{ name: "link.png", data: new TextEncoder().encode("/etc/passwd"), symlink: true }, { name: "1.png", data: makePng(8, 8, 2) }]));
    const r2 = await extractArchive(job(f2), opts());
    expect(r2.status).toBe("failed");
  });

  it("self-healing: an engine that writes a bad file first is retried and succeeds", async () => {
    const dir = fresh("heal");
    const f = path.join(dir, "Heal.zip");
    make7z(path7za, f, pages(3), ["-tzip"]);
    const real = new SevenZipEngine("7za", path7za);
    let calls = 0;
    const flaky = {
      id: "flaky",
      list: real.list.bind(real),
      test: real.test.bind(real),
      async extract(a: ArchiveJob, dest: string, o: Parameters<typeof real.extract>[2]) {
        const r = await real.extract(a, dest, o);
        if (++calls === 1) fs.writeFileSync(path.join(dest, "002.png"), "garbage");
        return r;
      },
    };
    const r = await extractArchive(job(f), opts({ engines: [flaky, real] }));
    expect(r.status).toBe("done");
    expect(r.attempts.length).toBeGreaterThanOrEqual(2);
    expect(r.attempts[0].ok).toBe(false);
    expect(r.attempts[r.attempts.length - 1].ok).toBe(true);
  });

  it("cancel leaves no staging folder behind", async () => {
    const dir = fresh("cancel");
    const f = path.join(dir, "Cancel.zip");
    make7z(path7za, f, pages(3), ["-tzip"]);
    const ctl = new AbortController();
    ctl.abort();
    const r = await extractArchive(job(f), opts({ signal: ctl.signal }));
    expect(r.status).toBe("cancelled");
    expect(leftovers(dir)).toEqual([]);
    expect(fs.existsSync(path.join(dir, "Cancel"))).toBe(false);
  });
});

const hasRar = (() => {
  try {
    execFileSync("rar", ["-?"], { stdio: "ignore" });
    return true;
  } catch {
    return false;
  }
})();

describe.skipIf(!hasRar)("rar (requires the rar encoder and a 7-Zip build with the RAR codec)", () => {
  it("is exercised only when rar is installed", () => expect(hasRar).toBe(true));
});
