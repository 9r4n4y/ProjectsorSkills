import { describe, expect, it } from "vitest";
import { columnsFor } from "../src/features/library/gridColumns";

describe("grid size steps", () => {
  for (const [name, width, pad, gap] of [["phone 360", 360, 16, 12], ["phone 320", 320, 16, 12], ["tablet 768", 768, 24, 16], ["desktop 1280", 1016, 24, 16]] as const) {
    it(`${name}: all five steps give a different, growing column count`, () => {
      const inner = width - pad * 2;
      const cols = [1, 2, 3, 4, 5].map((d) => columnsFor(inner, gap, d));
      expect(new Set(cols).size).toBe(5);
      expect([...cols].sort((a, b) => a - b)).toEqual(cols);
      expect(cols[0]).toBeGreaterThanOrEqual(1);
    });
  }
});
