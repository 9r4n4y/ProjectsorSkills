// Fixture generation: valid PNGs, a minimal ZIP writer (for hostile archives) and real 7-Zip archives.

import { execFileSync } from "node:child_process";
import * as fs from "node:fs";
import * as os from "node:os";
import * as path from "node:path";
import { deflateSync } from "node:zlib";
import { crc32 } from "@comiclib/shared";

export function makePng(w = 8, h = 8, seed = 0): Uint8Array {
  const chunk = (type: string, data: Uint8Array) => {
    const out = new Uint8Array(12 + data.length);
    const dv = new DataView(out.buffer);
    dv.setUint32(0, data.length);
    out.set(new TextEncoder().encode(type), 4);
    out.set(data, 8);
    dv.setUint32(8 + data.length, crc32(out.subarray(4, 8 + data.length)));
    return out;
  };
  const ihdr = new Uint8Array(13);
  const dv = new DataView(ihdr.buffer);
  dv.setUint32(0, w);
  dv.setUint32(4, h);
  ihdr[8] = 8;
  ihdr[9] = 2;
  const raw = new Uint8Array((w * 3 + 1) * h);
  let s = (seed + 1) * 2654435761;
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w * 3; x++) {
      s = (Math.imul(s, 1103515245) + 12345) >>> 0;
      raw[y * (w * 3 + 1) + 1 + x] = s >>> 24;
    }
  }
  const parts = [new Uint8Array([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]), chunk("IHDR", ihdr), chunk("IDAT", deflateSync(raw)), chunk("IEND", new Uint8Array())];
  const out = new Uint8Array(parts.reduce((s, p) => s + p.length, 0));
  let o = 0;
  for (const p of parts) {
    out.set(p, o);
    o += p.length;
  }
  return out;
}

export interface ZipEntry {
  name: string;
  data?: Uint8Array;
  symlink?: boolean;
}

/** Store-only ZIP writer that accepts any entry name (path traversal, symlink flags). */
export function makeZip(entries: ZipEntry[]): Uint8Array {
  const enc = new TextEncoder();
  const locals: Uint8Array[] = [];
  const centrals: Uint8Array[] = [];
  let offset = 0;
  for (const e of entries) {
    const name = enc.encode(e.name);
    const data = e.data ?? new Uint8Array();
    const crc = crc32(data);
    const lh = new Uint8Array(30 + name.length);
    const l = new DataView(lh.buffer);
    l.setUint32(0, 0x04034b50, true);
    l.setUint16(4, 20, true);
    l.setUint16(6, 0x0800, true);
    l.setUint32(14, crc, true);
    l.setUint32(18, data.length, true);
    l.setUint32(22, data.length, true);
    l.setUint16(26, name.length, true);
    lh.set(name, 30);
    locals.push(lh, data);
    const ch = new Uint8Array(46 + name.length);
    const c = new DataView(ch.buffer);
    c.setUint32(0, 0x02014b50, true);
    c.setUint16(4, e.symlink ? 0x031e : 20, true);
    c.setUint16(6, 20, true);
    c.setUint16(8, 0x0800, true);
    c.setUint32(16, crc, true);
    c.setUint32(20, data.length, true);
    c.setUint32(24, data.length, true);
    c.setUint16(28, name.length, true);
    c.setUint32(38, e.symlink ? (0o120777 << 16) >>> 0 : (0o100644 << 16) >>> 0, true);
    c.setUint32(42, offset, true);
    ch.set(name, 46);
    centrals.push(ch);
    offset += lh.length + data.length;
  }
  const cdSize = centrals.reduce((s, c) => s + c.length, 0);
  const end = new Uint8Array(22);
  const ev = new DataView(end.buffer);
  ev.setUint32(0, 0x06054b50, true);
  ev.setUint16(8, entries.length, true);
  ev.setUint16(10, entries.length, true);
  ev.setUint32(12, cdSize, true);
  ev.setUint32(16, offset, true);
  const all = [...locals, ...centrals, end];
  const out = new Uint8Array(all.reduce((s, p) => s + p.length, 0));
  let o = 0;
  for (const p of all) {
    out.set(p, o);
    o += p.length;
  }
  return out;
}

export function tmpDir(prefix = "comiclib-"): string {
  return fs.mkdtempSync(path.join(os.tmpdir(), prefix));
}

export function write(p: string, data: Uint8Array | string) {
  fs.mkdirSync(path.dirname(p), { recursive: true });
  fs.writeFileSync(p, data);
}

/** Create an archive with the real 7-Zip binary from a directory tree described as relative path -> bytes. */
export function make7z(bin: string, out: string, files: Record<string, Uint8Array>, args: string[] = []) {
  const src = tmpDir("src-");
  for (const [rel, data] of Object.entries(files)) write(path.join(src, rel), data);
  fs.mkdirSync(path.dirname(out), { recursive: true });
  execFileSync(bin, ["a", "-y", ...args, out, "."], { cwd: src, stdio: "ignore" });
  fs.rmSync(src, { recursive: true, force: true });
}

export function binaryWorks(bin: string): boolean {
  try {
    fs.chmodSync(bin, 0o755);
  } catch {
    /* read-only install; fall through and let the spawn decide */
  }
  try {
    execFileSync(bin, ["i"], { stdio: "ignore" });
    return true;
  } catch {
    return false;
  }
}
