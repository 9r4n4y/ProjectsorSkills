import { describe, expect, it } from "vitest";
import {
  type ArchiveEntry,
  buildManifest,
  compareHashes,
  compareListing,
  compareToManifest,
  compareTotals,
  groupArchives,
  indexLayer,
  inspectImage,
  isImageFile,
  isJunkPath,
  pageSequenceLayer,
  parseArchiveName,
  planExtraction,
  reconcileScan,
  sanitizeSegment,
  smallFilesLayer,
  summarizeLayers,
  uniqueName,
} from "@comiclib/shared";
import { makePng } from "./helpers";

const f = (path: string, size = 100, crc = 1): ArchiveEntry => ({ path, size, crc, isDir: false });

describe("extraction layout (no mixing)", () => {
  it("collapses a single top-level folder: archive_name/pages, no double nesting", () => {
    const p = planExtraction("Comic One", [f("Comic One/001.jpg"), f("Comic One/002.jpg")]);
    expect(p.folderName).toBe("Comic One");
    expect(p.files.map((x) => x.dest)).toEqual(["001.jpg", "002.jpg"]);
    expect(p.layout).toBe("single-folder");
    expect(p.comicDirs).toEqual([""]);
  });
  it("collapses repeatedly nested single folders", () => {
    const p = planExtraction("x", [f("a/a/1.jpg"), f("a/a/2.jpg")]);
    expect(p.files.map((x) => x.dest)).toEqual(["1.jpg", "2.jpg"]);
  });
  it("puts loose root files inside archive_name/", () => {
    const p = planExtraction("Loose", [f("1.jpg"), f("2.jpg")]);
    expect(p.layout).toBe("loose");
    expect(p.files.every((x) => !x.dest.startsWith("/") && !x.dest.includes(".."))).toBe(true);
  });
  it("keeps several top-level folders inside archive_name/ and registers each as a comic", () => {
    const p = planExtraction("Pack", [f("A/1.jpg"), f("A/2.jpg"), f("B/1.jpg")]);
    expect(p.layout).toBe("multi");
    expect(p.comicDirs).toEqual(["A", "B"]);
    expect(p.files.map((x) => x.dest)).toEqual(["A/1.jpg", "A/2.jpg", "B/1.jpg"]);
  });
  it("mixed loose files and folders stay together inside archive_name/", () => {
    const p = planExtraction("Mix", [f("cover.jpg"), f("Ch1/1.jpg")]);
    expect(p.layout).toBe("mixed");
    expect(p.comicDirs).toEqual(["", "Ch1"]);
  });
  it("rejects path traversal, absolute paths and symlinks", () => {
    const p = planExtraction("Bad", [
      f("../evil.jpg"),
      f("a/../../evil.jpg"),
      f("/etc/passwd"),
      f("C:/win/x.jpg"),
      { ...f("link"), isSymlink: true },
      f("ok/1.jpg"),
    ]);
    expect(p.unsafe).toHaveLength(5);
    expect(p.files.map((x) => x.dest)).toEqual(["1.jpg"]);
  });
  it("sanitizes invalid Windows characters and reserved names, keeps unicode and RTL", () => {
    expect(sanitizeSegment('a<b>c:d"e|f?g*h')).toBe("a_b_c_d_e_f_g_h");
    expect(sanitizeSegment("CON")).toBe("_CON");
    expect(sanitizeSegment("name. ")).toBe("name");
    expect(sanitizeSegment("\u0645\u0627\u0646\u062c\u0627")).toBe("\u0645\u0627\u0646\u062c\u0627");
    expect(sanitizeSegment("\u202eevil")).toBe("evil");
    expect(sanitizeSegment("\u65e5\u672c\u8a9e")).toBe("\u65e5\u672c\u8a9e");
  });
  it("renames case-only collisions", () => {
    const p = planExtraction("x", [f("A.jpg"), f("a.jpg")]);
    expect(new Set(p.files.map((x) => x.dest.toLowerCase())).size).toBe(2);
  });
  it("shortens very long paths", () => {
    const long = "x".repeat(200);
    const p = planExtraction("x", [f(`${long}/${long}.jpg`), f(`${long}/b.jpg`), f("other/c.jpg")], { parentLen: 100 });
    for (const x of p.files) expect(100 + x.dest.length + 1 + p.folderName.length).toBeLessThanOrEqual(240);
  });
  it("skips junk and detects nested archives", () => {
    const p = planExtraction("x", [f("__MACOSX/._1.jpg"), f("Thumbs.db"), f("1.jpg"), f("inner.zip")]);
    expect(p.skipped).toHaveLength(2);
    expect(p.nestedArchives).toEqual(["inner.zip"]);
  });
  it("auto-suffixes on collision case-insensitively", () => {
    expect(uniqueName("Comic", ["comic"])).toBe("Comic (2)");
    expect(uniqueName("Comic", ["Other"])).toBe("Comic");
  });
});

describe("archive detection", () => {
  it("parses names", () => {
    expect(parseArchiveName("a.tar.gz")?.base).toBe("a");
    expect(parseArchiveName("a.part01.rar")?.index).toBe(1);
    expect(parseArchiveName("a.7z.001")?.scheme).toBe("numbered");
    expect(parseArchiveName("a.jpg")).toBeNull();
  });
  it("groups split sets and reports missing parts", () => {
    const g = groupArchives([
      { name: "b.part1.rar", size: 10 },
      { name: "b.part3.rar", size: 10 },
      { name: "c.7z.001", size: 5 },
      { name: "c.7z.002", size: 5 },
      { name: "d.zip", size: 3 },
      { name: "d.z01", size: 3 },
      { name: "e.cbz", size: 1 },
    ]);
    const by = Object.fromEntries(g.map((x) => [x.base, x]));
    expect(by.b.missing).toEqual(["b.part2.rar"]);
    expect(by.c.missing).toEqual([]);
    expect(by.c.primary).toBe("c.7z.001");
    expect(by.d.primary).toBe("d.zip");
    expect(by.d.parts).toHaveLength(2);
    expect(by.e.volumes).toBe(false);
    expect(g).toHaveLength(4);
  });
  it("classifies images and junk", () => {
    expect(isImageFile("a/B.WEBP")).toBe(true);
    expect(isImageFile("a/b.txt")).toBe(false);
    expect(isJunkPath("x/__MACOSX/a.jpg")).toBe(true);
    expect(isJunkPath("Thumbs.db")).toBe(true);
  });
});

describe("verification layers", () => {
  const planned = [
    { src: "1.png", dest: "1.png", size: 10, crc: 5 },
    { src: "2.png", dest: "2.png", size: 20, crc: 6 },
  ];
  it("layer 2 detects missing and extra files", () => {
    expect(compareListing(planned, ["1.png", "2.png"]).status).toBe("pass");
    const r = compareListing(planned, ["1.png", "x.png"]);
    expect(r.status).toBe("fail");
    expect(r.details).toContain("missing: 2.png");
    expect(r.details).toContain("unexpected: x.png");
  });
  it("layer 3 compares CRC32", () => {
    const ok = new Map([["1.png", { crc32: 5, sha256: "", size: 10 }], ["2.png", { crc32: 6, sha256: "", size: 20 }]]);
    expect(compareHashes(planned, ok).status).toBe("pass");
    ok.set("2.png", { crc32: 7, sha256: "", size: 20 });
    expect(compareHashes(planned, ok).status).toBe("fail");
  });
  it("layer 4 compares counts and bytes", () => {
    expect(compareTotals({ count: 2, bytes: 30 }, { count: 2, bytes: 30 }).status).toBe("pass");
    expect(compareTotals({ count: 2, bytes: 30 }, { count: 1, bytes: 10 }).status).toBe("fail");
  });
  it("layer 6 reports the exact missing page numbers", () => {
    const r = pageSequenceLayer(["1.jpg", "2.jpg", "4.jpg", "7.jpg"]);
    expect(r.status).toBe("warn");
    expect(r.details[0]).toContain("3, 5, 6");
    expect(pageSequenceLayer(["page1.jpg", "page2.jpg", "page10.jpg"]).status).toBe("warn");
    expect(pageSequenceLayer(["001.jpg", "002.jpg", "003.jpg"]).status).toBe("pass");
  });
  it("layer 6 reports duplicates", () => {
    const r = pageSequenceLayer(["p1.jpg", "p1.png", "p2.jpg"]);
    expect(r.details.join()).toContain("duplicate");
  });
  it("layer 7 flags empty and tiny images", () => {
    expect(smallFilesLayer([{ path: "a.jpg", size: 0 }]).status).toBe("fail");
    expect(smallFilesLayer([{ path: "a.jpg", size: 100 }]).status).toBe("warn");
    expect(smallFilesLayer([{ path: "a.jpg", size: 5000 }]).status).toBe("pass");
  });
  it("layers 8 and 9: manifest and post-move comparison", () => {
    const m = buildManifest("a.zip", 100, [
      { path: "2.png", facts: { crc32: 1, sha256: "b", size: 5 } },
      { path: "10.png", facts: { crc32: 2, sha256: "c", size: 6 } },
    ]);
    expect(m.files.map((x) => x.path)).toEqual(["2.png", "10.png"]);
    expect(m.pageCount).toBe(2);
    expect(compareToManifest(m, [{ path: "2.png", size: 5 }, { path: "10.png", size: 6 }]).status).toBe("pass");
    expect(compareToManifest(m, [{ path: "2.png", size: 4 }]).status).toBe("fail");
  });
  it("layer 10 cross-checks the index", () => {
    expect(indexLayer(3, { pageCount: 3, thumbOk: true }).status).toBe("pass");
    expect(indexLayer(3, { pageCount: 2, thumbOk: true }).status).toBe("fail");
    expect(indexLayer(3, null).status).toBe("fail");
  });
  it("summarizes to green, amber, red", () => {
    const l = (s: "pass" | "warn" | "fail") => ({ layer: 1, name: "", status: s, summary: "", details: [] });
    expect(summarizeLayers([l("pass")])).toBe("green");
    expect(summarizeLayers([l("pass"), l("warn")])).toBe("amber");
    expect(summarizeLayers([l("warn"), l("fail")])).toBe("red");
  });
});

describe("image inspection (layer 5)", () => {
  const png = makePng(16, 12, 1);
  it("accepts a valid PNG", () => {
    const r = inspectImage(png);
    expect(r.ok).toBe(true);
    expect([r.width, r.height]).toEqual([16, 12]);
  });
  it("detects truncation and corruption", () => {
    expect(inspectImage(png.slice(0, png.length - 20)).ok).toBe(false);
    const c = png.slice();
    c[40] ^= 0xff;
    expect(inspectImage(c).ok).toBe(false);
    expect(inspectImage(new Uint8Array(100)).ok).toBe(false);
  });
  it("validates JPEG, GIF, BMP and WebP headers", () => {
    const jpeg = new Uint8Array([0xff, 0xd8, 0xff, 0xc0, 0, 17, 8, 0, 5, 0, 7, 3, 1, 0x22, 0, 2, 0x11, 1, 3, 0x11, 1, 0xff, 0xda, 0, 8, 1, 1, 0, 0, 63, 0, 1, 2, 3, 0xff, 0xd9]);
    const j = inspectImage(jpeg);
    expect(j.ok).toBe(true);
    expect([j.width, j.height]).toEqual([7, 5]);
    expect(inspectImage(jpeg.slice(0, jpeg.length - 4)).ok).toBe(false);
    const gif = new Uint8Array([71, 73, 70, 56, 57, 97, 4, 0, 3, 0, 0, 0, 0, 0x2c, 0, 0, 0x3b]);
    expect(inspectImage(gif).ok).toBe(true);
    const bmp = new Uint8Array(60);
    bmp.set([0x42, 0x4d, 60, 0, 0, 0], 0);
    bmp.set([6, 0, 0, 0], 18);
    bmp.set([4, 0, 0, 0], 22);
    expect(inspectImage(bmp).ok).toBe(true);
    const webp = new Uint8Array(40);
    webp.set([...new TextEncoder().encode("RIFF")], 0);
    webp.set([100, 0, 0, 0], 4);
    webp.set([...new TextEncoder().encode("WEBPVP8 ")], 8);
    expect(inspectImage(webp).ok).toBe(false);
  });
});

describe("scan reconciliation", () => {
  const prev = [
    { id: "a", relPath: "A/one", size: 100, mtime: 1, pages: 5 },
    { id: "b", relPath: "A/two", size: 200, mtime: 1, pages: 6 },
    { id: "c", relPath: "A/three", size: 300, mtime: 1, pages: 7 },
  ];
  it("detects unchanged, updated, moved, added and removed", () => {
    const r = reconcileScan(prev, [
      { relPath: "A/one", size: 100, mtime: 1, pages: 5 },
      { relPath: "A/two", size: 250, mtime: 2, pages: 6 },
      { relPath: "B/three", size: 300, mtime: 1, pages: 7 },
      { relPath: "A/new", size: 1, mtime: 1, pages: 1 },
    ]);
    expect(r.unchanged.map((x) => x.id)).toEqual(["a"]);
    expect(r.updated.map((x) => x.prev.id)).toEqual(["b"]);
    expect(r.moved.map((x) => [x.prev.id, x.next.relPath])).toEqual([["c", "B/three"]]);
    expect(r.added.map((x) => x.relPath)).toEqual(["A/new"]);
    expect(r.removed).toHaveLength(0);
  });
});
