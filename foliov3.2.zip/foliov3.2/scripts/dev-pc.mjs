// npm run dev:pc  ->  builds the UI and the Electron bundle, then opens the desktop app.
import { spawnSync } from "node:child_process";
import fs from "node:fs";
import path from "node:path";

const root = path.resolve(path.dirname(new URL(import.meta.url).pathname.replace(/^\/([A-Za-z]:)/, "$1")), "..");
const run = (cmd, args, cwd = root) => {
  const r = spawnSync(cmd, args, { cwd, stdio: "inherit", shell: process.platform === "win32" });
  if (r.status !== 0) process.exit(r.status ?? 1);
};
run("npm", ["run", "build"]);
if (!fs.existsSync(path.join(root, "electron/node_modules/electron"))) run("npm", ["--prefix", "electron", "install"]);
run("npm", ["start"], path.join(root, "electron"));
