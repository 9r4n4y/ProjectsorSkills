// Downloads the two UI fonts (Quicksand, Bagel Fat One) once into public/fonts so the offline app can ship them.
// The app has no INTERNET permission: fonts must be packaged, never fetched at runtime. Needs network only when run.
// Usage: npm run setup:fonts   (skips files that already exist; prepare-android.mjs calls it automatically)
import fs from "node:fs";
import path from "node:path";

const root = path.resolve(path.dirname(new URL(import.meta.url).pathname.replace(/^\/([A-Za-z]:)/, "$1")), "..");
const dir = path.join(root, "public/fonts");
fs.mkdirSync(dir, { recursive: true });
const UA = "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36"; // makes Google return woff2
const FONTS = [
  { file: "quicksand.woff2", css: "https://fonts.googleapis.com/css2?family=Quicksand:wght@300..700&display=swap" },
  { file: "bagel-fat-one.woff2", css: "https://fonts.googleapis.com/css2?family=Bagel+Fat+One&display=swap" },
];

let failed = false;
for (const f of FONTS) {
  const out = path.join(dir, f.file);
  if (fs.existsSync(out) && fs.statSync(out).size > 1000) continue;
  try {
    const css = await (await fetch(f.css, { headers: { "User-Agent": UA } })).text();
    // take the latin subset (the block that follows the "/* latin */" comment)
    const m = css.match(/\/\* latin \*\/\s*@font-face\s*\{[^}]*?url\((https:[^)]+\.woff2)\)/);
    if (!m) throw new Error("no latin woff2 found in Google Fonts CSS");
    const res = await fetch(m[1]);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    fs.writeFileSync(out, Buffer.from(await res.arrayBuffer()));
    console.log(`fonts: saved ${f.file}`);
  } catch (e) {
    failed = true;
    console.warn(`\nWARNING: could not fetch ${f.file}: ${e.message}\nThe app will fall back to system fonts. Run "npm run setup:fonts" with a network connection, or copy the woff2 files into public/fonts/ by hand.\n`);
  }
}
process.exit(0 * Number(failed));
