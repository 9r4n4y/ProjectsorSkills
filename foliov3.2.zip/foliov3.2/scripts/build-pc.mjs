// npm run build:pc  ->  release/ComicLibrary-Portable.exe (single file, no installer)
import { spawnSync } from "node:child_process";
import fs from "node:fs";
import path from "node:path";

const root = path.resolve(path.dirname(new URL(import.meta.url).pathname.replace(/^\/([A-Za-z]:)/, "$1")), "..");
const run = (cmd, args, cwd = root, env = {}) => {
  const r = spawnSync(cmd, args, { cwd, stdio: "inherit", shell: process.platform === "win32", env: { ...process.env, ...env } });
  if (r.status !== 0) {
    console.error(`\nCommand failed: ${cmd} ${args.join(" ")}\nSee the Troubleshooting section of README.md.`);
    process.exit(r.status ?? 1);
  }
};

run("npm", ["run", "build"]);
if (!fs.existsSync(path.join(root, "electron/node_modules/electron-builder"))) run("npm", ["--prefix", "electron", "install"]);
const res = path.join(root, "electron/resources/7zip");
const hasFull = fs.existsSync(res) && fs.readdirSync(res).some((f) => /^7z(z)?(\.exe)?$/.test(f));
if (!hasFull) {
  console.log("Fetching the full 7-Zip build (needed for RAR and RAR5). Build time only; the app itself never uses the network.");
  spawnSync("node", ["scripts/fetch-7zip.mjs"], { cwd: root, stdio: "inherit" });
}
run("npm", ["run", "pack"], path.join(root, "electron"), { BUILD_TARGET_WIN: "1" });
fs.mkdirSync(path.join(root, "release"), { recursive: true });
const src = path.join(root, "electron/release/ComicLibrary-Portable.exe");
if (fs.existsSync(src)) {
  fs.copyFileSync(src, path.join(root, "release/ComicLibrary-Portable.exe"));
  console.log("\nDone: release/ComicLibrary-Portable.exe  (double-click to run)");
} else {
  console.log("\nBuild finished. Look in electron/release/ for the output of your platform.");
}
