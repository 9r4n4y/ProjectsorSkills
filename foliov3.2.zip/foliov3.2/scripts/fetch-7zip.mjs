// Downloads the official full 7-Zip console build (it includes the RAR and RAR5 codecs, which the small 7za lacks)
// into electron/resources/7zip. Build time only. Run: npm run setup:7zip
import { spawnSync } from "node:child_process";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { createRequire } from "node:module";

const root = path.resolve(path.dirname(new URL(import.meta.url).pathname.replace(/^\/([A-Za-z]:)/, "$1")), "..");
const dest = path.join(root, "electron/resources/7zip");
fs.mkdirSync(dest, { recursive: true });
const V = "2408";
const tmp = fs.mkdtempSync(path.join(os.tmpdir(), "7z-"));
const target = process.env.BUILD_TARGET_WIN === "1" || process.platform === "win32" ? "win" : process.platform === "darwin" ? "mac" : "linux";
const { path7za } = createRequire(import.meta.url)("7zip-bin");
try { fs.chmodSync(path7za, 0o755); } catch { /* ignore */ }

async function get(url, file) {
  const r = await fetch(url);
  if (!r.ok) throw new Error(`${url}: HTTP ${r.status}`);
  fs.writeFileSync(file, Buffer.from(await r.arrayBuffer()));
}

try {
  if (target === "win") {
    const exe = path.join(tmp, "7z.exe");
    await get(`https://www.7-zip.org/a/7z${V}-x64.exe`, exe);
    // the installer is an archive that 7-Zip itself can open
    const r = spawnSync(path7za, ["x", "-y", `-o${tmp}/x`, exe, "7z.exe", "7z.dll"], { stdio: "inherit" });
    if (r.status !== 0) throw new Error("could not unpack the installer");
    fs.copyFileSync(path.join(tmp, "x/7z.exe"), path.join(dest, "7z.exe"));
    fs.copyFileSync(path.join(tmp, "x/7z.dll"), path.join(dest, "7z.dll"));
  } else {
    const name = target === "mac" ? `7z${V}-mac.tar.xz` : `7z${V}-linux-${process.arch === "arm64" ? "arm64" : "x64"}.tar.xz`;
    const f = path.join(tmp, name);
    await get(`https://www.7-zip.org/a/${name}`, f);
    const r = spawnSync("tar", ["-xJf", f, "-C", tmp], { stdio: "inherit" });
    if (r.status !== 0) throw new Error("tar could not unpack the download");
    fs.copyFileSync(path.join(tmp, "7zz"), path.join(dest, "7zz"));
    fs.chmodSync(path.join(dest, "7zz"), 0o755);
  }
  console.log("Full 7-Zip installed into", dest);
} catch (e) {
  console.warn("\nCould not download 7-Zip:", e.message);
  console.warn("The app will still work with the bundled 7za (ZIP, 7Z, TAR, GZ, BZ2, XZ). RAR needs the full build:");
  console.warn("copy 7z.exe and 7z.dll from a normal 7-Zip install into electron/resources/7zip/ and run build:pc again.");
}
fs.rmSync(tmp, { recursive: true, force: true });
