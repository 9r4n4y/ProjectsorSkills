# Folio v3.2

- **Fixed Scroll-Mode Preview Page Jump**: Opening a specific preview page in continuous scroll mode now reliably lands on and stays pinned to that exact page using bounding-rect alignment, eager loading around the target page, `ResizeObserver` layout-shift pinning while earlier pages load, and CSS `overflow-anchor: auto`.
- **Thick Black Page Dividers**: Added a clear thick black divider bar (`h-2.5 bg-black` with subtle edge contrast) between every page in scroll mode so you can immediately see where each page ends.
- **Direct Page & Comic Export**:
  - Added an **Export** menu directly in the Reader top bar to export either the **current opened page** (original image format) or the **full comic (.cbz)**.
  - Added a direct **Export comic (.cbz)** button in Quick Look.
  - Implemented native export on Android (`ACTION_CREATE_DOCUMENT` with fast stored ZIP streaming), Electron desktop (`showSaveDialog`), and Browser preview.
- **Version Bump**: Updated app name and version to **Folio v3.2** (`version 3.2.0`, Android `versionCode 5`, `Folio-v3.2-debug.apk`).
