// Bundles the Electron main process with esbuild, generates the app icon and stages the 7-Zip binaries.
import { build } from "esbuild";
import { deflateSync } from "node:zlib";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const here = path.dirname(fileURLToPath(import.meta.url));
const dist = path.join(here, "dist");
fs.mkdirSync(dist, { recursive: true });

const common = { bundle: true, platform: "node", target: "node20", format: "cjs", external: ["electron", "better-sqlite3", "7zip-bin"], sourcemap: false, logLevel: "info" };
await build({ ...common, entryPoints: [path.join(here, "main/main.ts")], outfile: path.join(dist, "main.cjs") });
await build({ ...common, entryPoints: [path.join(here, "main/preload.ts")], outfile: path.join(dist, "preload.cjs") });
await build({ ...common, entryPoints: [path.join(here, "main/imaging-preload.ts")], outfile: path.join(dist, "imaging-preload.cjs") });
fs.copyFileSync(path.join(here, "main/imaging.html"), path.join(dist, "imaging.html"));

// icon: a geometric open book on an accent square, drawn directly into a PNG
function crc32(buf) {
  let c, crc = ~0;
  for (let n = 0; n < buf.length; n++) {
    c = (crc ^ buf[n]) & 0xff;
    for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    crc = (crc >>> 8) ^ c;
  }
  return ~crc >>> 0;
}
function png(size, pixel) {
  const raw = Buffer.alloc((size * 4 + 1) * size);
  for (let y = 0; y < size; y++) for (let x = 0; x < size; x++) {
    const [r, g, b, a] = pixel(x / size, y / size);
    const o = y * (size * 4 + 1) + 1 + x * 4;
    raw[o] = r; raw[o + 1] = g; raw[o + 2] = b; raw[o + 3] = a;
  }
  const chunk = (t, d) => {
    const len = Buffer.alloc(4); len.writeUInt32BE(d.length);
    const td = Buffer.concat([Buffer.from(t), d]);
    const crc = Buffer.alloc(4); crc.writeUInt32BE(crc32(td));
    return Buffer.concat([len, td, crc]);
  };
  const ihdr = Buffer.alloc(13); ihdr.writeUInt32BE(size, 0); ihdr.writeUInt32BE(size, 4); ihdr[8] = 8; ihdr[9] = 6;
  return Buffer.concat([Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]), chunk("IHDR", ihdr), chunk("IDAT", deflateSync(raw)), chunk("IEND", Buffer.alloc(0))]);
}
const inRound = (u, v, r) => {
  const x = Math.abs(u - 0.5) - (0.5 - r), y = Math.abs(v - 0.5) - (0.5 - r);
  return Math.hypot(Math.max(x, 0), Math.max(y, 0)) <= r;
};
const icon = png(256, (u, v) => {
  if (!inRound(u, v, 0.2)) return [0, 0, 0, 0];
  const page = (u > 0.2 && u < 0.48 && v > 0.22 && v < 0.78) || (u > 0.52 && u < 0.8 && v > 0.22 && v < 0.78);
  return page ? [255, 255, 255, 255] : [59, 91, 219, 255];
});
fs.mkdirSync(path.join(here, "assets"), { recursive: true });
fs.writeFileSync(path.join(here, "assets/icon.png"), icon);
fs.writeFileSync(path.join(dist, "icon.png"), icon);

// stage a 7-Zip fallback (7za) from the 7zip-bin package so the exe always has a working engine
const res = path.join(here, "resources/7zip");
fs.mkdirSync(res, { recursive: true });
try {
  const { createRequire } = await import("node:module");
  const req = createRequire(import.meta.url);
  const { path7za } = req("7zip-bin");
  const win = process.env.BUILD_TARGET_WIN === "1" || process.platform === "win32";
  const src = win ? path.join(path.dirname(path.dirname(path7za)), "win", "x64", "7za.exe") : path7za;
  if (fs.existsSync(src)) fs.copyFileSync(src, path.join(res, win ? "7za.exe" : "7za"));
} catch (e) {
  console.warn("7zip-bin not available, skipping the 7za fallback:", e.message);
}
console.log("Electron bundle ready in", dist);
