import { contextBridge, ipcRenderer } from "electron";

contextBridge.exposeInMainWorld("comicNative", {
  platform: process.platform,
  invoke: (method: string, args: unknown[]) => ipcRenderer.invoke("api", method, args),
  on: (event: string, cb: (payload: unknown) => void) => {
    const h = (_e: unknown, name: string, payload: unknown) => {
      if (name === event) cb(payload);
    };
    ipcRenderer.on("api:event", h);
    return () => ipcRenderer.removeListener("api:event", h);
  },
});
