import { contextBridge, ipcRenderer } from "electron";

contextBridge.exposeInMainWorld("imgBridge", {
  onTask: (cb: (t: { id: number; kind: "decode" | "thumb"; url: string }) => void) => {
    ipcRenderer.on("imaging:task", (_e, t) => cb(t));
  },
  done: (id: number, result: unknown) => ipcRenderer.send("imaging:result", id, result),
});
