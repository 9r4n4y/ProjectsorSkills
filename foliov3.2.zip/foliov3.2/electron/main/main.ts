// Electron main process: window, tray, taskbar progress, notifications, protocol, IPC.

import { BrowserWindow, Menu, Notification, Tray, app, clipboard, dialog, ipcMain, nativeImage, net, protocol, safeStorage, shell } from "electron";
import * as fs from "node:fs";
import * as path from "node:path";
import { pathToFileURL } from "node:url";
import { createCipheriv, createDecipheriv, randomBytes } from "node:crypto";
import { type JobsState, summarizeJobs } from "@comiclib/shared";
import { Imaging } from "./imaging";
import { Service } from "./service";

protocol.registerSchemesAsPrivileged([{ scheme: "comic", privileges: { standard: true, secure: true, supportFetchAPI: true, stream: true, bypassCSP: true } }]);

// Portable build: keep all data beside the executable when electron-builder provides its directory.
if (process.env.PORTABLE_EXECUTABLE_DIR) {
  const p = path.join(process.env.PORTABLE_EXECUTABLE_DIR, "ComicLibraryData");
  try {
    fs.mkdirSync(p, { recursive: true });
    app.setPath("userData", p);
  } catch {
    /* read-only location: fall back to the default profile folder */
  }
}

let win: BrowserWindow | null = null;
let tray: Tray | null = null;
let service: Service;
let quitting = false;
let wasActive = false;

const resDir = () => (app.isPackaged ? process.resourcesPath : path.join(__dirname, "..", "resources"));
const uiIndex = () => (app.isPackaged ? path.join(process.resourcesPath, "ui", "index.html") : path.join(__dirname, "..", "..", "dist", "index.html"));

function sevenZipBins(): { id: string; bin: string }[] {
  const dir = path.join(resDir(), "7zip");
  const names = process.platform === "win32" ? ["7z.exe", "7za.exe"] : ["7zz", "7z", "7za"];
  const found = names.map((n) => path.join(dir, n)).filter((p) => fs.existsSync(p));
  try {
    // development fallback
    // eslint-disable-next-line @typescript-eslint/no-require-imports
    const { path7za } = require("7zip-bin") as { path7za: string };
    if (fs.existsSync(path7za)) found.push(path7za);
  } catch {
    /* not installed */
  }
  const uniq = [...new Set(found)];
  for (const f of uniq) if (process.platform !== "win32") try { fs.chmodSync(f, 0o755); } catch { /* ignore */ }
  if (!uniq.length) throw new Error("No 7-Zip binary found. Run: node scripts/fetch-7zip.mjs");
  return uniq.map((bin, i) => ({ id: i === 0 ? "7z" : path.basename(bin), bin }));
}

// Passwords are encrypted with the OS keystore (DPAPI / Keychain / libsecret) or, if unavailable, a local key file.
function vault(dataDir: string) {
  const keyFile = path.join(dataDir, "vault.key");
  const key = () => {
    if (!fs.existsSync(keyFile)) fs.writeFileSync(keyFile, randomBytes(32), { mode: 0o600 });
    return fs.readFileSync(keyFile);
  };
  return {
    encrypt(s: string): string {
      if (safeStorage.isEncryptionAvailable()) return "ss:" + safeStorage.encryptString(s).toString("base64");
      const iv = randomBytes(12);
      const c = createCipheriv("aes-256-gcm", key(), iv);
      const enc = Buffer.concat([c.update(s, "utf8"), c.final()]);
      return "aes:" + Buffer.concat([iv, c.getAuthTag(), enc]).toString("base64");
    },
    decrypt(s: string): string {
      if (s.startsWith("ss:")) return safeStorage.decryptString(Buffer.from(s.slice(3), "base64"));
      const b = Buffer.from(s.slice(4), "base64");
      const d = createDecipheriv("aes-256-gcm", key(), b.subarray(0, 12));
      d.setAuthTag(b.subarray(12, 28));
      return Buffer.concat([d.update(b.subarray(28)), d.final()]).toString("utf8");
    },
  };
}

function send(event: string, payload: unknown) {
  if (win && !win.isDestroyed()) win.webContents.send("api:event", event, payload);
  if (event === "jobs") onJobs(payload as JobsState);
}

function onJobs(state: JobsState) {
  const work = state.jobs.filter((j) => j.group === "extract" || j.group === "verify");
  const s = summarizeJobs(work);
  const active = s.running + s.queued > 0;
  if (win && !win.isDestroyed()) win.setProgressBar(active && !state.paused ? Math.max(0.02, s.fraction) : -1);
  tray?.setToolTip(active ? `Comic Library: ${Math.round(s.fraction * 100)}%, ${s.done} of ${s.total}${state.paused ? " (paused)" : ""}` : "Comic Library: idle");
  if (wasActive && !active && s.total > 0 && Notification.isSupported()) {
    new Notification({ title: "Comic Library", body: `Finished: ${s.done} succeeded, ${s.failed} with errors.` }).show();
  }
  wasActive = active;
}

function createWindow() {
  win = new BrowserWindow({
    width: 1280,
    height: 820,
    minWidth: 360,
    minHeight: 560,
    show: false,
    backgroundColor: "#111113",
    autoHideMenuBar: true,
    icon: path.join(__dirname, "icon.png"),
    webPreferences: { preload: path.join(__dirname, "preload.cjs"), contextIsolation: true, sandbox: false },
  });
  win.once("ready-to-show", () => win?.show());
  void win.loadFile(uiIndex());
  win.webContents.setWindowOpenHandler(({ url }) => {
    if (/^https?:/.test(url)) void shell.openExternal(url);
    return { action: "deny" };
  });
  win.on("close", (e) => {
    if (!quitting && service.settings().closeToTray) {
      e.preventDefault();
      win?.hide();
    }
  });
}

function createTray() {
  const img = nativeImage.createFromPath(path.join(__dirname, "icon.png")).resize({ width: 16, height: 16 });
  tray = new Tray(img);
  tray.setToolTip("Comic Library: idle");
  const rebuild = (): void =>
    tray!.setContextMenu(
      Menu.buildFromTemplate([
        { label: "Open Comic Library", click: () => (win?.show(), win?.focus()) },
        {
          label: service.queue.isPaused ? "Resume tasks" : "Pause tasks",
          click: (): void => {
            if (service.queue.isPaused) service.queue.resumeAll();
            else service.queue.pauseAll();
            rebuild();
          },
        },
        { type: "separator" },
        { label: "Quit", click: () => ((quitting = true), app.quit()) },
      ]),
    );
  rebuild();
  tray.on("click", () => (win?.isVisible() ? win.focus() : win?.show()));
}

const API = new Set([
  "init", "pickFolder", "setRoot", "getLibrary", "scan", "saveState", "pages", "ensureThumb", "resolveImage", "getJobs", "extractAll", "extractArchives",
  "reverify", "jobControl", "skipArchive", "markManual", "openFolder", "moveComics", "createFolder", "previewDelete", "confirmDelete", "trashList",
  "trashRestore", "trashEmpty", "listPasswords", "addPassword", "removePassword", "exportPasswords", "sizeReport", "folderCheck", "fixFolders",
  "exportPage", "exportComic", "saveTextFile", "pickTextFile", "backupDb", "restoreBackup", "applyImport", "runHealth", "getPermissions", "requestPermission", "openSystemSettings",
  "diagnostics", "copyText",
]);

if (!app.requestSingleInstanceLock()) {
  app.quit();
} else {
  app.on("second-instance", () => {
    win?.show();
    win?.focus();
  });
  app.whenReady().then(async () => {
    Menu.setApplicationMenu(null);
    const dataDir = app.getPath("userData");
    fs.mkdirSync(dataDir, { recursive: true });
    const v = vault(dataDir);
    let root: () => string | null = () => null;
    const imaging = new Imaging(path.join(__dirname, "imaging.html"), path.join(__dirname, "imaging-preload.cjs"), (abs) => `comic://raw/${encodeURIComponent(abs)}`);
    service = new Service({
      dataDir,
      appVersion: app.getVersion(),
      engines: sevenZipBins(),
      imaging: { check: (p) => imaging.check(p), thumbs: (s, a, b) => imaging.thumbs(s, a, b) },
      encrypt: v.encrypt,
      decrypt: v.decrypt,
      pickFolder: async () => {
        const r = await dialog.showOpenDialog(win!, { title: "Choose your comics folder", properties: ["openDirectory"] });
        return r.canceled ? null : r.filePaths[0];
      },
      saveText: async (name, text) => {
        const r = await dialog.showSaveDialog(win!, { defaultPath: name, filters: [{ name: "JSON", extensions: ["json"] }] });
        if (r.canceled || !r.filePath) return null;
        fs.writeFileSync(r.filePath, text, "utf8");
        return r.filePath;
      },
      savePath: async (name, filters) => {
        const r = await dialog.showSaveDialog(win!, { defaultPath: name, filters });
        return r.canceled || !r.filePath ? null : r.filePath;
      },
      pickText: async () => {
        const r = await dialog.showOpenDialog(win!, { properties: ["openFile"], filters: [{ name: "JSON", extensions: ["json"] }] });
        return r.canceled ? null : fs.readFileSync(r.filePaths[0], "utf8");
      },
      openPath: (p) => (fs.existsSync(p) && fs.statSync(p).isFile() ? shell.showItemInFolder(p) : void shell.openPath(p)),
      emit: send,
      copy: (t) => clipboard.writeText(t),
      notify: (title, body) => new Notification({ title, body }).show(),
    });
    root = () => service.root;

    protocol.handle("comic", async (req) => {
      const u = new URL(req.url);
      const parts = u.pathname.split("/").filter(Boolean).map(decodeURIComponent);
      let file: string | null = null;
      if (u.hostname === "thumb") file = await service.ensureThumbFile(parts[0], parts[1] === "s" ? "s" : "m");
      else if (u.hostname === "page") file = service.pageFile(parts[0], parts[1]);
      else if (u.hostname === "raw") {
        const abs = path.resolve(parts[0] ?? "");
        const r = root();
        const norm = (s: string) => (process.platform === "win32" ? s.toLowerCase() : s);
        if (r && norm(abs).startsWith(norm(path.resolve(r)) + path.sep)) file = abs;
      }
      if (!file || !fs.existsSync(file)) return new Response(null, { status: 404 });
      const res = await net.fetch(pathToFileURL(file).toString());
      return u.hostname === "thumb" ? new Response(res.body, { headers: { "content-type": "image/jpeg", "cache-control": "public, max-age=31536000" } }) : res;
    });

    ipcMain.handle("api", async (_e, method: string, args: unknown[]) => {
      if (!API.has(method)) throw new Error(`Unknown method ${method}`);
      return (service as unknown as Record<string, (...a: unknown[]) => unknown>)[method](...(args ?? []));
    });

    await service.start();
    createWindow();
    createTray();
  });
  app.on("before-quit", async () => {
    quitting = true;
    await service?.shutdown();
  });
  app.on("window-all-closed", () => {
    if (quitting || !service?.settings().closeToTray) app.quit();
  });
}
