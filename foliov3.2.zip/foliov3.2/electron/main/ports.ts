// Node implementations of the shared extraction ports: 7-Zip engine, filesystem, image check.
// No Electron imports here, so the integration tests run these exact classes.

import { spawn } from "node:child_process";
import { createHash } from "node:crypto";
import { createReadStream } from "node:fs";
import * as fsp from "node:fs/promises";
import * as path from "node:path";
import {
  type ArchiveEntry,
  type ArchiveJob,
  type EngineExtract,
  type EngineExtractOptions,
  type EngineList,
  type EnginePort,
  type EngineTest,
  type FileFacts,
  type FsPort,
  type ImagePort,
  crc32,
  inspectImage,
} from "@comiclib/shared";

interface RunResult {
  code: number;
  out: string;
  aborted: boolean;
}

const WRONG_PW = /Wrong password|Cannot open encrypted archive|Enter password|Data Error in encrypted file|Can not open encrypted archive/i;

/** Wraps a 7-Zip console binary (7z / 7zz / 7za). Streams output, never loads archives into memory. */
export class SevenZipEngine implements EnginePort {
  constructor(
    public id: string,
    private bin: string,
  ) {}

  private run(args: string[], o: { signal?: AbortSignal; onPercent?: (p: number) => void } = {}): Promise<RunResult> {
    return new Promise((resolve) => {
      const child = spawn(this.bin, args, { stdio: ["ignore", "pipe", "pipe"], windowsHide: true });
      let out = "";
      const cap = 256 * 1024;
      const onData = (b: Buffer) => {
        const s = b.toString("utf8");
        if (o.onPercent) {
          const m = s.match(/(\d{1,3})%/g);
          if (m) o.onPercent(parseInt(m[m.length - 1], 10));
        }
        if (out.length < cap) out += s.replace(/\r/g, "\n");
      };
      child.stdout.on("data", onData);
      child.stderr.on("data", onData);
      let aborted = false;
      const abort = () => {
        aborted = true;
        child.kill("SIGKILL");
      };
      if (o.signal) {
        if (o.signal.aborted) abort();
        else o.signal.addEventListener("abort", abort, { once: true });
      }
      child.on("error", (e) => resolve({ code: -1, out: `spawn failed: ${e.message}`, aborted }));
      child.on("close", (code) => {
        o.signal?.removeEventListener("abort", abort);
        resolve({ code: code ?? -1, out, aborted });
      });
    });
  }

  private pw(p?: string): string[] {
    return p !== undefined ? [`-p${p}`] : [];
  }

  async list(a: ArchiveJob, password?: string): Promise<EngineList> {
    const r = await this.run(["l", "-slt", "-ba", "-y", "-sccUTF-8", ...this.pw(password), "--", a.path]);
    const wrong = WRONG_PW.test(r.out);
    if (r.code > 1 || wrong) {
      return { ok: false, entries: [], encrypted: wrong, wrongPassword: wrong, error: lastLine(r.out), output: r.out };
    }
    const entries = parseSlt(r.out);
    return { ok: true, entries, encrypted: entries.some((e) => e.encrypted), output: r.out };
  }

  async test(a: ArchiveJob, password?: string): Promise<EngineTest> {
    const r = await this.run(["t", "-y", ...this.pw(password), "--", a.path]);
    const wrong = WRONG_PW.test(r.out);
    return { ok: r.code === 0 && !wrong, wrongPassword: wrong, output: r.out };
  }

  async extract(a: ArchiveJob, dest: string, o: EngineExtractOptions): Promise<EngineExtract> {
    const base = ["x", "-y", "-aoa", "-bsp1", `-o${dest}`, ...(o.threads ? [`-mmt=${o.threads}`] : []), ...this.pw(o.password)];
    let names = o.only;
    if (o.perFile && !names) {
      const l = await this.list(a, o.password);
      names = l.entries.filter((e) => !e.isDir).map((e) => e.path);
    }
    if (!names) {
      const r = await this.run([...base, "--", a.path], { signal: o.signal, onPercent: (p) => o.onProgress?.(p, 100) });
      return { ok: r.code === 0 || r.code === 1, error: r.code > 1 ? lastLine(r.out) : undefined, output: r.out };
    }
    // entry lists are processed in chunks so the command line stays short and one bad entry is isolated
    const size = o.perFile ? 25 : 200;
    let output = "";
    let ok = true;
    for (let i = 0; i < names.length; i += size) {
      if (o.signal?.aborted) break;
      const chunk = names.slice(i, i + size);
      const r = await this.run([...base, "-spd", "--", a.path, ...chunk], { signal: o.signal });
      output += r.out;
      if (r.code > 1) ok = false;
      o.onProgress?.(Math.min(names.length, i + size), names.length);
    }
    return { ok, error: ok ? undefined : lastLine(output), output };
  }
}

function lastLine(s: string): string {
  const l = s.split("\n").map((x) => x.trim()).filter(Boolean);
  return l.slice(-3).join(" | ") || "unknown error";
}

/** Parse `7z l -slt -ba` output into entries. */
export function parseSlt(out: string): ArchiveEntry[] {
  const entries: ArchiveEntry[] = [];
  for (const block of out.split(/\r?\n\r?\n/)) {
    const kv = new Map<string, string>();
    for (const line of block.split(/\r?\n/)) {
      const i = line.indexOf(" = ");
      if (i > 0) kv.set(line.slice(0, i), line.slice(i + 3));
    }
    const p = kv.get("Path");
    if (p === undefined) continue;
    const attr = kv.get("Attributes") ?? "";
    const isDir = kv.get("Folder") === "+" || /^D/.test(attr);
    const link = kv.get("Symbolic Link") || kv.get("Link");
    const unixLink = /(^|\s)l[r-][w-][x-]/.test(attr) || /\bl[r-][w-][x-][r-][w-][x-]/.test(attr);
    const crc = kv.get("CRC");
    entries.push({
      path: p,
      size: parseInt(kv.get("Size") ?? "0", 10) || 0,
      crc: crc ? parseInt(crc, 16) >>> 0 : undefined,
      isDir,
      isSymlink: !!link || unixLink,
      encrypted: kv.get("Encrypted") === "+",
    });
  }
  return entries;
}

export class NodeFs implements FsPort {
  async exists(p: string) {
    return fsp.access(p).then(() => true, () => false);
  }
  async listDir(p: string) {
    return fsp.readdir(p);
  }
  async listFiles(dir: string) {
    const out: { rel: string; size: number }[] = [];
    const walk = async (d: string, rel: string) => {
      for (const e of await fsp.readdir(d, { withFileTypes: true })) {
        const r = rel ? `${rel}/${e.name}` : e.name;
        if (e.isSymbolicLink()) continue;
        if (e.isDirectory()) await walk(path.join(d, e.name), r);
        else if (e.isFile()) out.push({ rel: r, size: (await fsp.stat(path.join(d, e.name))).size });
      }
    };
    await walk(dir, "");
    return out;
  }
  async mkdirp(p: string) {
    await fsp.mkdir(p, { recursive: true });
  }
  async rename(a: string, b: string) {
    await fsp.rename(a, b);
  }
  async rmrf(p: string) {
    await fsp.rm(p, { recursive: true, force: true, maxRetries: 3, retryDelay: 100 });
  }
  async writeText(p: string, t: string) {
    await fsp.mkdir(path.dirname(p), { recursive: true });
    await fsp.writeFile(p, t, "utf8");
  }
  async readText(p: string) {
    return fsp.readFile(p, "utf8");
  }
  hashFile(p: string): Promise<FileFacts> {
    return new Promise((resolve, reject) => {
      const sha = createHash("sha256");
      let crc = 0;
      let size = 0;
      const s = createReadStream(p, { highWaterMark: 1 << 20 });
      s.on("data", (c) => {
        const b = c as Buffer;
        sha.update(b);
        crc = crc32(b, crc);
        size += b.length;
      });
      s.on("error", reject);
      s.on("end", () => resolve({ crc32: crc, sha256: sha.digest("hex"), size }));
    });
  }
  join(...parts: string[]) {
    return path.join(...parts);
  }
}

/** Structural validation in Node. The Electron app layers a full pixel decode on top (see imaging.ts). */
export class StructuralImageCheck implements ImagePort {
  async check(p: string) {
    try {
      const r = inspectImage(new Uint8Array(await fsp.readFile(p)));
      return { ok: r.ok, width: r.width, height: r.height, error: r.error };
    } catch (e) {
      return { ok: false, width: 0, height: 0, error: (e as Error).message };
    }
  }
}
