// SQLite storage (better-sqlite3): WAL mode, versioned migrations, FTS5 search table, backups and integrity checks.

import Database from "better-sqlite3";
import * as fs from "node:fs";
import * as path from "node:path";
import {
  type ArchiveRecord,
  type ComicRecord,
  type ComicStatePatch,
  type FolderRecord,
  type Fingerprint,
  type JobRecord,
  type JobStore,
  MIGRATIONS,
  PRAGMAS,
  type TagDef,
  type TrashItem,
  type VerificationReport,
  normalizeText,
} from "@comiclib/shared";

export interface ComicRow {
  id: string;
  relPath: string;
  name: string;
  folder: string;
  author: string;
  pages: number;
  size: number;
  mtime: number;
}

export class Db implements JobStore {
  h!: Database.Database;
  constructor(
    public file: string,
    private rootGetter: () => string | null,
  ) {
    this.open();
  }

  open(): void {
    fs.mkdirSync(path.dirname(this.file), { recursive: true });
    this.h = new Database(this.file);
    for (const p of PRAGMAS) this.h.pragma(p.replace(/^PRAGMA /, ""));
    this.migrate();
  }
  close(): void {
    this.h.close();
  }

  migrate(): { from: number; to: number } {
    const from = this.h.pragma("user_version", { simple: true }) as number;
    let v = from;
    for (const m of MIGRATIONS) {
      if (m.version <= v) continue;
      this.h.transaction(() => {
        this.h.exec(m.sql);
        this.h.pragma(`user_version = ${m.version}`);
      })();
      v = m.version;
    }
    return { from, to: v };
  }

  get version(): number {
    return this.h.pragma("user_version", { simple: true }) as number;
  }

  // ---- settings ---------------------------------------------------------------------------
  getSetting<T>(key: string, def: T): T {
    const r = this.h.prepare("SELECT value FROM settings WHERE key = ?").get(key) as { value: string } | undefined;
    if (!r) return def;
    try {
      return JSON.parse(r.value) as T;
    } catch {
      return def;
    }
  }
  setSetting(key: string, value: unknown): void {
    this.h.prepare("INSERT INTO settings(key, value) VALUES(?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value").run(key, JSON.stringify(value));
  }

  // ---- comics -----------------------------------------------------------------------------
  private abs(rel: string): string {
    const root = this.rootGetter();
    return root ? path.join(root, ...rel.split("/")) : rel;
  }

  allComics(): ComicRecord[] {
    const tags = new Map<string, string[]>();
    for (const r of this.h.prepare("SELECT comic_id, tag FROM comic_tags").all() as { comic_id: string; tag: string }[]) {
      (tags.get(r.comic_id) ?? tags.set(r.comic_id, []).get(r.comic_id)!).push(r.tag);
    }
    const rows = this.h.prepare("SELECT * FROM comics").all() as any[];
    return rows.map((r) => ({
      id: r.id,
      path: this.abs(r.rel_path),
      relPath: r.rel_path,
      name: r.name,
      folder: r.folder,
      author: r.author,
      pages: r.pages,
      size: r.size,
      mtime: r.mtime,
      addedAt: r.added_at,
      favorite: !!r.favorite,
      read: !!r.read,
      lastPage: r.last_page,
      lastReadAt: r.last_read_at,
      tags: tags.get(r.id) ?? [],
      fp: r.fingerprint ? (JSON.parse(r.fingerprint) as Fingerprint) : undefined,
      thumbRev: r.thumb_rev,
      verification: r.verification ?? undefined,
    }));
  }

  comicById(id: string): ComicRecord | undefined {
    return this.allComics().find((c) => c.id === id);
  }
  comicRow(id: string): { id: string; rel_path: string } | undefined {
    return this.h.prepare("SELECT id, rel_path FROM comics WHERE id = ?").get(id) as any;
  }
  comicIdByRel(rel: string): string | undefined {
    return (this.h.prepare("SELECT id FROM comics WHERE rel_path = ?").get(rel) as any)?.id;
  }

  upsertComic(c: ComicRow, id?: string): string {
    const existing = id ?? this.comicIdByRel(c.relPath);
    if (existing) {
      this.h
        .prepare("UPDATE comics SET rel_path=?, name=?, folder=?, author=?, pages=?, size=?, mtime=? WHERE id=?")
        .run(c.relPath, c.name, c.folder, c.author, c.pages, c.size, c.mtime, existing);
      this.ftsPut(existing);
      return existing;
    }
    this.h
      .prepare("INSERT INTO comics(id, rel_path, name, folder, author, pages, size, mtime, added_at) VALUES(?,?,?,?,?,?,?,?,?)")
      .run(c.id, c.relPath, c.name, c.folder, c.author, c.pages, c.size, c.mtime, Date.now());
    this.ftsPut(c.id);
    return c.id;
  }

  deleteComics(ids: string[]): void {
    const del = this.h.prepare("DELETE FROM comics WHERE id = ?");
    const fts = this.h.prepare("DELETE FROM comic_fts WHERE comic_id = ?");
    this.h.transaction(() => ids.forEach((i) => (del.run(i), fts.run(i))))();
  }

  setFingerprint(id: string, fp: Fingerprint): void {
    this.h.prepare("UPDATE comics SET fingerprint = ? WHERE id = ?").run(JSON.stringify(fp), id);
  }
  bumpThumb(id: string): void {
    this.h.prepare("UPDATE comics SET thumb_rev = thumb_rev + 1 WHERE id = ?").run(id);
  }
  setVerification(id: string, v: string | null): void {
    this.h.prepare("UPDATE comics SET verification = ? WHERE id = ?").run(v, id);
  }

  ftsPut(id: string): void {
    const r = this.h.prepare("SELECT name, folder, author FROM comics WHERE id = ?").get(id) as any;
    this.h.prepare("DELETE FROM comic_fts WHERE comic_id = ?").run(id);
    if (!r) return;
    const tags = (this.h.prepare("SELECT tag FROM comic_tags WHERE comic_id = ?").all(id) as { tag: string }[]).map((t) => t.tag).join(" ");
    this.h
      .prepare("INSERT INTO comic_fts(comic_id, name, folder, author, tags) VALUES(?,?,?,?,?)")
      .run(id, normalizeText(r.name), normalizeText(r.folder), normalizeText(r.author), normalizeText(tags));
  }

  ftsRebuild(): number {
    this.h.transaction(() => {
      this.h.exec("DELETE FROM comic_fts");
      for (const r of this.h.prepare("SELECT id FROM comics").all() as { id: string }[]) this.ftsPut(r.id);
    })();
    return (this.h.prepare("SELECT COUNT(*) n FROM comic_fts").get() as any).n;
  }

  /** User state (favorites, tags, progress) applied in one transaction. */
  applyState(patches: ComicStatePatch[], tagDefs: TagDef[] = [], deleteTags: string[] = []): void {
    this.h.transaction(() => {
      const upd = this.h.prepare(
        "UPDATE comics SET favorite = COALESCE(?, favorite), read = COALESCE(?, read), last_page = COALESCE(?, last_page), last_read_at = COALESCE(?, last_read_at) WHERE id = ?",
      );
      const delTags = this.h.prepare("DELETE FROM comic_tags WHERE comic_id = ?");
      const insTag = this.h.prepare("INSERT OR IGNORE INTO comic_tags(comic_id, tag) VALUES(?, ?)");
      const defTag = this.h.prepare("INSERT OR IGNORE INTO tags(name, color) VALUES(?, NULL)");
      for (const p of patches) {
        upd.run(p.favorite === undefined ? null : +p.favorite, p.read === undefined ? null : +p.read, p.lastPage ?? null, p.lastReadAt ?? null, p.id);
        if (p.tags) {
          delTags.run(p.id);
          for (const t of p.tags) {
            defTag.run(t);
            insTag.run(p.id, t);
          }
          this.ftsPut(p.id);
        }
      }
      for (const d of tagDefs) this.h.prepare("INSERT INTO tags(name, color) VALUES(?, ?) ON CONFLICT(name) DO UPDATE SET color = excluded.color").run(d.name, d.color ?? null);
      for (const t of deleteTags) {
        const ids = this.h.prepare("SELECT comic_id FROM comic_tags WHERE tag = ?").all(t) as { comic_id: string }[];
        this.h.prepare("DELETE FROM comic_tags WHERE tag = ?").run(t);
        this.h.prepare("DELETE FROM tags WHERE name = ?").run(t);
        ids.forEach((i) => this.ftsPut(i.comic_id));
      }
    })();
  }

  allTags(): TagDef[] {
    return (this.h.prepare("SELECT name, color FROM tags ORDER BY name").all() as any[]).map((r) => ({ name: r.name, color: r.color ?? undefined }));
  }

  // ---- folders and archives ------------------------------------------------------------------
  replaceFolders(list: FolderRecord[]): void {
    const ins = this.h.prepare("INSERT INTO folders(path, name, parent, kind, comics, size) VALUES(?,?,?,?,?,?)");
    this.h.transaction(() => {
      this.h.exec("DELETE FROM folders");
      for (const f of list) ins.run(f.path, f.name, f.parent, f.kind, f.comics, f.size);
    })();
  }
  allFolders(): FolderRecord[] {
    return this.h.prepare("SELECT path, name, parent, kind, comics, size FROM folders ORDER BY path").all() as FolderRecord[];
  }

  allArchives(): ArchiveRecord[] {
    return (this.h.prepare("SELECT * FROM archives ORDER BY rel_path").all() as any[]).map((r) => this.archiveFromRow(r));
  }
  archive(id: string): ArchiveRecord | undefined {
    const r = this.h.prepare("SELECT * FROM archives WHERE id = ?").get(id);
    return r ? this.archiveFromRow(r) : undefined;
  }
  private archiveFromRow(r: any): ArchiveRecord {
    return {
      id: r.id,
      path: this.abs(r.rel_path),
      relPath: r.rel_path,
      name: r.name,
      folder: r.folder,
      author: r.author,
      size: r.size,
      parts: JSON.parse(r.parts),
      missingParts: JSON.parse(r.missing),
      encrypted: !!r.encrypted,
      status: r.status,
      targetName: r.target_name,
      uncompressed: r.uncompressed ?? undefined,
      detail: r.detail ?? undefined,
    };
  }
  upsertArchive(a: Omit<ArchiveRecord, "path">): void {
    this.h
      .prepare(
        `INSERT INTO archives(id, rel_path, name, folder, author, size, parts, missing, encrypted, status, target_name)
         VALUES(@id,@relPath,@name,@folder,@author,@size,@parts,@missing,@encrypted,@status,@targetName)
         ON CONFLICT(rel_path) DO UPDATE SET size=excluded.size, parts=excluded.parts, missing=excluded.missing, name=excluded.name, folder=excluded.folder, author=excluded.author, target_name=excluded.target_name`,
      )
      .run({ ...a, parts: JSON.stringify(a.parts), missing: JSON.stringify(a.missingParts), encrypted: +a.encrypted });
  }
  deleteArchivesNotIn(relPaths: Set<string>): number {
    let n = 0;
    for (const r of this.h.prepare("SELECT id, rel_path, status FROM archives").all() as any[]) {
      if (!relPaths.has(r.rel_path) && r.status !== "deleted") {
        this.h.prepare("DELETE FROM archives WHERE id = ?").run(r.id);
        n++;
      }
    }
    return n;
  }
  setArchive(id: string, patch: { status?: string; encrypted?: boolean; uncompressed?: number; detail?: string | null }): void {
    const sets: string[] = [];
    const vals: unknown[] = [];
    if (patch.status !== undefined) (sets.push("status = ?"), vals.push(patch.status));
    if (patch.encrypted !== undefined) (sets.push("encrypted = ?"), vals.push(+patch.encrypted));
    if (patch.uncompressed !== undefined) (sets.push("uncompressed = ?"), vals.push(patch.uncompressed));
    if (patch.detail !== undefined) (sets.push("detail = ?"), vals.push(patch.detail));
    if (sets.length) this.h.prepare(`UPDATE archives SET ${sets.join(", ")} WHERE id = ?`).run(...vals, id);
  }

  // ---- reports, jobs, passwords, trash --------------------------------------------------------
  saveReport(r: VerificationReport): void {
    this.h.prepare("INSERT INTO reports(id, json, updated_at) VALUES(?,?,?) ON CONFLICT(id) DO UPDATE SET json=excluded.json, updated_at=excluded.updated_at").run(r.id, JSON.stringify(r), r.updatedAt);
  }
  report(id: string): VerificationReport | undefined {
    const r = this.h.prepare("SELECT json FROM reports WHERE id = ?").get(id) as any;
    return r ? (JSON.parse(r.json) as VerificationReport) : undefined;
  }
  allReports(): VerificationReport[] {
    return (this.h.prepare("SELECT json FROM reports").all() as any[]).map((r) => JSON.parse(r.json));
  }

  async load(): Promise<JobRecord[]> {
    return (this.h.prepare("SELECT json FROM jobs ORDER BY updated_at").all() as any[]).map((r) => JSON.parse(r.json));
  }
  async save(jobs: JobRecord[]): Promise<void> {
    const ins = this.h.prepare("INSERT INTO jobs(id, json, updated_at) VALUES(?,?,?)");
    this.h.transaction(() => {
      this.h.exec("DELETE FROM jobs");
      for (const j of jobs) ins.run(j.id, JSON.stringify(j), j.createdAt);
    })();
  }

  listPasswords(): { id: string; label: string; blob: string }[] {
    return this.h.prepare("SELECT id, label, blob FROM passwords").all() as any[];
  }
  addPassword(id: string, label: string, blob: string): void {
    this.h.prepare("INSERT OR REPLACE INTO passwords(id, label, blob) VALUES(?,?,?)").run(id, label, blob);
  }
  removePassword(id: string): void {
    this.h.prepare("DELETE FROM passwords WHERE id = ?").run(id);
  }

  addTrash(t: TrashItem & { trashPath: string }): void {
    this.h.prepare("INSERT INTO trash(id, name, original_path, trash_path, size, deleted_at) VALUES(?,?,?,?,?,?)").run(t.id, t.name, t.originalPath, t.trashPath, t.size, t.deletedAt);
  }
  trash(): (TrashItem & { trashPath: string })[] {
    return (this.h.prepare("SELECT * FROM trash ORDER BY deleted_at DESC").all() as any[]).map((r) => ({ id: r.id, name: r.name, originalPath: r.original_path, trashPath: r.trash_path, size: r.size, deletedAt: r.deleted_at }));
  }
  removeTrash(id: string): void {
    this.h.prepare("DELETE FROM trash WHERE id = ?").run(id);
  }
  log(action: string, p: string, detail = ""): void {
    this.h.prepare("INSERT INTO deletion_log(at, action, path, detail) VALUES(?,?,?,?)").run(Date.now(), action, p, detail);
  }

  // ---- maintenance ------------------------------------------------------------------------------
  integrity(): { ok: boolean; messages: string[] } {
    const rows = this.h.pragma("integrity_check") as { integrity_check: string }[];
    const messages = rows.map((r) => r.integrity_check);
    return { ok: messages.length === 1 && messages[0] === "ok", messages };
  }
  ftsConsistency(): { ok: boolean; comics: number; indexed: number; error?: string } {
    const comics = (this.h.prepare("SELECT COUNT(*) n FROM comics").get() as any).n as number;
    const indexed = (this.h.prepare("SELECT COUNT(*) n FROM comic_fts").get() as any).n as number;
    try {
      this.h.exec("INSERT INTO comic_fts(comic_fts) VALUES('integrity-check')");
    } catch (e) {
      return { ok: false, comics, indexed, error: (e as Error).message };
    }
    return { ok: comics === indexed, comics, indexed };
  }
  counts() {
    const n = (sql: string) => (this.h.prepare(sql).get() as any).n as number;
    return {
      comics: n("SELECT COUNT(*) n FROM comics"),
      tags: n("SELECT COUNT(DISTINCT tag) n FROM comic_tags"),
      favorites: n("SELECT COUNT(*) n FROM comics WHERE favorite = 1"),
      read: n("SELECT COUNT(*) n FROM comics WHERE read = 1"),
    };
  }
  backupTo(file: string): void {
    fs.mkdirSync(path.dirname(file), { recursive: true });
    if (fs.existsSync(file)) fs.rmSync(file);
    this.h.exec(`VACUUM INTO '${file.replace(/'/g, "''")}'`);
  }
  restoreFrom(file: string): void {
    this.close();
    for (const ext of ["-wal", "-shm"]) fs.rmSync(this.file + ext, { force: true });
    fs.copyFileSync(file, this.file);
    this.open();
  }
}
