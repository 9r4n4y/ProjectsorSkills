// Image decoding and thumbnail generation run in a hidden renderer (Chromium decodes every supported format),
// so the main process and the UI never block. Structural checks use the shared inspector first.

import { BrowserWindow, ipcMain } from "electron";
import * as fsp from "node:fs/promises";
import * as path from "node:path";
import { type ImagePort, inspectImage } from "@comiclib/shared";

interface Pending {
  resolve: (r: ImagingResult) => void;
}

export interface ImagingResult {
  ok: boolean;
  width: number;
  height: number;
  error?: string;
  small?: ArrayBuffer;
  medium?: ArrayBuffer;
}

class Gate {
  private active = 0;
  private q: (() => void)[] = [];
  constructor(private max: number) {}
  async run<T>(fn: () => Promise<T>): Promise<T> {
    if (this.active >= this.max) await new Promise<void>((r) => this.q.push(r));
    this.active++;
    try {
      return await fn();
    } finally {
      this.active--;
      this.q.shift()?.();
    }
  }
}

export class Imaging implements ImagePort {
  private win: BrowserWindow | null = null;
  private ready: Promise<void> | null = null;
  private pending = new Map<number, Pending>();
  private seq = 0;
  private gate = new Gate(3);

  constructor(
    private htmlPath: string,
    private preloadPath: string,
    private urlFor: (abs: string) => string,
  ) {
    ipcMain.on("imaging:result", (_e, id: number, r: ImagingResult) => {
      const p = this.pending.get(id);
      if (p) {
        this.pending.delete(id);
        p.resolve(r);
      }
    });
  }

  private ensure(): Promise<void> {
    if (!this.ready) {
      this.win = new BrowserWindow({
        show: false,
        webPreferences: { preload: this.preloadPath, contextIsolation: true, sandbox: false, backgroundThrottling: false },
      });
      this.ready = this.win.loadFile(this.htmlPath).then(() => undefined);
      this.win.on("closed", () => {
        this.win = null;
        this.ready = null;
        for (const p of this.pending.values()) p.resolve({ ok: false, width: 0, height: 0, error: "imaging process closed" });
        this.pending.clear();
      });
    }
    return this.ready;
  }

  private async call(kind: "decode" | "thumb", abs: string): Promise<ImagingResult> {
    await this.ensure();
    const id = ++this.seq;
    return new Promise<ImagingResult>((resolve) => {
      const timer = setTimeout(() => {
        this.pending.delete(id);
        resolve({ ok: false, width: 0, height: 0, error: "decode timed out" });
      }, 60_000);
      this.pending.set(id, {
        resolve: (r) => {
          clearTimeout(timer);
          resolve(r);
        },
      });
      this.win!.webContents.send("imaging:task", { id, kind, url: this.urlFor(abs) });
    });
  }

  /** Layer 5: header and truncation check, then a full decode. */
  async check(abs: string) {
    try {
      const bytes = new Uint8Array(await fsp.readFile(abs));
      const s = inspectImage(bytes);
      if (!s.ok) return { ok: false, width: s.width, height: s.height, error: s.error };
    } catch (e) {
      return { ok: false, width: 0, height: 0, error: (e as Error).message };
    }
    const r = await this.gate.run(() => this.call("decode", abs));
    return { ok: r.ok && r.width > 0 && r.height > 0, width: r.width, height: r.height, error: r.error };
  }

  /** Writes small (200 px wide) and medium (400 px wide) cover-cropped 2:3 thumbnails. */
  async thumbs(srcAbs: string, smallOut: string, mediumOut: string): Promise<boolean> {
    const r = await this.gate.run(() => this.call("thumb", srcAbs));
    if (!r.ok || !r.small || !r.medium) return false;
    await fsp.mkdir(path.dirname(smallOut), { recursive: true });
    await fsp.writeFile(smallOut, Buffer.from(r.small));
    await fsp.writeFile(mediumOut, Buffer.from(r.medium));
    return true;
  }

  destroy(): void {
    this.win?.destroy();
  }
}
