// Recursive, parallel, incremental library scanner.
// A comic is a folder that directly contains page images; archives are grouped (split sets merged).

import * as fsp from "node:fs/promises";
import * as path from "node:path";
import { type ArchiveGroup, type IndexedItem, groupArchives, isImageFile, naturalCompare } from "@comiclib/shared";

export interface ScannedComic {
  relPath: string;
  name: string;
  folder: string;
  author: string;
  pages: number;
  size: number;
  mtime: number;
}

export interface ScannedArchive {
  relPath: string;
  name: string;
  folder: string;
  author: string;
  size: number;
  group: ArchiveGroup;
}

export interface ScanResult {
  comics: ScannedComic[];
  archives: ScannedArchive[];
  /** every non-hidden directory, relative path */
  dirs: string[];
}

class Limiter {
  private active = 0;
  private queue: (() => void)[] = [];
  constructor(private max: number) {}
  async run<T>(fn: () => Promise<T>): Promise<T> {
    if (this.active >= this.max) await new Promise<void>((r) => this.queue.push(r));
    this.active++;
    try {
      return await fn();
    } finally {
      this.active--;
      this.queue.shift()?.();
    }
  }
}

export async function naturalPages(dir: string): Promise<string[]> {
  const names = await fsp.readdir(dir);
  return names.filter((n) => isImageFile(n)).sort(naturalCompare);
}

/** Describe a single comic folder (used by scans and by the extraction index port). */
export async function describeComic(root: string, dir: string, prev?: IndexedItem): Promise<ScannedComic | null> {
  const names = await naturalPages(dir);
  if (!names.length) return null;
  const st = await fsp.stat(dir);
  const mtime = Math.floor(st.mtimeMs);
  const rel = path.relative(root, dir).split(path.sep).join("/");
  const parts = rel.split("/");
  let size = 0;
  if (prev && prev.mtime === mtime && prev.pages === names.length) size = prev.size;
  else {
    const sizes = await Promise.all(names.map((n) => fsp.stat(path.join(dir, n)).then((s) => s.size, () => 0)));
    size = sizes.reduce((a, b) => a + b, 0);
  }
  return { relPath: rel, name: parts[parts.length - 1], folder: parts.slice(0, -1).join("/"), author: parts.length > 1 ? parts[0] : "", pages: names.length, size, mtime };
}

export async function scanRoot(
  root: string,
  prev: ReadonlyMap<string, IndexedItem>,
  onProgress?: (dirs: number, comics: number) => void,
  signal?: AbortSignal,
): Promise<ScanResult> {
  const limiter = new Limiter(24);
  const comics: ScannedComic[] = [];
  const archives: ScannedArchive[] = [];
  const dirs: string[] = [];
  let seen = 0;

  const walk = async (abs: string, rel: string): Promise<void> => {
    if (signal?.aborted) return;
    const entries = await limiter.run(() => fsp.readdir(abs, { withFileTypes: true }).catch(() => []));
    const subdirs: string[] = [];
    const images: string[] = [];
    const files: { name: string; size: number }[] = [];
    const archiveNames: string[] = [];
    for (const e of entries) {
      if (e.name.startsWith(".")) continue;
      if (e.isSymbolicLink()) continue;
      if (e.isDirectory()) subdirs.push(e.name);
      else if (e.isFile()) {
        if (isImageFile(e.name)) images.push(e.name);
        else archiveNames.push(e.name);
      }
    }
    if (rel) dirs.push(rel);
    seen++;
    if (images.length) {
      const c = await limiter.run(() => describeComic(root, abs, prev.get(rel)));
      if (c) comics.push(c);
    }
    if (archiveNames.length) {
      const stats = await Promise.all(archiveNames.map((n) => limiter.run(() => fsp.stat(path.join(abs, n)).then((s) => ({ name: n, size: s.size }), () => null))));
      for (const s of stats) if (s) files.push(s);
      const parts = rel.split("/").filter(Boolean);
      for (const g of groupArchives(files)) {
        archives.push({
          relPath: rel ? `${rel}/${g.primary}` : g.primary,
          name: g.base,
          folder: rel,
          author: parts.length ? parts[0] : "",
          size: g.size,
          group: g,
        });
      }
    }
    onProgress?.(seen, comics.length);
    await Promise.all(subdirs.map((n) => walk(path.join(abs, n), rel ? `${rel}/${n}` : n)));
  };

  await walk(root, "");
  comics.sort((a, b) => naturalCompare(a.relPath, b.relPath));
  return { comics, archives, dirs: dirs.sort(naturalCompare) };
}
