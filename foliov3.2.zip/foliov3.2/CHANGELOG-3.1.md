# Folio v3.1

- **Edge Panel**: Removed the left three-line menu rail and sidebar drawer; replaced with a right-edge Mochi Nook Edge Panel handle (tap or swipe left to open, tap outside / swipe right / Back to close).
- **Non-sticky Search & Controls**: Re-arranged the library title, search bar, and filter/sort/grid/select toolbar in a clean scrolling card that moves away as you scroll.
- **Top & Bottom Pagination**: Updated the library page navigation bar at both the top and bottom of the comic grid, and added mobile-friendly Previous/Next page buttons inside the reader.
- **Fixed Comic Opening Errors**: Added error handling and retry flows when loading comic pages in Quick Look and the Reader, wrapped overlays in an error boundary, guarded against missing folders/null roots in Kotlin, escaped `#`/`?` in Capacitor file URLs, and added automatic native `readImage` fallback with proper MIME type detection.
- **Fixed APK Zoom Image Vanishing**: Removed `contain: layout paint` on `#root`, separated the scroll container from the GPU `translate3d` zoom stage, clamped pan bounds, fixed 2-finger-to-1-finger pinch transitions, and guarded against zero-distance `NaN` transforms.
- **v3.1 Branding & New App Logo**: Bumped version to `3.1` (`versionCode 4`, `Folio v3.1`) and updated all Android adaptive/round/legacy launcher icons (`#250453` background) and desktop icon with the new logo.
