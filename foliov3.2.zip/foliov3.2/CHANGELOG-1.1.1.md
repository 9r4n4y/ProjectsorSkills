# 1.1.1 UI fix pass (versionCode 2, appId app.comiclib.mobile)

Verified in headless Chromium at 320/360/390 px, light and dark (see "Not verified" below for Android).

- **Zoom-out / sliding page**: the page is now a fixed-size shell (`html, body { position: fixed; overflow: hidden }`), the viewport meta disables browser pinch-zoom (the reader keeps its own pinch/double-tap zoom) and `MainActivity` turns off WebView zoom. `touch-action: manipulation` removes double-tap zoom and the 300 ms tap delay.
- **Overlapping / clipped headers**: `PageShell` and the Library header wrap instead of squeezing; the title keeps a minimum width and actions drop to their own row on phones; cards clip their content; badges never wrap; table cells never wrap (the table scrolls sideways instead).
- **Buttons ("button over a button")**: every `Button` is now a static transparent hit target with a separate visual face (same `.btn` / `.f` structure as ui-inspiration.html). All motion (hover lift, press squeeze, spring) is on the face, which has `pointer-events: none`, so the pointer can never slide off the element mid-press. Other hit targets (comic cards, segmented control, sidebar items, filter +/- buttons, reader mode buttons) no longer scale themselves either.
- **Grid size**: five real steps (1 largest to 5 smallest) with a different column count at each step on every width (phone: 1,2,3,4,5 columns). The popover shows the current step name. Default is now step 2 (2 columns on a phone). Test: `tests/grid-density.test.ts`.
- **Fonts**: Quicksand and Bagel Fat One now come from `@fontsource` packages and are inlined in `dist/index.html` (works offline, no files to fetch). Display text no longer gets a synthetic bold.
- **Reader**: Mochi-styled bars; placeholders only for pages that have not loaded (loaded pages sit flush, measured gap 0 px); paged pages centred (measured 100 px above and below on a 360x740 screen); `touch-action` is `pan-y` only when a fit-width page can scroll, otherwise `none` so pinch/pan are never stolen.
- **Launcher icon**: the supplied artwork is pre-rendered to `android/native/res` (legacy, round and adaptive) and copied by `scripts/prepare-android.mjs`.
- `store.ts` no longer throws when `matchMedia` is missing (fixes `tests/back-stack.test.ts` in jsdom).

## Not verified
Gradle build, APK install and any on-device run (no Android SDK or device in this environment). Run `docs/ANDROID_TEST_CHECKLIST.md` on a phone.
