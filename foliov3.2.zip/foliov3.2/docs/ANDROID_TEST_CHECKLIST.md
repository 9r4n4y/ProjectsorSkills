# Android device checklist (must be run on a real device or emulator; NOT run in the build sandbox)

Capture logs first: `adb logcat -c && adb logcat *:W ComicDb:I ComicApp:E ComicNative:E AndroidRuntime:E`

1. **Fresh install** `adb install release/ComicLibrary-debug.apk`; cold start. Expect `ComicDb: SQLite x.y, FTS5=true|false` and no `AndroidRuntime` FATAL.
2. **Upgrade**: install the old APK, open the app, add a library, then `adb install -r` the new one (same debug key required). Library, settings, reading progress remain.
3. **Insets** (Android 9, 12, 15; gesture and 3-button nav; portrait + landscape; cutout device if possible): nothing under the status bar; top buttons (menu, search, reader close) tappable; bottom nav / reader scrubber clear of the nav bar; status-bar icons readable in light and dark theme.
4. **Reader scrubber**: drag slowly and fast; thumb follows the finger, no flicker; paged/auto commit on release; scroll mode follows live; label shows page N of M.
5. **Paged mode**: portrait, landscape, tiny and very tall pages are centred; tap left/right edges turn pages; pinch/double-tap zoom, pan, page change resets zoom; rotate keeps the page.
6. **Scroll mode**: no gap between pages (zoom screenshot at page joins); close and reopen resumes the last page.
7. **Back**: dialog open -> closes it; reader -> returns to library, progress kept; Settings/Tags -> Library; at Library root app goes to background (still in recents, not killed). Test hardware button and gesture.
8. `aapt dump permissions` shows no INTERNET.

9. **Mochi Nook visuals** (light and dark, 360 px phone and a tablet): fonts load (headings are rounded and heavy, not system bold); text on pastel fills is readable; buttons press down and spring back; library cards, dialogs, drawer, settings cards, bottom nav, onboarding and the reader controls all use the same ink outline; no clipped button shadows inside dialogs or toolbars; focus ring visible with an external keyboard; "reduce motion" system setting removes the spring animations.
