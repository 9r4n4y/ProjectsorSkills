@echo off
rem One-click launcher. Opens the portable app if it has been built, otherwise builds and runs it from source.
cd /d "%~dp0"
if exist "release\ComicLibrary-Portable.exe" (
  start "" "release\ComicLibrary-Portable.exe"
) else (
  call npm run dev:pc
)
