import { ChevronLeft, ChevronRight, ChevronsLeft, ChevronsRight } from "lucide-react";
import { Button } from "@/components/ui/button";

/** Page buttons used at the top and the bottom of every paged list. */
export function Pager({ page, total, pageSize, onChange, className }: { page: number; total: number; pageSize: number; onChange: (p: number) => void; className?: string }) {
  const pages = Math.max(1, Math.ceil(total / pageSize));
  if (total === 0) return null;
  const from = page * pageSize + 1;
  const to = Math.min(total, (page + 1) * pageSize);
  const single = pages <= 1;
  return (
    <nav
      className={`flex flex-wrap items-center justify-between gap-2 rounded-[20px] border-[2.5px] border-ink bg-surface px-3 py-2 shadow-[0_3px_0_var(--ink)] ${className ?? ""}`}
      aria-label="Pages"
    >
      <span className="text-[12px] font-bold text-sub tabular-nums">
        {from.toLocaleString()}–{to.toLocaleString()} of {total.toLocaleString()}
      </span>
      <div className="flex items-center gap-1.5">
        <Button variant="outline" size="icon" aria-label="First page" title="First page" disabled={single || page === 0} onClick={() => onChange(0)}>
          <ChevronsLeft />
        </Button>
        <Button variant="outline" size="icon" aria-label="Previous page" title="Previous page" disabled={single || page === 0} onClick={() => onChange(page - 1)}>
          <ChevronLeft />
        </Button>
        <span className="min-w-[84px] rounded-full border-2 border-ink bg-muted px-2.5 py-1 text-center text-[12px] font-bold tabular-nums text-fg">
          {page + 1} / {pages}
        </span>
        <Button variant="outline" size="icon" aria-label="Next page" title="Next page" disabled={single || page >= pages - 1} onClick={() => onChange(page + 1)}>
          <ChevronRight />
        </Button>
        <Button variant="outline" size="icon" aria-label="Last page" title="Last page" disabled={single || page >= pages - 1} onClick={() => onChange(pages - 1)}>
          <ChevronsRight />
        </Button>
      </div>
    </nav>
  );
}
