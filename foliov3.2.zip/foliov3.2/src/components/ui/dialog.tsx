import * as React from "react";
import * as D from "@radix-ui/react-dialog";
import { X } from "lucide-react";
import { cn } from "@/utils/cn";
import { Button } from "./button";
import { useBackClose } from "@/lib/hooks";

export const Dialog = D.Root;
export const DialogTrigger = D.Trigger;

interface ContentProps {
  title: string;
  description?: string;
  /** centered modal, or a side panel (bottom sheet on small screens) */
  panel?: boolean;
  size?: "sm" | "md" | "lg" | "xl";
  className?: string;
  hideTitle?: boolean;
  children: React.ReactNode;
  onCloseAutoFocus?: (e: Event) => void;
  headerExtra?: React.ReactNode;
  zIndex?: number;
}

const sizes = { sm: "sm:max-w-md", md: "sm:max-w-xl", lg: "sm:max-w-3xl", xl: "sm:max-w-5xl" };

export function DialogContent({ title, description, panel, size = "md", className, hideTitle, children, onCloseAutoFocus, headerExtra, zIndex = 50 }: ContentProps) {
  const ref = React.useRef<HTMLDivElement>(null);
  // Every dialog is dismissed by Back through its own close button, so busy/confirm guards in onOpenChange still apply.
  useBackClose(true, () => ref.current?.querySelector<HTMLElement>("[data-dialog-close]")?.click());
  return (
    <D.Portal>
      <D.Overlay style={{ zIndex }} className="dlg-overlay fixed inset-0 bg-[#140f32]/50" />
      <D.Content
        ref={ref}
        style={{ zIndex: zIndex + 1 }}
        onCloseAutoFocus={onCloseAutoFocus}
        aria-describedby={description ? undefined : undefined}
        className={cn(
          "fixed flex flex-col overflow-hidden border-[2.5px] border-ink bg-surface text-fg outline-none safe-b",
          panel
            ? "dlg-panel inset-x-0 bottom-0 max-h-[88dvh] rounded-t-[30px] border-b-0 sm:inset-y-0 sm:right-0 sm:left-auto sm:max-h-none sm:w-[420px] sm:rounded-none sm:border-y-0 sm:border-r-0"
            : cn("dlg-pop inset-x-0 bottom-0 max-h-[92dvh] rounded-t-[30px] border-b-0 sm:inset-auto sm:left-1/2 sm:top-1/2 sm:w-[calc(100%-32px)] sm:-translate-x-1/2 sm:-translate-y-1/2 sm:rounded-[28px] sm:border-b-[2.5px] sm:shadow-[0_6px_0_var(--ink)]", sizes[size]),
          className,
        )}
      >
        <span aria-hidden className="mx-auto mt-2 h-1.5 w-11 shrink-0 rounded-full bg-ink/30 sm:hidden" />
        <div className={cn("flex items-center gap-3 border-b border-line px-5 py-3", hideTitle && "sr-only")}>
          <div className="min-w-0 flex-1">
            <D.Title className="clamp-2 font-display text-[17px] font-extrabold leading-6">{title}</D.Title>
            {description ? <D.Description className="mt-0.5 text-[13px] text-sub">{description}</D.Description> : null}
          </div>
          {headerExtra}
          <D.Close asChild>
            <Button variant="ghost" size="icon" aria-label="Close" data-dialog-close>
              <X />
            </Button>
          </D.Close>
        </div>
        {children}
      </D.Content>
    </D.Portal>
  );
}
