import * as React from "react";
import * as P from "@radix-ui/react-popover";
import * as S from "@radix-ui/react-switch";
import { Check, CircleAlert, CircleCheck, CircleX, Minus } from "lucide-react";
import type { LayerStatus, Tri } from "@comiclib/shared";
import { cn } from "@/utils/cn";

export const Input = React.forwardRef<HTMLInputElement, React.InputHTMLAttributes<HTMLInputElement>>(({ className, ...p }, ref) => (
  <input
    ref={ref}
    className={cn(
      "h-9 w-full min-w-0 rounded-full border-[2.5px] border-ink bg-surface px-4 text-sm font-semibold text-fg placeholder:text-sub transition-shadow duration-300 focus-visible:outline-none focus-visible:ring-4 focus-visible:ring-lilac pointer-coarse:h-11",
      className,
    )}
    {...p}
  />
));
Input.displayName = "Input";

export function Switch({ checked, onCheckedChange, label }: { checked: boolean; onCheckedChange: (v: boolean) => void; label: string }) {
  return (
    <S.Root
      checked={checked}
      onCheckedChange={onCheckedChange}
      aria-label={label}
      className="relative inline-flex h-[30px] w-[52px] shrink-0 items-center rounded-full border-[2.5px] border-ink bg-muted transition-colors duration-300 data-[state=checked]:bg-mint"
    >
      <S.Thumb className="block size-5 translate-x-[3px] rounded-full border-[2.5px] border-ink bg-surface transition-transform duration-500 ease-spring data-[state=checked]:translate-x-[22px]" />
    </S.Root>
  );
}

export function Progress({ value, className, label }: { value: number; className?: string; label?: string }) {
  const v = Math.max(0, Math.min(1, value));
  return (
    <div role="progressbar" aria-label={label} aria-valuenow={Math.round(v * 100)} aria-valuemin={0} aria-valuemax={100} className={cn("h-3.5 w-full overflow-hidden rounded-full border-2 border-ink bg-muted", className)}>
      <div className={cn("stamp-fill h-full rounded-full transition-[width] duration-500 ease-spring", v > 0 && "border-r-2 border-ink")} style={{ width: `${v * 100}%` }} />
    </div>
  );
}

export function Badge({ children, tone = "neutral", className }: { children: React.ReactNode; tone?: "neutral" | "ok" | "warn" | "bad" | "accent"; className?: string }) {
  const tones = {
    neutral: "bg-muted text-sub",
    accent: "bg-lilac text-on",
    ok: "bg-mint text-on",
    warn: "bg-butter text-on",
    bad: "bg-peach text-on",
  };
  return <span className={cn("inline-flex h-6 shrink-0 items-center gap-1 whitespace-nowrap rounded-full border-2 border-ink px-2.5 text-xs font-bold", tones[tone], className)}>{children}</span>;
}

export const Popover = P.Root;
export const PopoverTrigger = P.Trigger;
export function PopoverContent({ className, children, align = "end" }: { className?: string; children: React.ReactNode; align?: "start" | "center" | "end" }) {
  return (
    <P.Portal>
      <P.Content align={align} sideOffset={6} className={cn("dlg-pop z-[70] rounded-[20px] border-[2.5px] border-ink bg-surface p-1.5 text-fg shadow-[0_4px_0_var(--ink)] outline-none", className)}>
        {children}
      </P.Content>
    </P.Portal>
  );
}

const triMap = {
  green: { icon: CircleCheck, cls: "text-ok", label: "Verified" },
  amber: { icon: CircleAlert, cls: "text-warn", label: "Warning" },
  red: { icon: CircleX, cls: "text-bad", label: "Failed" },
} as const;

export function TriIcon({ tri, className }: { tri: Tri; className?: string }) {
  const m = triMap[tri];
  const I = m.icon;
  return <I aria-label={m.label} className={cn("size-4 shrink-0", m.cls, className)} />;
}

export function LayerDot({ status, title }: { status: LayerStatus; title: string }) {
  const cls = { pass: "bg-ok", warn: "bg-warn", fail: "bg-bad", skip: "bg-line" }[status];
  return <span title={title} className={cn("block size-2 rounded-full", cls)} />;
}

export function LayerIcon({ status }: { status: LayerStatus }) {
  if (status === "pass") return <Check className="size-4 text-ok" aria-label="Pass" />;
  if (status === "warn") return <CircleAlert className="size-4 text-warn" aria-label="Warning" />;
  if (status === "fail") return <CircleX className="size-4 text-bad" aria-label="Fail" />;
  return <Minus className="size-4 text-sub" aria-label="Skipped" />;
}

export function Segmented<T extends string>({ value, onChange, options, label }: { value: T; onChange: (v: T) => void; options: { value: T; label: string }[]; label: string }) {
  return (
    <div role="radiogroup" aria-label={label} className="inline-flex max-w-full gap-0.5 rounded-full border-[2.5px] border-ink bg-muted p-0.5">
      {options.map((o) => (
        <button
          key={o.value}
          role="radio"
          aria-checked={value === o.value}
          onClick={() => onChange(o.value)}
          className={cn(
            "h-8 min-w-0 rounded-full border-2 px-3 text-[13px] min-[380px]:px-4 font-bold transition-[background-color,color,transform] duration-300 ease-spring active:brightness-90 touch-manipulation pointer-coarse:h-10",
            value === o.value ? "border-ink bg-mint text-on" : "border-transparent text-sub hover:text-fg",
          )}
        >
          {o.label}
        </button>
      ))}
    </div>
  );
}

export function EmptyState({ icon: Icon, title, text, children }: { icon: React.ElementType; title: string; text: string; children?: React.ReactNode }) {
  return (
    <div className="mx-auto flex max-w-sm flex-col items-center gap-3 px-6 py-16 text-center">
      <div className="flex size-14 items-center justify-center rounded-[20px] border-[2.5px] border-ink bg-butter text-on shadow-[0_4px_0_var(--ink)]">
        <Icon className="size-6" />
      </div>
      <h3 className="font-display text-lg font-extrabold">{title}</h3>
      <p className="text-[13px] text-sub">{text}</p>
      {children}
    </div>
  );
}
