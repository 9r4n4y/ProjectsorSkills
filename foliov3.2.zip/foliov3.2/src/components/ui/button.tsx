import * as React from "react";
import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "@/utils/cn";

/*
 * Mochi buttons, built like the reference "Mochi Nook UI" .btn / .f pair:
 *   - the OUTER <button> is a static, transparent hit target. It never moves, scales or resizes, so the pointer can
 *     never slide off it mid-press (that is what made taps "animate but not fire", or fire without any feedback);
 *   - the INNER face carries the pastel fill, ink outline, ink base shadow and ALL motion (lift on hover, squeeze on
 *     press, spring back on release). The face has pointer-events:none, so the outer button always gets the click.
 * Ghost buttons use the same structure with a flat face that only tints.
 */
const outer =
  "group relative inline-flex shrink-0 select-none touch-manipulation items-stretch justify-center rounded-[18px] border-0 bg-transparent p-0 pb-1 align-middle text-on disabled:pointer-events-none disabled:opacity-40 focus-visible:outline-none";

const faceBase =
  "pointer-events-none flex min-w-0 flex-1 items-center justify-center gap-2 whitespace-nowrap text-sm font-bold [&_svg]:size-4 [&_svg]:shrink-0 group-focus-visible:ring-4 group-focus-visible:ring-lilac";

const chunky =
  "border-[2.5px] border-ink text-on shadow-[0_4px_0_var(--ink)] transition-[transform,box-shadow,background-color] duration-500 ease-spring group-hover:-translate-y-0.5 group-hover:shadow-[0_6px_0_var(--ink)] group-active:translate-y-1 group-active:shadow-[0_0_0_var(--ink)] group-active:duration-100";

const faceVariants = cva(faceBase, {
  variants: {
    variant: {
      default: `${chunky} bg-butter`,
      secondary: `${chunky} bg-lilac`,
      outline: `${chunky} bg-surface !text-fg`,
      danger: `${chunky} bg-peach`,
      ghost: "text-fg transition-[transform,background-color] duration-300 ease-spring group-hover:bg-muted group-active:scale-90 group-active:bg-line group-active:duration-100",
    },
    size: {
      default: "h-9 rounded-[16px] px-4 pointer-coarse:h-11 pointer-coarse:px-5",
      sm: "h-8 rounded-[14px] px-3 text-[13px] pointer-coarse:h-10",
      lg: "h-11 rounded-[18px] px-6",
      icon: "size-9 rounded-full p-0 pointer-coarse:size-11 [&_svg]:size-[18px]",
    },
  },
  compoundVariants: [{ variant: "ghost", size: ["default", "sm", "lg"], class: "rounded-full" }],
  defaultVariants: { variant: "default", size: "default" },
});

export interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement>, VariantProps<typeof faceVariants> {
  /** extra classes for the visible face (colour, radius); className lands on the static outer button (layout). */
  faceClassName?: string;
}

export const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(({ className, faceClassName, variant, size, children, ...props }, ref) => {
  return (
    <button ref={ref} type="button" className={cn(outer, className)} {...props}>
      <span className={cn(faceVariants({ variant, size }), faceClassName)}>{children}</span>
    </button>
  );
});
Button.displayName = "Button";
