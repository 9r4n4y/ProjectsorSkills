import type { ArchiveRecord, InitInfo, VerificationReport } from "@comiclib/shared";

/** Structured report formatted so it can be pasted straight into an AI chat. */
export function buildErrorReport(r: VerificationReport, a: ArchiveRecord | undefined, info: InitInfo | null): string {
  const bad = r.layers.filter((l) => l.status === "fail" || l.status === "warn");
  const lines = [
    "# Comic Library error report",
    "",
    "## Item",
    `- Archive path: ${a?.path ?? r.archiveRelPath}`,
    `- Archive size: ${r.archiveSize} bytes`,
    `- Parts: ${a?.parts.join(", ") ?? "unknown"}`,
    `- Missing parts: ${a?.missingParts.length ? a.missingParts.join(", ") : "none"}`,
    `- State: ${r.state}`,
    `- Result: ${r.status}`,
    "",
    "## Error",
    r.error ?? "No error text recorded",
    "",
    "## Failing layers",
    ...(bad.length ? bad.flatMap((l) => [`- Layer ${l.layer} (${l.name}): ${l.status.toUpperCase()} - ${l.summary}`, ...l.details.slice(0, 15).map((d) => `    ${d}`)]) : ["- none"]),
    "",
    "## Attempts",
    ...(r.attempts.length ? r.attempts.map((t) => `- #${t.n} ${t.engine} / ${t.mode}: ${t.ok ? "ok" : "failed"}${t.error ? ` (${t.error})` : ""} in ${t.ms} ms`) : ["- none"]),
    "",
    "## Engine output",
    "```",
    (r.engineOutput ?? "(none)").slice(-2500),
    "```",
    "",
    "## Environment",
    `- App: Comic Library ${info?.appVersion ?? "?"}`,
    `- Platform: ${info?.platform ?? "?"}`,
    `- OS: ${info?.env.os ?? "?"}`,
    `- CPUs: ${info?.env.cpus ?? "?"}`,
    `- Free storage: ${info ? Math.round(info.env.freeBytes / 1024 ** 2) : "?"} MB`,
    "",
    "Please explain the most likely cause and the exact steps to fix it.",
  ];
  return lines.join("\n");
}
