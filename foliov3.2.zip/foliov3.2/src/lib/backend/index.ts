import { Capacitor, registerPlugin } from "@capacitor/core";
import type { ApiEvent, ComicRecord, NativeApi } from "@comiclib/shared";
import { createDemoApi } from "./demo";

type Invoke = (method: string, args: unknown[]) => Promise<unknown>;

/** Every method not implemented locally is forwarded to the platform side. */
function proxy(base: Record<string, unknown>, invoke: Invoke): NativeApi {
  return new Proxy(base, {
    get(t, p: string) {
      if (p in t) return t[p];
      return (...args: unknown[]) => invoke(p, args);
    },
  }) as unknown as NativeApi;
}

function electronApi(): NativeApi {
  const n = (window as unknown as { comicNative: { invoke: Invoke; on: (e: string, cb: (p: unknown) => void) => () => void } }).comicNative;
  return proxy(
    {
      platform: "electron",
      thumbUrl: (c: Pick<ComicRecord, "id" | "thumbRev">, size: "s" | "m") => `comic://thumb/${c.id}/${size}?v=${c.thumbRev}`,
      resolveImage: async (u: string) => u,
      on: (e: ApiEvent, cb: (p: unknown) => void) => n.on(e, cb),
    },
    n.invoke,
  );
}

interface NativePlugin {
  invoke(o: { method: string; args: unknown[] }): Promise<{ result: unknown }>;
  addListener(ev: string, cb: (d: { name: string; payload: unknown }) => void): Promise<{ remove(): void }>;
}

/** Encode characters like #, ? that can break Capacitor's local file URLs if left unescaped. */
function safeConvertFileSrc(path: string): string {
  const converted = Capacitor.convertFileSrc(path);
  return converted.replace(/#/g, "%23").replace(/\?/g, "%3F");
}

function capacitorApi(): NativeApi {
  const plugin = registerPlugin<NativePlugin>("ComicNative");
  let thumbDir = "";
  const listeners = new Map<string, Set<(p: unknown) => void>>();
  void plugin.addListener("event", (d) => listeners.get(d.name)?.forEach((cb) => cb(d.payload)));
  const toSrc = (u: string) => (u.startsWith("saf:") ? u : safeConvertFileSrc(u));
  const invoke: Invoke = async (m, a) => (await plugin.invoke({ method: m, args: a })).result;
  const base = {
    platform: "android",
    async init() {
      thumbDir = (await invoke("thumbBase", [])) as string;
      return invoke("init", []);
    },
    thumbUrl: (c: Pick<ComicRecord, "id" | "thumbRev">, size: "s" | "m") => `${safeConvertFileSrc(`${thumbDir}/${c.id}_${size}.jpg`)}?v=${c.thumbRev}`,
    async pages(id: string) {
      const list = (await invoke("pages", [id])) as { name: string; url: string; size: number }[];
      return (Array.isArray(list) ? list : []).map((p) => ({
        ...p,
        url: toSrc(p.url),
        fallbackUrl: p.url.startsWith("saf:") ? p.url : `saf:${p.url}`,
      }));
    },
    async resolveImage(u: string) {
      if (!u.startsWith("saf:")) return u;
      return (await invoke("readImage", [u.slice(4)])) as string;
    },
    on(e: string, cb: (p: unknown) => void) {
      (listeners.get(e) ?? listeners.set(e, new Set()).get(e)!).add(cb);
      return () => listeners.get(e)?.delete(cb);
    },
  };
  return proxy(base, invoke);
}

export function createApi(): NativeApi {
  if ((window as unknown as { comicNative?: unknown }).comicNative) return electronApi();
  if (Capacitor.isNativePlatform()) return capacitorApi();
  return createDemoApi();
}

export const api: NativeApi = createApi();
