// Grid size has FIVE real steps (1 = largest covers ... 5 = smallest). Each step is a different column count at every width:
// a target cover width per step gives the first guess, and the count is forced to grow by at least one column per step,
// so the slider can never skip steps or land on the same layout twice (the old floor() maths only ever produced 2 or 3 columns on a phone).
const TARGET_W = [220, 176, 144, 118, 96];
const PHONE_COLS = [1, 2, 3, 4, 5];
export function columnsFor(inner: number, gap: number, density: number): number {
  const level = Math.min(5, Math.max(1, Math.round(density) || 3)) - 1;
  if (inner < 480) return PHONE_COLS[level];
  let prev = 0;
  for (let i = 0; i <= level; i++) {
    const guess = Math.max(1, Math.round((inner + gap) / (TARGET_W[i] + gap)));
    prev = Math.max(prev + 1, guess);
  }
  return prev;
}
