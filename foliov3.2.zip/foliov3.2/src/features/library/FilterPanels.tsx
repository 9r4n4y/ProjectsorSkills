import { useMemo, useState } from "react";
import { Folder, Minus, Plus, Search, Tag } from "lucide-react";
import { countFolders, countTags, normalizeText, tagKey, toggleInEx } from "@comiclib/shared";
import { useStore } from "@/lib/store";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Input, Segmented } from "@/components/ui/controls";
import { Button } from "@/components/ui/button";
import { cn } from "@/utils/cn";

function IncExRow({ label, sub, count, indent, inc, exc, onInc, onExc, icon: Icon }: { label: string; sub?: string; count: number; indent?: number; inc: boolean; exc: boolean; onInc: () => void; onExc: () => void; icon: React.ElementType }) {
  return (
    <li className="flex items-center gap-2 border-b border-line/60 px-3 py-1" style={{ paddingLeft: 12 + (indent ?? 0) * 16 }}>
      <button
        aria-label={`Include ${label}`}
        aria-pressed={inc}
        onClick={onInc}
        className={cn("flex size-9 shrink-0 items-center justify-center rounded-full border-2 transition-[background-color,transform] duration-300 ease-spring active:brightness-90 touch-manipulation pointer-coarse:size-11", inc ? "border-ink bg-mint text-on" : "border-line text-sub hover:bg-muted hover:text-fg")}
      >
        <Plus className="size-4" />
      </button>
      <div className="flex min-w-0 flex-1 items-center gap-2">
        <Icon className="size-4 shrink-0 text-sub" />
        <div className="min-w-0 flex-1">
          <div className={cn("truncate text-sm", exc && "text-sub line-through")} title={sub ?? label}>{label}</div>
          {sub && <div className="truncate text-xs text-sub">{sub}</div>}
        </div>
        <span className="shrink-0 text-xs tabular-nums text-sub">{count}</span>
      </div>
      <button
        aria-label={`Exclude ${label}`}
        aria-pressed={exc}
        onClick={onExc}
        className={cn("flex size-9 shrink-0 items-center justify-center rounded-full border-2 transition-[background-color,transform] duration-300 ease-spring active:brightness-90 touch-manipulation pointer-coarse:size-11", exc ? "border-ink bg-peach text-on" : "border-line text-sub hover:bg-muted hover:text-fg")}
      >
        <Minus className="size-4" />
      </button>
    </li>
  );
}

export function FilterPanels() {
  const panel = useStore((s) => s.panel);
  const set = useStore((s) => s.set);
  return (
    <Dialog open={panel !== null} onOpenChange={(o) => !o && set({ panel: null })}>
      {panel === "tags" && <TagPanel />}
      {panel === "folders" && <FolderPanel />}
    </Dialog>
  );
}

function TagPanel() {
  const comics = useStore((s) => s.comics);
  const defs = useStore((s) => s.tags);
  const f = useStore((s) => s.filters);
  const setFilters = useStore((s) => s.setFilters);
  const clearFilters = useStore((s) => s.clearFilters);
  const setSettings = useStore((s) => s.setSettings);
  const [q, setQ] = useState("");
  const list = useMemo(() => {
    const counts = countTags(comics);
    const all = new Map<string, { name: string; count: number }>();
    for (const d of defs) all.set(tagKey(d.name), { name: d.name, count: counts.get(tagKey(d.name))?.count ?? 0 });
    for (const [k, v] of counts) all.set(k, v);
    const nq = normalizeText(q);
    return [...all.values()].filter((t) => !nq || normalizeText(t.name).includes(nq)).sort((a, b) => b.count - a.count || a.name.localeCompare(b.name));
  }, [comics, defs, q]);
  const toggle = (name: string, kind: "in" | "ex") => {
    const r = toggleInEx(f.tagsIn, f.tagsEx, name, kind);
    setFilters({ tagsIn: r.inc, tagsEx: r.exc });
  };
  return (
    <DialogContent title="Filter by tag" description={`${list.length} tags. Plus includes, minus excludes.`} panel>
      <div className="flex flex-col gap-3 border-b border-line p-4">
        <div className="relative">
          <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-sub" />
          <Input autoFocus value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search tags" className="pl-9" aria-label="Search tags" />
        </div>
        <div className="flex items-center justify-between gap-3">
          <span className="text-[13px] text-sub">Included tags match</span>
          <Segmented label="Tag combination" value={f.tagMode} onChange={(v) => (setFilters({ tagMode: v }), setSettings({ tagMode: v }))} options={[{ value: "and", label: "All (AND)" }, { value: "or", label: "Any (OR)" }]} />
        </div>
      </div>
      <ul className="min-h-0 flex-1 overflow-y-auto">
        {list.map((t) => (
          <IncExRow key={t.name} icon={Tag} label={t.name} count={t.count} inc={f.tagsIn.some((x) => tagKey(x) === tagKey(t.name))} exc={f.tagsEx.some((x) => tagKey(x) === tagKey(t.name))} onInc={() => toggle(t.name, "in")} onExc={() => toggle(t.name, "ex")} />
        ))}
        {!list.length && <li className="p-6 text-center text-[13px] text-sub">No tag matches "{q}".</li>}
      </ul>
      <div className="flex items-center justify-between gap-2 border-t border-line p-3">
        <Button variant="ghost" size="sm" onClick={() => setFilters({ tagsIn: [], tagsEx: [] })} disabled={!f.tagsIn.length && !f.tagsEx.length}>Clear tags</Button>
        <Button variant="ghost" size="sm" onClick={clearFilters}>Clear all</Button>
      </div>
    </DialogContent>
  );
}

function FolderPanel() {
  const comics = useStore((s) => s.comics);
  const folders = useStore((s) => s.folders);
  const f = useStore((s) => s.filters);
  const setFilters = useStore((s) => s.setFilters);
  const clearFilters = useStore((s) => s.clearFilters);
  const [q, setQ] = useState("");
  const counts = useMemo(() => countFolders(comics), [comics]);
  const list = useMemo(() => {
    const nq = normalizeText(q);
    return folders.filter((x) => !nq || normalizeText(x.path).includes(nq));
  }, [folders, q]);
  const toggle = (p: string, kind: "in" | "ex") => {
    const r = toggleInEx(f.foldersIn, f.foldersEx, p, kind);
    setFilters({ foldersIn: r.inc, foldersEx: r.exc });
  };
  return (
    <DialogContent title="Filter by folder" description="Plus searches only inside, minus excludes. Author folders include everything below them." panel>
      <div className="border-b border-line p-4">
        <div className="relative">
          <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-sub" />
          <Input autoFocus value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search folders" className="pl-9" aria-label="Search folders" />
        </div>
      </div>
      <ul className="min-h-0 flex-1 overflow-y-auto">
        {list.map((x) => (
          <IncExRow key={x.path} icon={Folder} label={x.name} sub={x.parent ? x.parent : x.kind === "author" ? "Author folder" : undefined} indent={q ? 0 : x.path.split("/").length - 1} count={counts.get(x.path) ?? 0} inc={f.foldersIn.includes(x.path)} exc={f.foldersEx.includes(x.path)} onInc={() => toggle(x.path, "in")} onExc={() => toggle(x.path, "ex")} />
        ))}
        {!list.length && <li className="p-6 text-center text-[13px] text-sub">No folder matches "{q}".</li>}
      </ul>
      <div className="flex items-center justify-between gap-2 border-t border-line p-3">
        <Button variant="ghost" size="sm" onClick={() => setFilters({ foldersIn: [], foldersEx: [] })} disabled={!f.foldersIn.length && !f.foldersEx.length}>Clear folders</Button>
        <Button variant="ghost" size="sm" onClick={clearFilters}>Clear all</Button>
      </div>
    </DialogContent>
  );
}
