import { useMemo, useState } from "react";
import { CheckCheck, Folder, FolderPlus, Heart, Tag, X, FolderInput } from "lucide-react";
import { type ComicRecord, normalizeText, tagKey } from "@comiclib/shared";
import { api } from "@/lib/backend";
import { useStore } from "@/lib/store";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/controls";
import { cn } from "@/utils/cn";

export function TagEditor({ ids, onClose }: { ids: string[]; onClose: () => void }) {
  const comics = useStore((s) => s.comics);
  const defs = useStore((s) => s.tags);
  const editTags = useStore((s) => s.editTags);
  const targets = useMemo(() => comics.filter((c) => ids.includes(c.id)), [comics, ids]);
  const current = useMemo(() => {
    const m = new Map<string, { name: string; n: number }>();
    for (const c of targets) for (const t of c.tags) {
      const e = m.get(tagKey(t));
      if (e) e.n++;
      else m.set(tagKey(t), { name: t, n: 1 });
    }
    return [...m.values()];
  }, [targets]);
  const [adds, setAdds] = useState<string[]>([]);
  const [removes, setRemoves] = useState<string[]>([]);
  const [q, setQ] = useState("");
  const sugg = useMemo(() => {
    const nq = normalizeText(q);
    const taken = new Set([...adds, ...current.map((c) => c.name)].map(tagKey));
    return defs.filter((d) => !taken.has(tagKey(d.name)) && (!nq || normalizeText(d.name).includes(nq))).slice(0, 8);
  }, [defs, q, adds, current]);
  const add = (name: string) => {
    const t = name.trim();
    if (!t) return;
    setAdds((a) => (a.some((x) => tagKey(x) === tagKey(t)) ? a : [...a, t]));
    setRemoves((r) => r.filter((x) => tagKey(x) !== tagKey(t)));
    setQ("");
  };
  return (
    <Dialog open onOpenChange={(o) => !o && onClose()}>
      <DialogContent title={ids.length === 1 ? "Edit tags" : `Edit tags for ${ids.length} comics`} description={ids.length === 1 ? targets[0]?.name : "Added tags apply to every selected comic."} size="sm" zIndex={80}>
        <div className="flex min-h-0 flex-1 flex-col gap-4 overflow-y-auto p-5">
          <div>
            <div className="mb-2 text-[13px] font-medium">Current tags</div>
            <div className="flex flex-wrap gap-2">
              {current.length === 0 && <span className="text-[13px] text-sub">No tags yet.</span>}
              {current.map((t) => {
                const gone = removes.some((r) => tagKey(r) === tagKey(t.name));
                return (
                  <button key={t.name} onClick={() => setRemoves((r) => (gone ? r.filter((x) => tagKey(x) !== tagKey(t.name)) : [...r, t.name]))} aria-pressed={gone} className={cn("inline-flex h-8 items-center gap-1.5 rounded-md border px-2.5 text-[13px]", gone ? "border-line text-sub line-through" : "border-line bg-muted")}>
                    {t.name}
                    {ids.length > 1 && <span className="text-xs text-sub">{t.n}/{ids.length}</span>}
                    <X className="size-3.5" />
                  </button>
                );
              })}
            </div>
          </div>
          <div>
            <div className="mb-2 text-[13px] font-medium">Add tags</div>
            <form onSubmit={(e) => (e.preventDefault(), add(q))} className="flex gap-2">
              <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Type a tag and press Enter" aria-label="New tag" autoFocus />
              <Button type="submit" variant="secondary" disabled={!q.trim()}>Add</Button>
            </form>
            {sugg.length > 0 && (
              <div className="mt-2 flex flex-wrap gap-2" aria-label="Suggestions">
                {sugg.map((s) => <button key={s.name} onClick={() => add(s.name)} className="h-8 rounded-md border border-line px-2.5 text-[13px] hover:bg-muted">{s.name}</button>)}
              </div>
            )}
            {adds.length > 0 && (
              <div className="mt-3 flex flex-wrap gap-2">
                {adds.map((a) => <button key={a} onClick={() => setAdds(adds.filter((x) => x !== a))} className="inline-flex h-8 items-center gap-1.5 rounded-md border border-accent/40 bg-accent-soft px-2.5 text-[13px] text-accent">{a}<X className="size-3.5" /></button>)}
              </div>
            )}
          </div>
        </div>
        <div className="flex justify-end gap-2 border-t border-line p-3">
          <Button variant="ghost" onClick={onClose}>Cancel</Button>
          <Button disabled={!adds.length && !removes.length} onClick={() => (editTags(ids, adds, removes), onClose())}>Apply</Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

export function MoveDialog({ ids, onClose }: { ids: string[]; onClose: () => void }) {
  const folders = useStore((s) => s.folders);
  const refresh = useStore((s) => s.refresh);
  const toast = useStore((s) => s.toast);
  const [q, setQ] = useState("");
  const [dest, setDest] = useState<string | null>(null);
  const [name, setName] = useState("");
  const [busy, setBusy] = useState(false);
  const list = useMemo(() => folders.filter((f) => !q || normalizeText(f.path).includes(normalizeText(q))), [folders, q]);
  const run = async (target: string) => {
    setBusy(true);
    try {
      const res = await api.moveComics(ids, target);
      await refresh();
      const bad = res.filter((r) => !r.ok);
      if (bad.length) toast(`${bad.length} could not be moved: ${bad[0].error}`, "error");
      else toast(`Moved ${res.length} comic${res.length > 1 ? "s" : ""} and verified the result`);
      onClose();
    } catch (e) {
      toast((e as Error).message, "error");
    } finally {
      setBusy(false);
    }
  };
  const create = async () => {
    try {
      const p = await api.createFolder(dest ?? "", name.trim());
      await refresh();
      setDest(p);
      setName("");
    } catch (e) {
      toast((e as Error).message, "error");
    }
  };
  return (
    <Dialog open onOpenChange={(o) => !o && onClose()}>
      <DialogContent title={`Move ${ids.length} comic${ids.length > 1 ? "s" : ""}`} description="Files are moved on disk, then checked. Name clashes get a numeric suffix." size="sm" zIndex={80}>
        <div className="flex min-h-0 flex-1 flex-col">
          <div className="border-b border-line p-4"><Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search folders" aria-label="Search folders" /></div>
          <ul className="max-h-[40dvh] min-h-[160px] flex-1 overflow-y-auto">
            <li>
              <button onClick={() => setDest("")} className={cn("flex h-10 w-full items-center gap-2 px-4 text-left text-sm hover:bg-muted pointer-coarse:h-12", dest === "" && "bg-accent-soft text-accent")}><Folder className="size-4" />Mother folder (top level)</button>
            </li>
            {list.map((f) => (
              <li key={f.path}>
                <button onClick={() => setDest(f.path)} className={cn("flex h-10 w-full items-center gap-2 px-4 text-left text-sm hover:bg-muted pointer-coarse:h-12", dest === f.path && "bg-accent-soft text-accent")} style={{ paddingLeft: 16 + (q ? 0 : (f.path.split("/").length - 1) * 16) }}>
                  <Folder className="size-4 shrink-0" /><span className="truncate">{q ? f.path : f.name}</span>
                  {f.kind === "author" && <span className="ml-auto shrink-0 text-xs text-sub">Author</span>}
                </button>
              </li>
            ))}
          </ul>
          <div className="flex gap-2 border-t border-line p-3">
            <Input value={name} onChange={(e) => setName(e.target.value)} placeholder={dest ? `New folder inside ${dest}` : "New top-level folder"} aria-label="New folder name" />
            <Button variant="secondary" disabled={!name.trim()} onClick={() => void create()}><FolderPlus />Create</Button>
          </div>
        </div>
        <div className="flex justify-end gap-2 border-t border-line p-3">
          <Button variant="ghost" onClick={onClose}>Cancel</Button>
          <Button disabled={dest === null || busy} onClick={() => dest !== null && void run(dest)}>{busy ? "Moving" : "Move here"}</Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

export function BulkBar({ items }: { items: ComicRecord[] }) {
  const selected = useStore((s) => s.selected);
  const setSelected = useStore((s) => s.setSelected);
  const setSelectMode = useStore((s) => s.setSelectMode);
  const toggleFavorite = useStore((s) => s.toggleFavorite);
  const [tags, setTags] = useState(false);
  const [move, setMove] = useState(false);
  const ids = [...selected];
  return (
    <>
      <div className="safe-b flex items-center gap-2 border-t border-line bg-surface px-4 py-2 sm:px-6" role="toolbar" aria-label="Bulk actions">
        <Button variant="ghost" size="icon" aria-label="Exit select mode" onClick={() => setSelectMode(false)}><X /></Button>
        <span className="mr-auto text-sm tabular-nums"><b>{ids.length}</b> selected</span>
        <Button variant="ghost" size="sm" onClick={() => setSelected(items.map((c) => c.id))}><CheckCheck /><span className="hidden sm:inline">Select all {items.length}</span></Button>
        <Button variant="outline" size="sm" disabled={!ids.length} onClick={() => toggleFavorite(ids)}><Heart /><span className="hidden sm:inline">Favorite</span></Button>
        <Button variant="outline" size="sm" disabled={!ids.length} onClick={() => setTags(true)}><Tag /><span className="hidden sm:inline">Tags</span></Button>
        <Button variant="outline" size="sm" disabled={!ids.length} onClick={() => setMove(true)}><FolderInput /><span className="hidden sm:inline">Move</span></Button>
      </div>
      {tags && <TagEditor ids={ids} onClose={() => setTags(false)} />}
      {move && <MoveDialog ids={ids} onClose={() => setMove(false)} />}
    </>
  );
}
