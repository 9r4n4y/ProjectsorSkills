import { useCallback, useEffect, useState } from "react";
import { ClipboardCopy, HeartPulse, Play, Wrench } from "lucide-react";
import type { HealthReport } from "@comiclib/shared";
import { api } from "@/lib/backend";
import { useStore } from "@/lib/store";
import { Button } from "@/components/ui/button";
import { Badge, TriIcon } from "@/components/ui/controls";
import { Card, PageShell } from "@/components/PageShell";

export function Health() {
  const [report, setReport] = useState<HealthReport | null>(null);
  const [busy, setBusy] = useState<null | "check" | "repair">(null);
  const [open, setOpen] = useState<string | null>(null);
  const toast = useStore((s) => s.toast);
  const refresh = useStore((s) => s.refresh);

  const run = useCallback(
    async (repair: boolean) => {
      setBusy(repair ? "repair" : "check");
      try {
        const r = await api.runHealth(repair);
        setReport(r);
        if (repair) {
          await refresh();
          toast("Repair finished");
        }
      } catch (e) {
        toast((e as Error).message, "error");
      } finally {
        setBusy(null);
      }
    },
    [refresh, toast],
  );
  useEffect(() => void run(false), [run]);

  const worst = report?.checks.some((c) => c.status === "red") ? "red" : report?.checks.some((c) => c.status === "amber") ? "amber" : "green";
  const repairable = report?.checks.some((c) => c.repairable && c.status !== "green");
  const copy = async () => {
    const d = await api.diagnostics();
    const lines = report?.checks.map((c) => `- ${c.status.toUpperCase()} ${c.title}: ${c.summary}${c.details.length ? "\n    " + c.details.slice(0, 8).join("\n    ") : ""}`) ?? [];
    await api.copyText(`# Comic Library diagnostics\n\n${d}\n\n## Health checks\n${lines.join("\n")}\n\n## Repair log\n${(report?.log ?? []).join("\n") || "none"}\n`);
    toast("Diagnostics copied");
  };

  return (
    <PageShell
      title="Health"
      description="Checks the database, the library, thumbnails, manifests and metadata."
      actions={
        <>
          <Button variant="outline" onClick={() => void copy()}><ClipboardCopy /><span className="hidden sm:inline">Copy diagnostics</span></Button>
          <Button variant="outline" disabled={!!busy} onClick={() => void run(false)}><Play />Run checks</Button>
          <Button disabled={!!busy || !repairable} onClick={() => void run(true)}><Wrench />Repair all</Button>
        </>
      }
    >
      {report && (
        <div className="flex items-center gap-3 rounded-[20px] border-[2.5px] border-ink bg-surface px-4 py-3 shadow-[0_4px_0_var(--ink)]" role="status">
          <TriIcon tri={worst} className="size-6" />
          <div className="text-sm">
            <div className="font-medium">{worst === "green" ? "Everything is healthy" : worst === "amber" ? "Some items need attention" : "Problems found"}</div>
            <div className="text-[13px] text-sub">Last run {new Date(report.ranAt).toLocaleTimeString()}</div>
          </div>
        </div>
      )}
      {!report ? (
        <div className="flex flex-col gap-3" aria-busy="true">{[0, 1, 2, 3, 4].map((i) => <div key={i} className="skeleton h-16 rounded-lg" />)}</div>
      ) : (
        <Card>
          <ul className="-mx-4 -my-4 divide-y divide-line">
            {report.checks.map((c) => (
              <li key={c.id}>
                <button onClick={() => setOpen(open === c.id ? null : c.id)} aria-expanded={open === c.id} className="flex w-full items-center gap-3 px-4 py-3 text-left">
                  <TriIcon tri={c.status} />
                  <span className="min-w-0 flex-1">
                    <span className="block text-sm font-medium">{c.title}</span>
                    <span className="block truncate text-[13px] text-sub">{c.summary}</span>
                  </span>
                  {c.repairable && c.status !== "green" && <Badge tone="neutral">Repairable</Badge>}
                </button>
                {open === c.id && c.details.length > 0 && (
                  <ul className="mx-4 mb-3 max-h-48 overflow-y-auto rounded-md bg-muted p-3 font-mono text-xs">{c.details.map((d, i) => <li key={i} className="break-words">{d}</li>)}</ul>
                )}
              </li>
            ))}
          </ul>
        </Card>
      )}
      {report && report.log.length > 0 && (
        <Card title="Repair log">
          <ul className="flex flex-col gap-1 font-mono text-xs">{report.log.map((l, i) => <li key={i} className="break-words">{l}</li>)}</ul>
        </Card>
      )}
      {!report && busy === "check" && <p className="flex items-center gap-2 text-[13px] text-sub"><HeartPulse className="size-4" />Running checks</p>}
    </PageShell>
  );
}
