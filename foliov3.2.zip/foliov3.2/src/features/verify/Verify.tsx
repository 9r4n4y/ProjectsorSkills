import { useCallback, useEffect, useMemo, useState } from "react";
import { ChevronRight, ClipboardCopy, FolderOpen, KeyRound, RefreshCw, RotateCcw, ShieldCheck, SkipForward, Trash2, Undo2, CheckCheck, Wrench } from "lucide-react";
import { type DeletePreview, type FolderCheck, type SizeReport, type VerificationReport, formatBytes } from "@comiclib/shared";
import { api } from "@/lib/backend";
import { useStore } from "@/lib/store";
import { buildErrorReport } from "@/lib/report";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Badge, EmptyState, Input, LayerDot, LayerIcon, Segmented, TriIcon } from "@/components/ui/controls";
import { Card, PageShell, Stat } from "@/components/PageShell";
import { cn } from "@/utils/cn";

const isOk = (r: VerificationReport) => r.status === "green" || (r.manual && r.status === "amber");

export function Verify() {
  const [tab, setTab] = useState<"items" | "sizes" | "folders" | "trash">("items");
  return (
    <PageShell
      title="Verification centre"
      description="Ten checks run on every extraction. Green means all passed."
      actions={<Segmented label="Section" value={tab} onChange={setTab} options={[{ value: "items", label: "Items" }, { value: "sizes", label: "Sizes" }, { value: "folders", label: "Folders" }, { value: "trash", label: "Trash" }]} />}
    >
      {tab === "items" && <Items />}
      {tab === "sizes" && <Sizes />}
      {tab === "folders" && <Folders />}
      {tab === "trash" && <Trash />}
    </PageShell>
  );
}

function Items() {
  const reports = useStore((s) => s.reports);
  const archives = useStore((s) => s.archives);
  const info = useStore((s) => s.info);
  const toast = useStore((s) => s.toast);
  const refresh = useStore((s) => s.refresh);
  const [filter, setFilter] = useState<"all" | "attention" | "ok">("all");
  const [open, setOpen] = useState<string | null>(null);
  const [sel, setSel] = useState<Set<string>>(new Set());
  const [del, setDel] = useState(false);

  const aById = useMemo(() => new Map(archives.map((a) => [a.id, a])), [archives]);
  const rows = useMemo(() => reports.filter((r) => !aById.has(r.id) || ["done", "needs_password", "needs_input", "no_images", "failed", "quarantined", "skipped"].includes(aById.get(r.id)!.status)).sort((a, b) => ({ red: 0, amber: 1, green: 2 })[a.status] - ({ red: 0, amber: 1, green: 2 })[b.status] || a.subject.localeCompare(b.subject)), [reports, aById]);
  const shown = rows.filter((r) => (filter === "all" ? true : filter === "ok" ? isOk(r) : !isOk(r)));
  const extractedArchives = archives.filter((a) => a.status === "done").length;
  const verified = rows.filter(isOk).length;
  const failed = rows.filter((r) => r.status === "red" && !r.manual).length;
  const needs = rows.filter((r) => r.status === "amber" && !r.manual).length;
  const unprocessed = archives.filter((a) => ["pending", "queued", "extracting"].includes(a.status)).length;
  const allGreen = rows.length > 0 && rows.every(isOk) && unprocessed === 0;
  const selectable = shown.filter((r) => isOk(r) && aById.get(r.id)?.status === "done");

  const act = async (fn: () => Promise<unknown>, ok?: string) => {
    try {
      await fn();
      if (ok) toast(ok);
      await refresh();
    } catch (e) {
      toast((e as Error).message, "error");
    }
  };

  return (
    <>
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-5">
        <Stat label="Total archives" value={archives.length} />
        <Stat label="Extracted" value={extractedArchives} />
        <Stat label="Verified" value={verified} tone="ok" />
        <Stat label="Failed" value={failed} tone={failed ? "bad" : undefined} />
        <Stat label="Needs input" value={needs} tone={needs ? "warn" : undefined} />
      </div>

      {allGreen && (
        <div className="flex items-center gap-3 rounded-lg border border-ok/40 bg-ok-soft px-4 py-4 text-ok" role="status">
          <ShieldCheck className="size-6 shrink-0" />
          <div>
            <div className="text-[15px] font-semibold">100% verified</div>
            <div className="text-[13px]">Every extracted archive passed all ten checks. {rows.length} of {rows.length} are green.</div>
          </div>
        </div>
      )}

      {rows.length === 0 ? (
        <EmptyState icon={ShieldCheck} title="Nothing to verify yet" text="After you extract archives, each one appears here with the result of every check." />
      ) : (
        <Card
          title={`${shown.length} item${shown.length === 1 ? "" : "s"}`}
          actions={
            <div className="flex items-center gap-2">
              <Segmented label="Filter" value={filter} onChange={setFilter} options={[{ value: "all", label: "All" }, { value: "attention", label: "Attention" }, { value: "ok", label: "Verified" }]} />
            </div>
          }
        >
          <div className="-mx-4 -my-4 flex flex-col divide-y divide-line">
            {shown.map((r) => (
              <Row key={r.id} r={r} a={aById.get(r.id)} open={open === r.id} onToggle={() => setOpen(open === r.id ? null : r.id)} selectable={selectable.some((x) => x.id === r.id)} checked={sel.has(r.id)} onCheck={() => setSel((s) => { const n = new Set(s); n.has(r.id) ? n.delete(r.id) : n.add(r.id); return n; })} act={act} info={info} />
            ))}
          </div>
        </Card>
      )}

      {selectable.length > 0 && (
        <Card title="Delete extracted archives" actions={<Button variant="ghost" size="sm" onClick={() => setSel(new Set(selectable.map((r) => r.id)))}><CheckCheck />Select all green</Button>}>
          <p className="mb-3 text-[13px] text-sub">Only fully green archives can be selected. A fresh verification runs first, and archives move to a recoverable trash. Nothing is erased permanently here.</p>
          <Button variant="danger" disabled={sel.size === 0} onClick={() => setDel(true)}><Trash2 />Delete {sel.size} extracted archive{sel.size === 1 ? "" : "s"}</Button>
        </Card>
      )}
      {del && <DeleteFlow ids={[...sel]} onClose={(done) => { setDel(false); if (done) setSel(new Set()); }} />}
    </>
  );
}

function Row({ r, a, open, onToggle, selectable, checked, onCheck, act, info }: { r: VerificationReport; a?: ReturnType<typeof useStore.getState>["archives"][number]; open: boolean; onToggle: () => void; selectable: boolean; checked: boolean; onCheck: () => void; act: (fn: () => Promise<unknown>, ok?: string) => Promise<void>; info: ReturnType<typeof useStore.getState>["info"] }) {
  const [pw, setPw] = useState("");
  const [pwOpen, setPwOpen] = useState(false);
  const toast = useStore((s) => s.toast);
  const tri = r.manual && r.status === "amber" ? "green" : r.status;
  const copy = async () => {
    await api.copyText(buildErrorReport(r, a, info));
    toast("Error report copied. Paste it into an AI chat to get a fix.");
  };
  return (
    <div>
      <div className="flex items-center gap-3 px-4 py-3">
        {selectable ? <input type="checkbox" checked={checked} onChange={onCheck} aria-label={`Select ${r.subject} for deletion`} className="size-4 shrink-0 accent-[var(--accent)]" /> : <span className="size-4 shrink-0" />}
        <button onClick={onToggle} aria-expanded={open} className="flex min-w-0 flex-1 items-center gap-3 text-left">
          <TriIcon tri={tri} />
          <span className="min-w-0 flex-1">
            <span className="block truncate text-sm font-medium" title={r.subject}>{r.subject}</span>
            <span className="block truncate text-xs text-sub">{r.archiveRelPath || "Comic folder"}{r.archiveSize ? `  ·  ${formatBytes(r.archiveSize)}` : ""}</span>
          </span>
          <span className="hidden items-center gap-1 sm:flex" aria-label="Layer results">{r.layers.map((l) => <LayerDot key={l.layer} status={l.status} title={`${l.layer}. ${l.name}: ${l.summary}`} />)}</span>
          {r.manual && <Badge tone="neutral">Checked manually</Badge>}
          {r.status === "amber" && !r.manual && <Badge tone="warn">{r.state === "needs_password" ? "Password" : "Warning"}</Badge>}
          <ChevronRight className={cn("size-4 shrink-0 text-sub transition-transform duration-150", open && "rotate-90")} />
        </button>
      </div>
      {open && (
        <div className="flex flex-col gap-4 border-t border-line bg-bg px-4 py-4">
          {r.error && r.status !== "green" && (
            <div className="rounded-md border border-bad/30 bg-bad-soft p-3 text-[13px] text-bad">
              <div className="font-medium">Error</div>
              <div className="mt-1 break-words font-mono text-xs">{r.error}</div>
            </div>
          )}
          <ol className="flex flex-col gap-1.5">
            {r.layers.map((l) => (
              <li key={l.layer} className="flex gap-3 text-[13px]">
                <LayerIcon status={l.status} />
                <div className="min-w-0 flex-1">
                  <div><span className="tabular-nums text-sub">{l.layer}.</span> <span className="font-medium">{l.name}</span> <span className="text-sub">{l.summary}</span></div>
                  {l.details.length > 0 && l.status !== "pass" && <ul className="mt-1 max-h-40 overflow-y-auto rounded-sm bg-muted p-2 font-mono text-xs">{l.details.map((d, i) => <li key={i} className="break-words">{d}</li>)}</ul>}
                </div>
              </li>
            ))}
          </ol>
          {r.attempts.length > 0 && <div className="text-xs text-sub">Attempts: {r.attempts.map((t) => `#${t.n} ${t.engine} ${t.ok ? "ok" : "failed"}`).join(", ")}</div>}
          <div className="flex flex-wrap gap-2">
            {r.status !== "green" && <Button variant="outline" size="sm" onClick={() => void copy()}><ClipboardCopy />Copy error</Button>}
            {a && <Button variant="outline" size="sm" onClick={() => void act(() => api.extractArchives([a.id]), "Queued for retry")}><RotateCcw />Retry</Button>}
            {a && <Button variant="outline" size="sm" onClick={() => setPwOpen(!pwOpen)}><KeyRound />Retry with password</Button>}
            <Button variant="outline" size="sm" onClick={() => void act(() => api.reverify([r.id]), "Verification queued")}><RefreshCw />Re-verify</Button>
            {info?.platform !== "demo" && <Button variant="outline" size="sm" onClick={() => void api.openFolder(a ? { archiveId: a.id } : { comicId: r.comicIds[0] })}><FolderOpen />Open folder</Button>}
            {a && a.status !== "skipped" && <Button variant="outline" size="sm" onClick={() => void act(() => api.skipArchive(a.id), "Skipped")}><SkipForward />Skip</Button>}
            {r.status !== "green" && <Button variant={r.manual ? "secondary" : "outline"} size="sm" onClick={() => void act(() => api.markManual(r.id, !r.manual))}><CheckCheck />{r.manual ? "Unmark manual check" : "Mark as manually checked"}</Button>}
          </div>
          {pwOpen && a && (
            <form className="flex gap-2" onSubmit={(e) => { e.preventDefault(); void act(() => api.extractArchives([a.id], { password: pw }), "Queued with password"); setPw(""); setPwOpen(false); }}>
              <Input type="password" value={pw} onChange={(e) => setPw(e.target.value)} placeholder="Password" aria-label="Password" autoComplete="off" className="max-w-xs" />
              <Button type="submit" disabled={!pw}>Retry</Button>
            </form>
          )}
        </div>
      )}
    </div>
  );
}

function DeleteFlow({ ids, onClose }: { ids: string[]; onClose: (done: boolean) => void }) {
  const [pre, setPre] = useState<DeletePreview | null>(null);
  const [sure, setSure] = useState(false);
  const [busy, setBusy] = useState(false);
  const toast = useStore((s) => s.toast);
  const refresh = useStore((s) => s.refresh);
  useEffect(() => {
    let live = true;
    api.previewDelete(ids).then((p) => live && setPre(p)).catch((e) => live && setPre({ ok: false, archives: [], totalBytes: 0, failures: [{ id: "", name: "Verification", reason: (e as Error).message }] }));
    return () => { live = false; };
  }, [ids]);
  const go = async () => {
    setBusy(true);
    try {
      const r = await api.confirmDelete(pre!.archives.map((a) => a.id));
      await refresh();
      if (r.ok) toast(`${r.moved} archive${r.moved === 1 ? "" : "s"} moved to the trash. You can restore them from the Trash section.`);
      else toast(`Stopped: ${r.failures[0]?.reason}`, "error");
      onClose(r.ok);
    } catch (e) {
      toast((e as Error).message, "error");
      setBusy(false);
    }
  };
  return (
    <Dialog open onOpenChange={(o) => !o && !busy && onClose(false)}>
      <DialogContent title="Delete extracted archives" description="Final verification, then move to the recoverable trash." size="md">
        <div className="flex min-h-0 flex-1 flex-col gap-4 overflow-y-auto p-5">
          {!pre ? (
            <div className="flex flex-col gap-2" aria-busy="true"><div className="skeleton h-5 w-2/3 rounded-sm" /><div className="skeleton h-5 w-1/2 rounded-sm" /><p className="text-[13px] text-sub">Running a fresh verification of the extracted folders against the manifests and the archive contents.</p></div>
          ) : (
            <>
              {pre.failures.length > 0 && (
                <div className="rounded-md border border-bad/30 bg-bad-soft p-3 text-[13px] text-bad" role="alert">
                  <div className="font-medium">Verification failed. Nothing will be deleted.</div>
                  <ul className="mt-1 list-disc pl-5">{pre.failures.map((f) => <li key={f.id + f.name}><b>{f.name}</b>: {f.reason}</li>)}</ul>
                </div>
              )}
              {pre.archives.length > 0 && (
                <>
                  <div className="grid grid-cols-2 gap-3"><Stat label="Archives" value={pre.archives.length} /><Stat label="Space freed" value={formatBytes(pre.totalBytes)} /></div>
                  <ul className="max-h-56 divide-y divide-line overflow-y-auto rounded-md border border-line text-[13px]">
                    {pre.archives.map((a) => <li key={a.id} className="px-3 py-2"><div className="font-medium">{a.name} <span className="font-normal text-sub">{formatBytes(a.size)}</span></div><div className="truncate text-xs text-sub">Verified folders: {a.folders.join(", ") || "none"}</div></li>)}
                  </ul>
                  {pre.ok && <label className="flex items-start gap-2 text-[13px]"><input type="checkbox" checked={sure} onChange={(e) => setSure(e.target.checked)} className="mt-0.5 size-4 accent-[var(--accent)]" />I confirm. Archives move to the app trash, where they can be restored until the trash is emptied.</label>}
                </>
              )}
            </>
          )}
        </div>
        <div className="flex justify-end gap-2 border-t border-line p-3">
          <Button variant="ghost" onClick={() => onClose(false)} disabled={busy}>Cancel</Button>
          <Button variant="danger" disabled={!pre?.ok || !sure || busy} onClick={() => void go()}>{busy ? "Moving" : "Move to trash"}</Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

function Sizes() {
  const [r, setR] = useState<SizeReport | null>(null);
  const [err, setErr] = useState<string | null>(null);
  const load = useCallback(() => { setR(null); api.sizeReport().then(setR).catch((e) => setErr((e as Error).message)); }, []);
  useEffect(load, [load]);
  if (err) return <p className="text-sm text-bad">{err}</p>;
  if (!r) return <div className="grid grid-cols-2 gap-3 sm:grid-cols-4" aria-busy="true">{[0, 1, 2, 3].map((i) => <div key={i} className="skeleton h-20 rounded-lg" />)}</div>;
  return (
    <>
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        <Stat label="Mother folder" value={formatBytes(r.rootBytes)} />
        <Stat label="Archives" value={formatBytes(r.archiveBytes)} />
        <Stat label="Extracted comics" value={formatBytes(r.extractedBytes)} />
        <Stat label="Archives unpacked" value={formatBytes(r.archiveUncompressed)} />
      </div>
      <Card title="Per author folder" actions={<Button variant="ghost" size="sm" onClick={load}><RefreshCw />Refresh</Button>}>
        <div className="-mx-4 -my-4 overflow-x-auto"><table className="w-full min-w-max text-[13px] [&_td]:whitespace-nowrap [&_th]:whitespace-nowrap [&_tbody_tr:last-child]:border-b-0"><thead><tr className="border-b border-line text-left text-xs text-sub"><th className="px-4 py-2 font-medium">Folder</th><th className="px-4 py-2 text-right font-medium">Extracted</th><th className="px-4 py-2 text-right font-medium">Archives</th><th className="px-4 py-2 text-right font-medium">Archive size</th></tr></thead><tbody>
          {r.perFolder.map((f) => <tr key={f.folder} className="border-b border-line/60"><td className="px-4 py-2">{f.folder}</td><td className="px-4 py-2 text-right tabular-nums">{formatBytes(f.bytes)}</td><td className="px-4 py-2 text-right tabular-nums">{f.archives}</td><td className="px-4 py-2 text-right tabular-nums">{formatBytes(f.archiveBytes)}</td></tr>)}
        </tbody></table></div>
      </Card>
      <Card title="Archive uncompressed size versus extracted size">
        {r.comparisons.length === 0 ? <p className="text-[13px] text-sub">No extracted archives to compare yet.</p> : (
          <div className="-mx-4 -my-4 overflow-x-auto"><table className="w-full min-w-max text-[13px] [&_td]:whitespace-nowrap [&_th]:whitespace-nowrap [&_tbody_tr:last-child]:border-b-0"><thead><tr className="border-b border-line text-left text-xs text-sub"><th className="px-4 py-2 font-medium">Archive</th><th className="px-4 py-2 text-right font-medium">Uncompressed</th><th className="px-4 py-2 text-right font-medium">Extracted</th><th className="px-4 py-2 font-medium">Result</th></tr></thead><tbody>
            {r.comparisons.map((c) => <tr key={c.archive} className="border-b border-line/60"><td className="max-w-[240px] truncate px-4 py-2">{c.archive}</td><td className="px-4 py-2 text-right tabular-nums">{formatBytes(c.uncompressed)}</td><td className="px-4 py-2 text-right tabular-nums">{formatBytes(c.extracted)}</td><td className="px-4 py-2"><TriIcon tri={c.ok ? "green" : "amber"} /></td></tr>)}
          </tbody></table></div>
        )}
      </Card>
    </>
  );
}

function Folders() {
  const [r, setR] = useState<FolderCheck | null>(null);
  const [busy, setBusy] = useState(false);
  const refresh = useStore((s) => s.refresh);
  const toast = useStore((s) => s.toast);
  const load = useCallback(() => { setR(null); api.folderCheck().then(setR).catch((e) => toast((e as Error).message, "error")); }, [toast]);
  useEffect(load, [load]);
  if (!r) return <div className="skeleton h-40 rounded-lg" aria-busy="true" />;
  const ok = r.mismatches.length === 0;
  return (
    <>
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        <Stat label="Folders on disk" value={r.diskFolders} /><Stat label="Folders in library" value={r.libraryFolders} tone={r.diskFolders === r.libraryFolders ? "ok" : "warn"} />
        <Stat label="Comics on disk" value={r.diskComics} /><Stat label="Comics in library" value={r.libraryComics} tone={r.diskComics === r.libraryComics ? "ok" : "warn"} />
      </div>
      <Card title={ok ? "Library matches the disk" : `${r.mismatches.length} mismatch${r.mismatches.length === 1 ? "" : "es"}`} actions={!ok ? <Button size="sm" disabled={busy} onClick={async () => { setBusy(true); try { await api.fixFolders(); await refresh(); toast("Library rescanned and reconciled"); load(); } catch (e) { toast((e as Error).message, "error"); } setBusy(false); }}><Wrench />Fix</Button> : <TriIcon tri="green" />}>
        {ok ? <p className="text-[13px] text-sub">Every folder and comic found on disk is shown in the library, and nothing in the library is missing from disk.</p> : (
          <ul className="flex flex-col divide-y divide-line text-[13px]">{r.mismatches.slice(0, 100).map((m) => <li key={m.path + m.reason} className="py-2"><div className="break-words font-medium">{m.path}</div><div className="text-sub">{m.reason}</div></li>)}</ul>
        )}
      </Card>
    </>
  );
}

function Trash() {
  const trash = useStore((s) => s.trash);
  const refresh = useStore((s) => s.refresh);
  const toast = useStore((s) => s.toast);
  const [confirm, setConfirm] = useState(false);
  useEffect(() => { if (!confirm) return; const t = setTimeout(() => setConfirm(false), 5000); return () => clearTimeout(t); }, [confirm]);
  if (!trash.length) return <EmptyState icon={Trash2} title="Trash is empty" text="Archives you delete after verification wait here until you restore or permanently remove them." />;
  return (
    <Card title={`${trash.length} archive${trash.length === 1 ? "" : "s"} in trash · ${formatBytes(trash.reduce((s, t) => s + t.size, 0))}`} actions={
      confirm ? <Button variant="danger" size="sm" onClick={async () => { const n = await api.trashEmpty(); await refresh(); setConfirm(false); toast(`Permanently removed ${n} archive${n === 1 ? "" : "s"}`); }}>Confirm: remove permanently</Button> : <Button variant="outline" size="sm" onClick={() => setConfirm(true)}><Trash2 />Empty trash</Button>
    }>
      <ul className="-my-2 flex flex-col divide-y divide-line">
        {trash.map((t) => (
          <li key={t.id} className="flex items-center gap-3 py-3">
            <div className="min-w-0 flex-1"><div className="truncate text-sm font-medium">{t.name}</div><div className="truncate text-xs text-sub">{t.originalPath} · {formatBytes(t.size)} · {new Date(t.deletedAt).toLocaleString()}</div></div>
            <Button variant="outline" size="sm" onClick={async () => { try { await api.trashRestore(t.id); await refresh(); toast("Archive restored"); } catch (e) { toast((e as Error).message, "error"); } }}><Undo2 />Restore</Button>
          </li>
        ))}
      </ul>
    </Card>
  );
}
