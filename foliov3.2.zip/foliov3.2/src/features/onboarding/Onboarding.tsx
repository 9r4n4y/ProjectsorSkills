import { useState } from "react";
import { BatteryCharging, Bell, BookOpen, FolderOpen, HardDrive, Lock, Workflow } from "lucide-react";
import type { PermissionKind } from "@comiclib/shared";
import { api } from "@/lib/backend";
import { useStore } from "@/lib/store";
import { Button } from "@/components/ui/button";

const STEPS: { key: PermissionKind; icon: React.ElementType; title: string; body: string; allow: string }[] = [
  { key: "allFiles", icon: HardDrive, title: "Access to your comics", body: "Comic Library reads comics where they already are and extracts archives next to them. Nothing is copied or uploaded. Allow all files access, or skip and pick a folder with the system folder picker instead.", allow: "Allow all files access" },
  { key: "notifications", icon: Bell, title: "Progress notifications", body: "Long tasks such as extraction show a notification with progress, time left, and Pause and Cancel buttons. A summary appears when they finish.", allow: "Allow notifications" },
  { key: "foregroundService", icon: Workflow, title: "Background work", body: "A foreground service of type data sync keeps extraction and verification running when the screen is off or the app is closed. It stops when the work is done.", allow: "Continue" },
  { key: "wakeLock", icon: Lock, title: "Stay awake while working", body: "A wake lock keeps the processor running during a task so it is not interrupted. It is released as soon as the task finishes.", allow: "Continue" },
  { key: "batteryOptimization", icon: BatteryCharging, title: "Ignore battery optimization", body: "Some phones stop long background tasks to save power. Exempting this app lets big libraries finish extracting. You can change this later in settings.", allow: "Open battery settings" },
];

export function Welcome() {
  const info = useStore((s) => s.info);
  const refresh = useStore((s) => s.refresh);
  const set = useStore((s) => s.set);
  const toast = useStore((s) => s.toast);
  const [step, setStep] = useState(info?.needsOnboarding ? 0 : -1);
  const [busy, setBusy] = useState(false);

  const pick = async () => {
    setBusy(true);
    try {
      const p = await api.pickFolder();
      if (!p) return;
      set({ scanning: true });
      await api.setRoot(p);
      set({ root: p });
      await refresh();
      set({ scanning: false, info: info ? { ...info, root: p } : info });
    } catch (e) {
      set({ scanning: false });
      toast((e as Error).message, "error");
    } finally {
      setBusy(false);
    }
  };

  const cur = step >= 0 ? STEPS[step] : null;
  return (
    <div className="safe-t safe-b flex min-h-dvh items-center justify-center p-6">
      <div className="flex w-full max-w-md flex-col gap-6">
        <div className="flex items-center gap-3"><div className="flex size-11 items-center justify-center rounded-[14px] border-[2.5px] border-ink bg-butter text-on shadow-[0_4px_0_var(--ink)]"><BookOpen className="size-5" /></div><span className="font-display text-2xl font-extrabold leading-8">Comic Library</span></div>
        {cur ? (
          <div className="flex flex-col gap-5 rounded-[28px] border-[2.5px] border-ink bg-surface p-6 shadow-[0_6px_0_var(--ink)]" role="region" aria-label={`Permission ${step + 1} of ${STEPS.length}`}>
            <div className="flex items-center justify-between text-xs text-sub"><span>Step {step + 1} of {STEPS.length}</span><span className="flex gap-1">{STEPS.map((_, i) => <span key={i} className={`h-2.5 w-5 rounded-full border-2 ${i <= step ? "border-ink bg-peach" : "border-line bg-muted"}`} />)}</span></div>
            <div className="flex size-14 items-center justify-center rounded-[20px] border-[2.5px] border-ink bg-mint text-on shadow-[0_4px_0_var(--ink)]"><cur.icon className="size-6" /></div>
            <div><h1 className="font-display text-2xl font-extrabold leading-8">{cur.title}</h1><p className="mt-2 text-[13px] leading-5 text-sub">{cur.body}</p></div>
            <div className="flex flex-col gap-2">
              <Button size="lg" onClick={async () => { if (cur.key === "batteryOptimization") await api.openSystemSettings(cur.key); else await api.requestPermission(cur.key); step + 1 < STEPS.length ? setStep(step + 1) : setStep(-1); }}>{cur.allow}</Button>
              <Button variant="ghost" size="lg" onClick={() => (step + 1 < STEPS.length ? setStep(step + 1) : setStep(-1))}>{cur.key === "allFiles" ? "Skip and use the folder picker" : "Not now"}</Button>
            </div>
          </div>
        ) : (
          <div className="flex flex-col gap-5 rounded-[28px] border-[2.5px] border-ink bg-surface p-6 shadow-[0_6px_0_var(--ink)]">
            <div><h1 className="font-display text-2xl font-extrabold leading-8">Choose your comics folder</h1><p className="mt-2 text-[13px] leading-5 text-sub">Pick the one mother folder that holds your comics and archives. It is scanned recursively. Your files stay where they are, and the app works fully offline.</p></div>
            <Button size="lg" onClick={() => void pick()} disabled={busy}><FolderOpen />{busy ? "Scanning" : "Choose folder"}</Button>
            {info?.platform === "android" && <Button variant="ghost" onClick={() => setStep(0)}>Review permissions</Button>}
          </div>
        )}
      </div>
    </div>
  );
}
