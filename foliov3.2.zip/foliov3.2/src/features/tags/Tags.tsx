import { useMemo, useState } from "react";
import { Check, GitMerge, Pencil, Search, Tag as TagIcon, Trash2, X } from "lucide-react";
import { countTags, normalizeText, tagKey } from "@comiclib/shared";
import { useStore } from "@/lib/store";
import { Button } from "@/components/ui/button";
import { EmptyState, Input } from "@/components/ui/controls";
import { Card, PageShell } from "@/components/PageShell";

export function Tags() {
  const comics = useStore((s) => s.comics);
  const defs = useStore((s) => s.tags);
  const renameTag = useStore((s) => s.renameTag);
  const deleteTag = useStore((s) => s.deleteTag);
  const clearFilters = useStore((s) => s.clearFilters);
  const setFilters = useStore((s) => s.setFilters);
  const setScreen = useStore((s) => s.setScreen);
  const toast = useStore((s) => s.toast);
  const [q, setQ] = useState("");
  const [edit, setEdit] = useState<{ name: string; mode: "rename" | "merge" | "delete" } | null>(null);
  const [value, setValue] = useState("");

  const list = useMemo(() => {
    const counts = countTags(comics);
    const all = new Map<string, { name: string; count: number }>();
    for (const d of defs) all.set(tagKey(d.name), { name: d.name, count: counts.get(tagKey(d.name))?.count ?? 0 });
    for (const [k, v] of counts) all.set(k, v);
    const nq = normalizeText(q);
    return [...all.values()].filter((t) => !nq || normalizeText(t.name).includes(nq)).sort((a, b) => b.count - a.count || a.name.localeCompare(b.name));
  }, [comics, defs, q]);

  const show = (name: string) => {
    clearFilters();
    setFilters({ tagsIn: [name] });
    setScreen("library");
  };
  const commit = () => {
    if (!edit) return;
    if (edit.mode === "delete") {
      deleteTag(edit.name);
      toast(`Deleted tag "${edit.name}"`);
    } else if (value.trim()) {
      renameTag(edit.name, value.trim());
      toast(edit.mode === "merge" ? `Merged "${edit.name}" into "${value.trim()}"` : `Renamed to "${value.trim()}"`);
    }
    setEdit(null);
    setValue("");
  };

  return (
    <PageShell title="Tags" description={`${list.length} tags across ${comics.length.toLocaleString()} comics`}>
      <div className="relative max-w-md">
        <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-sub" />
        <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search tags" aria-label="Search tags" className="pl-9" />
      </div>
      {list.length === 0 ? (
        <EmptyState icon={TagIcon} title="No tags yet" text="Open any comic and choose the tag button to add one. Select several comics to tag them together." />
      ) : (
        <Card>
          <ul className="-mx-4 -my-4 divide-y divide-line">
            {list.map((t) => (
              <li key={t.name} className="flex flex-col gap-2 px-4 py-2.5">
                <div className="flex items-center gap-2">
                  <button onClick={() => show(t.name)} className="flex min-w-0 flex-1 items-center gap-3 text-left" title="Show comics with this tag">
                    <TagIcon className="size-4 shrink-0 text-sub" />
                    <span className="min-w-0 flex-1 truncate text-sm">{t.name}</span>
                    <span className="text-[13px] tabular-nums text-sub">{t.count}</span>
                  </button>
                  <Button variant="ghost" size="icon" aria-label={`Rename ${t.name}`} onClick={() => { setEdit({ name: t.name, mode: "rename" }); setValue(t.name); }}><Pencil /></Button>
                  <Button variant="ghost" size="icon" aria-label={`Merge ${t.name} into another tag`} onClick={() => { setEdit({ name: t.name, mode: "merge" }); setValue(""); }}><GitMerge /></Button>
                  <Button variant="ghost" size="icon" aria-label={`Delete ${t.name}`} onClick={() => setEdit({ name: t.name, mode: "delete" })}><Trash2 /></Button>
                </div>
                {edit?.name === t.name && (
                  <form className="flex flex-wrap items-center gap-2 pb-1" onSubmit={(e) => { e.preventDefault(); commit(); }}>
                    {edit.mode === "delete" ? (
                      <span className="text-[13px]">Remove "{t.name}" from {t.count} comic{t.count === 1 ? "" : "s"}? The comics are not touched.</span>
                    ) : (
                      <>
                        <Input autoFocus list={edit.mode === "merge" ? "merge-targets" : undefined} value={value} onChange={(e) => setValue(e.target.value)} placeholder={edit.mode === "merge" ? "Merge into tag" : "New name"} aria-label={edit.mode === "merge" ? "Target tag" : "New tag name"} className="max-w-xs" />
                        {edit.mode === "merge" && <datalist id="merge-targets">{list.filter((x) => x.name !== t.name).map((x) => <option key={x.name} value={x.name} />)}</datalist>}
                      </>
                    )}
                    <Button type="submit" size="sm" variant={edit.mode === "delete" ? "danger" : "default"}><Check />{edit.mode === "delete" ? "Delete" : edit.mode === "merge" ? "Merge" : "Rename"}</Button>
                    <Button type="button" size="sm" variant="ghost" onClick={() => setEdit(null)}><X />Cancel</Button>
                  </form>
                )}
              </li>
            ))}
          </ul>
        </Card>
      )}
    </PageShell>
  );
}
