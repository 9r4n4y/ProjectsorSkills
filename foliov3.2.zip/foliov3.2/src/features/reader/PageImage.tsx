import { useEffect, useState } from "react";
import { api } from "@/lib/backend";

/**
 * Page image with SAF resolution and automatic native-read fallback.
 * If Capacitor's local file server fails on Android (for example due to special characters
 * or scoped storage quirks), it automatically retries via the native readImage bridge.
 */
export function PageImage({
  url,
  fallbackUrl,
  className,
  lazy,
  onLoad,
  onFail,
  draggable = false,
}: {
  url: string;
  fallbackUrl?: string;
  className?: string;
  lazy?: boolean;
  onLoad?: (e: React.SyntheticEvent<HTMLImageElement>) => void;
  onFail?: () => void;
  draggable?: boolean;
}) {
  const [src, setSrc] = useState(url.startsWith("saf:") ? "" : url);
  const [triedFallback, setTriedFallback] = useState(false);
  const [failed, setFailed] = useState(false);

  useEffect(() => {
    setFailed(false);
    setTriedFallback(false);
    if (!url.startsWith("saf:")) {
      setSrc(url);
      return;
    }
    setSrc("");
    let live = true;
    void api
      .resolveImage(url)
      .then((s) => {
        if (!live) return;
        if (s) setSrc(s);
        else {
          setFailed(true);
          onFail?.();
        }
      })
      .catch(() => {
        if (!live) return;
        setFailed(true);
        onFail?.();
      });
    return () => {
      live = false;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [url]);

  const handleError = () => {
    if (!triedFallback && fallbackUrl && fallbackUrl !== url) {
      setTriedFallback(true);
      void api
        .resolveImage(fallbackUrl)
        .then((s) => {
          if (s) setSrc(s);
          else {
            setFailed(true);
            onFail?.();
          }
        })
        .catch(() => {
          setFailed(true);
          onFail?.();
        });
      return;
    }
    setFailed(true);
    onFail?.();
  };

  if (failed) return <div className="flex size-full min-h-[120px] items-center justify-center bg-muted px-3 text-center text-xs text-sub">Cannot load page</div>;
  if (!src) return <div className="skeleton size-full min-h-[120px]" />;
  return (
    <img
      src={src}
      alt=""
      loading={lazy ? "lazy" : undefined}
      decoding="async"
      draggable={draggable}
      onLoad={onLoad}
      onError={handleError}
      className={className}
    />
  );
}
