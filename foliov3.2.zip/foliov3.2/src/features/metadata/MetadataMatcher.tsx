import { useMemo, useState } from "react";
import { ArrowLeft, ArrowRight, CheckCircle2, FileUp, Pencil, Search, ShieldCheck, Sparkles, Undo2, Wand2, X } from "lucide-react";
import {
  type Candidate,
  type ComicRecord,
  type ComicStatePatch,
  type ImportReport,
  type MatchItem,
  type MetadataFile,
  autoAssign,
  buildPool,
  decryptSecret,
  mergeUserState,
  matchRecords,
  normalizeText,
  searchComics,
  suggestFor,
  validateMetadata,
} from "@comiclib/shared";
import { api } from "@/lib/backend";
import { useStore } from "@/lib/store";
import { Button } from "@/components/ui/button";
import { Badge, Input } from "@/components/ui/controls";
import { Card, PageShell, Stat } from "@/components/PageShell";
import { Pager } from "@/components/Pager";
import { cn } from "@/utils/cn";

type Source = "exact" | "auto" | "manual";
interface Pick {
  id: string;
  score: number;
  source: Source;
}
type Tab = "all" | "exact" | "auto" | "review" | "none";
const TABS: { key: Tab; label: string }[] = [
  { key: "all", label: "All" },
  { key: "exact", label: "Exact" },
  { key: "auto", label: "Auto" },
  { key: "review", label: "Review" },
  { key: "none", label: "Unmatched" },
];
const SURE = 0.8;

function ComicLine({ c, score, source }: { c: ComicRecord; score?: number; source?: Source }) {
  const has = c.tags.length > 0 || c.favorite || c.read;
  return (
    <div className="min-w-0">
      <div className="flex flex-wrap items-center gap-1.5">
        <span className="min-w-0 break-words text-sm font-bold">{c.name}</span>
        {source && score != null && <Badge tone={source === "manual" ? "accent" : score >= SURE ? "ok" : "warn"}>{source === "manual" ? "Manual" : `${Math.round(score * 100)}%`}</Badge>}
        {has && <Badge tone="warn">has data</Badge>}
      </div>
      <div className="break-all text-xs text-sub">{c.relPath}</div>
      <div className="text-xs text-sub">{c.pages} pages</div>
    </div>
  );
}

function Picker({ item, comics, pool, owner, onPick, onClose }: { item: MatchItem; comics: ComicRecord[]; pool: ReturnType<typeof buildPool>; owner: Map<string, number>; onPick: (id: string) => void; onClose: () => void }) {
  const [q, setQ] = useState("");
  const byId = useMemo(() => new Map(comics.map((c) => [c.id, c])), [comics]);
  const list: Candidate[] = useMemo(() => (q.trim() ? searchComics(q, pool, 12) : suggestFor(item.record, pool, undefined, 12)), [q, item, pool]);
  return (
    <div className="mt-3 flex flex-col gap-2 rounded-[18px] border-2 border-ink bg-muted p-3">
      <div className="flex items-center gap-2">
        <div className="relative min-w-0 flex-1">
          <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-sub" />
          <Input autoFocus value={q} onChange={(e) => setQ(e.target.value)} placeholder={`Search all comics (reference: ${item.record.name})`} aria-label="Search all comics" className="pl-9" />
        </div>
        <Button variant="ghost" size="icon" aria-label="Close search" onClick={onClose}><X /></Button>
      </div>
      <div className="text-xs text-sub">{q.trim() ? `Results for "${q}"` : "Closest comics to the original name"}</div>
      <ul className="flex max-h-72 flex-col divide-y divide-line overflow-y-auto rounded-[14px] border border-line bg-surface">
        {list.map((cand) => {
          const c = byId.get(cand.comicId)!;
          const o = owner.get(c.id);
          return (
            <li key={c.id}>
              <button onClick={() => onPick(c.id)} className="flex w-full items-start gap-3 p-3 text-left hover:bg-muted">
                <div className="min-w-0 flex-1"><ComicLine c={c} /></div>
                <div className="flex shrink-0 flex-col items-end gap-1"><Badge tone={cand.score >= SURE ? "ok" : "warn"}>{Math.round(cand.score * 100)}%</Badge>{o != null && o !== item.index && <span className="text-[11px] text-sub">used by another</span>}</div>
              </button>
            </li>
          );
        })}
        {!list.length && <li className="p-4 text-center text-[13px] text-sub">No comic found. Try other words.</li>}
      </ul>
    </div>
  );
}

export function MetadataMatcher() {
  const comics = useStore((s) => s.comics);
  const pageSize = useStore((s) => s.settings.pageSize) || 20;
  const refresh = useStore((s) => s.refresh);
  const setScreen = useStore((s) => s.setScreen);
  const toast = useStore((s) => s.toast);

  const [file, setFile] = useState<MetadataFile | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [matches, setMatches] = useState<MatchItem[]>([]);
  const [picks, setPicks] = useState<Record<number, Pick | null>>({});
  const [tab, setTab] = useState<Tab>("all");
  const [queries, setQueries] = useState<Record<Tab, string>>({ all: "", exact: "", auto: "", review: "", none: "" });
  const [page, setPage] = useState(0);
  const [open, setOpen] = useState<number | null>(null);
  const [pass, setPass] = useState("");
  const [busy, setBusy] = useState(false);
  const [done, setDone] = useState<{ report: ImportReport; skipped: MatchItem[]; undone: boolean } | null>(null);

  const pool = useMemo(() => buildPool(comics), [comics]);
  const byId = useMemo(() => new Map(comics.map((c) => [c.id, c])), [comics]);

  const runAuto = (ms: MatchItem[], keepManual: Record<number, Pick | null> = {}) => {
    const next: Record<number, Pick | null> = {};
    const taken = new Set<string>();
    for (const m of ms) {
      const k = keepManual[m.index];
      if (k?.source === "manual") (next[m.index] = k), taken.add(k.id);
      else if (m.comicId && (m.method === "path" || m.method === "fingerprint" || m.method === "name+pages")) (next[m.index] = { id: m.comicId, score: 1, source: "exact" }), taken.add(m.comicId);
    }
    const todo = ms.filter((m) => !next[m.index]).map((m) => ({ index: m.index, record: m.record }));
    const auto = autoAssign(todo, pool, taken);
    for (const t of todo) {
      const a = auto.get(t.index);
      next[t.index] = a ? { id: a.comicId, score: a.score, source: "auto" } : null;
    }
    setPicks(next);
  };

  const pick = async () => {
    const text = await api.pickTextFile();
    if (!text) return;
    const v = validateMetadata(text);
    if (!v.ok) return setError(`${v.error} (${v.stage})`);
    setError(null);
    const ms = matchRecords(v.file.data.comics, comics);
    setFile(v.file);
    setMatches(ms);
    setDone(null);
    setPage(0);
    runAuto(ms);
  };

  const owner = useMemo(() => {
    const o = new Map<string, number>();
    for (const [i, p] of Object.entries(picks)) if (p) o.set(p.id, +i);
    return o;
  }, [picks]);

  const assign = (index: number, id: string | null) => {
    setPicks((cur) => {
      const next = { ...cur };
      if (id) for (const [i, p] of Object.entries(next)) if (p?.id === id && +i !== index) next[+i] = null;
      const m = matches[index];
      const sc = id ? suggestFor(m.record, pool, undefined, 40).find((c) => c.comicId === id)?.score ?? 0.5 : 0;
      next[index] = id ? { id, score: sc, source: "manual" } : null;
      return next;
    });
    setOpen(null);
  };

  const kindOf = (m: MatchItem): Tab => {
    const p = picks[m.index];
    if (!p) return "none";
    if (p.source === "exact") return "exact";
    if (p.source === "auto" && p.score < SURE) return "review";
    return "auto";
  };

  const counts = useMemo(() => {
    const c: Record<Tab, number> = { all: matches.length, exact: 0, auto: 0, review: 0, none: 0 };
    for (const m of matches) c[kindOf(m)]++;
    return c;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [matches, picks]);

  const rows = useMemo(() => {
    const nq = normalizeText(queries[tab]);
    return matches.filter((m) => {
      if (tab !== "all" && kindOf(m) !== tab) return false;
      if (!nq) return true;
      const p = picks[m.index];
      const c = p ? byId.get(p.id) : undefined;
      return normalizeText(`${m.record.name} ${m.record.relPath} ${c?.name ?? ""} ${c?.relPath ?? ""}`).includes(nq);
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [matches, picks, tab, queries, byId]);

  const shown = rows.slice(page * pageSize, (page + 1) * pageSize);
  const applyCount = Object.values(picks).filter(Boolean).length;

  const apply = async () => {
    if (!file) return;
    setBusy(true);
    try {
      const patches: ComicStatePatch[] = [];
      const skipped: MatchItem[] = [];
      for (const m of matches) {
        const p = picks[m.index];
        const c = p ? byId.get(p.id) : undefined;
        if (!c) {
          skipped.push(m);
          continue;
        }
        const { id: _i, ...patch } = mergeUserState(c, m.record);
        patches.push({ id: c.id, ...patch });
      }
      let passwords: string[] | undefined;
      if (file.data.passwords && pass) passwords = JSON.parse(await decryptSecret(file.data.passwords, pass)) as string[];
      const report = await api.applyImport({ comics: patches, tagDefs: file.data.tags, settings: file.data.settings, passwords });
      await refresh();
      setDone({ report, skipped, undone: false });
    } catch (e) {
      toast(`Import stopped: ${(e as Error).message}`, "error");
    } finally {
      setBusy(false);
    }
  };

  const back = <Button variant="outline" onClick={() => setScreen("settings")}><ArrowLeft />Settings</Button>;

  return (
    <PageShell title="Match metadata" description="Pair every record in the file with a comic on this device" actions={back}>
      {!file && !done && (
        <Card title="Choose the metadata file">
          <div className="flex flex-col items-start gap-3 text-[13px]">
            <p className="text-sub">Exact matches (same path, fingerprint or name and pages) are found first. Everything else is paired automatically with the most similar comic that has no metadata yet. Then you can check and fix every single record before anything is changed.</p>
            {error && <div className="rounded-[14px] border-2 border-ink bg-peach p-3 text-on" role="alert">{error}</div>}
            <Button onClick={() => void pick()}><FileUp />Choose metadata file</Button>
          </div>
        </Card>
      )}

      {file && !done && (
        <>
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
            <Stat label="Exact" value={counts.exact} tone="ok" />
            <Stat label="Auto" value={counts.auto} tone="ok" />
            <Stat label="Review" value={counts.review} tone={counts.review ? "warn" : undefined} />
            <Stat label="Unmatched" value={counts.none} tone={counts.none ? "warn" : undefined} />
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <Button variant="outline" onClick={() => runAuto(matches, picks)}><Wand2 />Auto match again</Button>
            <Button variant="outline" onClick={() => { setPicks(Object.fromEntries(matches.map((m) => [m.index, null]))); }}>Clear all</Button>
            <Button variant="ghost" onClick={() => { setFile(null); setMatches([]); setPicks({}); }}>Other file</Button>
          </div>

          <Card title="Records">
            <div className="flex flex-col gap-3">
              <div className="flex gap-1.5 overflow-x-auto pb-1" role="tablist" aria-label="Match groups">
                {TABS.map((t) => (
                  <button key={t.key} role="tab" aria-selected={tab === t.key} onClick={() => { setTab(t.key); setPage(0); setOpen(null); }} className={cn("h-9 shrink-0 rounded-full border-2 px-3.5 text-[13px] font-bold", tab === t.key ? "border-ink bg-lilac text-on" : "border-line text-sub hover:bg-muted")}>
                    {t.label} <span className="tabular-nums">{counts[t.key]}</span>
                  </button>
                ))}
              </div>
              <div className="relative">
                <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-sub" />
                <Input value={queries[tab]} onChange={(e) => { setQueries({ ...queries, [tab]: e.target.value }); setPage(0); }} placeholder="Search this tab by original or matched name" aria-label="Search this tab" className="pl-9" />
              </div>
              <Pager page={page} total={rows.length} pageSize={pageSize} onChange={setPage} />
              <ul className="flex flex-col gap-3">
                {shown.map((m) => {
                  const p = picks[m.index];
                  const c = p ? byId.get(p.id) : undefined;
                  return (
                    <li key={m.index} className="rounded-[20px] border-2 border-ink bg-surface p-3">
                      <div className="grid gap-3 md:grid-cols-[1fr_auto_1fr] md:items-start">
                        <div className="min-w-0">
                          <div className="mb-1 text-[11px] font-bold uppercase tracking-wide text-sub">Original in file</div>
                          <div className="break-words text-sm font-bold">{m.record.name}</div>
                          <div className="break-all text-xs text-sub">{m.record.relPath}</div>
                          <div className="mt-1 flex flex-wrap gap-1">{m.record.tags.slice(0, 5).map((t) => <Badge key={t}>{t}</Badge>)}{m.record.tags.length > 5 && <Badge>+{m.record.tags.length - 5}</Badge>}{m.record.favorite && <Badge tone="accent">favorite</Badge>}</div>
                        </div>
                        <ArrowRight className="hidden size-5 text-sub md:mt-6 md:block" />
                        <div className="min-w-0">
                          <div className="mb-1 text-[11px] font-bold uppercase tracking-wide text-sub">Matched comic</div>
                          {c && p ? <ComicLine c={c} score={p.score} source={p.source} /> : <div className="text-sm text-sub">Not matched. Metadata will be skipped.</div>}
                        </div>
                      </div>
                      <div className="mt-3 flex flex-wrap gap-2">
                        <Button size="sm" variant="outline" onClick={() => setOpen(open === m.index ? null : m.index)}><Pencil />{c ? "Change" : "Search comic"}</Button>
                        {c && <Button size="sm" variant="ghost" onClick={() => assign(m.index, null)}>Skip</Button>}
                      </div>
                      {open === m.index && <Picker item={m} comics={comics} pool={pool} owner={owner} onPick={(id) => assign(m.index, id)} onClose={() => setOpen(null)} />}
                    </li>
                  );
                })}
                {!shown.length && <li className="p-6 text-center text-[13px] text-sub">Nothing here.</li>}
              </ul>
              <Pager page={page} total={rows.length} pageSize={pageSize} onChange={(p) => { setPage(p); }} />
            </div>
          </Card>

          <Card title="Apply">
            <div className="flex flex-col gap-3 text-[13px]">
              <p className="text-sub"><Sparkles className="mr-1 inline size-4" />{applyCount} of {matches.length} records will be applied. Tags are combined, favorites stay, the newest reading position wins. A backup is made first and you can undo.</p>
              {file.data.passwords && <Input type="password" value={pass} onChange={(e) => setPass(e.target.value)} placeholder="Passphrase to restore saved passwords (optional)" aria-label="Passphrase" className="max-w-sm" autoComplete="off" />}
              <div><Button disabled={busy || applyCount === 0} onClick={() => void apply()}><CheckCircle2 />{busy ? "Applying" : `Apply ${applyCount} records`}</Button></div>
            </div>
          </Card>
        </>
      )}

      {done && (
        <Card title="Import finished">
          <div className="flex flex-col gap-3 text-[13px]">
            <div className="flex items-center gap-2 text-ok"><ShieldCheck className="size-4" />{done.undone ? "Import undone. The previous database was restored." : `Applied ${done.report.applied} records in a single transaction.`}</div>
            <table className="w-full text-[13px]"><thead><tr className="border-b border-line text-left text-xs text-sub"><th className="py-2 font-medium">Count</th><th className="py-2 text-right font-medium">Before</th><th className="py-2 text-right font-medium">After</th></tr></thead><tbody>
              {(["comics", "tags", "favorites", "read"] as const).map((k) => <tr key={k} className="border-b border-line/60"><td className="py-2 capitalize">{k}</td><td className="py-2 text-right tabular-nums">{done.report.before[k]}</td><td className="py-2 text-right tabular-nums">{done.undone ? done.report.before[k] : done.report.after[k]}</td></tr>)}
            </tbody></table>
            {done.skipped.length > 0 && <div className="text-sub">{done.skipped.length} records were not applied.</div>}
            <div className="flex flex-wrap gap-2">
              {!done.undone && <Button variant="outline" onClick={async () => { await api.restoreBackup(done.report.backupId); await refresh(); setDone({ ...done, undone: true }); toast("Import undone"); }}><Undo2 />Undo import</Button>}
              <Button onClick={() => setScreen("settings")}>Done</Button>
            </div>
          </div>
        </Card>
      )}
    </PageShell>
  );
}
