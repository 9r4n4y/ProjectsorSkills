import { useMemo, useState } from "react";
import { Download, KeyRound, Pause, Play, RotateCcw, X, PackageOpen, TriangleAlert } from "lucide-react";
import { formatBytes, formatDuration, summarizeJobs, type ArchiveRecord } from "@comiclib/shared";
import { api } from "@/lib/backend";
import { useStore } from "@/lib/store";
import { Button } from "@/components/ui/button";
import { Badge, EmptyState, Input, Progress, Switch } from "@/components/ui/controls";
import { Card, PageShell, Stat } from "@/components/PageShell";

const STATUS: Record<string, { label: string; tone: "neutral" | "ok" | "warn" | "bad" | "accent" }> = {
  pending: { label: "Waiting", tone: "neutral" },
  queued: { label: "Queued", tone: "accent" },
  extracting: { label: "Extracting", tone: "accent" },
  verifying: { label: "Verifying", tone: "accent" },
  done: { label: "Extracted", tone: "ok" },
  needs_password: { label: "Password required", tone: "warn" },
  needs_input: { label: "Needs input", tone: "warn" },
  no_images: { label: "No images", tone: "warn" },
  failed: { label: "Failed", tone: "bad" },
  quarantined: { label: "Quarantined", tone: "bad" },
  skipped: { label: "Skipped", tone: "neutral" },
};

export function ArchiveStatusBadge({ a }: { a: ArchiveRecord }) {
  const s = STATUS[a.status] ?? STATUS.pending;
  return <Badge tone={s.tone}>{s.label}</Badge>;
}

export function Extract() {
  const archives = useStore((s) => s.archives);
  const jobs = useStore((s) => s.jobs);
  const settings = useStore((s) => s.settings);
  const setSettings = useStore((s) => s.setSettings);
  const toast = useStore((s) => s.toast);
  const refresh = useStore((s) => s.refresh);
  const info = useStore((s) => s.info);
  const [pw, setPw] = useState("");
  const [all, setAll] = useState(true);

  const by = useMemo(() => {
    const m: Record<string, ArchiveRecord[]> = {};
    for (const a of archives) (m[a.status] ??= []).push(a);
    return m;
  }, [archives]);
  const sum = summarizeJobs(jobs.jobs, "extract");
  const pending = by.pending ?? [];
  const needPw = by.needs_password ?? [];
  const needInput = by.needs_input ?? [];
  const running = jobs.jobs.filter((j) => j.group === "extract" && ["running", "queued", "paused"].includes(j.state));
  const finished = jobs.jobs.filter((j) => j.group === "extract" && ["failed", "cancelled"].includes(j.state)).slice(-6);
  const names = new Map(archives.map((a) => [a.id, a.name]));
  const nameOf = (j: { payload: unknown; title: string }) => names.get((j.payload as { archiveId?: string })?.archiveId ?? "") ?? j.title;

  const run = async (fn: () => Promise<unknown>) => {
    try {
      await fn();
      await refresh();
    } catch (e) {
      toast((e as Error).message, "error");
    }
  };

  return (
    <PageShell
      title="Extraction"
      description="Every archive extracts into its own folder, then every result is verified."
      actions={
        <>
          {jobs.paused ? <Button variant="outline" onClick={() => void api.jobControl("resume")}><Play />Resume</Button> : <Button variant="outline" disabled={!sum.active} onClick={() => void api.jobControl("pause")}><Pause />Pause</Button>}
          <Button variant="outline" disabled={!sum.active} onClick={() => void api.jobControl("cancel")}><X />Cancel all</Button>
        </>
      }
    >
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        <Stat label="Waiting" value={pending.length} />
        <Stat label="In progress" value={(by.queued?.length ?? 0) + (by.extracting?.length ?? 0)} />
        <Stat label="Extracted" value={by.done?.length ?? 0} tone="ok" />
        <Stat label="Need attention" value={needPw.length + needInput.length + (by.failed?.length ?? 0) + (by.quarantined?.length ?? 0) + (by.no_images?.length ?? 0)} tone={needPw.length + (by.failed?.length ?? 0) + (by.quarantined?.length ?? 0) ? "bad" : "warn"} />
      </div>

      {archives.length === 0 ? (
        <EmptyState icon={PackageOpen} title="No archives found" text="ZIP, 7Z, RAR, CBZ, CBR, CB7, TAR and split volumes inside your mother folder will be listed here automatically." />
      ) : (
        <Card>
          <div className="flex flex-col gap-4">
            <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
              <div>
                <div className="text-sm font-medium">{pending.length > 0 ? `${pending.length} archive${pending.length > 1 ? "s" : ""} ready to extract` : sum.active ? "Extraction in progress" : "Nothing waiting"}</div>
                <div className="text-[13px] text-sub">{formatBytes(pending.reduce((s, a) => s + a.size, 0))} of archives waiting. Originals are never modified.</div>
              </div>
              <Button size="lg" disabled={pending.length === 0} onClick={() => void run(() => api.extractAll())}><Download />Extract all</Button>
            </div>
            {(sum.active || sum.total > 0) && (
              <div className="flex flex-col gap-2" aria-live="polite">
                <Progress value={sum.fraction} label="Overall extraction progress" />
                <div className="flex flex-wrap justify-between gap-2 text-[13px] text-sub">
                  <span className="tabular-nums">{sum.done + sum.failed} of {sum.total} archives, {Math.round(sum.fraction * 100)}%</span>
                  <span className="tabular-nums">{sum.speed > 0 ? `${formatBytes(sum.speed)}/s` : "--"} · ETA {formatDuration(sum.etaSec)}</span>
                </div>
              </div>
            )}
            <div className="flex flex-wrap items-center gap-3 border-t border-line pt-4 text-[13px]">
              <label htmlFor="workers" className="text-sub">Parallel workers</label>
              <select id="workers" value={settings.workers} onChange={(e) => setSettings({ workers: +e.target.value })} className="h-9 rounded-md border border-line bg-surface px-2 pointer-coarse:h-11">
                <option value={0}>Automatic ({Math.max(1, Math.min(4, Math.floor((info?.env.cpus ?? 4) / 2)))})</option>
                {[1, 2, 3, 4, 6, 8].map((n) => <option key={n} value={n}>{n}</option>)}
              </select>
              <span className="ml-auto flex items-center gap-2 text-sub">If a folder already exists: <b className="text-fg">{settings.collision === "suffix" ? "add a number" : "ask me"}</b>
                <Switch label="Ask when the target folder exists" checked={settings.collision === "ask"} onCheckedChange={(v) => setSettings({ collision: v ? "ask" : "suffix" })} />
              </span>
            </div>
          </div>
        </Card>
      )}

      {needPw.length > 0 && (
        <Card title="Password required" actions={<Badge tone="warn">{needPw.length}</Badge>}>
          <p className="mb-3 text-[13px] text-sub">Saved passwords were tried first. Enter a password once; it can be tried on every archive that is waiting for one.</p>
          <ul className="mb-4 flex flex-col gap-1 text-[13px]">{needPw.slice(0, 6).map((a) => <li key={a.id} className="truncate">{a.relPath}</li>)}{needPw.length > 6 && <li className="text-sub">and {needPw.length - 6} more</li>}</ul>
          <form className="flex flex-col gap-3 sm:flex-row sm:items-center" onSubmit={(e) => { e.preventDefault(); void run(() => api.extractArchives(needPw.map((a) => a.id), { password: pw, applyToSimilar: all })); setPw(""); }}>
            <Input type="password" value={pw} onChange={(e) => setPw(e.target.value)} placeholder="Archive password" aria-label="Archive password" autoComplete="off" className="sm:max-w-xs" />
            <label className="flex items-center gap-2 text-[13px]"><input type="checkbox" checked={all} onChange={(e) => setAll(e.target.checked)} className="size-4 accent-[var(--accent)]" />Apply to all similar archives</label>
            <Button type="submit" disabled={!pw}><KeyRound />Try password</Button>
          </form>
        </Card>
      )}

      {needInput.length > 0 && (
        <Card title="Folder already exists" actions={<Badge tone="warn">{needInput.length}</Badge>}>
          <ul className="mb-3 flex flex-col gap-1 text-[13px]">{needInput.slice(0, 6).map((a) => <li key={a.id}><span className="font-medium">{a.name}</span> <span className="text-sub">{a.detail}</span></li>)}</ul>
          <Button onClick={() => { setSettings({ collision: "suffix" }); void run(() => api.extractArchives(needInput.map((a) => a.id))); }}>Extract with a numbered folder name</Button>
        </Card>
      )}

      {(running.length > 0 || finished.length > 0) && (
        <Card title="Queue">
          <ul className="flex flex-col divide-y divide-line">
            {[...running, ...finished].map((j) => (
              <li key={j.id} className="flex flex-col gap-2 py-3 first:pt-0 last:pb-0">
                <div className="flex items-center gap-3">
                  <div className="min-w-0 flex-1">
                    <div className="truncate text-sm font-medium" title={nameOf(j)}>{nameOf(j)}</div>
                    <div className="truncate text-[13px] text-sub">{j.state === "failed" ? j.error : j.message}</div>
                  </div>
                  <Badge tone={j.state === "running" ? "accent" : j.state === "failed" ? "bad" : "neutral"}>{j.state}</Badge>
                  {["failed", "cancelled"].includes(j.state) ? (
                    <Button variant="ghost" size="icon" aria-label="Retry" onClick={() => void api.jobControl("retry", j.id)}><RotateCcw /></Button>
                  ) : (
                    <Button variant="ghost" size="icon" aria-label="Cancel" onClick={() => void api.jobControl("cancel", j.id)}><X /></Button>
                  )}
                </div>
                {j.state === "running" && (
                  <>
                    <Progress value={j.progress} label={`Progress of ${nameOf(j)}`} />
                    <div className="flex justify-between text-xs tabular-nums text-sub"><span>{Math.round(j.progress * 100)}%</span><span>{j.speed > 0 ? `${formatBytes(j.speed)}/s` : ""} {j.etaSec != null ? `, ETA ${formatDuration(j.etaSec)}` : ""}</span></div>
                  </>
                )}
              </li>
            ))}
          </ul>
        </Card>
      )}

      {archives.length > 0 && (
        <Card title="Archives" actions={<span className="text-[13px] text-sub">{archives.length}</span>}>
          <ul className="flex flex-col divide-y divide-line">
            {archives.slice(0, 200).map((a) => (
              <li key={a.id} className="flex items-center gap-3 py-2.5 first:pt-0 last:pb-0">
                <div className="min-w-0 flex-1">
                  <div className="truncate text-sm" title={a.relPath}>{a.name}</div>
                  <div className="truncate text-xs text-sub">{a.folder || "Mother folder"} · {formatBytes(a.size)}{a.parts.length > 1 ? `, ${a.parts.length} volumes` : ""}</div>
                  {a.missingParts.length > 0 && <div className="mt-0.5 flex items-center gap-1 text-xs text-bad"><TriangleAlert className="size-3.5" />Missing: {a.missingParts.join(", ")}</div>}
                </div>
                <ArchiveStatusBadge a={a} />
              </li>
            ))}
          </ul>
          {archives.length > 200 && <p className="mt-3 text-[13px] text-sub">Showing the first 200 of {archives.length}. All are processed.</p>}
        </Card>
      )}
    </PageShell>
  );
}
