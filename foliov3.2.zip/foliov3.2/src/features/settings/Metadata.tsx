import { useMemo, useState } from "react";
import { FileDown, FileUp, ShieldCheck, Undo2 } from "lucide-react";
import {
  type ComicStatePatch,
  type ImportReport,
  type MatchItem,
  type MetadataFile,
  buildMetadata,
  decryptSecret,
  encryptSecret,
  matchRecords,
  mergeUserState,
  normalizeText,
  summarizeMatches,
  validateMetadata,
} from "@comiclib/shared";
import { api } from "@/lib/backend";
import { useStore } from "@/lib/store";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Badge, Input } from "@/components/ui/controls";
import { Stat } from "@/components/PageShell";

export function ExportDialog({ onClose }: { onClose: () => void }) {
  const comics = useStore((s) => s.comics);
  const tags = useStore((s) => s.tags);
  const settings = useStore((s) => s.settings);
  const toast = useStore((s) => s.toast);
  const [withPw, setWithPw] = useState(false);
  const [pass, setPass] = useState("");
  const [busy, setBusy] = useState(false);
  const go = async () => {
    setBusy(true);
    try {
      let blob;
      if (withPw) blob = await encryptSecret(JSON.stringify(await api.exportPasswords()), pass);
      const file = buildMetadata(comics, tags, settings, blob);
      const where = await api.saveTextFile(`comic-library-metadata-${new Date().toISOString().slice(0, 10)}.json`, JSON.stringify(file, null, 1));
      if (where) toast(`Exported ${comics.length} comics, ${tags.length} tags`);
      onClose();
    } catch (e) {
      toast((e as Error).message, "error");
      setBusy(false);
    }
  };
  return (
    <Dialog open onOpenChange={(o) => !o && onClose()}>
      <DialogContent title="Export metadata" description="One JSON file with tags, favorites, folders, reading progress, settings and fingerprints." size="sm">
        <div className="flex flex-col gap-4 p-5 text-[13px]">
          <p className="text-sub">{comics.length.toLocaleString()} comics and {tags.length} tags will be saved. Comic files are never included.</p>
          <label className="flex items-start gap-2"><input type="checkbox" checked={withPw} onChange={(e) => setWithPw(e.target.checked)} className="mt-0.5 size-4 accent-[var(--accent)]" />Include saved archive passwords, encrypted with a passphrase (off by default)</label>
          {withPw && <Input type="password" value={pass} onChange={(e) => setPass(e.target.value)} placeholder="Passphrase (needed to import them)" aria-label="Passphrase" autoComplete="new-password" />}
        </div>
        <div className="flex justify-end gap-2 border-t border-line p-3">
          <Button variant="ghost" onClick={onClose}>Cancel</Button>
          <Button disabled={busy || (withPw && pass.length < 4)} onClick={() => void go()}><FileDown />Export</Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

type Step = { s: "pick" } | { s: "error"; stage: string; error: string } | { s: "preview"; file: MetadataFile; matches: MatchItem[] } | { s: "done"; report: ImportReport; unmatched: MatchItem[]; undone: boolean };

export function ImportDialog({ onClose }: { onClose: () => void }) {
  const comics = useStore((s) => s.comics);
  const refresh = useStore((s) => s.refresh);
  const toast = useStore((s) => s.toast);
  const [step, setStep] = useState<Step>({ s: "pick" });
  const [choice, setChoice] = useState<Record<number, string>>({});
  const [pass, setPass] = useState("");
  const [busy, setBusy] = useState(false);
  const [q, setQ] = useState<Record<number, string>>({});

  const pick = async () => {
    const text = await api.pickTextFile();
    if (!text) return;
    const v = validateMetadata(text);
    if (!v.ok) return setStep({ s: "error", stage: v.stage, error: v.error });
    setStep({ s: "preview", file: v.file, matches: matchRecords(v.file.data.comics, comics) });
    setChoice({});
  };

  const apply = async () => {
    if (step.s !== "preview") return;
    setBusy(true);
    try {
      const byId = new Map(comics.map((c) => [c.id, c]));
      const patches: ComicStatePatch[] = [];
      const left: MatchItem[] = [];
      for (const m of step.matches) {
        const id = m.comicId ?? choice[m.index];
        const c = id ? byId.get(id) : undefined;
        if (!c) {
          left.push(m);
          continue;
        }
        const { id: _i, ...patch } = mergeUserState(c, m.record);
        patches.push({ id: c.id, ...patch });
      }
      let passwords: string[] | undefined;
      if (step.file.data.passwords && pass) passwords = JSON.parse(await decryptSecret(step.file.data.passwords, pass)) as string[];
      const report = await api.applyImport({ comics: patches, tagDefs: step.file.data.tags, settings: step.file.data.settings, passwords });
      await refresh();
      setStep({ s: "done", report, unmatched: left, undone: false });
    } catch (e) {
      toast(`Import stopped: ${(e as Error).message}`, "error");
    } finally {
      setBusy(false);
    }
  };

  const sum = useMemo(() => (step.s === "preview" ? summarizeMatches(step.matches) : null), [step]);
  const attention = step.s === "preview" ? step.matches.filter((m) => m.status === "ambiguous" || m.status === "unmatched") : [];
  const unresolved = attention.filter((m) => !choice[m.index]).length;

  return (
    <Dialog open onOpenChange={(o) => !o && onClose()}>
      <DialogContent title="Import metadata" description="Validate, preview, back up, apply, then reconcile. Nothing changes until you apply." size="lg">
        <div className="flex min-h-0 flex-1 flex-col gap-4 overflow-y-auto p-5">
          {step.s === "pick" && (
            <div className="flex flex-col items-start gap-3 text-[13px]">
              <p className="text-sub">Open the app on your mother folder, then choose the exported metadata file. Records are matched by relative path, then fingerprint, then name and page count, then fuzzy name, so moved and renamed comics are found.</p>
              <ol className="list-decimal pl-5 text-sub"><li>Schema and version check</li><li>Checksum check</li><li>Dry run preview</li><li>Automatic backup of the current database</li><li>Single transaction apply</li><li>Count reconciliation</li><li>Report of unmatched items</li><li>One-tap undo</li></ol>
              <Button onClick={() => void pick()}><FileUp />Choose metadata file</Button>
            </div>
          )}
          {step.s === "error" && (
            <div className="rounded-md border border-bad/30 bg-bad-soft p-3 text-[13px] text-bad" role="alert">
              <div className="font-medium">The file was rejected ({step.stage})</div>
              <div className="mt-1">{step.error}</div>
              <Button className="mt-3" variant="outline" size="sm" onClick={() => setStep({ s: "pick" })}>Choose another file</Button>
            </div>
          )}
          {step.s === "preview" && sum && (
            <>
              <div className="flex items-center gap-2 text-[13px] text-ok"><ShieldCheck className="size-4" />Schema, version and checksum are valid. This is a preview; nothing has been changed.</div>
              <div className="grid grid-cols-2 gap-3 sm:grid-cols-4"><Stat label="Matched" value={sum.matched} tone="ok" /><Stat label="Conflicting" value={sum.conflict} tone={sum.conflict ? "warn" : undefined} /><Stat label="Ambiguous" value={sum.ambiguous} tone={sum.ambiguous ? "warn" : undefined} /><Stat label="Unmatched" value={sum.unmatched} tone={sum.unmatched ? "warn" : undefined} /></div>
              <p className="text-[13px] text-sub">Conflicts are merged: tags are combined, a favorite stays a favorite, and the most recent reading position wins.</p>
              {step.file.data.passwords && <div className="flex items-center gap-2"><Input type="password" value={pass} onChange={(e) => setPass(e.target.value)} placeholder="Passphrase to restore saved passwords (optional)" aria-label="Passphrase" className="max-w-sm" autoComplete="off" /></div>}
              {attention.length > 0 && (
                <div>
                  <div className="mb-2 text-sm font-medium">Resolve manually ({unresolved} left, the rest are skipped)</div>
                  <ul className="max-h-72 divide-y divide-line overflow-y-auto rounded-md border border-line text-[13px]">
                    {attention.slice(0, 60).map((m) => {
                      const pool = m.status === "ambiguous" ? comics.filter((c) => m.candidates.includes(c.id)) : comics.filter((c) => q[m.index] && normalizeText(c.name).includes(normalizeText(q[m.index]))).slice(0, 6);
                      return (
                        <li key={m.index} className="flex flex-col gap-2 p-3">
                          <div className="flex items-center gap-2"><Badge tone="warn">{m.status}</Badge><span className="min-w-0 flex-1 truncate font-medium" title={m.record.relPath}>{m.record.name}</span></div>
                          {m.status === "unmatched" && <Input value={q[m.index] ?? ""} onChange={(e) => setQ({ ...q, [m.index]: e.target.value })} placeholder="Search for the matching comic" aria-label="Search for the matching comic" />}
                          <select value={choice[m.index] ?? ""} onChange={(e) => setChoice({ ...choice, [m.index]: e.target.value })} aria-label={`Match for ${m.record.name}`} className="h-9 rounded-md border border-line bg-surface px-2 pointer-coarse:h-11">
                            <option value="">Skip this record</option>
                            {pool.map((c) => <option key={c.id} value={c.id}>{c.relPath}</option>)}
                          </select>
                        </li>
                      );
                    })}
                  </ul>
                </div>
              )}
            </>
          )}
          {step.s === "done" && (
            <>
              <div className="flex items-center gap-2 text-[13px] text-ok"><ShieldCheck className="size-4" />{step.undone ? "Import undone. The previous database was restored." : `Applied ${step.report.applied} records in a single transaction.`}</div>
              <table className="w-full min-w-max text-[13px] [&_td]:whitespace-nowrap [&_th]:whitespace-nowrap [&_tbody_tr:last-child]:border-b-0"><thead><tr className="border-b border-line text-left text-xs text-sub"><th className="py-2 font-medium">Count</th><th className="py-2 text-right font-medium">Before</th><th className="py-2 text-right font-medium">After</th></tr></thead><tbody>
                {(["comics", "tags", "favorites", "read"] as const).map((k) => <tr key={k} className="border-b border-line/60"><td className="py-2 capitalize">{k}</td><td className="py-2 text-right tabular-nums">{step.report.before[k]}</td><td className="py-2 text-right tabular-nums">{step.undone ? step.report.before[k] : step.report.after[k]}</td></tr>)}
              </tbody></table>
              <div className="text-[13px] text-sub">Backup: {step.report.backupId}</div>
              {step.unmatched.length > 0 && (
                <div><div className="mb-1 text-sm font-medium">{step.unmatched.length} record{step.unmatched.length === 1 ? "" : "s"} not applied</div>
                  <ul className="max-h-40 overflow-y-auto rounded-md bg-muted p-3 font-mono text-xs">{step.unmatched.slice(0, 100).map((m) => <li key={m.index} className="break-words">{m.record.relPath} ({m.status})</li>)}</ul></div>
              )}
            </>
          )}
        </div>
        <div className="flex justify-end gap-2 border-t border-line p-3">
          {step.s === "done" && !step.undone && <Button variant="outline" onClick={async () => { await api.restoreBackup(step.report.backupId); await refresh(); setStep({ ...step, undone: true }); toast("Import undone"); }}><Undo2 />Undo import</Button>}
          <Button variant="ghost" onClick={onClose}>{step.s === "done" ? "Close" : "Cancel"}</Button>
          {step.s === "preview" && <Button disabled={busy || (sum?.matched ?? 0) + (sum?.conflict ?? 0) + Object.values(choice).filter(Boolean).length === 0} onClick={() => void apply()}>{busy ? "Applying" : "Apply import"}</Button>}
        </div>
      </DialogContent>
    </Dialog>
  );
}
