import { Component, type ReactNode, useEffect, useState } from "react";
import { AnimatePresence, motion } from "motion/react";
import { Activity, Download, Library as LibraryIcon, Settings as SettingsIcon, ShieldCheck, ShieldAlert, TriangleAlert } from "lucide-react";
import { formatDuration, summarizeJobs, type PermissionStatus } from "@comiclib/shared";
import { api } from "@/lib/backend";
import { useStore, type Screen } from "@/lib/store";
import { useIsMobile } from "@/lib/hooks";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/controls";
import { Library } from "@/features/library/Library";
import { QuickLook } from "@/features/library/QuickLook";
import { FilterPanels } from "@/features/library/FilterPanels";
import { EdgePanel, EdgePanelHandle } from "@/features/library/Sidebar";
import { Reader } from "@/features/reader/Reader";
import { Extract } from "@/features/extract/Extract";
import { Verify } from "@/features/verify/Verify";
import { Tags } from "@/features/tags/Tags";
import { Health } from "@/features/health/Health";
import { Settings } from "@/features/settings/Settings";
import { MetadataMatcher } from "@/features/metadata/MetadataMatcher";
import { Welcome } from "@/features/onboarding/Onboarding";
import { cn } from "@/utils/cn";

class OverlayErrorBoundary extends Component<{ onReset: () => void; label: string; children: ReactNode }, { err: Error | null }> {
  state: { err: Error | null } = { err: null };
  static getDerivedStateFromError(err: Error) {
    return { err };
  }
  componentDidCatch(err: Error) {
    console.error(`[${this.props.label}]`, err);
  }
  render() {
    if (this.state.err) {
      return (
        <div className="fixed inset-0 z-[70] flex items-center justify-center bg-[#140f32]/75 p-4 backdrop-blur-sm" role="alertdialog" aria-label={`${this.props.label} error`}>
          <div className="flex w-full max-w-sm flex-col gap-3 rounded-[24px] border-[2.5px] border-ink bg-surface p-5 text-fg shadow-[0_6px_0_var(--ink)]">
            <div className="font-display text-lg">Could not open comic</div>
            <p className="text-[13px] text-sub">{this.state.err.message || "Something went wrong while opening this comic."}</p>
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => { this.setState({ err: null }); this.props.onReset(); }}>Close</Button>
              <Button onClick={() => this.setState({ err: null })}>Try again</Button>
            </div>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

const BOTTOM: { screen: Screen; label: string; icon: React.ElementType }[] = [
  { screen: "library", label: "Library", icon: LibraryIcon },
  { screen: "extract", label: "Extract", icon: Download },
  { screen: "verify", label: "Verify", icon: ShieldCheck },
  { screen: "health", label: "Health", icon: Activity },
  { screen: "settings", label: "Settings", icon: SettingsIcon },
];

function Toasts() {
  const toasts = useStore((s) => s.toasts);
  return (
    <div className="pointer-events-none fixed inset-x-0 bottom-20 z-[100] flex flex-col items-center gap-2 px-4 md:bottom-6" aria-live="polite">
      <AnimatePresence>
        {toasts.map((t) => (
          <motion.div key={t.id} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} transition={{ duration: 0.18 }} className={cn("pointer-events-auto max-w-md rounded-full border-[2.5px] px-5 py-2.5 text-[13px] font-bold", t.kind === "error" ? "border-ink bg-peach text-on" : "border-ink bg-fg text-surface")} role={t.kind === "error" ? "alert" : "status"}>
            {t.text}
          </motion.div>
        ))}
      </AnimatePresence>
    </div>
  );
}

function ActivityStrip() {
  const jobs = useStore((s) => s.jobs);
  const setScreen = useStore((s) => s.setScreen);
  const screen = useStore((s) => s.screen);
  const work = jobs.jobs.filter((j) => j.state === "running" || j.state === "queued" || j.state === "paused");
  if (!work.length || screen === "extract") return null;
  const s = summarizeJobs(jobs.jobs.filter((j) => j.group === "extract" || j.group === "verify" || j.group === "scan"));
  const cur = work.find((j) => j.state === "running") ?? work[0];
  return (
    <button onClick={() => setScreen(cur.group === "extract" ? "extract" : "verify")} className="flex items-center gap-3 border-b border-line bg-surface px-4 py-2 text-left text-[13px] sm:px-6" aria-label="Show running tasks">
      <span className="min-w-0 flex-1 truncate">{jobs.paused ? "Paused" : cur.group === "scan" ? "Scanning" : cur.title}<span className="text-sub"> · {work.length} task{work.length > 1 ? "s" : ""} left{s.etaSec != null ? `, ETA ${formatDuration(s.etaSec)}` : ""}</span></span>
      <Progress value={s.fraction || cur.progress} className="w-24 shrink-0 sm:w-40" label="Task progress" />
    </button>
  );
}

export default function App() {
  const ready = useStore((s) => s.ready);
  const error = useStore((s) => s.error);
  const root = useStore((s) => s.root);
  const screen = useStore((s) => s.screen);
  const setScreen = useStore((s) => s.setScreen);
  const info = useStore((s) => s.info);
  const boot = useStore((s) => s.boot);
  const closeQuick = useStore((s) => s.closeQuick);
  const closeReader = useStore((s) => s.closeReader);
  const mobile = useIsMobile();
  const [perms, setPerms] = useState<PermissionStatus | null>(null);

  useEffect(() => void boot(), [boot]);

  // detect permissions that were denied later and guide the user back to settings
  useEffect(() => {
    if (info?.platform !== "android") return;
    const check = () => void api.getPermissions().then(setPerms);
    check();
    document.addEventListener("visibilitychange", check);
    return () => document.removeEventListener("visibilitychange", check);
  }, [info?.platform]);

  if (!ready) return <div className="flex min-h-dvh items-center justify-center text-sm text-sub" aria-busy="true">Starting</div>;
  if (error) return <div className="flex min-h-dvh items-center justify-center p-6 text-center text-sm text-bad" role="alert">Could not start: {error}</div>;
  if (!root) return <><Welcome /><Toasts /></>;

  const denied = perms && (perms.allFiles === "denied" || perms.notifications === "denied") && perms.safFolder !== "granted";

  return (
    <div className="flex h-full w-full min-w-0 flex-row overflow-hidden text-fg">
      <main className="flex min-h-0 min-w-0 flex-1 flex-col">
        {info?.demo && (
          <div className="flex items-center gap-2 border-b border-line bg-accent-soft px-4 py-1.5 text-xs text-accent sm:px-6">
            <TriangleAlert className="size-3.5 shrink-0" />Browser preview with a generated sample library. Install the PC or Android build to use your own comics.
          </div>
        )}
        {denied && (
          <button onClick={() => setScreen("settings")} className="flex items-center gap-2 border-b border-warn/30 bg-warn-soft px-4 py-2 text-left text-[13px] text-warn sm:px-6">
            <ShieldAlert className="size-4 shrink-0" />A permission was turned off. Open settings to allow it again so background work keeps running.
          </button>
        )}
        <ActivityStrip />
        <div className="min-h-0 flex-1">
          <div className={screen === "library" ? "h-full" : "hidden"}><Library /></div>
          {screen === "tags" && <Tags />}
          {screen === "extract" && <Extract />}
          {screen === "verify" && <Verify />}
          {screen === "health" && <Health />}
          {screen === "settings" && <Settings />}
          {screen === "metadata" && <MetadataMatcher />}
        </div>
        {mobile && (
          <nav className="safe-b flex shrink-0 border-t-[2.5px] border-ink bg-surface" aria-label="Sections">
            {BOTTOM.map((b) => {
              const active = screen === b.screen || (b.screen === "library" && screen === "tags");
              return (
                <button key={b.screen} onClick={() => setScreen(b.screen)} aria-current={active ? "page" : undefined} className={cn("group flex h-16 min-w-0 flex-1 flex-col items-center justify-center gap-0.5 text-[11px] font-bold", active ? "text-fg" : "text-sub")}>
                  <span className={cn("flex h-8 w-14 items-center justify-center rounded-full border-[2.5px] transition-[background-color,transform] duration-500 ease-spring group-active:scale-90", active ? "-translate-y-0.5 border-ink bg-lilac text-on shadow-[0_3px_0_var(--ink)]" : "border-transparent")}><b.icon className="size-5" /></span>{b.label}
                </button>
              );
            })}
          </nav>
        )}
      </main>
      <EdgePanelHandle />
      <EdgePanel />
      <FilterPanels />
      <OverlayErrorBoundary label="QuickLook" onReset={closeQuick}>
        <QuickLook />
      </OverlayErrorBoundary>
      <OverlayErrorBoundary label="Reader" onReset={closeReader}>
        <Reader />
      </OverlayErrorBoundary>
      <Toasts />
    </div>
  );
}
