// Versioned SQLite schema shared by better-sqlite3 (PC) and the native Android plugin.
// The Android build copies this list into an asset (scripts/prepare-android.mjs), so there is one source of truth.

export interface Migration {
  version: number;
  name: string;
  sql: string;
  /**
   * Android only: used instead of `sql` when the platform SQLite has no FTS5 module (the stock Android SQLite
   * often lacks it). Required for every migration whose `sql` mentions fts5, enforced by tests/schema-android.test.ts.
   */
  sqlNoFts5?: string;
}

/** FTS4 equivalent of the FTS5 comic_fts table. notindexed needs SQLite 3.8.0, unicode61 3.7.13; API 23 ships 3.8.10. */
export const COMIC_FTS4_DDL = `CREATE VIRTUAL TABLE comic_fts USING fts4(comic_id, name, folder, author, tags, notindexed=comic_id, tokenize=unicode61 "remove_diacritics=1")`;

export const PRAGMAS = ["PRAGMA journal_mode = WAL", "PRAGMA synchronous = NORMAL", "PRAGMA foreign_keys = ON"];

const V1_TABLES = `
CREATE TABLE meta (key TEXT PRIMARY KEY, value TEXT);
CREATE TABLE comics (
  id TEXT PRIMARY KEY,
  rel_path TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  folder TEXT NOT NULL,
  author TEXT NOT NULL,
  pages INTEGER NOT NULL,
  size INTEGER NOT NULL,
  mtime INTEGER NOT NULL,
  added_at INTEGER NOT NULL,
  favorite INTEGER NOT NULL DEFAULT 0,
  read INTEGER NOT NULL DEFAULT 0,
  last_page INTEGER NOT NULL DEFAULT 0,
  last_read_at INTEGER NOT NULL DEFAULT 0,
  fingerprint TEXT,
  thumb_rev INTEGER NOT NULL DEFAULT 0,
  verification TEXT
);
CREATE TABLE tags (name TEXT PRIMARY KEY COLLATE NOCASE, color TEXT);
CREATE TABLE comic_tags (
  comic_id TEXT NOT NULL REFERENCES comics(id) ON DELETE CASCADE,
  tag TEXT NOT NULL COLLATE NOCASE,
  PRIMARY KEY (comic_id, tag)
);
CREATE TABLE folders (path TEXT PRIMARY KEY, name TEXT NOT NULL, parent TEXT NOT NULL, kind TEXT NOT NULL, comics INTEGER NOT NULL, size INTEGER NOT NULL);
CREATE TABLE archives (
  id TEXT PRIMARY KEY,
  rel_path TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  folder TEXT NOT NULL,
  author TEXT NOT NULL,
  size INTEGER NOT NULL,
  parts TEXT NOT NULL,
  missing TEXT NOT NULL,
  encrypted INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL,
  target_name TEXT NOT NULL,
  uncompressed INTEGER,
  detail TEXT
);
CREATE TABLE reports (id TEXT PRIMARY KEY, json TEXT NOT NULL, updated_at INTEGER NOT NULL);
CREATE TABLE jobs (id TEXT PRIMARY KEY, json TEXT NOT NULL, updated_at INTEGER NOT NULL);
CREATE TABLE passwords (id TEXT PRIMARY KEY, label TEXT NOT NULL, blob TEXT NOT NULL);
CREATE TABLE trash (id TEXT PRIMARY KEY, name TEXT NOT NULL, original_path TEXT NOT NULL, trash_path TEXT NOT NULL, size INTEGER NOT NULL, deleted_at INTEGER NOT NULL);
CREATE TABLE deletion_log (id INTEGER PRIMARY KEY AUTOINCREMENT, at INTEGER NOT NULL, action TEXT NOT NULL, path TEXT NOT NULL, detail TEXT);
CREATE TABLE settings (key TEXT PRIMARY KEY, value TEXT NOT NULL);
`;

export const MIGRATIONS: Migration[] = [
  {
    version: 1,
    name: "initial schema",
    sql: `${V1_TABLES}CREATE VIRTUAL TABLE comic_fts USING fts5(comic_id UNINDEXED, name, folder, author, tags, tokenize = 'unicode61 remove_diacritics 2');
`,
    sqlNoFts5: `${V1_TABLES}${COMIC_FTS4_DDL};
`,
  },
  {
    version: 2,
    name: "indexes for sorting and lookups",
    sql: `
CREATE INDEX idx_comics_folder ON comics(folder);
CREATE INDEX idx_comics_author ON comics(author);
CREATE INDEX idx_comics_last_read ON comics(last_read_at);
CREATE INDEX idx_comic_tags_tag ON comic_tags(tag);
CREATE INDEX idx_archives_status ON archives(status);
`,
  },
];

export const SCHEMA_VERSION = MIGRATIONS[MIGRATIONS.length - 1].version;
