import { boundedDistance, posixBasename, stem, tokenize } from "./text";

export interface SearchDoc {
  id: string;
  name: string;
  folder: string;
  author: string;
  tags: string[];
}

const W_NAME = 3;
const W_TAG = 2;
const W_AUTHOR = 1.5;
const W_FOLDER = 1.2;

const S_EXACT = 100;
const S_PREFIX = 70;
const S_STEM = 50;
const S_FUZZY = 20;

/**
 * In-memory inverted index. Ranking: exact token, then prefix, then stem, then fuzzy.
 * All query tokens must match (AND). Built for 10,000+ documents with sub-100 ms queries.
 */
export class SearchIndex {
  private ids: string[] = [];
  private raw = new Map<string, Map<number, number>>();
  private stems = new Map<string, Map<number, number>>();
  private rawVocab: string[] = [];
  private stemVocab: string[] = [];
  private normNames: string[] = [];

  build(docs: readonly SearchDoc[]): void {
    this.ids = docs.map((d) => d.id);
    this.raw = new Map();
    this.stems = new Map();
    this.normNames = [];
    docs.forEach((d, i) => {
      this.addField(i, d.name, W_NAME);
      this.addField(i, posixBasename(d.folder), W_FOLDER);
      this.addField(i, d.author, W_AUTHOR);
      for (const t of d.tags) this.addField(i, t, W_TAG);
      this.normNames.push(tokenize(d.name).join(" "));
    });
    this.rawVocab = [...this.raw.keys()].sort();
    this.stemVocab = [...this.stems.keys()];
  }

  get size(): number {
    return this.ids.length;
  }

  private addField(doc: number, text: string, weight: number): void {
    for (const t of tokenize(text)) {
      put(this.raw, t, doc, weight);
      put(this.stems, stem(t), doc, weight);
    }
  }

  /** Returns matching ids ranked best first. Empty query returns null (no text filter). */
  search(query: string): string[] | null {
    const tokens = tokenize(query);
    if (!tokens.length) return null;
    let acc: Map<number, number> | null = null;
    for (const q of tokens) {
      const m = this.matchToken(q);
      if (acc === null) {
        acc = m;
      } else {
        const next = new Map<number, number>();
        for (const [d, s] of m) {
          const prev = acc.get(d);
          if (prev !== undefined) next.set(d, prev + s);
        }
        acc = next;
      }
      if (acc.size === 0) return [];
    }
    const phrase = tokens.join(" ");
    const scored: [number, number][] = [];
    for (const [d, s] of acc!) {
      let bonus = 0;
      const nm = this.normNames[d];
      if (nm === phrase) bonus = 80;
      else if (nm.startsWith(phrase)) bonus = 30;
      else if (nm.includes(phrase)) bonus = 10;
      scored.push([d, s + bonus]);
    }
    scored.sort((a, b) => b[1] - a[1] || a[0] - b[0]);
    return scored.map(([d]) => this.ids[d]);
  }

  private matchToken(q: string): Map<number, number> {
    const out = new Map<number, number>();
    const bump = (docs: Map<number, number> | undefined, base: number) => {
      if (!docs) return;
      for (const [d, w] of docs) {
        const s = base * w;
        if (s > (out.get(d) ?? 0)) out.set(d, s);
      }
    };
    bump(this.raw.get(q), S_EXACT);
    // prefix range over the sorted vocabulary
    let lo = lowerBound(this.rawVocab, q);
    while (lo < this.rawVocab.length && this.rawVocab[lo].startsWith(q)) {
      bump(this.raw.get(this.rawVocab[lo]), S_PREFIX);
      lo++;
    }
    bump(this.stems.get(stem(q)), S_STEM);
    if (out.size === 0 && q.length >= 4) {
      const max = q.length <= 7 ? 1 : 2;
      const sq = stem(q);
      for (const v of this.stemVocab) {
        if (Math.abs(v.length - sq.length) > max) continue;
        if (boundedDistance(sq, v, max) <= max) bump(this.stems.get(v), S_FUZZY);
      }
    }
    return out;
  }
}

function put(map: Map<string, Map<number, number>>, key: string, doc: number, w: number) {
  let m = map.get(key);
  if (!m) map.set(key, (m = new Map()));
  if ((m.get(doc) ?? 0) < w) m.set(doc, w);
}

function lowerBound(arr: string[], v: string): number {
  let lo = 0;
  let hi = arr.length;
  while (lo < hi) {
    const mid = (lo + hi) >> 1;
    if (arr[mid] < v) lo = mid + 1;
    else hi = mid;
  }
  return lo;
}
