// Text helpers: natural sorting, search normalization, stemming, bounded edit distance.

const collator = new Intl.Collator("en", { numeric: true, sensitivity: "base" });

/** Natural order: page2 comes before page10. */
export function naturalCompare(a: string, b: string): number {
  const r = collator.compare(a, b);
  if (r !== 0) return r;
  return a < b ? -1 : a > b ? 1 : 0;
}

const MARKS = /\p{M}+/gu;
const APOS = /['\u2019\u2018`\u00B4]/g;
const NON_ALNUM = /[^\p{L}\p{N}]+/gu;

/**
 * Case-insensitive, diacritic-insensitive, punctuation-insensitive form.
 * "[Sisters] Bon-Bon (v2)" becomes "sisters bon bon v2".
 */
export function normalizeText(s: string): string {
  return s
    .normalize("NFKD")
    .replace(MARKS, "")
    .toLowerCase()
    .replace(APOS, "")
    .replace(NON_ALNUM, " ")
    .trim()
    .replace(/\s+/g, " ");
}

export function tokenize(s: string): string[] {
  const n = normalizeText(s);
  return n ? n.split(" ") : [];
}

/** Light English plural / inflection handling. Non-Latin tokens are returned unchanged. */
export function stem(t: string): string {
  if (t.length < 4 || !/^[a-z0-9]+$/.test(t)) return t;
  if (t.endsWith("ies") && t.length > 4) return t.slice(0, -3) + "y";
  if (t.endsWith("sses")) return t.slice(0, -2);
  if (/(xes|ches|shes|zes)$/.test(t)) return t.slice(0, -2);
  if (t.endsWith("s") && !/(ss|us|is)$/.test(t)) return t.slice(0, -1);
  if (t.length > 5 && t.endsWith("ing")) return t.slice(0, -3);
  if (t.length > 4 && t.endsWith("ed")) return t.slice(0, -2);
  return t;
}

/**
 * Damerau-Levenshtein distance with an early cut-off.
 * Returns max + 1 when the distance exceeds max.
 */
export function boundedDistance(a: string, b: string, max: number): number {
  if (a === b) return 0;
  const la = a.length;
  const lb = b.length;
  if (Math.abs(la - lb) > max) return max + 1;
  let prev2: number[] = [];
  let prev: number[] = Array.from({ length: lb + 1 }, (_, j) => j);
  for (let i = 1; i <= la; i++) {
    const cur: number[] = [i];
    let rowMin = i;
    for (let j = 1; j <= lb; j++) {
      const cost = a.charCodeAt(i - 1) === b.charCodeAt(j - 1) ? 0 : 1;
      let v = Math.min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + cost);
      if (i > 1 && j > 1 && a[i - 1] === b[j - 2] && a[i - 2] === b[j - 1]) {
        v = Math.min(v, prev2[j - 2] + 1);
      }
      cur[j] = v;
      if (v < rowMin) rowMin = v;
    }
    if (rowMin > max) return max + 1;
    prev2 = prev;
    prev = cur;
  }
  return prev[lb] <= max ? prev[lb] : max + 1;
}

export function similarity(a: string, b: string): number {
  const na = normalizeText(a);
  const nb = normalizeText(b);
  if (!na && !nb) return 1;
  const max = Math.max(na.length, nb.length);
  const d = boundedDistance(na, nb, Math.ceil(max * 0.4));
  return Math.max(0, 1 - d / max);
}

export function formatBytes(n: number): string {
  if (!isFinite(n) || n <= 0) return "0 B";
  const u = ["B", "KB", "MB", "GB", "TB"];
  const i = Math.min(u.length - 1, Math.floor(Math.log(n) / Math.log(1024)));
  const v = n / Math.pow(1024, i);
  return `${v >= 100 || i === 0 ? v.toFixed(0) : v.toFixed(1)} ${u[i]}`;
}

export function formatDuration(sec: number | null | undefined): string {
  if (sec == null || !isFinite(sec)) return "--";
  const s = Math.max(0, Math.round(sec));
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const r = s % 60;
  if (h) return `${h}h ${m}m`;
  if (m) return `${m}m ${r}s`;
  return `${r}s`;
}

/** Run async work over items with a concurrency limit, preserving order of results. */
export async function mapLimit<T, R>(
  items: readonly T[],
  limit: number,
  fn: (item: T, index: number) => Promise<R>,
): Promise<R[]> {
  const out = new Array<R>(items.length);
  let next = 0;
  const workers = Array.from({ length: Math.max(1, Math.min(limit, items.length)) }, async () => {
    while (true) {
      const i = next++;
      if (i >= items.length) return;
      out[i] = await fn(items[i], i);
    }
  });
  await Promise.all(workers);
  return out;
}

export function posixJoin(...parts: string[]): string {
  return parts.filter((p) => p !== "").join("/").replace(/\/{2,}/g, "/");
}

export function posixDirname(p: string): string {
  const i = p.lastIndexOf("/");
  return i < 0 ? "" : p.slice(0, i);
}

export function posixBasename(p: string): string {
  const i = p.lastIndexOf("/");
  return i < 0 ? p : p.slice(i + 1);
}
