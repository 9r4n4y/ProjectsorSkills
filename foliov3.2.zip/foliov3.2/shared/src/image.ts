// Structural image validation: header, dimensions and truncation for every supported format.
// A full pixel decode is done by the platform (hidden renderer on PC, BitmapFactory on Android).

import { crc32 } from "./hash";

export interface ImageInspection {
  ok: boolean;
  format: string;
  width: number;
  height: number;
  error?: string;
}

const bad = (format: string, error: string): ImageInspection => ({ ok: false, format, width: 0, height: 0, error });
const good = (format: string, width: number, height: number): ImageInspection =>
  width > 0 && height > 0 ? { ok: true, format, width, height } : bad(format, "dimensions are zero");

const u32 = (b: Uint8Array, o: number) => ((b[o] << 24) | (b[o + 1] << 16) | (b[o + 2] << 8) | b[o + 3]) >>> 0;
const le32 = (b: Uint8Array, o: number) => (b[o] | (b[o + 1] << 8) | (b[o + 2] << 16) | (b[o + 3] << 24)) >>> 0;
const le16 = (b: Uint8Array, o: number) => b[o] | (b[o + 1] << 8);
const ascii = (b: Uint8Array, o: number, n: number) => String.fromCharCode(...b.subarray(o, o + n));

export function inspectImage(b: Uint8Array): ImageInspection {
  if (b.length < 12) return bad("unknown", "file too small to be an image");
  if (b[0] === 0x89 && ascii(b, 1, 3) === "PNG") return inspectPng(b);
  if (b[0] === 0xff && b[1] === 0xd8) return inspectJpeg(b);
  if (ascii(b, 0, 3) === "GIF") return inspectGif(b);
  if (ascii(b, 0, 4) === "RIFF" && ascii(b, 8, 4) === "WEBP") return inspectWebp(b);
  if (b[0] === 0x42 && b[1] === 0x4d) return inspectBmp(b);
  if (ascii(b, 4, 4) === "ftyp") return inspectAvif(b);
  return bad("unknown", "unrecognised image header");
}

function inspectPng(b: Uint8Array): ImageInspection {
  let o = 8;
  let w = 0;
  let h = 0;
  let sawIdat = false;
  while (o + 12 <= b.length) {
    const len = u32(b, o);
    const type = ascii(b, o + 4, 4);
    if (o + 12 + len > b.length) return bad("png", `truncated inside ${type} chunk`);
    const crc = u32(b, o + 8 + len);
    if (crc32(b.subarray(o + 4, o + 8 + len)) !== crc) return bad("png", `chunk ${type} CRC mismatch`);
    if (type === "IHDR") {
      w = u32(b, o + 8);
      h = u32(b, o + 12);
    } else if (type === "IDAT") sawIdat = true;
    else if (type === "IEND") return sawIdat ? good("png", w, h) : bad("png", "no image data");
    o += 12 + len;
  }
  return bad("png", "truncated: IEND chunk missing");
}

function inspectJpeg(b: Uint8Array): ImageInspection {
  let o = 2;
  let w = 0;
  let h = 0;
  while (o + 4 <= b.length) {
    if (b[o] !== 0xff) {
      o++;
      continue;
    }
    const m = b[o + 1];
    if (m === 0xff || m === 0x00 || (m >= 0xd0 && m <= 0xd7) || m === 0x01) {
      o += m === 0xff ? 1 : 2;
      continue;
    }
    if (m === 0xd9) break;
    const len = (b[o + 2] << 8) | b[o + 3];
    if (m >= 0xc0 && m <= 0xcf && m !== 0xc4 && m !== 0xc8 && m !== 0xcc) {
      h = (b[o + 5] << 8) | b[o + 6];
      w = (b[o + 7] << 8) | b[o + 8];
    }
    if (m === 0xda) {
      // entropy-coded data follows; the end marker must appear near the end of the file
      let e = b.length - 1;
      while (e > 0 && b[e] === 0) e--;
      if (!(b[e] === 0xd9 && b[e - 1] === 0xff)) return bad("jpeg", "truncated: end of image marker missing");
      return good("jpeg", w, h);
    }
    o += 2 + len;
  }
  return bad("jpeg", "truncated: no scan data");
}

function inspectGif(b: Uint8Array): ImageInspection {
  const v = ascii(b, 0, 6);
  if (v !== "GIF87a" && v !== "GIF89a") return bad("gif", "bad GIF signature");
  let e = b.length - 1;
  while (e > 0 && b[e] === 0) e--;
  if (b[e] !== 0x3b) return bad("gif", "truncated: trailer missing");
  return good("gif", le16(b, 6), le16(b, 8));
}

function inspectWebp(b: Uint8Array): ImageInspection {
  const riff = le32(b, 4) + 8;
  if (riff > b.length) return bad("webp", `truncated: expected ${riff} bytes, found ${b.length}`);
  const t = ascii(b, 12, 4);
  if (t === "VP8 ") {
    if (b[23] !== 0x9d || b[24] !== 0x01 || b[25] !== 0x2a) return bad("webp", "bad VP8 start code");
    return good("webp", le16(b, 26) & 0x3fff, le16(b, 28) & 0x3fff);
  }
  if (t === "VP8L") {
    if (b[20] !== 0x2f) return bad("webp", "bad VP8L signature");
    const bits = le32(b, 21);
    return good("webp", (bits & 0x3fff) + 1, ((bits >>> 14) & 0x3fff) + 1);
  }
  if (t === "VP8X") {
    const w = (b[24] | (b[25] << 8) | (b[26] << 16)) + 1;
    const h = (b[27] | (b[28] << 8) | (b[29] << 16)) + 1;
    return good("webp", w, h);
  }
  return bad("webp", "unknown WebP chunk " + t);
}

function inspectBmp(b: Uint8Array): ImageInspection {
  const declared = le32(b, 2);
  if (declared && declared > b.length) return bad("bmp", `truncated: expected ${declared} bytes, found ${b.length}`);
  const w = le32(b, 18) | 0;
  const h = Math.abs(le32(b, 22) | 0);
  return good("bmp", Math.abs(w), h);
}

function inspectAvif(b: Uint8Array): ImageInspection {
  const brand = ascii(b, 8, 4);
  if (!["avif", "avis", "mif1", "msf1"].includes(brand)) return bad("avif", "unsupported ftyp brand " + brand);
  let o = 0;
  while (o + 8 <= b.length) {
    let size = u32(b, o);
    if (size === 1) size = u32(b, o + 12);
    if (size === 0) size = b.length - o;
    if (size < 8) return bad("avif", "corrupt box size");
    if (o + size > b.length) return bad("avif", "truncated: box extends past end of file");
    o += size;
  }
  for (let i = 0; i + 20 < b.length && i < 4096; i++) {
    if (b[i] === 0x69 && b[i + 1] === 0x73 && b[i + 2] === 0x70 && b[i + 3] === 0x65) {
      return good("avif", u32(b, i + 8), u32(b, i + 12));
    }
  }
  return bad("avif", "image size box (ispe) not found");
}
