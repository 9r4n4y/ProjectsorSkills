// File classification: images, junk, archives, and multi-volume sets.

export const IMAGE_EXT = new Set(["png", "jpg", "jpeg", "webp", "avif", "gif", "bmp"]);

export function extOf(name: string): string {
  const b = name.slice(name.lastIndexOf("/") + 1);
  const i = b.lastIndexOf(".");
  return i <= 0 ? "" : b.slice(i + 1).toLowerCase();
}

export function isImageFile(name: string): boolean {
  return IMAGE_EXT.has(extOf(name)) && !isJunkPath(name);
}

const JUNK_NAMES = new Set(["thumbs.db", "desktop.ini", ".ds_store", "ehthumbs.db"]);

export function isJunkPath(path: string): boolean {
  const parts = path.split(/[\\/]/);
  for (const p of parts) {
    const l = p.toLowerCase();
    if (l === "__macosx" || JUNK_NAMES.has(l) || l.startsWith("._")) return true;
    if (l.startsWith(".comiclib")) return true;
  }
  return false;
}

export interface ParsedArchiveName {
  /** archive name without any (multi-part) extension */
  base: string;
  scheme: "single" | "rar-part" | "numbered" | "zip-z" | "rar-r";
  /** 1-based volume index (0 for the primary file of zip-z and rar-r sets) */
  index: number;
  /** digits width used by the numbering */
  width: number;
  ext: string;
}

const SINGLE_EXTS = ["tar.gz", "tar.bz2", "tar.xz", "tgz", "tbz2", "txz", "zip", "7z", "rar", "cbz", "cbr", "cb7", "tar"];

export function parseArchiveName(file: string): ParsedArchiveName | null {
  const lower = file.toLowerCase();
  let m = /^(.*)\.part0*(\d+)\.rar$/i.exec(file);
  if (m) return { base: m[1], scheme: "rar-part", index: +m[2], width: file.match(/\.part(\d+)\.rar$/i)![1].length, ext: "rar" };
  m = /^(.*)\.(7z|zip|rar|tar)\.(\d{3})$/i.exec(file);
  if (m) return { base: m[1], scheme: "numbered", index: +m[3], width: 3, ext: m[2].toLowerCase() };
  m = /^(.*)\.z(\d{2})$/i.exec(file);
  if (m) return { base: m[1], scheme: "zip-z", index: +m[2], width: 2, ext: "zip" };
  m = /^(.*)\.r(\d{2})$/i.exec(file);
  if (m) return { base: m[1], scheme: "rar-r", index: +m[2] + 1, width: 2, ext: "rar" };
  for (const e of SINGLE_EXTS) {
    if (lower.endsWith("." + e) && file.length > e.length + 1) {
      return { base: file.slice(0, file.length - e.length - 1), scheme: "single", index: 0, width: 0, ext: e };
    }
  }
  return null;
}

export function isArchiveFile(name: string): boolean {
  return parseArchiveName(name.slice(name.lastIndexOf("/") + 1)) !== null;
}

/** Name an archive extracts to: the file name without extension(s). */
export function archiveBaseName(file: string): string {
  return parseArchiveName(file)?.base ?? file.replace(/\.[^.]+$/, "");
}

export interface ArchiveGroup {
  base: string;
  /** file passed to the extraction engine */
  primary: string;
  parts: string[];
  missing: string[];
  size: number;
  volumes: boolean;
}

function pad(n: number, w: number): string {
  return String(n).padStart(w, "0");
}

/** Group the files of one directory into archives, merging multi-volume sets. */
export function groupArchives(files: readonly { name: string; size: number }[]): ArchiveGroup[] {
  const groups = new Map<string, { base: string; scheme: string; items: { name: string; size: number; p: ParsedArchiveName }[] }>();
  const sizeOf = new Map(files.map((f) => [f.name.toLowerCase(), f.size]));
  const parsed: { name: string; size: number; p: ParsedArchiveName }[] = [];
  for (const f of files) {
    const p = parseArchiveName(f.name);
    if (p && !isJunkPath(f.name)) parsed.push({ ...f, p });
  }
  // volume sets first
  for (const it of parsed) {
    if (it.p.scheme === "single") continue;
    const key = `${it.p.scheme}|${it.p.base.toLowerCase()}|${it.p.scheme === "numbered" ? it.p.ext : ""}`;
    let g = groups.get(key);
    if (!g) groups.set(key, (g = { base: it.p.base, scheme: it.p.scheme, items: [] }));
    g.items.push(it);
  }
  const out: ArchiveGroup[] = [];
  const consumed = new Set<string>();
  for (const g of groups.values()) {
    const idx = g.items.map((i) => i.p.index).sort((a, b) => a - b);
    const w = g.items[0].p.width;
    const parts: string[] = [];
    const missing: string[] = [];
    let primary = "";
    let size = 0;
    for (const i of g.items) size += i.size;
    const ext = g.items[0].p.ext;
    if (g.scheme === "rar-part") {
      const max = idx[idx.length - 1];
      for (let n = 1; n <= max; n++) {
        const found = g.items.find((i) => i.p.index === n);
        const nm = found ? found.name : `${g.base}.part${pad(n, w)}.rar`;
        (found ? parts : missing).push(nm);
      }
      primary = g.items.find((i) => i.p.index === 1)?.name ?? `${g.base}.part${pad(1, w)}.rar`;
    } else if (g.scheme === "numbered") {
      const max = idx[idx.length - 1];
      for (let n = 1; n <= max; n++) {
        const found = g.items.find((i) => i.p.index === n);
        const nm = found ? found.name : `${g.base}.${ext}.${pad(n, 3)}`;
        (found ? parts : missing).push(nm);
      }
      primary = g.items.find((i) => i.p.index === 1)?.name ?? `${g.base}.${ext}.001`;
    } else {
      // zip-z (base.zip + base.z01 ...) and rar-r (base.rar + base.r00 ...)
      const mainExt = g.scheme === "zip-z" ? "zip" : "rar";
      const mainName = [`${g.base}.${mainExt}`, `${g.base}.${mainExt.toUpperCase()}`].find((n) => sizeOf.has(n.toLowerCase()));
      const max = idx[idx.length - 1];
      const first = g.scheme === "zip-z" ? 1 : 1;
      for (let n = first; n <= max; n++) {
        const found = g.items.find((i) => i.p.index === n);
        const label = g.scheme === "zip-z" ? `${g.base}.z${pad(n, 2)}` : `${g.base}.r${pad(n - 1, 2)}`;
        (found ? parts : missing).push(found ? found.name : label);
      }
      if (mainName) {
        const real = files.find((f) => f.name.toLowerCase() === mainName.toLowerCase())!;
        parts.push(real.name);
        size += real.size;
        primary = real.name;
        consumed.add(real.name.toLowerCase());
      } else {
        missing.push(`${g.base}.${mainExt}`);
        primary = `${g.base}.${mainExt}`;
      }
      // the .zip / .rar is listed first for the engine
      parts.sort((a, b) => (a === primary ? -1 : b === primary ? 1 : 0));
    }
    out.push({ base: g.base, primary, parts, missing, size, volumes: true });
  }
  for (const it of parsed) {
    if (it.p.scheme !== "single" || consumed.has(it.name.toLowerCase())) continue;
    out.push({ base: it.p.base, primary: it.name, parts: [it.name], missing: [], size: it.size, volumes: false });
  }
  return out.sort((a, b) => a.primary.localeCompare(b.primary));
}
