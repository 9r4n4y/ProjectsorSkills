// Reusable job framework: queue, progress, persistence, pause/resume, cancel, retry.
// Any future task (scan, verify, thumbnails, import) registers a handler and gets all of it.

import type { JobRecord } from "./types";

export interface JobProgress {
  done?: number;
  total?: number;
  bytes?: number;
  totalBytes?: number;
  fraction?: number;
  message?: string;
}

export interface JobContext<P = unknown> {
  id: string;
  payload: P;
  signal: AbortSignal;
  progress(p: JobProgress): void;
  log(message: string): void;
}

export type JobHandler<P = any> = (ctx: JobContext<P>) => Promise<void>;

export interface JobStore {
  load(): Promise<JobRecord[]>;
  save(jobs: JobRecord[]): Promise<void>;
}

export interface JobsState {
  jobs: JobRecord[];
  paused: boolean;
}

export interface JobQueueOptions {
  concurrency: number;
  store?: JobStore;
  now?: () => number;
  /** maximum finished jobs kept in history */
  history?: number;
  log?: (m: string) => void;
}

type Reason = "pause" | "cancel";

export class JobQueue {
  private jobs = new Map<string, JobRecord>();
  private handlers = new Map<string, JobHandler>();
  private running = new Map<string, { ctl: AbortController; reason?: Reason }>();
  private listeners = new Set<(s: JobsState) => void>();
  private concurrency: number;
  private paused = false;
  private seq = 0;
  private saveTimer: ReturnType<typeof setTimeout> | null = null;
  private emitTimer: ReturnType<typeof setTimeout> | null = null;
  private idleWaiters: (() => void)[] = [];
  private lastTick = new Map<string, { t: number; bytes: number }>();
  private now: () => number;

  constructor(private opts: JobQueueOptions) {
    this.concurrency = Math.max(1, opts.concurrency);
    this.now = opts.now ?? Date.now;
  }

  register<P>(kind: string, handler: JobHandler<P>): void {
    this.handlers.set(kind, handler as JobHandler);
  }

  /** Reload persisted jobs. Anything that was queued or running when the app died is queued again. */
  async restore(): Promise<number> {
    if (!this.opts.store) return 0;
    let n = 0;
    for (const j of await this.opts.store.load()) {
      if (j.state === "running" || j.state === "paused" || j.state === "queued") {
        j.state = "queued";
        j.message = "Resumed after restart";
        n++;
      }
      this.jobs.set(j.id, j);
      const num = parseInt(j.id.split("-").pop() ?? "0", 10);
      if (num > this.seq) this.seq = num;
    }
    this.emit();
    this.pump();
    return n;
  }

  add(kind: string, title: string, payload: unknown, o: { group?: string; id?: string; total?: number; totalBytes?: number } = {}): JobRecord {
    const id = o.id ?? `job-${this.now().toString(36)}-${++this.seq}`;
    const job: JobRecord = {
      id,
      kind,
      title,
      state: "queued",
      progress: 0,
      done: 0,
      total: o.total ?? 1,
      bytes: 0,
      totalBytes: o.totalBytes ?? 0,
      speed: 0,
      etaSec: null,
      message: "Queued",
      attempts: 0,
      createdAt: this.now(),
      group: o.group,
      payload,
    };
    this.jobs.set(id, job);
    this.changed();
    this.pump();
    return job;
  }

  list(): JobRecord[] {
    return [...this.jobs.values()].sort((a, b) => a.createdAt - b.createdAt);
  }
  get(id: string): JobRecord | undefined {
    return this.jobs.get(id);
  }
  state(): JobsState {
    return { jobs: this.list(), paused: this.paused };
  }
  get isPaused(): boolean {
    return this.paused;
  }
  subscribe(fn: (s: JobsState) => void): () => void {
    this.listeners.add(fn);
    return () => this.listeners.delete(fn);
  }
  setConcurrency(n: number): void {
    this.concurrency = Math.max(1, n);
    this.pump();
  }
  get workers(): number {
    return this.concurrency;
  }

  pauseAll(): void {
    this.paused = true;
    for (const [id, r] of this.running) {
      r.reason = "pause";
      r.ctl.abort();
      const j = this.jobs.get(id);
      if (j) j.message = "Pausing";
    }
    this.changed();
  }
  resumeAll(): void {
    this.paused = false;
    for (const j of this.jobs.values()) if (j.state === "paused") j.state = "queued";
    this.changed();
    this.pump();
  }
  cancel(id: string): void {
    const j = this.jobs.get(id);
    if (!j) return;
    const r = this.running.get(id);
    if (r) {
      r.reason = "cancel";
      r.ctl.abort();
    } else if (j.state === "queued" || j.state === "paused") {
      j.state = "cancelled";
      j.message = "Cancelled";
      j.finishedAt = this.now();
      this.changed();
    }
  }
  cancelAll(group?: string): void {
    for (const j of [...this.jobs.values()]) if (!group || j.group === group) this.cancel(j.id);
  }
  retry(id: string): void {
    const j = this.jobs.get(id);
    if (!j || !["failed", "cancelled"].includes(j.state)) return;
    j.state = "queued";
    j.error = undefined;
    j.progress = 0;
    j.done = 0;
    j.message = "Queued";
    j.finishedAt = undefined;
    this.changed();
    this.pump();
  }
  remove(id: string): void {
    const j = this.jobs.get(id);
    if (j && !this.running.has(id)) {
      this.jobs.delete(id);
      this.changed();
    }
  }
  clearFinished(): void {
    for (const j of [...this.jobs.values()]) if (["done", "failed", "cancelled"].includes(j.state)) this.jobs.delete(j.id);
    this.changed();
  }

  whenIdle(): Promise<void> {
    if (this.isIdle()) return Promise.resolve();
    return new Promise((r) => this.idleWaiters.push(r));
  }
  private isIdle(): boolean {
    if (this.running.size) return false;
    if (this.paused) return true;
    return ![...this.jobs.values()].some((j) => j.state === "queued");
  }

  private pump(): void {
    while (!this.paused && this.running.size < this.concurrency) {
      const next = [...this.jobs.values()].find((j) => j.state === "queued" && !this.running.has(j.id));
      if (!next) break;
      void this.run(next);
    }
    if (this.isIdle()) {
      const w = this.idleWaiters.splice(0);
      w.forEach((r) => r());
    }
  }

  private async run(job: JobRecord): Promise<void> {
    const handler = this.handlers.get(job.kind);
    const ctl = new AbortController();
    const entry: { ctl: AbortController; reason?: Reason } = { ctl };
    this.running.set(job.id, entry);
    job.state = "running";
    job.attempts++;
    job.startedAt = this.now();
    job.message = "Starting";
    this.lastTick.set(job.id, { t: this.now(), bytes: 0 });
    this.changed();
    try {
      if (!handler) throw new Error(`No handler registered for job kind "${job.kind}"`);
      await handler({
        id: job.id,
        payload: job.payload,
        signal: ctl.signal,
        log: (m) => this.opts.log?.(`[${job.id}] ${m}`),
        progress: (p) => this.applyProgress(job, p),
      });
      if (entry.reason === "cancel") this.finish(job, "cancelled", "Cancelled");
      else if (entry.reason === "pause") this.finish(job, "paused", "Paused");
      else {
        job.progress = 1;
        job.done = job.total;
        this.finish(job, "done", "Done");
      }
    } catch (e) {
      if (entry.reason === "cancel") this.finish(job, "cancelled", "Cancelled");
      else if (entry.reason === "pause") this.finish(job, "paused", "Paused");
      else {
        job.error = (e as Error).message;
        this.finish(job, "failed", job.error);
      }
    } finally {
      this.running.delete(job.id);
      this.lastTick.delete(job.id);
      this.trimHistory();
      this.changed();
      this.pump();
    }
  }

  private finish(job: JobRecord, state: JobRecord["state"], message: string): void {
    job.state = state;
    job.message = message;
    job.speed = 0;
    job.etaSec = null;
    if (state !== "paused") job.finishedAt = this.now();
  }

  private applyProgress(job: JobRecord, p: JobProgress): void {
    if (p.total !== undefined) job.total = p.total;
    if (p.done !== undefined) job.done = p.done;
    if (p.totalBytes !== undefined) job.totalBytes = p.totalBytes;
    if (p.bytes !== undefined) {
      job.bytes = p.bytes;
      const tick = this.lastTick.get(job.id);
      const t = this.now();
      if (tick && t - tick.t >= 500) {
        const inst = ((p.bytes - tick.bytes) * 1000) / (t - tick.t);
        job.speed = job.speed ? job.speed * 0.7 + inst * 0.3 : inst;
        this.lastTick.set(job.id, { t, bytes: p.bytes });
      }
    }
    if (p.fraction !== undefined) job.progress = Math.max(0, Math.min(1, p.fraction));
    else if (job.total > 0) job.progress = Math.min(1, job.done / job.total);
    if (p.message !== undefined) job.message = p.message;
    if (job.speed > 0 && job.totalBytes > job.bytes) job.etaSec = (job.totalBytes - job.bytes) / job.speed;
    else if (job.startedAt && job.progress > 0.02 && job.progress < 1) {
      job.etaSec = ((this.now() - job.startedAt) / 1000) * ((1 - job.progress) / job.progress);
    }
    this.scheduleEmit();
  }

  private trimHistory(): void {
    const max = this.opts.history ?? 200;
    const fin = [...this.jobs.values()].filter((j) => ["done", "failed", "cancelled"].includes(j.state));
    for (const j of fin.slice(0, Math.max(0, fin.length - max))) this.jobs.delete(j.id);
  }

  private changed(): void {
    this.emit();
    if (this.opts.store && !this.saveTimer) {
      this.saveTimer = setTimeout(() => {
        this.saveTimer = null;
        void this.opts.store!.save(this.list()).catch(() => undefined);
      }, 300);
    }
  }
  private scheduleEmit(): void {
    if (this.emitTimer) return;
    this.emitTimer = setTimeout(() => {
      this.emitTimer = null;
      this.emit();
    }, 120);
  }
  private emit(): void {
    const s = this.state();
    for (const l of this.listeners) l(s);
  }
  /** Flush persistence immediately (call on shutdown). */
  async flush(): Promise<void> {
    if (this.saveTimer) clearTimeout(this.saveTimer);
    this.saveTimer = null;
    await this.opts.store?.save(this.list());
  }
}

export interface JobSummary {
  total: number;
  done: number;
  failed: number;
  running: number;
  queued: number;
  active: boolean;
  fraction: number;
  speed: number;
  etaSec: number | null;
  bytes: number;
  totalBytes: number;
}

export function summarizeJobs(jobs: readonly JobRecord[], group?: string): JobSummary {
  const list = group ? jobs.filter((j) => j.group === group) : jobs;
  const s: JobSummary = { total: list.length, done: 0, failed: 0, running: 0, queued: 0, active: false, fraction: 0, speed: 0, etaSec: null, bytes: 0, totalBytes: 0 };
  let sum = 0;
  for (const j of list) {
    if (j.state === "done") s.done++;
    else if (j.state === "failed") s.failed++;
    else if (j.state === "running") s.running++;
    else if (j.state === "queued" || j.state === "paused") s.queued++;
    sum += j.state === "done" ? 1 : j.state === "failed" || j.state === "cancelled" ? 1 : j.progress;
    s.speed += j.state === "running" ? j.speed : 0;
    s.bytes += j.bytes;
    s.totalBytes += j.totalBytes;
  }
  s.active = s.running + s.queued > 0;
  s.fraction = list.length ? sum / list.length : 0;
  if (s.speed > 0 && s.totalBytes > s.bytes) s.etaSec = (s.totalBytes - s.bytes) / s.speed;
  else {
    const etas = list.filter((j) => j.state === "running" && j.etaSec != null).map((j) => j.etaSec!);
    if (etas.length && s.queued === 0) s.etaSec = Math.max(...etas);
  }
  return s;
}
