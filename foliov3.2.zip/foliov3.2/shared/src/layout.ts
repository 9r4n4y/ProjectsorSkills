// Extraction layout planning. This module enforces the "no mixing" rule:
// every archive always lands inside its own folder named after the archive.

import { Sha256 } from "./hash";
import { isArchiveFile, isImageFile, isJunkPath } from "./archives";

export interface ArchiveEntry {
  path: string;
  size: number;
  crc?: number;
  isDir: boolean;
  isSymlink?: boolean;
  encrypted?: boolean;
}

export interface PlannedFile {
  /** path inside the archive */
  src: string;
  /** path relative to the final comic folder (the folder named after the archive) */
  dest: string;
  size: number;
  crc?: number;
}

export type LayoutKind = "single-folder" | "loose" | "multi" | "mixed" | "empty";

export interface ExtractionPlan {
  /** name of the final folder (archive name, sanitized only where required) */
  folderName: string;
  files: PlannedFile[];
  skipped: { src: string; reason: string }[];
  unsafe: { src: string; reason: string }[];
  /** relative dirs (inside folderName) that directly contain page images; "" is the folder itself */
  comicDirs: string[];
  nestedArchives: string[];
  imageCount: number;
  totalBytes: number;
  layout: LayoutKind;
  collapsed: number;
}

const RESERVED = /^(con|prn|aux|nul|com[1-9]|lpt[1-9])(\..*)?$/i;
const INVALID = /[<>:"|?*\u0000-\u001f]/g;
const BIDI = /[\u200e\u200f\u202a-\u202e\u2066-\u2069]/g;

/** Make one path segment safe on Windows, Android and Linux while keeping unicode and RTL letters. */
export function sanitizeSegment(seg: string): string {
  let s = seg.normalize("NFC").replace(BIDI, "").replace(INVALID, "_");
  s = s.replace(/[. ]+$/, "").replace(/^ +/, "");
  if (!s) s = "_";
  if (RESERVED.test(s)) s = "_" + s;
  return s;
}

function shortHash(s: string): string {
  return new Sha256().update(new TextEncoder().encode(s)).digestHex().slice(0, 4);
}

function splitExt(name: string): [string, string] {
  const i = name.lastIndexOf(".");
  return i > 0 && name.length - i <= 8 ? [name.slice(0, i), name.slice(i)] : [name, ""];
}

function shorten(seg: string, max: number): string {
  if (seg.length <= max) return seg;
  const [b, e] = splitExt(seg);
  const keep = Math.max(4, max - e.length - 5);
  return `${b.slice(0, keep)}~${shortHash(seg)}${e}`;
}

export interface PlanOptions {
  /** length of the parent directory path, used to stay below the path limit */
  parentLen?: number;
  maxPath?: number;
}

export function planExtraction(archiveName: string, entries: readonly ArchiveEntry[], opts: PlanOptions = {}): ExtractionPlan {
  const maxPath = opts.maxPath ?? 240;
  const folderName = shorten(sanitizeSegment(archiveName), 120);
  const unsafe: ExtractionPlan["unsafe"] = [];
  const skipped: ExtractionPlan["skipped"] = [];
  const cand: { src: string; segs: string[]; size: number; crc?: number }[] = [];

  for (const e of entries) {
    const p = e.path.replace(/\\/g, "/").replace(/^(\.\/)+/, "");
    if (e.isSymlink) {
      unsafe.push({ src: e.path, reason: "symbolic link" });
      continue;
    }
    const raw = p.split("/");
    if (p.startsWith("/") || /^[A-Za-z]:/.test(p) || raw.includes("..") || p.includes("\u0000")) {
      unsafe.push({ src: e.path, reason: "path traversal or absolute path" });
      continue;
    }
    if (e.isDir) continue;
    if (isJunkPath(p)) {
      skipped.push({ src: e.path, reason: "system junk file" });
      continue;
    }
    const segs = raw.filter((s) => s !== "" && s !== ".");
    if (!segs.length) continue;
    cand.push({ src: e.path, segs: segs.map(sanitizeSegment), size: e.size, crc: e.crc });
  }

  // collapse single top-level folders (repeatedly) so there is never double nesting
  let collapsed = 0;
  while (cand.length) {
    const tops = new Set<string>();
    let loose = false;
    for (const c of cand) {
      if (c.segs.length === 1) loose = true;
      else tops.add(c.segs[0]);
    }
    if (loose || tops.size !== 1) break;
    for (const c of cand) c.segs.shift();
    collapsed++;
  }

  let layout: LayoutKind = "empty";
  if (cand.length) {
    const tops = new Set(cand.filter((c) => c.segs.length > 1).map((c) => c.segs[0]));
    const loose = cand.some((c) => c.segs.length === 1);
    if (!tops.size) layout = "loose";
    else if (loose) layout = "mixed";
    else layout = tops.size > 1 ? "multi" : "single-folder";
    if (layout === "loose" && collapsed > 0) layout = "single-folder";
  }

  // case-only collisions and long paths
  const seen = new Map<string, number>();
  const files: PlannedFile[] = [];
  const budget = maxPath - (opts.parentLen ?? 0) - folderName.length - 2;
  for (const c of cand) {
    let segs = c.segs;
    if (segs.join("/").length > budget) {
      segs = segs.map((s) => shorten(s, 60));
      if (segs.join("/").length > budget) {
        segs = segs.map((s, i) => (i === segs.length - 1 ? shorten(s, 40) : shorten(s, 24)));
      }
    }
    let dest = segs.join("/");
    const key = dest.normalize("NFC").toLowerCase();
    const n = seen.get(key) ?? 0;
    seen.set(key, n + 1);
    if (n > 0) {
      const [b, e] = splitExt(segs[segs.length - 1]);
      segs = [...segs.slice(0, -1), `${b} (${n + 1})${e}`];
      dest = segs.join("/");
      seen.set(dest.normalize("NFC").toLowerCase(), 1);
    }
    files.push({ src: c.src, dest, size: c.size, crc: c.crc });
  }

  const dirSet = new Set<string>();
  const nested: string[] = [];
  let imageCount = 0;
  let totalBytes = 0;
  for (const f of files) {
    totalBytes += f.size;
    if (isImageFile(f.dest)) {
      imageCount++;
      const i = f.dest.lastIndexOf("/");
      dirSet.add(i < 0 ? "" : f.dest.slice(0, i));
    } else if (isArchiveFile(f.dest)) nested.push(f.dest);
  }
  return {
    folderName,
    files,
    skipped,
    unsafe,
    comicDirs: [...dirSet].sort(),
    nestedArchives: nested,
    imageCount,
    totalBytes,
    layout,
    collapsed,
  };
}

/** Pick a target folder name that never overwrites anything (case-insensitive). */
export function uniqueName(desired: string, existingNames: Iterable<string>): string {
  const taken = new Set([...existingNames].map((n) => n.normalize("NFC").toLowerCase()));
  if (!taken.has(desired.normalize("NFC").toLowerCase())) return desired;
  for (let i = 2; i < 10000; i++) {
    const c = `${desired} (${i})`;
    if (!taken.has(c.normalize("NFC").toLowerCase())) return c;
  }
  return `${desired} (${Date.now()})`;
}
