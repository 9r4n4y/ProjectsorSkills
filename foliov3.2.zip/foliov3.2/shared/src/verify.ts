// The ten verification layers. Each function is pure so the same rules run on PC, Android bridge and tests.

import type { Fingerprint, LayerResult, LayerStatus, Tri } from "./types";
import type { PlannedFile } from "./layout";
import { crcHex, sha256Hex } from "./hash";
import { isImageFile } from "./archives";
import { naturalCompare } from "./text";

export const LAYER_NAMES = [
  "Archive integrity",
  "File list comparison",
  "CRC32 and SHA-256",
  "Count and total size",
  "Image decode",
  "Page sequence",
  "Empty and tiny files",
  "Manifest",
  "Post-move check",
  "Library index",
] as const;

export function layer(n: number, status: LayerStatus, summary: string, details: string[] = []): LayerResult {
  return { layer: n, name: LAYER_NAMES[n - 1], status, summary, details: capList(details) };
}

function capList(d: string[], max = 40): string[] {
  return d.length > max ? [...d.slice(0, max), `... and ${d.length - max} more`] : d;
}

export function skipped(n: number, why: string): LayerResult {
  return layer(n, "skip", why);
}

export function summarizeLayers(layers: readonly LayerResult[]): Tri {
  if (layers.some((l) => l.status === "fail")) return "red";
  if (layers.some((l) => l.status === "warn")) return "amber";
  return "green";
}

export interface FileFacts {
  crc32: number;
  sha256: string;
  size: number;
}

/** Layer 1 */
export function layerIntegrity(ok: boolean, output: string, engine: string): LayerResult {
  return ok
    ? layer(1, "pass", `Archive test passed (${engine})`)
    : layer(1, "fail", `Archive test failed (${engine})`, output.split("\n").filter(Boolean).slice(-8));
}

/** Layer 2: every expected entry present, no extras. */
export function compareListing(expected: readonly PlannedFile[], actual: readonly string[]): LayerResult {
  const want = new Set(expected.map((e) => e.dest));
  const have = new Set(actual);
  const missing = [...want].filter((p) => !have.has(p));
  const extra = [...have].filter((p) => !want.has(p));
  if (!missing.length && !extra.length) return layer(2, "pass", `${want.size} entries match the archive listing`);
  return layer(2, "fail", `${missing.length} missing, ${extra.length} unexpected`, [
    ...missing.map((m) => `missing: ${m}`),
    ...extra.map((x) => `unexpected: ${x}`),
  ]);
}

/** Layer 3: recomputed CRC32 compared with the stored value; SHA-256 is recorded for the manifest. */
export function compareHashes(expected: readonly PlannedFile[], actual: ReadonlyMap<string, FileFacts>): LayerResult {
  const bad: string[] = [];
  let checked = 0;
  let noCrc = 0;
  for (const e of expected) {
    const a = actual.get(e.dest);
    if (!a) continue;
    if (e.crc === undefined) {
      noCrc++;
      if (a.size !== e.size) bad.push(`${e.dest}: size ${a.size}, expected ${e.size}`);
      continue;
    }
    checked++;
    if ((a.crc32 >>> 0) !== (e.crc >>> 0)) bad.push(`${e.dest}: CRC32 ${crcHex(a.crc32)}, expected ${crcHex(e.crc)}`);
  }
  if (bad.length) return layer(3, "fail", `${bad.length} file(s) failed the checksum`, bad);
  if (noCrc && !checked) return layer(3, "warn", `Archive stores no CRC; compared sizes for ${noCrc} file(s)`);
  return layer(3, "pass", `${checked} checksum(s) verified`, noCrc ? [`${noCrc} entries without stored CRC were size-checked`] : []);
}

/** Layer 4 */
export function compareTotals(declared: { count: number; bytes: number }, actual: { count: number; bytes: number }): LayerResult {
  const d: string[] = [];
  if (declared.count !== actual.count) d.push(`file count ${actual.count}, expected ${declared.count}`);
  if (declared.bytes !== actual.bytes) d.push(`total bytes ${actual.bytes}, expected ${declared.bytes}`);
  return d.length
    ? layer(4, "fail", "Totals differ from the archive", d)
    : layer(4, "pass", `${actual.count} files, ${actual.bytes} bytes match`);
}

export interface DecodeResult {
  path: string;
  ok: boolean;
  width: number;
  height: number;
  error?: string;
}

/** Layer 5 */
export function decodeLayer(results: readonly DecodeResult[]): LayerResult {
  const bad = results.filter((r) => !r.ok || r.width <= 0 || r.height <= 0);
  if (!results.length) return layer(5, "warn", "No images to decode");
  if (bad.length) return layer(5, "fail", `${bad.length} of ${results.length} images failed to decode`, bad.map((b) => `${b.path}: ${b.error ?? "invalid dimensions"}`));
  return layer(5, "pass", `${results.length} images decoded`);
}

/** Extract the trailing number of a page file name, or null. */
export function pageNumber(fileName: string): number | null {
  const base = fileName.slice(fileName.lastIndexOf("/") + 1).replace(/\.[^.]+$/, "");
  const m = /(\d+)(?!.*\d)/.exec(base);
  return m ? parseInt(m[1], 10) : null;
}

/** Layer 6: gaps and duplicates in page numbering, reported as warnings with exact numbers. */
export function pageSequenceLayer(files: readonly string[]): LayerResult {
  const byDir = new Map<string, string[]>();
  for (const f of files) {
    if (!isImageFile(f)) continue;
    const i = f.lastIndexOf("/");
    const d = i < 0 ? "" : f.slice(0, i);
    (byDir.get(d) ?? byDir.set(d, []).get(d)!).push(f);
  }
  const warn: string[] = [];
  for (const [dir, list] of byDir) {
    const nums = list.map(pageNumber).filter((n): n is number => n !== null);
    if (nums.length < 2) continue;
    const label = dir ? `${dir}: ` : "";
    const seen = new Map<number, number>();
    for (const n of nums) seen.set(n, (seen.get(n) ?? 0) + 1);
    const dups = [...seen].filter(([, c]) => c > 1).map(([n]) => n);
    const sorted = [...seen.keys()].sort((a, b) => a - b);
    const missing: number[] = [];
    for (let n = sorted[0]; n <= sorted[sorted.length - 1]; n++) if (!seen.has(n)) missing.push(n);
    if (missing.length) warn.push(`${label}missing page number(s): ${listNums(missing)}`);
    if (dups.length) warn.push(`${label}duplicate page number(s): ${listNums(dups)}`);
  }
  return warn.length
    ? layer(6, "warn", `${warn.length} numbering issue(s)`, warn)
    : layer(6, "pass", "Page numbering is continuous");
}

function listNums(n: number[]): string {
  const s = n.slice(0, 30).join(", ");
  return n.length > 30 ? `${s} and ${n.length - 30} more` : s;
}

/** Layer 7 */
export function smallFilesLayer(files: readonly { path: string; size: number }[], tinyBytes = 1024): LayerResult {
  const zero = files.filter((f) => f.size === 0 && isImageFile(f.path));
  const zeroOther = files.filter((f) => f.size === 0 && !isImageFile(f.path));
  const tiny = files.filter((f) => f.size > 0 && f.size < tinyBytes && isImageFile(f.path));
  if (zero.length) return layer(7, "fail", `${zero.length} zero-byte image(s)`, zero.map((z) => z.path));
  if (tiny.length || zeroOther.length) {
    return layer(7, "warn", `${tiny.length} suspiciously small image(s), ${zeroOther.length} empty file(s)`, [
      ...tiny.map((z) => `${z.path} (${z.size} bytes)`),
      ...zeroOther.map((z) => `${z.path} (empty)`),
    ]);
  }
  return layer(7, "pass", "No empty or tiny files");
}

export interface Manifest {
  version: 1;
  archive: string;
  archiveSize: number;
  createdAt: number;
  pageCount: number;
  totalBytes: number;
  files: { path: string; size: number; sha256: string; crc32: string }[];
}

export const MANIFEST_NAME = ".comiclib-manifest.json";

/** Layer 8 helper. Paths are relative to the comic folder. */
export function buildManifest(
  archive: string,
  archiveSize: number,
  files: readonly { path: string; facts: FileFacts }[],
  now = Date.now(),
): Manifest {
  const sorted = [...files].sort((a, b) => naturalCompare(a.path, b.path));
  return {
    version: 1,
    archive,
    archiveSize,
    createdAt: now,
    pageCount: sorted.filter((f) => isImageFile(f.path)).length,
    totalBytes: sorted.reduce((s, f) => s + f.facts.size, 0),
    files: sorted.map((f) => ({ path: f.path, size: f.facts.size, sha256: f.facts.sha256, crc32: crcHex(f.facts.crc32) })),
  };
}

/** Layer 9 (and later re-verification): compare the folder on disk with the manifest. */
export function compareToManifest(manifest: Manifest, actual: readonly { path: string; size: number }[], layerNo = 9): LayerResult {
  const have = new Map(actual.map((a) => [a.path, a.size]));
  const d: string[] = [];
  for (const f of manifest.files) {
    const s = have.get(f.path);
    if (s === undefined) d.push(`missing: ${f.path}`);
    else if (s !== f.size) d.push(`size changed: ${f.path} (${s}, expected ${f.size})`);
  }
  const known = new Set(manifest.files.map((f) => f.path));
  for (const a of actual) if (!known.has(a.path)) d.push(`unexpected: ${a.path}`);
  return d.length
    ? layer(layerNo, "fail", `${d.length} difference(s) from the manifest`, d)
    : layer(layerNo, "pass", `${manifest.files.length} files and sizes match`);
}

/** Layer 10 */
export function indexLayer(expectedPages: number, indexed: { pageCount: number; thumbOk: boolean } | null): LayerResult {
  if (!indexed) return layer(10, "fail", "Comic is not in the library index");
  const d: string[] = [];
  if (indexed.pageCount !== expectedPages) d.push(`indexed ${indexed.pageCount} pages, expected ${expectedPages}`);
  if (!indexed.thumbOk) d.push("thumbnail is missing or invalid");
  return d.length ? layer(10, "fail", "Index cross-check failed", d) : layer(10, "pass", `Indexed with ${expectedPages} pages and a valid thumbnail`);
}

/** Fingerprint used to recognise a comic after it is moved or renamed. */
export function makeFingerprint(pages: { size: number }[], firstSha: string, lastSha: string): Fingerprint {
  return { pages: pages.length, sizes: sha256Hex(pages.map((p) => p.size).join(",")), first: firstSha, last: lastSha };
}
