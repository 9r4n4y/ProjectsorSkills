// Incremental rescan: detect added, removed, moved and changed items by path, size and modified time.

export interface IndexedItem {
  id: string;
  relPath: string;
  size: number;
  mtime: number;
  pages: number;
}

export interface ScannedItem {
  relPath: string;
  size: number;
  mtime: number;
  pages: number;
}

export interface ReconcileResult<I extends IndexedItem, S extends ScannedItem> {
  unchanged: I[];
  updated: { prev: I; next: S }[];
  added: S[];
  removed: I[];
  moved: { prev: I; next: S }[];
}

const base = (p: string) => p.slice(p.lastIndexOf("/") + 1).toLowerCase();

export function reconcileScan<I extends IndexedItem, S extends ScannedItem>(prev: readonly I[], found: readonly S[]): ReconcileResult<I, S> {
  const prevByPath = new Map(prev.map((p) => [p.relPath, p]));
  const seen = new Set<string>();
  const unchanged: I[] = [];
  const updated: { prev: I; next: S }[] = [];
  const addedCand: S[] = [];
  for (const f of found) {
    const p = prevByPath.get(f.relPath);
    if (!p) {
      addedCand.push(f);
      continue;
    }
    seen.add(p.relPath);
    if (p.size === f.size && p.mtime === f.mtime && p.pages === f.pages) unchanged.push(p);
    else updated.push({ prev: p, next: f });
  }
  const removedCand = prev.filter((p) => !seen.has(p.relPath));

  // moves: same page count and total size; prefer the same folder name, require uniqueness
  const sig = (x: { pages: number; size: number }) => `${x.pages}|${x.size}`;
  const bySig = new Map<string, I[]>();
  for (const r of removedCand) (bySig.get(sig(r)) ?? bySig.set(sig(r), []).get(sig(r))!).push(r);
  const moved: { prev: I; next: S }[] = [];
  const added: S[] = [];
  const takenPrev = new Set<string>();
  for (const a of addedCand) {
    const cands = (bySig.get(sig(a)) ?? []).filter((c) => !takenPrev.has(c.id));
    let pick: I | undefined;
    if (cands.length === 1) pick = cands[0];
    else if (cands.length > 1) {
      const same = cands.filter((c) => base(c.relPath) === base(a.relPath));
      if (same.length === 1) pick = same[0];
    }
    if (pick && a.pages > 0) {
      takenPrev.add(pick.id);
      moved.push({ prev: pick, next: a });
    } else added.push(a);
  }
  const removed = removedCand.filter((r) => !takenPrev.has(r.id));
  return { unchanged, updated, added, removed, moved };
}
