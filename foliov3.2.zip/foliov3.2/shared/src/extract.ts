// Extraction pipeline: staging, no-mixing layout, ten verification layers and self-healing.
// The platform supplies ports (engine, filesystem, image decoder, index); the rules live here.

import type { AttemptLog, LayerResult } from "./types";
import { type ArchiveEntry, type ExtractionPlan, type PlannedFile, planExtraction, uniqueName } from "./layout";
import {
  type DecodeResult,
  type FileFacts,
  MANIFEST_NAME,
  buildManifest,
  compareHashes,
  compareListing,
  compareToManifest,
  compareTotals,
  decodeLayer,
  indexLayer,
  layer,
  layerIntegrity,
  pageSequenceLayer,
  skipped,
  smallFilesLayer,
} from "./verify";
import { isImageFile, isJunkPath } from "./archives";
import { mapLimit, posixBasename, posixDirname } from "./text";

export interface ArchiveJob {
  id: string;
  /** absolute path of the file passed to the engine (first volume for split sets) */
  path: string;
  /** archive name without extension; the extraction folder is named after it */
  name: string;
  parentDir: string;
  parts: string[];
  missingParts: string[];
  size: number;
}

export interface EngineList {
  ok: boolean;
  entries: ArchiveEntry[];
  encrypted: boolean;
  wrongPassword?: boolean;
  error?: string;
  output: string;
}
export interface EngineTest {
  ok: boolean;
  wrongPassword?: boolean;
  output: string;
}
export interface EngineExtractOptions {
  password?: string;
  /** extract only these archive paths */
  only?: string[];
  /** extract entry by entry (alternate method) */
  perFile?: boolean;
  threads?: number;
  onProgress?: (done: number, total: number) => void;
  signal?: AbortSignal;
}
export interface EngineExtract {
  ok: boolean;
  error?: string;
  output: string;
}
export interface EnginePort {
  id: string;
  list(a: ArchiveJob, password?: string): Promise<EngineList>;
  test(a: ArchiveJob, password?: string): Promise<EngineTest>;
  extract(a: ArchiveJob, destDir: string, o: EngineExtractOptions): Promise<EngineExtract>;
}
export interface FsPort {
  exists(p: string): Promise<boolean>;
  listDir(p: string): Promise<string[]>;
  /** recursive file listing, "/" separated paths relative to dir */
  listFiles(dir: string): Promise<{ rel: string; size: number }[]>;
  mkdirp(p: string): Promise<void>;
  rename(from: string, to: string): Promise<void>;
  rmrf(p: string): Promise<void>;
  writeText(p: string, text: string): Promise<void>;
  readText(p: string): Promise<string>;
  hashFile(p: string): Promise<FileFacts>;
  join(...parts: string[]): string;
}
export interface ImagePort {
  check(path: string): Promise<{ ok: boolean; width: number; height: number; error?: string }>;
}
export interface IndexPort {
  register(comicDir: string): Promise<{ pageCount: number; thumbOk: boolean } | null>;
}

export interface ExtractOptions {
  engines: EnginePort[];
  fs: FsPort;
  image: ImagePort;
  index: IndexPort;
  savedPasswords?: string[];
  password?: string;
  collision: "suffix" | "ask";
  quarantineDir: string;
  parallelism?: number;
  signal?: AbortSignal;
  onProgress?: (p: { phase: string; fraction: number; message: string }) => void;
  onReduceParallelism?: () => void;
  now?: () => number;
}

export type ExtractStatus =
  | "done"
  | "already_extracted"
  | "needs_password"
  | "needs_input"
  | "no_images"
  | "failed"
  | "quarantined"
  | "cancelled";

export interface ExtractResult {
  status: ExtractStatus;
  reason?: string;
  finalDir?: string;
  comics: { dir: string; name: string; pageCount: number }[];
  layers: LayerResult[];
  attempts: AttemptLog[];
  warnings: string[];
  engineOutput?: string;
  passwordUsed?: string;
  uncompressed: number;
  entries: number;
  nestedArchives: string[];
  quarantineDir?: string;
  plan?: ExtractionPlan;
}

class Cancelled extends Error {}

const INVALID_RAW = /[<>:"|?*\u0000-\u001f]/g;
const rawKey = (p: string) =>
  p
    .replace(/\\/g, "/")
    .split("/")
    .filter(Boolean)
    .map((s) => s.normalize("NFC").replace(INVALID_RAW, "_").replace(/[. ]+$/, "").toLowerCase())
    .join("/");

interface Strategy {
  engine: number;
  mode: "full" | "repair";
  perFile?: boolean;
  reduced?: boolean;
  label: string;
}

export async function extractArchive(job: ArchiveJob, o: ExtractOptions): Promise<ExtractResult> {
  const { fs } = o;
  const now = o.now ?? Date.now;
  const L: LayerResult[] = Array.from({ length: 10 }, (_, i) => skipped(i + 1, "Not reached"));
  const set = (r: LayerResult) => (L[r.layer - 1] = r);
  const attempts: AttemptLog[] = [];
  const warnings: string[] = [];
  const par = Math.max(1, o.parallelism ?? 4);
  const stage = fs.join(job.parentDir, `.comiclib-staging-${job.id}`);
  const rawDir = fs.join(stage, "raw");
  const finalRoot = fs.join(stage, "final");
  const prog = (phase: string, fraction: number, message: string) => o.onProgress?.({ phase, fraction, message });
  const chk = () => {
    if (o.signal?.aborted) throw new Cancelled();
  };
  const result = (status: ExtractStatus, extra: Partial<ExtractResult> = {}): ExtractResult => ({
    status,
    comics: [],
    layers: L,
    attempts,
    warnings,
    uncompressed: 0,
    entries: 0,
    nestedArchives: [],
    ...extra,
  });

  try {
    chk();
    if (job.missingParts.length) {
      set(layer(1, "fail", "Volumes are missing", job.missingParts.map((p) => `missing: ${p}`)));
      return result("failed", { reason: `Missing volume(s): ${job.missingParts.join(", ")}` });
    }

    // ---- open, passwords ----------------------------------------------------------------
    prog("open", 0.01, "Reading archive");
    const primary = o.engines[0];
    let pw = o.password;
    let listing = await primary.list(job, pw);
    const needsPw = (l: EngineList) => (!l.ok && !!l.wrongPassword) || (l.ok && l.entries.some((e) => e.encrypted));
    if (needsPw(listing) && !(listing.ok && pw !== undefined)) {
      const cands = [...new Set([o.password, ...(o.savedPasswords ?? [])].filter((x): x is string => !!x))];
      let found: string | undefined;
      for (const c of cands) {
        chk();
        const l = await primary.list(job, c);
        if (l.ok && !l.wrongPassword) {
          const t = await primary.test(job, c);
          if (t.ok) {
            found = c;
            listing = l;
            break;
          }
        }
      }
      if (found === undefined) {
        return result("needs_password", { reason: o.password ? "The supplied password is incorrect" : "Password required", engineOutput: listing.output });
      }
      pw = found;
    } else if (!listing.ok) {
      for (const alt of o.engines.slice(1)) {
        const l = await alt.list(job, pw);
        if (l.ok) {
          listing = l;
          break;
        }
      }
      if (!listing.ok) {
        set(layer(1, "fail", "Archive cannot be opened", (listing.error ?? listing.output).split("\n").filter(Boolean).slice(-8)));
        return result("quarantined", { reason: `Cannot open archive: ${listing.error ?? "unknown error"}`, engineOutput: listing.output });
      }
    } else if (pw !== undefined && listing.entries.some((e) => e.encrypted)) {
      const t = await primary.test(job, pw);
      if (!t.ok) return result("needs_password", { reason: "The supplied password is incorrect", engineOutput: t.output });
    }

    // ---- layer 1: integrity -------------------------------------------------------------
    prog("test", 0.03, "Testing archive integrity");
    let tested = false;
    let lastOut = "";
    for (const e of o.engines) {
      chk();
      const t = await e.test(job, pw);
      lastOut = t.output;
      if (t.ok) {
        set(layerIntegrity(true, t.output, e.id));
        tested = true;
        break;
      }
      if (t.wrongPassword) return result("needs_password", { reason: "Password required", engineOutput: t.output });
      set(layerIntegrity(false, t.output, e.id));
    }
    if (!tested) {
      return result("quarantined", { reason: "Archive integrity test failed with every engine", engineOutput: lastOut });
    }

    // ---- plan ---------------------------------------------------------------------------
    const plan = planExtraction(job.name, listing.entries, { parentLen: job.parentDir.length });
    const base = { uncompressed: plan.totalBytes, entries: plan.files.length, plan, nestedArchives: [] as string[] };
    if (plan.unsafe.length) {
      set(layer(2, "fail", "Archive contains unsafe entries", plan.unsafe.map((u) => `${u.src}: ${u.reason}`)));
      return result("failed", { ...base, reason: `Archive rejected: ${plan.unsafe.length} unsafe entry path(s) (path traversal or symbolic link)` });
    }
    if (plan.imageCount === 0 && plan.nestedArchives.length === 0) {
      return result("no_images", { ...base, reason: "Archive contains no images" });
    }

    // ---- collision ----------------------------------------------------------------------
    const parentNames = await fs.listDir(job.parentDir);
    let targetName = plan.folderName;
    const clash = parentNames.find((n) => n.normalize("NFC").toLowerCase() === targetName.normalize("NFC").toLowerCase());
    if (clash !== undefined) {
      const existing = fs.join(job.parentDir, clash);
      if (await sameAsPlan(fs, existing, plan)) {
        const comics = await registerAll(existing, plan, o, L);
        return result("already_extracted", { ...base, finalDir: existing, comics, reason: "Already extracted and identical", nestedArchives: plan.nestedArchives.map((n) => fs.join(existing, n)) });
      }
      if (o.collision === "ask") return result("needs_input", { ...base, reason: `A different folder named "${clash}" already exists` });
      targetName = uniqueName(plan.folderName, parentNames);
      warnings.push(`Target existed; extracted to "${targetName}"`);
    }
    const finalDir = fs.join(finalRoot, targetName);

    // ---- extract + verify with self-healing ----------------------------------------------
    const strategies: Strategy[] = [
      { engine: 0, mode: "full", label: "extract" },
      { engine: 0, mode: "repair", label: "re-extract failed files" },
      { engine: 1, mode: "full", perFile: true, label: "alternate engine, entry by entry" },
      { engine: 0, mode: "full", reduced: true, label: "single-threaded retry" },
    ];
    const hashCache = new Map<string, FileFacts>();
    const decodeCache = new Map<string, DecodeResult>();
    let verdict: Awaited<ReturnType<typeof verifyStaged>> | null = null;
    let lastError = "";
    let engineOutput = "";
    let good = false;

    for (let i = 0; i < strategies.length; i++) {
      const s = strategies[i];
      chk();
      if (s.mode === "repair" && (!verdict || verdict.failed.size === 0 || verdict.failed.size >= plan.files.length)) continue;
      if (s.reduced) o.onReduceParallelism?.();
      const t0 = now();
      const eng = o.engines[Math.min(s.engine, o.engines.length - 1)];
      prog("extract", 0.05, `Extracting (${s.label})`);
      let repairFiles: PlannedFile[] | undefined;
      if (s.mode === "full") {
        await fs.rmrf(stage);
        await fs.mkdirp(rawDir);
        await fs.mkdirp(finalDir);
        hashCache.clear();
        decodeCache.clear();
      } else {
        repairFiles = plan.files.filter((f) => verdict!.failed.has(f.dest));
        for (const f of repairFiles) {
          await fs.rmrf(fs.join(finalDir, f.dest));
          hashCache.delete(f.dest);
          decodeCache.delete(f.dest);
        }
        await fs.rmrf(rawDir);
        await fs.mkdirp(rawDir);
      }
      const r = await eng.extract(job, rawDir, {
        password: pw,
        only: repairFiles?.map((f) => f.src),
        perFile: s.perFile,
        threads: s.reduced ? 1 : undefined,
        signal: o.signal,
        onProgress: (d, t) => prog("extract", 0.05 + 0.55 * (t ? d / t : 0), "Extracting"),
      });
      chk();
      engineOutput = r.output;
      await restructure(fs, rawDir, finalDir, repairFiles ?? plan.files);
      prog("verify", 0.62, "Verifying extracted files");
      verdict = await verifyStaged(fs, o.image, finalDir, plan, hashCache, decodeCache, par, chk, (f) =>
        prog("verify", 0.62 + 0.3 * f, "Verifying extracted files"),
      );
      const failedNow = verdict.layers.some((l) => l.status === "fail");
      lastError = failedNow ? verdict.layers.filter((l) => l.status === "fail").map((l) => `${l.name}: ${l.summary}`).join("; ") : r.ok ? "" : r.error ?? "engine reported an error";
      attempts.push({ n: attempts.length + 1, engine: eng.id, mode: s.label, ok: !failedNow, error: lastError || undefined, ms: now() - t0 });
      if (!failedNow) {
        good = true;
        break;
      }
      if (verdict.sourceCorrupt) {
        warnings.push("Source archive stores undecodable image data (checksums match); retrying would not help");
        break;
      }
    }

    for (const l of verdict?.layers ?? []) set(l);

    if (!good) {
      let qdir: string | undefined;
      const reason = lastError || "Verification failed";
      try {
        await fs.mkdirp(o.quarantineDir);
        qdir = fs.join(o.quarantineDir, `${job.id}-${targetName}`);
        await fs.rmrf(qdir);
        await fs.writeText(fs.join(stage, "REASON.txt"), `${job.path}\n${reason}\n`);
        await fs.rename(stage, qdir);
      } catch (e) {
        qdir = stage;
        warnings.push(`Could not move partial output to quarantine: ${(e as Error).message}`);
      }
      return result("quarantined", { ...base, reason, quarantineDir: qdir, engineOutput });
    }

    // ---- layer 8: manifests ----------------------------------------------------------------
    prog("finalize", 0.93, "Writing manifest");
    const dirs = plan.comicDirs;
    for (const d of dirs) {
      const own = plan.files.filter((f) => ownerDir(f.dest, dirs) === d);
      const manifest = buildManifest(
        posixBasename(job.path),
        job.size,
        own.map((f) => ({ path: d ? f.dest.slice(d.length + 1) : f.dest, facts: hashCache.get(f.dest)! })),
        now(),
      );
      await fs.writeText(fs.join(finalDir, d, MANIFEST_NAME), JSON.stringify(manifest, null, 1));
    }
    set(dirs.length ? layer(8, "pass", `${dirs.length} manifest(s) written`) : skipped(8, "No comic folders to describe"));

    // ---- atomic move + layer 9 ------------------------------------------------------------
    const target = fs.join(job.parentDir, targetName);
    chk();
    await fs.rename(finalDir, target);
    await fs.rmrf(stage);
    const after = (await fs.listFiles(target)).filter((f) => posixBasename(f.rel) !== MANIFEST_NAME);
    const l9 = compareToManifest(
      {
        version: 1,
        archive: "",
        archiveSize: 0,
        createdAt: 0,
        pageCount: 0,
        totalBytes: 0,
        files: plan.files.map((f) => ({ path: f.dest, size: f.size, sha256: "", crc32: "" })),
      },
      after.map((a) => ({ path: a.rel, size: a.size })),
      9,
    );
    set(l9);

    // ---- layer 10 -------------------------------------------------------------------------
    prog("index", 0.97, "Updating library");
    const comics = await registerAll(target, plan, o, L);
    prog("done", 1, "Done");
    const failed = L.some((l) => l.status === "fail");
    return result(failed ? "failed" : "done", {
      ...base,
      finalDir: target,
      comics,
      passwordUsed: pw,
      engineOutput,
      reason: failed ? L.filter((l) => l.status === "fail").map((l) => `${l.name}: ${l.summary}`).join("; ") : undefined,
      nestedArchives: plan.nestedArchives.map((n) => fs.join(target, n)),
    });
  } catch (e) {
    await fs.rmrf(stage).catch(() => undefined);
    if (e instanceof Cancelled) return result("cancelled", { reason: "Cancelled" });
    return result("failed", { reason: (e as Error).message });
  }
}

function ownerDir(dest: string, dirs: string[]): string | null {
  let best: string | null = null;
  for (const d of dirs) {
    if (d === "" || dest.startsWith(d + "/")) if (best === null || d.length > best.length) best = d;
  }
  return best;
}

async function registerAll(target: string, plan: ExtractionPlan, o: ExtractOptions, L: LayerResult[]) {
  const comics: ExtractResult["comics"] = [];
  const problems: string[] = [];
  for (const d of plan.comicDirs) {
    const abs = d ? o.fs.join(target, d) : target;
    const expected = plan.files.filter((f) => isImageFile(f.dest) && posixDirname(f.dest) === d).length;
    const info = await o.index.register(abs);
    const l = indexLayer(expected, info);
    if (l.status === "fail") problems.push(`${d || plan.folderName}: ${l.details.join("; ") || l.summary}`);
    comics.push({ dir: abs, name: d ? posixBasename(d) : posixBasename(target.replace(/\\/g, "/")), pageCount: info?.pageCount ?? 0 });
  }
  L[9] = problems.length
    ? layer(10, "fail", `${problems.length} comic(s) failed the index cross-check`, problems)
    : plan.comicDirs.length
      ? layer(10, "pass", `${plan.comicDirs.length} comic(s) indexed with valid thumbnails`)
      : skipped(10, "No comic folders");
  return comics;
}

/** True when an existing folder already holds exactly what the archive would produce. */
async function sameAsPlan(fs: FsPort, dir: string, plan: ExtractionPlan): Promise<boolean> {
  const actual = (await fs.listFiles(dir)).filter((f) => !isJunkPath(f.rel));
  if (actual.length !== plan.files.length) return false;
  const have = new Map(actual.map((a) => [a.rel, a.size]));
  for (const f of plan.files) {
    if (have.get(f.dest) !== f.size) return false;
    if (f.crc !== undefined) {
      const h = await fs.hashFile(fs.join(dir, f.dest));
      if ((h.crc32 >>> 0) !== (f.crc >>> 0)) return false;
    }
  }
  return true;
}

/** Move files from the raw engine output to their planned places inside the staging folder. */
async function restructure(fs: FsPort, rawDir: string, finalDir: string, files: PlannedFile[]) {
  const raw = await fs.listFiles(rawDir);
  const byKey = new Map<string, string[]>();
  for (const r of raw) {
    const k = rawKey(r.rel);
    (byKey.get(k) ?? byKey.set(k, []).get(k)!).push(r.rel);
  }
  for (const f of files) {
    const q = byKey.get(rawKey(f.src));
    const rel = q?.shift();
    if (!rel) continue;
    const dest = fs.join(finalDir, f.dest);
    await fs.mkdirp(fs.join(finalDir, posixDirname(f.dest)));
    await fs.rename(fs.join(rawDir, rel), dest);
  }
}

async function verifyStaged(
  fs: FsPort,
  image: ImagePort,
  finalDir: string,
  plan: ExtractionPlan,
  hashCache: Map<string, FileFacts>,
  decodeCache: Map<string, DecodeResult>,
  par: number,
  chk: () => void,
  progress: (f: number) => void,
) {
  const actual = await fs.listFiles(finalDir);
  const sizes = new Map(actual.map((a) => [a.rel, a.size]));
  const planned = plan.files;
  const present = planned.filter((f) => sizes.has(f.dest));
  const failed = new Set<string>();
  for (const f of planned) if (!sizes.has(f.dest)) failed.add(f.dest);

  let n = 0;
  const total = present.length * 2 || 1;
  await mapLimit(present, par, async (f) => {
    chk();
    if (!hashCache.has(f.dest)) hashCache.set(f.dest, await fs.hashFile(fs.join(finalDir, f.dest)));
    progress(++n / total);
  });
  const facts = new Map<string, FileFacts>();
  for (const f of present) facts.set(f.dest, hashCache.get(f.dest)!);
  for (const f of present) {
    const h = facts.get(f.dest)!;
    if (f.crc !== undefined ? (h.crc32 >>> 0) !== (f.crc >>> 0) : h.size !== f.size) failed.add(f.dest);
    else if (h.size !== f.size) failed.add(f.dest);
  }

  const images = present.filter((f) => isImageFile(f.dest));
  const decodes: DecodeResult[] = await mapLimit(images, par, async (f) => {
    chk();
    let d = decodeCache.get(f.dest);
    if (!d) {
      const r = await image.check(fs.join(finalDir, f.dest));
      d = { path: f.dest, ok: r.ok, width: r.width, height: r.height, error: r.error };
      decodeCache.set(f.dest, d);
    }
    progress(++n / total);
    return d;
  });
  const decodeBad = decodes.filter((d) => !d.ok || d.width <= 0 || d.height <= 0);
  const zero = present.filter((f) => (sizes.get(f.dest) ?? 0) === 0 && f.size > 0);

  const layers: LayerResult[] = [
    compareListing(planned, actual.map((a) => a.rel)),
    compareHashes(planned, facts),
    compareTotals(
      { count: planned.length, bytes: plan.totalBytes },
      { count: actual.length, bytes: actual.reduce((s, a) => s + a.size, 0) },
    ),
    decodeLayer(decodes),
    pageSequenceLayer(planned.map((f) => f.dest)),
    smallFilesLayer(present.map((f) => ({ path: f.dest, size: sizes.get(f.dest) ?? 0 }))),
  ];
  void zero;
  const crcMap = new Map(planned.map((f) => [f.dest, f.crc]));
  const sourceCorrupt =
    failed.size === 0 && decodeBad.length > 0 && actual.length === planned.length && decodeBad.every((d) => crcMap.get(d.path) !== undefined);
  for (const d of decodeBad) if (!sourceCorrupt) failed.add(d.path);
  return { layers, failed, sourceCorrupt };
}
