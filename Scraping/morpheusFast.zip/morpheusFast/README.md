# morpheusFast

**Ultra-fast multi-engine search scraper with maximum curl_cffi stealth.**

morpheusFast is a Python toolkit that:

- Searches **Google**, **Bing**, **DuckDuckGo**, **Yahoo**, **Brave**, and **Presearch** in parallel.
- **Auto-failovers** when an engine is captcha'd, throttled, or times out.
- **Fully scrapes** the body text of every result page, ready for an LLM to read.
- Uses **curl_cffi** with `chrome124` impersonation → real-Chrome TLS/JA3 fingerprint.
- Skips **reddit.com / youtube.com / facebook.com / instagram.com** by default.
- Targets **50 fully-scraped results in under 15 seconds** on a typical home connection.
- 0 API keys, 0 paid services, 0 headless browsers.

---

## Table of Contents

1. [Install](#install)
2. [Quick start](#quick-start)
3. [CLI reference](#cli-reference)
4. [Python API](#python-api)
5. [How it works](#how-it-works)
6. [Configuration](#configuration)
7. [Performance tuning](#performance-tuning)
8. [Troubleshooting](#troubleshooting)
9. [Project layout](#project-layout)
10. [License](#license)

---

## Install

### Linux / macOS / WSL

```bash
# Option A: virtualenv (recommended)
cd morpheusFast
./install.sh

# Option B: system-wide (needs sudo on most systems)
sudo ./install.sh --system

# Option C: user site-packages
./install.sh --user
```

### Windows (PowerShell)

```powershell
cd morpheusFast
.\install.ps1
# or
.\install.ps1 -Mode user
```

### Manual install

```bash
pip install -r requirements.txt
pip install -e .
```

Requirements: Python 3.10+, `curl_cffi>=0.7.0`, `beautifulsoup4>=4.12.0`.

Verify install:

```bash
morpheus --version
morpheus "openai gpt 5" --count 5 --format urls
```

---

## Quick start

### CLI

```bash
# 1 query → 50 fully-fetched pages, JSON to stdout
morpheus "what is rlhf" --count 50

# 5 queries × 10 each → 50 unique scraped pages, save to file
morpheus "q1" "q2" "q3" "q4" "q5" --per-query 10 --count 50 -o results.json

# URLs only (no page scraping, very fast)
morpheus "openai" --count 30 --no-fetch --format urls

# Plain-text bodies, one file ready for your LLM
morpheus "transformer attention" --count 20 --format text -o corpus.txt

# Markdown with titles + URLs + body
morpheus "rust async runtime" --count 10 --format markdown -o out.md
```

### Python

```python
import asyncio
from morpheus import Morpheus

async def main():
    async with Morpheus() as m:
        # 1 query → 50 fully-scraped results
        results = await m.search("what is rlhf", count=50)
        for r in results:
            print(r.url, r.engine, len(r.text), r.fetch_time)

asyncio.run(main())
```

```python
# 5 queries × 10 each → 50 unique results
results = await m.search_many(
    ["q1", "q2", "q3", "q4", "q5"],
    per_query=10,
    total=50,
)
```

---

## CLI reference

```
morpheus [-h] [-n COUNT] [--per-query N] [--format FMT] [-o FILE]
         [--no-fetch] [--engines E1 E2 ...] [--concurrency N]
         [--timeout S] [--max-text N] [--blocked D1 D2 ...]
         [--allow-reddit] [--version]
         queries [queries ...]
```

| Flag             | Default | Description |
|------------------|---------|-------------|
| `queries`        | —       | One or more search queries. |
| `-n/--count`     | `10`    | Total unique results to return. |
| `--per-query`    | auto    | Results per query (multi-query mode). Default = count ÷ len(queries). |
| `--format`       | `json`  | Output: `json` / `text` / `urls` / `markdown`. |
| `-o/--out`       | stdout  | Write to this file. |
| `--no-fetch`     | off     | Skip page scraping; only return URLs. |
| `--engines`      | all     | Override engine order, e.g. `--engines bing duckduckgo google`. |
| `--concurrency`  | `25`    | Max concurrent page fetches. |
| `--timeout`      | `10`    | Per-page fetch timeout (seconds). |
| `--max-text`     | `20000` | Max extracted text chars per page. |
| `--blocked`      | —       | Extra domains to block. |
| `--allow-reddit` | off     | Do NOT block reddit.com (blocked by default). |

---

## Python API

### `Morpheus(config: Config | None = None)`

Async context manager that owns the HTTP session and router.

```python
async with Morpheus() as m:
    ...
```

#### `await m.search(query, count=10, *, fetch=True) -> list[FetchedResult]`

Single-query mode.

#### `await m.search_many(queries, per_query, total=None, *, fetch=True) -> list[FetchedResult]`

Multi-query mode. Runs all queries in parallel, dedupes by host+path,
returns up to `total` results.

### `FetchedResult`

```python
@dataclass
class FetchedResult:
    url: str
    title: str
    text: str          # cleaned body text
    engine: str        # which engine surfaced this URL
    status: int        # HTTP status (0 if fetch failed)
    fetch_time: float  # seconds
    bytes: int         # raw response body bytes
    error: str | None  # None if successful
```

Call `.to_dict()` to serialize.

### `Config`

```python
from morpheus import Config, Morpheus

cfg = Config(
    engine_order=("google", "bing", "duckduckgo", "brave", "presearch"),
    blocked_domains=("reddit.com", "youtube.com", "facebook.com", "instagram.com"),
    max_concurrent_fetches=25,
    max_concurrent_engines=5,
    search_timeout=8.0,
    page_timeout=10.0,
    impersonate="chrome124",
    search_retries=1,
    page_retries=1,
    min_text_length=200,
    max_text_length=20_000,
    user_agent=None,
    extra_headers={},
)
cfg = cfg.with_blocked(["pinterest.com", "quora.com"])  # add blocks
```

---

## How it works

```
                  ┌──────────────┐
                  │  User Query  │
                  └──────┬───────┘
                         │
              ┌──────────▼───────────┐
              │   Router (parallel)  │
              └──────────┬───────────┘
        ┌────────────────┼────────────────┐
        ▼                ▼                ▼
   ┌────────┐       ┌────────┐       ┌────────┐
   │ Google │       │  Bing  │       │  DDG   │ ...
   └────┬───┘       └────┬───┘       └────┬───┘
        │                │                │
        │  (captcha?)    │                │
        ▼                ▼                ▼
   ┌─────────────────────────────────────────┐
   │  Dedupe + filter blocked domains        │
   │  If short, failover to next engine      │
   └────────────────────┬────────────────────┘
                        │
              ┌─────────▼──────────┐
              │ Concurrent Fetch   │  (25 parallel, chrome124 TLS)
              │ + Extract clean    │
              │   text (BS4)       │
              └─────────┬──────────┘
                        │
                ┌───────▼────────┐
                │ FetchedResult[] │
                └────────────────┘
```

### Stealth

- `curl_cffi` with `impersonate="chrome124"` reproduces Chrome 124's exact TLS ClientHello, JA3 fingerprint, and HTTP/2 SETTINGS frame.
- Realistic Chrome headers (`Sec-Ch-Ua`, `Sec-Fetch-*`, `Accept-*`).
- Rotating `Accept-Language` from a small pool.
- `Referer` set to each engine's own domain (same-origin navigation).
- Reused connection pool → fewer handshakes, faster.

### Routing

1. All available engines queried in parallel.
2. Each engine returns up to `count` URLs.
3. URLs deduped by `(host, path)`.
4. Blocked domains removed.
5. If still short of `count`:
   - Available engines retried with `count * 2` ask.
   - Tired engines retried once.
6. Final URLs passed to concurrent fetcher.

---

## Configuration

### Engine order

Default: `google → bing → duckduckgo → yahoo → brave → presearch`

Override via CLI:

```bash
morpheus "test" --engines bing duckduckgo yahoo
```

Or via Python:

```python
cfg = Config(engine_order=("bing", "duckduckgo", "yahoo"))
```

### Blocked domains

Built-in: `reddit.com`, `youtube.com`, `facebook.com`, `instagram.com` (and their `www.`/`m.`/`old.` subdomains).

Add more:

```bash
morpheus "test" --blocked pinterest.com quora.com
```

```python
cfg = cfg.with_blocked(["pinterest.com", "quora.com"])
```

Re-enable Reddit:

```bash
morpheus "test" --allow-reddit
```

---

## Performance tuning

The default config is calibrated for **50 pages in under 15 seconds** on a typical 50 Mbps home connection.

To go faster:

```bash
morpheus "test" --count 50 --concurrency 50 --timeout 8
```

```python
cfg = Config(
    max_concurrent_fetches=50,   # default 25
    page_timeout=8.0,            # default 10
    max_text_length=10_000,      # smaller → faster extraction
)
```

To be gentler (e.g., behind a corporate proxy):

```bash
morpheus "test" --count 20 --concurrency 10 --timeout 20
```

### Tips for max speed

- Increase `--concurrency` until you hit network saturation (typically 30–60).
- Lower `--max-text` if your AI doesn't need long pages.
- Use `--no-fetch` if you only need URLs (≈1–2s for 50 URLs).
- Use multiple queries × small `per-query` rather than one query × large `count` — engines paginate faster than they aggregate.

---

## Troubleshooting

### `ImportError: curl_cffi is required`

Run `./install.sh` (or `pip install -r requirements.txt`).

### Google returns 0 results

Google is the most captcha-happy engine. If it returns nothing, morpheusFast automatically falls back to Bing/DDG/Brave/Presearch. To force a different engine order:

```bash
morpheus "test" --engines bing duckduckgo brave presearch google
```

### All engines return 0 results

Likely causes:
- Network egress blocked (corporate firewall, country-level censorship).
- Rate-limited at IP level (wait 5 min and retry).
- `curl_cffi` not properly impersonating (check `curl_cffi.__version__` ≥ 0.7.0).

### Some pages return `error: low-text`

This is expected for some sites (paywalled news, JS-only SPAs, login walls). The URL is still returned; your AI can decide whether to follow up.

### Some pages return `error: http-403`

The target site itself is blocking (Cloudflare, etc.). curl_cffi bypasses most TLS fingerprinting but cannot solve JS challenges. The URL is still in the result set; you can retry it later or with a different egress IP.

### Want to add a new engine?

Subclass `SearchEngine` in `morpheus/engines/` and register it in `ENGINES` dict.

---

## Project layout

```
morpheusFast/
├── README.md                  # this file
├── skill.md                   # quick-reference command sheet
├── pyproject.toml
├── requirements.txt
├── install.sh                 # Linux/macOS/WSL installer
├── install.ps1                # Windows installer
└── morpheus/
    ├── __init__.py
    ├── cli.py                 # CLI entry point
    ├── client.py              # Morpheus orchestrator
    ├── config.py              # Config dataclass + defaults
    ├── http_client.py         # curl_cffi stealth wrapper
    ├── extractor.py           # HTML → clean text
    ├── router.py              # multi-engine failover
    └── engines/
        ├── __init__.py        # registry
        ├── base.py            # SearchEngine ABC + dedupe
        ├── google.py
        ├── bing.py
        ├── duckduckgo.py
        ├── brave.py
        ├── presearch.py
        └── yahoo.py
```

---

## License

MIT.
