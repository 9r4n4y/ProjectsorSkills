#!/usr/bin/env bash
# morpheusFast installer - works on Linux, macOS, and WSL.
# Usage:
#   ./install.sh            # install into a venv at ./.venv
#   ./install.sh --system   # install into the active Python (requires sudo)
#   ./install.sh --user     # install into the user site-packages
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

MODE="${1:-venv}"
PYTHON="${PYTHON:-python3}"

if ! command -v "$PYTHON" >/dev/null 2>&1; then
    echo "ERROR: $PYTHON not found. Install Python 3.10+ first." >&2
    exit 1
fi

echo "Using Python: $($PYTHON --version)"

case "$MODE" in
    --system)
        echo "Installing morpheusFast system-wide..."
        $PYTHON -m pip install --upgrade pip
        $PYTHON -m pip install -r requirements.txt
        $PYTHON -m pip install .
        ;;
    --user)
        echo "Installing morpheusFast into user site-packages..."
        $PYTHON -m pip install --user --upgrade pip
        $PYTHON -m pip install --user -r requirements.txt
        $PYTHON -m pip install --user .
        ;;
    venv|--venv|"")
        echo "Creating virtualenv at $SCRIPT_DIR/.venv ..."
        $PYTHON -m venv .venv
        # shellcheck disable=SC1091
        source .venv/bin/activate
        pip install --upgrade pip
        pip install -r requirements.txt
        pip install -e .
        echo
        echo "Done. Activate with:"
        echo "    source $SCRIPT_DIR/.venv/bin/activate"
        echo "Then run:"
        echo "    morpheus 'your search query' --count 10"
        ;;
    *)
        echo "Unknown mode: $MODE" >&2
        echo "Usage: $0 [--system|--user|venv]" >&2
        exit 1
        ;;
esac

echo
echo "morpheusFast installation complete."
