"""HTML to clean-text extractor.

Uses BeautifulSoup if available (more accurate), otherwise falls back
to a fast regex-based stripper. Either way the output is plain text
suitable for an LLM context window.
"""
from __future__ import annotations

import re
from html import unescape

try:
    from bs4 import BeautifulSoup  # type: ignore
    _HAS_BS4 = True
except ImportError:  # pragma: no cover
    _HAS_BS4 = False


# Tags whose content is useless for AI text consumption.
_DROP_TAGS = (
    "script",
    "style",
    "noscript",
    "iframe",
    "svg",
    "canvas",
    "nav",
    "footer",
    "header",
    "form",
    "button",
    "aside",
    "figure",
    "figcaption",
    "template",
)

# Tags that should be replaced with a newline boundary so that
# adjacent text doesn't get glued together.
_BLOCK_TAGS = (
    "p",
    "br",
    "div",
    "section",
    "article",
    "h1",
    "h2",
    "h3",
    "h4",
    "h5",
    "h6",
    "li",
    "tr",
    "td",
    "th",
    "ul",
    "ol",
    "table",
    "blockquote",
    "pre",
)

_WS_RE = re.compile(r"[ \t]+")
_NL_RE = re.compile(r"\n{3,}")


def extract_text(html: str, max_chars: int = 20_000) -> str:
    """Extract clean readable text from raw HTML."""
    if not html:
        return ""

    if _HAS_BS4:
        text = _extract_with_bs4(html)
    else:
        text = _extract_with_regex(html)

    # Collapse whitespace.
    text = _WS_RE.sub(" ", text)
    text = _NL_RE.sub("\n\n", text).strip()
    if len(text) > max_chars:
        text = text[:max_chars].rsplit(" ", 1)[0] + "…"
    return text


def extract_title(html: str) -> str:
    """Extract the <title> of a page."""
    if not html:
        return ""
    m = re.search(r"<title[^>]*>([^<]*)</title>", html, re.IGNORECASE | re.DOTALL)
    if m:
        return unescape(m.group(1)).strip()
    if _HAS_BS4:
        try:
            soup = BeautifulSoup(html, "html.parser")
            if soup.title and soup.title.string:
                return soup.title.string.strip()
        except Exception:
            pass
    return ""


# ---------------------------------------------------------------------------
# BS4 implementation
# ---------------------------------------------------------------------------
def _extract_with_bs4(html: str) -> str:
    try:
        soup = BeautifulSoup(html, "html.parser")
    except Exception:
        return _extract_with_regex(html)

    # Remove clearly useless tags.
    for tag_name in _DROP_TAGS:
        for tag in soup.find_all(tag_name):
            tag.decompose()

    # Prefer <main> or <article> if present - this avoids nav / sidebar
    # boilerplate that survived the DROP pass.
    main = soup.find("main") or soup.find("article")
    target = main if main is not None else soup

    # Insert newlines after block-level elements.
    for tag_name in _BLOCK_TAGS:
        for tag in target.find_all(tag_name):
            tag.append("\n")

    text = target.get_text(separator=" ", strip=False)
    return text


# ---------------------------------------------------------------------------
# Regex fallback (no BS4)
# ---------------------------------------------------------------------------
_COMMENT_RE = re.compile(r"<!--.*?-->", re.DOTALL)
_TAG_RE = re.compile(r"<[^>]+>")


def _extract_with_regex(html: str) -> str:
    # Strip comments.
    html = _COMMENT_RE.sub("", html)
    # Strip script/style/etc blocks entirely.
    for tag in _DROP_TAGS:
        html = re.sub(
            rf"<{tag}\b[^>]*>.*?</{tag}>",
            "",
            html,
            flags=re.IGNORECASE | re.DOTALL,
        )
    # Insert newlines for block-level boundaries.
    for tag in _BLOCK_TAGS:
        html = re.sub(
            rf"</{tag}\s*>",
            "\n",
            html,
            flags=re.IGNORECASE,
        )
        html = re.sub(
            rf"<{tag}\b[^>]*>",
            "\n",
            html,
            flags=re.IGNORECASE,
        )
    # Strip remaining tags.
    text = _TAG_RE.sub(" ", html)
    return unescape(text)
