"""Morpheus - main entry point.

Combines the multi-engine :class:`Router` with the concurrent page
scraper to deliver fully-fetched page bodies ready for an LLM to read.

Typical usage
-------------
>>> import asyncio
>>> from morpheus import Morpheus
>>> async def main():
...     async with Morpheus() as m:
...         results = await m.search("what is quantum entanglement", count=50)
...         for r in results:
...             print(r.url, len(r.text))
>>> asyncio.run(main())
"""
from __future__ import annotations

import asyncio
import time
from dataclasses import dataclass, field
from typing import Iterable

from .config import Config
from .engines import SearchResult
from .extractor import extract_text, extract_title
from .http_client import HttpClient, HttpResponse
from .router import Router


@dataclass
class FetchedResult:
    """A fully scraped search result, ready for AI consumption."""

    url: str
    title: str
    text: str
    engine: str
    status: int
    fetch_time: float
    bytes: int
    error: str | None = None

    def to_dict(self) -> dict:
        return {
            "url": self.url,
            "title": self.title,
            "text": self.text,
            "engine": self.engine,
            "status": self.status,
            "fetch_time": round(self.fetch_time, 3),
            "bytes": self.bytes,
            "error": self.error,
        }


class Morpheus:
    """Main orchestrator: search + fetch + extract."""

    def __init__(self, config: Config | None = None):
        self.config = config or Config()
        self.http = HttpClient(
            impersonate=self.config.impersonate,
            user_agent=self.config.user_agent,
            extra_headers=self.config.extra_headers,
        )
        self.router = Router(self.http, self.config)

    async def __aenter__(self) -> "Morpheus":
        await self.http.start()
        return self

    async def __aexit__(self, *exc):
        await self.http.close()

    async def search(
        self,
        query: str,
        count: int = 10,
        *,
        fetch: bool = True,
    ) -> list[FetchedResult]:
        """Search a single query and fully scrape up to ``count`` results.

        Parameters
        ----------
        query:
            The search string.
        count:
            Number of unique result pages to fully fetch.
        fetch:
            If False, only the discovery phase runs and ``text`` will
            be empty. Useful when you just want URLs.
        """
        t0 = time.perf_counter()
        results = await self.router.search(query, count)
        if not fetch:
            return [
                FetchedResult(
                    url=r.url,
                    title="",
                    text="",
                    engine=r.engine,
                    status=0,
                    fetch_time=0.0,
                    bytes=0,
                    error="not-fetched",
                )
                for r in results[:count]
            ]
        fetched = await self._fetch_all(results[:count])
        return fetched

    async def search_many(
        self,
        queries: Iterable[str],
        per_query: int,
        total: int | None = None,
        *,
        fetch: bool = True,
    ) -> list[FetchedResult]:
        """Run multiple queries and return ``total`` fully-fetched results.

        Examples
        --------
        >>> # 5 queries, 10 results each = 50 unique scraped pages
        >>> await m.search_many(["q1", "q2", "q3", "q4", "q5"], per_query=10)
        >>> # 1 query, 50 results
        >>> await m.search_many(["q1"], per_query=50)
        """
        queries = list(queries)
        if not queries:
            return []
        if total is None:
            total = per_query * len(queries)

        results = await self.router.search_many(queries, per_query, total)
        if not fetch:
            return [
                FetchedResult(
                    url=r.url,
                    title="",
                    text="",
                    engine=r.engine,
                    status=0,
                    fetch_time=0.0,
                    bytes=0,
                    error="not-fetched",
                )
                for r in results[:total]
            ]
        return await self._fetch_all(results[:total])

    # ------------------------------------------------------------------
    async def _fetch_all(self, results: list[SearchResult]) -> list[FetchedResult]:
        """Fully scrape a list of search results in parallel."""
        if not results:
            return []

        urls = [r.url for r in results]
        sem = asyncio.Semaphore(self.config.max_concurrent_fetches)

        async def one(r: SearchResult) -> FetchedResult:
            async with sem:
                return await self._fetch_one(r)

        return await asyncio.gather(*(one(r) for r in results))

    async def _fetch_one(self, r: SearchResult) -> FetchedResult:
        t0 = time.perf_counter()
        try:
            resp = await self.http.get(
                r.url,
                timeout=self.config.page_timeout,
                retries=self.config.page_retries,
            )
        except Exception as exc:
            return FetchedResult(
                url=r.url,
                title="",
                text="",
                engine=r.engine,
                status=0,
                fetch_time=time.perf_counter() - t0,
                bytes=0,
                error=str(exc)[:200],
            )

        text = extract_text(resp.text, max_chars=self.config.max_text_length)
        title = extract_title(resp.text) or r.title

        # If extraction yielded too little, mark it.
        if len(text) < self.config.min_text_length:
            error = "low-text" if resp.ok else f"http-{resp.status}"
        else:
            error = None if resp.ok else f"http-{resp.status}"

        return FetchedResult(
            url=str(resp.url),
            title=title,
            text=text,
            engine=r.engine,
            status=resp.status,
            fetch_time=time.perf_counter() - t0,
            bytes=len(resp.body),
            error=error,
        )
