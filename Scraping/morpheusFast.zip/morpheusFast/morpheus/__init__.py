"""
morpheusFast - Ultra-fast multi-engine search scraper.

A high-concurrency search-and-scrape toolkit that:
  * Queries Google, DuckDuckGo, Bing, Brave and Presearch.
  * Auto-failovers when an engine is captcha'd or throttled.
  * Fully scrapes result page bodies for AI consumption.
  * Skips Reddit / YouTube / Facebook / Instagram by default.
  * Uses curl_cffi with maximum browser impersonation for stealth.

Public API
----------
>>> from morpheus import Morpheus
>>> async with Morpheus() as m:
...     results = await m.search("openai gpt-5", count=50)
"""

from .client import Morpheus
from .config import Config

__version__ = "1.0.0"
__all__ = ["Morpheus", "Config"]
