"""Global configuration for morpheusFast."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Iterable


# Domains that are explicitly blacklisted because they aggressively
# block scraping or render content via JS only.
DEFAULT_BLOCKED_DOMAINS: tuple[str, ...] = (
    "reddit.com",
    "old.reddit.com",
    "www.reddit.com",
    "youtube.com",
    "m.youtube.com",
    "youtu.be",
    "facebook.com",
    "m.facebook.com",
    "instagram.com",
    "www.instagram.com",
)


# Order in which engines are tried. Google first because it has the
# best relevance, then we fall back if captcha / throttle / timeout.
# Yahoo uses Bing's index but is independently scrapeable.
DEFAULT_ENGINE_ORDER: tuple[str, ...] = (
    "google",
    "bing",
    "duckduckgo",
    "yahoo",
    "brave",
    "presearch",
)


@dataclass
class Config:
    """Runtime configuration for a Morpheus instance."""

    # --- Engine / routing -------------------------------------------------
    engine_order: tuple[str, ...] = DEFAULT_ENGINE_ORDER
    blocked_domains: tuple[str, ...] = DEFAULT_BLOCKED_DOMAINS

    # --- Concurrency ------------------------------------------------------
    # How many pages to fetch in parallel when fully scraping result URLs.
    # 50 is aggressive but safe - real browsers do 6 concurrent but we're
    # impersonating many clients. Drop to 25 on slow networks.
    max_concurrent_fetches: int = 50

    # How many engines to query in parallel during the discovery phase.
    max_concurrent_engines: int = 6

    # --- Timeouts (seconds) ----------------------------------------------
    # Tight timeouts so the discovery + fetch phases together stay <15s.
    search_timeout: float = 6.0
    page_timeout: float = 8.0

    # --- curl_cffi impersonation -----------------------------------------
    # "chrome124" is the most recent chrome profile curl_cffi ships and
    # produces a TLS / JA3 fingerprint indistinguishable from real Chrome.
    impersonate: str = "chrome124"

    # --- Retry / robustness ----------------------------------------------
    search_retries: int = 1
    page_retries: int = 1

    # --- Content extraction ----------------------------------------------
    # Drop pages smaller than this many characters of extracted text -
    # they are usually soft-404s or login walls.
    min_text_length: int = 200

    # Maximum characters of extracted text per page (truncated to keep
    # memory bounded when feeding 50 pages into an LLM context).
    max_text_length: int = 20_000

    # User-Agent override (None = let curl_cffi pick from impersonation).
    user_agent: str | None = None

    # Extra headers applied to every request.
    extra_headers: dict[str, str] = field(default_factory=dict)

    # ------------------------------------------------------------------
    def is_blocked(self, host: str) -> bool:
        """Return True if a hostname should be skipped."""
        host = host.lower().lstrip(".")
        for bad in self.blocked_domains:
            if host == bad or host.endswith("." + bad):
                return True
        return False

    def with_blocked(self, extras: Iterable[str]) -> "Config":
        """Return a new Config with additional blocked domains."""
        merged = tuple(dict.fromkeys((*self.blocked_domains, *extras)))
        return Config(
            engine_order=self.engine_order,
            blocked_domains=merged,
            max_concurrent_fetches=self.max_concurrent_fetches,
            max_concurrent_engines=self.max_concurrent_engines,
            search_timeout=self.search_timeout,
            page_timeout=self.page_timeout,
            impersonate=self.impersonate,
            search_retries=self.search_retries,
            page_retries=self.page_retries,
            min_text_length=self.min_text_length,
            max_text_length=self.max_text_length,
            user_agent=self.user_agent,
            extra_headers=dict(self.extra_headers),
        )
