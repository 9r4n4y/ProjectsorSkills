"""Brave Search scraper."""
from __future__ import annotations

import re
from urllib.parse import quote_plus

from .base import SearchEngine, SearchResult


class BraveEngine(SearchEngine):
    name = "brave"
    home_url = "https://search.brave.com/"

    _HREF_RE = re.compile(
        r'<a[^>]+href="(https?://[^"]+)"[^>]*>', re.IGNORECASE
    )

    async def search(self, query: str, count: int = 10) -> list[SearchResult]:
        url = (
            "https://search.brave.com/search?q=" + quote_plus(query)
            + "&source=web&spellcheck=1"
        )
        # Brave is aggressive about rate-limiting. We try with our default
        # impersonation; if we get 429 or a connection error, we just
        # return [] and let the router failover.
        try:
            resp = await self.http.get(
                url,
                timeout=self.search_timeout,
                retries=1,
                extra_headers={
                    "Referer": "https://search.brave.com/",
                    "Sec-Fetch-Site": "same-origin",
                    "Accept-Language": "en-US,en;q=0.5",
                },
            )
        except Exception:
            return []
        if not resp.ok:
            return []
        if self._is_captcha(resp.text.lower()):
            return []
        # Brave sometimes serves a "verify you're human" page that returns 200.
        if "verify you" in resp.text.lower() or "challenge" in resp.text.lower()[:1000]:
            return []
        return self._parse(resp.text, count)

    def _parse(self, html: str, count: int) -> list[SearchResult]:
        results: list[SearchResult] = []
        seen: set[str] = set()

        for m in self._HREF_RE.finditer(html):
            raw = m.group(1)
            clean = self._clean_url(raw)
            if not clean:
                continue
            host = clean.split("/", 3)[2] if "://" in clean else ""
            if (
                host.endswith("brave.com")
                or host.endswith("brave.so")
                or host == ""
            ):
                continue
            key = clean.split("#", 1)[0]
            if key in seen:
                continue
            seen.add(key)
            results.append(
                SearchResult(
                    url=clean,
                    title="",
                    snippet="",
                    engine=self.name,
                    rank=len(results) + 1,
                )
            )
            if len(results) >= count * 2:
                break

        return results[:count]
