"""Presearch search scraper.

Presearch is a decentralized search engine that returns a clean SERP
without aggressive bot detection, making it a reliable last-resort
fallback.
"""
from __future__ import annotations

import re
from urllib.parse import quote_plus

from .base import SearchEngine, SearchResult


class PresearchEngine(SearchEngine):
    name = "presearch"
    home_url = "https://presearch.com/"

    _HREF_RE = re.compile(r'href="(https?://[^"]+)"', re.IGNORECASE)

    async def search(self, query: str, count: int = 10) -> list[SearchResult]:
        url = "https://presearch.com/search?q=" + quote_plus(query)
        # Presearch is behind Cloudflare and frequently returns 403 to
        # data-center IPs. We try, and if blocked we return [] so the
        # router can fall back to other engines.
        try:
            resp = await self.http.get(
                url,
                timeout=self.search_timeout,
                retries=1,
                extra_headers={
                    "Referer": "https://presearch.com/",
                    "Sec-Fetch-Site": "same-origin",
                    "Accept-Language": "en-US,en;q=0.9",
                },
            )
        except Exception:
            return []
        if not resp.ok:
            return []
        if self._is_captcha(resp.text.lower()):
            return []
        # Cloudflare challenge pages have "Just a moment" in the title.
        if "just a moment" in resp.text.lower()[:500]:
            return []
        return self._parse(resp.text, count)

    def _parse(self, html: str, count: int) -> list[SearchResult]:
        results: list[SearchResult] = []
        seen: set[str] = set()

        for m in self._HREF_RE.finditer(html):
            raw = m.group(1)
            clean = self._clean_url(raw)
            if not clean:
                continue
            host = clean.split("/", 3)[2] if "://" in clean else ""
            if host.endswith("presearch.com") or host == "":
                continue
            key = clean.split("#", 1)[0]
            if key in seen:
                continue
            seen.add(key)
            results.append(
                SearchResult(
                    url=clean,
                    title="",
                    snippet="",
                    engine=self.name,
                    rank=len(results) + 1,
                )
            )
            if len(results) >= count * 2:
                break

        return results[:count]
