"""DuckDuckGo search scraper.

Uses the GET endpoint at https://html.duckduckgo.com/html/?q=... which
returns a clean HTML page with result URLs encoded as ``uddg=`` params.

DDG's HTML endpoint returns ~10-25 results per page. The router asks
for 2x the target count and dedupes across engines, so this is usually
enough. For >25 unique results from a single query, the router will
naturally fall back to other engines (Bing, Yahoo, Presearch).
"""
from __future__ import annotations

import re
from urllib.parse import quote_plus, unquote

from .base import SearchEngine, SearchResult


class DuckDuckGoEngine(SearchEngine):
    name = "duckduckgo"
    home_url = "https://duckduckgo.com/"

    # DDG wraps result URLs in /l/?uddg=... encoding.
    _UDDG_RE = re.compile(r"uddg=([^&\"']+)", re.IGNORECASE)
    # Fallback absolute hrefs.
    _HREF_RE = re.compile(r'href="(https?://(?!duckduckgo\.com)[^"]+)"', re.IGNORECASE)

    async def search(self, query: str, count: int = 10) -> list[SearchResult]:
        url = (
            "https://html.duckduckgo.com/html/?q=" + quote_plus(query)
            + "&kl=us-en"
        )
        try:
            resp = await self.http.get(
                url,
                timeout=self.search_timeout,
                retries=1,
                extra_headers={
                    "Referer": "https://duckduckgo.com/",
                    "Sec-Fetch-Site": "same-origin",
                    "Accept-Language": "en-US,en;q=0.9",
                },
            )
        except Exception:
            return []
        if not resp.ok:
            return []
        if self._is_captcha(resp.text.lower()):
            return []
        return self._parse(resp.text, count)

    def _parse(self, html: str, count: int) -> list[SearchResult]:
        results: list[SearchResult] = []
        seen: set[str] = set()

        # Primary: uddg-encoded target URLs.
        for m in self._UDDG_RE.finditer(html):
            raw = unquote(m.group(1))
            clean = self._clean_url(raw)
            if not clean:
                continue
            host = clean.split("/", 3)[2] if "://" in clean else ""
            if host.endswith("duckduckgo.com"):
                continue
            key = clean.split("#", 1)[0]
            if key in seen:
                continue
            seen.add(key)
            results.append(
                SearchResult(
                    url=clean,
                    title="",
                    snippet="",
                    engine=self.name,
                    rank=len(results) + 1,
                )
            )
            if len(results) >= count * 2:
                break

        # Fallback: scan absolute hrefs.
        if len(results) < count:
            for m in self._HREF_RE.finditer(html):
                raw = m.group(1)
                clean = self._clean_url(raw)
                if not clean:
                    continue
                host = clean.split("/", 3)[2] if "://" in clean else ""
                if host.endswith("duckduckgo.com") or host == "":
                    continue
                key = clean.split("#", 1)[0]
                if key in seen:
                    continue
                seen.add(key)
                results.append(
                    SearchResult(
                        url=clean,
                        title="",
                        snippet="",
                        engine=self.name,
                        rank=len(results) + 1,
                    )
                )
                if len(results) >= count * 2:
                    break

        return results[:count]
