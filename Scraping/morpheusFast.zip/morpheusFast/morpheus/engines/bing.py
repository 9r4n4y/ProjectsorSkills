"""Bing search scraper.

Bing's HTML SERP contains the actual result URLs in two reliable places:
  1. ``<li class="b_algo">`` blocks - each contains an ``<a href>``
     pointing to a ``bing.com/ck/a?...&u=a1<base64-encoded real URL>``
     redirect. We scope our extraction to these blocks to avoid picking
     up "People also ask" / "Related searches" / sidebar links.
  2. ``<cite>`` tags showing the display URL (e.g. ``openai.com``).

We prefer strategy 1 because it gives the full URL with path.
"""
from __future__ import annotations

import base64
import re
from urllib.parse import quote_plus, unquote
from html import unescape as html_unescape

from .base import SearchEngine, SearchResult


class BingEngine(SearchEngine):
    name = "bing"
    home_url = "https://www.bing.com/"

    # Bing wraps organic result URLs in /ck/a?...&u=a1<base64-encoded URL>
    # The & may be HTML-escaped as &amp; in the raw HTML.
    _CK_U_RE = re.compile(r"(?:&amp;|&)u=a1([^&\"']+)", re.IGNORECASE)
    # <cite> tags contain plain-text display URLs (domain only usually).
    _CITE_RE = re.compile(r"<cite[^>]*>([^<]+)</cite>", re.IGNORECASE)
    # Fallback: absolute https hrefs that aren't bing.com / microsoft.com.
    _HREF_RE = re.compile(
        r'href="(https?://(?!www\.bing\.com/ck|r\.bing\.com|go\.microsoft\.|www\.microsoft\.com)[^"]+)"',
        re.IGNORECASE,
    )

    async def search(self, query: str, count: int = 10) -> list[SearchResult]:
        url = (
            "https://www.bing.com/search?q=" + quote_plus(query)
            + "&count=" + str(max(count * 3, 30))
            + "&mkt=en-US&setlang=en-US&cc=US&form=QBLH"
        )
        try:
            resp = await self.http.get(
                url,
                timeout=self.search_timeout,
                retries=1,
                extra_headers={
                    "Referer": "https://www.bing.com/",
                    "Sec-Fetch-Site": "same-origin",
                    "Accept-Language": "en-US,en;q=0.9",
                    "Cookie": "_EDGE_S=mkt=en-us; _SS=mkt=en-us",
                },
            )
        except Exception:
            return []
        if not resp.ok:
            return []
        if self._is_captcha(resp.text.lower()):
            return []
        return self._parse(resp.text, count)

    def _parse(self, html: str, count: int) -> list[SearchResult]:
        results: list[SearchResult] = []
        seen: set[str] = set()

        # Strategy 1 (primary): scope to <li class="b_algo"> blocks.
        # This avoids picking up sidebar / "people also ask" / related
        # search links. Use a simple regex to extract these blocks.
        algo_blocks = re.findall(
            r'<li[^>]*class="[^"]*b_algo[^"]*"[^>]*>(.*?)</li>',
            html,
            re.IGNORECASE | re.DOTALL,
        )
        for block in algo_blocks:
            # Find the first /ck/a?...&u=a1<base64> in this block.
            m = self._CK_U_RE.search(block)
            if not m:
                continue
            encoded = m.group(1)
            try:
                padded = encoded + "=" * (-len(encoded) % 4)
                decoded = base64.urlsafe_b64decode(padded).decode("utf-8", errors="ignore")
            except Exception:
                continue
            clean = self._clean_url(decoded)
            if not clean:
                continue
            host = clean.split("/", 3)[2] if "://" in clean else ""
            if host.endswith("bing.com") or host.endswith("microsoft.com"):
                continue
            key = clean.split("#", 1)[0]
            if key in seen:
                continue
            seen.add(key)
            results.append(
                SearchResult(
                    url=clean,
                    title="",
                    snippet="",
                    engine=self.name,
                    rank=len(results) + 1,
                )
            )
            if len(results) >= count:
                break

        # Strategy 2: <cite> tags as fallback (domain-only URLs).
        if len(results) < count:
            for m in self._CITE_RE.finditer(html):
                raw = html_unescape(m.group(1)).strip()
                raw = raw.replace("...", "").strip()
                if not raw or " " in raw:
                    continue
                if not raw.startswith("http"):
                    raw = "https://" + raw.lstrip("/")
                clean = self._clean_url(raw)
                if not clean:
                    continue
                host = clean.split("/", 3)[2] if "://" in clean else ""
                if host.endswith("bing.com") or host.endswith("microsoft.com"):
                    continue
                key = clean.split("#", 1)[0]
                if key in seen:
                    continue
                seen.add(key)
                results.append(
                    SearchResult(
                        url=clean,
                        title="",
                        snippet="",
                        engine=self.name,
                        rank=len(results) + 1,
                    )
                )
                if len(results) >= count * 2:
                    break

        # Strategy 3: absolute https hrefs that aren't Bing tracking.
        if len(results) < count:
            for m in self._HREF_RE.finditer(html):
                raw = m.group(1)
                clean = self._clean_url(raw)
                if not clean:
                    continue
                host = clean.split("/", 3)[2] if "://" in clean else ""
                if host.endswith("bing.com") or host.endswith("microsoft.com"):
                    continue
                key = clean.split("#", 1)[0]
                if key in seen:
                    continue
                seen.add(key)
                results.append(
                    SearchResult(
                        url=clean,
                        title="",
                        snippet="",
                        engine=self.name,
                        rank=len(results) + 1,
                    )
                )
                if len(results) >= count * 2:
                    break

        return results[:count]
