"""Search engine interface and base classes."""
from __future__ import annotations

import abc
import re
from dataclasses import dataclass
from urllib.parse import urlsplit, urlunsplit, parse_qsl, urlencode

from ..http_client import HttpClient, HttpResponse


@dataclass
class SearchResult:
    """A single search hit."""

    url: str
    title: str
    snippet: str
    engine: str
    rank: int = 0

    def host(self) -> str:
        try:
            return urlsplit(self.url).netloc.lower()
        except Exception:
            return ""


class SearchEngine(abc.ABC):
    """Abstract search engine."""

    name: str = "base"
    home_url: str = ""

    def __init__(self, http: HttpClient, search_timeout: float = 6.0):
        self.http = http
        self.search_timeout = search_timeout

    @abc.abstractmethod
    async def search(self, query: str, count: int = 10) -> list[SearchResult]:
        """Return up to ``count`` results for ``query``."""
        raise NotImplementedError

    # ------------------------------------------------------------------
    # Helpers shared by HTML-parsing engines.
    # ------------------------------------------------------------------
    def _clean_url(self, u: str) -> str | None:
        """Normalize a URL and return None if it's junk."""
        if not u:
            return None
        u = u.strip()
        if u.startswith("//"):
            u = "https:" + u
        if u.startswith("/"):
            # Resolve relative URLs against the engine's own home URL.
            u = "https://" + urlsplit(self.home_url).netloc + u
        parts = urlsplit(u)
        if parts.scheme not in ("http", "https"):
            return None
        if not parts.netloc:
            return None
        # Strip tracking query params common in SERPs.
        if parts.query:
            keep = [
                (k, v)
                for k, v in parse_qsl(parts.query, keep_blank_values=True)
                if k not in _TRACKING_PARAMS
            ]
            parts = parts._replace(query=urlencode(keep))
        return urlunsplit(parts)

    def _is_captcha(self, body_lower: str) -> bool:
        """Heuristic captcha / block detection."""
        for sig in _CAPTCHA_SIGNATURES:
            if sig in body_lower:
                return True
        return False


# Common tracking query parameters to strip.
_TRACKING_PARAMS = {
    "utm_source",
    "utm_medium",
    "utm_campaign",
    "utm_term",
    "utm_content",
    "gclid",
    "fbclid",
    "msclkid",
    "ref",
    "ref_src",
    "ref_url",
}

# Strings that strongly suggest we hit a captcha / interstitial.
_CAPTCHA_SIGNATURES = (
    "our systems have detected unusual traffic",
    "unusual traffic from your computer network",
    "/sorry/index?continue=",
    "recaptcha",
    "are you a robot",
    "captcha-bypass",
    "access denied",
    "blocked",
    "verify you are human",
    "please verify you're not a robot",
    "ddg-captcha",
    "presearch captcha",
)


def dedupe(results: list[SearchResult]) -> list[SearchResult]:
    """Drop duplicate URLs, keeping the first occurrence per engine order."""
    seen: set[str] = set()
    out: list[SearchResult] = []
    for r in results:
        # Normalize to host+path for dedup so http vs https and trailing
        # slash variations don't fool us.
        key = _normalize_key(r.url)
        if key in seen:
            continue
        seen.add(key)
        out.append(r)
    return out


def _normalize_key(url: str) -> str:
    parts = urlsplit(url)
    host = parts.netloc.lower()
    if host.startswith("www."):
        host = host[4:]
    path = parts.path.rstrip("/")
    return f"{host}{path}"
