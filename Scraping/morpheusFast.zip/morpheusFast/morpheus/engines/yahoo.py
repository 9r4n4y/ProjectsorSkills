"""Yahoo search scraper.

Yahoo uses Bing's search index but renders results in a different
HTML layout that is very scrape-friendly. Yahoo wraps organic result
URLs in ``r.search.yahoo.com/...RU=<url-encoded-real-url>`` redirects
which we extract and decode.
"""
from __future__ import annotations

import re
from urllib.parse import quote_plus, unquote

from .base import SearchEngine, SearchResult


class YahooEngine(SearchEngine):
    name = "yahoo"
    home_url = "https://search.yahoo.com/"

    # Yahoo wraps organic URLs in: ...RU=<url-encoded-real-url>...
    _RU_RE = re.compile(r"RU=([^&\"']+)", re.IGNORECASE)
    # Yahoo appends trailing junk like "/RK=2/RS=..." to the real URL.
    # We strip everything from "/RK=" onward.
    _RK_RE = re.compile(r"/RK=\d+/RS=[^/\s]+$", re.IGNORECASE)
    # Fallback: absolute https hrefs.
    _HREF_RE = re.compile(
        r'href="(https?://(?!search\.yahoo\.|www\.yahoo\.|r\.yahoo\.|r\.search\.yahoo\.|ysm\.yahoo\.|s\.yimg\.|geo\.yahoo\.|scout\.yahoo\.|images\.search\.yahoo\.|video\.search\.yahoo\.|news\.search\.yahoo\.)[^"]+)"',
        re.IGNORECASE,
    )

    async def search(self, query: str, count: int = 10) -> list[SearchResult]:
        url = "https://search.yahoo.com/search?p=" + quote_plus(query) + "&n=" + str(max(count * 3, 30)) + "&fr=yfp-t"
        try:
            resp = await self.http.get(
                url,
                timeout=self.search_timeout,
                retries=1,
                extra_headers={
                    "Referer": "https://search.yahoo.com/",
                    "Sec-Fetch-Site": "same-origin",
                    "Accept-Language": "en-US,en;q=0.9",
                },
            )
        except Exception:
            return []
        if not resp.ok:
            return []
        if self._is_captcha(resp.text.lower()):
            return []
        return self._parse(resp.text, count)

    def _parse(self, html: str, count: int) -> list[SearchResult]:
        results: list[SearchResult] = []
        seen: set[str] = set()

        # Primary: RU= encoded target URLs (Yahoo's organic result links).
        for m in self._RU_RE.finditer(html):
            raw = unquote(m.group(1))
            # Strip Yahoo's trailing /RK=2/RS=... junk.
            raw = self._RK_RE.sub("", raw)
            # Skip Yahoo's own nav URLs (mail, news, sports, etc).
            clean = self._clean_url(raw)
            if not clean:
                continue
            host = clean.split("/", 3)[2] if "://" in clean else ""
            if (
                host.endswith("yahoo.com")
                or host.endswith("yimg.com")
                or host.endswith("yahoo.")
                or host == ""
            ):
                continue
            key = clean.split("#", 1)[0]
            if key in seen:
                continue
            seen.add(key)
            results.append(
                SearchResult(
                    url=clean,
                    title="",
                    snippet="",
                    engine=self.name,
                    rank=len(results) + 1,
                )
            )
            if len(results) >= count * 2:
                break

        # Fallback: absolute hrefs that aren't Yahoo-internal.
        if len(results) < count:
            for m in self._HREF_RE.finditer(html):
                raw = m.group(1)
                raw = self._RK_RE.sub("", raw)
                clean = self._clean_url(raw)
                if not clean:
                    continue
                host = clean.split("/", 3)[2] if "://" in clean else ""
                if host.endswith("yahoo.com") or host.endswith("yimg.com") or host == "":
                    continue
                key = clean.split("#", 1)[0]
                if key in seen:
                    continue
                seen.add(key)
                results.append(
                    SearchResult(
                        url=clean,
                        title="",
                        snippet="",
                        engine=self.name,
                        rank=len(results) + 1,
                    )
                )
                if len(results) >= count * 2:
                    break

        return results[:count]
