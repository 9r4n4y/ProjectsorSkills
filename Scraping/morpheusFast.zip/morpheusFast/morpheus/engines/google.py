"""Google search scraper (HTML SERP).

Google has tightened anti-bot defences significantly in 2024-2025. The
classic ``/url?q=`` pattern only appears in the JS-rendered page; the
plain HTML response often serves a "JavaScript required" interstitial.

To maximise the chance of getting organic results, this engine:

  1. Sends a CONSENT cookie so Google doesn't show the EU consent page.
  2. Tries the desktop endpoint first.
  3. Falls back to the mobile Google endpoint (sometimes returns simpler HTML).
  4. Falls back to the lite endpoint with ``&gbv=1``.
  5. If all return the JS-only page (no ``/url?q=`` patterns), returns []
     so the router can fall back to Bing / DuckDuckGo / Yahoo.

If you absolutely need Google results and this engine consistently
returns 0, you have three options:

  * Use Google's Programmable Search JSON API (requires API key).
  * Run morpheusFast behind a JS-rendering proxy (Browserless, ScrapingBee).
  * Rely on the router's failover — Bing / DuckDuckGo / Yahoo cover
    most of Google's index.
"""
from __future__ import annotations

import re
from urllib.parse import quote_plus

from .base import SearchEngine, SearchResult


# Cookie that bypasses Google's EU consent screen.
_CONSENT_COOKIE = "CONSENT=YES+cb.20240101-00-prod.EN+FX+999"


class GoogleEngine(SearchEngine):
    name = "google"
    home_url = "https://www.google.com/"

    # Google wraps real result URLs in /url?q=... redirects.
    _URL_Q_RE = re.compile(r"/url\?q=([^&\"']+)", re.IGNORECASE)
    # Fallback: absolute https URLs that look like real results.
    _ABS_RE = re.compile(
        r'href="(https?://(?!www\.google\.|accounts\.google\.|support\.google\.|policies\.google\.|maps\.google\.|play\.google\.|mail\.google\.|drive\.google\.|news\.google\.|www\.gstatic\.|www\.googleapis\.|www\.googleusercontent\.)[^"]+)"',
        re.IGNORECASE,
    )
    # Google sometimes embeds display URLs in <cite> tags.
    _CITE_RE = re.compile(r"<cite[^>]*>([^<]+)</cite>", re.IGNORECASE)

    async def search(self, query: str, count: int = 10) -> list[SearchResult]:
        per_page = 20 if count <= 10 else 30
        # Try multiple URL strategies in sequence - the first that yields
        # results wins.
        strategies = [
            # Strategy 1: standard desktop search with consent cookie
            (
                "https://www.google.com/search?q=" + quote_plus(query)
                + "&num=" + str(per_page) + "&hl=en&gl=us&ie=utf-8&oe=utf-8&filter=0&nfpr=1",
                {
                    "Referer": "https://www.google.com/",
                    "Sec-Fetch-Site": "same-origin",
                    "Cookie": _CONSENT_COOKIE,
                    "Accept-Language": "en-US,en;q=0.9",
                },
            ),
            # Strategy 2: basic HTML version
            (
                "https://www.google.com/search?q=" + quote_plus(query)
                + "&num=" + str(per_page) + "&hl=en&gl=us&gbv=1&seid=",
                {
                    "Referer": "https://www.google.com/",
                    "Cookie": _CONSENT_COOKIE,
                },
            ),
            # Strategy 3: mobile-ish UA endpoint
            (
                "https://www.google.com/search?q=" + quote_plus(query)
                + "&num=" + str(per_page) + "&hl=en&gl=us&source=lnms&sa=X&ved=&biw=375&bih=600",
                {
                    "Referer": "https://www.google.com/",
                    "Cookie": _CONSENT_COOKIE,
                },
            ),
        ]
        for url, headers in strategies:
            try:
                resp = await self.http.get(url, timeout=self.search_timeout, retries=1, extra_headers=headers)
            except Exception:
                continue
            if not resp.ok:
                continue
            body_lower = resp.text.lower()
            if self._is_captcha(body_lower):
                continue
            # Google's JS-required interstitial contains this signature.
            if "/httpservice/retry/enablejs" in body_lower:
                continue
            results = self._parse(resp.text, count)
            if results:
                return results
        # All strategies failed - return empty so router can failover.
        return []

    def _parse(self, html: str, count: int) -> list[SearchResult]:
        results: list[SearchResult] = []
        seen: set[str] = set()

        # Strategy 1: /url?q=... pattern - the canonical organic result URL.
        for m in self._URL_Q_RE.finditer(html):
            raw = m.group(1)
            clean = self._clean_url(raw)
            if not clean:
                continue
            key = clean.split("#", 1)[0]
            if key in seen:
                continue
            seen.add(key)
            results.append(
                SearchResult(
                    url=clean,
                    title="",
                    snippet="",
                    engine=self.name,
                    rank=len(results) + 1,
                )
            )
            if len(results) >= count * 2:
                break

        # Strategy 2: <cite> tags with display URLs.
        if len(results) < count:
            for m in self._CITE_RE.finditer(html):
                raw = m.group(1).strip().replace("...", "").strip()
                if not raw or " " in raw:
                    continue
                if not raw.startswith("http"):
                    raw = "https://" + raw.lstrip("/")
                clean = self._clean_url(raw)
                if not clean:
                    continue
                key = clean.split("#", 1)[0]
                if key in seen:
                    continue
                seen.add(key)
                results.append(
                    SearchResult(
                        url=clean,
                        title="",
                        snippet="",
                        engine=self.name,
                        rank=len(results) + 1,
                    )
                )
                if len(results) >= count * 2:
                    break

        # Strategy 3: absolute https hrefs that aren't Google-internal.
        if len(results) < count:
            for m in self._ABS_RE.finditer(html):
                raw = m.group(1)
                clean = self._clean_url(raw)
                if not clean:
                    continue
                host = clean.split("/", 3)[2] if "://" in clean else ""
                if host.endswith("google.com") or host.endswith("google."):
                    continue
                key = clean.split("#", 1)[0]
                if key in seen:
                    continue
                seen.add(key)
                results.append(
                    SearchResult(
                        url=clean,
                        title="",
                        snippet="",
                        engine=self.name,
                        rank=len(results) + 1,
                    )
                )
                if len(results) >= count * 2:
                    break

        return results[:count]
