"""Search engine registry."""
from .base import SearchEngine, SearchResult, dedupe
from .google import GoogleEngine
from .bing import BingEngine
from .duckduckgo import DuckDuckGoEngine
from .brave import BraveEngine
from .presearch import PresearchEngine
from .yahoo import YahooEngine

ENGINES: dict[str, type[SearchEngine]] = {
    "google": GoogleEngine,
    "bing": BingEngine,
    "duckduckgo": DuckDuckGoEngine,
    "brave": BraveEngine,
    "presearch": PresearchEngine,
    "yahoo": YahooEngine,
}

__all__ = [
    "SearchEngine",
    "SearchResult",
    "dedupe",
    "ENGINES",
    "GoogleEngine",
    "BingEngine",
    "DuckDuckGoEngine",
    "BraveEngine",
    "PresearchEngine",
    "YahooEngine",
]
