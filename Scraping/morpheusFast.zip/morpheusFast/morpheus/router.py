"""Multi-engine router with smart failover.

Given a target number of unique results, the router:

  1. Queries engines in parallel (up to ``max_concurrent_engines``) to
     maximize discovery speed.
  2. If an engine returns 0 results (likely captcha'd or blocked), it
     is marked as "tired" for the rest of the session.
  3. If the union of all engines doesn't yield enough results, the
     router falls back to the next engine in the order list, one at a
     time, until the target is reached or all engines are exhausted.
  4. Results are deduplicated by normalized URL (host+path).
  5. Blocked domains (reddit/youtube/facebook/instagram by default) are
     filtered out before dedup.
"""
from __future__ import annotations

import asyncio
from typing import Iterable

from .config import Config
from .engines import ENGINES, SearchResult, dedupe
from .http_client import HttpClient


class Router:
    """Coordinates multi-engine search with failover."""

    def __init__(self, http: HttpClient, config: Config):
        self.http = http
        self.config = config
        self._engines = {
            name: ENGINES[name](http, search_timeout=config.search_timeout)
            for name in config.engine_order
            if name in ENGINES
        }
        # Engines that returned 0 results or captcha in this session.
        self._tired: set[str] = set()

    @property
    def available_engines(self) -> list[str]:
        return [n for n in self.config.engine_order if n in self._engines and n not in self._tired]

    async def search(self, query: str, count: int) -> list[SearchResult]:
        """Return up to ``count`` unique results for ``query``.

        Strategy:
          Phase 1: Query all available engines in parallel, each asked
                   for 2x ``count`` results. This is enough to cover
                   dedup loss in most cases.
          Phase 2: If still short, retry tired engines once in parallel.
        """
        if count <= 0:
            return []

        # Phase 1: parallel discovery across all engines (ask 2x).
        results = await self._parallel_discovery(query, count * 2)
        results = self._filter_blocked(results)
        results = dedupe(results)

        if len(results) >= count:
            return results[:count]

        # Phase 2: retry tired engines once with a small ask (in parallel).
        if self._tired:
            tired_list = list(self._tired)
            sem = asyncio.Semaphore(self.config.max_concurrent_engines)

            async def retry(name: str) -> list[SearchResult]:
                if name not in self._engines:
                    return []
                async with sem:
                    try:
                        r = await self._engines[name].search(query, count=count)
                    except Exception:
                        r = []
                    if r:
                        self._tired.discard(name)
                    return r

            more_lists = await asyncio.gather(*(retry(n) for n in tired_list))
            for lst in more_lists:
                results.extend(self._filter_blocked(lst))
            results = dedupe(results)

        return results[:count]

    async def search_many(
        self,
        queries: Iterable[str],
        per_query: int,
        total: int | None = None,
    ) -> list[SearchResult]:
        """Run multiple queries in parallel and merge unique results.

        ``total`` is the desired total result count across all queries.
        If None, it defaults to ``per_query * len(queries)``.
        """
        queries = list(queries)
        if not queries:
            return []
        if total is None:
            total = per_query * len(queries)

        sem = asyncio.Semaphore(self.config.max_concurrent_engines)

        async def one(q: str) -> list[SearchResult]:
            async with sem:
                return await self.search(q, per_query)

        all_results = await asyncio.gather(*(one(q) for q in queries))
        flat: list[SearchResult] = []
        for r in all_results:
            flat.extend(r)
        flat = self._filter_blocked(flat)
        flat = dedupe(flat)
        return flat[:total] if total else flat

    # ------------------------------------------------------------------
    async def _parallel_discovery(self, query: str, count: int) -> list[SearchResult]:
        available = self.available_engines
        if not available:
            return []

        async def one(name: str) -> list[SearchResult]:
            engine = self._engines[name]
            try:
                r = await engine.search(query, count=count)
                if not r:
                    self._tired.add(name)
                return r
            except Exception:
                self._tired.add(name)
                return []

        tasks = [one(n) for n in available]
        gathered = await asyncio.gather(*tasks)
        out: list[SearchResult] = []
        for r in gathered:
            out.extend(r)
        return out

    def _filter_blocked(self, results: list[SearchResult]) -> list[SearchResult]:
        return [r for r in results if not self.config.is_blocked(r.host())]
