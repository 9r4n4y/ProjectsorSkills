"""morpheusFast CLI.

Examples
--------
    # 1 query, 50 fully-scraped results, print to stdout as JSON
    morpheus "what is rlhf" --count 50 --format json

    # 5 queries, 10 each, save to results.json
    morpheus "q1" "q2" "q3" "q4" "q5" --per-query 10 --out results.json

    # URLs only (no page scraping), as plain text
    morpheus "openai" --count 30 --no-fetch --format text

    # Custom engine order
    morpheus "test" --engines bing duckduckgo google --count 20
"""
from __future__ import annotations

import argparse
import asyncio
import json
import sys
from typing import Iterable

from . import __version__
from .client import FetchedResult, Morpheus
from .config import Config


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="morpheus",
        description="morpheusFast - multi-engine fast search scraper.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__,
    )
    p.add_argument(
        "queries",
        nargs="+",
        help="One or more search queries. Multiple queries run in parallel.",
    )
    p.add_argument(
        "-n",
        "--count",
        type=int,
        default=10,
        help="Total number of fully-fetched unique results to return "
        "(used when only 1 query is given). Default: 10.",
    )
    p.add_argument(
        "--per-query",
        type=int,
        default=None,
        help="Results per query (used when >1 query is given). "
        "Defaults to count // len(queries).",
    )
    p.add_argument(
        "--format",
        choices=("json", "text", "urls", "markdown"),
        default="json",
        help="Output format. Default: json.",
    )
    p.add_argument(
        "-o",
        "--out",
        default=None,
        help="Write output to this file instead of stdout.",
    )
    p.add_argument(
        "--no-fetch",
        action="store_true",
        help="Skip page scraping; only return URLs.",
    )
    p.add_argument(
        "--engines",
        nargs="+",
        default=None,
        help="Override engine order, e.g. --engines bing duckduckgo google.",
    )
    p.add_argument(
        "--concurrency",
        type=int,
        default=None,
        help="Max concurrent page fetches. Default: 25.",
    )
    p.add_argument(
        "--timeout",
        type=float,
        default=None,
        help="Page fetch timeout (seconds). Default: 10.",
    )
    p.add_argument(
        "--max-text",
        type=int,
        default=None,
        help="Max characters of extracted text per page. Default: 20000.",
    )
    p.add_argument(
        "--blocked",
        nargs="*",
        default=None,
        help="Additional domains to block (in addition to the defaults).",
    )
    p.add_argument(
        "--allow-reddit",
        action="store_true",
        help="Do NOT block reddit.com (blocked by default).",
    )
    p.add_argument(
        "--version",
        action="version",
        version=f"morpheusFast {__version__}",
    )
    return p


def make_config(args: argparse.Namespace) -> Config:
    cfg = Config()
    if args.engines:
        cfg.engine_order = tuple(args.engines)
    if args.concurrency is not None:
        cfg.max_concurrent_fetches = args.concurrency
    if args.timeout is not None:
        cfg.page_timeout = args.timeout
    if args.max_text is not None:
        cfg.max_text_length = args.max_text
    if args.allow_reddit:
        cfg.blocked_domains = tuple(
            d for d in cfg.blocked_domains if "reddit.com" not in d
        )
    if args.blocked:
        cfg = cfg.with_blocked(args.blocked)
    return cfg


def format_results(results: list[FetchedResult], fmt: str) -> str:
    if fmt == "json":
        return json.dumps([r.to_dict() for r in results], indent=2, ensure_ascii=False)
    if fmt == "urls":
        return "\n".join(r.url for r in results)
    if fmt == "text":
        parts = []
        for r in results:
            parts.append(f"=== {r.url} ({r.engine}) ===")
            parts.append(f"Title: {r.title}")
            if r.error:
                parts.append(f"Error: {r.error}")
            parts.append("")
            parts.append(r.text)
            parts.append("")
            parts.append("")
        return "\n".join(parts)
    if fmt == "markdown":
        parts = ["# morpheusFast Results", ""]
        for i, r in enumerate(results, 1):
            parts.append(f"## {i}. [{r.title or r.url}]({r.url})")
            parts.append(f"*Engine:* {r.engine} | *Status:* {r.status} | *Fetch time:* {r.fetch_time:.2f}s")
            if r.error:
                parts.append(f"*Error:* {r.error}")
            parts.append("")
            parts.append(r.text[:5000] if r.text else "")
            parts.append("")
            parts.append("---")
            parts.append("")
        return "\n".join(parts)
    raise ValueError(f"unknown format: {fmt}")


async def run(args: argparse.Namespace) -> int:
    config = make_config(args)
    async with Morpheus(config=config) as m:
        if len(args.queries) == 1:
            results = await m.search(args.queries[0], args.count, fetch=not args.no_fetch)
        else:
            per_query = args.per_query or max(1, args.count // len(args.queries))
            results = await m.search_many(
                args.queries,
                per_query=per_query,
                total=args.count,
                fetch=not args.no_fetch,
            )
    output = format_results(results, args.format)
    if args.out:
        with open(args.out, "w", encoding="utf-8") as f:
            f.write(output)
        n_ok = sum(1 for r in results if not r.error)
        print(
            f"OK: {n_ok}/{len(results)} fetched successfully -> {args.out}",
            file=sys.stderr,
        )
    else:
        print(output)
    return 0


def main(argv: Iterable[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(list(argv) if argv is not None else None)
    return asyncio.run(run(args))


if __name__ == "__main__":
    sys.exit(main())
