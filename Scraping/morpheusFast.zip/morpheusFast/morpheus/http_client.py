"""curl_cffi stealth HTTP client wrapper.

This module exposes a single :class:`HttpClient` that:
  * Reuses a single ``AsyncSession`` per instance (connection pooling).
  * Uses ``chrome124`` impersonation for a real-Chrome TLS fingerprint.
  * Rotates a small header pool to avoid identical header fingerprints.
  * Handles retries with exponential backoff.
"""
from __future__ import annotations

import asyncio
import itertools
import random
from typing import Any

try:
    from curl_cffi.requests import AsyncSession  # type: ignore
except ImportError as exc:  # pragma: no cover
    raise ImportError(
        "curl_cffi is required. Install with: pip install curl_cffi>=0.7.0"
    ) from exc


# A small rotation of realistic Accept-Language headers - Google in
# particular looks at this to decide whether to serve a captcha.
_ACCEPT_LANGS = [
    "en-US,en;q=0.9",
    "en-US,en;q=0.8",
    "en-GB,en-US;q=0.9,en;q=0.8",
    "en-US,en;q=0.9,zh-CN;q=0.8",
    "en,en-US;q=0.9",
]

# Realistic secondary headers that real Chrome sends.
_DEFAULT_HEADERS = {
    "Accept": (
        "text/html,application/xhtml+xml,application/xml;q=0.9,"
        "image/avif,image/webp,image/apng,*/*;q=0.8"
    ),
    "Cache-Control": "no-cache",
    "Pragma": "no-cache",
    "Sec-Ch-Ua": '"Chromium";v="124", "Google Chrome";v="124", "Not-A.Brand";v="99"',
    "Sec-Ch-Ua-Mobile": "?0",
    "Sec-Ch-Ua-Platform": '"Windows"',
    "Sec-Fetch-Dest": "document",
    "Sec-Fetch-Mode": "navigate",
    "Sec-Fetch-Site": "none",
    "Sec-Fetch-User": "?1",
    "Upgrade-Insecure-Requests": "1",
}


class HttpResponse:
    """Lightweight HTTP response container."""

    __slots__ = ("status", "url", "headers", "body", "text")

    def __init__(self, status: int, url: str, headers: dict, body: bytes, text: str):
        self.status = status
        self.url = url
        self.headers = headers
        self.body = body
        self.text = text

    @property
    def ok(self) -> bool:
        return 200 <= self.status < 300


class HttpClient:
    """Async HTTP client backed by curl_cffi with Chrome impersonation."""

    def __init__(
        self,
        impersonate: str = "chrome124",
        user_agent: str | None = None,
        extra_headers: dict[str, str] | None = None,
    ):
        self.impersonate = impersonate
        self.user_agent = user_agent
        self.extra_headers = extra_headers or {}
        self._session: AsyncSession | None = None
        self._lang_cycle = itertools.cycle(_ACCEPT_LANGS)

    async def __aenter__(self) -> "HttpClient":
        await self.start()
        return self

    async def __aexit__(self, *exc):
        await self.close()

    async def start(self) -> None:
        if self._session is None:
            self._session = AsyncSession(impersonate=self.impersonate)

    async def close(self) -> None:
        if self._session is not None:
            await self._session.close()
            self._session = None

    def _build_headers(self, extra: dict[str, str] | None = None) -> dict[str, str]:
        headers = dict(_DEFAULT_HEADERS)
        headers["Accept-Language"] = next(self._lang_cycle)
        if self.user_agent:
            headers["User-Agent"] = self.user_agent
        headers.update(self.extra_headers)
        if extra:
            headers.update(extra)
        return headers

    async def get(
        self,
        url: str,
        *,
        timeout: float = 10.0,
        retries: int = 1,
        extra_headers: dict[str, str] | None = None,
        allow_redirects: bool = True,
    ) -> HttpResponse:
        """GET a URL with retries and exponential backoff."""
        await self.start()
        assert self._session is not None
        headers = self._build_headers(extra_headers)
        last_exc: Exception | None = None
        for attempt in range(retries + 1):
            try:
                r = await self._session.get(
                    url,
                    headers=headers,
                    timeout=timeout,
                    allow_redirects=allow_redirects,
                )
                text = ""
                try:
                    text = r.text
                except Exception:
                    text = r.content.decode("utf-8", errors="replace")
                return HttpResponse(
                    status=r.status_code,
                    url=str(r.url),
                    headers=dict(r.headers),
                    body=r.content,
                    text=text,
                )
            except Exception as exc:
                last_exc = exc
                # Small jittered backoff before retry.
                if attempt < retries:
                    await asyncio.sleep(0.4 * (attempt + 1) + random.uniform(0, 0.2))
        # All retries failed - re-raise.
        assert last_exc is not None
        raise last_exc

    async def get_many(
        self,
        urls: list[str],
        *,
        timeout: float = 10.0,
        retries: int = 1,
        concurrency: int = 25,
    ) -> list[HttpResponse | Exception]:
        """Fetch many URLs concurrently with a semaphore.

        Returns a list aligned with ``urls``; each entry is either an
        :class:`HttpResponse` or an ``Exception`` if the fetch failed.
        """
        await self.start()
        sem = asyncio.Semaphore(concurrency)

        async def one(u: str) -> HttpResponse | Exception:
            async with sem:
                try:
                    return await self.get(u, timeout=timeout, retries=retries)
                except Exception as exc:
                    return exc

        return await asyncio.gather(*(one(u) for u in urls))
