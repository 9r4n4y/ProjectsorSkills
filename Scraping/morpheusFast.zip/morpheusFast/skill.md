# skill.md — morpheusFast Command Reference

> **morpheusFast** is a fast multi-engine search scraper that fully fetches
> result page bodies for AI consumption. Uses curl_cffi with chrome124
> impersonation for maximum stealth. Targets **50 pages in <15s**.

---

## 1. Install

```bash
# Linux / macOS / WSL
cd morpheusFast
./install.sh                # virtualenv (recommended)
# or:  ./install.sh --system
# or:  ./install.sh --user

# Windows (PowerShell)
.\install.ps1
```

Verify:

```bash
morpheus --version
morpheus "openai" --count 3 --format urls
```

Requirements: Python 3.10+, `curl_cffi>=0.7.0`, `beautifulsoup4>=4.12.0`.

---

## 2. CLI — One-Liners

### Single query, 50 fully-scraped results

```bash
morpheus "what is rlhf" --count 50
```

### 5 queries × 10 each = 50 unique scraped pages, save to file

```bash
morpheus "q1" "q2" "q3" "q4" "q5" --per-query 10 --count 50 -o results.json
```

### URLs only (no page scraping — fastest, ~2s for 50 URLs)

```bash
morpheus "openai" --count 50 --no-fetch --format urls
```

### Plain-text corpus for LLM

```bash
morpheus "transformer attention" --count 20 --format text -o corpus.txt
```

### Markdown with titles + URLs + body

```bash
morpheus "rust async runtime" --count 10 --format markdown -o out.md
```

### Custom engine order (e.g. Bing first, Google last)

```bash
morpheus "test" --engines bing duckduckgo brave presearch google --count 20
```

### Aggressive concurrency (50 in parallel)

```bash
morpheus "test" --count 50 --concurrency 50 --timeout 8
```

### Block extra domains

```bash
morpheus "test" --count 20 --blocked pinterest.com quora.com medium.com
```

### Allow Reddit (blocked by default)

```bash
morpheus "best mechanical keyboards" --count 20 --allow-reddit
```

---

## 3. CLI — Full Reference

```
morpheus [-h] [-n COUNT] [--per-query N] [--format FMT] [-o FILE]
         [--no-fetch] [--engines E1 E2 ...] [--concurrency N]
         [--timeout S] [--max-text N] [--blocked D1 D2 ...]
         [--allow-reddit] [--version]
         queries [queries ...]
```

| Flag             | Default | Description |
|------------------|---------|-------------|
| `queries`        | —       | One or more search queries. Multiple run in parallel. |
| `-n/--count`     | `10`    | Total unique results to return. |
| `--per-query`    | auto    | Results per query (multi-query mode). Default = count ÷ len(queries). |
| `--format`       | `json`  | `json` / `text` / `urls` / `markdown`. |
| `-o/--out`       | stdout  | Write output to file. |
| `--no-fetch`     | off     | Skip page scraping; only return URLs. |
| `--engines`      | all     | Override engine order. |
| `--concurrency`  | `25`    | Max concurrent page fetches. |
| `--timeout`      | `10`    | Per-page fetch timeout (seconds). |
| `--max-text`     | `20000` | Max extracted text chars per page. |
| `--blocked`      | —       | Extra domains to block. |
| `--allow-reddit` | off     | Do NOT block reddit.com. |
| `--version`      | —       | Print version and exit. |

---

## 4. Python API

### Single query → 50 fully-fetched results

```python
import asyncio
from morpheus import Morpheus

async def main():
    async with Morpheus() as m:
        results = await m.search("what is rlhf", count=50)
        for r in results:
            print(r.url, r.engine, len(r.text), f"{r.fetch_time:.2f}s")

asyncio.run(main())
```

### 5 queries × 10 each → 50 unique results

```python
results = await m.search_many(
    ["q1", "q2", "q3", "q4", "q5"],
    per_query=10,
    total=50,
)
```

### Custom config

```python
from morpheus import Config, Morpheus

cfg = Config(
    engine_order=("bing", "duckduckgo", "google"),  # Bing first
    max_concurrent_fetches=50,
    page_timeout=8.0,
    max_text_length=10_000,
)
cfg = cfg.with_blocked(["pinterest.com", "quora.com"])

async with Morpheus(config=cfg) as m:
    results = await m.search("best laptops 2025", count=20)
```

### Serialize for AI ingestion

```python
import json

with open("results.json", "w", encoding="utf-8") as f:
    json.dump([r.to_dict() for r in results], f, indent=2, ensure_ascii=False)

# Or feed directly into your LLM:
context = "\n\n---\n\n".join(
    f"URL: {r.url}\nTitle: {r.title}\n\n{r.text}"
    for r in results if r.text
)
```

---

## 5. FetchedResult Schema

```python
@dataclass
class FetchedResult:
    url: str              # final URL after redirects
    title: str            # <title> tag
    text: str             # cleaned body text (HTML stripped, scripts removed)
    engine: str           # which engine surfaced this URL
    status: int           # HTTP status (0 if fetch failed)
    fetch_time: float     # seconds
    bytes: int            # raw response body size
    error: str | None     # None on success; "low-text" / "http-403" / etc.
```

`.to_dict()` returns a JSON-serializable dict.

---

## 6. Engines

| Name         | Endpoint                                  | Reliability | Notes |
|--------------|-------------------------------------------|-------------|-------|
| `google`     | `https://www.google.com/search`           | ⚠️ JS-required | Google serves a JS-only page to non-browser clients. Returns 0 results; auto-failovers to Bing/DDG/Yahoo. Use Google's Programmable Search API if you need guaranteed Google coverage. |
| `bing`       | `https://www.bing.com/search`             | ✅ Reliable | May geo-locate to regional results based on IP. |
| `duckduckgo` | `https://html.duckduckgo.com/html/`       | ✅ Highly reliable | HTML endpoint, low bot detection, ~25 results/page. |
| `yahoo`      | `https://search.yahoo.com/search`         | ✅ Reliable | Uses Bing's index; independent HTML layout. |
| `brave`      | `https://search.brave.com/search`         | ⚠️ Rate-limited | Returns 429 to datacenter IPs; works from residential IPs. |
| `presearch`  | `https://presearch.com/search`            | ⚠️ Cloudflare | 403 to datacenter IPs; works intermittently. |

Default order: `google → bing → duckduckgo → yahoo → brave → presearch`.

The router queries ALL engines in parallel and dedupes results. Even
if 2-3 engines fail, the remaining ones typically yield enough unique
URLs to hit the target count.

---

## 7. How Failover Works

1. All available engines queried **in parallel**.
2. Each engine returns up to `count` URLs.
3. URLs deduped by `(host, path)`.
4. Blocked domains (reddit/youtube/facebook/instagram + any custom) removed.
5. If still short of `count`:
   - Available engines retried with `count * 2` ask.
   - Tired engines (returned 0 first time) retried once.
6. Final URLs passed to concurrent fetcher (25-way parallel by default).

---

## 8. Speed Tuning

Default: **50 pages in <15s** on a 50 Mbps connection.

```bash
# Faster (more aggressive)
morpheus "test" --count 50 --concurrency 50 --timeout 8

# Gentler (corporate proxy)
morpheus "test" --count 20 --concurrency 10 --timeout 20

# URLs only (~2s for 50 URLs)
morpheus "test" --count 50 --no-fetch --format urls
```

| Setting                | Default | Faster | Gentler |
|------------------------|---------|--------|---------|
| `--concurrency`        | 25      | 50     | 10      |
| `--timeout`            | 10      | 8      | 20      |
| `--max-text`           | 20000   | 10000  | 20000   |

---

## 9. Blocklist

Default blocked:

- `reddit.com` (and `www.`, `m.`, `old.` subdomains)
- `youtube.com`, `m.youtube.com`, `youtu.be`
- `facebook.com`, `m.facebook.com`
- `instagram.com`, `www.instagram.com`

Add more: `--blocked pinterest.com quora.com medium.com`

Re-enable Reddit: `--allow-reddit`

---

## 10. Output Formats

### `json` (default)

```json
[
  {
    "url": "https://example.com/article",
    "title": "Article title",
    "text": "Cleaned body text...",
    "engine": "google",
    "status": 200,
    "fetch_time": 0.842,
    "bytes": 45231,
    "error": null
  }
]
```

### `text`

```
=== https://example.com/article (google) ===
Title: Article title

Cleaned body text...
```

### `urls` (one per line, no fetch)

```
https://example.com/article1
https://example.com/article2
```

### `markdown`

```markdown
# morpheusFast Results

## 1. [Article title](https://example.com/article)
*Engine:* google | *Status:* 200 | *Fetch time:* 0.84s

Cleaned body text (truncated to 5000 chars)...

---
```

---

## 11. Common Recipes

### Recipe A — Daily news digest for AI

```bash
morpheus \
  "AI news today" \
  "openai latest announcement" \
  "anthropic claude news" \
  "gemini google ai" \
  --per-query 10 --count 40 \
  --format markdown \
  -o daily_digest.md
```

### Recipe B — Technical research corpus

```bash
morpheus \
  "rlhf paper" \
  "ppo trpo policy gradient" \
  "transformer architecture" \
  --per-query 15 --count 45 \
  --concurrency 50 \
  --format json \
  -o research.json
```

### Recipe C — Skip Google, use only Bing + DDG

```bash
morpheus "private query" --count 30 --engines bing duckduckgo
```

### Recipe D — Just URLs, fastest mode

```bash
morpheus "anything" --count 50 --no-fetch --format urls -o urls.txt
```

### Recipe E — Build a RAG context for an LLM

```python
import asyncio, json
from morpheus import Morpheus

async def build_context(query: str, n: int = 20) -> str:
    async with Morpheus() as m:
        results = await m.search(query, count=n)
    chunks = []
    for r in results:
        if r.error or not r.text:
            continue
        chunks.append(f"SOURCE: {r.url}\nTITLE: {r.title}\n\n{r.text[:8000]}")
    return "\n\n===\n\n".join(chunks)

context = asyncio.run(build_context("what is dpo", n=20))
# Now feed `context` into your LLM as retrieved documents.
```

---

## 12. Troubleshooting

| Symptom | Fix |
|---------|-----|
| `ImportError: curl_cffi` | `./install.sh` |
| Google returns 0 | Auto-failovers; or `--engines bing duckduckgo brave presearch google` |
| All engines return 0 | Check network egress; wait 5 min if rate-limited |
| `error: low-text` on some pages | Paywalls/JS-only sites; URL still returned |
| `error: http-403` | Target site blocks; retry later or different egress IP |
| Want new engine | Subclass `SearchEngine`, register in `ENGINES` dict |

---

## 13. Performance Benchmark

Tested on a server with 50 Mbps connection, default config:

| Mode                              | Time    | Results | OK  |
|-----------------------------------|---------|---------|-----|
| 1 query, 50 results               | ~7-12s  | 29-42*  | 17-26 |
| 5 queries × 10 each = 50 results  | ~13s    | 50      | 40-42 |

*1-query-50-results mode may return fewer than 50 because:
- DDG serves ~25 results per query
- Bing + Yahoo serve ~10 each
- After dedup, typically 30-45 unique URLs

For guaranteed 50 results, use multi-query mode (`5 queries × 10 each`).

To hit <15s on slower links, raise `--concurrency` and lower `--max-text`:

```bash
morpheus "test" --count 50 --concurrency 50 --timeout 8 --max-text 10000
```

---

## 14. File Layout

```
morpheusFast/
├── README.md
├── skill.md                   ← you are here
├── pyproject.toml
├── requirements.txt
├── install.sh / install.ps1
├── examples/
│   ├── basic_search.py
│   ├── multi_query.py
│   └── custom_config.py
└── morpheus/
    ├── __init__.py
    ├── cli.py                 ← CLI entry
    ├── client.py              ← Morpheus orchestrator
    ├── config.py              ← Config dataclass
    ├── http_client.py         ← curl_cffi stealth wrapper
    ├── extractor.py           ← HTML → text
    ├── router.py              ← multi-engine failover
    └── engines/
        ├── base.py
        ├── google.py
        ├── bing.py
        ├── duckduckgo.py
        ├── brave.py
        ├── presearch.py
        └── yahoo.py
```

---

**That's it.** Install → `morpheus "your query" --count 50` → feed JSON to your AI.
