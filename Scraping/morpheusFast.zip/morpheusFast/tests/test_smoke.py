"""Smoke tests for morpheusFast.

These tests don't hit the network — they verify the package imports,
configs are sane, and parsers work on saved HTML fixtures.
"""
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from morpheus import Morpheus, Config
from morpheus.engines import ENGINES, dedupe, SearchResult
from morpheus.engines.base import _normalize_key
from morpheus.extractor import extract_text, extract_title


def test_engines_registered():
    """All 6 engines should be registered."""
    expected = {"google", "bing", "duckduckgo", "yahoo", "brave", "presearch"}
    assert expected.issubset(set(ENGINES.keys())), f"missing: {expected - set(ENGINES.keys())}"


def test_default_config():
    """Default config should have sensible values."""
    cfg = Config()
    assert "google" in cfg.engine_order
    assert "reddit.com" in cfg.blocked_domains
    assert "youtube.com" in cfg.blocked_domains
    assert "facebook.com" in cfg.blocked_domains
    assert "instagram.com" in cfg.blocked_domains
    assert cfg.max_concurrent_fetches >= 25
    assert cfg.search_timeout > 0
    assert cfg.page_timeout > 0


def test_blocklist_filters_reddit():
    """Config.is_blocked should reject reddit / youtube / facebook / instagram."""
    cfg = Config()
    assert cfg.is_blocked("reddit.com")
    assert cfg.is_blocked("www.reddit.com")
    assert cfg.is_blocked("old.reddit.com")
    assert cfg.is_blocked("youtube.com")
    assert cfg.is_blocked("m.youtube.com")
    assert cfg.is_blocked("youtu.be")
    assert cfg.is_blocked("facebook.com")
    assert cfg.is_blocked("instagram.com")
    assert not cfg.is_blocked("openai.com")
    assert not cfg.is_blocked("wikipedia.org")


def test_with_blocked_merges():
    """with_blocked should add domains without duplicating."""
    cfg = Config()
    cfg2 = cfg.with_blocked(["pinterest.com", "quora.com", "reddit.com"])
    assert "pinterest.com" in cfg2.blocked_domains
    assert "quora.com" in cfg2.blocked_domains
    assert "reddit.com" in cfg2.blocked_domains
    # Original should be unchanged.
    assert "pinterest.com" not in cfg.blocked_domains


def test_dedupe_normalizes_host():
    """Dedupe should treat www.example.com and example.com as the same host."""
    results = [
        SearchResult(url="https://www.example.com/page", title="", snippet="", engine="x"),
        SearchResult(url="https://example.com/page", title="", snippet="", engine="x"),
        SearchResult(url="https://example.com/page/", title="", snippet="", engine="x"),
        SearchResult(url="https://other.com/page", title="", snippet="", engine="x"),
    ]
    deduped = dedupe(results)
    assert len(deduped) == 2


def test_normalize_key_strips_query():
    """URL normalization should keep host+path but drop query string."""
    k1 = _normalize_key("https://example.com/page?utm_source=x")
    k2 = _normalize_key("https://example.com/page")
    # Note: _normalize_key does NOT drop the query - it just normalizes host/path.
    # This is intentional so that the same page with different utm params still
    # dedupes. The query is dropped by _clean_url in the engine.
    assert k1 == "example.com/page"


def test_extract_text_strips_scripts():
    """extract_text should remove <script> and <style> tags."""
    html = """
    <html><head><style>body { color: red; }</style></head>
    <body>
        <script>alert('hi');</script>
        <p>Hello world.</p>
        <script>console.log('bye');</script>
    </body></html>
    """
    text = extract_text(html)
    assert "Hello world" in text
    assert "alert" not in text
    assert "console.log" not in text
    assert "color: red" not in text


def test_extract_title():
    """extract_title should return the <title> tag content."""
    assert extract_title("<html><head><title>My Page</title></head></html>") == "My Page"
    assert extract_title("<html><head></head></html>") == ""
    assert extract_title("") == ""


def test_extract_text_truncates():
    """extract_text should truncate to max_chars."""
    html = "<p>" + ("a" * 1000) + "</p>"
    text = extract_text(html, max_chars=100)
    assert len(text) <= 110  # 100 + ellipsis char


def test_morpheus_instantiation():
    """Morpheus should instantiate without errors."""
    m = Morpheus()
    assert m.config is not None
    assert m.http is not None
    assert m.router is not None
    assert "google" in m.router._engines


if __name__ == "__main__":
    # Run all tests if executed directly.
    tests = [
        test_engines_registered,
        test_default_config,
        test_blocklist_filters_reddit,
        test_with_blocked_merges,
        test_dedupe_normalizes_host,
        test_normalize_key_strips_query,
        test_extract_text_strips_scripts,
        test_extract_title,
        test_extract_text_truncates,
        test_morpheus_instantiation,
    ]
    passed = 0
    failed = 0
    for test in tests:
        try:
            test()
            print(f"  PASS  {test.__name__}")
            passed += 1
        except AssertionError as e:
            print(f"  FAIL  {test.__name__}: {e}")
            failed += 1
        except Exception as e:
            print(f"  ERROR {test.__name__}: {e}")
            failed += 1
    print(f"\n{passed} passed, {failed} failed")
    sys.exit(0 if failed == 0 else 1)
