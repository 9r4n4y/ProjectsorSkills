"""Example: custom config (engine order, extra blocked domains)."""
import asyncio

from morpheus import Config, Morpheus


async def main():
    cfg = Config(
        engine_order=("bing", "duckduckgo", "google"),  # Bing first, Google last
        max_concurrent_fetches=50,                       # aggressive concurrency
        page_timeout=8.0,
        max_text_length=10_000,
    )
    # Add extra blocked domains
    cfg = cfg.with_blocked(["pinterest.com", "quora.com"])

    async with Morpheus(config=cfg) as m:
        results = await m.search("best mechanical keyboards 2025", count=20)
        for r in results:
            print(r.url, r.engine, len(r.text))


if __name__ == "__main__":
    asyncio.run(main())
