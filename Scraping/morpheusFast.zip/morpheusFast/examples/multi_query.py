"""Example: 5 queries x 10 results = 50 unique scraped pages."""
import asyncio
import json
import time

from morpheus import Morpheus


async def main():
    queries = [
        "rlhf reinforcement learning human feedback",
        "ppo proximal policy optimization",
        "dpo direct preference optimization",
        "transformer attention mechanism",
        "mixture of experts language model",
    ]
    async with Morpheus() as m:
        t0 = time.perf_counter()
        results = await m.search_many(queries, per_query=10, total=50)
        elapsed = time.perf_counter() - t0
        ok = sum(1 for r in results if not r.error)
        print(f"Fetched {ok}/{len(results)} pages in {elapsed:.2f}s")

        with open("multi_query_results.json", "w", encoding="utf-8") as f:
            json.dump([r.to_dict() for r in results], f, indent=2, ensure_ascii=False)


if __name__ == "__main__":
    asyncio.run(main())
