"""Example: basic search + full scrape."""
import asyncio
import json
import time

from morpheus import Morpheus


async def main():
    async with Morpheus() as m:
        # 1 query, 50 fully-fetched unique results
        t0 = time.perf_counter()
        results = await m.search("what is quantum entanglement", count=50)
        elapsed = time.perf_counter() - t0

        ok = sum(1 for r in results if not r.error)
        print(f"Fetched {ok}/{len(results)} pages in {elapsed:.2f}s")
        for r in results[:5]:
            print(f"  - [{r.engine}] {r.url} ({len(r.text)} chars, {r.fetch_time:.2f}s)")

        # Save to JSON for your AI to read
        with open("results.json", "w", encoding="utf-8") as f:
            json.dump([r.to_dict() for r in results], f, indent=2, ensure_ascii=False)


if __name__ == "__main__":
    asyncio.run(main())
