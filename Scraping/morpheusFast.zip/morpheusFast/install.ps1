#!/usr/bin/env powershell
# morpheusFast installer for Windows.
# Usage:
#   .\install.ps1
#   .\install.ps1 -Mode system
#   .\install.ps1 -Mode user
param(
    [ValidateSet("venv","system","user")]
    [string]$Mode = "venv",
    [string]$Python = "python"
)

$ErrorActionPreference = "Stop"
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Definition
Set-Location $ScriptDir

if (-not (Get-Command $Python -ErrorAction SilentlyContinue)) {
    Write-Error "Python not found. Install Python 3.10+ from https://python.org first."
    exit 1
}

Write-Host "Using Python: $(& $Python --version)"

switch ($Mode) {
    "system" {
        Write-Host "Installing morpheusFast system-wide..."
        & $Python -m pip install --upgrade pip
        & $Python -m pip install -r requirements.txt
        & $Python -m pip install .
    }
    "user" {
        Write-Host "Installing morpheusFast into user site-packages..."
        & $Python -m pip install --user --upgrade pip
        & $Python -m pip install --user -r requirements.txt
        & $Python -m pip install --user .
    }
    default {
        Write-Host "Creating virtualenv at $ScriptDir\.venv ..."
        & $Python -m venv .venv
        & ".\.venv\Scripts\Activate.ps1"
        pip install --upgrade pip
        pip install -r requirements.txt
        pip install -e .
        Write-Host ""
        Write-Host "Done. Activate with:"
        Write-Host "    .\.venv\Scripts\Activate.ps1"
        Write-Host "Then run:"
        Write-Host "    morpheus 'your search query' --count 10"
    }
}

Write-Host ""
Write-Host "morpheusFast installation complete."
