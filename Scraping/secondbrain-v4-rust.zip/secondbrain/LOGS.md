# LOGS — the log rules (v4)

Logs record what changed and who changed it. v4 makes the rules stricter and
simpler than ever:

## 1. `logs/` is manual only

The engine **never** creates log files in `logs/` by itself. Not on note
creation, not on edits, not on backups, not on folder changes — nothing.
A manual entry exists only when a person (or the AI, on instruction) writes
one, with a **who** and a **title**:

- On the website: **Logs → New log entry**.
- From the AI: the `add_log_entry` MCP tool (`title`, `details`, `who`).

Manual entries are named `YYYY-MM-DD_HH-MM-SS_<title>.md` and are never
edited or deleted after they are written.

## 2. Instruction to the AI (binding)

> **After any structural change you make to this app — a new feature, a
> changed behavior, a renamed or added tool or file, a modified rule — YOU
> MUST add a log entry yourself** (via `add_log_entry` or by writing a
> `logs/YYYY-MM-DD_HH-MM-SS_<title>.md` file), titled with the change and
> signed with your name. Do this before you report the change as done.

## 3. The ONE automatic file: `logs/edits.md`

Exactly one file is written automatically, and it is not a log of the app —
it is the **note-edit history**. Every note edit appends one entry:

```
## 2026-11-02 11:56:27 — edited Garlic Bread — by user
- Note: database/Recipes/Garlic Bread/Garlic Bread.md
- Lines added: 2 — (empty line) | A fresh line added by the test.
- Lines removed: 1 — Updated: 2026-10-31
```

That is all: which note, when, who, and which **lines were added and
removed**. Nothing else about the app is logged automatically.

## 4. Undo is never automatic

Every write records how to reverse it in the internal undo journal
(`core/.cache/undo-journal.json` — not a log file). Reversing a change
happens only when the user presses **Undo** (Logs → Undo journal) or asks
the AI to call `undo_change`. The undo itself is recorded in the journal.
Nothing is ever reversed by itself, and logs/ is never touched by undo.
