# SecondBrain v4 — a universal personal notes system, rewritten in Rust

SecondBrain is a single-user notes system that keeps **all knowledge as plain
Markdown files in plain folders**. There is no database, no cloud and no
vendor lock-in — the files outlive any app. v4 is a **complete rewrite of the
engine in Rust**: the parser, the ranking search engine, the tag system, the
website server, the MCP server and the backup tool are all one fast, native
codebase now. The data format is unchanged — the same `database/` folder that
older versions wrote still works, byte for byte.

A **local website** (Rust + React/shadcn-ui + HeroUI styling) reads those
files and presents them in a clean, searchable interface, an **AI librarian**
(MCP server, 42 tools) can search, read and file notes for you under strict
safety rules, and a **ranking search engine** finds notes by tags, keywords,
synonyms and links — no semantic model, no embeddings, instant on a personal
collection.

```
secondbrain/
├── README.md               this file
├── SKILL.md                the complete manual for the AI librarian
├── StructureOFnotes.md     the exact note format rulebook (with VERIFIED examples)
├── LOGS.md                 the log rules: manual entries only + the AI instruction
├── _tags.md                the master tag vocabulary
├── FIXES.md                what changed in v4 and how each change is proven
├── Cargo.toml / Cargo.lock the Rust workspace (core + website + mcp + backup)
├── core/                   the engine crate (parser, index, search, tags, store…)
├── mcp/                    the MCP server binary (42 tools)
├── website/                the axum server + static/ (compiled UI) + app/ (UI sources)
├── backup/                 the backup / restore / verify CLI
├── database/               every note lives here, as <Subject>/.../<Note Name>/
├── inbox/                  raw unsorted notes waiting to be filed
├── logs/                   MANUAL log entries + the automatic edits.md
├── scripts/                small helper scripts
└── target/                 Rust build output (created by cargo build)
```

---

## What changed in 4.0 — the full list

| # | Change | Where to see it |
| --- | --- | --- |
| 1 | **The whole engine is Rust.** Parser, indexer, ranking search, tags, store, health check, images, backup, website server, MCP server, backup CLI — one workspace, no Python. Same data format, same JSON API shapes, same ranking behavior (the fixed ranking test set passes unchanged). | `core/`, `website/src/`, `mcp/src/`, `backup/src/` |
| 2 | **The graph view is gone — connected notes are the map.** No UI graph is rendered anywhere. A note page shows a clean **Connected notes** panel: *Connects to* and *Referenced by*, one link per row, click to open, × to remove. Connections are used as references while reading. | Note page, Connected notes panel |
| 3 | **Tables get a real editor.** In edit mode, put the cursor in any table and tap the **Table** button: the table opens in a grid dialog — type in cells, add/remove rows and columns, and **Update** rewrites the same lines in place (or **Insert** writes a new table at the cursor). | Editor toolbar → Table |
| 4 | **Select any Markdown, tap a tool.** The toolbar is smart: select a word (or existing Markdown like `**word**`) and tap Bold/Italic/Code/… to format it — tap again to undo the format. Prefix tools (`## `, `- `, `> `, `- [ ] `) toggle per line. The cursor always lands where you keep typing. | Editor toolbar |
| 5 | **Multi-image grid with move + size.** Consecutive images render as a tidy grid (up to 3 columns). Hover an image: arrows move it left/right/up/down inside the grid and the size button cycles 25% → 50% → 75% → full width — every change rewrites exactly the image Markdown lines. | Note preview, image grid |
| 6 | **42 MCP tools — nearly every capability.** Note making, reading, editing, moving, tags, connections, references, images (crop included, in-process), health data, backups, undo, saved searches, structure — plus new: `get_health_data`, `get_settings`, `update_settings` (change rank/advanced settings before a search), `add_log_entry`, `get_edit_history`, `list_notes`. | SKILL.md section 9 |
| 7 | **`StructureOFnotes.md` is now a verified document.** Every Markdown example in it carries a `verify=` mark and an automated test extracts and runs each one through the real engine — the rulebook cannot drift from the code. | `core/tests/structure_examples.rs` |
| 8 | **Preview under every typing bar.** Adding tags, connected notes, folders, search filters — every input shows a live list of everything that exists matching what you typed, with note counts. Nothing can be picked that isn't real. | All dialogs and filter bars |
| 9 | **Find bar and Markdown toolbar never scroll away.** Both are sticky at the top — the find bar in preview AND edit mode (it selects + scrolls the editor in edit mode), the toolbar while editing. | Note page, Ctrl+F |
| 10 | **Search sees the whole note.** Body, headings, quick-info labels and values, tags, file names and folder paths are all indexed — nothing hidden or behind. Scopes let you narrow, never hide. | Search page → How to use |
| 11 | **12 themes; Grey is the default.** Six dark (Grey, Ocean Blue, Forest, Plum, Crimson, Amber) — Grey's background is a slightly darker tone of grey. Six light that **never use white** (Sky, Sage, Rose, Sand, Lavender, Paper): the background is a deeper tinted shade, interactive cards and buttons are lighter shades of the same hue — cozy, not glaring. | Top bar → palette icon; Settings |
| 12 | **New brain logo.** A modern geometric brain — two hemispheres, synapse nodes and links, gradient stroke on a rounded plate. Same SVG as the favicon. | Top bar, `website/app/public/favicon.svg` |
| 13 | **Logs are manual only (with one exception).** The engine never writes log files. The user (or the AI via `add_log_entry`) writes entries with a name and title. The AI is instructed — in LOGS.md, SKILL.md and via a tool description — to add a log entry itself after any structural change. The ONE automatic file is `logs/edits.md`: which note was edited and which lines were added/removed. | LOGS.md, Logs page |
| 14 | **Undo journal.** Every write records its reversal in an internal journal (`core/.cache/undo-journal.json`); the Logs page lists changes with an Undo button that always asks first. Nothing is ever reversed automatically. | Logs page → Undo journal |
| 15 | **shadcn/ui + HeroUI style.** The React app is built on Radix primitives + Tailwind (shadcn/ui components) with HeroUI-flavored gradient hero, cards and buttons. | `website/app/src/components/` |
| 16 | **Command palette** (Ctrl/⌘+K or `/`), Back button (Alt+←), `e` toggles edit, Ctrl+S saves, Ctrl+F finds. | Everywhere |

## Quick start

You need the **Rust toolchain** (rustup, stable) and, only if you want to
rebuild the UI, **Node 18+**. The compiled UI ships prebuilt in
`website/static/`.

```bash
cd secondbrain
./run.sh                       # uses the prebuilt binaries in bin/ (linux x64)
                               # or builds from source on the first run
```

Or step by step:

```bash
cd secondbrain
cargo build --release          # builds core, website, mcp and backup
./target/release/secondbrain-website            # serves http://localhost:8765
```

(The zip ships prebuilt linux-x64 binaries in `bin/`; `cargo build --release`
regenerates them for your machine and is needed on macOS/Windows/ARM.)

The website opens in your browser automatically (disable with
`--no-browser`). Everything stays on this computer; nothing leaves it.

Useful flags and binaries:

```bash
./bin/secondbrain-website --port 9000 --bind 127.0.0.1 --no-browser --rebuild
./bin/secondbrain-backup --to /path/OUTSIDE/the/project --yes   # byte-identical backup
./bin/secondbrain-backup --to /path/to/backup --verify          # re-hash everything
./bin/secondbrain-mcp                                           # the AI tool server (stdio)
```

(With a source build the same binaries are in `target/release/` instead.)

### Connect an AI assistant (MCP)

Point any MCP client at the compiled server:

```json
{"command": "/absolute/path/to/secondbrain/bin/secondbrain-mcp"}
```

The AI gets 42 tools — everything the website can do, nothing hidden. The
librarian rules are enforced in the engine, not in prompts: paths outside the
structure are refused; every tag used lands in the master list at once;
*My notes* is append-only; the AI must ask before creating a folder (tools
answer `needs_approval` until the request carries
`approve_new_folder=true`, which only happens after you agreed); and the AI
is instructed to write a manual log entry after any structural change it
makes to the app.

## Purpose

SecondBrain exists to keep a person's knowledge in a form that is:

- **Minimal effort** — a note is a text file in a folder; nothing else is
  required.
- **Universally extensible** — any new subject, tag or note type can be
  added without changing the system. New subject = new folder. New tag = one
  line in `_tags.md`.
- **Searchable, taggable and connected** — the ranking engine orders notes
  by how well they match, the tag system is global and always in sync, and
  wiki links tie notes together; the Connected notes panel is the map.
- **Durable** — plain UTF-8 Markdown with LF line endings, readable in any
  editor, on any operating system, forever.
- **Auditable** — manual log entries name their maker; the automatic edit
  history records exactly which lines changed; undo always asks.
- **Recoverable** — the backup tool makes the chosen folder **byte-identical**
  to the project, keeps every replaced file in a dated `.versions/` folder,
  re-hashes EVERY file in scope before it calls a run successful, and never
  writes anything inside the live project.

## The folder structure and every fixed file

The structure is strict on purpose: the health check reports anything that is
not on the allowed list, and the tools refuse to create anything outside it.

### Top level

| Path | What it is |
| --- | --- |
| `README.md` | this file |
| `SKILL.md` | the complete AI manual (vocabulary, rules, tools, examples) |
| `StructureOFnotes.md` | the exact note format rulebook — every example verified by a test |
| `LOGS.md` | the log rules: manual entries only, the AI instruction, edits.md |
| `_tags.md` | master tag vocabulary: approved tags, per-tag synonyms, general synonyms, proposed tags |
| `FIXES.md` | the v4 change log with proof for every item |
| `Cargo.toml`, `Cargo.lock` | the Rust workspace manifest and lockfile |
| `database/` | every note, as subject folders to any depth |
| `inbox/` | raw notes waiting for the AI librarian (plain `.md`/`.txt`) |
| `logs/` | `YYYY-MM-DD_HH-MM-SS_<title>.md` manual entries + `edits.md` (automatic) |
| `core/` | the engine crate: `Cargo.toml`, `src/`, `tests/`, `settings.json`, `.cache/` |
| `mcp/` | the MCP server crate (`src/main.rs`) |
| `website/` | the website crate: `src/main.rs`, `static/` (compiled UI), `app/` (UI sources) |
| `backup/` | the backup CLI crate |
| `scripts/` | helper scripts (dev convenience) |
| `target/` | Rust build output (created by `cargo build`) |
| `bin/` | prebuilt linux-x64 binaries shipped with the zip |

### Inside `database/`

Subject folders nest to any depth (`Learning › Languages › Vocabulary`). A
subject folder may contain an optional `_subject.md` with four fields:

```
Purpose: coffee and tea
Template: Tasting Note
Sensitivity: private
Inherits: sensitivity
```

`Sensitivity: private` hides and locks the folder and excludes it from the
search index (inherited by sub-folders unless overridden). `Template` names a
note whose body is used when creating notes here.

Each note lives in its **own folder**, named exactly like the note:

```
database/Recipes/Quick Vegetable Pasta for Weeknights/
├── Quick Vegetable Pasta for Weeknights.md   the note itself
├── tags.txt                                  its tags, comma separated
└── attachments/                              images used by the note
```

File names are detailed and descriptive (they are the wiki links) and are
unique across the whole wiki, even ignoring capital letters.

### The engine crates

| Crate | Role |
| --- | --- |
| `core/src/textutil.rs` | normalization, tokenizer, stemmer, edit distance, typo buckets |
| `core/src/paths.rs` | project layout, safe names, the allowed-structure check |
| `core/src/tags.rs` | tag notation, `tags.txt`, the `_tags.md` master, the auto tag extractor |
| `core/src/parser.rs` | the ONE note parser: quick info, sections, links, references, metadata |
| `core/src/store.rs` | every write operation (create/edit/move, tags, connections, images, inbox filing) |
| `core/src/editlog.rs` | the automatic note-edit history (`logs/edits.md`) + the undo journal |
| `core/src/logger.rs` | manual log entries, log listing and reading |
| `core/src/indexer.rs` | the incremental index (only re-parses notes whose hash changed) |
| `core/src/search.rs` | the ranking search pipeline |
| `core/src/healthcheck.rs` | fault-isolated health checks + fix actions |
| `core/src/images.rs` | attachments: add, crop (in-process), thumbnails, delete with history |
| `core/src/backup.rs` | backup, sync and restore library (used by the CLI and the API) |
| `core/tests/` | the fixed ranking test set + the verified-structure-examples test |
| `website/src/main.rs` | the axum server: the JSON API + static files |
| `mcp/src/main.rs` | the MCP tool server (newline-delimited JSON-RPC 2.0 on stdio) |
| `backup/src/main.rs` | the backup CLI |

`core/settings.json` holds the tunables: ranking weights, page size,
typo tolerance, BM25 parameters, default theme, server port/bind, saved
searches. Every value can also be changed from the AI with
`update_settings`, and the Settings page edits the common ones.

## The tag notation

Tags are plain text a non-coder can edit:

- A note's `tags.txt` holds comma-separated entries:
  `COOKING-weeknight, FOOD-pasta-vegetarian, METHOD-stovetop-one_pot`
- **Every tag is one independent name.** Dashes and underscores are just
  characters; `FOOD-pasta-vegetarian` has no relationship to `FOOD-pasta` or
  `FOOD` — nothing is implied, nothing propagates. Search matches a tag
  exactly (capitals ignored).
- A space inside a tag name is written as an underscore
  (`HOME_REPAIR-wall_painting`); commas never appear inside a tag.
- **Always in sync:** a tag used on any note — added on the website, by the
  AI, or in a `tags.txt` by hand — appears in the Approved tags of
  `_tags.md` at once, and the Tags page lists every tag in use with its
  count. The global index and the per-file tags cannot drift apart.
- `_tags.md` is the master vocabulary. Under `## Approved tags` every tag is
  listed (grouped under `### MAJOR` headings for readability only, each line
  optionally `TAG: synonym, synonym`). The `## Synonyms` section maps general
  search words (`quick: fast, rapid, speedy`). `## Proposed tags` holds tags
  the AI wants to add; they become usable when you approve them (one click
  on the Tags page).

## Search: modes, scopes and ranking

The engine has **no semantic model**. It ranks *notes*, never text chunks;
tags and keywords are boosters, not filters. Three modes:

- **Ranking only** (default) — nothing is excluded; signals only order.
- **Strict keyword** — only notes containing *every* query word (any order;
  synonyms satisfy it; `"quoted words"` are an exact phrase).
- **Strict tag** — only notes carrying *all* selected tags.

You can also pick subjects (a hard boundary — the search never looks
outside, sub-folders included, with a *this folder only* toggle), pick tags
(only real tags can be chosen; every available tag shows up as you type),
choose the scope (file name / tags / headings / body / folder path), and
filter by date. A **How to use** button on the search page explains all of
it in plain language.

Every query is understood the same way on the website and from the AI:
lowercased, accents stripped, dashes/underscores as spaces, filler words
dropped but negations kept, words stemmed so endings match, one wrong letter
tolerated for words of five or more letters, words matching an approved tag
(or a tag synonym) becoming query tags. Query words expand into concept
groups (the word, its stem, its synonyms — your words count fully, synonyms
0.7, and a note earns a group once through its best term).

Candidates come from tag hits, keyword hits, neighbors (notes sharing at
least two tags with a top-5 hit or connected to one) and a fallback that
keeps results from ever being blank. Every candidate is scored:

| Signal | Weight |
| --- | --- |
| Tags (exact match only — tags are independent; rarer tags count more) | 34% |
| Title and aliases (share of groups found) | 24% |
| Headings and quick-info labels (BM25) | 14% |
| Neighbors | 12% |
| Body (BM25, length-normalized) | 10% |
| Closeness (words near each other / same section) | 6% |

`final = 100 × weighted sum × coverage`, where coverage is
`0.4 + 0.6 × (share of query groups matched)` — matching every part of the
query beats matching one part many times. Signals that do not apply have
their weight shared among the rest; each signal is scaled against the best
candidate; an exact title or alias match ranks first; a neighbor-only note
never outranks a direct match; ties break by more groups matched, more
recently updated, then title A–Z — identical on every run. Results come 20
at a time (*Show 20 more* continues the same list), and every result
explains itself: a one-sentence reason plus *Why this ranking* with the
exact signal bars (only the signals that actually applied).

The weights live in `core/settings.json`. `cargo test -p secondbrain-core
--test ranking` runs the fixed query set and fails loudly if ranking
regresses.

## The website

Run `./target/release/secondbrain-website` (options: `--port`, `--bind`,
`--no-browser`, `--rebuild`). It listens on this computer only; opening it
to the home network is an explicit setting (`server_bind` in
`core/settings.json`).

- **App shell** — sidebar (Home / Search / Files / Tags / Health / Logs /
  Backup / Settings), mobile slide-in nav, top bar with the one-step Back
  button and the theme picker.
- **Home** — gradient hero with search, saved searches, stat cards, pinned
  and recently updated notes, quick actions.
- **Search** — the two numbered groups (*How should it match?* and *Narrow
  by tags & folders*), the How-to-use guide, scopes with plain labels, date
  range, *Show 20 more*, and per-result score badges with a reason sentence
  and the *Why this ranking* signal bars.
- **Note page** — breadcrumbs; the quick info card (image rows render the
  picture); the rendered note with **tappable checklist boxes** (the tick is
  saved to the file); then **Connected notes** — the clean two-column list
  (Connects to / Referenced by), no graph anywhere; then **Reference
  sources** (type `example.com`, https is added for you), the **Tags panel**
  (chips with × to remove; typing shows every existing tag with its note
  count), the **Metadata** panel and the **Attachments** panel (upload,
  insert, delete with backup history). Plus Copy note, Export metadata
  (exact file location, all tags on the note and every tag used in the
  wiki), Print/PDF, pin, and **Find in note** (`Ctrl+F`) — the find bar is
  sticky at the top in preview AND edit mode.
- **Editing** — raw Markdown with the **sticky smart toolbar**: select a
  word and tap any tool to format it (tap again to undo); the cursor lands
  exactly where you continue. **Table** opens the real grid editor (add and
  remove rows/columns, type in cells, update in place). **Link** connects
  the selected word to any note or website. Saving checks the file hash
  first and asks before overwriting; every save lands in the automatic edit
  history (lines added/removed).
- **Images** — consecutive images render as a **grid**; hover controls move
  an image left/right/up/down and resize it (25/50/75/100%); click for full
  screen; upload from the editor's Image tool or the Attachments panel;
  delete keeps the file in backup history.
- **Tags page** — one flat list of independent tags with counts; per-tag
  actions (see the notes, rename, merge, remove everywhere), add/rename/
  merge with a preview of every affected note, one-click approval for
  proposed and unapproved tags, and the `_tags.md` raw editor.
- **Files** — a real folder browser: click into any folder, see its notes
  and subfolders as cards, create a note or subfolder **right here**,
  rename/move/delete the folder, private folders marked.
- **Health** — fault-isolated check cards (a broken check can never take the
  page down), each fixable finding with a **one-click repair**.
- **Logs** — the manual log (with **New log entry**), the automatic **edit
  history** (lines added/removed per note edit) and the **undo journal**
  with Undo buttons that always ask first.
- **Backup** — a three-step page: choose folder + scope + direction,
  preview, run & verify. Success means byte-identical: every file in scope
  re-hashed on both sides.
- **Settings** — the 12-theme picker with swatches, reading font size,
  results per page, typo tolerance, ranking weights display, index rebuild.

12 themes are built in — six dark (**Grey is the default**, Ocean Blue,
Forest, Plum, Crimson, Amber) and six light that never use white (Light Sky,
Light Sage, Light Rose, Light Sand, Light Lavender, Light Paper). In a light
theme the background is a deeper tinted shade of the hue and the interactive
cards and buttons are lighter shades — cozy and low-glare. Reading font and
text size are adjustable. Keyboard: `/` opens search, `e` toggles edit on a
note, `Ctrl+S` saves in the editor, `Ctrl+F` finds in the note, `Alt+←` goes
back, `Ctrl/⌘+K` opens the command palette.

## The AI tools (MCP)

The AI gets **42 tools** — the full list with inputs is in SKILL.md §9:
`search_notes`, `suggest_tags`, `list_tags`, `list_folders` /
`list_subjects`, `list_notes`, `read_note`, `get_connections`, `file_note`,
`create_note`, `edit_note`, `append_my_notes`, `move_note`, `rename_note`,
`edit_tags`, `connect_notes`, `add_reference`, `edit_quick_info`,
`add_attachment`, `edit_links`, `edit_metadata`, `export_metadata`,
`crop_image`, `delete_image`, `rename_tag`, `merge_tags`, `approve_tags`,
`health_check`, `get_health_data`, `health_fix`, `toggle_task`,
`backup_preview`, `backup_run`, `backup_restore`, `backup_verify`,
`undo_change`, `saved_searches`, `get_structure`, `add_log_entry`,
`get_edit_history`, `get_settings`, `update_settings`.

Highlights of the v4 additions:

- `get_health_data` / `health_check` — the full health report as JSON.
- `get_settings` / `update_settings` — read and change the rank and advanced
  settings (weights, coverage base, synonym weight, typo tolerance, page
  size, BM25 parameters, theme, server settings) **before** a search; the
  change takes effect on the next search.
- `add_log_entry` — the manual log tool the AI uses (and is required to use
  after structural changes).
- `get_edit_history` — the automatic note-edit history (lines added/removed).
- `list_notes` — every note with path, title, folder, tags, dates.

## Tests and verification

```bash
cargo test                                     # everything
cargo test -p secondbrain-core --test ranking  # the fixed ranking test set
cargo test -p secondbrain-core --test structure_examples
                                               # StructureOFnotes.md examples
```

- **17 unit tests** cover the stemmer, tokenizer, parser, tags, tasks,
  URLs, section rebuilding and the diff.
- **The ranking suite** runs 17 fixed queries with expected top results
  (synonyms, typo tolerance, word endings, folder boundaries, strict modes,
  coverage, determinism and the score formula) plus the behavior rules
  (independent tags, fallback never blank, require-mode notices).
- **The structure-examples test** extracts every `verify=` example from
  StructureOFnotes.md and runs it through the real parser, tag rules and
  reference parsing — the rulebook is executable.
- The v4 end-to-end flow was exercised over the real HTTP API and the real
  MCP stdio server during development: create/edit/undo, tag sync, edit
  history, backup run + verify, and all 42 tool calls.

## Building the UI (only when you change it)

The compiled app ships prebuilt in `website/static/`. To change the UI:

```bash
cd website/app
npm install
./deploy.sh          # npm run build + copy into website/static/
```

The UI sources live in `website/app/src/` (React + TypeScript + Tailwind,
shadcn/ui components in `components/ui/`, views in `views/`, the Markdown
renderer in `lib/markdown.tsx`).

## Privacy and safety

- Everything runs on this computer. The server binds `127.0.0.1` by default.
- The backup tool refuses any backup folder inside the project.
- The AI can never overwrite your `## My notes` lines (append-only),
  cannot create folders without your approval, cannot touch paths outside
  the allowed structure, and every write it makes is visible in the undo
  journal — reversible with one click.
