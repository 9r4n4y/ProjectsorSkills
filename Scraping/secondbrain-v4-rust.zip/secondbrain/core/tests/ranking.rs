//! The fixed ranking test set — a faithful port of `core/test_ranking.py`.
//!
//! A fixed set of queries with expected top results protects against
//! ranking regressions. Run: `cargo test -p secondbrain-core --test ranking`

use sbcore::{indexer, paths, search};
use std::collections::HashMap;

const PASTA: &str =
    "database/Recipes/Quick Vegetable Pasta for Weeknights/Quick Vegetable Pasta for Weeknights.md";
const GARLIC: &str = "database/Recipes/Garlic Bread/Garlic Bread.md";
const SOUP: &str = "database/Recipes/Lentil Soup for Cold Evenings/Lentil Soup for Cold Evenings.md";
const SPANISH: &str =
    "database/Learning/Languages/Vocabulary/Spanish Kitchen Words/Spanish Kitchen Words.md";
const SETUP: &str = "database/Projects/SecondBrain Setup/SecondBrain Setup.md";
const GARDEN: &str = "database/Projects/Garden Plan 2026/Garden Plan 2026.md";

struct Case {
    name: &'static str,
    q: &'static str,
    mode: &'static str,
    tags: Vec<&'static str>,
    folders: Vec<&'static str>,
    scope: Vec<&'static str>,
    tag_mode: &'static str,
    expected: Expect,
}

enum Expect {
    Top(&'static str),
    InTop3(&'static str),
    FolderBoundary,
    None,
}

fn s(q: &'static str, expected: Expect) -> Case {
    Case {
        name: "",
        q,
        mode: "rank",
        tags: vec![],
        folders: vec![],
        scope: vec![],
        tag_mode: "rank",
        expected,
    }
}

#[test]
fn ranking_expectations_hold() {
    // make sure the engine roots itself at the project (cwd = core/ during tests)
    std::env::set_var("SB_ROOT", paths::discover_root().to_string_lossy().to_string());

    let cases: Vec<(&str, Case)> = vec![
        ("quick vegetable pasta", Case { name: "quick vegetable pasta", ..s("quick vegetable pasta", Expect::Top(PASTA)) }),
        ("single word pasta", Case { name: "single word pasta", ..s("pasta", Expect::Top(PASTA)) }),
        ("garlic side", Case { name: "garlic side", ..s("garlic", Expect::Top(GARLIC)) }),
        ("synonyms: fast veggie meal", Case { name: "syn fast veggie meal", ..s("fast veggie meal", Expect::Top(PASTA)) }),
        ("synonyms: speedy dish", Case { name: "syn speedy dish", ..s("speedy dish", Expect::Top(PASTA)) }),
        ("typo tolerance: pastha", Case { name: "typo pastha", ..s("pastha", Expect::Top(PASTA)) }),
        ("typo tolerance: lental", Case { name: "typo lental", ..s("lental", Expect::Top(SOUP)) }),
        ("word endings: recipes", Case { name: "recipes in top3", ..s("recipes", Expect::InTop3(PASTA)) }),
        ("vocabulary words", Case { name: "vocabulary words", ..s("vocabulary words", Expect::Top(SPANISH)) }),
        ("project search", Case { name: "secondbrain setup", ..s("secondbrain setup", Expect::Top(SETUP)) }),
        ("garden tomatoes", Case { name: "garden tomatoes", ..s("garden tomatoes", Expect::Top(GARDEN)) }),
        (
            "folder boundary",
            Case {
                name: "folder boundary",
                q: "pasta",
                folders: vec!["Learning"],
                expected: Expect::FolderBoundary,
                ..Case { name: "", q: "", mode: "rank", tags: vec![], folders: vec![], scope: vec![], tag_mode: "rank", expected: Expect::None }
            },
        ),
        (
            "strict keyword drops partial",
            Case {
                name: "strict keyword",
                q: "lentil garlic",
                mode: "strict_keyword",
                expected: Expect::Top(SOUP),
                ..Case { name: "", q: "", mode: "rank", tags: vec![], folders: vec![], scope: vec![], tag_mode: "rank", expected: Expect::None }
            },
        ),
        (
            "strict tag requires all",
            Case {
                name: "strict tag",
                q: "",
                tags: vec!["FOOD-pasta-vegetarian"],
                mode: "strict_tag",
                expected: Expect::Top(PASTA),
                ..Case { name: "", q: "", mode: "rank", tags: vec![], folders: vec![], scope: vec![], tag_mode: "rank", expected: Expect::None }
            },
        ),
        (
            "empty query with tag",
            Case {
                name: "empty query tag",
                q: "",
                tags: vec!["INGREDIENT-lentils"],
                expected: Expect::Top(SOUP),
                ..Case { name: "", q: "", mode: "rank", tags: vec![], folders: vec![], scope: vec![], tag_mode: "rank", expected: Expect::None }
            },
        ),
        (
            "scope file name only",
            Case {
                name: "scope file name",
                q: "bread",
                scope: vec!["file name"],
                expected: Expect::Top(GARLIC),
                ..Case { name: "", q: "", mode: "rank", tags: vec![], folders: vec![], scope: vec![], tag_mode: "rank", expected: Expect::None }
            },
        ),
        ("coverage: both groups beat one", Case { name: "coverage", ..s("quick pasta", Expect::Top(PASTA)) }),
    ];

    let idx = indexer::load_index().expect("index builds from the project data");
    let mut failures: Vec<String> = Vec::new();

    for (label, c) in &cases {
        let arr = |v: &[&str]| -> Vec<String> { v.iter().map(|x| x.to_string()).collect() };
        let res = search::search(
            &idx,
            &c.q,
            &c.mode,
            &arr(&c.tags),
            &arr(&c.folders),
            false,
            &{
                let sc = arr(&c.scope);
                if sc.is_empty() { vec!["everything".to_string()] } else { sc }
            },
            if c.tag_mode == "require" { "require" } else { "rank" },
            if c.mode == "strict_keyword" { "require" } else { "rank" },
            false,
            None,
            None,
            None,
            &[],
            0,
            None,
        );
        let paths: Vec<&str> = res["results"]
            .as_array()
            .map(|a| a.iter().filter_map(|r| r["path"].as_str()).collect())
            .unwrap_or_default();
        let ok = match &c.expected {
            Expect::Top(want) => paths.first() == Some(want),
            Expect::InTop3(want) => paths.iter().take(3).any(|p| p == want),
            Expect::FolderBoundary => {
                !paths.is_empty() && paths.iter().all(|p| p.starts_with("database/Learning"))
            }
            Expect::None => paths.is_empty(),
        };
        println!(
            "[{}] {:38} -> {}",
            if ok { "PASS" } else { "FAIL" },
            label,
            paths.first().unwrap_or(&"(no results)")
        );
        if !ok {
            failures.push(format!("{label}: expected {:?}", c.expected_top()));
        }
    }

    // ---- Behavior rules that are not simple top-1 checks ----

    // strict keyword removes notes without every word
    let res = search::search(&idx, "lentil garlic", "strict_keyword", &[], &[], false, &["everything".into()], "rank", "require", false, None, None, None, &[], 0, None);
    let only: Vec<&str> = res["results"].as_array().map(|a| a.iter().filter_map(|r| r["path"].as_str()).collect()).unwrap_or_default();
    println!("[{}] strict keyword removed partial matches -> {:?}", if only.contains(&GARLIC) { "FAIL" } else { "PASS" }, only);
    if only.contains(&GARLIC) {
        failures.push("strict keyword completeness".into());
    }

    // strict tag FOOD-pasta-vegetarian -> exactly the pasta note
    let res = search::search(&idx, "", "strict_tag", &["FOOD-pasta-vegetarian".into()], &[], false, &["everything".into()], "require", "rank", false, None, None, None, &[], 0, None);
    let only: Vec<&str> = res["results"].as_array().map(|a| a.iter().filter_map(|r| r["path"].as_str()).collect()).unwrap_or_default();
    println!("[{}] strict tag FOOD-pasta-vegetarian -> {:?}", if only == vec![PASTA] { "PASS" } else { "FAIL" }, only);
    if only != vec![PASTA] {
        failures.push("strict tag".into());
    }

    // v1.1 rule kept: tags are independent — a deep tag does not satisfy its parent
    let res = search::search(&idx, "", "strict_tag", &["FOOD-pasta".into()], &[], false, &["everything".into()], "require", "rank", false, None, None, None, &[], 0, None);
    let empty = res["results"].as_array().map(|a| a.is_empty()).unwrap_or(true);
    println!("[{}] independent tags: deep tag does not satisfy parent", if empty { "PASS" } else { "FAIL" });
    if !empty {
        failures.push("independent tags".into());
    }

    // fallback: result never blank
    let res = search::search(&idx, "zzzqqq xyzzyq", "rank", &[], &[], false, &["everything".into()], "rank", "rank", false, None, None, None, &[], 0, None);
    let fb = res["fallback_used"].as_bool().unwrap_or(false);
    let n = res["results"].as_array().map(|a| a.len()).unwrap_or(0);
    println!("[{}] fallback: result never blank -> {n} results", if fb && n > 0 { "PASS" } else { "FAIL" });
    if !fb || n == 0 {
        failures.push("fallback".into());
    }

    // require-mode notice explains the removal
    let res = search::search(&idx, "pasta", "rank", &["FOOD-soup".into(), "FOOD-pasta".into()], &[], false, &["everything".into()], "require", "rank", false, None, None, None, &[], 0, None);
    let notice = res["notice"].as_str().unwrap_or("");
    let no_results = res["results"].as_array().map(|a| a.is_empty()).unwrap_or(true);
    println!("[{}] require-mode notice -> {notice}", if no_results && notice.contains("Require switch on tags") { "PASS" } else { "FAIL" });
    if !(no_results && notice.contains("Require switch on tags")) {
        failures.push("require notice".into());
    }

    // deterministic order across runs
    let r1 = search::search(&idx, "pasta", "rank", &[], &[], false, &["everything".into()], "rank", "rank", false, None, None, None, &[], 0, None);
    let r2 = search::search(&idx, "pasta", "rank", &[], &[], false, &["everything".into()], "rank", "rank", false, None, None, None, &[], 0, None);
    let p1: Vec<&str> = r1["results"].as_array().map(|a| a.iter().filter_map(|r| r["path"].as_str()).collect()).unwrap_or_default();
    let p2: Vec<&str> = r2["results"].as_array().map(|a| a.iter().filter_map(|r| r["path"].as_str()).collect()).unwrap_or_default();
    println!("[{}] deterministic order across runs", if p1 == p2 { "PASS" } else { "FAIL" });
    if p1 != p2 {
        failures.push("deterministic".into());
    }

    // score = 100 x weighted signals x coverage
    let first = &r1["results"][0];
    let breakdown = first["breakdown"].as_object().unwrap();
    let total: f64 = breakdown.values().filter_map(|v| v["points"].as_f64()).sum();
    let cov = first["coverage"].as_f64().unwrap_or(0.0);
    let score = first["score"].as_f64().unwrap_or(0.0);
    let ok = (score - 100.0 * total * cov).abs() < 0.5;
    println!("[{}] score formula (score={score}, signals={total:.3}, coverage={cov})", if ok { "PASS" } else { "FAIL" });
    if !ok {
        failures.push("score formula".into());
    }

    println!();
    if failures.is_empty() {
        println!("All ranking expectations hold.");
    } else {
        panic!("{} ranking expectation(s) failed:\n  - {}", failures.len(), failures.join("\n  - "));
    }
}

impl Case {
    fn expected_top(&self) -> String {
        match &self.expected {
            Expect::Top(w) => format!("top {w}"),
            Expect::InTop3(w) => format!("{w} in top 3"),
            Expect::FolderBoundary => "only Learning notes".into(),
            Expect::None => "no results".into(),
        }
    }
}

// silence unused warnings for the helper map (kept for future cases)
#[allow(dead_code)]
fn _unused(_: HashMap<&str, &str>) {}
