//! StructureOFnotes.md — the verified-examples test.
//!
//! Every fenced example in the rulebook marked with `verify=<name>` is
//! extracted from the real file and run through the real engine. If the
//! rulebook and the engine ever drift apart, this test fails.

use sbcore::{parser, tags as tags_mod};

fn project_root() -> std::path::PathBuf {
    std::path::Path::new(env!("CARGO_MANIFEST_DIR"))
        .parent()
        .unwrap()
        .to_path_buf()
}

/// Extract {name: block_text} for every fenced example preceded by prose
/// containing `verify=<name>`. Handles 3- and 4-backtick fences (the
/// Markdown showcase nests 3-backtick fences inside a 4-backtick fence).
fn extract_examples(doc: &str) -> Vec<(String, String)> {
    let mut out = Vec::new();
    let mut pending: Option<String> = None;
    let mut in_fence: Option<(usize, String)> = None; // (fence_len, collected)
    for line in doc.lines() {
        if let Some((len, buf)) = &mut in_fence {
            let ticks = line.trim_start().chars().take_while(|c| *c == '`').count();
            if ticks == *len && line.trim_end().trim_matches('`').trim().is_empty() {
                let name = pending.take().unwrap_or_default();
                out.push((name, buf.trim_end_matches('\n').to_string()));
                in_fence = None;
            } else {
                buf.push_str(line);
                buf.push('\n');
            }
            continue;
        }
        if let Some(idx) = line.find("verify=") {
            let rest = &line[idx + 7..];
            let name: String = rest
                .chars()
                .take_while(|c| c.is_ascii_alphanumeric() || *c == '-' || *c == '_')
                .collect();
            pending = Some(name);
        }
        let ticks = line.trim_start().chars().take_while(|c| *c == '`').count();
        let info = line.trim().trim_matches('`').trim();
        if ticks >= 3 {
            in_fence = Some((ticks, String::new()));
        }
    }
    out
}

fn get(examples: &[(String, String)], name: &str) -> String {
    examples
        .iter()
        .find(|(n, _)| n == name)
        .map(|(_, b)| b.clone())
        .unwrap_or_else(|| panic!("StructureOFnotes.md is missing the verify={name} example"))
}

#[test]
fn structure_examples_are_valid() {
    let doc = std::fs::read_to_string(project_root().join("StructureOFnotes.md"))
        .expect("StructureOFnotes.md must exist next to the workspace");
    let examples = extract_examples(&doc);
    assert!(
        examples.len() >= 6,
        "expected at least 6 verified examples, found {}: {:?}",
        examples.len(),
        examples.iter().map(|(n, _)| n).collect::<Vec<_>>()
    );

    // ---- note-minimal ----
    let minimal = get(&examples, "note-minimal");
    let doc1 = parser::parse_note(&minimal, "database/Recipes/Garlic Bread/Garlic Bread.md");
    assert_eq!(doc1.title, "Garlic Bread");
    assert_eq!(
        doc1.connected,
        vec!["Quick Vegetable Pasta for Weeknights".to_string()],
        "minimal note: connected section must parse"
    );
    assert_eq!(doc1.meta.get("created").map(String::as_str), Some("2026-10-15"));
    assert_eq!(doc1.meta.get("pinned").map(String::as_str), Some("no"));
    assert!(doc1.my_notes.contains("made with the pasta dinner"));

    // ---- note-quickinfo ----
    let qi = get(&examples, "note-quickinfo");
    let doc2 = parser::parse_note(
        &qi,
        "database/Recipes/Quick Vegetable Pasta for Weeknights/Quick Vegetable Pasta for Weeknights.md",
    );
    assert!(doc2.has_quick_info, "quick info block must be found");
    let serves = doc2
        .quick_info_rows
        .iter()
        .find(|r| r.label == "Serves")
        .expect("Serves row");
    assert_eq!(serves.value, "4");
    assert!(
        doc2.quick_info_rows
            .iter()
            .any(|r| r.group.as_deref() == Some("Dietary notes") && r.label == "Vegan"),
        "group rows must parse with their group"
    );
    let image = parser::qi_first_image(&doc2.quick_info_rows).expect("Image row");
    assert_eq!(image, "attachments/pasta-1.png");
    let aliases = parser::qi_aliases(&doc2.quick_info_rows);
    assert_eq!(aliases, vec!["Vegetable Pasta"], "Common name is a title alias");

    // ---- markdown-showcase ----
    let md = get(&examples, "markdown-showcase");
    assert!(
        md.contains("## Tables") && md.contains("| Ingredient | Amount |"),
        "showcase keeps its table"
    );
    assert_eq!(md.matches("- [ ] ").count(), 1, "one open task");
    assert_eq!(md.matches("- [x] ").count(), 1, "one done task");
    assert_eq!(md.matches("![The pan, mid-cook](attachments/pasta-2.png)").count(), 1);
    assert!(md.contains("![Plated, ready|50](attachments/pasta-3.png)"), "sized image syntax");
    assert!(md.contains("[[Garlic Bread|the side dish]]"), "wiki link with word");
    assert!(md.contains("[^1]: The note text of the footnote"), "footnote def");
    assert!(md.contains("$$\\int_0^1 x\\,dx$$"), "display math");
    // the nested python fence survives the 4-backtick outer fence
    assert!(md.contains("```python"), "nested code fence survives");
    // every task line matches the engine's task regex
    let task_re = regex::Regex::new(r"^(\s*(?:[-*]|\d+[.)])\s+)\[([ xX])\](\s+)(.*)$").unwrap();
    let tasks = md.lines().filter(|l| task_re.is_match(l)).count();
    assert_eq!(tasks, 2, "both task lines are recognized by the engine");

    // ---- tags ----
    let tag_block = get(&examples, "tags");
    let tags = tags_mod::parse_tags_txt(&tag_block).expect("tags.txt example must parse");
    assert_eq!(
        tags,
        vec![
            "COOKING-weeknight".to_string(),
            "FOOD-pasta-vegetarian".to_string(),
            "METHOD-stovetop-one_pot".to_string(),
            "INGREDIENT-garlic".to_string(),
        ]
    );
    // independent tags: no hierarchy at all
    assert!(tags_mod::relation("FOOD-pasta-vegetarian", "FOOD-pasta").is_none());
    assert!(tags_mod::relation("FOOD-pasta-vegetarian", "food-PASTA-VEGETARIAN").is_some());

    // ---- references ----
    let ref_block = get(&examples, "references");
    let refs = parser::parse_references(
        &ref_block.lines().map(|l| l.to_string()).collect::<Vec<_>>(),
    );
    assert_eq!(refs.len(), 1, "the reference line parses");
    assert_eq!(refs[0].title, "BBC Good Food: one-pot pasta technique");
    assert_eq!(refs[0].url, "https://www.bbcgoodfood.com/one-pot-pasta");
    assert_eq!(refs[0].accessed, "2026-10-15");

    // ---- metadata block (from section 9, picked up as verify=meta) ----
    if let Some((_, meta_block)) = examples.iter().find(|(n, _)| n == "meta") {
        let (_, _, meta) = parser::extract_blocks(meta_block);
        assert_eq!(meta.get("pinned").map(String::as_str), Some("yes"));
        assert_eq!(meta.get("updated").map(String::as_str), Some("2026-10-31"));
    }
}
