//! Project layout, name rules and allowed structure. A port of
//! `core/paths.py`, updated for the Rust workspace layout (v4).

use crate::error::{Result, SbError};
use crate::textutil::key_of;
use once_cell::sync::Lazy;
use regex::Regex;
use std::path::{Path, PathBuf};
use unicode_normalization::UnicodeNormalization;

pub static ROOT: Lazy<PathBuf> = Lazy::new(|| discover_root());
pub static DATABASE: Lazy<PathBuf> = Lazy::new(|| ROOT.join("database"));
pub static INBOX: Lazy<PathBuf> = Lazy::new(|| ROOT.join("inbox"));
pub static LOGS: Lazy<PathBuf> = Lazy::new(|| ROOT.join("logs"));
pub static CORE_DIR: Lazy<PathBuf> = Lazy::new(|| ROOT.join("core"));
pub static MCP_DIR: Lazy<PathBuf> = Lazy::new(|| ROOT.join("mcp"));
pub static WEBSITE_DIR: Lazy<PathBuf> = Lazy::new(|| ROOT.join("website"));
pub static BACKUP_DIR: Lazy<PathBuf> = Lazy::new(|| ROOT.join("backup"));
pub static CACHE: Lazy<PathBuf> = Lazy::new(|| CORE_DIR.join(".cache"));

/// Project root: `SB_ROOT` env var when set, otherwise the nearest ancestor
/// of the current directory holding both `core/` and `database/`.
pub fn discover_root() -> PathBuf {
    if let Ok(env_root) = std::env::var("SB_ROOT") {
        let p = PathBuf::from(env_root);
        if p.join("core").exists() {
            return p;
        }
    }
    let cwd = std::env::current_dir().unwrap_or_else(|_| PathBuf::from("."));
    for dir in cwd.ancestors() {
        if dir.join("core").exists() && dir.join("database").exists() {
            return dir.to_path_buf();
        }
    }
    cwd
}

pub static ROOT_FILES: &[&str] = &[
    "README.md",
    "SKILL.md",
    "FIXES.md",
    "StructureOFnotes.md",
    "_tags.md",
    "LOGS.md",
    "Cargo.toml",
    "Cargo.lock",
    ".gitignore",
    "run.sh",
    "build.sh",
];

pub static TOP_FOLDERS: &[&str] = &[
    "database", "inbox", "logs", "core", "mcp", "website", "backup", "target", "scripts", "bin",
];

pub static IMAGE_EXTS: &[&str] =
    &[".png", ".jpg", ".jpeg", ".gif", ".webp", ".svg", ".bmp"];

static FORBIDDEN_NAME_CHARS: Lazy<Regex> =
    Lazy::new(|| Regex::new(r#"[\\/:*?"<>|\x00-\x1f]"#).unwrap());

static LOGS_PATTERN: Lazy<Regex> =
    Lazy::new(|| Regex::new(r"^\d{4}-\d{2}-\d{2}_\d{2}-\d{2}-\d{2}_.+\.md$").unwrap());

/// Allowed entries inside `core/` (the Rust engine crate). `src/`, `tests/`
/// and `.cache/` are folders; everything else must be one of these files.
pub static CORE_ALLOWED_FILES: &[&str] = &["Cargo.toml", "settings.json"];
pub static CORE_ALLOWED_DIRS: &[&str] = &["src", "tests", ".cache"];

/// Allowed entries inside `mcp/` and `backup/`.
pub static BIN_CRATE_FILES: &[&str] = &["Cargo.toml", "README.md"];
pub static BIN_CRATE_DIRS: &[&str] = &["src"];

/// Allowed entries inside `website/`.
pub static WEBSITE_FILES: &[&str] = &["Cargo.toml", "README.md"];
pub static WEBSITE_FOLDERS: &[&str] = &["src", "static", "app"];

/// Allowed top-level entries inside `website/static/`.
pub static WEBSITE_STATIC_FILES: &[&str] = &["index.html", "favicon.svg"];
pub static WEBSITE_STATIC_DIRS: &[&str] = &["assets", "vendor"];

/// Allowed top-level entries inside `website/app/` (UI sources; node_modules
/// and dist are tooling/output and allowed).
pub static WEBSITE_APP_META: &[&str] = &[
    "package.json",
    "package-lock.json",
    "tsconfig.json",
    "tsconfig.node.json",
    "tsconfig.tsbuildinfo",
    "vite.config.ts",
    "tailwind.config.js",
    "postcss.config.js",
    "index.html",
    "deploy.sh",
    "README.md",
    ".gitignore",
    "components.json",
    "eslint.config.js",
];
pub static WEBSITE_APP_DIRS: &[&str] = &["src", "node_modules", "dist", "public", "scripts"];

pub fn is_image(name: &str) -> bool {
    let lower = name.to_lowercase();
    IMAGE_EXTS.iter().any(|ext| lower.ends_with(ext))
}

/// Normalize a note/folder display name. Raises when the name cannot be used
/// on every operating system.
pub fn clean_name(name: &str) -> Result<String> {
    let mut name = name.trim().nfc().collect::<String>();
    name = Regex::new(r"\s+").unwrap().replace_all(&name, " ").to_string();
    if name.is_empty() || name == "." || name == ".." {
        return Err(SbError::Invalid("Empty name is not allowed.".into()));
    }
    if FORBIDDEN_NAME_CHARS.is_match(&name) {
        return Err(SbError::Invalid(
            "Names may not contain \\ / : * ? \" < > | or control characters.".into(),
        ));
    }
    while name.ends_with(' ') || name.ends_with('.') || name.ends_with(':') {
        name.pop();
    }
    if name.is_empty() {
        return Err(SbError::Invalid("Empty name is not allowed.".into()));
    }
    if name.chars().count() > 120 {
        return Err(SbError::Invalid("Name is longer than 120 characters.".into()));
    }
    Ok(name)
}

/// Path relative to the project root, always with forward slashes.
pub fn rel(path: &Path) -> String {
    match path.strip_prefix(ROOT.as_path()) {
        Ok(p) => p.to_string_lossy().replace('\\', "/"),
        Err(_) => path.to_string_lossy().replace('\\', "/"),
    }
}

/// Join parts under base and refuse any escape from base (no `..`).
pub fn safe_join(base: &Path, parts: &[&str]) -> Result<PathBuf> {
    let mut p = base.to_path_buf();
    for part in parts {
        let part = part.trim().trim_matches('/');
        if part.is_empty() || part == "." || part == ".." || FORBIDDEN_NAME_CHARS.is_match(part) {
            return Err(SbError::Invalid(format!("Unsafe path element: {part:?}")));
        }
        p = p.join(part);
    }
    Ok(p)
}

/// Join a single slash-separated relative path under base (used everywhere).
pub fn safe_join_rel(base: &Path, rel: &str) -> Result<PathBuf> {
    let parts: Vec<&str> = rel.split('/').filter(|s| !s.is_empty()).collect();
    safe_join(base, &parts)
}

/// {path, problem} for every file or folder that is not on the allowed list.
fn add_problem(problems: &mut Vec<serde_json::Value>, p: &Path, problem: &str) {
    problems.push(serde_json::json!({"path": rel(p), "problem": problem}));
}

pub fn check_structure() -> Vec<serde_json::Value> {
    let mut problems: Vec<serde_json::Value> = Vec::new();

    let ok = match std::fs::read_dir(ROOT.as_path()) {
        Ok(rd) => rd,
        Err(_) => return problems,
    };
    let mut entries: Vec<PathBuf> = ok.filter_map(|e| e.ok()).map(|e| e.path()).collect();
    entries.sort();
    for child in entries {
        let name = match child.file_name().and_then(|n| n.to_str()) {
            Some(n) => n.to_string(),
            None => continue,
        };
        if child.is_file() {
            if !ROOT_FILES.contains(&name.as_str()) && !name.starts_with('.') {
                add_problem(&mut problems, 
                    &child,
                    &format!(
                        "File not allowed at the top level (allowed: {})",
                        ROOT_FILES.join(", ")
                    ),
                );
            }
        } else if child.is_dir() {
            if name == ".git" || name == ".cargo" || name == ".vscode" {
                continue; // tooling
            }
            if !TOP_FOLDERS.contains(&name.as_str()) {
                add_problem(&mut problems, 
                    &child,
                    &format!(
                        "Folder not allowed at the top level (allowed: {})",
                        TOP_FOLDERS.join(", ")
                    ),
                );
            }
        }
    }

    check_database(&mut problems);
    check_flat(&INBOX, &mut problems);
    check_logs(&mut problems);
    check_code_folder(&CORE_DIR, CORE_ALLOWED_FILES, CORE_ALLOWED_DIRS, &mut problems);
    check_code_folder(&MCP_DIR, BIN_CRATE_FILES, BIN_CRATE_DIRS, &mut problems);
    check_code_folder(&BACKUP_DIR, BIN_CRATE_FILES, BIN_CRATE_DIRS, &mut problems);
    check_website(&mut problems);
    problems
}

fn check_website(problems: &mut Vec<serde_json::Value>) {
    let entries = match std::fs::read_dir(WEBSITE_DIR.as_path()) {
        Ok(rd) => rd,
        Err(_) => return,
    };
    let mut children: Vec<PathBuf> = entries.filter_map(|e| e.ok()).map(|e| e.path()).collect();
    children.sort();
    for child in children {
        let name = child.file_name().and_then(|n| n.to_str()).unwrap_or("").to_string();
        if child.is_file() {
            if !WEBSITE_FILES.contains(&name.as_str()) {
                add_problem(problems, &child, "Unexpected file inside website/");
            }
        } else if child.is_dir() {
            if !WEBSITE_FOLDERS.contains(&name.as_str()) {
                add_problem(problems, &child, "Only src/, static/ and app/ are allowed inside website/");
                continue;
            }
            if name == "static" {
                check_static_dir(&child, problems);
            } else if name == "app" {
                check_app_dir(&child, problems);
            }
        }
    }
}

fn check_static_dir(static_dir: &Path, problems: &mut Vec<serde_json::Value>) {
    let entries = match std::fs::read_dir(static_dir) {
        Ok(rd) => rd,
        Err(_) => return,
    };
    let mut children: Vec<PathBuf> = entries.filter_map(|e| e.ok()).map(|e| e.path()).collect();
    children.sort();
    for f in children {
        let name = f.file_name().and_then(|n| n.to_str()).unwrap_or("").to_string();
        if f.is_dir() {
            if !WEBSITE_STATIC_DIRS.contains(&name.as_str()) {
                add_problem(problems, 
                    &f,
                    &format!(
                        "Unexpected folder inside website/static/ (allowed: {})",
                        WEBSITE_STATIC_DIRS.join(", ")
                    ),
                );
            }
        } else if !WEBSITE_STATIC_FILES.contains(&name.as_str()) {
            add_problem(problems, 
                &f,
                &format!(
                    "Unexpected file inside website/static/ (allowed: {} and the assets/ + vendor/ folders)",
                    WEBSITE_STATIC_FILES.join(", ")
                ),
            );
        }
    }
}

fn check_app_dir(app_dir: &Path, problems: &mut Vec<serde_json::Value>) {
    for f in walkdir::WalkDir::new(app_dir).min_depth(1).sort_by_file_name() {
        let Ok(entry) = f else { continue };
        let p = entry.path();
        let rp = match p.strip_prefix(app_dir) {
            Ok(rp) => rp,
            Err(_) => continue,
        };
        if rp.components().next().is_none() {
            continue;
        }
        let top = rp.components().next().unwrap().as_os_str().to_string_lossy().to_string();
        if entry.file_type().is_dir() {
            if !WEBSITE_APP_DIRS.contains(&top.as_str()) {
                add_problem(problems, p, "Unexpected folder inside website/app/");
            }
        } else if !WEBSITE_APP_DIRS.contains(&top.as_str())
            && !(rp.components().count() == 1 && WEBSITE_APP_META.contains(&top.as_str()))
        {
            add_problem(problems, p, "Unexpected file inside website/app/");
        }
    }
}

fn check_code_folder(
    folder: &Path,
    allowed_files: &[&str],
    allowed_dirs: &[&str],
    problems: &mut Vec<serde_json::Value>,
) {
    if !folder.exists() {
        return;
    }
    let entries = match std::fs::read_dir(folder) {
        Ok(rd) => rd,
        Err(_) => return,
    };
    let mut children: Vec<PathBuf> = entries.filter_map(|e| e.ok()).map(|e| e.path()).collect();
    children.sort();
    for child in children {
        let name = child.file_name().and_then(|n| n.to_str()).unwrap_or("").to_string();
        if child.is_dir() {
            if !allowed_dirs.contains(&name.as_str()) {
                add_problem(problems, 
                    &child,
                    &format!(
                        "Folder not allowed inside {}/ (allowed: {})",
                        folder.file_name().and_then(|n| n.to_str()).unwrap_or(""),
                        allowed_dirs.join(", ")
                    ),
                );
            }
        } else if !allowed_files.contains(&name.as_str()) {
            add_problem(problems, 
                &child,
                &format!(
                    "File not named in README.md (allowed here: {})",
                    allowed_files.join(", ")
                ),
            );
        }
    }
}

fn check_database(problems: &mut Vec<serde_json::Value>) {
    if !DATABASE.exists() {
        return;
    }
    check_subject_folder(&DATABASE, problems);
}

fn check_subject_folder(folder: &Path, problems: &mut Vec<serde_json::Value>) {
    let entries = match std::fs::read_dir(folder) {
        Ok(rd) => rd,
        Err(_) => return,
    };
    let mut children: Vec<PathBuf> = entries.filter_map(|e| e.ok()).map(|e| e.path()).collect();
    children.sort();
    for child in children {
        let name = child.file_name().and_then(|n| n.to_str()).unwrap_or("").to_string();
        if child.is_file() {
            if name == "_subject.md" {
                continue;
            }
            add_problem(problems, 
                &child,
                "Only note folders and _subject.md are allowed inside a subject folder",
            );
        } else if child.is_dir() {
            if child.join(format!("{name}.md")).exists() {
                check_note_folder(&child, problems);
            } else {
                check_subject_folder(&child, problems);
            }
        }
    }
}

fn check_note_folder(note_dir: &Path, problems: &mut Vec<serde_json::Value>) {
    let dir_name = note_dir.file_name().and_then(|n| n.to_str()).unwrap_or("").to_string();
    let expected_md = format!("{dir_name}.md");
    let mut found_md = false;
    let mut has_any = false;
    let entries = match std::fs::read_dir(note_dir) {
        Ok(rd) => rd,
        Err(_) => return,
    };
    let mut children: Vec<PathBuf> = entries.filter_map(|e| e.ok()).map(|e| e.path()).collect();
    children.sort();
    for child in children {
        has_any = true;
        let name = child.file_name().and_then(|n| n.to_str()).unwrap_or("").to_string();
        if child.is_file() {
            if name == expected_md {
                found_md = true;
            } else if name == "tags.txt" {
                continue;
            } else {
                add_problem(problems, 
                    &child,
                    "A note folder may only contain '<Note Name>.md' and 'tags.txt'",
                );
            }
        } else if child.is_dir() {
            if name == "attachments" {
                if let Ok(imgs) = std::fs::read_dir(&child) {
                    let mut imgs: Vec<PathBuf> =
                        imgs.filter_map(|e| e.ok()).map(|e| e.path()).collect();
                    imgs.sort();
                    for img in imgs {
                        let iname = img.file_name().and_then(|n| n.to_str()).unwrap_or("").to_string();
                        if img.is_file() && !is_image(&iname) {
                            add_problem(problems, &img, "attachments/ holds image files only");
                        } else if img.is_dir() {
                            add_problem(problems, &img, "Folders are not allowed inside attachments/");
                        }
                    }
                }
            } else {
                add_problem(problems, &child, "Only attachments/ is allowed inside a note folder");
            }
        }
    }
    if !found_md && has_any {
        add_problem(problems, note_dir, "Note folder is missing its '<Note Name>.md' file");
    }
}

fn check_flat(folder: &Path, problems: &mut Vec<serde_json::Value>) {
    if !folder.exists() {
        return;
    }
    for child in walkdir::WalkDir::new(folder).min_depth(1) {
        let Ok(entry) = child else { continue };
        let p = entry.path();
        if entry.file_type().is_dir() {
            add_problem(problems, p, "Folders are not allowed inside inbox/");
        } else {
            let name = p.file_name().and_then(|n| n.to_str()).unwrap_or("").to_lowercase();
            if !name.ends_with(".md") && !name.ends_with(".txt") {
                add_problem(problems, p, "Only .md and .txt files are allowed inside inbox/");
            }
        }
    }
}

fn check_logs(problems: &mut Vec<serde_json::Value>) {
    if !LOGS.exists() {
        return;
    }
    let entries = match std::fs::read_dir(LOGS.as_path()) {
        Ok(rd) => rd,
        Err(_) => return,
    };
    for child in entries.filter_map(|e| e.ok()) {
        let p = child.path();
        if !p.is_file() {
            add_problem(problems, &p, "logs/ holds only Markdown files");
            continue;
        }
        let name = p.file_name().and_then(|n| n.to_str()).unwrap_or("");
        if name == "edits.md" || LOGS_PATTERN.is_match(name) {
            continue; // edits.md = the one automatic note-edit history file
        }
        add_problem(problems, 
            &p,
            "logs/ holds only files named YYYY-MM-DD_HH-MM-SS_<title>.md (plus edits.md, the automatic edit history)",
        );
    }
}

/// Uniqueness helper re-exported for convenience.
pub fn same_name(a: &str, b: &str) -> bool {
    key_of(a) == key_of(b)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_clean_name() {
        assert!(clean_name("Garlic Bread").is_ok());
        assert!(clean_name("bad/name").is_err());
        assert!(clean_name("").is_err());
        assert_eq!(clean_name("  Spaced  Out  ").unwrap(), "Spaced Out");
    }
}
