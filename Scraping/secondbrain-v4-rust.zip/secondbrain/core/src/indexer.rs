//! The index. Files are the truth; the index is only a cache and can always
//! be rebuilt. Every file is hashed; only notes whose hash changed are
//! re-parsed. A faithful port of `core/indexer.py`.

use crate::error::{Result, SbError};
use crate::parser::{self, qi_aliases, qi_label_rows, qi_value_rows};
use crate::paths;
use crate::store;
use crate::tags as tags_mod;
use crate::textutil::{deletion_variants, key_of, normalize, stem, tokenize};
use serde::{Deserialize, Serialize};
use std::collections::{BTreeMap, HashMap, HashSet};

pub const INDEX_VERSION: u32 = 100;

fn cache_path() -> std::path::PathBuf {
    paths::CACHE.join("index.json")
}

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct NoteEntry {
    #[serde(default)]
    pub hash: String,
    #[serde(default)]
    pub tags_hash: String,
    #[serde(default)]
    pub title: String,
    #[serde(default)]
    pub folder: String,
    #[serde(default)]
    pub folder_path: String,
    #[serde(default)]
    pub headings: Vec<String>,
    #[serde(default)]
    pub heading_text: String,
    #[serde(default)]
    pub title_tokens: Vec<String>,
    #[serde(default)]
    pub tokens: Vec<String>,
    #[serde(default)]
    pub section_spans: Vec<(usize, usize)>,
    #[serde(default)]
    pub tags: Vec<String>,
    #[serde(default)]
    pub tag_text: String,
    #[serde(default)]
    pub aliases: Vec<String>,
    #[serde(default)]
    pub qi_labels: Vec<String>,
    #[serde(default)]
    pub connected: Vec<String>,
    #[serde(default)]
    pub linked_in_text: Vec<String>,
    #[serde(default)]
    pub references: Vec<parser::Reference>,
    #[serde(default)]
    pub meta: HashMap<String, String>,
    #[serde(default)]
    pub status: String,
    #[serde(default)]
    pub updated: String,
    #[serde(default)]
    pub created: String,
    #[serde(default)]
    pub pinned: bool,
    #[serde(default)]
    pub snippet_text: String,
    #[serde(default)]
    pub image: Option<String>,
    #[serde(default)]
    pub words: HashMap<String, i64>,
    #[serde(default)]
    pub heading_words: HashMap<String, i64>,
}

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct Index {
    pub version: u32,
    pub files: BTreeMap<String, NoteEntry>,
    pub generated: String,
    // derived (rebuilt on load, not stored)
    #[serde(skip)]
    pub n: usize,
    #[serde(skip)]
    pub df: HashMap<String, i64>,
    #[serde(skip)]
    pub h_df: HashMap<String, i64>,
    #[serde(skip)]
    pub avgdl: f64,
    #[serde(skip)]
    pub h_avgdl: f64,
    #[serde(skip)]
    pub graph: HashMap<String, Vec<String>>,
    #[serde(skip)]
    pub broken_links: HashMap<String, Vec<String>>,
    #[serde(skip)]
    pub backlinks: HashMap<String, Vec<String>>,
    #[serde(skip)]
    pub tag_map: HashMap<String, Vec<String>>,
    #[serde(skip)]
    pub typo_buckets: HashMap<String, Vec<String>>,
}

fn walk_notes() -> Vec<std::path::PathBuf> {
    let mut out: Vec<std::path::PathBuf> = walkdir::WalkDir::new(paths::DATABASE.as_path())
        .into_iter()
        .filter_map(|e| e.ok())
        .map(|e| e.path().to_path_buf())
        .filter(|p| {
            p.is_file()
                && p.extension().map(|x| x == "md").unwrap_or(false)
                && p.file_name().map(|n| n != "_subject.md").unwrap_or(false)
                && p.parent()
                    .and_then(|d| d.file_name())
                    .map(|d| d == p.file_stem().unwrap_or_default())
                    .unwrap_or(false)
        })
        .filter(|p| !store::is_private(p.parent().unwrap()))
        .collect();
    out.sort();
    out
}

fn tf(tokens: &[String]) -> HashMap<String, i64> {
    let mut tf: HashMap<String, i64> = HashMap::new();
    for t in tokens {
        *tf.entry(t.clone()).or_insert(0) += 1;
    }
    tf
}

fn index_one(md: &std::path::Path, rp: &str, h: &str) -> Result<NoteEntry> {
    let text = std::fs::read_to_string(md)?;
    let doc = parser::parse_note(&text, rp);
    let mut e = NoteEntry {
        hash: h.to_string(),
        title: doc.title.clone(),
        ..Default::default()
    };
    e.status = "unverified".into();
    let folder = md.parent().and_then(|d| d.parent()).unwrap();
    e.folder = paths::rel(folder).trim_start_matches("database/").to_string();
    e.folder_path = tokenize(&normalize(&e.folder.replace('/', " ")))
        .iter()
        .map(|t| stem(t))
        .collect::<Vec<_>>()
        .join(" ");
    e.title_tokens = tokenize(&normalize(&doc.title)).iter().map(|t| stem(t)).collect();
    e.headings = doc.headings.iter().map(|(_, t)| t.clone()).collect();
    e.qi_labels = qi_label_rows(&doc.quick_info_rows);
    e.heading_text = normalize(&format!(
        "{} {}",
        e.headings.join(" "),
        e.qi_labels.join(" ")
    ));
    e.aliases = qi_aliases(&doc.quick_info_rows)
        .iter()
        .map(|a| normalize(a))
        .collect();

    // Body tokens + section spans for closeness. Tokens are stems.
    let mut tokens: Vec<String> = Vec::new();
    let mut spans: Vec<(usize, usize)> = Vec::new();
    let mut plain: Vec<String> = Vec::new();
    for para in regex::Regex::new(r"\n\s*\n")
        .unwrap()
        .split(&doc.body)
    {
        let start = tokens.len();
        tokens.extend(tokenize(para).iter().map(|t| stem(t)));
        spans.push((start, tokens.len()));
        plain.push(para.to_string());
    }
    let qv = qi_value_rows(&doc.quick_info_rows).join(" ");
    if !qv.is_empty() {
        let start = tokens.len();
        tokens.extend(tokenize(&qv).iter().map(|t| stem(t)));
        spans.push((start, tokens.len()));
        plain.push(qv);
    }
    e.tokens = tokens;
    e.section_spans = spans;
    e.snippet_text = normalize(&plain.join(" "));
    e.words = tf(&e.tokens);
    e.heading_words = tf(&tokenize(&e.heading_text).iter().map(|t| stem(t)).collect::<Vec<_>>());

    let tags_file = md.parent().unwrap().join("tags.txt");
    if tags_file.exists() {
        e.tags_hash = store::sha256_of(&tags_file)?;
        e.tags = tags_mod::parse_tags_txt(&std::fs::read_to_string(&tags_file)?)?;
    }
    e.tag_text = tokenize(
        &e.tags
            .iter()
            .map(|t| t.replace('_', " ").replace('-', " "))
            .collect::<Vec<_>>()
            .join(" "),
    )
    .iter()
    .map(|t| stem(t))
    .collect::<Vec<_>>()
    .join(" ");
    e.connected = doc.connected.clone();
    e.linked_in_text = doc.linked_in_text.iter().map(|(t, _)| t.clone()).collect();
    e.references = doc.references.clone();
    e.meta = doc.meta.clone();
    e.status = doc.meta.get("status").cloned().unwrap_or_else(|| "unverified".into());
    e.updated = doc.meta.get("updated").cloned().unwrap_or_default();
    e.created = doc.meta.get("created").cloned().unwrap_or_default();
    e.pinned = doc.meta.get("pinned").map(|v| v.to_lowercase() == "yes").unwrap_or(false);
    e.image = parser::qi_first_image(&doc.quick_info_rows);
    Ok(e)
}

fn derive(idx: &mut Index) {
    let n = idx.files.len();
    idx.n = n;
    let mut df: HashMap<String, i64> = HashMap::new();
    let mut h_df: HashMap<String, i64> = HashMap::new();
    let mut dl_sum = 0usize;
    let mut h_dl_sum = 0usize;
    for e in idx.files.values() {
        for w in e.words.keys() {
            *df.entry(w.clone()).or_insert(0) += 1;
        }
        for w in e.heading_words.keys() {
            *h_df.entry(w.clone()).or_insert(0) += 1;
        }
        dl_sum += e.tokens.len();
        h_dl_sum += e.heading_words.values().sum::<i64>() as usize;
    }
    idx.avgdl = if n > 0 { dl_sum as f64 / n as f64 } else { 0.0 };
    idx.h_avgdl = if n > 0 { h_dl_sum as f64 / n as f64 } else { 0.0 };

    // Connection graph (explicit + linked-in-text), resolved by file name.
    let mut by_title: HashMap<String, String> = HashMap::new();
    for (rp, e) in &idx.files {
        by_title.insert(key_of(&e.title), rp.clone());
    }
    let mut graph: HashMap<String, Vec<String>> = HashMap::new();
    let mut broken: HashMap<String, Vec<String>> = HashMap::new();
    for (rp, e) in &idx.files {
        let mut targets: Vec<String> = Vec::new();
        for name in e.connected.iter().chain(e.linked_in_text.iter()) {
            match by_title.get(&key_of(name)) {
                Some(tgt) => {
                    if tgt != rp {
                        targets.push(tgt.clone());
                    }
                }
                None => {
                    let b = broken.entry(rp.clone()).or_default();
                    if !b.contains(name) {
                        b.push(name.clone());
                    }
                }
            }
        }
        targets.sort();
        targets.dedup();
        graph.insert(rp.clone(), targets);
    }
    idx.broken_links = broken;

    let mut backlinks: HashMap<String, Vec<String>> = idx.files.keys().map(|k| (k.clone(), Vec::new())).collect();
    for (rp, targets) in &graph {
        for t in targets {
            backlinks.entry(t.clone()).or_default().push(rp.clone());
        }
    }
    for v in backlinks.values_mut() {
        v.sort();
        v.dedup();
    }
    idx.backlinks = backlinks;
    idx.graph = graph;

    // Tag -> notes map. Tags are INDEPENDENT: a tag matches only itself.
    let mut tag_map: HashMap<String, Vec<String>> = HashMap::new();
    for (rp, e) in &idx.files {
        for t in &e.tags {
            tag_map.entry(key_of(t)).or_default().push(rp.clone());
        }
    }
    for v in tag_map.values_mut() {
        v.sort();
        v.dedup();
    }
    idx.tag_map = tag_map;

    // Deletion buckets for typo tolerance (words of 5+ letters).
    idx.df = df;
    idx.h_df = h_df;
    let mut buckets: HashMap<String, Vec<String>> = HashMap::new();
    let vocab: HashSet<String> = idx
        .df
        .keys()
        .chain(idx.h_df.keys())
        .cloned()
        .collect();
    for w in vocab {
        if w.chars().count() >= 5 {
            for d in deletion_variants(w.as_str()) {
                buckets.entry(d).or_default().push(w.clone());
            }
        }
    }
    idx.typo_buckets = buckets;
}

/// Load or build the index incrementally, then return it.
pub fn build_index(force: bool) -> Result<Index> {
    std::fs::create_dir_all(paths::CACHE.as_path())?;
    let mut idx: Option<Index> = None;
    if !force {
        if let Ok(text) = std::fs::read_to_string(cache_path()) {
            if let Ok(mut data) = serde_json::from_str::<Index>(&text) {
                if data.version == INDEX_VERSION {
                    data.n = data.files.len();
                    idx = Some(data);
                }
            }
        }
    }
    let mut idx = idx.unwrap_or(Index {
        version: INDEX_VERSION,
        ..Default::default()
    });

    let mut changed: Vec<String> = Vec::new();
    let live: HashSet<String> = walk_notes().iter().map(|md| paths::rel(md)).collect();
    for md in walk_notes() {
        let rp = paths::rel(&md);
        let h = store::sha256_of(&md).unwrap_or_default();
        let needs = match idx.files.get(&rp) {
            None => true,
            Some(e) => e.hash != h,
        };
        if needs {
            match index_one(&md, &rp, &h) {
                Ok(entry) => {
                    idx.files.insert(rp.clone(), entry);
                }
                Err(_) => continue,
            }
            changed.push(rp.clone());
        }
        // tags.txt can change without the .md changing
        let tags_file = md.parent().unwrap().join("tags.txt");
        let th = if tags_file.exists() {
            store::sha256_of(&tags_file).unwrap_or_default()
        } else {
            String::new()
        };
        let mut rederive_tags = false;
        {
            let entry = idx.files.get_mut(&rp).unwrap();
            if entry.tags_hash != th {
                entry.tags_hash = th;
                entry.tags = if tags_file.exists() {
                    tags_mod::parse_tags_txt(&std::fs::read_to_string(&tags_file)?)
                        .unwrap_or_default()
                } else {
                    Vec::new()
                };
                entry.tag_text = tokenize(
                    &entry
                        .tags
                        .iter()
                        .map(|t| t.replace('_', " ").replace('-', " "))
                        .collect::<Vec<_>>()
                        .join(" "),
                )
                .iter()
                .map(|t| stem(t))
                .collect::<Vec<_>>()
                .join(" ");
                rederive_tags = true;
            }
        }
        if rederive_tags && !changed.contains(&rp) {
            changed.push(rp);
        }
    }

    // Drop deleted notes.
    let stale: Vec<String> = idx.files.keys().filter(|rp| !live.contains(*rp)).cloned().collect();
    for rp in &stale {
        idx.files.remove(rp);
        changed.push(rp.clone());
    }

    derive(&mut idx);
    idx.generated = store::now_iso();
    let tmp = cache_path().with_extension("tmp");
    if std::fs::write(&tmp, serde_json::to_string(&idx)?).is_ok() {
        let _ = std::fs::rename(&tmp, cache_path());
    }
    Ok(idx)
}

pub fn rebuild_index() -> Result<Index> {
    let _ = std::fs::remove_file(cache_path());
    build_index(true)
}

/// Public entry used by the website and MCP: fresh enough on every call.
/// Only changed files are re-parsed.
pub fn load_index() -> Result<Index> {
    build_index(false)
}

/// List all notes for /api/state style views.
pub fn recent_notes(idx: &Index, k: usize) -> Vec<(String, NoteEntry)> {
    let mut v: Vec<(String, NoteEntry)> =
        idx.files.iter().map(|(k, v)| (k.clone(), v.clone())).collect();
    v.sort_by(|a, b| b.1.updated.cmp(&a.1.updated));
    v.into_iter().take(k).collect()
}
