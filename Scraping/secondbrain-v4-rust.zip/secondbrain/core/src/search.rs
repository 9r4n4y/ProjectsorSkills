//! The ranking search engine. No semantic or embedding model. Everything is
//! computed from tags, keywords, synonyms and links. Search ranks notes; it
//! never returns text chunks. A faithful port of `core/search.py`.

use crate::indexer::{Index, NoteEntry};
use crate::paths;
use crate::store;
use crate::tags as tags_mod;
use crate::textutil::{
    is_filler, is_keep_word, jaccard, key_of, levenshtein_leq1, normalize, stem, tokenize,
};
use serde::Serialize;
use std::collections::{BTreeMap, HashMap, HashSet};
use std::time::Instant;

// --------------------------------------------------------------------------
// Built-in general synonyms (the master file can add more)
// --------------------------------------------------------------------------

pub fn builtin_synonyms() -> HashMap<&'static str, Vec<&'static str>> {
    HashMap::from([
        ("quick", vec!["fast", "rapid", "speedy"]),
        ("fast", vec!["quick", "rapid", "speedy"]),
        ("rapid", vec!["quick", "fast", "speedy"]),
        ("speedy", vec!["quick", "fast", "rapid"]),
        ("recipe", vec!["dish", "meal"]),
        ("dish", vec!["recipe", "meal"]),
        ("meal", vec!["recipe", "dish"]),
        ("dinner", vec!["supper", "evening meal", "meal"]),
        ("lunch", vec!["midday meal", "meal"]),
        ("veggie", vec!["vegetable"]),
        ("vegetable", vec!["veggie"]),
        ("picture", vec!["image", "photo"]),
        ("photo", vec!["image", "picture"]),
        ("image", vec!["picture", "photo"]),
        ("word", vec!["vocabulary", "term"]),
        ("vocabulary", vec!["words", "terms"]),
        ("plan", vec!["planning", "idea"]),
        ("make", vec!["cook", "prepare"]),
        ("cook", vec!["make", "prepare"]),
        ("prepare", vec!["make", "cook"]),
        ("note", vec!["notes"]),
        ("soup", vec!["broth", "stew"]),
        ("stew", vec!["soup"]),
        ("fix", vec!["repair", "mend"]),
        ("repair", vec!["fix", "mend"]),
    ])
}

// --------------------------------------------------------------------------
// Step 1: understand the query
// --------------------------------------------------------------------------

#[derive(Debug, Clone, Default)]
pub struct Group {
    pub terms: Vec<(String, f64)>,
    pub phrase: bool,
    pub text: String,
    pub phrase_tokens: Vec<String>,
}

pub struct ParsedQuery {
    pub groups: Vec<Group>,
    pub query_tags: Vec<String>,
    pub phrases: Vec<String>,
    pub only_fillers: bool,
}

pub fn parse_query(q: &str, master: &tags_mod::MasterTags, settings: &serde_json::Value) -> ParsedQuery {
    static PHRASE_RE: once_cell::sync::Lazy<regex::Regex> =
        once_cell::sync::Lazy::new(|| regex::Regex::new(r#""([^"]+)""#).unwrap());
    let q = q.trim();
    let phrases: Vec<String> =
        PHRASE_RE.captures_iter(q).map(|c| c[1].to_string()).collect();
    let q_no_quotes = PHRASE_RE.replace_all(q, " ").to_string();
    let norm = normalize(&q_no_quotes);
    let all_words = tokenize(&norm);

    let only_fillers = !all_words.is_empty()
        && all_words.iter().all(|w| is_filler(w) && !is_keep_word(w));
    let words: Vec<String> = if only_fillers {
        all_words.clone()
    } else {
        all_words
            .iter()
            .filter(|w| !is_filler(w) || is_keep_word(w))
            .cloned()
            .collect()
    };

    let max_groups = settings
        .get("max_word_groups")
        .and_then(|v| v.as_i64())
        .unwrap_or(12) as usize;
    let mut groups: Vec<Group> = Vec::new();

    let tag_lookup = tags_mod::tag_synonym_to_tag(master);
    let mut query_tags: Vec<String> = Vec::new();

    // A word (or short run of words) matching an approved tag or a tag
    // synonym also becomes a query tag.
    {
        let mut found = false;
        'outer: for n in (2..=4).rev() {
            let mut i = 0;
            while i + n <= words.len() {
                let run = words[i..i + n].join(" ");
                if let Some(hit) = tag_lookup.get(&run.replace(' ', "-")) {
                    query_tags.push(hit.clone());
                    found = true;
                    break 'outer;
                }
                i += 1;
            }
        }
        let _ = found;
        for w in &words {
            if let Some(hit) = tag_lookup.get(w) {
                query_tags.push(hit.clone());
            }
        }
    }

    let mut gen_syn: HashMap<String, Vec<String>> = master.general_synonyms.clone();
    for (k, v) in builtin_synonyms() {
        gen_syn.entry(k.to_string()).or_insert_with(|| v.iter().map(|s| s.to_string()).collect());
    }

    let synonym_weight = settings
        .get("synonym_weight")
        .and_then(|v| v.as_f64())
        .unwrap_or(0.7);

    for w in &words {
        if groups.len() >= max_groups {
            break;
        }
        let s = stem(w);
        let mut terms: Vec<(String, f64)> = vec![(w.clone(), 1.0), (s.clone(), 1.0)];
        if let Some(syns) = gen_syn.get(w) {
            for syn in syns {
                for t in tokenize(syn) {
                    terms.push((t.clone(), synonym_weight));
                    terms.push((stem(&t), synonym_weight));
                }
            }
        }
        let mut seen: HashSet<String> = HashSet::new();
        terms.retain(|(t, _)| seen.insert(t.clone()));
        groups.push(Group { terms, phrase: false, text: w.clone(), phrase_tokens: Vec::new() });
    }
    for ph in &phrases {
        if groups.len() >= max_groups {
            break;
        }
        let toks = tokenize(ph);
        let terms: Vec<(String, f64)> =
            toks.first().map(|t| vec![(t.clone(), 1.0)]).unwrap_or_default();
        groups.push(Group {
            terms,
            phrase: true,
            text: ph.trim().to_string(),
            phrase_tokens: toks,
        });
    }

    // de-duplicate query tags, keep order
    let mut seen: HashSet<String> = HashSet::new();
    query_tags.retain(|t| seen.insert(key_of(t)));
    ParsedQuery { groups, query_tags, phrases, only_fillers }
}

// --------------------------------------------------------------------------
// Candidate collection
// --------------------------------------------------------------------------

fn scope_text(e: &NoteEntry, scope: &[String]) -> Vec<String> {
    let everything = scope.is_empty() || scope.iter().any(|s| s == "everything");
    let mut fields: Vec<String> = Vec::new();
    let wants = |name: &str| everything || scope.iter().any(|s| s == name);
    if wants("file name") || wants("filename") {
        fields.push(normalize(&e.title_tokens.join(" ")));
    }
    if wants("tags") {
        fields.push(e.tag_text.clone());
    }
    if wants("headings") {
        fields.push(e.heading_text.clone());
    }
    if wants("body") {
        fields.push(e.snippet_text.clone());
    }
    if wants("folder path") {
        fields.push(e.folder_path.clone());
    }
    fields
}

fn typo_words(idx: &Index, w: &str, min_len: usize) -> Vec<String> {
    if w.chars().count() < min_len {
        return Vec::new();
    }
    let mut cands: HashSet<String> = HashSet::new();
    let mut variants: Vec<String> = vec![w.to_string()];
    let chars: Vec<char> = w.chars().collect();
    for i in 0..chars.len() {
        let v: String = chars
            .iter()
            .enumerate()
            .filter(|(j, _)| *j != i)
            .map(|(_, c)| c)
            .collect();
        variants.push(v);
    }
    for v in &variants {
        if let Some(bucket) = idx.typo_buckets.get(v) {
            for cand in bucket {
                if cand != w && levenshtein_leq1(w, cand) {
                    cands.insert(cand.clone());
                }
            }
        }
    }
    let mut out: Vec<String> = cands.into_iter().collect();
    out.sort();
    out
}

fn term_in_titles(idx: &Index, term: &str) -> bool {
    idx.files.values().any(|e| e.title_tokens.iter().any(|t| t == term))
}

fn term_in_tags(idx: &Index, term: &str) -> bool {
    idx.files.values().any(|e| e.tag_text.split_whitespace().any(|t| t == term))
}

fn term_in_folders(idx: &Index, term: &str) -> bool {
    idx.files.values().any(|e| e.folder_path.split_whitespace().any(|t| t == term))
}

fn notes_with_term(idx: &Index, term: &str, scope: &[String]) -> Vec<String> {
    let everything = scope.is_empty() || scope.iter().any(|s| s == "everything");
    let wants = |name: &str| everything || scope.iter().any(|s| s == name);
    let mut out = Vec::new();
    for (rp, e) in &idx.files {
        if wants("body") && e.words.contains_key(term) {
            out.push(rp.clone());
            continue;
        }
        if wants("headings") && e.heading_words.contains_key(term) {
            out.push(rp.clone());
            continue;
        }
        if (wants("file name") || wants("filename")) && e.title_tokens.iter().any(|t| t == term) {
            out.push(rp.clone());
            continue;
        }
        if wants("tags") && tokenize(&e.tag_text).iter().any(|t| t == term) {
            out.push(rp.clone());
            continue;
        }
        if wants("folder path") && tokenize(&e.folder_path).iter().any(|t| t == term) {
            out.push(rp.clone());
            continue;
        }
    }
    out
}

fn keyword_hits(
    idx: &Index,
    groups: &[Group],
    scope: &[String],
    settings: &serde_json::Value,
) -> HashSet<String> {
    let min_len = settings
        .get("typo_min_length")
        .and_then(|v| v.as_i64())
        .unwrap_or(5) as usize;
    let use_typo = settings
        .get("typo_tolerance")
        .and_then(|v| v.as_bool())
        .unwrap_or(true);
    let mut hits: HashSet<String> = HashSet::new();
    for g in groups {
        if g.phrase {
            continue;
        }
        for (term, _wt) in &g.terms {
            let direct = idx.df.contains_key(term)
                || idx.h_df.contains_key(term)
                || term_in_titles(idx, term)
                || term_in_tags(idx, term)
                || term_in_folders(idx, term);
            if direct {
                for rp in notes_with_term(idx, term, scope) {
                    hits.insert(rp);
                }
            }
            if use_typo {
                for tw in typo_words(idx, term, min_len) {
                    for rp in notes_with_term(idx, &tw, scope) {
                        hits.insert(rp);
                    }
                }
            }
        }
    }
    hits
}

fn tag_hits(idx: &Index, query_tags: &[String], selected_tags: &[String]) -> HashSet<String> {
    let mut hits: HashSet<String> = HashSet::new();
    for qt in query_tags.iter().chain(selected_tags.iter()) {
        let k = key_of(qt);
        if let Some(notes) = idx.tag_map.get(&k) {
            hits.extend(notes.iter().cloned());
        }
        for (tk, notes) in &idx.tag_map {
            if tk.starts_with(&format!("{k}-")) || k.starts_with(&format!("{tk}-")) {
                hits.extend(notes.iter().cloned());
            }
        }
    }
    hits
}

fn apply_typo_corrections(
    idx: &Index,
    groups: &mut Vec<Group>,
    settings: &serde_json::Value,
) -> bool {
    let min_len = settings
        .get("typo_min_length")
        .and_then(|v| v.as_i64())
        .unwrap_or(5) as usize;
    if !settings
        .get("typo_tolerance")
        .and_then(|v| v.as_bool())
        .unwrap_or(true)
    {
        return false;
    }
    let mut added = false;
    for g in groups.iter_mut() {
        if g.phrase || g.text.chars().count() < min_len {
            continue;
        }
        if g.terms.iter().any(|(t, _)| idx.df.contains_key(t) || idx.h_df.contains_key(t)) {
            continue;
        }
        for c in typo_words(idx, &g.text, min_len) {
            let w = settings
                .get("synonym_weight")
                .and_then(|v| v.as_f64())
                .unwrap_or(0.7);
            g.terms.push((c.clone(), w));
            g.terms.push((stem(&c), w));
            added = true;
        }
        let mut seen: HashSet<String> = HashSet::new();
        g.terms.retain(|(t, _)| seen.insert(t.clone()));
    }
    added
}

fn neighbor_candidates(
    idx: &Index,
    top_hits: &[String],
) -> (HashMap<String, String>, HashMap<String, String>) {
    let mut out: HashMap<String, String> = HashMap::new();
    let mut src: HashMap<String, String> = HashMap::new();
    for hit in top_hits {
        let he = match idx.files.get(hit) {
            Some(e) => e,
            None => continue,
        };
        let linked = idx
            .graph
            .get(hit)
            .cloned()
            .unwrap_or_default()
            .into_iter()
            .chain(idx.backlinks.get(hit).cloned().unwrap_or_default());
        for linked in linked {
            if &linked != hit {
                out.entry(linked.clone()).or_insert_with(|| "connected".into());
                src.entry(linked).or_insert_with(|| hit.clone());
            }
        }
        let htags: HashSet<String> = he.tags.iter().map(|t| key_of(t)).collect();
        for (rp, e) in &idx.files {
            if rp == hit || out.contains_key(rp) {
                continue;
            }
            let shared = e.tags.iter().filter(|t| htags.contains(&key_of(t))).count();
            if shared >= 2 {
                out.insert(rp.clone(), "shared tags".into());
                src.insert(rp.clone(), hit.clone());
            }
        }
    }
    (out, src)
}

fn fallback_candidates(idx: &Index, groups: &[Group], k: usize) -> Vec<String> {
    let qwords: HashSet<String> = groups.iter().map(|g| stem(&g.text)).collect();
    let mut scored: Vec<(f64, String)> = Vec::new();
    for (rp, e) in &idx.files {
        let note_tags: HashSet<String> = e.tags.iter().map(|t| key_of(t)).collect();
        let title_stems: HashSet<String> = e.title_tokens.iter().cloned().collect();
        let mut s = 0.5 * jaccard(&qwords, &title_stems);
        s += 0.25 * ((note_tags.len() as f64) / 3.0).min(1.0);
        scored.push((s, rp.clone()));
    }
    scored.sort_by(|a, b| b.0.partial_cmp(&a.0).unwrap_or(std::cmp::Ordering::Equal).then_with(|| a.1.cmp(&b.1)));
    let top: Vec<String> = scored.iter().take(k).filter(|(s, _)| *s > 0.0).map(|(_, rp)| rp.clone()).collect();
    if top.is_empty() {
        scored.iter().take(k).map(|(_, rp)| rp.clone()).collect()
    } else {
        top
    }
}

// --------------------------------------------------------------------------
// Scoring
// --------------------------------------------------------------------------

fn bm25(
    tf: &HashMap<String, i64>,
    dl: usize,
    avgdl: f64,
    n_docs: usize,
    df: &HashMap<String, i64>,
    terms: &[(String, f64)],
    k1: f64,
    b: f64,
) -> f64 {
    let mut score = 0.0;
    for (term, weight) in terms {
        let f = *tf.get(term).unwrap_or(&0);
        if f == 0 {
            continue;
        }
        let n = *df.get(term).unwrap_or(&0);
        let idf = (1.0 + (n_docs as f64 - n as f64 + 0.5) / (n as f64 + 0.5)).ln();
        let denom = f as f64
            + k1 * (1.0 - b + b * (if avgdl > 0.0 { dl as f64 / avgdl } else { 1.0 }));
        score += weight * idf * (f as f64 * (k1 + 1.0)) / denom;
    }
    score
}

fn group_in_text(g: &Group, texts: &[&str]) -> bool {
    if g.phrase {
        let toks: Vec<String> = g.phrase_tokens.iter().map(|t| stem(t)).collect();
        let joined = toks.join(" ");
        if joined.is_empty() {
            return false;
        }
        return texts.iter().any(|t| {
            let stem_text = tokenize(t).iter().map(|x| stem(x)).collect::<Vec<_>>().join(" ");
            stem_text.contains(&joined)
        });
    }
    for (term, _wt) in &g.terms {
        let s = stem(term);
        for t in texts {
            if t.is_empty() {
                continue;
            }
            let words: Vec<&str> = t.split_whitespace().collect();
            if words.contains(&term.as_str()) || words.contains(&s.as_str()) {
                return true;
            }
            let stemmed: Vec<String> = tokenize(t).iter().map(|x| stem(x)).collect();
            if stemmed.contains(&s) {
                return true;
            }
        }
    }
    false
}

fn group_positions(g: &Group, tokens: &[String]) -> Vec<usize> {
    if g.phrase {
        let toks = &g.phrase_tokens;
        let mut out = Vec::new();
        if !toks.is_empty() {
            for i in 0..tokens.len().saturating_sub(toks.len()) + 1 {
                if &tokens[i..i + toks.len()] == toks.as_slice() {
                    out.push(i);
                }
            }
        }
        return out;
    }
    let mut out = Vec::new();
    for (i, t) in tokens.iter().enumerate() {
        for (term, _wt) in &g.terms {
            if t == term {
                out.push(i);
            }
        }
    }
    out
}

#[derive(Debug, Clone, Default)]
struct Scored {
    rp: String,
    raw: HashMap<String, f64>,
    matched_groups: usize,
    matched_tag_pairs: Vec<serde_json::Value>,
    title_hit: usize,
    direct: bool,
    neighbor_kind: Option<String>,
    query_has_tags: bool,
    score: f64,
    coverage: f64,
    breakdown: serde_json::Value,
    connected_to: Option<String>,
}

#[allow(clippy::too_many_arguments)]
fn score_note(
    idx: &Index,
    rp: &str,
    groups: &[Group],
    query_tags: &[String],
    selected_tags: &[String],
    direct: bool,
    neighbor_kind: Option<&str>,
    settings: &serde_json::Value,
) -> Scored {
    let e = &idx.files[rp];
    let k1 = settings
        .get("bm25")
        .and_then(|b| b.get("k1"))
        .and_then(|v| v.as_f64())
        .unwrap_or(1.5);
    let b_b = settings
        .get("bm25")
        .and_then(|b| b.get("b"))
        .and_then(|v| v.as_f64())
        .unwrap_or(0.75);
    let n_docs = idx.n;

    // ---- Tags signal (tags are independent: only exact matches count) ----
    let mut tag_score_raw = 0.0;
    let mut matched_tag_pairs: Vec<serde_json::Value> = Vec::new();
    if !query_tags.is_empty() || !selected_tags.is_empty() {
        for qt in query_tags.iter().chain(selected_tags.iter()) {
            let mut best: Option<(f64, String, String, f64)> = None;
            for nt in &e.tags {
                let rel_w = match tags_mod::relation(nt, qt) {
                    Some(w) => w,
                    None => continue,
                };
                let dfc = idx.tag_map.get(&key_of(nt)).map(|v| v.len()).unwrap_or(0).max(1);
                let rarity = ((1.0 + n_docs as f64 / dfc as f64).ln()
                    / (1.0 + n_docs.max(2) as f64).ln())
                .min(1.0);
                let val = rel_w * rarity;
                let better = match &best {
                    None => true,
                    Some((bv, _, _, _)) => val > *bv,
                };
                if better {
                    best = Some((val, qt.clone(), nt.clone(), rel_w));
                }
            }
            if let Some((val, qt, nt, rel_w)) = best {
                tag_score_raw += val;
                matched_tag_pairs.push(serde_json::json!({
                    "query_tag": qt, "note_tag": nt, "relation": rel_w,
                }));
            }
        }
    }

    // ---- Title and aliases: share of query groups found ----
    let title_norm = normalize(&e.title);
    let title_tokens_norm = normalize(&e.title_tokens.join(" "));
    let title_texts: Vec<String> = [title_norm]
        .into_iter()
        .chain(e.aliases.iter().cloned())
        .chain(std::iter::once(title_tokens_norm))
        .collect();
    let title_texts_ref: Vec<&str> = title_texts.iter().map(|s| s.as_str()).collect();
    let title_hit = groups.iter().filter(|g| group_in_text(g, &title_texts_ref)).count();
    let title_share = if !groups.is_empty() {
        title_hit as f64 / groups.len() as f64
    } else {
        0.0
    };

    // ---- Headings (BM25) ----
    let mut h_terms: Vec<(String, f64)> = Vec::new();
    let mut b_terms: Vec<(String, f64)> = Vec::new();
    for g in groups {
        if g.phrase {
            for t in &g.phrase_tokens {
                h_terms.push((t.clone(), 1.0));
                b_terms.push((t.clone(), 1.0));
            }
        } else {
            h_terms.extend(g.terms.iter().cloned());
            b_terms.extend(g.terms.iter().cloned());
        }
    }
    let h_dl = tokenize(&e.heading_text).len();
    let h_score = if !h_terms.is_empty() {
        bm25(
            &e.heading_words,
            h_dl,
            if idx.h_avgdl > 0.0 { idx.h_avgdl } else { 1.0 },
            n_docs,
            &idx.h_df,
            &h_terms,
            k1,
            b_b,
        )
    } else {
        0.0
    };

    // ---- Body (BM25) ----
    let b_score = if !b_terms.is_empty() {
        bm25(
            &e.words,
            e.tokens.len(),
            if idx.avgdl > 0.0 { idx.avgdl } else { 1.0 },
            n_docs,
            &idx.df,
            &b_terms,
            k1,
            b_b,
        )
    } else {
        0.0
    };

    // ---- Neighbors ----
    let nb_score = match neighbor_kind {
        Some(k) if k == "connected" => 1.0,
        Some(k) if k == "shared tags" => 0.8,
        _ => 0.0,
    };

    // ---- Closeness ----
    let mut close = 0.0;
    if groups.len() >= 2 {
        let positions: Vec<Vec<usize>> = groups
            .iter()
            .map(|g| group_positions(g, &e.tokens))
            .filter(|p| !p.is_empty())
            .collect();
        let window = settings
            .get("closeness_window_tokens")
            .and_then(|v| v.as_i64())
            .unwrap_or(40) as usize;
        let mut same_section = false;
        let mut near = false;
        for i in 0..positions.len() {
            for j in (i + 1)..positions.len() {
                for a in &positions[i] {
                    for b in &positions[j] {
                        if a.abs_diff(*b) <= window {
                            near = true;
                        }
                        for (s0, s1) in &e.section_spans {
                            if *s0 <= *a && *a < *s1 && *s0 <= *b && *b < *s1 {
                                same_section = true;
                            }
                        }
                    }
                }
            }
        }
        close = if near {
            1.0
        } else if same_section {
            0.7
        } else {
            0.0
        };
    }

    // ---- Groups matched (for coverage) ----
    let mut all_texts: Vec<&str> = title_texts_ref.clone();
    all_texts.push(&e.heading_text);
    all_texts.push(&e.snippet_text);
    all_texts.push(&e.tag_text);
    all_texts.push(&e.folder_path);
    let matched_groups = groups.iter().filter(|g| group_in_text(g, &all_texts)).count();

    let mut raw = HashMap::new();
    raw.insert("tags".to_string(), tag_score_raw);
    raw.insert("title".to_string(), title_share);
    raw.insert("headings".to_string(), h_score);
    raw.insert("neighbors".to_string(), nb_score);
    raw.insert("body".to_string(), b_score);
    raw.insert("closeness".to_string(), close);

    Scored {
        rp: rp.to_string(),
        raw,
        matched_groups,
        matched_tag_pairs,
        title_hit,
        direct,
        neighbor_kind: neighbor_kind.map(|s| s.to_string()),
        query_has_tags: !query_tags.is_empty() || !selected_tags.is_empty(),
        score: 0.0,
        coverage: 0.0,
        breakdown: serde_json::json!({}),
        connected_to: None,
    }
}

fn finalize_scores(scored: &mut [Scored], groups: &[Group], weights: &serde_json::Value, settings: &serde_json::Value) {
    if scored.is_empty() {
        return;
    }
    let n_groups = groups.len();
    let mut applicable: HashMap<String, bool> = HashMap::new();
    applicable.insert(
        "tags".to_string(),
        scored.iter().any(|x| x.raw["tags"] > 0.0) || scored.iter().any(|x| x.query_has_tags),
    );
    applicable.insert("title".to_string(), true);
    applicable.insert(
        "headings".to_string(),
        !groups.is_empty() && scored.iter().any(|x| x.raw["headings"] > 0.0),
    );
    applicable.insert(
        "neighbors".to_string(),
        scored.iter().any(|x| x.neighbor_kind.is_some()),
    );
    applicable.insert(
        "body".to_string(),
        !groups.is_empty() && scored.iter().any(|x| x.raw["body"] > 0.0),
    );
    applicable.insert(
        "closeness".to_string(),
        !groups.is_empty() && scored.iter().any(|x| x.raw["closeness"] > 0.0),
    );
    if groups.is_empty() {
        // empty query with tags ranks by tags (guard rail)
        applicable.insert("title".to_string(), false);
        applicable.insert("headings".to_string(), false);
        applicable.insert("body".to_string(), false);
        applicable.insert("closeness".to_string(), false);
    }

    let mut active: Vec<String> = applicable
        .iter()
        .filter(|(_, v)| **v)
        .map(|(k, _)| k.clone())
        .collect();
    if active.is_empty() {
        active = vec!["title".to_string()];
        applicable.insert("title".to_string(), true);
    }
    let total_w: f64 = active
        .iter()
        .map(|k| weights.get(k).and_then(|v| v.as_f64()).unwrap_or(0.0))
        .sum();
    let used: HashMap<String, f64> = active
        .iter()
        .map(|k| {
            let w = weights.get(k).and_then(|v| v.as_f64()).unwrap_or(0.0);
            (
                k.clone(),
                if total_w > 0.0 { w / total_w } else { 1.0 / active.len() as f64 },
            )
        })
        .collect();

    let mut scales: HashMap<String, f64> = HashMap::new();
    for k in &active {
        let m = scored
            .iter()
            .map(|x| *x.raw.get(k).unwrap_or(&0.0))
            .fold(f64::NEG_INFINITY, f64::max);
        scales.insert(k.clone(), if m > 0.0 { 1.0 / m } else { 0.0 });
    }

    let coverage_base = settings
        .get("coverage_base")
        .and_then(|v| v.as_f64())
        .unwrap_or(0.4);
    for x in scored.iter_mut() {
        let mut breakdown = serde_json::Map::new();
        let mut wsum = 0.0;
        for k in &active {
            let raw_v = *x.raw.get(k).unwrap_or(&0.0);
            let scale = *scales.get(k).unwrap_or(&0.0);
            let scaled = if scale > 0.0 { (raw_v * scale).min(1.0) } else { 0.0 };
            let w = *used.get(k).unwrap_or(&0.0);
            let points = w * scaled;
            wsum += points;
            breakdown.insert(
                k.clone(),
                serde_json::json!({
                    "weight": (w * 10000.0).round() / 10000.0,
                    "raw": (raw_v * 10000.0).round() / 10000.0,
                    "scaled": (scaled * 10000.0).round() / 10000.0,
                    "points": (points * 10000.0).round() / 10000.0,
                    "applied": true,
                }),
            );
        }
        let wk: Vec<String> = weights.as_object().map(|o| o.keys().cloned().collect()).unwrap_or_default();
        for k in wk {
            if !breakdown.contains_key(&k) {
                breakdown.insert(
                    k.clone(),
                    serde_json::json!({
                        "weight": 0.0,
                        "raw": (*x.raw.get(&k).unwrap_or(&0.0) * 10000.0).round() / 10000.0,
                        "scaled": 0.0,
                        "points": 0.0,
                        "applied": false,
                    }),
                );
            }
        }
        let coverage = if groups.is_empty() {
            1.0
        } else {
            coverage_base
                + (1.0 - coverage_base) * (x.matched_groups as f64 / n_groups.max(1) as f64)
        };
        x.coverage = (coverage * 10000.0).round() / 10000.0;
        x.score = (100.0 * wsum * coverage * 100.0).round() / 100.0;
        x.breakdown = serde_json::Value::Object(breakdown);
    }
}

// --------------------------------------------------------------------------
// Main entry
// --------------------------------------------------------------------------

#[allow(clippy::too_many_arguments)]
pub fn search(
    idx: &Index,
    q: &str,
    mode: &str,
    tags_sel: &[String],
    folders: &[String],
    folder_only: bool,
    scope: &[String],
    tag_mode: &str,
    kw_mode: &str,
    include_connected: bool,
    status: Option<&str>,
    date_from: Option<&str>,
    date_to: Option<&str>,
    limit_to: &[String],
    offset: usize,
    limit: Option<usize>,
) -> serde_json::Value {
    let t0 = Instant::now();
    let settings = store::load_settings();
    let weights = settings["ranking_weights"].clone();
    let page_size = settings
        .get("page_size")
        .and_then(|v| v.as_i64())
        .unwrap_or(20) as usize;
    let limit = limit.unwrap_or(page_size);
    let master = match tags_mod::load_master() {
        Ok(m) => m,
        Err(_) => tags_mod::MasterTags::default(),
    };

    let mut parsed = parse_query(q, &master, &settings);
    let mut query_tags = parsed.query_tags.clone();
    if apply_typo_corrections(idx, &mut parsed.groups, &settings) {
        // A corrected word can also be a query tag: pastha -> pasta -> FOOD-pasta.
        let tag_lookup = tags_mod::tag_synonym_to_tag(&master);
        for g in &parsed.groups {
            for (t, wt) in &g.terms {
                if let Some(hit) = tag_lookup.get(t) {
                    if *wt < 1.0 {
                        query_tags.push(hit.clone());
                    }
                }
            }
        }
        let mut seen: HashSet<String> = HashSet::new();
        query_tags.retain(|t| seen.insert(key_of(t)));
    }
    let tag_mode = if mode == "strict_tag" { "require" } else { tag_mode };
    let kw_mode = if mode == "strict_keyword" { "require" } else { kw_mode };

    // Folder boundary: a hard boundary, the search never looks outside it.
    let mut universe: Vec<String> = idx.files.keys().cloned().collect();
    if !folders.is_empty() {
        let in_scope = |rp: &str| -> bool {
            for f in folders {
                let f = f.trim_matches('/');
                if f.is_empty() && !folder_only {
                    return true;
                }
                if rp.starts_with(&format!("database/{f}/")) || rp == format!("database/{f}") {
                    let note_folder = std::path::Path::new(rp)
                        .parent()
                        .map(|p| p.to_path_buf())
                        .unwrap_or_default();
                    let rel_folder = paths::rel(&note_folder)
                        .trim_start_matches("database/")
                        .to_string();
                    if folder_only {
                        if rel_folder == f {
                            return true;
                        }
                    } else if rel_folder == f || rel_folder.starts_with(&format!("{f}/")) {
                        return true;
                    }
                }
            }
            false
        };
        universe.retain(|rp| in_scope(rp));
    }

    // Status and date filters.
    universe.retain(|rp| {
        let e = &idx.files[rp];
        if let Some(st) = status {
            if &e.status != st {
                return false;
            }
        }
        if let Some(df) = date_from {
            let u = if e.updated.is_empty() { "0000" } else { &e.updated };
            if u < df {
                return false;
            }
        }
        if let Some(dt) = date_to {
            let u = if e.updated.is_empty() { "9999" } else { &e.updated };
            if u > dt {
                return false;
            }
        }
        true
    });

    // Search within a chosen group of notes.
    if !limit_to.is_empty() {
        let wanted: HashSet<String> = limit_to.iter().map(|t| key_of(t)).collect();
        universe.retain(|rp| {
            wanted.contains(&key_of(&idx.files[rp].title)) || limit_to.iter().any(|x| x == rp)
        });
    }

    let mut removed_by = HashMap::from([("tags".to_string(), 0i64), ("keywords".to_string(), 0i64)]);

    // ---- Strict tag mode (hard filter): must carry all selected tags ----
    if tag_mode == "require" && !tags_sel.is_empty() {
        let before = universe.len() as i64;
        universe.retain(|rp| {
            let carried: HashSet<String> = idx.files[rp].tags.iter().map(|t| key_of(t)).collect();
            tags_sel.iter().all(|st| carried.contains(&key_of(st)))
        });
        removed_by.insert("tags".to_string(), before - universe.len() as i64);
    }

    // ---- Collect candidates ----
    let uni: HashSet<String> = universe.iter().cloned().collect();
    let mut direct: HashSet<String> = HashSet::new();
    if !q.trim().is_empty() {
        let sel = if tag_mode == "rank" { tags_sel } else { &[] };
        direct = tag_hits(idx, &query_tags, sel)
            .union(&keyword_hits(idx, &parsed.groups, scope, &settings))
            .cloned()
            .collect();
        direct.retain(|rp| uni.contains(rp));
    } else if !tags_sel.is_empty() {
        direct = tag_hits(idx, &[], tags_sel);
        direct.retain(|rp| uni.contains(rp));
    }

    // ---- Strict keyword mode (hard filter): every query word, any order ----
    if kw_mode == "require" && (!parsed.groups.is_empty() || !parsed.phrases.is_empty()) {
        let before = universe.len() as i64;
        universe.retain(|rp| {
            let e = &idx.files[rp];
            let texts = scope_text(e, scope);
            let text_refs: Vec<&str> = texts.iter().map(|s| s.as_str()).collect();
            let mut ok = parsed.groups.iter().all(|g| group_in_text(g, &text_refs));
            for ph in &parsed.phrases {
                let toks: Vec<String> = tokenize(ph).iter().map(|t| stem(t)).collect();
                let joined = toks.join(" ");
                ok = ok
                    && texts.iter().any(|t| {
                        let stem_text = tokenize(t)
                            .iter()
                            .map(|t| stem(t))
                            .collect::<Vec<_>>()
                            .join(" ");
                        stem_text.contains(&joined)
                    });
            }
            ok
        });
        removed_by.insert("keywords".to_string(), before - universe.len() as i64);
        direct.retain(|rp| universe.contains(rp));
    }

    // ---- Neighbors of the top-5 direct hits ----
    let mut pre_top: Vec<String> = direct.iter().cloned().collect();
    pre_top.sort_by(|a, b| {
        let ta = idx.files[a].tags.len();
        let tb = idx.files[b].tags.len();
        tb.cmp(&ta).then_with(|| a.cmp(b))
    });
    pre_top.truncate(5);
    let (neighbor_map, nb_src) = if !direct.is_empty() {
        neighbor_candidates(idx, &pre_top)
    } else {
        (HashMap::new(), HashMap::new())
    };
    let mut neighbors: HashMap<String, String> = neighbor_map
        .into_iter()
        .filter(|(rp, _)| universe.contains(rp) && !direct.contains(rp))
        .collect();

    // ---- Fallback: never blank ----
    let mut fallback_used = false;
    if direct.is_empty() && neighbors.is_empty() && !universe.is_empty() {
        let fb = fallback_candidates(idx, &parsed.groups, 20);
        direct = fb.into_iter().filter(|rp| universe.contains(rp)).collect();
        fallback_used = true;
        neighbors.clear();
    }

    let mut candidates: Vec<(String, bool, Option<String>)> = direct
        .iter()
        .map(|rp| (rp.clone(), true, None))
        .chain(neighbors.iter().map(|(rp, kind)| (rp.clone(), false, Some(kind.clone()))))
        .collect();

    let mut scored: Vec<Scored> = Vec::new();
    // deterministic candidate order
    candidates.sort_by(|a, b| a.0.cmp(&b.0));
    for (rp, is_direct, kind) in &candidates {
        let sel = if tag_mode == "rank" { tags_sel } else { &[] };
        let mut sc = score_note(
            idx,
            rp,
            &parsed.groups,
            &query_tags,
            sel,
            *is_direct,
            kind.as_deref(),
            &settings,
        );
        if include_connected && kind.as_deref() == Some("connected") {
            sc.connected_to = nb_src.get(rp).cloned();
        }
        scored.push(sc);
    }

    finalize_scores(&mut scored, &parsed.groups, &weights, &settings);

    // Neighbor-only notes can never outrank notes that match directly.
    // Ties: more groups matched, more recently updated, then title A–Z.
    let date_key = |d: &str| date_key(d);
    scored.sort_by(|a, b| {
        let ad = if a.direct { 0 } else { 1 };
        let bd = if b.direct { 0 } else { 1 };
        ad.cmp(&bd)
            .then_with(|| b.score.partial_cmp(&a.score).unwrap_or(std::cmp::Ordering::Equal))
            .then_with(|| b.matched_groups.cmp(&a.matched_groups))
            .then_with(|| date_key(&idx.files[&b.rp].updated).cmp(&date_key(&idx.files[&a.rp].updated)))
            .then_with(|| idx.files[&a.rp].title.to_lowercase().cmp(&idx.files[&b.rp].title.to_lowercase()))
    });

    // Exact title or alias match always ranks first (within direct matches).
    let qnorm = normalize(q);
    if !qnorm.is_empty() {
        let exact: Vec<Scored> = scored
            .iter()
            .filter(|x| {
                x.direct
                    && (qnorm == normalize(&idx.files[&x.rp].title)
                        || idx.files[&x.rp]
                            .aliases
                            .iter()
                            .any(|a| qnorm == *a))
            })
            .cloned()
            .collect();
        if !exact.is_empty() {
            let exact_keys: HashSet<&str> = exact.iter().map(|x| x.rp.as_str()).collect();
            let mut rest: Vec<Scored> = scored
                .iter()
                .filter(|x| !exact_keys.contains(x.rp.as_str()))
                .cloned()
                .collect();
            let mut exact_sorted = exact.clone();
            exact_sorted.sort_by(|a, b| {
                b.score
                    .partial_cmp(&a.score)
                    .unwrap_or(std::cmp::Ordering::Equal)
                    .then_with(|| {
                        idx.files[&a.rp]
                            .title
                            .to_lowercase()
                            .cmp(&idx.files[&b.rp].title.to_lowercase())
                    })
            });
            rest.sort_by(|a, b| {
                let ad = if a.direct { 0 } else { 1 };
                let bd = if b.direct { 0 } else { 1 };
                ad.cmp(&bd)
                    .then_with(|| b.score.partial_cmp(&a.score).unwrap_or(std::cmp::Ordering::Equal))
                    .then_with(|| b.matched_groups.cmp(&a.matched_groups))
                    .then_with(|| {
                        date_key(&idx.files[&b.rp].updated).cmp(&date_key(&idx.files[&a.rp].updated))
                    })
                    .then_with(|| {
                        idx.files[&a.rp]
                            .title
                            .to_lowercase()
                            .cmp(&idx.files[&b.rp].title.to_lowercase())
                    })
            });
            exact_sorted.extend(rest);
            scored = exact_sorted;
        }
    }

    let mut results: Vec<serde_json::Value> =
        scored.iter().map(|x| present(idx, x, &parsed.groups)).collect();

    // ---- Include connected notes as extra results ----
    if include_connected && !scored.is_empty() {
        let top_hits: Vec<String> = scored.iter().take(5).map(|x| x.rp.clone()).collect();
        let mut seen: HashSet<String> = scored.iter().map(|x| x.rp.clone()).collect();
        let mut extra: Vec<serde_json::Value> = Vec::new();
        for hit in &top_hits {
            let nbs = idx
                .graph
                .get(hit)
                .cloned()
                .unwrap_or_default()
                .into_iter()
                .chain(idx.backlinks.get(hit).cloned().unwrap_or_default());
            for nb in nbs {
                if !seen.contains(&nb) && universe.contains(&nb) {
                    seen.insert(nb.clone());
                    let e = &idx.files[&nb];
                    extra.push(serde_json::json!({
                        "path": nb, "title": e.title, "folder": e.folder,
                        "tags": e.tags, "status": e.status,
                        "updated": e.updated, "score": null,
                        "connected_to": hit,
                        "snippet": snippet(e, &parsed.groups),
                    }));
                }
            }
        }
        results.extend(extra);
    }

    let total = results.len();
    let page: Vec<serde_json::Value> = results
        .into_iter()
        .skip(offset)
        .take(limit)
        .collect();
    let elapsed = t0.elapsed().as_secs_f64() * 1000.0;

    let mut notice: Option<String> = None;
    if total == 0 {
        if tag_mode == "require" && removed_by["tags"] > 0 {
            notice = Some("No results: the Require switch on tags removed all notes (every note must carry all of the selected tags). Relax it to Rank to see boosted results instead.".into());
        } else if kw_mode == "require" && removed_by["keywords"] > 0 {
            notice = Some("No results: the Require switch on keywords removed all notes (every note must contain every query word). Relax it to Rank.".into());
        } else if !folders.is_empty() {
            notice = Some("No results inside the selected folder boundary. Search never looks outside chosen folders - widen the folder selection or clear it.".into());
        }
    }

    serde_json::json!({
        "total": total,
        "offset": offset,
        "results": page,
        "notice": notice,
        "removed_by": removed_by,
        "fallback_used": fallback_used,
        "query": {
            "groups": parsed.groups.iter().map(|g| g.text.clone()).collect::<Vec<_>>(),
            "query_tags": query_tags,
            "phrases": parsed.phrases,
        },
        "elapsed_ms": (elapsed * 10.0).round() / 10.0,
    })
}

pub fn date_key(d: &str) -> String {
    let mut padded = d.to_string();
    while padded.chars().count() < 10 {
        padded.push(' ');
    }
    padded
        .chars()
        .map(|c| char::from_u32(0x10FFFF - c as u32).unwrap_or('\u{0}'))
        .collect()
}

fn snippet(e: &NoteEntry, groups: &[Group]) -> String {
    let text = &e.snippet_text;
    if groups.is_empty() {
        return text.chars().take(200).collect();
    }
    let mut best_i = 0;
    for g in groups {
        let pos = group_positions(g, &e.tokens);
        if !pos.is_empty() {
            best_i = pos[0];
            break;
        }
    }
    let toks: Vec<&str> = text.split_whitespace().collect();
    let a = best_i.saturating_sub(12);
    let b = (best_i + 24).min(toks.len());
    toks[a..b].join(" ")
}

fn present(idx: &Index, x: &Scored, groups: &[Group]) -> serde_json::Value {
    let e = &idx.files[&x.rp];
    serde_json::json!({
        "path": x.rp,
        "title": e.title,
        "folder": e.folder,
        "tags": e.tags,
        "status": e.status,
        "updated": e.updated,
        "pinned": e.pinned,
        "score": x.score,
        "coverage": x.coverage,
        "direct": x.direct,
        "neighbor_kind": x.neighbor_kind,
        "connected_to": x.connected_to,
        "matched_groups": x.matched_groups,
        "matched_tag_pairs": x.matched_tag_pairs,
        "rank_reason": rank_reason(x, groups.len()),
        "breakdown": x.breakdown,
        "snippet": snippet(e, groups),
    })
}

fn rank_reason(x: &Scored, n_groups: usize) -> String {
    let mut bits: Vec<String> = Vec::new();
    if !x.direct {
        if let Some(kind) = &x.neighbor_kind {
            bits.push(
                "appears here because it is ".to_string()
                    + (if kind == "connected" {
                        "connected to a top result"
                    } else {
                        "shares tags with a top result"
                    }),
            );
        }
    }
    let pairs = &x.matched_tag_pairs;
    if !pairs.is_empty() {
        let names: Vec<String> = pairs
            .iter()
            .take(2)
            .map(|p| format!("`{}`", p["note_tag"].as_str().unwrap_or("")))
            .collect();
        bits.push(format!(
            "tag {} match{} your search",
            names.join(" and "),
            if pairs.len() > 1 { "" } else { "es" }
        ));
    }
    let g = x.matched_groups;
    if g > 0 && n_groups > 0 {
        bits.push(format!("{g} of {n_groups} search words found in the note"));
    }
    if x.title_hit > 0 && x.direct {
        bits.push("title matches the search".into());
    }
    if bits.is_empty() {
        bits.push("closest match the engine could find".into());
    }
    let joined = bits.iter().take(3).cloned().collect::<Vec<_>>().join("; ");
    let mut c = joined.chars();
    match c.next() {
        Some(f) => f.to_uppercase().collect::<String>() + c.as_str() + ".",
        None => String::new(),
    }
}

/// Convenience used by the website and MCP for the /api/suggest endpoint.
pub fn suggest_for(q: &str, kind: &str) -> serde_json::Value {
    store::suggest(q, kind).unwrap_or_else(|_| serde_json::json!({"suggestions": []}))
}

/// A small BTreeMap type alias for deterministic result maps.
pub type RankedMap = BTreeMap<String, f64>;

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_date_key_order() {
        // more recent dates must sort BEFORE older dates in ascending order
        let a = date_key("2026-10-31");
        let b = date_key("2026-10-01");
        assert!(a < b);
    }

    #[test]
    fn test_parse_query() {
        let mt = tags_mod::MasterTags::default();
        let settings = serde_json::json!({});
        let pq = parse_query("quick pasta recipe", &mt, &settings);
        assert_eq!(pq.groups.len(), 3);
        assert_eq!(pq.groups[0].text, "quick");
        // "the" is filler and dropped
        let pq2 = parse_query("the pasta", &mt, &settings);
        assert_eq!(pq2.groups.len(), 1);
    }
}
