//! Normalization, tokenizer, a small deterministic stemmer, edit distance and
//! deletion buckets for typo tolerance. A faithful port of `core/textutil.py`.

use once_cell::sync::Lazy;
use regex::Regex;
use std::collections::HashSet;
use unicode_normalization::UnicodeNormalization;

/// Filler words are dropped from queries. Negations are NEVER dropped because
/// they change meaning.
pub const FILLER: &[&str] = &[
    "the", "a", "an", "of", "and", "or", "to", "in", "on", "at", "for", "with",
    "is", "are", "was", "were", "be", "been", "it", "its", "that", "this",
    "these", "those", "my", "i", "me", "we", "our", "you", "your",
];

pub const KEEP_WORDS: &[&str] = &["no", "not", "without", "never", "nor"];

pub fn is_filler(w: &str) -> bool {
    FILLER.contains(&w)
}

pub fn is_keep_word(w: &str) -> bool {
    KEEP_WORDS.contains(&w)
}

static WORD_RE: Lazy<Regex> = Lazy::new(|| Regex::new(r"[a-z0-9]+").unwrap());
static DASH_RE: Lazy<Regex> = Lazy::new(|| Regex::new(r"[_\-\u2010-\u2015]+").unwrap());
static NON_ALNUM_RE: Lazy<Regex> = Lazy::new(|| Regex::new(r"[^a-z0-9 ]+").unwrap());
static SPACES_RE: Lazy<Regex> = Lazy::new(|| Regex::new(r"\s+").unwrap());
static UNDERSCORE_DASH_RE: Lazy<Regex> = Lazy::new(|| Regex::new(r"[_\-]+").unwrap());

/// Remove accents: e-acute -> e (NFKD then drop combining marks).
pub fn strip_accents(s: &str) -> String {
    s.nfkd()
        .filter(|c| !unicode_normalization::char::is_combining_mark(*c))
        .collect()
}

/// Lowercase, strip accents, treat underscores and dashes as spaces, drop
/// everything that is not an ASCII letter or digit, squeeze spaces.
pub fn normalize(s: &str) -> String {
    let lowered = strip_accents(s).to_lowercase();
    let dashed = DASH_RE.replace_all(&lowered, " ");
    let cleaned: String = dashed
        .chars()
        .map(|c| if c.is_ascii_alphanumeric() || c == ' ' { c } else { ' ' })
        .collect();
    SPACES_RE.replace_all(&cleaned, " ").trim().to_string()
}

pub fn normalize_keep_case(s: &str) -> String {
    let stripped = strip_accents(s);
    let dashed = UNDERSCORE_DASH_RE.replace_all(&stripped, " ");
    SPACES_RE.replace_all(&dashed, " ").trim().to_string()
}

/// Split already-normalized text into word tokens.
pub fn tokenize(s: &str) -> Vec<String> {
    WORD_RE.find_iter(&normalize(s)).map(|m| m.as_str().to_string()).collect()
}

/// Small, deterministic stemmer so plurals and endings match
/// (recipe/recipes, dish/dishes, cook/cooking/cooked).
pub fn stem(w: &str) -> String {
    let mut w = w.to_string();
    if w.chars().count() <= 3 {
        return w;
    }
    let len_gt = |s: &str, n: usize| s.chars().count() > n;
    if w.ends_with("ies") && len_gt(&w, 4) {
        let cut = w.chars().count() - 3;
        w = w[..cut].to_string() + "y";
    } else if w.ends_with("sses") && len_gt(&w, 4) {
        let cut = w.chars().count() - 2;
        w = w[..cut].to_string();
    } else if (w.ends_with("ches")
        || w.ends_with("shes")
        || w.ends_with("xes")
        || w.ends_with("zes")
        || w.ends_with("ses"))
        && len_gt(&w, 4)
    {
        let cut = w.chars().count() - 2;
        w = w[..cut].to_string();
    } else if w.ends_with('s')
        && len_gt(&w, 3)
        && !w.ends_with("ss")
        && !w.ends_with("us")
        && !w.ends_with("is")
    {
        let cut = w.chars().count() - 1;
        w = w[..cut].to_string();
    }
    if len_gt(&w, 5) && w.ends_with("ing") {
        let cut = w.chars().count() - 3;
        w = restore_e(w[..cut].to_string());
    } else if len_gt(&w, 4) && w.ends_with("ed") {
        let cut = w.chars().count() - 2;
        w = restore_e(w[..cut].to_string());
    }
    let chars: Vec<char> = w.chars().collect();
    if chars.len() > 3
        && chars[chars.len() - 1] == chars[chars.len() - 2]
        && !"lsf".contains(chars[chars.len() - 1])
    {
        w = chars[..chars.len() - 1].iter().collect();
    }
    w
}

/// baking -> bake (consonant-vowel-consonant gets a silent e back).
fn restore_e(mut w: String) -> String {
    let chars: Vec<char> = w.chars().collect();
    if chars.len() >= 3 {
        let last = chars[chars.len() - 1];
        let mid = chars[chars.len() - 2];
        let third = chars[chars.len() - 3];
        if !"aeiouwxy".contains(last) && "aeiou".contains(mid) && !"aeiou".contains(third) {
            w.push('e');
        }
    }
    w
}

pub fn stem_tokens(tokens: &[String]) -> Vec<String> {
    tokens.iter().map(|t| stem(t)).collect()
}

/// True when a and b differ by at most one letter (one substitution,
/// insertion or deletion).
pub fn levenshtein_leq1(a: &str, b: &str) -> bool {
    if a == b {
        return true;
    }
    let ac: Vec<char> = a.chars().collect();
    let bc: Vec<char> = b.chars().collect();
    let (mut a, mut b) = (&ac[..], &bc[..]);
    if a.len().abs_diff(b.len()) > 1 {
        return false;
    }
    if a.len() > b.len() {
        std::mem::swap(&mut a, &mut b);
    }
    let (mut i, mut j, mut diff) = (0usize, 0usize, 0u32);
    while i < a.len() && j < b.len() {
        if a[i] == b[j] {
            i += 1;
            j += 1;
        } else {
            diff += 1;
            if diff > 1 {
                return false;
            }
            if a.len() == b.len() {
                i += 1;
                j += 1;
            } else {
                j += 1; // skip one char in the longer word
            }
        }
    }
    true
}

/// The word itself plus every one-letter deletion. Two words within edit
/// distance 1 always share at least one variant.
pub fn deletion_variants(w: &str) -> Vec<String> {
    let chars: Vec<char> = w.chars().collect();
    let mut out = vec![w.to_string()];
    for i in 0..chars.len() {
        let v: String = chars
            .iter()
            .enumerate()
            .filter(|(j, _)| *j != i)
            .map(|(_, c)| c)
            .collect();
        out.push(v);
    }
    out
}

pub fn jaccard(a: &HashSet<String>, b: &HashSet<String>) -> f64 {
    if a.is_empty() || b.is_empty() {
        return 0.0;
    }
    let inter = a.intersection(b).count();
    let union = a.union(b).count();
    if union == 0 {
        0.0
    } else {
        inter as f64 / union as f64
    }
}

/// Case-insensitive uniqueness key (accent-normalized). Python used NFKD +
/// casefold; Rust to_lowercase is close enough for the Latin data this
/// project holds and matches its behaviour for every example in the wiki.
pub fn key_of(name: &str) -> String {
    strip_accents(name.trim()).nfkd().collect::<String>().to_lowercase()
}

pub fn truncate(s: &str, n: usize) -> String {
    let s = s.trim();
    if s.chars().count() <= n {
        s.to_string()
    } else {
        let cut: String = s.chars().take(n.saturating_sub(1)).collect();
        format!("{}\u{2026}", cut.trim_end())
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_normalize() {
        assert_eq!(normalize("Café Résumé"), "cafe resume");
        assert_eq!(normalize("FOOD-pasta_veggie"), "food pasta veggie");
        assert_eq!(tokenize("Hello, World! 42"), vec!["hello", "world", "42"]);
    }

    #[test]
    fn test_stem() {
        assert_eq!(stem("recipes"), "recipe");
        assert_eq!(stem("dishes"), "dish");
        assert_eq!(stem("boxes"), "box");
        assert_eq!(stem("cooking"), "cook");
        assert_eq!(stem("baking"), "bake");
        assert_eq!(stem("stopped"), "stop");
        assert_eq!(stem("planning"), "plan");
        assert_eq!(stem("recipes"), stem("recipe"));
    }

    #[test]
    fn test_levenshtein() {
        assert!(levenshtein_leq1("pasta", "pasts"));
        assert!(levenshtein_leq1("pasta", "pasta"));
        assert!(levenshtein_leq1("pasta", "past"));
        assert!(!levenshtein_leq1("pasta", "paster"));
        assert!(levenshtein_leq1("pasta", "paste")); // one substitution
        assert!(!levenshtein_leq1("abc", "abcdx"));
    }

    #[test]
    fn test_key_of() {
        assert_eq!(key_of("Garlic Bread"), key_of("garlic bread"));
    }
}
