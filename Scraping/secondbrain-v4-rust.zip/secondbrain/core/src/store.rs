//! The store — every write operation in one place. The website, the MCP
//! server and the backup tool all edit files through this module, so the
//! librarian rules, the edit history and atomic writes behave the same
//! everywhere. A faithful port of `core/store.py`.

use crate::editlog::{self, UndoStep};
use crate::error::{Result, SbError};
use crate::parser::{self, NoteDoc, WIKI_LINK_RE};
use crate::paths;
use crate::tags as tags_mod;
use crate::textutil::key_of;
use chrono::Local;
use regex::Regex;
use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::collections::HashMap;
use std::path::{Path, PathBuf};

pub fn settings_path() -> PathBuf {
    paths::CORE_DIR.join("settings.json")
}

pub fn default_settings() -> Value {
    json!({
        "ranking_weights": {
            "tags": 0.34, "title": 0.24, "headings": 0.14,
            "neighbors": 0.12, "body": 0.10, "closeness": 0.06
        },
        "coverage_base": 0.4,
        "synonym_weight": 0.7,
        "page_size": 20,
        "max_word_groups": 12,
        "typo_tolerance": true,
        "typo_min_length": 5,
        "closeness_window_tokens": 40,
        "bm25": {"k1": 1.5, "b": 0.75},
        "default_theme": "grey",
        "server_port": 8765,
        "server_bind": "127.0.0.1",
        "open_browser_on_start": true,
        "backup_versions_to_keep": 10,
        "saved_searches": [],
        "recent_searches": []
    })
}

pub fn load_settings() -> Value {
    let mut merged = default_settings();
    if let Ok(text) = std::fs::read_to_string(settings_path()) {
        if let Ok(data) = serde_json::from_str::<Value>(&text) {
            if let (Some(m), Some(d)) = (merged.as_object_mut(), data.as_object()) {
                for (k, v) in d {
                    m.insert(k.clone(), v.clone());
                }
            }
        }
    }
    merged
}

pub fn save_settings(settings: &Value) -> Result<()> {
    std::fs::create_dir_all(settings_path().parent().unwrap())?;
    let tmp = settings_path().with_extension("tmp");
    std::fs::write(&tmp, serde_json::to_string_pretty(settings)? + "\n")?;
    std::fs::rename(&tmp, settings_path())?;
    Ok(())
}

pub fn today() -> String {
    Local::now().format("%Y-%m-%d").to_string()
}

pub fn now_iso() -> String {
    Local::now().format("%Y-%m-%d %H:%M:%S").to_string()
}

pub fn sha256_of(path: &Path) -> Result<String> {
    let data = std::fs::read(path)?;
    Ok(text_sha256_bytes(&data))
}

pub fn text_sha256(text: &str) -> String {
    text_sha256_bytes(text.as_bytes())
}

pub fn text_sha256_bytes(data: &[u8]) -> String {
    let mut h = Sha256::new();
    h.update(data);
    let out = h.finalize();
    out.iter().map(|b| format!("{b:02x}")).collect()
}

pub fn atomic_write(path: &Path, data: &str) -> Result<()> {
    if let Some(parent) = path.parent() {
        std::fs::create_dir_all(parent)?;
    }
    let tmp = path.with_file_name(format!(
        "{}.tmp-write",
        path.file_name().and_then(|n| n.to_str()).unwrap_or("file")
    ));
    std::fs::write(&tmp, data)?;
    std::fs::rename(&tmp, path)?;
    Ok(())
}

// --------------------------------------------------------------------------
// Reading helpers
// --------------------------------------------------------------------------

/// database/<folder>/<Name>/<Name>.md from any of:
/// 'database/<folder>/<Name>/<Name>.md' or 'database/<folder>/<Name>'.
pub fn note_md_path(note_rel: &str) -> PathBuf {
    let p = paths::ROOT.join(note_rel);
    if p.extension().map(|e| e == "md").unwrap_or(false) {
        p
    } else {
        p.join(format!("{}.md", p.file_name().and_then(|n| n.to_str()).unwrap_or("")))
    }
}

pub fn note_exists(name: &str) -> Option<PathBuf> {
    let k = key_of(name);
    if k.is_empty() {
        return None;
    }
    let mut all: Vec<PathBuf> = walkdir::WalkDir::new(paths::DATABASE.as_path())
        .into_iter()
        .filter_map(|e| e.ok())
        .map(|e| e.path().to_path_buf())
        .filter(|p| {
            p.is_file()
                && p.extension().map(|e| e == "md").unwrap_or(false)
                && p.file_name().map(|n| n != "_subject.md").unwrap_or(false)
        })
        .collect();
    all.sort();
    for md in all {
        let stem = md.file_stem().and_then(|n| n.to_str()).unwrap_or("");
        if key_of(stem) == k {
            return Some(md);
        }
    }
    None
}

pub fn list_note_files() -> Vec<PathBuf> {
    let mut out: Vec<PathBuf> = walkdir::WalkDir::new(paths::DATABASE.as_path())
        .into_iter()
        .filter_map(|e| e.ok())
        .map(|e| e.path().to_path_buf())
        .filter(|p| {
            p.is_file()
                && p.extension().map(|e| e == "md").unwrap_or(false)
                && p.file_name().map(|n| n != "_subject.md").unwrap_or(false)
                && p.parent()
                    .and_then(|d| d.file_name())
                    .map(|d| d == p.file_stem().unwrap_or_default())
                    .unwrap_or(false)
        })
        .collect();
    out.sort();
    out
}

/// A subject folder with 'Sensitivity: private' in _subject.md is hidden,
/// locked and excluded from the index. Private inherits down the tree
/// unless overridden.
pub fn is_private(folder: &Path) -> bool {
    let check = |dir: &Path| -> bool {
        let subj = dir.join("_subject.md");
        if let Ok(text) = std::fs::read_to_string(&subj) {
            static RE: once_cell::sync::Lazy<Regex> = once_cell::sync::Lazy::new(|| {
                Regex::new(r"(?im)^\s*Sensitivity:\s*private\s*$").unwrap()
            });
            return RE.is_match(&text);
        }
        false
    };
    if check(folder) {
        return true;
    }
    for parent in folder.ancestors().skip(1) {
        if parent == paths::ROOT.as_path() {
            break;
        }
        if check(parent) {
            return true;
        }
    }
    false
}

// --------------------------------------------------------------------------
// Note creation / editing
// --------------------------------------------------------------------------

pub fn note_template(title: &str, tags: Option<&[String]>, quick_info: Option<&str>) -> String {
    let _ = tags;
    let mut parts = vec![format!("# {title}"), String::new()];
    if let Some(qi) = quick_info {
        parts.push(":::quick-info".into());
        parts.push(qi.trim_end().to_string());
        parts.push(":::".into());
        parts.push(String::new());
    }
    parts.extend([
        String::new(),
        "## My notes".into(),
        String::new(),
        String::new(),
        "## Connected notes".into(),
        String::new(),
        "## Reference sources".into(),
        String::new(),
        parser::render_meta(&HashMap::from([
            ("created".to_string(), today()),
            ("updated".to_string(), today()),
            ("pinned".to_string(), "no".to_string()),
        ])),
    ]);
    parts.join("\n") + "\n"
}

pub fn available_folders() -> Vec<String> {
    list_subjects().iter().map(|s| s["path"].as_str().unwrap_or("").to_string()).collect()
}

pub fn create_note(
    folder_rel: &str,
    name: &str,
    tags: Option<&[String]>,
    text: Option<&str>,
    quick_info: Option<&str>,
    who: &str,
    reason: &str,
) -> Result<Value> {
    let name = paths::clean_name(name)?;
    let folder_rel = folder_rel.trim().trim_matches('/').replace('\\', "/");
    let folder = if folder_rel.is_empty() {
        paths::DATABASE.as_path().to_path_buf()
    } else {
        paths::safe_join_rel(paths::DATABASE.as_path(), &folder_rel)?
    };
    if !folder.exists() {
        let avail = available_folders();
        let list = if avail.is_empty() {
            "  - (database root only)".to_string()
        } else {
            avail.iter().map(|a| format!("  - {a}")).collect::<Vec<_>>().join("\n")
        };
        return Err(SbError::NotFound(format!(
            "Folder {folder_rel:?} does not exist. Existing folders you can file into:\n{list}\nCreate the folder first, then create the note."
        )));
    }
    let existing: Vec<String> = list_note_files()
        .iter()
        .filter_map(|p| p.file_stem().and_then(|s| s.to_str()).map(|t| key_of(t)))
        .collect();
    if existing.contains(&key_of(&name)) {
        return Err(SbError::Exists(format!(
            "Note names are unique across the whole wiki: {name:?} already exists elsewhere."
        )));
    }

    let note_dir = folder.join(&name);
    let md_path = note_dir.join(format!("{name}.md"));
    if note_dir.exists() || md_path.exists() {
        return Err(SbError::Exists(format!("A note named {name:?} already exists there.")));
    }
    std::fs::create_dir_all(note_dir.join("attachments"))?;

    let body = match text {
        Some(t) => t.to_string(),
        None => note_template(&name, tags, quick_info),
    };
    atomic_write(&md_path, &body)?;

    let mut tag_list: Vec<String> = Vec::new();
    for t in tags.unwrap_or(&[]) {
        let t = tags_mod::validate_tag(t)?;
        if !tag_list.iter().any(|x| key_of(x) == key_of(&t)) {
            tag_list.push(t);
        }
    }
    let synced = tags_mod::add_to_master(&tag_list, who)?;
    atomic_write(&note_dir.join("tags.txt"), &tags_mod::render_tags_txt(&tag_list))?;
    // the automatic edit history also records creations (all lines "added")
    let _ = editlog::record_note_edit(&paths::rel(&md_path), who, "", &body);

    editlog::record_change(
        who,
        &format!("Create note {name}"),
        vec![
            UndoStep { op: "write".into(), path: Some(paths::rel(&md_path)), before: None, from: None, to: None },
            UndoStep { op: "write".into(), path: Some(paths::rel(&note_dir.join("tags.txt"))), before: None, from: None, to: None },
            UndoStep { op: "mkdir".into(), path: Some(paths::rel(&note_dir.join("attachments"))), before: None, from: None, to: None },
        ],
    )?;
    Ok(json!({"path": paths::rel(&md_path), "master_updated": synced}))
}

pub fn save_note_text(
    note_rel: &str,
    new_text: &str,
    base_hash: Option<&str>,
    who: &str,
    force: bool,
    reason: &str,
) -> Result<Value> {
    let p = paths::ROOT.join(note_rel);
    if !p.exists() {
        return Err(SbError::NotFound(format!("Note {note_rel} not found.")));
    }
    let old = std::fs::read_to_string(&p)?;
    let current_hash = text_sha256(&old);
    if let Some(bh) = base_hash {
        if bh != current_hash && !force {
            return Ok(json!({
                "conflict": true,
                "current_hash": current_hash,
                "message": "This file changed while it was open (for example the AI filed something). Reload or overwrite?"
            }));
        }
    }

    // 'My notes' is append-only: refuse to shrink or alter it.
    let old_doc = parser::parse_note(&old, note_rel);
    let new_doc = parser::parse_note(new_text, note_rel);
    if !old_doc.my_notes.is_empty() && !new_doc.my_notes.starts_with(&old_doc.my_notes) {
        return Err(SbError::Permission(
            "'My notes' is append-only: existing lines cannot be changed or removed.".into(),
        ));
    }

    let new_text = touch_updated(new_text);
    atomic_write(&p, &new_text)?;
    editlog::record_note_edit(note_rel, who, &old, &new_text)?;
    editlog::record_change(
        who,
        &format!("Edited note {}", p.file_stem().and_then(|s| s.to_str()).unwrap_or("")),
        vec![UndoStep {
            op: "write".into(),
            path: Some(note_rel.to_string()),
            before: Some(old),
            from: None,
            to: None,
        }],
    )?;
    Ok(json!({"ok": true, "hash": text_sha256(&new_text), "reason": reason}))
}

pub fn touch_updated(text: &str) -> String {
    static META_RE: once_cell::sync::Lazy<Regex> = once_cell::sync::Lazy::new(|| {
        Regex::new(r"(?s)(:::meta\n)(.*?)\n:::").unwrap()
    });
    if !text.contains(":::meta") {
        return text.to_string();
    }
    let found_today = today();
    let result = META_RE.replace(text, |caps: &regex::Captures| {
        let mut lines: Vec<String> = caps[2].lines().map(|l| l.to_string()).collect();
        let mut found = false;
        for ln in lines.iter_mut() {
            let t = ln.trim();
            if t.to_lowercase().starts_with("updated:") {
                *ln = format!("Updated: {found_today}");
                found = true;
            }
        }
        if !found {
            lines.push(format!("Updated: {found_today}"));
        }
        format!("{}\n{}\n:::", &caps[1], lines.join("\n"))
    });
    result.to_string()
}

pub fn append_to_my_notes(note_rel: &str, addition: &str, who: &str, reason: &str) -> Result<Value> {
    let p = paths::ROOT.join(note_rel);
    let text = std::fs::read_to_string(&p)
        .map_err(|_| SbError::NotFound(format!("Note {note_rel} not found.")))?;
    let new_text = if text.contains("## My notes") {
        text.replacen(
            "## My notes",
            &format!("## My notes\n{}\n", addition.trim_end()),
            1,
        )
    } else {
        format!("{}\n## My notes\n{}\n", text, addition.trim_end())
    };
    let new_text = touch_updated(&new_text);
    atomic_write(&p, &new_text)?;
    editlog::record_note_edit(note_rel, who, &text, &new_text)?;
    editlog::record_change(
        who,
        &format!(
            "Appended to My notes of {}",
            p.file_stem().and_then(|s| s.to_str()).unwrap_or("")
        ),
        vec![UndoStep {
            op: "write".into(),
            path: Some(note_rel.to_string()),
            before: Some(text),
            from: None,
            to: None,
        }],
    )?;
    Ok(json!({"ok": true, "reason": reason}))
}

pub fn move_note(note_rel: &str, new_folder_rel: &str, new_name: Option<&str>, who: &str) -> Result<Value> {
    let p = paths::ROOT.join(note_rel);
    if !p.exists() {
        return Err(SbError::NotFound(format!("Note {note_rel} not found.")));
    }
    let old_name = p
        .parent()
        .and_then(|d| d.file_name())
        .and_then(|n| n.to_str())
        .unwrap_or("")
        .to_string();
    let new_name = match new_name {
        Some(n) => paths::clean_name(n)?,
        None => old_name.clone(),
    };
    let new_folder = if new_folder_rel.trim().is_empty() {
        paths::DATABASE.as_path().to_path_buf()
    } else {
        paths::safe_join_rel(paths::DATABASE.as_path(), new_folder_rel)?
    };
    if !new_folder.exists() {
        return Err(SbError::NotFound(format!("Folder {new_folder_rel:?} does not exist.")));
    }
    let new_dir = new_folder.join(&new_name);
    if new_dir.exists() {
        return Err(SbError::Exists(format!("Target {} already exists.", paths::rel(&new_dir))));
    }
    if !key_of(&new_name).eq(&key_of(&old_name)) && note_exists(&new_name).is_some() {
        return Err(SbError::Exists(format!(
            "Note names are unique across the whole wiki: {new_name:?} already exists."
        )));
    }

    // 1. Move the folder with everything in it.
    std::fs::create_dir_all(&new_folder)?;
    std::fs::rename(p.parent().unwrap(), &new_dir)?;
    let new_rel = paths::rel(&new_dir.join(format!("{new_name}.md")));

    // 2. Rewrite every link in every note when the name changed.
    let mut rewrites: Vec<Value> = Vec::new();
    if key_of(&new_name) != key_of(&old_name) {
        let link_re = Regex::new(&format!(
            r"(?i)\[\[{}(\|[^\]]*)?\]\]",
            regex::escape(&old_name)
        ))
        .unwrap();
        for md in list_note_files() {
            let text = std::fs::read_to_string(&md)?;
            let mut count = 0;
            let new_text = link_re
                .replace_all(&text, |_: &regex::Captures| {
                    count += 1;
                    format!("[[{new_name}]]")
                })
                .to_string();
            if count > 0 {
                atomic_write(&md, &new_text)?;
                rewrites.push(json!({"file": paths::rel(&md), "links_updated": count}));
            }
        }
    }

    editlog::record_change(
        who,
        &format!(
            "Moved note {old_name}{}",
            if key_of(&new_name) != key_of(&old_name) {
                format!(" and renamed it to {new_name}")
            } else {
                String::new()
            }
        ),
        vec![
            UndoStep {
                op: "move".into(),
                path: None,
                before: None,
                from: Some(note_rel.to_string()),
                to: Some(new_rel.clone()),
            },
        ],
    )?;
    Ok(json!({"path": new_rel, "rewrites": rewrites}))
}

pub fn delete_folder(folder_rel: &str, who: &str) -> Result<Value> {
    let folder = if folder_rel.trim().is_empty() {
        paths::DATABASE.as_path().to_path_buf()
    } else {
        paths::safe_join_rel(paths::DATABASE.as_path(), folder_rel)?
    };
    if folder == paths::DATABASE.as_path() {
        return Err(SbError::Invalid("database/ itself cannot be deleted.".into()));
    }
    if !folder.exists() {
        return Err(SbError::NotFound(format!("Folder {folder_rel} not found.")));
    }
    if std::fs::read_dir(&folder).map(|mut d| d.next().is_some()).unwrap_or(false) {
        return Err(SbError::Invalid(
            "Folder is not empty; move or remove its notes first.".into(),
        ));
    }
    std::fs::remove_dir(&folder)?;
    editlog::record_change(
        who,
        &format!(
            "Deleted empty folder {}",
            folder.file_name().and_then(|s| s.to_str()).unwrap_or("")
        ),
        vec![UndoStep {
            op: "mkdir".into(),
            path: Some(paths::rel(&folder)),
            before: None,
            from: None,
            to: None,
        }],
    )?;
    Ok(json!({"ok": true}))
}

// --------------------------------------------------------------------------
// Folder operations
// --------------------------------------------------------------------------

pub fn create_folder(parent_rel: &str, name: &str, who: &str, subject_md: Option<&str>) -> Result<Value> {
    let name = paths::clean_name(name)?;
    let parent = if parent_rel.trim().is_empty() {
        paths::DATABASE.as_path().to_path_buf()
    } else {
        paths::safe_join_rel(paths::DATABASE.as_path(), parent_rel)?
    };
    let folder = parent.join(&name);
    if folder.exists() {
        return Err(SbError::Exists(format!("Folder {name:?} already exists there.")));
    }
    std::fs::create_dir_all(&folder)?;
    if let Some(sm) = subject_md {
        if !sm.trim().is_empty() {
            atomic_write(&folder.join("_subject.md"), &format!("{}\n", sm.trim_end()))?;
        }
    }
    editlog::record_change(
        who,
        &format!("Created folder {name}"),
        vec![UndoStep {
            op: "mkdir".into(),
            path: Some(paths::rel(&folder)),
            before: None,
            from: None,
            to: None,
        }],
    )?;
    Ok(json!({"path": paths::rel(&folder)}))
}

pub fn rename_folder(folder_rel: &str, new_name: &str, who: &str) -> Result<Value> {
    let folder = paths::safe_join_rel(paths::DATABASE.as_path(), folder_rel)?;
    if folder == paths::DATABASE.as_path() {
        return Err(SbError::Invalid("database/ itself cannot be renamed.".into()));
    }
    let new_name = paths::clean_name(new_name)?;
    let new_folder = folder.parent().unwrap().join(&new_name);
    if new_folder.exists() {
        return Err(SbError::Exists(format!("Folder {new_name:?} already exists.")));
    }
    std::fs::rename(&folder, &new_folder)?;
    editlog::record_change(
        who,
        &format!(
            "Renamed folder {} to {new_name}",
            folder.file_name().and_then(|s| s.to_str()).unwrap_or("")
        ),
        vec![UndoStep {
            op: "move".into(),
            path: None,
            before: None,
            from: Some(paths::rel(&folder)),
            to: Some(paths::rel(&new_folder)),
        }],
    )?;
    Ok(json!({"path": paths::rel(&new_folder)}))
}

pub fn move_folder(folder_rel: &str, new_parent_rel: &str, who: &str) -> Result<Value> {
    let folder = paths::safe_join_rel(paths::DATABASE.as_path(), folder_rel)?;
    let new_parent = if new_parent_rel.trim().is_empty() {
        paths::DATABASE.as_path().to_path_buf()
    } else {
        paths::safe_join_rel(paths::DATABASE.as_path(), new_parent_rel)?
    };
    if new_parent == folder || new_parent.starts_with(&folder) {
        return Err(SbError::Invalid("A folder cannot move inside itself.".into()));
    }
    let fname = folder.file_name().and_then(|n| n.to_str()).unwrap_or("").to_string();
    let new_folder = new_parent.join(&fname);
    if new_folder.exists() {
        return Err(SbError::Exists(format!("Folder {fname:?} already exists there.")));
    }
    std::fs::rename(&folder, &new_folder)?;
    editlog::record_change(
        who,
        &format!("Moved folder {fname}"),
        vec![UndoStep {
            op: "move".into(),
            path: None,
            before: None,
            from: Some(paths::rel(&folder)),
            to: Some(paths::rel(&new_folder)),
        }],
    )?;
    Ok(json!({"path": paths::rel(&new_folder)}))
}

// --------------------------------------------------------------------------
// Folder tree / subject files
// --------------------------------------------------------------------------

pub fn folder_tree() -> Value {
    fn build(folder: &Path) -> Value {
        let is_db = folder == paths::DATABASE.as_path();
        let private = is_private(folder);
        let mut notes = 0i64;
        let mut children: Vec<Value> = Vec::new();
        let mut dirs: Vec<PathBuf> = std::fs::read_dir(folder)
            .map(|rd| rd.filter_map(|e| e.ok()).map(|e| e.path()).collect())
            .unwrap_or_default();
        dirs.sort_by_key(|p| {
            p.file_name()
                .and_then(|n| n.to_str())
                .map(|n| n.to_lowercase())
                .unwrap_or_default()
        });
        for child in dirs {
            let cname = child.file_name().and_then(|n| n.to_str()).unwrap_or("").to_string();
            if !child.is_dir() || cname == "attachments" {
                continue;
            }
            if child.join(format!("{cname}.md")).exists() {
                if !private {
                    notes += 1;
                }
                continue;
            }
            children.push(build(&child));
        }
        json!({
            "name": if is_db { "database".to_string() } else { folder.file_name().and_then(|n| n.to_str()).unwrap_or("").to_string() },
            "path": if is_db { "".to_string() } else { paths::rel(folder).trim_start_matches("database/").to_string() },
            "notes": notes,
            "private": private,
            "children": children,
        })
    }
    build(paths::DATABASE.as_path())
}

pub fn list_subjects() -> Vec<Value> {
    let mut out: Vec<Value> = Vec::new();
    let mut dirs: Vec<PathBuf> = walkdir::WalkDir::new(paths::DATABASE.as_path())
        .min_depth(1)
        .into_iter()
        .filter_map(|e| e.ok())
        .map(|e| e.path().to_path_buf())
        .filter(|p| p.is_dir())
        .collect();
    dirs.sort();
    for folder in dirs {
        let name = folder.file_name().and_then(|n| n.to_str()).unwrap_or("").to_string();
        if name == "attachments" || folder.join(format!("{name}.md")).exists() {
            continue;
        }
        let path = paths::rel(&folder).trim_start_matches("database/").to_string();
        out.push(json!({
            "path": path,
            "name": name,
            "private": is_private(&folder),
        }));
    }
    out
}

// --------------------------------------------------------------------------
// Tags on notes, master tags
// --------------------------------------------------------------------------

pub fn edit_tags(note_rel: &str, add: Option<Vec<String>>, remove: Option<Vec<String>>, who: &str) -> Result<Value> {
    let p = paths::ROOT.join(note_rel);
    let tags_file = p.parent().unwrap().join("tags.txt");
    let old_raw = std::fs::read_to_string(&tags_file).unwrap_or_default();
    let mut current = tags_mod::parse_tags_txt(&old_raw)?;
    let mut added: Vec<String> = Vec::new();
    let mut removed: Vec<String> = Vec::new();
    let mut keys: Vec<String> = current.iter().map(|t| key_of(t)).collect();
    for t in add.unwrap_or_default() {
        let t = tags_mod::validate_tag(&t)?;
        if !keys.contains(&key_of(&t)) {
            current.push(t.clone());
            keys.push(key_of(&t));
            added.push(t);
        }
    }
    for t in remove.unwrap_or_default() {
        let t = tags_mod::validate_tag(&t)?;
        let before = current.len();
        current.retain(|x| key_of(x) != key_of(&t));
        if current.len() < before {
            removed.push(t);
        }
    }
    if !added.is_empty() || !removed.is_empty() {
        atomic_write(&tags_file, &tags_mod::render_tags_txt(&current))?;
        let synced = tags_mod::add_to_master(&added, who)?;
        editlog::record_change(
            who,
            &format!(
                "Edited tags of {}",
                p.file_stem().and_then(|s| s.to_str()).unwrap_or("")
            ),
            vec![UndoStep {
                op: "write".into(),
                path: Some(paths::rel(&tags_file)),
                before: Some(old_raw),
                from: None,
                to: None,
            }],
        )?;
        return Ok(json!({
            "tags": current, "added": added, "removed": removed,
            "master_updated": synced,
        }));
    }
    Ok(json!({"tags": current, "added": added, "removed": removed}))
}

pub fn rename_tag(old: &str, new: &str, who: &str, run: bool) -> Result<Value> {
    let old = tags_mod::validate_tag(old)?;
    let new = tags_mod::validate_tag(new)?;
    let mut affected: Vec<(PathBuf, String, Vec<String>, Vec<String>)> = Vec::new();
    let mut tags_files: Vec<PathBuf> = walkdir::WalkDir::new(paths::DATABASE.as_path())
        .into_iter()
        .filter_map(|e| e.ok())
        .map(|e| e.path().to_path_buf())
        .filter(|p| p.is_file() && p.file_name().map(|n| n == "tags.txt").unwrap_or(false))
        .collect();
    tags_files.sort();
    for tf in &tags_files {
        let raw = std::fs::read_to_string(tf)?;
        let cur = tags_mod::parse_tags_txt(&raw)?;
        let mut out: Vec<String> = Vec::new();
        let mut changed = false;
        for t in &cur {
            if tags_mod::same_tag(t, &old) {
                if !out.contains(&new) {
                    out.push(new.clone());
                }
                changed = true;
            } else if !out.contains(t) {
                out.push(t.clone());
            }
        }
        if changed {
            affected.push((tf.clone(), raw, cur, out));
        }
    }
    let preview = json!({
        "from": old, "to": new,
        "notes": affected.iter().map(|(f, _, o, n)| json!({
            "file": paths::rel(f),
            "old": o, "new": n,
        })).collect::<Vec<_>>(),
    });
    if !run {
        return Ok(preview);
    }

    let master_path = paths::ROOT.join("_tags.md");
    let master_old = std::fs::read_to_string(&master_path)?;
    let pat = Regex::new(&format!(
        r"(?im)^(\s*-\s*){}(\s*:.*)?$",
        regex::escape(&old)
    ))
    .unwrap();
    let n_master = pat.find_iter(&master_old).count();
    let master_new = pat
        .replace_all(&master_old, |c: &regex::Captures| {
            format!("{}{}{}", &c[1], new, c.get(2).map(|m| m.as_str()).unwrap_or(""))
        })
        .to_string();
    for (f, _raw, cur, out) in &affected {
        let _ = cur;
        atomic_write(f, &tags_mod::render_tags_txt(out))?;
    }
    if n_master > 0 {
        atomic_write(&master_path, &master_new)?;
    }
    let mut steps = vec![UndoStep {
        op: "write".into(),
        path: Some("_tags.md".into()),
        before: Some(master_old),
        from: None,
        to: None,
    }];
    for (f, _raw, cur, _out) in &affected {
        steps.push(UndoStep {
            op: "write".into(),
            path: Some(paths::rel(f)),
            before: Some(tags_mod::render_tags_txt(cur)),
            from: None,
            to: None,
        });
    }
    editlog::record_change(who, &format!("Renamed tag {old} to {new}"), steps)?;
    Ok(preview)
}

pub fn merge_tags(src: &str, dst: &str, who: &str, run: bool) -> Result<Value> {
    let src = tags_mod::validate_tag(src)?;
    let dst = tags_mod::validate_tag(dst)?;
    let mut tags_files: Vec<PathBuf> = walkdir::WalkDir::new(paths::DATABASE.as_path())
        .into_iter()
        .filter_map(|e| e.ok())
        .map(|e| e.path().to_path_buf())
        .filter(|p| p.is_file() && p.file_name().map(|n| n == "tags.txt").unwrap_or(false))
        .collect();
    tags_files.sort();
    let mut affected: Vec<(PathBuf, String, Vec<String>, Vec<String>)> = Vec::new();
    for tf in &tags_files {
        let raw = std::fs::read_to_string(tf)?;
        let cur = tags_mod::parse_tags_txt(&raw)?;
        if !cur.iter().any(|t| tags_mod::same_tag(t, &src)) {
            continue;
        }
        let mut out: Vec<String> = Vec::new();
        for t in &cur {
            let t2 = if tags_mod::same_tag(t, &src) { dst.clone() } else { t.clone() };
            if !out.contains(&t2) {
                out.push(t2);
            }
        }
        affected.push((tf.clone(), raw, cur, out));
    }
    let preview = json!({
        "from": src, "into": dst,
        "notes": affected.iter().map(|(f, _, o, n)| json!({
            "file": paths::rel(f), "old": o, "new": n,
        })).collect::<Vec<_>>(),
    });
    if !run {
        return Ok(preview);
    }
    let master_path = paths::ROOT.join("_tags.md");
    let master_old = std::fs::read_to_string(&master_path)?;
    let master_new = remove_tag_from_master(&master_old, &src);
    for (f, _raw, cur, out) in &affected {
        atomic_write(f, &tags_mod::render_tags_txt(out))?;
    }
    atomic_write(&master_path, &master_new)?;
    let mut steps = vec![UndoStep {
        op: "write".into(),
        path: Some("_tags.md".into()),
        before: Some(master_old),
        from: None,
        to: None,
    }];
    for (f, _raw, cur, _out) in &affected {
        steps.push(UndoStep {
            op: "write".into(),
            path: Some(paths::rel(f)),
            before: Some(tags_mod::render_tags_txt(cur)),
            from: None,
            to: None,
        });
    }
    editlog::record_change(who, &format!("Merged tag {src} into {dst}"), steps)?;
    Ok(preview)
}

pub fn remove_tag_everywhere(tag: &str, who: &str, run: bool) -> Result<Value> {
    let tag = tags_mod::validate_tag(tag)?;
    let mut tags_files: Vec<PathBuf> = walkdir::WalkDir::new(paths::DATABASE.as_path())
        .into_iter()
        .filter_map(|e| e.ok())
        .map(|e| e.path().to_path_buf())
        .filter(|p| p.is_file() && p.file_name().map(|n| n == "tags.txt").unwrap_or(false))
        .collect();
    tags_files.sort();
    let mut affected: Vec<(PathBuf, String, Vec<String>, Vec<String>)> = Vec::new();
    for tf in &tags_files {
        let raw = std::fs::read_to_string(tf)?;
        let cur = tags_mod::parse_tags_txt(&raw)?;
        let out: Vec<String> =
            cur.iter().filter(|t| !tags_mod::same_tag(t, &tag)).cloned().collect();
        if out != cur {
            affected.push((tf.clone(), raw, cur, out));
        }
    }
    let preview = json!({
        "tag": tag,
        "notes": affected.iter().map(|(f, _, o, n)| json!({
            "file": paths::rel(f), "old": o, "new": n,
        })).collect::<Vec<_>>(),
    });
    if !run {
        return Ok(preview);
    }
    let master_path = paths::ROOT.join("_tags.md");
    let master_old = std::fs::read_to_string(&master_path)?;
    let master_new = remove_tag_from_master(&master_old, &tag);
    for (f, _raw, cur, out) in &affected {
        atomic_write(f, &tags_mod::render_tags_txt(out))?;
    }
    atomic_write(&master_path, &master_new)?;
    let mut steps = vec![UndoStep {
        op: "write".into(),
        path: Some("_tags.md".into()),
        before: Some(master_old),
        from: None,
        to: None,
    }];
    for (f, _raw, cur, _out) in &affected {
        steps.push(UndoStep {
            op: "write".into(),
            path: Some(paths::rel(f)),
            before: Some(tags_mod::render_tags_txt(cur)),
            from: None,
            to: None,
        });
    }
    editlog::record_change(who, &format!("Removed tag {tag}"), steps)?;
    Ok(preview)
}

fn remove_tag_from_master(master: &str, tag: &str) -> String {
    let re = Regex::new(r"^\s*-\s*([A-Za-z0-9_\-]+)").unwrap();
    master
        .lines()
        .filter(|ln| {
            re.captures(ln)
                .map(|c| !tags_mod::same_tag(&c[1], tag))
                .unwrap_or(true)
        })
        .collect::<Vec<_>>()
        .join("\n")
}

pub fn edit_master_tags(new_text: &str, who: &str) -> Result<Value> {
    let master_path = paths::ROOT.join("_tags.md");
    let old = std::fs::read_to_string(&master_path)?;
    atomic_write(&master_path, new_text)?;
    editlog::record_change(
        who,
        "Edited master tag list",
        vec![UndoStep {
            op: "write".into(),
            path: Some("_tags.md".into()),
            before: Some(old),
            from: None,
            to: None,
        }],
    )?;
    Ok(json!({"ok": true}))
}

// --------------------------------------------------------------------------
// Quick info, connections, references, links, metadata
// --------------------------------------------------------------------------

pub fn set_quick_info(note_rel: &str, qi_text: Option<&str>, who: &str) -> Result<Value> {
    let p = paths::ROOT.join(note_rel);
    let text = std::fs::read_to_string(&p)
        .map_err(|_| SbError::NotFound(format!("Note {note_rel} not found.")))?;
    static QI_BLOCK_RE: once_cell::sync::Lazy<Regex> =
        once_cell::sync::Lazy::new(|| Regex::new(r"(?s):::quick-info\n.*?\n:::").unwrap());
    let old_block = QI_BLOCK_RE
        .find(&text)
        .map(|m| m.as_str().to_string())
        .unwrap_or_default();

    let new_text = if qi_text.is_none() || qi_text.unwrap_or("").trim().is_empty() {
        if old_block.is_empty() {
            text.clone()
        } else {
            text.replacen(&format!("{old_block}\n\n"), "", 1)
                .replacen(&format!("{old_block}\n"), "", 1)
        }
    } else {
        let qi = qi_text.unwrap_or("");
        let _ = parser::parse_quick_info(qi); // validate
        let new_block = format!(":::quick-info\n{}\n:::", qi.trim_end());
        if !old_block.is_empty() {
            text.replacen(&old_block, &new_block, 1)
        } else {
            // insert after the H1 title line
            let mut inserted = false;
            let mut lines: Vec<String> = Vec::new();
            for ln in text.split_inclusive('\n') {
                lines.push(ln.to_string());
                if !inserted && ln.starts_with("# ") {
                    lines.push(format!("\n{new_block}\n"));
                    inserted = true;
                }
            }
            if !inserted {
                lines.insert(0, format!("{new_block}\n"));
            }
            lines.join("")
        }
    };
    let new_text = touch_updated(&new_text);
    atomic_write(&p, &new_text)?;
    if new_text != text {
        editlog::record_note_edit(note_rel, who, &text, &new_text)?;
    }
    editlog::record_change(
        who,
        &format!(
            "Edited quick info of {}",
            p.file_stem().and_then(|s| s.to_str()).unwrap_or("")
        ),
        vec![UndoStep {
            op: "write".into(),
            path: Some(note_rel.to_string()),
            before: Some(text),
            from: None,
            to: None,
        }],
    )?;
    Ok(json!({"ok": true}))
}

pub fn set_metadata(note_rel: &str, meta: &Value, who: &str) -> Result<Value> {
    let p = paths::ROOT.join(note_rel);
    let text = std::fs::read_to_string(&p)
        .map_err(|_| SbError::NotFound(format!("Note {note_rel} not found.")))?;
    static META_BLOCK_RE: once_cell::sync::Lazy<Regex> =
        once_cell::sync::Lazy::new(|| Regex::new(r"(?s):::meta\n.*?\n:::").unwrap());
    let old_block = META_BLOCK_RE
        .find(&text)
        .map(|m| m.as_str().to_string())
        .unwrap_or_default();
    let old_doc = parser::parse_note(&text, note_rel);
    let mut merged = old_doc.meta.clone();
    if let Some(obj) = meta.as_object() {
        for (k, v) in obj {
            if let Some(s) = v.as_str() {
                merged.insert(k.clone(), s.to_string());
            }
        }
    }
    merged.remove("status"); // verification removed in v1.1
    let new_block = parser::render_meta(&merged);
    let new_text = if !old_block.is_empty() {
        text.replacen(&old_block, &new_block, 1)
    } else {
        format!("{}\n\n{new_block}\n", text.trim_end())
    };
    atomic_write(&p, &new_text)?;
    if new_text != text {
        editlog::record_note_edit(note_rel, who, &text, &new_text)?;
    }
    editlog::record_change(
        who,
        &format!(
            "Edited metadata of {}",
            p.file_stem().and_then(|s| s.to_str()).unwrap_or("")
        ),
        vec![UndoStep {
            op: "write".into(),
            path: Some(note_rel.to_string()),
            before: Some(text),
            from: None,
            to: None,
        }],
    )?;
    Ok(json!({"ok": true, "meta": merged}))
}

pub fn edit_connections(
    note_rel: &str,
    add: Option<Vec<String>>,
    remove: Option<Vec<String>>,
    edit_link: Option<&Value>,
    who: &str,
) -> Result<Value> {
    let p = paths::ROOT.join(note_rel);
    let text = std::fs::read_to_string(&p)
        .map_err(|_| SbError::NotFound(format!("Note {note_rel} not found.")))?;
    let old = text.clone();
    let doc = parser::parse_note(&text, note_rel);
    let mut targets = doc.connected.clone();

    for t in remove.unwrap_or_default() {
        let mut t = t;
        if !targets.iter().any(|x| key_of(x) == key_of(&t)) {
            let existing = note_exists(&t)
                .ok_or_else(|| SbError::NotFound(format!("No note named {t:?}.")))?;
            t = existing.file_stem().and_then(|s| s.to_str()).unwrap_or("").to_string();
        }
        targets.retain(|x| key_of(x) != key_of(&t));
    }

    for t in add.unwrap_or_default() {
        let existing = note_exists(&t).ok_or_else(|| {
            SbError::Invalid(format!(
                "A connection to a note that does not exist cannot be created: {t:?} is not in this wiki."
            ))
        })?;
        let t = existing.file_stem().and_then(|s| s.to_str()).unwrap_or("").to_string();
        if key_of(&t) != key_of(&doc.title)
            && !targets.iter().any(|x| key_of(x) == key_of(&t))
        {
            targets.push(t);
        }
    }

    let mut text = text;
    if let Some(el) = edit_link {
        // edit a linked-in-text connection: change target of [[old|word]]
        let old_target = el.get("target").and_then(|v| v.as_str()).unwrap_or("").to_string();
        let word = el.get("word").and_then(|v| v.as_str()).map(|s| s.to_string());
        let new_target = el.get("new_target").and_then(|v| v.as_str()).map(|s| s.to_string());
        let unlink = el.get("unlink").and_then(|v| v.as_bool()).unwrap_or(false);
        text = WIKI_LINK_RE
            .replace_all(&text, |caps: &regex::Captures| {
                let tgt = caps[1].trim().to_string();
                let cap_word = caps
                    .get(2)
                    .map(|w| w.as_str().trim().to_string())
                    .unwrap_or_else(|| tgt.clone());
                if key_of(&tgt) == key_of(&old_target)
                    && (word.is_none() || word.as_deref() == Some(cap_word.as_str()))
                {
                    if unlink {
                        return cap_word;
                    }
                    if let Some(nt) = &new_target {
                        return match caps.get(2) {
                            Some(w) => format!("[[{nt}|{}]]", w.as_str()),
                            None => format!("[[{nt}]]"),
                        };
                    }
                }
                caps[0].to_string()
            })
            .to_string();
    }

    // rebuild the Connected notes section
    text = rebuild_section(&text, "Connected notes", &targets);
    if text == old {
        return Ok(json!({"ok": true, "connected": targets}));
    }
    let text = touch_updated(&text);
    atomic_write(&p, &text)?;
    editlog::record_note_edit(note_rel, who, &old, &text)?;
    editlog::record_change(
        who,
        &format!(
            "Edited connections of {}",
            p.file_stem().and_then(|s| s.to_str()).unwrap_or("")
        ),
        vec![UndoStep {
            op: "write".into(),
            path: Some(note_rel.to_string()),
            before: Some(old),
            from: None,
            to: None,
        }],
    )?;
    Ok(json!({"ok": true, "connected": targets}))
}

/// Replace (or append) the `## <title>` section's lines, keeping everything
/// before and after byte-for-byte (a level-2 heading ends the section).
pub fn rebuild_section(src_text: &str, title: &str, lines: &[String]) -> String {
    let heading = format!("## {title}");
    let src_lines: Vec<&str> = src_text.lines().collect();
    let mut out: Vec<String> = Vec::new();
    let mut i = 0usize;
    let mut found = false;
    while i < src_lines.len() {
        if !found && src_lines[i].trim() == heading {
            found = true;
            out.push(heading.clone());
            i += 1;
            let mut in_code = false;
            while i < src_lines.len() {
                let l = src_lines[i];
                if l.trim_start().starts_with("```") {
                    in_code = !in_code;
                }
                if !in_code && l.starts_with("## ") {
                    break;
                }
                i += 1;
            }
            out.push(String::new());
            for l in lines {
                out.push(l.clone());
            }
            continue;
        }
        out.push(src_lines[i].to_string());
        i += 1;
    }
    if !found {
        out.push(String::new());
        out.push(heading.clone());
        out.push(String::new());
        for l in lines {
            out.push(l.clone());
        }
    }
    let mut joined = out.join("\n");
    if src_text.ends_with('\n') {
        joined.push('\n');
    }
    joined
}

pub fn normalize_url(url: &str) -> String {
    static SCHEME_RE: once_cell::sync::Lazy<Regex> =
        once_cell::sync::Lazy::new(|| Regex::new(r"^[a-zA-Z][a-zA-Z0-9+.-]*://").unwrap());
    let u = url.trim();
    if u.is_empty() {
        return u.to_string();
    }
    if SCHEME_RE.is_match(u) {
        return u.to_string();
    }
    if u.starts_with('#') || u.starts_with('/') {
        return u.to_string();
    }
    format!("https://{u}")
}

pub fn edit_references(
    note_rel: &str,
    add: Option<&Value>,
    remove_url: Option<&str>,
    who: &str,
) -> Result<Value> {
    let p = paths::ROOT.join(note_rel);
    let text = std::fs::read_to_string(&p)
        .map_err(|_| SbError::NotFound(format!("Note {note_rel} not found.")))?;
    let old = text.clone();
    let doc = parser::parse_note(&text, note_rel);
    let mut refs = doc.references.clone();
    if let Some(ru) = remove_url {
        refs.retain(|r| r.url != ru);
    }
    if let Some(a) = add {
        let url = normalize_url(a.get("url").and_then(|v| v.as_str()).unwrap_or(""));
        if !url.starts_with("http") {
            return Err(SbError::Invalid(
                "A reference needs a web address, for example example.com (https:// is added automatically).".into(),
            ));
        }
        refs.push(parser::Reference {
            title: a
                .get("title")
                .and_then(|v| v.as_str())
                .filter(|s| !s.is_empty())
                .unwrap_or(&url)
                .to_string(),
            url,
            accessed: a
                .get("accessed")
                .and_then(|v| v.as_str())
                .filter(|s| !s.is_empty())
                .unwrap_or(&today())
                .to_string(),
        });
    }
    let lines: Vec<String> = refs
        .iter()
        .map(|r| {
            if r.accessed.is_empty() {
                format!("- [{}]({})", r.title, r.url)
            } else {
                format!("- [{}]({}) \u{2014} accessed {}", r.title, r.url, r.accessed)
            }
        })
        .collect();
    let mut text = rebuild_section(&text, "Reference sources", &lines);
    if text != old {
        text = touch_updated(&text);
        atomic_write(&p, &text)?;
        editlog::record_note_edit(note_rel, who, &old, &text)?;
        editlog::record_change(
            who,
            &format!(
                "Edited reference sources of {}",
                p.file_stem().and_then(|s| s.to_str()).unwrap_or("")
            ),
            vec![UndoStep {
                op: "write".into(),
                path: Some(note_rel.to_string()),
                before: Some(old),
                from: None,
                to: None,
            }],
        )?;
    }
    Ok(json!({"ok": true, "references": refs}))
}

pub fn edit_links(note_rel: &str, word: &str, new_target: Option<&str>, make_note: bool, who: &str) -> Result<Value> {
    let p = paths::ROOT.join(note_rel);
    let text = std::fs::read_to_string(&p)
        .map_err(|_| SbError::NotFound(format!("Note {note_rel} not found.")))?;
    let old = text.clone();
    let mut text = text;
    match new_target {
        None => {
            // unlink, keep the words
            let pat = Regex::new(&format!(
                r"\[\[{}\]\]|\[\[[^\]|]+\|{}\]\]",
                regex::escape(word),
                regex::escape(word)
            ))
            .unwrap();
            text = pat.replace_all(&text, word.replace('$', "$$").as_str()).to_string();
        }
        Some(t) => {
            if make_note {
                let existing = note_exists(t).ok_or_else(|| {
                    SbError::Invalid(format!("No note named {t:?} in this wiki."))
                })?;
                let stem = existing.file_stem().and_then(|s| s.to_str()).unwrap_or("").to_string();
                text = text.replacen(word, &format!("[[{stem}|{word}]]"), 1);
            } else {
                text = text.replacen(word, &format!("[{word}]({t})"), 1);
            }
        }
    }
    if text != old {
        let text = touch_updated(&text);
        atomic_write(&p, &text)?;
        editlog::record_note_edit(note_rel, who, &old, &text)?;
        editlog::record_change(
            who,
            &format!(
                "Edited links in {}",
                p.file_stem().and_then(|s| s.to_str()).unwrap_or("")
            ),
            vec![UndoStep {
                op: "write".into(),
                path: Some(note_rel.to_string()),
                before: Some(old),
                from: None,
                to: None,
            }],
        )?;
        return Ok(json!({"ok": true}));
    }
    Ok(json!({"ok": true}))
}

pub fn export_metadata(note_rel: &str) -> Result<String> {
    let p = paths::ROOT.join(note_rel);
    let text = std::fs::read_to_string(&p)?;
    let doc = parser::parse_note(&text, note_rel);
    let tags_file = p.parent().unwrap().join("tags.txt");
    let note_tags = if tags_file.exists() {
        tags_mod::parse_tags_txt(&std::fs::read_to_string(&tags_file)?)?
    } else {
        Vec::new()
    };
    // incoming connections: notes that connect TO this note
    let mut incoming: Vec<String> = Vec::new();
    for md in list_note_files() {
        if md == p {
            continue;
        }
        let other = parser::parse_note(&std::fs::read_to_string(&md)?, &paths::rel(&md));
        if other.connected.iter().any(|c| key_of(c) == key_of(&doc.title)) {
            incoming.push(
                md.parent()
                    .and_then(|d| d.file_name())
                    .and_then(|n| n.to_str())
                    .unwrap_or("")
                    .to_string(),
            );
        }
    }
    let att_dir = p.parent().unwrap().join("attachments");
    let mut atts: Vec<String> = std::fs::read_dir(&att_dir)
        .map(|rd| {
            rd.filter_map(|e| e.ok())
                .filter(|e| e.path().is_file())
                .filter_map(|e| e.file_name().into_string().ok())
                .collect()
        })
        .unwrap_or_default();
    atts.sort();

    let ext = tags_mod::extract_all_notes_tags()?;
    let folder_rel = p
        .parent()
        .and_then(|d| d.strip_prefix(paths::DATABASE.as_path()).ok())
        .map(|d| d.to_string_lossy().replace('\\', "/"))
        .unwrap_or_default();
    let parent_rel = p
        .parent()
        .and_then(|d| d.parent())
        .and_then(|d| d.strip_prefix(paths::DATABASE.as_path()).ok())
        .map(|d| d.to_string_lossy().replace('\\', "/"))
        .unwrap_or_else(|| "(root)".to_string());
    let counts = ext["counts"].as_object().cloned().unwrap_or_default();
    let all_tags = ext["tags"].as_array().cloned().unwrap_or_default();

    let mut l: Vec<String> = vec![
        format!("File name: {}", doc.title),
        format!("File location: database/{folder_rel}/{}", p.file_name().and_then(|n| n.to_str()).unwrap_or("")),
        format!("Folder path: {parent_rel}"),
        format!("Tags: {}", if note_tags.is_empty() { "(none)".into() } else { note_tags.join(", ") }),
        format!("Created: {}", doc.meta.get("created").unwrap_or(&"".to_string())),
        format!("Updated: {}", doc.meta.get("updated").unwrap_or(&"".to_string())),
        format!("Pinned: {}", doc.meta.get("pinned").unwrap_or(&"no".to_string())),
        String::new(),
        "Connected notes:".into(),
    ];
    if doc.connected.is_empty() {
        l.push("  (none)".into());
    } else {
        for c in &doc.connected {
            l.push(format!("  - {c}"));
        }
    }
    l.push(String::new());
    l.push("Connected from (other notes link here):".into());
    if incoming.is_empty() {
        l.push("  (none)".into());
    } else {
        for b in &incoming {
            l.push(format!("  - {b}"));
        }
    }
    l.push(String::new());
    l.push("Reference sources:".into());
    if doc.references.is_empty() {
        l.push("  (none)".into());
    } else {
        for r in &doc.references {
            l.push(format!("  - {} <{}>", r.title, r.url));
        }
    }
    l.push(String::new());
    l.push("Attachments:".into());
    if atts.is_empty() {
        l.push("  (none)".into());
    } else {
        for a in &atts {
            l.push(format!("  - attachments/{a}"));
        }
    }
    l.push(String::new());
    l.push("All tags used in this wiki (tag \u{2014} times used):".into());
    if all_tags.is_empty() {
        l.push("  (none)".into());
    } else {
        for t in &all_tags {
            let tag = t.as_str().unwrap_or("");
            let count = counts.get(tag).and_then(|c| c.as_i64()).unwrap_or(0);
            l.push(format!("  - {tag} \u{2014} {count}"));
        }
    }
    Ok(l.join("\n") + "\n")
}

// --------------------------------------------------------------------------
// Tasks
// --------------------------------------------------------------------------

static TASK_RE: once_cell::sync::Lazy<Regex> = once_cell::sync::Lazy::new(|| {
    Regex::new(r"^(\s*(?:[-*]|\d+[.)])\s+)\[([ xX])\](\s+)(.*)$").unwrap()
});

fn flip_task(text: &str, task_index: usize) -> (String, bool, bool) {
    let mut n: i64 = -1;
    let mut out: Vec<String> = Vec::new();
    let mut done_now = false;
    let mut found = false;
    for ln in text.lines() {
        let mut line = ln.to_string();
        if let Some(c) = TASK_RE.captures(ln) {
            n += 1;
            if n == task_index as i64 {
                let tick = c[2].to_string();
                let new_tick = if tick.eq_ignore_ascii_case("x") { " " } else { "x" };
                done_now = new_tick == "x";
                found = true;
                line = format!("{}[{}]{}{}", &c[1], new_tick, &c[3], &c[4]);
            }
        }
        out.push(line);
    }
    let trailing = if text.ends_with('\n') { "\n" } else { "" };
    (out.join("\n") + trailing, done_now, found)
}

pub fn toggle_task(
    note_rel: &str,
    task_index: usize,
    who: &str,
    new_text: Option<&str>,
) -> Result<Value> {
    if let Some(draft) = new_text {
        let (flipped, done, found) = flip_task(draft, task_index);
        if !found {
            return Err(SbError::Invalid(format!("Task #{task_index} was not found in this text.")));
        }
        return Ok(json!({"ok": true, "text": flipped, "done": done, "draft": true}));
    }
    let p = paths::ROOT.join(note_rel);
    if !p.exists() {
        return Err(SbError::NotFound(format!("Note {note_rel} not found.")));
    }
    let old = std::fs::read_to_string(&p)?;
    let (flipped, done, found) = flip_task(&old, task_index);
    if !found {
        return Err(SbError::Invalid(format!("Task #{task_index} was not found in this note.")));
    }
    atomic_write(&p, &flipped)?;
    editlog::record_note_edit(note_rel, who, &old, &flipped)?;
    editlog::record_change(
        who,
        &format!(
            "Toggled a checklist item in {}",
            p.file_stem().and_then(|s| s.to_str()).unwrap_or("")
        ),
        vec![UndoStep {
            op: "write".into(),
            path: Some(note_rel.to_string()),
            before: Some(old),
            from: None,
            to: None,
        }],
    )?;
    Ok(json!({"ok": true, "text": flipped, "done": done, "hash": text_sha256(&flipped)}))
}

pub fn note_tasks(note_rel: &str, text: Option<&str>) -> Vec<Value> {
    let raw = match text {
        Some(t) => t.to_string(),
        None => std::fs::read_to_string(paths::ROOT.join(note_rel)).unwrap_or_default(),
    };
    let mut out = Vec::new();
    for (i, ln) in raw.lines().enumerate() {
        if let Some(c) = TASK_RE.captures(ln) {
            out.push(json!({
                "index": out.len(),
                "done": c[2].to_lowercase() == "x",
                "text": c[4],
                "line": i,
            }));
        }
    }
    out
}

pub fn toggle_pin(note_rel: &str, who: &str) -> Result<Value> {
    let p = paths::ROOT.join(note_rel);
    let text = std::fs::read_to_string(&p)?;
    let doc = parser::parse_note(&text, note_rel);
    let pinned = doc.meta.get("pinned").map(|v| v.to_lowercase() == "yes").unwrap_or(false);
    set_metadata(note_rel, &json!({"pinned": if pinned { "no" } else { "yes" }}), who)
}

// --------------------------------------------------------------------------
// Saved searches
// --------------------------------------------------------------------------

pub fn saved_searches() -> Vec<Value> {
    load_settings()
        .get("saved_searches")
        .and_then(|v| v.as_array().cloned())
        .unwrap_or_default()
}

pub fn save_search(name: &str, params: &Value, who: &str) -> Result<Value> {
    let mut s = load_settings();
    let mut lst: Vec<Value> = s
        .get("saved_searches")
        .and_then(|v| v.as_array().cloned())
        .unwrap_or_default()
        .into_iter()
        .filter(|x| x.get("name").and_then(|n| n.as_str()) != Some(name))
        .collect();
    lst.push(json!({"name": name, "params": params}));
    if let Some(obj) = s.as_object_mut() {
        obj.insert("saved_searches".into(), Value::Array(lst.clone()));
    }
    save_settings(&s)?;
    Ok(json!({"ok": true, "saved": lst, "who": crate::logger::who_name(who)}))
}

pub fn delete_saved_search(name: &str) -> Result<Value> {
    let mut s = load_settings();
    let lst: Vec<Value> = s
        .get("saved_searches")
        .and_then(|v| v.as_array().cloned())
        .unwrap_or_default()
        .into_iter()
        .filter(|x| x.get("name").and_then(|n| n.as_str()) != Some(name))
        .collect();
    if let Some(obj) = s.as_object_mut() {
        obj.insert("saved_searches".into(), Value::Array(lst));
    }
    save_settings(&s)?;
    Ok(json!({"ok": true}))
}

// --------------------------------------------------------------------------
// AI librarian support
// --------------------------------------------------------------------------

pub fn propose_tags(proposed: &[String], who: &str, reason: &str) -> Result<Value> {
    let mt = tags_mod::load_master()?;
    let mut new: Vec<String> = Vec::new();
    for t in proposed {
        let Ok(t) = tags_mod::validate_tag(t) else { continue };
        if !mt.has(&t) && !mt.proposed.iter().any(|x| key_of(x) == key_of(&t)) {
            new.push(t);
        }
    }
    if new.is_empty() {
        return Ok(json!({"proposed": []}));
    }
    let master_path = paths::ROOT.join("_tags.md");
    let old = std::fs::read_to_string(&master_path)?;
    let add: String = new.iter().map(|t| format!("- {t}\n")).collect();
    let new_text = if Regex::new(r"(?im)^## Proposed tags\s*$")
        .unwrap()
        .is_match(&old)
    {
        let mut nt = old.clone();
        // append at end of file (simplest correct spot)
        nt = format!("{}\n{}", nt.trim_end(), add);
        nt
    } else {
        format!("{}\n\n## Proposed tags\n\n{}", old.trim_end(), add)
    };
    atomic_write(&master_path, &new_text)?;
    crate::logger::new_log(
        who,
        &format!(
            "Proposed tag{} {}",
            if new.len() > 1 { "s" } else { "" },
            new.join(", ")
        ),
        &format!(
            "- Added under *Proposed tags* in `_tags.md`: {}{}",
            new.join(", "),
            if reason.is_empty() { String::new() } else { format!("\n- Reason: {reason}") }
        ),
    );
    Ok(json!({"proposed": new}))
}

pub fn file_note(
    text: &str,
    name: &str,
    folder_rel: &str,
    tags: Option<Vec<String>>,
    who: &str,
    reason: &str,
    approve_new_folder: bool,
) -> Result<Value> {
    let name = paths::clean_name(name)?;
    let mut validated_tags: Vec<String> = Vec::new();
    for t in tags.unwrap_or_default() {
        validated_tags.push(tags_mod::validate_tag(&t)?);
    }
    let text = text.trim();
    if text.is_empty() {
        return Err(SbError::Invalid("file_note needs some content to file.".into()));
    }
    if let Some(existing) = note_exists(&name) {
        let old = std::fs::read_to_string(&existing)?;
        let block = format!(
            "### Filed {today}{reason_part}\n\n{text}\n",
            today = today(),
            reason_part = if reason.is_empty() {
                String::new()
            } else {
                format!(" \u{2014} {reason}")
            }
        );
        let new_text = if old.contains("## My notes") {
            old.replacen("## My notes", &format!("{block}\n## My notes"), 1)
        } else {
            format!("{}\n\n{block}", old.trim_end())
        };
        let new_text = touch_updated(&new_text);
        atomic_write(&existing, &new_text)?;
        let proposed = propose_tags(&validated_tags, who, if reason.is_empty() { "filed with note update" } else { reason })?;
        editlog::record_change(
            who,
            &format!(
                "Filed new material into {}",
                existing.file_stem().and_then(|s| s.to_str()).unwrap_or("")
            ),
            vec![UndoStep {
                op: "write".into(),
                path: Some(paths::rel(&existing)),
                before: Some(old),
                from: None,
                to: None,
            }],
        )?;
        return Ok(json!({
            "filed_into": paths::rel(&existing),
            "action": "updated",
            "proposed_tags": proposed.get("proposed"),
        }));
    }

    let folder = if folder_rel.trim().is_empty() {
        paths::DATABASE.as_path().to_path_buf()
    } else {
        paths::safe_join_rel(paths::DATABASE.as_path(), folder_rel)?
    };
    if !folder.exists() {
        if !approve_new_folder {
            return Err(SbError::NeedsApproval {
                question: format!(
                    "The folder {folder_rel:?} does not exist. The AI must ask before creating a new folder. Ask the user; if they approve, call again with approve_new_folder=true."
                ),
            });
        }
        let parts: Vec<&str> = folder_rel.split('/').filter(|s| !s.is_empty()).collect();
        let (parent, leaf) = parts.split_at(parts.len().saturating_sub(1));
        create_folder(&parent.join("/"), leaf.first().unwrap_or(&""), "ai", None)?;
    }
    let body = format!(
        "# {name}\n\n{text}\n\n## My notes\n\n## Connected notes\n\n## Reference sources\n\n{}",
        parser::render_meta(&HashMap::from([
            ("created".to_string(), today()),
            ("updated".to_string(), today()),
            ("pinned".to_string(), "no".to_string()),
        ]))
    );
    let mut out = create_note(
        folder_rel,
        &name,
        Some(&validated_tags),
        Some(&body),
        None,
        who,
        if reason.is_empty() { "filed from raw note" } else { reason },
    )?;
    let proposed = propose_tags(&validated_tags, who, if reason.is_empty() { "filed with new note" } else { reason })?;
    if let Some(obj) = out.as_object_mut() {
        obj.insert("action".into(), json!("created"));
        obj.insert("proposed_tags".into(), proposed.get("proposed").cloned().unwrap_or(json!([])));
    }
    Ok(out)
}

// --------------------------------------------------------------------------
// Type-ahead suggestions (shared by website and MCP)
// --------------------------------------------------------------------------

pub fn note_count(subject_rel: &str) -> usize {
    let base = paths::DATABASE.join(subject_rel);
    if !base.exists() {
        return 0;
    }
    walkdir::WalkDir::new(base)
        .into_iter()
        .filter_map(|e| e.ok())
        .filter(|e| {
            e.path().is_file()
                && e.path().extension().map(|x| x == "md").unwrap_or(false)
                && e.file_name() != "_subject.md"
                && e.path()
                    .parent()
                    .and_then(|d| d.file_name())
                    .map(|d| d == e.path().file_stem().unwrap_or_default())
                    .unwrap_or(false)
        })
        .count()
}

pub fn suggest(q: &str, kind: &str) -> Result<Value> {
    let qn = q.trim().to_lowercase().replace(' ', "-");
    let qn_note = q.trim().to_lowercase();
    let mut out: Vec<Value> = Vec::new();
    let mut seen: Vec<String> = Vec::new();

    // note names: the preview under "add a connected note" and link inputs
    if kind == "note" {
        let idx = crate::indexer::load_index()?;
        let mut rows: Vec<Value> = Vec::new();
        for (rp, e) in &idx.files {
            let tl = e.title.to_lowercase();
            let starts = tl.starts_with(&qn_note);
            let contains = qn_note.is_empty() || tl.contains(&qn_note);
            if qn_note.is_empty() || starts || contains {
                rows.push(json!({
                    "type": "note", "name": e.title, "path": rp,
                    "folder": e.folder, "count": 0, "starts": starts,
                }));
            }
        }
        rows.sort_by(|a, b| {
            let as_ = a["starts"].as_bool().unwrap_or(false);
            let bs = b["starts"].as_bool().unwrap_or(false);
            bs.cmp(&as_).then_with(|| {
                a["name"].as_str().unwrap_or("").to_lowercase()
                    .cmp(&b["name"].as_str().unwrap_or("").to_lowercase())
            })
        });
        rows.truncate(12);
        return Ok(json!({"suggestions": rows}));
    }
    if kind == "all" || kind == "tag" {
        let ext = tags_mod::extract_all_notes_tags()?;
        let counts = ext["counts"].as_object().cloned().unwrap_or_default();
        if let Some(tags) = ext["tags"].as_array() {
            for t in tags {
                let t = t.as_str().unwrap_or("");
                let tl = t.to_lowercase();
                let starts = tl.starts_with(&qn);
                let contains = if qn.is_empty() { true } else { tl.contains(&qn) };
                if qn.is_empty() || starts || contains {
                    seen.push(key_of(t));
                    out.push(json!({
                        "type": "tag", "name": t,
                        "count": counts.get(t).and_then(|c| c.as_i64()).unwrap_or(0),
                        "starts": starts,
                    }));
                }
            }
        }
        let mt = tags_mod::load_master()?;
        for t in mt.all_tags() {
            if seen.contains(&key_of(&t)) {
                continue;
            }
            let tl = t.to_lowercase();
            let starts = tl.starts_with(&qn);
            let contains = if qn.is_empty() { true } else { tl.contains(&qn) };
            if qn.is_empty() || starts || contains {
                seen.push(key_of(&t));
                out.push(json!({"type": "tag", "name": t, "count": 0, "starts": starts}));
            }
        }
    }
    if kind == "all" || kind == "folder" {
        for s in list_subjects() {
            let name = s["name"].as_str().unwrap_or("");
            let sl = name.to_lowercase();
            let starts = sl.starts_with(&qn);
            let contains = if qn.is_empty() { true } else { sl.contains(&qn) };
            if qn.is_empty() || starts || contains {
                out.push(json!({
                    "type": "folder", "name": name,
                    "path": s["path"],
                    "count": note_count(s["path"].as_str().unwrap_or("")),
                    "starts": starts,
                }));
            }
        }
    }
    out.sort_by(|a, b| {
        let a_starts = a["starts"].as_bool().unwrap_or(false);
        let b_starts = b["starts"].as_bool().unwrap_or(false);
        b_starts
            .cmp(&a_starts)
            .then_with(|| {
                a["type"]
                    .as_str()
                    .unwrap_or("")
                    .cmp(b["type"].as_str().unwrap_or(""))
            })
            .then_with(|| {
                a["name"]
                    .as_str()
                    .unwrap_or("")
                    .to_lowercase()
                    .cmp(&b["name"].as_str().unwrap_or("").to_lowercase())
            })
    });
    out.truncate(12);
    Ok(json!({"suggestions": out}))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_normalize_url() {
        assert_eq!(normalize_url("example.com"), "https://example.com");
        assert_eq!(normalize_url("http://a.b"), "http://a.b");
        assert_eq!(normalize_url("https://a.b"), "https://a.b");
    }

    #[test]
    fn test_flip_task() {
        let (t, done, found) = flip_task("- [ ] buy milk\n- [x] go", 0);
        assert!(found && done);
        assert!(t.starts_with("- [x] buy milk"));
    }

    #[test]
    fn test_rebuild_section() {
        let out = rebuild_section("# T\n\n## Connected notes\n\n[[A]]\n\n## Reference sources\n\n- x", "Connected notes", &["[[B]]".to_string()]);
        assert!(out.contains("[[B]]"));
        assert!(!out.contains("[[A]]"));
        assert!(out.contains("## Reference sources"));
        // append when the section is missing
        let out2 = rebuild_section("# T\n\nbody", "Connected notes", &["[[B]]".to_string()]);
        assert!(out2.contains("## Connected notes\n\n[[B]]"));
    }
}
