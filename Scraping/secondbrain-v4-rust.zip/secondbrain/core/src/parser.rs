//! The ONE note parser: quick info, sections, links, references, metadata.
//! A faithful port of `core/parser.py`.

use crate::textutil::normalize;
use regex::Regex;
use serde::Serialize;

pub static WIKI_LINK_RE: once_cell::sync::Lazy<Regex> = once_cell::sync::Lazy::new(|| {
    Regex::new(r"\[\[([^\]|]+)(?:\|([^\]]+))?\]\]").unwrap()
});
pub static MD_LINK_RE: once_cell::sync::Lazy<Regex> =
    once_cell::sync::Lazy::new(|| Regex::new(r"\[([^\]]+)\]\((https?://[^)\s]+)\)").unwrap());
pub static META_LINE_RE: once_cell::sync::Lazy<Regex> =
    once_cell::sync::Lazy::new(|| Regex::new(r"^([A-Za-z][A-Za-z0-9 _-]*):\s*(.*)$").unwrap());

pub const STANDARD_SECTIONS: &[&str] = &["My notes", "Connected notes", "Reference sources"];

pub const ALIAS_LABELS: &[&str] = &[
    "common name", "aliases", "also known as", "aka", "title aliases",
];

#[derive(Debug, Clone, Serialize)]
pub struct QuickInfoRow {
    pub label: String,
    pub value: String,
    pub group: Option<String>,
}

#[derive(Debug, Clone, Serialize, serde::Deserialize, Default)]
pub struct Reference {
    pub title: String,
    pub url: String,
    pub accessed: String,
}

#[derive(Debug, Clone, Default)]
pub struct NoteDoc {
    pub rel_path: String,
    pub title: String,
    pub raw: String,
    /// main text without blocks/panels
    pub body: String,
    pub quick_info_raw: Option<String>,
    pub quick_info_rows: Vec<QuickInfoRow>,
    pub headings: Vec<(usize, String)>,
    pub connected: Vec<String>,
    pub linked_in_text: Vec<(String, String)>,
    pub references: Vec<Reference>,
    pub meta: std::collections::HashMap<String, String>,
    pub my_notes: String,
    pub has_quick_info: bool,
}

/// Extract `:::quick-info` / `:::meta` blocks from the text.
/// Returns (remaining_text, quick_info_raw, meta_dict).
pub fn extract_blocks(text: &str) -> (String, Option<String>, std::collections::HashMap<String, String>) {
    static BLOCK_RE: once_cell::sync::Lazy<Regex> = once_cell::sync::Lazy::new(|| {
        Regex::new(r"(?ms)^:::(quick-info|meta)[ \t]*\n(.*?)\n:::[ \t]*$").unwrap()
    });
    let mut qi: Option<String> = None;
    let mut meta = std::collections::HashMap::new();
    let remaining = BLOCK_RE.replace_all(text, |caps: &regex::Captures| {
        let kind = &caps[1];
        let content = caps[2].to_string();
        if kind == "quick-info" && qi.is_none() {
            qi = Some(content);
        } else if kind == "meta" {
            for (k, v) in parse_meta(&content) {
                meta.insert(k, v);
            }
        }
        ""
    });
    (remaining.to_string(), qi, meta)
}

pub fn parse_meta(content: &str) -> Vec<(String, String)> {
    let mut out = Vec::new();
    for line in content.lines() {
        if let Some(c) = META_LINE_RE.captures(line.trim()) {
            out.push((c[1].trim().to_lowercase(), c[2].trim().to_string()));
        }
    }
    out
}

pub fn render_meta(meta: &std::collections::HashMap<String, String>) -> String {
    let order = ["status", "created", "updated", "pinned", "ai"];
    let mut lines: Vec<String> = Vec::new();
    for k in order {
        if let Some(v) = meta.get(k) {
            if !v.is_empty() {
                let mut c = k.chars();
                let head = c.next().map(|x| x.to_uppercase().to_string()).unwrap_or_default();
                lines.push(format!("{}{}: {}", head, c.as_str(), v));
            }
        }
    }
    for (k, v) in meta {
        if !order.contains(&k.as_str()) && !v.is_empty() {
            lines.push(format!("{k}: {v}"));
        }
    }
    format!(":::meta\n{}\n:::", lines.join("\n"))
}

pub fn parse_quick_info(content: &str) -> Vec<QuickInfoRow> {
    static IMAGE_RE: once_cell::sync::Lazy<Regex> =
        once_cell::sync::Lazy::new(|| Regex::new(r"(?i)^Image:\s*").unwrap());
    static ROW_RE: once_cell::sync::Lazy<Regex> =
        once_cell::sync::Lazy::new(|| Regex::new(r"^([^:]{1,60}):\s*(.*)$").unwrap());
    let mut rows: Vec<QuickInfoRow> = Vec::new();
    let mut group: Option<String> = None;
    for raw in content.lines() {
        let line = raw.trim();
        if line.is_empty() {
            continue;
        }
        if line.starts_with("##") {
            group = Some(line.trim_start_matches('#').trim().to_string());
            continue;
        }
        if IMAGE_RE.is_match(line) {
            let value = IMAGE_RE.replace(line, "").to_string();
            rows.push(QuickInfoRow { label: "Image".into(), value, group: group.clone() });
            continue;
        }
        if let Some(c) = ROW_RE.captures(line) {
            rows.push(QuickInfoRow {
                label: c[1].trim().to_string(),
                value: c[2].trim().to_string(),
                group: group.clone(),
            });
        } else if let Some(last) = rows.last_mut() {
            last.value.push(' ');
            last.value.push_str(line);
        }
    }
    rows
}

/// Labels count like headings in search.
pub fn qi_label_rows(rows: &[QuickInfoRow]) -> Vec<String> {
    let mut out = Vec::new();
    for r in rows {
        if r.label.to_lowercase() != "image" {
            out.push(r.label.clone());
            if let Some(g) = &r.group {
                out.push(g.clone());
            }
        }
    }
    out
}

pub fn qi_value_rows(rows: &[QuickInfoRow]) -> Vec<String> {
    rows.iter()
        .filter(|r| r.label.to_lowercase() != "image")
        .map(|r| r.value.clone())
        .collect()
}

pub fn qi_aliases(rows: &[QuickInfoRow]) -> Vec<String> {
    rows.iter()
        .filter(|r| ALIAS_LABELS.contains(&r.label.to_lowercase().as_str()))
        .map(|r| r.value.clone())
        .collect()
}

pub fn qi_images(rows: &[QuickInfoRow]) -> Vec<String> {
    rows.iter()
        .filter(|r| r.label.to_lowercase() == "image" && !r.value.trim().is_empty())
        .map(|r| r.value.trim().to_string())
        .collect()
}

pub fn qi_first_image(rows: &[QuickInfoRow]) -> Option<String> {
    qi_images(rows).into_iter().next()
}

pub struct Section {
    pub level: usize,
    pub title: String,
    pub lines: Vec<String>,
}

/// Split body into sections. Returns (sections, before_first_heading).
/// Level 2+ only (# title excluded).
pub fn split_sections(text: &str) -> (Vec<Section>, String) {
    static HEAD_RE: once_cell::sync::Lazy<Regex> =
        once_cell::sync::Lazy::new(|| Regex::new(r"^(#{2,6})\s+(.*?)\s*#*\s*$").unwrap());
    let mut sections: Vec<Section> = Vec::new();
    let mut before: Vec<String> = Vec::new();
    let mut current: Option<Section> = None;
    for line in text.lines() {
        if let Some(c) = HEAD_RE.captures(line) {
            if let Some(cur) = current.take() {
                sections.push(cur);
            }
            current = Some(Section {
                level: c[1].chars().count(),
                title: c[2].to_string(),
                lines: Vec::new(),
            });
        } else if current.is_none() {
            before.push(line.to_string());
        } else if let Some(cur) = current.as_mut() {
            cur.lines.push(line.to_string());
        }
    }
    if let Some(cur) = current {
        sections.push(cur);
    }
    (sections, before.join("\n"))
}

pub fn parse_connected(lines: &[String]) -> Vec<String> {
    let mut out: Vec<String> = Vec::new();
    for line in lines {
        for m in WIKI_LINK_RE.captures_iter(line) {
            let target = m[1].trim().to_string();
            if !target.is_empty() && !out.contains(&target) {
                out.push(target);
            }
        }
    }
    out
}

pub fn parse_references(lines: &[String]) -> Vec<Reference> {
    static ACCESSED_RE: once_cell::sync::Lazy<Regex> = once_cell::sync::Lazy::new(|| {
        Regex::new(r"[-\u{2014}\u{2013}]\s*(?:accessed\s*)?(\d{4}-\d{2}-\d{2}.*)$").unwrap()
    });
    let mut refs = Vec::new();
    for raw in lines {
        let line = raw.trim().trim_start_matches(['-', '*']).trim();
        if let Some(m) = MD_LINK_RE.captures(line) {
            let mut accessed = String::new();
            if let Some(am) = ACCESSED_RE.captures(line) {
                accessed = am[1].trim().to_string();
            }
            refs.push(Reference {
                title: m[1].trim().to_string(),
                url: m[2].trim().to_string(),
                accessed,
            });
        }
    }
    refs
}

/// Full parse.
pub fn parse_note(text: &str, rel_path: &str) -> NoteDoc {
    let mut doc = NoteDoc {
        rel_path: rel_path.to_string(),
        raw: text.to_string(),
        ..Default::default()
    };
    let name = rel_path.rsplit('/').next().unwrap_or(rel_path);
    doc.title = if let Some(stripped) = name.strip_suffix(".md") {
        stripped.to_string()
    } else {
        name.to_string()
    };

    let (remaining, qi_raw, meta) = extract_blocks(text);
    doc.quick_info_raw = qi_raw;
    for (k, v) in meta {
        doc.meta.insert(k, v);
    }
    if doc.quick_info_raw.is_some() {
        doc.has_quick_info = true;
        doc.quick_info_rows = parse_quick_info(doc.quick_info_raw.as_deref().unwrap_or(""));
    }

    let (sections, before) = split_sections(&remaining);
    doc.headings = sections.iter().map(|s| (s.level, s.title.clone())).collect();

    let mut connected_lines: Vec<String> = Vec::new();
    let mut reference_lines: Vec<String> = Vec::new();
    let mut my_lines: Vec<String> = Vec::new();
    let mut body_parts: Vec<String> = Vec::new();
    if !before.trim().is_empty() {
        body_parts.push(before.trim().to_string());
    }

    for s in &sections {
        let low = normalize(&s.title);
        if low == "connected notes" {
            connected_lines = s.lines.clone();
        } else if low == "reference sources" {
            reference_lines = s.lines.clone();
        } else if low == "my notes" {
            my_lines = s.lines.clone();
            body_parts.push(format!("## {}\n{}", s.title, s.lines.join("\n")));
        } else {
            body_parts.push(format!("## {}\n{}", s.title, s.lines.join("\n")));
        }
    }

    doc.body = body_parts.join("\n\n").trim().to_string();
    doc.my_notes = my_lines.join("\n").trim().to_string();
    doc.connected = parse_connected(&connected_lines);
    doc.references = parse_references(&reference_lines);

    for m in WIKI_LINK_RE.captures_iter(&doc.body) {
        let target = m[1].trim().to_string();
        let word = m
            .get(2)
            .map(|w| w.as_str().trim().to_string())
            .unwrap_or_else(|| target.clone());
        if !target.is_empty() && target != doc.title {
            doc.linked_in_text.push((target, word));
        }
    }

    doc
}

/// Parse a note file from disk.
pub fn read_note(path: &std::path::Path) -> std::io::Result<NoteDoc> {
    let text = std::fs::read_to_string(path)?;
    let rp = crate::paths::rel(path);
    Ok(parse_note(&text, &rp))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_parse_full() {
        let text = "# Garlic Bread\n\n:::quick-info\nServes: 2\nImage: attachments/g.png\n\n## Group\nA: b\n:::\n\nBody text here.\n\n## My notes\n\n- note\n\n## Connected notes\n\n[[Pasta]]\n\n## Reference sources\n\n- [BBC](https://bbc.example.com) \u{2014} accessed 2026-01-01\n\n:::meta\nCreated: 2026-01-01\nUpdated: 2026-01-02\nPinned: no\n:::\n";
        let doc = parse_note(text, "database/Recipes/Garlic Bread/Garlic Bread.md");
        assert_eq!(doc.title, "Garlic Bread");
        assert!(doc.has_quick_info);
        assert_eq!(doc.quick_info_rows.len(), 3);
        assert_eq!(doc.connected, vec!["Pasta"]);
        assert_eq!(doc.references.len(), 1);
        assert_eq!(doc.meta.get("created").unwrap(), "2026-01-01");
        assert_eq!(doc.my_notes, "- note");
        assert!(doc.body.contains("Body text here."));
    }

    #[test]
    fn test_alias_rows() {
        let rows = parse_quick_info("Common name: Veg Pasta\nServes: 4");
        assert_eq!(qi_aliases(&rows), vec!["Veg Pasta"]);
        assert_eq!(qi_first_image(&rows), None);
    }
}
