//! SecondBrain core engine — the ONE engine shared by the website, the MCP
//! server and the backup tool (Rust rewrite, v4).
//!
//! Modules mirror the original Python engine one-to-one:
//! textutil, paths, tags, parser, store, logger/editlog, indexer, search,
//! healthcheck, images, backup.

pub mod backup;
pub mod editlog;
pub mod healthcheck;
pub mod images;
pub mod indexer;
pub mod logger;
pub mod parser;
pub mod paths;
pub mod search;
pub mod store;
pub mod tags;
pub mod textutil;
pub mod error;

pub use error::SbError;

pub const VERSION: &str = "4.0.0";
