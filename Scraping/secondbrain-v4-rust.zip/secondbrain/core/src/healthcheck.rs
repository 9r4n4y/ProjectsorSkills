//! The health check: fault-isolated checks + one-click fix actions.
//! A faithful port of `core/healthcheck.py`.

use crate::editlog::UndoStep;
use crate::error::{Result, SbError};
use crate::indexer::Index;
use crate::paths;
use crate::store;
use crate::tags as tags_mod;
use regex::Regex;
use serde_json::{json, Value};
use std::collections::BTreeMap;

fn guard<T, F: FnOnce() -> Result<T>>(f: F) -> (Value, Option<String>)
where
    T: serde::Serialize,
{
    match f() {
        Ok(v) => (serde_json::to_value(v).unwrap_or(json!([])), None),
        Err(e) => (json!([]), Some(format!("{e}"))),
    }
}

pub fn health_check(idx: &Index) -> Value {
    let extractor = tags_mod::extract_all_notes_tags().unwrap_or_else(|_| json!({}));

    let mut broken: Vec<Value> = Vec::new();
    for (rp, names) in &idx.broken_links {
        for name in names {
            broken.push(json!({"note": rp, "link": name}));
        }
    }

    let no_tags: Vec<String> = idx
        .files
        .iter()
        .filter(|(_, e)| e.tags.is_empty())
        .map(|(rp, _)| rp.clone())
        .collect();
    let no_connections: Vec<String> = idx
        .files
        .iter()
        .filter(|(rp, e)| {
            idx.graph.get(*rp).map(|g| g.is_empty()).unwrap_or(true)
                && idx.backlinks.get(*rp).map(|b| b.is_empty()).unwrap_or(true)
        })
        .map(|(rp, _)| rp.clone())
        .collect();
    let no_meta: Vec<String> = idx
        .files
        .iter()
        .filter(|(_, e)| e.created.is_empty() || e.updated.is_empty())
        .map(|(rp, _)| rp.clone())
        .collect();

    let stray = stray_attachments();

    let checks: Vec<(&str, Value, Option<String>)> = vec![
        ("broken_links", json!(broken), None),
        ("notes_without_tags", json!(no_tags), None),
        ("notes_without_connections", json!(no_connections), None),
        ("tags_used_once", extractor["used_once"].clone(), None),
        ("near_duplicate_tags", extractor["near_duplicates"].clone(), None),
        ("unapproved_tags", extractor["unapproved"].clone(), None),
        ("tags_missing_from_master", extractor["missing_from_master"].clone(), None),
        ("proposed_tags", extractor["proposed"].clone(), None),
        ("notes_without_dates", json!(no_meta), None),
        ("unreferenced_attachments", json!(stray), None),
        ("structure_problems", json!(paths::check_structure()), None),
    ];

    let fixable: BTreeMap<&str, &str> = BTreeMap::from([
        ("broken_links", "Remove the broken links from the notes."),
        ("near_duplicate_tags", "Merge the pair into one tag."),
        ("unapproved_tags", "Approve the tag into the master list."),
        ("tags_missing_from_master", "Approve the tag into the master list."),
        ("notes_without_dates", "Fill Created/Updated from the file dates."),
        ("unreferenced_attachments", "Delete the stray file (kept in backup history)."),
        ("structure_problems", "Show the path so you can move it manually."),
    ]);

    let mut summary = serde_json::Map::new();
    let mut checks_out = serde_json::Map::new();
    let mut all_ok = true;
    for (k, items, err) in &checks {
        let n: i64 = match err {
            None => items.as_array().map(|a| a.len()).unwrap_or(0) as i64,
            Some(_) => {
                all_ok = false;
                -1
            }
        };
        summary.insert(k.to_string(), json!(n));
        checks_out.insert(
            k.to_string(),
            json!({
                "items": items,
                "error": err,
                "fixable": fixable.contains_key(*k),
            }),
        );
    }
    json!({
        "ok": all_ok,
        "summary": summary,
        "checks": checks_out,
        "fix_hints": fixable,
    })
}

fn stray_attachments() -> Vec<Value> {
    static IMG_RE: once_cell::sync::Lazy<Regex> =
        once_cell::sync::Lazy::new(|| Regex::new(r"\((?:attachments/)?([^)]+)\)").unwrap());
    static DOC_IMG_RE: once_cell::sync::Lazy<Regex> =
        once_cell::sync::Lazy::new(|| Regex::new(r"Image:\s*(\S+)").unwrap());
    let mut out = Vec::new();
    for md in store::list_note_files() {
        let att = md.parent().unwrap().join("attachments");
        if !att.exists() {
            continue;
        }
        let mut used: std::collections::HashSet<String> = std::collections::HashSet::new();
        let text = std::fs::read_to_string(&md).unwrap_or_default();
        for m in IMG_RE.captures_iter(&text) {
            let name = m[1].split('/').next_back().unwrap_or("").to_string();
            used.insert(name);
        }
        if let Some(m) = DOC_IMG_RE.captures(&text) {
            used.insert(m[1].split('/').next_back().unwrap_or("").to_string());
        }
        if let Ok(entries) = std::fs::read_dir(&att) {
            for img in entries.filter_map(|e| e.ok()) {
                let name = img.file_name().to_string_lossy().to_string();
                if img.path().is_file() && !used.contains(&name) {
                    out.push(json!({
                        "note": paths::rel(&md),
                        "file": name,
                        "reason": "image not referenced in the note (kept as backup history)",
                    }));
                }
            }
        }
    }
    out
}

// --------------------------------------------------------------------------
// Fix actions
// --------------------------------------------------------------------------

pub fn health_fix(action: &str, params: &Value, who: &str) -> Result<Value> {
    match action {
        "remove_broken_links" => {
            let note = params["note"].as_str().unwrap_or_default().to_string();
            let p = paths::ROOT.join(&note);
            let text = std::fs::read_to_string(&p)?;
            let old = text.clone();
            let mut text = text;
            let mut links: Vec<String> = params
                .get("links")
                .and_then(|v| v.as_array())
                .map(|a| a.iter().filter_map(|x| x.as_str().map(String::from)).collect())
                .unwrap_or_default();
            if let Some(l) = params.get("link").and_then(|v| v.as_str()) {
                links.push(l.to_string());
            }
            for name in &links {
                let re = Regex::new(&format!(
                    r"\[\[{}(\|[^\]]*)?\]\]",
                    regex::escape(name)
                ))
                .unwrap();
                let replacement = name.replace('$', "$$");
                text = re.replace_all(&text, replacement.as_str()).to_string();
            }
            if text == old {
                return Ok(json!({"ok": true, "message": "Nothing to remove."}));
            }
            store::atomic_write(&p, &text)?;
            crate::editlog::record_note_edit(&note, who, &old, &text)?;
            crate::editlog::record_change(
                who,
                &format!(
                    "Removed broken links in {}",
                    p.file_stem().and_then(|s| s.to_str()).unwrap_or("")
                ),
                vec![UndoStep {
                    op: "write".into(),
                    path: Some(note.clone()),
                    before: Some(old),
                    from: None,
                    to: None,
                }],
            )?;
            Ok(json!({"ok": true}))
        }
        "remove_stray_attachment" => crate::images::delete_image(
            params["note"].as_str().unwrap_or_default(),
            params["file"].as_str().unwrap_or_default(),
            who,
        ),
        "fix_missing_dates" => {
            let note = params["note"].as_str().unwrap_or_default();
            let p = paths::ROOT.join(note);
            let meta = p.metadata().map_err(|e| SbError::Io(e.to_string()))?;
            let created = chrono::DateTime::<chrono::Local>::from(
                meta.created().or_else(|_| meta.modified()).unwrap_or_else(|_| std::time::SystemTime::now()),
            )
            .format("%Y-%m-%d");
            let updated = chrono::DateTime::<chrono::Local>::from(meta.modified().unwrap_or_else(|_| std::time::SystemTime::now()))
                .format("%Y-%m-%d");
            store::set_metadata(note, &json!({"created": created.to_string(), "updated": updated.to_string()}), who)
        }
        "merge_tags" => store::merge_tags(
            params["from"].as_str().unwrap_or_default(),
            params["into"].as_str().unwrap_or_default(),
            who,
            true,
        ),
        "approve_tag" => {
            let mut tags: Vec<String> = params
                .get("tags")
                .and_then(|v| v.as_array())
                .map(|a| a.iter().filter_map(|x| x.as_str().map(String::from)).collect())
                .unwrap_or_default();
            if tags.is_empty() {
                if let Some(t) = params.get("tag").and_then(|v| v.as_str()) {
                    tags.push(t.to_string());
                }
            }
            let added = tags_mod::add_to_master(&tags, who)?;
            Ok(json!({
                "ok": true, "added": added,
                "message": if added.is_empty() { "Already approved.".to_string() } else { format!("{} approved.", added.join(", ")) },
            }))
        }
        other => Err(SbError::Invalid(format!("Unknown health fix action: {other:?}"))),
    }
}
