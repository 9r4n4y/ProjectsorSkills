//! Tags (v1.1 semantics kept): ALL TAGS ARE INDEPENDENT — no hierarchy.
//! A tag is one flat name; matching ignores case. `tags.txt` holds the comma
//! separated tags of one note; `_tags.md` is the master vocabulary.
//! A faithful port of `core/tags.py`.

use crate::error::{Result, SbError};
use crate::paths;
use crate::textutil::{key_of, levenshtein_leq1, normalize};
use once_cell::sync::Lazy;
use regex::Regex;
use serde::Serialize;
use std::collections::HashMap;

pub static TAG_RE: Lazy<Regex> = Lazy::new(|| Regex::new(r"^[A-Za-z0-9_]+(?:-[A-Za-z0-9_]+)*$").unwrap());

pub fn validate_tag(tag: &str) -> Result<String> {
    let tag = tag.trim();
    if tag.is_empty() {
        return Err(SbError::Invalid("Empty tag.".into()));
    }
    if !TAG_RE.is_match(tag) {
        return Err(SbError::Invalid(format!(
            "Tag {tag:?} is not valid. Use letters, digits and underscores; dashes may \
             separate words; spaces are written as underscores; no commas."
        )));
    }
    Ok(tag.to_string())
}

/// Display helper only: the part before the first dash. Carries NO hierarchy
/// meaning — every tag is independent.
pub fn major_of(tag: &str) -> String {
    validate_tag(tag)
        .unwrap_or_else(|_| tag.to_string())
        .split('-')
        .next()
        .unwrap_or(tag)
        .to_string()
}

pub fn norm_tag(tag: &str) -> String {
    tag.trim().to_string()
}

pub fn same_tag(a: &str, b: &str) -> bool {
    key_of(a) == key_of(b)
}

/// Score of a (note tag, query tag) pair: 1.0 on exact (case-insensitive)
/// match, None otherwise. Tags are independent.
pub fn relation(note_tag: &str, query_tag: &str) -> Option<f64> {
    if key_of(note_tag) == key_of(query_tag) {
        Some(1.0)
    } else {
        None
    }
}

// --------------------------------------------------------------------------
// tags.txt
// --------------------------------------------------------------------------

pub fn parse_tags_txt(text: &str) -> Result<Vec<String>> {
    let mut tags: Vec<String> = Vec::new();
    let mut seen: Vec<String> = Vec::new();
    for chunk in text.split([',', '\n']) {
        let t = chunk.trim();
        if t.is_empty() {
            continue;
        }
        let t = validate_tag(t)?;
        let k = key_of(&t);
        if !seen.contains(&k) {
            seen.push(k);
            tags.push(t);
        }
    }
    Ok(tags)
}

pub fn render_tags_txt(tags: &[String]) -> String {
    format!("{}\n", tags.join(", "))
}

// --------------------------------------------------------------------------
// _tags.md master vocabulary
// --------------------------------------------------------------------------

#[derive(Debug, Clone, Serialize)]
pub struct MasterTag {
    pub tag: String,
    pub synonyms: Vec<String>,
    pub major: String,
}

#[derive(Debug, Clone, Default)]
pub struct MasterTags {
    /// key -> {tag, synonyms, major}
    pub approved: HashMap<String, MasterTag>,
    pub proposed: Vec<String>,
    pub general_synonyms: HashMap<String, Vec<String>>,
    /// approved tags in file order (keys)
    pub order: Vec<String>,
}

impl MasterTags {
    pub fn has(&self, tag: &str) -> bool {
        self.approved.contains_key(&key_of(tag))
    }
    pub fn all_tags(&self) -> Vec<String> {
        self.order
            .iter()
            .filter_map(|k| self.approved.get(k))
            .map(|v| v.tag.clone())
            .collect()
    }
    pub fn synonyms_of(&self, tag: &str) -> Vec<String> {
        self.approved
            .get(&key_of(tag))
            .map(|v| v.synonyms.clone())
            .unwrap_or_default()
    }
    pub fn major_of_approved(&self, tag: &str) -> Option<String> {
        self.approved.get(&key_of(tag)).map(|v| v.major.clone())
    }
}

pub fn parse_master(text: &str) -> MasterTags {
    let mut mt = MasterTags::default();
    let mut section = "";
    let mut current_major: Option<String> = None;
    for raw in text.lines() {
        let line = raw.trim();
        if line.is_empty() {
            continue;
        }
        let low = line.to_lowercase();
        if low.starts_with("## ") {
            let title = low[3..].trim();
            section = if title.contains("proposed") {
                "proposed"
            } else if title.contains("synonym") {
                "synonyms"
            } else {
                "approved"
            };
            current_major = None;
            continue;
        }
        match section {
            "approved" => {
                if low.starts_with("### ") {
                    current_major = Some(line[4..].trim().to_string());
                    continue;
                }
                if let Some(entry) = line.strip_prefix("- ") {
                    let entry = entry.trim();
                    let (tag, syn): (String, Vec<String>) = if let Some((t, rest)) =
                        entry.split_once(':')
                    {
                        (
                            t.trim().to_string(),
                            rest.split(',')
                                .map(|s| s.trim().to_string())
                                .filter(|s| !s.is_empty())
                                .collect(),
                        )
                    } else {
                        (entry.to_string(), Vec::new())
                    };
                    if validate_tag(&tag).is_err() {
                        continue;
                    }
                    let k = key_of(&tag);
                    if !mt.approved.contains_key(&k) {
                        mt.approved.insert(
                            k.clone(),
                            MasterTag {
                                tag,
                                synonyms: syn,
                                major: current_major
                                    .clone()
                                    .unwrap_or_else(|| major_of(&k)),
                            },
                        );
                        mt.order.push(k);
                    }
                }
            }
            "proposed" => {
                if let Some(entry) = line.strip_prefix("- ") {
                    let t = entry
                        .trim()
                        .split(':')
                        .next()
                        .unwrap_or("")
                        .trim()
                        .to_string();
                    if validate_tag(&t).is_ok() && !mt.proposed.contains(&t) {
                        mt.proposed.push(t);
                    }
                }
            }
            "synonyms" => {
                if !line.starts_with('#') && !line.starts_with('<') {
                    if let Some((word, syn_part)) = line.split_once(':') {
                        let w = normalize(word);
                        let syns: Vec<String> = syn_part
                            .split(',')
                            .map(|s| normalize(s))
                            .filter(|s| !s.is_empty())
                            .collect();
                        if !w.is_empty() && !syns.is_empty() {
                            let entry = mt.general_synonyms.entry(w).or_default();
                            for s in syns {
                                if !entry.contains(&s) {
                                    entry.push(s);
                                }
                            }
                        }
                    }
                }
            }
            _ => {}
        }
    }
    mt
}

pub fn load_master() -> Result<MasterTags> {
    let text = std::fs::read_to_string(paths::ROOT.join("_tags.md"))?;
    Ok(parse_master(&text))
}

/// Map every approved tag name and every per-tag synonym (normalized) to the
/// canonical tag.
pub fn tag_synonym_to_tag(mt: &MasterTags) -> HashMap<String, String> {
    let mut out: HashMap<String, String> = HashMap::new();
    for v in mt.approved.values() {
        for name in std::iter::once(&v.tag).chain(v.synonyms.iter()) {
            let n = normalize(name);
            out.entry(n.replace(' ', "-")).or_insert_with(|| v.tag.clone());
            out.entry(n.replace(' ', "_")).or_insert_with(|| v.tag.clone());
        }
    }
    out
}

fn atomic_write(path: &std::path::Path, text: &str) -> Result<()> {
    if let Some(parent) = path.parent() {
        std::fs::create_dir_all(parent)?;
    }
    let tmp = path.with_file_name(format!(
        "{}.tmp-write",
        path.file_name().and_then(|n| n.to_str()).unwrap_or("file")
    ));
    std::fs::write(&tmp, text)?;
    std::fs::rename(&tmp, path)?;
    Ok(())
}

/// Add tags to the Approved tags list in `_tags.md` so the global tag index
/// and the tags on notes are ALWAYS in sync. Returns the tags actually added.
pub fn add_to_master(new_tags: &[String], who: &str) -> Result<Vec<String>> {
    let mt = load_master()?;
    let mut new: Vec<String> = Vec::new();
    let mut promoted: Vec<String> = Vec::new();
    for t in new_tags {
        let Ok(t) = validate_tag(t) else { continue };
        let in_proposed = mt.proposed.iter().any(|p| key_of(p) == key_of(&t));
        if !mt.has(&t) && !in_proposed {
            new.push(t);
        } else if in_proposed {
            // a tag sitting in Proposed that the user applies directly is approved
            promoted.push(t);
        }
    }
    if new.is_empty() && promoted.is_empty() {
        return Ok(Vec::new());
    }
    let master_path = paths::ROOT.join("_tags.md");
    let old = std::fs::read_to_string(&master_path)?;
    let mut text = old.clone();
    if !promoted.is_empty() {
        text = drop_proposed(&text, &promoted);
    }
    if !new.is_empty() {
        text = insert_approved(&text, &new);
    }
    if text != old {
        let added_list: Vec<String> = new.iter().chain(promoted.iter()).cloned().collect();
        crate::logger::new_log(
            who,
            "Updated master tag list",
            &format!(
                "- Tags added to Approved tags in `_tags.md`: {}\n- Reason: keep the global tag index in sync with note tags.",
                added_list.join(", ")
            ),
        );
        atomic_write(&master_path, &text)?;
    }
    Ok(new.into_iter().chain(promoted).collect())
}

fn drop_proposed(text: &str, tags: &[String]) -> String {
    let keys: Vec<String> = tags.iter().map(|t| key_of(t)).collect();
    let mut out: Vec<String> = Vec::new();
    let mut in_proposed = false;
    for ln in text.lines() {
        let s = ln.trim();
        if s.to_lowercase().starts_with("## ") {
            in_proposed = s.to_lowercase().contains("proposed");
        }
        if in_proposed && s.starts_with("- ") {
            let cand = s[2..]
                .split(':')
                .next()
                .unwrap_or("")
                .split(',')
                .next()
                .unwrap_or("")
                .trim();
            if keys.contains(&key_of(cand)) {
                continue;
            }
        }
        out.push(ln.to_string());
    }
    out.join("\n")
}

fn insert_approved(text: &str, tags: &[String]) -> String {
    static MAJOR_RE: Lazy<Regex> = Lazy::new(|| Regex::new(r"^###\s+(\S+)").unwrap());
    static APPROVED_RE: Lazy<Regex> =
        Lazy::new(|| Regex::new(r"(?im)^## Approved tags\s*$").unwrap());
    let lines: Vec<String> = text.lines().map(|l| l.to_string()).collect();
    let mut out: Vec<String> = Vec::new();
    let mut inserted: Vec<String> = Vec::new();
    for ln in &lines {
        out.push(ln.clone());
        if let Some(m) = MAJOR_RE.captures(ln.trim()) {
            let major = m[1].to_string();
            for t in tags {
                if !inserted.contains(t)
                    && major_of(t).to_lowercase() == major.to_lowercase()
                {
                    out.push(format!("- {t}"));
                    inserted.push(t.clone());
                }
            }
        }
    }
    let rest: Vec<&String> = tags.iter().filter(|t| !inserted.contains(*t)).collect();
    if !rest.is_empty() {
        let mut final_lines: Vec<String> = Vec::new();
        let mut placed = false;
        for ln in &out {
            final_lines.push(ln.clone());
            if !placed && APPROVED_RE.is_match(ln.trim()) {
                for t in &rest {
                    let major_seen = out.iter().any(|l| {
                        MAJOR_RE
                            .captures(l.trim())
                            .map(|m| m[1].to_lowercase() == major_of(t).to_lowercase())
                            .unwrap_or(false)
                    });
                    if major_seen {
                        final_lines.push(format!("- {t}"));
                    } else {
                        final_lines.push(String::new());
                        final_lines.push(format!("### {}", major_of(t)));
                        final_lines.push(format!("- {t}"));
                    }
                }
                placed = true;
            }
        }
        out = final_lines;
    }
    out.join("\n")
}

/// Scan the whole wiki and build the flat, independent list of every tag in
/// use, with counts; flag unapproved tags and near-duplicates.
pub fn extract_all_notes_tags() -> Result<serde_json::Value> {
    let mt = load_master()?;
    let mut used: HashMap<String, usize> = HashMap::new();
    let mut per_note: HashMap<String, Vec<String>> = HashMap::new();
    let mut tags_files: Vec<std::path::PathBuf> = walkdir::WalkDir::new(paths::DATABASE.as_path())
        .into_iter()
        .filter_map(|e| e.ok())
        .map(|e| e.path().to_path_buf())
        .filter(|p| p.is_file() && p.file_name().map(|n| n == "tags.txt").unwrap_or(false))
        .collect();
    tags_files.sort();
    for tf in &tags_files {
        let raw = std::fs::read_to_string(tf)?;
        let tags = parse_tags_txt(&raw).unwrap_or_default();
        let folder = tf
            .parent()
            .and_then(|p| p.strip_prefix(paths::DATABASE.as_path()).ok())
            .map(|p| p.to_string_lossy().replace('\\', "/"))
            .unwrap_or_default();
        per_note.insert(folder, tags.clone());
        for t in tags {
            *used.entry(t).or_insert(0) += 1;
        }
    }

    let unapproved: Vec<String> = {
        let mut v: Vec<String> = used
            .keys()
            .filter(|t| !mt.has(t))
            .cloned()
            .collect();
        v.sort();
        v
    };

    // Near-duplicates: two different tags within one letter of each other.
    let mut keys: Vec<String> = used.keys().cloned().collect();
    keys.sort();
    let norm_of: HashMap<String, String> = keys
        .iter()
        .map(|t| {
            (
                t.clone(),
                normalize(&t.replace('_', " ").replace('-', " ")).replace(' ', ""),
            )
        })
        .collect();
    let mut near: Vec<serde_json::Value> = Vec::new();
    for i in 0..keys.len() {
        for b in keys.iter().skip(i + 1) {
            let a = &keys[i];
            if key_of(a) == key_of(b) {
                continue;
            }
            if levenshtein_leq1(&norm_of[a], &norm_of[b]) {
                near.push(serde_json::json!({"tags": [a, b]}));
            }
        }
    }

    let missing_master: Vec<String> = {
        let mut v: Vec<String> = used
            .keys()
            .filter(|t| !mt.has(t))
            .cloned()
            .collect();
        v.sort();
        v
    };
    let used_once: Vec<String> = {
        let mut v: Vec<String> = used
            .iter()
            .filter(|(_, c)| **c == 1)
            .map(|(t, _)| t.clone())
            .collect();
        v.sort();
        v
    };
    let mut flat: Vec<String> = used.keys().cloned().collect();
    flat.sort_by(|a, b| key_of(a).cmp(&key_of(b)));
    let approved_unused: Vec<String> = mt
        .all_tags()
        .into_iter()
        .filter(|t| !used.keys().any(|u| key_of(u) == key_of(t)))
        .collect();

    let counts = serde_json::to_value(&used)?;
    let rows: Vec<serde_json::Value> = flat
        .iter()
        .map(|t| serde_json::json!({"tag": t, "count": used[t], "depth": 0}))
        .collect();
    let children: serde_json::Map<String, serde_json::Value> = flat
        .iter()
        .map(|t| {
            (
                t.clone(),
                serde_json::json!({"count": used[t], "children": {}}),
            )
        })
        .collect();

    Ok(serde_json::json!({
        "tags": flat,
        "counts": counts,
        "tree": {"children": children},
        "rows": rows,
        "unapproved": unapproved,
        "near_duplicates": near,
        "missing_from_master": missing_master,
        "used_once": used_once,
        "proposed": mt.proposed,
        "per_note": per_note,
        "approved_unused": approved_unused,
    }))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_validate() {
        assert!(validate_tag("FOOD-pasta_veggie").is_ok());
        assert!(validate_tag("food pasta").is_err());
        assert!(validate_tag("FOOD,pasta").is_err());
        assert_eq!(major_of("FOOD-pasta-x"), "FOOD");
    }

    #[test]
    fn test_parse_tags_txt() {
        let tags = parse_tags_txt("A-b, c, A-B\nd,").unwrap();
        assert_eq!(tags, vec!["A-b", "c", "d"]);
    }

    #[test]
    fn test_parse_master() {
        let mt = parse_master(
            "# Master\n\n## Approved tags\n\n### FOOD\n- FOOD-pasta: pasta, noodles\n- FOOD-soup\n\n## Synonyms\n\nquick: fast, rapid\n\n## Proposed tags\n\n- FOOD-curry\n",
        );
        assert!(mt.has("food-pasta"));
        assert!(!mt.has("food-curry"));
        assert_eq!(mt.proposed, vec!["FOOD-curry"]);
        assert_eq!(
            mt.general_synonyms.get("quick").unwrap(),
            &vec!["fast".to_string(), "rapid".to_string()]
        );
        assert_eq!(mt.synonyms_of("FOOD-pasta"), vec!["pasta", "noodles"]);
    }

    #[test]
    fn test_independent_relation() {
        assert!(relation("FOOD-pasta-vegetarian", "FOOD-pasta-vegetarian").is_some());
        assert!(relation("FOOD-pasta-vegetarian", "FOOD-pasta").is_none());
    }
}

/// Insert approved tags under their major-tag heading in Approved tags
/// (used by the approve flow after a tag leaves Proposed).
pub fn reinsert_approved_into(text: &str, tags: &[String]) -> String {
    static MAJOR_RE: Lazy<Regex> = Lazy::new(|| Regex::new(r"^###\s+(\S+)").unwrap());
    static APPROVED_RE: Lazy<Regex> =
        Lazy::new(|| Regex::new(r"(?im)^## Approved tags\s*$").unwrap());
    let mut out: Vec<String> = Vec::new();
    let mut inserted: Vec<String> = Vec::new();
    for ln in text.lines() {
        out.push(ln.to_string());
        if let Some(m) = MAJOR_RE.captures(ln.trim()) {
            let current_major = m[1].to_string();
            for t in tags {
                if t.split('-').next().unwrap_or("").to_lowercase() == current_major.to_lowercase()
                    && !inserted.contains(t)
                {
                    out.push(format!("- {t}"));
                    inserted.push(t.clone());
                }
            }
        }
    }
    let rest: Vec<&String> = tags.iter().filter(|t| !inserted.contains(*t)).collect();
    if !rest.is_empty() {
        let mut final_lines: Vec<String> = Vec::new();
        let mut done = false;
        for ln in &out {
            final_lines.push(ln.clone());
            if !done && APPROVED_RE.is_match(ln.trim()) {
                let major = rest[0].split('-').next().unwrap_or("").to_string();
                final_lines.push(String::new());
                final_lines.push(format!("### {major}"));
                for t in &rest {
                    final_lines.push(format!("- {t}"));
                }
                done = true;
            }
        }
        out = final_lines;
    }
    out.join("\n")
}
