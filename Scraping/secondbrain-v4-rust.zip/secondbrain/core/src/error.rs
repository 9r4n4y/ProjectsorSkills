//! Engine error type. Every module reports failures through `SbError` so the
//! website, the MCP server and the backup tool share one error surface.

use std::fmt;

#[derive(Debug, Clone)]
pub enum SbError {
    NotFound(String),
    Exists(String),
    Invalid(String),
    Permission(String),
    NeedsApproval { question: String },
    Io(String),
    Json(String),
}

impl fmt::Display for SbError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            SbError::NotFound(m) => write!(f, "FileNotFoundError: {m}"),
            SbError::Exists(m) => write!(f, "FileExistsError: {m}"),
            SbError::Invalid(m) => write!(f, "ValueError: {m}"),
            SbError::Permission(m) => write!(f, "PermissionError: {m}"),
            SbError::NeedsApproval { question } => {
                write!(f, "NeedsApproval: {question}")
            }
            SbError::Io(m) => write!(f, "IOError: {m}"),
            SbError::Json(m) => write!(f, "JSONError: {m}"),
        }
    }
}

impl std::error::Error for SbError {}

impl From<std::io::Error> for SbError {
    fn from(e: std::io::Error) -> Self {
        if e.kind() == std::io::ErrorKind::NotFound {
            SbError::NotFound(e.to_string())
        } else {
            SbError::Io(e.to_string())
        }
    }
}

impl From<image::ImageError> for SbError {
    fn from(e: image::ImageError) -> Self {
        SbError::Invalid(format!("Image error: {e}"))
    }
}

impl From<serde_json::Error> for SbError {
    fn from(e: serde_json::Error) -> Self {
        SbError::Json(e.to_string())
    }
}

pub type Result<T> = std::result::Result<T, SbError>;
