# StructureOFnotes — the exact rulebook for every note (v4)

This is the rulebook for how every note in SecondBrain is written. It is for
you and for the AI. The parser implements it, the health check checks it, and
the AI reads it before writing anything. **Every Markdown example on this
page is verified by the automated test suite** (`cargo test` — the test
`structure_examples_are_valid` extracts every fenced example marked
`verify=…` from this file and runs it through the real engine: the parser,
the tag rules and the search pipeline). If an example is here, it is tested.

---

## 1. The anatomy of a note

Every note is a **folder** named exactly like the note, containing exactly
three things:

```
database/<Subject>/.../<Note Name>/
├── <Note Name>.md    the note file (this page describes it)
├── tags.txt          the note's tags, comma separated (section 5)
└── attachments/      images only
```

The `.md` file has five parts, in this order:

```
1. # The Note Title              (an H1 heading, the same words as the folder)
2. :::quick-info ... :::         (optional quick info card — section 3)
3. The main text                 (any Markdown — section 4)
4. ## My notes                   (optional, append-only — section 6)
5. ## Connected notes            (section 7)
   ## Reference sources          (section 8)
   :::meta ... :::               (metadata — section 9)
```

A complete minimal note (verified: `verify=note-minimal`):

```markdown
# Garlic Bread

Crispy, buttery, ready in 15 minutes.

## My notes

- 2026-10-20: made with the pasta dinner — worked well.

## Connected notes

[[Quick Vegetable Pasta for Weeknights]]

## Reference sources

:::meta
Created: 2026-10-15
Updated: 2026-10-31
Pinned: no
:::
```

## 2. File and folder naming rules

- A note folder and its `.md` file share the note's exact name; note names
  are unique across the whole wiki, even when capital letters are ignored.
- Names may contain letters, digits, spaces, accents, dashes and
  underscores. They may **not** contain `\ / : * ? " < > |` or control
  characters, and never end with a space or a dot.
- Subject folders follow the same rules; a subject folder never contains
  loose files (only note folders, sub-subjects and an optional
  `_subject.md`).
- Attachments live only in a note's `attachments/` folder, only as images
  (`.png .jpg .jpeg .gif .webp .svg .bmp`).
- Everything is UTF-8 with LF line endings; all paths inside the project
  are relative.

## 3. The quick info card (`:::quick-info`)

The small fact card at the top of a note. It lives inside the note file, so
it moves, searches and backs up with the note. A full example (verified:
`verify=note-quickinfo` — this text parses, all rows are found, the alias
ranks the note like a title match, and the image row is found):

```markdown
# Quick Vegetable Pasta for Weeknights

:::quick-info
Common name: Vegetable Pasta
Serves: 4
Often paired with: [[Garlic Bread]]
Image: attachments/pasta-1.png

## Dietary notes
Vegetarian: Yes
Vegan: No (parmesan)
:::
```

Rules:

- One line per fact: `Label: value`. The first colon separates them; the
  label is short (up to ~60 characters).
- Values may hold **bold**, *italics*, web links `[text](url)` and wiki
  links `[[Note Name]]`.
- A line starting with `## ` begins a named group of rows (`## Dietary
  notes` above); groups render as titled sections of the card.
- A line starting with `Image:` adds a photo from `attachments/`; several
  `Image:` lines are allowed and shown in order.
- Quick info is searchable: **labels count like headings, values count like
  body text**.
- Labels `Common name`, `Also known as`, `Aliases`, `AKA` are treated as
  **title aliases** in search.

## 4. The main text — every Markdown form the app supports

What you type in edit mode is exactly what is saved in the file. Every form
below is verified by the suite (`verify=markdown-showcase` — it parses, the
renderer produces every listed element, and the extracted links/tasks/images
match what is written):

````markdown
## Headings

## Section, ### Sub-section — up to ###### (the note title is the # H1)

## Text styles

**bold**, *italic*, _italic too_, ~~strikethrough~~, `inline code`,
and $e = mc^2$ inline math with $$\int_0^1 x\,dx$$ display math.

## Lists

- a bullet item
- another one
  - nested by two-space indentation
1. a numbered item
2. the second step

## Tasks

- [ ] an open task
- [x] a done task (tappable in the rendered note — the tick saves to the file)

## Tables

| Ingredient | Amount |
| --- | --- |
| Pasta | 350 g |
| Garlic | 3 cloves |

## Code

```python
def hello():
    print("world")
```

## Quotes

> Quoted text. Consecutive quote lines form one quote.

## Images

![The pan, mid-cook](attachments/pasta-2.png)

![Plated, ready|50](attachments/pasta-3.png)

Three or more consecutive images arrange into a grid; each image can be
moved (left / right / up / down) and resized (25% → 50% → 75% → full) from
the rendered note — the controls rewrite exactly these lines. The `|50`
suffix means 50% width.

## Links

- A web link: [BBC Good Food](https://www.bbcgoodfood.com/one-pot-pasta) —
  a bare domain like example.com gets https:// added automatically.
- A wiki link: [[Garlic Bread]] or with a word: [[Garlic Bread|the side dish]].
  Missing targets render dashed and are flagged by the health check.

## Footnotes

A fact needs a source[^1].

[^1]: The note text of the footnote, listed at the end.

## Horizontal rules

---
````

Not rendered (kept as plain text, faithfully preserved): raw HTML and
custom directives other than the `:::quick-info`, `:::meta` and `:::undo`
blocks the system itself writes.

**Links on words.** Selecting a word and choosing *link* offers a note in
the wiki (`[[File Name|word]]`) or a web address (`[word](https://…)`);
clicking the word opens the target. You can change which words carry the
link, change the target, or remove the link and keep the words — from the
note page or with the `edit_links` tool.

## 5. Tags (`tags.txt`)

- One `tags.txt` per note, next to the `.md` file. Entries separated by
  commas. **Verified** (`verify=tags`): the file below parses to exactly
  the four tags listed, in order.

```
COOKING-weeknight, FOOD-pasta-vegetarian, METHOD-stovetop-one_pot, INGREDIENT-garlic
```

- **All tags are independent** (v1.1 rule, kept in v4): a tag is one flat
  name. Dashes and underscores are ordinary characters —
  `FOOD-pasta-vegetarian` has **no** relationship to `FOOD-pasta` or
  `FOOD`; nothing is implied, nothing propagates. Matching ignores case.
- A space inside a tag name is written as an underscore
  (`HOME_REPAIR-wall_painting`); commas never appear inside a tag.
- **Always in sync:** a tag used on any note (website or AI) is added to
  the Approved tags of `_tags.md` at the same moment.
- `_tags.md` is the master vocabulary: `## Approved tags` (grouped under
  `### MAJOR` headings for readability only, each line optionally
  `TAG: synonym, synonym`), a general `## Synonyms` map (`quick: fast,
  rapid, speedy`), and `## Proposed tags` where the AI proposes new tags.

## 6. `My notes` — append-only

- `## My notes` holds your own observations, dated lines work well:

  ```
  ## My notes

  - 2026-10-20: made it with frozen peas — works well.
  ```

- **Nothing in the system ever overwrites or rewrites this section.** The
  only change anyone (including the AI, through `append_my_notes`) may make
  is adding lines at the end. The engine refuses any edit that alters or
  removes existing lines (verified by the suite).

## 7. Connected notes

- Written in `## Connected notes` as one `[[File Name]]` per line — file
  names, not paths, so notes can move between folders without breaking
  links (verified: `verify=note-minimal` above).

  ```
  ## Connected notes

  [[Garlic Bread]]
  [[Lentil Soup for Cold Evenings]]
  ```

- **v4: connected notes are the map.** The old graph view is gone. On the
  note page, the Connected notes panel lists every connection: *Connects
  to* (outgoing) and *Referenced by* (incoming, generated automatically).
  These lists are how you see everything a note touches — use them as
  references while reading.
- Links written inside the text (`[[File Name|word]]`) appear in the panel
  marked *linked in text* and can be unlinked there.
- Adding a connection uses type-ahead of existing file names: a connection
  to a note that does not exist cannot be created.
- Renaming or moving a note rewrites every link to it everywhere.
- Connected notes affect search (neighbor and backlink signals); connected
  sets can be searched as a group with `include_connected`.

## 8. Reference sources

- Written in `## Reference sources`, one per line. **Verified**
  (`verify=references`): the line below parses to
  title `BBC Good Food: one-pot pasta technique`, the URL, and the
  accessed date `2026-10-15`.

  ```
  - [BBC Good Food: one-pot pasta technique](https://www.bbcgoodfood.com/one-pot-pasta) — accessed 2026-10-15
  ```

- `[Title](url)` plus the date accessed after a dash (`— accessed
  YYYY-MM-DD` or `- accessed YYYY-MM-DD` — both parse).
- URLs you add are stored with `https://` even if you wrote a bare domain.
- Reference sources are **proof of where a fact came from**. They never mix
  with Connected notes (which point to notes in this wiki) and they do not
  affect search ranking.

## 9. Metadata (`:::meta`)

Metadata lives at the bottom of the note file in a simple block
(verified: `verify=meta` — the block parses to Created/Updated/Pinned):

```
:::meta
Created: 2026-10-15
Updated: 2026-10-31
Pinned: yes
:::
```

- There is **no Status field** (verification was removed in v1.1); if an
  older note still carries one, the engine ignores it and the next metadata
  edit removes it.
- `Created` and `Updated` are `YYYY-MM-DD`; the engine touches `Updated` on
  every saved change.
- `Pinned: yes` shows the note on the home page.
- Other `Key: value` lines are preserved and editable.

## 10. What the app reads vs. plain text

Parsed and understood by the tools: the H1 title; `:::quick-info` (rows,
groups, images); headings; task list states; wiki links (section and
in-text); web links and reference dates; images under `attachments/`;
`:::meta`; `tags.txt`. Everything else — prose, tables, code, math,
quotes — is rendered faithfully and stored byte-for-byte; the parser never
reformats the parts it does not understand.

## 11. Subject files (`_subject.md`)

Optional, one per subject folder:

```
Purpose: what this subject is for
Template: Tasting Note        (optional: a note name whose body pre-fills new notes here)
Sensitivity: private          (optional: private = hidden, locked, excluded from the index)
Inherits: sensitivity         (optional: fields taken from the parent subject when unset)
```

## 12. The inbox

Raw, unsorted notes (`.md` or `.txt`, flat, no sub-folders) waiting for the
AI librarian. Anything goes in — fragments, clippings, reminders. The
librarian files them into the deepest matching subject, asks before
creating folders, and never deletes the original until you say so.
