#!/usr/bin/env bash
# SecondBrain v4 — build everything: engine + website + mcp + backup, tests.
set -euo pipefail
cd "$(dirname "$0")"
cargo build --release
cargo test
echo
echo "Binaries in target/release/:"
echo "  secondbrain-website   the local website"
echo "  secondbrain-mcp       the AI tool server (MCP, stdio)"
echo "  secondbrain-backup    the backup / restore / verify CLI"
