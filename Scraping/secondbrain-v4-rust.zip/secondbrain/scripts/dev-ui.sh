#!/usr/bin/env bash
# Rebuild the UI sources (website/app) into website/static/.
set -euo pipefail
cd "$(dirname "$0")/../website/app"
npm install
npm run build
rm -rf ../static/assets
mkdir -p ../static
cp -r dist/* ../static/
echo "UI deployed to website/static/."
