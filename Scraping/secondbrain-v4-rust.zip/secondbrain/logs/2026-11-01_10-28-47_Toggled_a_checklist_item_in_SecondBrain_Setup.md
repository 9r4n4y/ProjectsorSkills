# Toggled a checklist item in SecondBrain Setup

- **When:** 2026-11-01 10:28:47
- **Who:** user
- **Title:** Toggled a checklist item in SecondBrain Setup

## What was done

- File: `database/Projects/SecondBrain Setup/SecondBrain Setup.md`
- Task #4 is now done.

## How to undo

:::undo
{
 "title": "Toggle task in SecondBrain Setup",
 "steps": [
  {
   "op": "write",
   "path": "database/Projects/SecondBrain Setup/SecondBrain Setup.md",
   "before": "# SecondBrain Setup\n\n:::quick-info\nCommon name: SecondBrain project setup\nState: in progress\nStarted: 2026-10-12\n:::\n\nThe working plan for building and keeping this SecondBrain wiki running:\nplain Markdown files, one folder per note, tags in the dash notation, and\nan AI librarian with auditable rules.\n\n## Remaining steps\n\n- [x] Decide the folder structure and the allowed file list\n- [x] Write the tag notation down in `_tags.md`\n- [x] Set up the local website with the ranking search\n- [x] Connect the AI librarian through the MCP server\n- [ ] Move the first hundred notes in from the old wiki\n- [ ] Set up the nightly backup to the external drive\n\n## Design decisions\n\nThe search engine has no semantic model: it ranks notes from tags, keywords,\nsynonyms and links only. Tags boost more than keywords, and the coverage\nfactor makes a note that matches every part of a query beat a note that\nmatches one part many times. The full text stays in ordinary files, so any\neditor can open it and no app can hold it hostage.\n\nThe housekeeping rhythm is written in the README: the backup tool keeps a\nsecond copy up to date, the health check catches broken links and stray\ntags, and every AI change lands in `logs/` where it can be undone.\n\n## Connected notes\n\n[[Garden Plan 2026]]\n\n## Reference sources\n\n- [Markdown guide](https://www.markdownguide.org/) — accessed 2026-10-12\n\n:::meta\nStatus: verified\nCreated: 2026-10-12\nUpdated: 2026-10-30\nPinned: yes\n:::\n"
  }
 ]
}
:::

---

Log files are never edited or deleted after they are written.
