# Garden Plan 2026

:::quick-info
Common name: Garden plan
State: planning
Beds: 4
:::

What goes where this year. The basil that keeps ending up in the pasta
finally gets its own pot by the kitchen door, and the tomatoes move to the
sunny bed so they stop sulking.

## Beds

| Bed | Position | Planned for |
| --- | --- | --- |
| 1 | south wall | tomatoes |
| 2 | centre | beans and salad |
| 3 | under the window | herbs: basil, parsley |
| 4 | shade | nothing this year, rest |

## Calendar

- March: start tomato seedlings indoors.
- April: bed 2 digging and compost; salad sowing.
- May: plant the basil out after the last frost; tomatoes to bed 1.
- August: expected first ripe tomatoes, ideally before the holiday.

## My notes

- Last year's basil went woody by August — pinch flowers off earlier.

## Connected notes

[[SecondBrain Setup]]

## Reference sources

:::meta
Status: unverified
Created: 2026-10-22
Updated: 2026-10-22
:::
