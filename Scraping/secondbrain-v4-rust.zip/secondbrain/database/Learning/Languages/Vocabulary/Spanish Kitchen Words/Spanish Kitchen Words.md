# Spanish Kitchen Words

:::quick-info
Common name: Spanish kitchen vocabulary
Level: A1–A2
Review date: 2026-11-07
:::

Vocabulary list for the kitchen, collected while cooking. Linked to the
recipes these words came from, so each review swims through the dishes too.

## Words

| Spanish | English |
| --- | --- |
| la olla | pot |
| la sartén | frying pan |
| el ajo | garlic |
| los lentejas | lentils |
| la pasta | pasta |
| el caldo | broth, stock |
| la cebolla | onion |
| el tomate | tomato |
| hervir | to boil |
| freír | to fry |

## Notes on usage

- *Hervir* is used for the pasta water: *hierve el agua*.
- In Spain *ajo* appears in almost every recipe — see [[Garlic Bread]] and
  the vegetable pasta, where the garlic is always sliced, never crushed.

## My notes

- Ten words per review session works better than twenty.

## Connected notes

[[Quick Vegetable Pasta for Weeknights]]
[[Lentil Soup for Cold Evenings]]

## Reference sources

- [WordReference: olla](https://www.wordreference.com/es/en/translation.asp?espen=olla) — accessed 2026-10-20

:::meta
Status: unverified
Created: 2026-10-20
Updated: 2026-10-25
:::
