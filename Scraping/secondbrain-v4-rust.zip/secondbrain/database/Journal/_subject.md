Purpose: private reflections and daily pages
Sensitivity: private
Inherits: sensitivity
