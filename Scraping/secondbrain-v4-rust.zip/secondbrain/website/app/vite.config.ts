import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import path from "path";

export default defineConfig({
  plugins: [react()], server: { proxy: { "/api": "http://localhost:8877", "/files": "http://localhost:8877", "/thumb": "http://localhost:8877" } },
  resolve: { alias: { "@": path.resolve(__dirname, "./src") } },
  build: { outDir: "dist", chunkSizeWarningLimit: 1200 },
});
