#!/usr/bin/env bash
# Rebuild the compiled single-page app into website/static/.
# Needs Node 18+. Run from anywhere: website/app/deploy.sh
set -euo pipefail
cd "$(dirname "$0")"
npm install
npm run build
rm -rf ../static/assets
mkdir -p ../static
cp -r dist/* ../static/
echo "Deployed to website/static/."
