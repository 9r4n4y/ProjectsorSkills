/* SecondBrain v4 logo — a modern geometric brain: two hemispheres drawn as
   smooth lobes with circuit nodes and connecting synapses, gradient stroke,
   on a rounded squircle. Replaces the old flat brain mark. */

export function BrainLogo({ size = 34, className = "" }: { size?: number; className?: string }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 64 64"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      aria-label="SecondBrain"
      role="img"
    >
      <defs>
        <linearGradient id="sbg-brain" x1="8" y1="6" x2="58" y2="60" gradientUnits="userSpaceOnUse">
          <stop offset="0" stopColor="hsl(var(--primary))" />
          <stop offset="1" stopColor="hsl(var(--hero-from))" />
        </linearGradient>
        <linearGradient id="sbg-plate" x1="0" y1="0" x2="64" y2="64" gradientUnits="userSpaceOnUse">
          <stop offset="0" stopColor="hsl(var(--hero-from))" />
          <stop offset="1" stopColor="hsl(var(--background))" />
        </linearGradient>
      </defs>

      {/* rounded squircle plate */}
      <rect x="2" y="2" width="60" height="60" rx="17" fill="url(#sbg-plate)" />
      <rect x="2" y="2" width="60" height="60" rx="17" stroke="url(#sbg-brain)" strokeOpacity="0.55" strokeWidth="1.6" />

      {/* left hemisphere */}
      <path
        d="M30 15c-3.2-2.6-8-2.4-10.7.6-2.5 2.7-2.6 6.3-1 9.1-3.2 1.1-5.5 4.1-5.3 7.7.2 3.4 2.6 6.1 5.7 7-1.3 2.9-.7 6.4 1.7 8.6 2.6 2.4 6.3 2.6 9.1.9V15z"
        stroke="url(#sbg-brain)"
        strokeWidth="2.4"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      {/* right hemisphere (mirrored) */}
      <path
        d="M34 15c3.2-2.6 8-2.4 10.7.6 2.5 2.7 2.6 6.3 1 9.1 3.2 1.1 5.5 4.1 5.3 7.7-.2 3.4-2.6 6.1-5.7 7 1.3 2.9.7 6.4-1.7 8.6-2.6 2.4-6.3 2.6-9.1.9V15z"
        stroke="url(#sbg-brain)"
        strokeWidth="2.4"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      {/* central fissure */}
      <path d="M32 13v38" stroke="url(#sbg-brain)" strokeWidth="2.4" strokeLinecap="round" />

      {/* synapse nodes */}
      <circle cx="24.5" cy="24" r="2.1" fill="hsl(var(--primary))" />
      <circle cx="24.5" cy="38" r="2.1" fill="hsl(var(--primary))" />
      <circle cx="39.5" cy="24" r="2.1" fill="hsl(var(--primary))" />
      <circle cx="39.5" cy="38" r="2.1" fill="hsl(var(--primary))" />

      {/* synapse links */}
      <path d="M24.5 24c2.5 1.2 4.5 2.4 7.5 2.4s5-1.2 7.5-2.4M24.5 38c2.5-1.2 4.5-2.4 7.5-2.4s5 1.2 7.5 2.4"
        stroke="url(#sbg-brain)" strokeWidth="1.4" strokeLinecap="round" strokeOpacity="0.75" />
      <path d="M24.5 26v10M39.5 26v10" stroke="url(#sbg-brain)" strokeWidth="1.4" strokeLinecap="round" strokeOpacity="0.55" />
    </svg>
  );
}

export function LogoMark({ size = 30 }: { size?: number }) {
  return <BrainLogo size={size} />;
}
