import { X } from "lucide-react";
import { Badge } from "@/components/ui/primitives";

export function TagChip({
  tag, count, onRemove, onClick,
}: {
  tag: string;
  count?: number;
  onRemove?: () => void;
  onClick?: () => void;
}) {
  return (
    <Badge variant="default" className="gap-1 group">
      <button
        onClick={onClick}
        className="max-w-52 truncate text-left"
        title={onClick ? "Show the notes with this tag" : tag}
      >
        {tag}
        {count !== undefined && <span className="ml-1 opacity-60">{count}</span>}
      </button>
      {onRemove && (
        <button onClick={onRemove} className="opacity-50 transition-opacity hover:opacity-100" title="Remove">
          <X className="h-3 w-3" />
        </button>
      )}
    </Badge>
  );
}
