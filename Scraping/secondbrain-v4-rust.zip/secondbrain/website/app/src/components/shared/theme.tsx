/* Theme context: 12 themes, 6 dark (grey default) + 6 light (never white).
   The theme is remembered in localStorage and applied to <html data-theme>. */

import React, { createContext, useContext, useEffect, useState } from "react";

export const THEMES: { id: string; label: string; mode: "dark" | "light"; swatch: string }[] = [
  { id: "grey", label: "Grey (default)", mode: "dark", swatch: "#1c1e26" },
  { id: "blue", label: "Ocean Blue", mode: "dark", swatch: "#0b1626" },
  { id: "green", label: "Forest", mode: "dark", swatch: "#0f1c17" },
  { id: "plum", label: "Plum", mode: "dark", swatch: "#1b1422" },
  { id: "crimson", label: "Crimson", mode: "dark", swatch: "#221016" },
  { id: "amber", label: "Amber", mode: "dark", swatch: "#211a10" },
  { id: "sky", label: "Light Sky", mode: "light", swatch: "#a9c8e3" },
  { id: "sage", label: "Light Sage", mode: "light", swatch: "#a9c9b4" },
  { id: "rose", label: "Light Rose", mode: "light", swatch: "#e0a9ba" },
  { id: "sand", label: "Light Sand", mode: "light", swatch: "#ddc5a0" },
  { id: "lavender", label: "Light Lavender", mode: "light", swatch: "#c3b1dd" },
  { id: "paper", label: "Light Paper", mode: "light", swatch: "#c3c6d2" },
];

interface ThemeCtx {
  theme: string;
  setTheme: (t: string) => void;
}

const Ctx = createContext<ThemeCtx>({ theme: "grey", setTheme: () => {} });

export function ThemeProvider({ children }: { children: React.ReactNode }) {
  const [theme, setThemeState] = useState<string>(() => {
    try {
      return localStorage.getItem("sb-theme") || "grey";
    } catch {
      return "grey";
    }
  });

  useEffect(() => {
    const meta = THEMES.find((t) => t.id === theme) ?? THEMES[0];
    document.documentElement.setAttribute("data-theme", meta.id);
    document.documentElement.setAttribute("data-mode", meta.mode);
    try {
      localStorage.setItem("sb-theme", meta.id);
    } catch {}
  }, [theme]);

  return <Ctx.Provider value={{ theme, setTheme: setThemeState }}>{children}</Ctx.Provider>;
}

export const useTheme = () => useContext(Ctx);
