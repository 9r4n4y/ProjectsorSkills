/* SuggestInput — every typing bar in the app (tags, connected notes,
   folders, search filters) uses it: a preview list of every existing note /
   tag that matches what you type appears right below the input, with
   note counts. */

import React, { useEffect, useRef, useState } from "react";
import { Input } from "@/components/ui/primitives";
import { api } from "@/lib/api";
import type { Suggestion } from "@/lib/types";
import { cn } from "@/lib/utils";

export function SuggestInput({
  value,
  onChange,
  onSubmit,
  kind = "all",
  placeholder,
  className,
  autoFocus,
  onKeyDown,
  validate,
}: {
  value: string;
  onChange?: (v: string) => void;
  onSubmit?: (v: string) => void;
  kind?: "all" | "tag" | "folder";
  placeholder?: string;
  className?: string;
  autoFocus?: boolean;
  onKeyDown?: (e: React.KeyboardEvent<HTMLInputElement>) => void;
  /** optional validator called when a suggestion is picked or Enter pressed */
  validate?: (v: string) => string;
}) {
  const [suggestions, setSuggestions] = useState<Suggestion[]>([]);
  const [open, setOpen] = useState(false);
  const [active, setActive] = useState(-1);
  const boxRef = useRef<HTMLDivElement>(null);
  const debounce = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    if (debounce.current) clearTimeout(debounce.current);
    debounce.current = setTimeout(() => {
      api
        .suggest(value, kind)
        .then((r) => setSuggestions(r.suggestions))
        .catch(() => setSuggestions([]));
    }, 140);
    return () => {
      if (debounce.current) clearTimeout(debounce.current);
    };
  }, [value, kind]);

  useEffect(() => {
    const onDoc = (e: MouseEvent) => {
      if (boxRef.current && !boxRef.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener("mousedown", onDoc);
    return () => document.removeEventListener("mousedown", onDoc);
  }, []);

  const pick = (s: Suggestion) => {
    onChange?.(s.name);
    setOpen(false);
    setActive(-1);
  };

  const handleKey = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (open && suggestions.length > 0) {
      if (e.key === "ArrowDown") {
        e.preventDefault();
        setActive((a) => (a + 1) % suggestions.length);
        return;
      }
      if (e.key === "ArrowUp") {
        e.preventDefault();
        setActive((a) => (a <= 0 ? suggestions.length - 1 : a - 1));
        return;
      }
      if (e.key === "Enter" && active >= 0) {
        e.preventDefault();
        pick(suggestions[active]);
        return;
      }
      if (e.key === "Escape") {
        setOpen(false);
        return;
      }
    }
    if (e.key === "Enter" && onSubmit) {
      e.preventDefault();
      const v = validate ? validate(value) : value;
      if (v !== value) onChange?.(v);
      onSubmit(v);
    }
    onKeyDown?.(e);
  };

  return (
    <div className={cn("relative", className)} ref={boxRef}>
      <Input
        value={value}
        placeholder={placeholder}
        autoFocus={autoFocus}
        onChange={(e) => {
          onChange?.(e.target.value);
          setOpen(true);
          setActive(-1);
        }}
        onFocus={() => setOpen(true)}
        onKeyDown={handleKey}
      />
      {open && suggestions.length > 0 && (
        <div className="absolute z-50 mt-1 w-full overflow-hidden rounded-lg border bg-popover shadow-lg animate-in fade-in">
          <div className="max-h-56 overflow-y-auto p-1">
            {suggestions.map((s, i) => (
              <button
                key={s.type + s.name}
                type="button"
                className={cn(
                  "flex w-full items-center justify-between gap-2 rounded-md px-2.5 py-1.5 text-left text-sm",
                  i === active ? "bg-accent text-accent-foreground" : "hover:bg-accent"
                )}
                onMouseDown={(e) => {
                  e.preventDefault();
                  pick(s);
                }}
              >
                <span className="truncate">
                  <span className={cn("mr-1.5 rounded px-1 py-0.5 text-[10px] uppercase tracking-wide",
                    s.type === "tag" ? "bg-primary/15 text-primary" : "bg-secondary text-secondary-foreground")}>
                    {s.type}
                  </span>
                  {s.name}
                </span>
                <span className="shrink-0 text-xs text-muted-foreground">
                  {s.type === "tag" ? `${s.count} note${s.count === 1 ? "" : "s"}` : ""}
                </span>
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
