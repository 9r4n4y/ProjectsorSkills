/* FindBar — Ctrl+F find-in-note. STICKY AT THE TOP (never scrolls away),
   works in both preview and edit mode: highlights every hit in the rendered
   note, n/total counter, ↑/↓ to jump; in edit mode selects the match in the
   textarea and scrolls it into view. Esc closes. */

import React, { useEffect, useRef } from "react";
import { ArrowDown, ArrowUp, X } from "lucide-react";
import { Input } from "@/components/ui/primitives";
import { Kbd } from "./kbd";

export function FindBar({
  query, setQuery, count, active, onPrev, onNext, onClose, inputRef,
}: {
  query: string;
  setQuery: (q: string) => void;
  count: number;
  active: number;
  onPrev: () => void;
  onNext: () => void;
  onClose: () => void;
  inputRef: React.RefObject<HTMLInputElement>;
}) {
  useEffect(() => {
    inputRef.current?.focus();
    inputRef.current?.select();
  }, []);

  return (
    <div className="sb-sticky flex items-center gap-2 rounded-b-lg border border-t-0 border-border bg-background/95 px-3 py-2 shadow-sm">
      <Input
        ref={inputRef}
        value={query}
        placeholder="Find in note…"
        className="h-8 w-56"
        onChange={(e) => setQuery(e.target.value)}
        onKeyDown={(e) => {
          if (e.key === "Enter") { e.preventDefault(); e.shiftKey ? onPrev() : onNext(); }
          if (e.key === "Escape") onClose();
        }}
      />
      <span className="min-w-16 text-center text-xs text-muted-foreground">
        {query ? `${count === 0 ? 0 : active + 1} / ${count}` : "0 / 0"}
      </span>
      <button onClick={onPrev} className="rounded-md p-1.5 hover:bg-accent" title="Previous (Shift+Enter)"><ArrowUp className="h-4 w-4" /></button>
      <button onClick={onNext} className="rounded-md p-1.5 hover:bg-accent" title="Next (Enter)"><ArrowDown className="h-4 w-4" /></button>
      <span className="ml-2 hidden text-[11px] text-muted-foreground sm:inline"><Kbd>Enter</Kbd> next · <Kbd>Esc</Kbd> close</span>
      <button onClick={onClose} className="ml-auto rounded-md p-1.5 hover:bg-accent" title="Close"><X className="h-4 w-4" /></button>
    </div>
  );
}
