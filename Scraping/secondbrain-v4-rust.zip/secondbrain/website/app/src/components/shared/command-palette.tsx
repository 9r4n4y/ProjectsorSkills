/* Command palette — Ctrl/⌘+K (or /) jumps to any note or page. */

import React, { useEffect, useState } from "react";
import { Command } from "cmdk";
import { useNavigate } from "react-router-dom";
import { Dialog, DialogContent, DialogTitle } from "@/components/ui/overlays";
import { api, noteHref } from "@/lib/api";
import type { NoteRef } from "@/lib/types";
import { BookOpen, FileText, Home, Search, Tag, FolderTree, ShieldCheck, DatabaseBackup, ScrollText, Settings } from "lucide-react";

const PAGES = [
  { name: "Home", to: "/", icon: Home },
  { name: "Search", to: "/search", icon: Search },
  { name: "Files", to: "/files", icon: FolderTree },
  { name: "Tags", to: "/tags", icon: Tag },
  { name: "Health", to: "/health", icon: ShieldCheck },
  { name: "Logs", to: "/logs", icon: ScrollText },
  { name: "Backup", to: "/backup", icon: DatabaseBackup },
  { name: "Settings", to: "/settings", icon: Settings },
];

export function CommandPalette({ open, setOpen }: { open: boolean; setOpen: (v: boolean) => void }) {
  const [notes, setNotes] = useState<NoteRef[]>([]);
  const [q, setQ] = useState("");
  const nav = useNavigate();

  useEffect(() => {
    if (open) {
      setQ("");
      api.search({ q: "", page_size: 100 }).then((r) =>
        setNotes(r.results.map((x) => ({ path: x.path, title: x.title, folder: x.folder })))
      ).catch(() => {});
    }
  }, [open]);

  const go = (to: string) => {
    setOpen(false);
    nav(to);
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogContent className="overflow-hidden p-0 sm:max-w-xl" title="Command palette">
        <DialogTitle className="sr-only">Command palette</DialogTitle>
        <Command className="w-full" shouldFilter>
          <Command.Input
            value={q}
            onValueChange={setQ}
            autoFocus
            placeholder="Jump to a note or page…"
            className="w-full border-b bg-transparent px-4 py-3.5 text-sm outline-none placeholder:text-muted-foreground"
          />
          <Command.List className="max-h-80 overflow-y-auto p-2">
            <Command.Empty className="py-6 text-center text-sm text-muted-foreground">No matches.</Command.Empty>
            <Command.Group heading="Pages" className="[&_[cmdk-group-heading]]:px-2 [&_[cmdk-group-heading]]:py-1.5 [&_[cmdk-group-heading]]:text-xs [&_[cmdk-group-heading]]:text-muted-foreground">
              {PAGES.map((p) => (
                <Command.Item key={p.to} value={`page ${p.name}`} onSelect={() => go(p.to)} className="flex cursor-pointer items-center gap-2 rounded-md px-2 py-1.5 text-sm data-[selected=true]:bg-accent">
                  <p.icon className="h-4 w-4 text-muted-foreground" /> {p.name}
                </Command.Item>
              ))}
            </Command.Group>
            <Command.Group heading="Notes" className="[&_[cmdk-group-heading]]:px-2 [&_[cmdk-group-heading]]:py-1.5 [&_[cmdk-group-heading]]:text-xs [&_[cmdk-group-heading]]:text-muted-foreground">
              {notes.map((n) => (
                <Command.Item
                  key={n.path}
                  value={`note ${n.title} ${n.folder}`}
                  onSelect={() => go(noteHref(n.path))}
                  className="flex cursor-pointer items-center gap-2 rounded-md px-2 py-1.5 text-sm data-[selected=true]:bg-accent"
                >
                  <FileText className="h-4 w-4 shrink-0 text-muted-foreground" />
                  <span className="truncate">{n.title}</span>
                  <span className="ml-auto shrink-0 text-xs text-muted-foreground">{n.folder}</span>
                </Command.Item>
              ))}
            </Command.Group>
          </Command.List>
        </Command>
      </DialogContent>
    </Dialog>
  );
}

export { BookOpen };
