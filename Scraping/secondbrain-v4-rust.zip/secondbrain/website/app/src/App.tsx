import React, { useEffect, useState } from "react";
import { Routes, Route, NavLink, Link, useLocation, useNavigate } from "react-router-dom";
import {
  Home as HomeIcon, Search, FolderTree, Tag, ShieldCheck, ScrollText,
  DatabaseBackup, Settings, ChevronLeft, Menu, Palette, Command as CommandIcon, Check,
} from "lucide-react";
import { toast } from "sonner";
import { BrainLogo } from "@/components/shared/logo";
import { useTheme, THEMES } from "@/components/shared/theme";
import { CommandPalette } from "@/components/shared/command-palette";
import { Button, Badge, Separator } from "@/components/ui/primitives";
import {
  DropdownMenu, DropdownMenuTrigger, DropdownMenuContent,
  DropdownMenuItem, DropdownMenuLabel, DropdownMenuSeparator, Popover, PopoverTrigger, PopoverContent,
} from "@/components/ui/overlays";
import { Kbd } from "@/components/shared/kbd";
import { cn } from "@/lib/utils";

import Home from "@/views/home";
import Note from "@/views/note";
import SearchView from "@/views/search";
import Tags from "@/views/tags";
import Files from "@/views/files";
import Health from "@/views/health";
import Logs from "@/views/logs";
import Backup from "@/views/backup";
import SettingsView from "@/views/settings";

const NAV = [
  { to: "/", label: "Home", icon: HomeIcon },
  { to: "/search", label: "Search", icon: Search },
  { to: "/files", label: "Files", icon: FolderTree },
  { to: "/tags", label: "Tags", icon: Tag },
  { to: "/health", label: "Health", icon: ShieldCheck },
  { to: "/logs", label: "Logs", icon: ScrollText },
  { to: "/backup", label: "Backup", icon: DatabaseBackup },
  { to: "/settings", label: "Settings", icon: Settings },
];

export default function App() {
  const [paletteOpen, setPaletteOpen] = useState(false);
  const [navOpen, setNavOpen] = useState(false);
  const loc = useLocation();
  const nav = useNavigate();
  const { theme, setTheme } = useTheme();

  useEffect(() => setNavOpen(false), [loc.pathname, loc.search]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const tag = (e.target as HTMLElement)?.tagName;
      const typing = tag === "INPUT" || tag === "TEXTAREA" || (e.target as HTMLElement)?.isContentEditable;
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "k") {
        e.preventDefault();
        setPaletteOpen(true);
      } else if (e.key === "/" && !typing) {
        e.preventDefault();
        nav("/search");
      } else if (e.key === "ArrowLeft" && e.altKey) {
        nav(-1);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [nav]);

  return (
    <div className="flex min-h-screen">
      {/* sidebar */}
      <aside
        className={cn(
          "fixed inset-y-0 left-0 z-40 flex w-60 flex-col border-r bg-card/80 backdrop-blur transition-transform lg:sticky lg:top-0 lg:h-screen lg:translate-x-0",
          navOpen ? "translate-x-0" : "-translate-x-full"
        )}
      >
        <Link to="/" className="flex items-center gap-2.5 px-4 py-4">
          <BrainLogo size={34} />
          <div>
            <div className="text-[15px] font-bold leading-none">SecondBrain</div>
            <div className="mt-1 text-[10px] uppercase tracking-widest text-muted-foreground">v4 · Rust engine</div>
          </div>
        </Link>
        <Separator />
        <nav className="flex-1 space-y-0.5 overflow-y-auto p-2">
          {NAV.map((n) => (
            <NavLink
              key={n.to}
              to={n.to}
              end={n.to === "/"}
              className={({ isActive }) =>
                cn(
                  "flex items-center gap-2.5 rounded-lg px-3 py-2 text-sm transition-colors",
                  isActive ? "bg-primary/12 font-medium text-primary" : "text-muted-foreground hover:bg-accent hover:text-foreground"
                )
              }
            >
              <n.icon className="h-4 w-4" />
              {n.label}
            </NavLink>
          ))}
        </nav>
        <div className="border-t p-3 text-xs text-muted-foreground">
          <button
            className="mb-1 flex w-full items-center justify-between rounded-md px-2 py-1.5 hover:bg-accent"
            onClick={() => setPaletteOpen(true)}
          >
            <span className="flex items-center gap-2"><CommandIcon className="h-3.5 w-3.5" /> Command</span>
            <Kbd>Ctrl K</Kbd>
          </button>
          <div className="px-2">Everything stays on this computer.</div>
        </div>
      </aside>
      {navOpen && <div className="fixed inset-0 z-30 bg-black/50 lg:hidden" onClick={() => setNavOpen(false)} />}

      {/* main */}
      <div className="flex min-w-0 flex-1 flex-col">
        <header className="sb-sticky z-20 flex items-center gap-2 border-b px-3 py-2 sm:px-5">
          <Button variant="ghost" size="icon" className="lg:hidden" onClick={() => setNavOpen(true)}>
            <Menu className="h-5 w-5" />
          </Button>
          <Button variant="ghost" size="sm" className="gap-1" onClick={() => nav(-1)} title="Back (Alt+←)">
            <ChevronLeft className="h-4 w-4" /> Back
          </Button>
          <div className="ml-auto flex items-center gap-1.5">
            <Button variant="outline" size="sm" onClick={() => setPaletteOpen(true)} className="hidden sm:inline-flex">
              <Search className="h-3.5 w-3.5" /> Jump to…
              <Kbd className="ml-1">Ctrl K</Kbd>
            </Button>
            {/* theme picker */}
            <Popover>
              <PopoverTrigger asChild>
                <Button variant="ghost" size="icon" title="Theme"><Palette className="h-4.5 w-4.5" /></Button>
              </PopoverTrigger>
              <PopoverContent align="end" className="w-64">
                <div className="mb-2 text-xs font-semibold uppercase tracking-wide text-muted-foreground">Dark</div>
                <div className="grid grid-cols-2 gap-1.5">
                  {THEMES.filter((t) => t.mode === "dark").map((t) => (
                    <ThemeButton key={t.id} t={t} active={theme === t.id} onClick={() => setTheme(t.id)} />
                  ))}
                </div>
                <div className="mb-2 mt-3 text-xs font-semibold uppercase tracking-wide text-muted-foreground">Light (never white)</div>
                <div className="grid grid-cols-2 gap-1.5">
                  {THEMES.filter((t) => t.mode === "light").map((t) => (
                    <ThemeButton key={t.id} t={t} active={theme === t.id} onClick={() => setTheme(t.id)} />
                  ))}
                </div>
              </PopoverContent>
            </Popover>
          </div>
        </header>
        <main className="mx-auto w-full max-w-6xl flex-1 px-3 py-5 sm:px-6">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/note" element={<Note />} />
            <Route path="/search" element={<SearchView />} />
            <Route path="/tags" element={<Tags />} />
            <Route path="/files" element={<Files />} />
            <Route path="/health" element={<Health />} />
            <Route path="/logs" element={<Logs />} />
            <Route path="/backup" element={<Backup />} />
            <Route path="/settings" element={<SettingsView />} />
            <Route path="*" element={<Home />} />
          </Routes>
        </main>
      </div>
      <CommandPalette open={paletteOpen} setOpen={setPaletteOpen} />
    </div>
  );
}

function ThemeButton({ t, active, onClick }: { t: (typeof THEMES)[number]; active: boolean; onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className={cn(
        "flex items-center gap-2 rounded-lg border px-2 py-1.5 text-left text-xs transition-colors hover:bg-accent",
        active && "border-primary ring-1 ring-primary"
      )}
    >
      <span className="h-4 w-4 shrink-0 rounded-full border border-black/20" style={{ background: t.swatch }} />
      <span className="truncate">{t.label}</span>
      {active && <Check className="ml-auto h-3.5 w-3.5 text-primary" />}
    </button>
  );
}
