import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

/** The app never asks the user to type https:// — a bare domain gets it. */
export function normalizeUrl(url: string): string {
  const u = (url || "").trim();
  if (!u) return u;
  if (/^[a-zA-Z][a-zA-Z0-9+.-]*:\/\//.test(u)) return u;
  if (u.startsWith("#") || u.startsWith("/")) return u;
  return "https://" + u;
}

export function todayISO(): string {
  return new Date().toISOString().slice(0, 10);
}
