/* Shared API types (subset the UI relies on). */

export interface AppState {
  notes: number;
  recent: NoteRef[];
  pinned: NoteRef[];
  saved_searches: { name: string; params: Record<string, unknown> }[];
  themes: string[];
  port: number;
  bind: string;
}
export interface NoteRef {
  path: string;
  title: string;
  folder: string;
  updated?: string;
}
export interface Suggestion {
  type: "tag" | "folder";
  name: string;
  path?: string;
  count: number;
  starts: boolean;
}
export interface SearchSignal {
  weight: number;
  raw: number;
  scaled: number;
  points: number;
  applied: boolean;
}
export interface SearchResult {
  path: string;
  title: string;
  folder: string;
  tags: string[];
  status: string;
  updated: string;
  pinned: boolean;
  score: number;
  coverage: number;
  direct: boolean;
  neighbor_kind: string | null;
  connected_to: string | null;
  matched_groups: number;
  matched_tag_pairs: { query_tag: string; note_tag: string; relation: number }[];
  rank_reason: string;
  breakdown: Record<string, SearchSignal>;
  snippet: string;
}
export interface SearchResponse {
  total: number;
  offset: number;
  results: SearchResult[];
  notice: string | null;
  removed_by: Record<string, number>;
  fallback_used: boolean;
  query: { groups: string[]; query_tags: string[]; phrases: string[] };
  elapsed_ms: number;
}
export interface Reference {
  title: string;
  url: string;
  accessed: string;
}
export interface QuickInfoRow {
  label: string;
  value: string;
  group: string | null;
}
export interface Task {
  index: number;
  done: boolean;
  text: string;
  line: number;
}
export interface NoteView {
  path: string;
  folder: string;
  title: string;
  raw: string;
  hash: string;
  quick_info_raw: string | null;
  quick_info_rows: QuickInfoRow[];
  headings: [number, string][];
  body: string;
  connected: string[];
  linked_in_text: { target: string; word: string }[];
  references: Reference[];
  meta: Record<string, string>;
  my_notes: string;
  incoming: string[];
  tags: string[];
  tasks: Task[];
  attachments: string[];
  pinned: boolean;
}
export interface FoldersData {
  tree: FolderNode;
  subjects: { path: string; name: string; private: boolean }[];
}
export interface FolderNode {
  name: string;
  path: string;
  notes: number;
  private: boolean;
  children: FolderNode[];
}
export interface TagsData {
  tags: string[];
  rows: { tag: string; count: number; depth: number }[];
  counts: Record<string, number>;
  per_note: Record<string, string[]>;
  unapproved: string[];
  proposed: string[];
  near_duplicates: { tags: string[] }[];
  approved_unused: string[];
  majors: string[];
  approved: string[];
  tag_synonyms: Record<string, string[]>;
  general_synonyms: Record<string, string[]>;
}
export interface HealthCheck {
  items: unknown[];
  error: string | null;
  fixable: boolean;
}
export interface HealthData {
  ok: boolean;
  summary: Record<string, number>;
  checks: Record<string, HealthCheck>;
  fix_hints: Record<string, string>;
}
export interface LogRow {
  file: string;
  date: string;
  who: string;
  title: string;
}
export interface EditHistoryRow {
  when: string;
  note: string;
  who: string;
  note_path?: string;
  lines_added?: string;
  lines_removed?: string;
}
export interface JournalRow {
  id: string;
  when: string;
  who: string;
  title: string;
  steps: number;
}
