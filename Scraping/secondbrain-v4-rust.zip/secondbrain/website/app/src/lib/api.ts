/* Typed fetch wrapper over the Rust backend (website server). */

export class ApiError extends Error {
  status: number;
  constructor(message: string, status: number) {
    super(message);
    this.status = status;
  }
}

async function handle<T>(r: Response): Promise<T> {
  let j: any = null;
  try { j = await r.json(); } catch { /* empty body */ }
  if (!r.ok || (j && j.error)) {
    throw new ApiError((j && j.error) || r.statusText || "Request failed", r.status);
  }
  return j as T;
}

export async function apiGet<T>(url: string): Promise<T> {
  const r = await fetch(url);
  return handle<T>(r);
}

export async function apiPost<T>(url: string, body?: unknown): Promise<T> {
  const r = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body || {}),
  });
  return handle<T>(r);
}

import type {
  AppState, SearchResponse, Suggestion, TagsData, FoldersData,
  NoteView, HealthData, LogRow, EditHistoryRow, JournalRow,
} from "./types";

const qs = (obj: Record<string, string | number | boolean | undefined>) => {
  const p = new URLSearchParams();
  for (const [k, v] of Object.entries(obj)) {
    if (v !== undefined && v !== "" && v !== false) p.set(k, String(v));
  }
  return p.toString();
};

export const api = {
  state: () => apiGet<AppState>("/api/state"),

  search: (o: Record<string, string | number | boolean | undefined>) =>
    apiGet<SearchResponse>("/api/search?" + qs(o)),

  suggest: (q: string, type: "all" | "tag" | "folder" = "all") =>
    apiGet<{ suggestions: Suggestion[] }>("/api/suggest?" + qs({ q, type })),

  tags: () => apiGet<TagsData>("/api/tags"),
  tagNotes: (tag: string) =>
    apiGet<{ tag: string; notes: { path: string; title: string; folder: string; tags: string[] }[] }>(
      "/api/tag/notes?" + qs({ tag })),

  folders: () => apiGet<FoldersData>("/api/folders"),

  note: (path: string) => apiGet<NoteView>("/api/note?" + qs({ path })),
  exportUrl: (path: string) => "/api/export?" + qs({ path }),

  health: () => apiGet<HealthData>("/api/health"),
  healthFix: (action: string, params: Record<string, unknown>) =>
    apiPost<{ message?: string }>("/api/health/fix", { action, params }),

  logs: (limit = 100) => apiGet<{ logs: LogRow[] }>("/api/logs?" + qs({ limit })),
  log: (name: string) => apiGet<{ name: string; text: string }>("/api/log?" + qs({ name })),
  createLog: (who: string, title: string, details: string) =>
    apiPost<{ ok: boolean; file: string }>("/api/log/create", { who, title, details }),
  editHistory: (limit = 100) =>
    apiGet<{ history: EditHistoryRow[] }>("/api/edit_history?" + qs({ limit })),
  journal: () => apiGet<{ changes: JournalRow[] }>("/api/journal"),
  undo: (change: string) => apiPost<{ log: string }>("/api/undo", { change }),
  masterTags: () => apiGet<{ text: string }>("/api/master_tags"),

  createNote: (folder: string, name: string, tags: string[], text?: string) =>
    apiPost<{ path?: string; master_updated?: string[] }>("/api/note/create", { folder, name, tags, text }),

  saveNote: (path: string, text: string, base_hash: string, force = false) =>
    apiPost<{ hash: string; conflict?: boolean; message?: string; current_hash?: string }>(
      "/api/note/save", { path, text, base_hash, force }),

  moveNote: (path: string, folder?: string, name?: string) =>
    apiPost<{ path: string }>("/api/note/move", { path, folder, name }),

  togglePin: (path: string) => apiPost<Record<string, unknown>>("/api/pin", { path }),
  toggleTask: (path: string, index: number, text?: string) =>
    apiPost<{ text: string; hash?: string }>("/api/note/toggle_task", { path, index, ...(text !== undefined ? { text } : {}) }),

  editTags: (path: string, add?: string[], remove?: string[]) =>
    apiPost<Record<string, unknown>>("/api/tags/edit", { path, add, remove }),

  addConnection: (path: string, add: string[]) =>
    apiPost<Record<string, unknown>>("/api/connections", { path, add }),
  removeConnection: (path: string, remove: string[]) =>
    apiPost<Record<string, unknown>>("/api/connections", { path, remove }),
  unlinkWord: (path: string, word: string) =>
    apiPost<Record<string, unknown>>("/api/links", { path, word, target: null }),

  addReference: (path: string, add: { title: string; url: string }) =>
    apiPost<Record<string, unknown>>("/api/references", { path, add }),
  removeReference: (path: string, remove_url: string) =>
    apiPost<Record<string, unknown>>("/api/references", { path, remove_url }),

  setMetadata: (path: string, meta: Record<string, string>) =>
    apiPost<Record<string, unknown>>("/api/metadata", { path, meta }),
  setQuickInfo: (path: string, text: string) =>
    apiPost<Record<string, unknown>>("/api/quick_info", { path, text }),

  folderCreate: (parent: string, name: string, subject_md?: string) =>
    apiPost<Record<string, unknown>>("/api/folder/create", { parent, name, subject_md }),
  folderRename: (path: string, name: string) =>
    apiPost<Record<string, unknown>>("/api/folder/rename", { path, name }),
  folderMove: (path: string, parent: string) =>
    apiPost<Record<string, unknown>>("/api/folder/move", { path, parent }),
  folderDelete: (path: string) =>
    apiPost<Record<string, unknown>>("/api/folder/delete", { path }),

  tagRename: (from: string, to: string, run = false) =>
    apiPost<any>("/api/tags/rename", { from, to, run }),
  tagMerge: (from: string, into: string, run = false) =>
    apiPost<any>("/api/tags/merge", { from, into, run }),
  tagRemove: (tag: string, run = false) =>
    apiPost<any>("/api/tags/remove", { tag, run }),
  tagsMasterSave: (text: string) => apiPost("/api/tags/master", { text }),
  tagsMasterAdd: (tags: string[]) => apiPost<{ added: string[] }>("/api/tags/master/add", { tags }),

  imageAdd: (path: string, filename: string, data_base64: string) =>
    apiPost<{ file: string }>("/api/image/add", { path, filename, data_base64 }),
  imageDelete: (path: string, filename: string) =>
    apiPost<{ deleted?: boolean; warning?: boolean; message?: string }>("/api/image/delete", { path, filename }),

  savedSearchSave: (name: string, params: Record<string, unknown>) =>
    apiPost("/api/saved_searches/save", { name, params }),
  savedSearchDelete: (name: string) =>
    apiPost("/api/saved_searches/delete", { name }),

  settings: () => apiGet<{ settings: Record<string, any> }>("/api/settings"),
  updateSettings: (settings: Record<string, unknown>) =>
    apiPost<{ settings: Record<string, any> }>("/api/settings", { settings }),

  rebuildIndex: () => apiPost<{ ok: boolean; notes: number }>("/api/index/rebuild"),
};

export const noteHref = (path: string) =>
  "/note?path=" + encodeURIComponent(path);

export const thumbUrl = (rel: string, w = 480) =>
  "/thumb?" + qs({ path: rel, w });
