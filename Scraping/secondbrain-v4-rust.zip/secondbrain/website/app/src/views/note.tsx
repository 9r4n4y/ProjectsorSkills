import React, { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Link, useSearchParams } from "react-router-dom";
import {
  Pencil, Eye, Save, Pin, PinOff, Printer, Copy, Download, Search as SearchIcon,
  Bold, Italic, Heading2, List, ListOrdered, CheckSquare, Quote, Code,
  Table2, Link2, ImagePlus, Minus, Sigma, X, ArrowUpRight, PanelLeftClose,
  ChevronRight, FileText, Repeat2, Tag as TagIcon, Info, Trash2, Maximize2,
} from "lucide-react";
import { toast } from "sonner";
import { api, noteHref, thumbUrl } from "@/lib/api";
import type { NoteView } from "@/lib/types";
import { Button, Card, CardContent, Input, Label, Badge, Skeleton, Separator, Textarea } from "@/components/ui/primitives";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription,
  AlertDialog, AlertDialogContent, AlertDialogTitle, AlertDialogDescription, AlertDialogCancel, AlertDialogAction,
} from "@/components/ui/overlays";
import { MarkdownBody, resetFindCounter, lastFindCount } from "@/lib/markdown";
import { FindBar } from "@/components/shared/find-bar";
import { SuggestInput } from "@/components/shared/suggest-input";
import { TagChip } from "@/components/shared/tag-badge";
import { normalizeUrl, cn } from "@/lib/utils";

/* The note page. v4 changes live here:
   - Connected notes are a clean LINKED LIST (no graph view anywhere):
     “Connects to” and “Referenced by”, used as references.
   - The Markdown toolbar is STICKY AT THE TOP of the editor and the find
     bar is STICKY in both preview and edit mode — neither scrolls away.
   - The Table tool opens a real grid editor; the Link tool links words to
     notes or sites; images render as a grid with move + size controls. */

export default function Note() {
  const [sp] = useSearchParams();
  const path = sp.get("path") ?? "";
  const [note, setNote] = useState<NoteView | null>(null);
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState("");
  const [hash, setHash] = useState("");
  const [saving, setSaving] = useState(false);
  const [findOpen, setFindOpen] = useState(false);
  const [findQuery, setFindQuery] = useState("");
  const [findCount, setFindCount] = useState(0);
  const [findActive, setFindActive] = useState(0);
  const [viewer, setViewer] = useState<{ src: string; alt: string } | null>(null);
  const [wikiTitles, setWikiTitles] = useState<Set<string>>(new Set());
  const scrollRef = useRef<HTMLDivElement>(null);
  const findInputRef = useRef<HTMLInputElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);

  const reload = useCallback(() => {
    api
      .note(path)
      .then((n) => {
        setNote(n);
        setHash(n.hash);
        setDraft(n.raw);
        setEditing(false);
      })
      .catch((e) => toast.error(e.message));
  }, [path]);

  useEffect(() => {
    if (path) reload();
  }, [path, reload]);

  useEffect(() => {
    api
      .search({ q: "", page_size: 200 })
      .then((r) => setWikiTitles(new Set(r.results.map((x) => x.title.toLowerCase()))))
      .catch(() => {});
  }, []);

  // `e` toggles edit, Ctrl+F / Ctrl+S shortcuts
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const tag = (e.target as HTMLElement)?.tagName;
      const typing = tag === "INPUT" || tag === "TEXTAREA";
      if (!typing && e.key === "e" && note) {
        setEditing(true);
      }
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "f") {
        e.preventDefault();
        setFindOpen(true);
        setTimeout(() => findInputRef.current?.focus(), 30);
      }
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "s") {
        e.preventDefault();
        if (editing) save();
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [note, editing, draft, hash]);

  // count find hits in the rendered preview
  useEffect(() => {
    if (!findOpen || editing) return;
    const t = setTimeout(() => {
      const marks = contentRef.current?.querySelectorAll("mark.sb-find") ?? [];
      setFindCount(marks.length);
      setFindActive((a) => (marks.length ? a % marks.length : 0));
    }, 120);
    return () => clearTimeout(t);
  }, [findQuery, findOpen, editing, note, draft]);

  const jumpToFind = (dir: 1 | -1) => {
    if (editing) {
      editFind(dir);
      return;
    }
    setFindActive((a) => {
      const n = findCount || 0;
      if (!n) return 0;
      const next = (a + dir + n) % n;
      const el = contentRef.current?.querySelector(`mark.sb-find[data-find-hit="${next}"]`);
      el?.scrollIntoView({ behavior: "smooth", block: "center" });
      return next;
    });
  };

  const editFind = (dir: 1 | -1) => {
    const ta = textareaRef.current;
    if (!ta || !findQuery) return;
    const text = ta.value.toLowerCase();
    const q = findQuery.toLowerCase();
    let idx = dir === 1 ? text.indexOf(q, ta.selectionEnd) : text.lastIndexOf(q, Math.max(0, ta.selectionStart - 1));
    if (idx === -1 && dir === 1) idx = text.indexOf(q);
    if (idx === -1) return;
    ta.focus();
    ta.setSelectionRange(idx, idx + q.length);
    const line = text.slice(0, idx).split("\n").length;
    ta.scrollTop = Math.max(0, (line - 6) * 22);
    setFindCount(text.split(q).length - 1);
  };

  if (!note) return <Skeleton className="h-96" />;

  const folderCrumbs = note.folder ? note.folder.split("/") : [];

  const save = (force = false) => {
    setSaving(true);
    api
      .saveNote(note.path, draft, hash, force)
      .then((r: any) => {
        if (r.conflict) {
          if (confirm(r.message + "\n\nOK = overwrite (force), Cancel = reload")) {
            save(true);
          } else {
            reload();
          }
          return;
        }
        toast.success("Saved");
        setHash(r.hash);
        setEditing(false);
        reload();
      })
      .catch((e) => toast.error(e.message))
      .finally(() => setSaving(false));
  };

  const toggleTask = (index: number) => {
    if (editing) {
      // flip inside the unsaved draft preview text
      api
        .toggleTask(note.path, index, draft)
        .then((r: any) => setDraft(r.text))
        .catch((e) => toast.error(e.message));
    } else {
      api
        .toggleTask(note.path, index)
        .then(() => reload())
        .catch((e) => toast.error(e.message));
    }
  };

  const imageOp = (groupIdx: number, imgIdx: number, op: "left" | "right" | "up" | "down" | "size") => {
    const lines = note.raw.split("\n");
    const imgIdxs = lines.map((l, i) => (/^!\[([^\]]*)\]\(([^)\s]+)\)\s*$/.test(l.trim()) ? i : -1)).filter((i) => i >= 0);
    if (imgIdxs.length === 0) return;
    // group consecutive image lines
    const groups: number[][] = [[imgIdxs[0]]];
    for (let k = 1; k < imgIdxs.length; k++) {
      const g = groups[groups.length - 1];
      const prev = g[g.length - 1];
      // consecutive within a group if no non-blank, non-image lines between
      const between = lines.slice(prev + 1, imgIdxs[k]);
      if (between.every((l) => l.trim() === "")) g.push(imgIdxs[k]);
      else groups.push([imgIdxs[k]]);
    }
    const group = groups[Math.min(groupIdx, groups.length - 1)];
    if (!group || group.length === 0) return;
    const cols = Math.min(3, Math.max(1, group.length));
    const pos = Math.min(imgIdx, group.length - 1);
    let swapWith = -1;
    if (op === "left" && pos > 0) swapWith = group[pos - 1];
    else if (op === "right" && pos < group.length - 1) swapWith = group[pos + 1];
    else if (op === "up" && pos - cols >= 0) swapWith = group[pos - cols];
    else if (op === "down" && pos + cols < group.length) swapWith = group[pos + cols];
    else if (op === "size") {
      const line = lines[group[pos]];
      const m = /^!\[([^\]]*)\]\(([^)\s]+)\)\s*$/.exec(line.trim())!;
      const wm = /^(.*)\|(\d{1,3})%?$/.exec(m[1]);
      const sizes = ["25", "50", "75", ""];
      const cur = wm ? wm[2] : "";
      const next = sizes[(sizes.indexOf(cur) + 1) % sizes.length];
      const alt = wm ? wm[1] : m[1];
      lines[group[pos]] = next
        ? `![${alt}|${next}](${m[2]})`
        : `![${alt}](${m[2]})`;
      applyRawLines(lines);
      return;
    }
    if (swapWith === -1) return;
    const a = group[pos];
    const b = swapWith;
    [lines[a], lines[b]] = [lines[b], lines[a]];
    applyRawLines(lines);
  };

  const applyRawLines = (lines: string[]) => {
    const newText = lines.join("\n");
    api
      .saveNote(note.path, newText, hash)
      .then((r: any) => {
        if (r.conflict) { toast.error(r.message); return; }
        setHash(r.hash);
        reload();
      })
      .catch((e) => toast.error(e.message));
  };

  const openImage = (src: string, alt: string) => setViewer({ src, alt });

  return (
    <div className="space-y-4">
      {/* breadcrumbs */}
      <div className="flex flex-wrap items-center gap-1 text-sm text-muted-foreground">
        <Link className="hover:text-primary" to="/files">database</Link>
        {folderCrumbs.map((c, i) => (
          <React.Fragment key={i}>
            <ChevronRight className="h-3.5 w-3.5" />
            <Link className="hover:text-primary" to={`/files?folder=${encodeURIComponent(folderCrumbs.slice(0, i + 1).join("/"))}`}>{c}</Link>
          </React.Fragment>
        ))}
        <ChevronRight className="h-3.5 w-3.5" />
        <span className="text-foreground">{note.title}</span>
      </div>

      {/* title row */}
      <div className="flex flex-wrap items-center gap-2">
        <h1 className="text-2xl font-bold">{note.title}</h1>
        {note.pinned && <Badge><Pin className="mr-1 h-3 w-3" /> pinned</Badge>}
        <div className="ml-auto flex flex-wrap gap-1.5">
          <Button variant={editing ? "default" : "outline"} size="sm" onClick={() => setEditing(!editing)}>
            {editing ? <><Eye className="h-3.5 w-3.5" /> Preview</> : <><Pencil className="h-3.5 w-3.5" /> Edit</>}
          </Button>
          {!editing && (
            <Button variant="outline" size="sm" onClick={() => { setFindOpen(true); setTimeout(() => findInputRef.current?.focus(), 30); }}>
              <SearchIcon className="h-3.5 w-3.5" /> Find
            </Button>
          )}
          <Button variant="outline" size="sm" onClick={() =>
            api.togglePin(note.path).then(() => reload()).catch((e) => toast.error(e.message))
          }>
            {note.pinned ? <PinOff className="h-3.5 w-3.5" /> : <Pin className="h-3.5 w-3.5" />}
          </Button>
          <Button variant="outline" size="sm" onClick={() => {
            navigator.clipboard.writeText(note.raw).then(() => toast.success("Note copied to the clipboard"));
          }}>
            <Copy className="h-3.5 w-3.5" />
          </Button>
          <Button variant="outline" size="sm" asChild>
            <a href={api.exportUrl(note.path)} download><Download className="h-3.5 w-3.5" /></a>
          </Button>
          <Button variant="outline" size="sm" className="no-print" onClick={() => window.print()}>
            <Printer className="h-3.5 w-3.5" />
          </Button>
        </div>
      </div>

      {/* quick info card */}
      {note.quick_info_rows.length > 0 && !editing && (
        <Card>
          <CardContent className="p-4">
            <div className="mb-2 flex items-center gap-2 text-xs font-semibold uppercase tracking-wide text-muted-foreground">
              <Info className="h-3.5 w-3.5" /> Quick info
            </div>
            <QuickInfoTable rows={note.quick_info_rows} notePath={note.path} />
          </CardContent>
        </Card>
      )}

      {/* find bar — sticky in both modes */}
      {findOpen && (
        <FindBar
          query={findQuery}
          setQuery={(q) => { setFindQuery(q); setFindActive(0); }}
          count={findCount}
          active={findActive}
          onPrev={() => jumpToFind(-1)}
          onNext={() => jumpToFind(1)}
          onClose={() => { setFindOpen(false); setFindQuery(""); }}
          inputRef={findInputRef}
        />
      )}

      {/* ============ EDIT MODE ============ */}
      {editing ? (
        <div>
          <EditorToolbar draft={draft} setDraft={setDraft} textareaRef={textareaRef} note={note} onSaved={reload} />
          <Textarea
            ref={textareaRef as any}
            value={draft}
            onChange={(e) => setDraft(e.target.value)}
            spellCheck={false}
            className="min-h-[60vh] w-full rounded-none rounded-b-lg border-t-0 font-mono text-[13px] leading-6"
            placeholder="Markdown…"
          />
          <div className="mt-3 flex flex-wrap items-center gap-2">
            <Button variant="hero" onClick={() => save()} disabled={saving}>
              <Save className="h-4 w-4" /> Save (Ctrl+S)
            </Button>
            <Button variant="outline" onClick={() => { setDraft(note.raw); setEditing(false); }}>Cancel</Button>
            <span className="text-xs text-muted-foreground">
              Select a word and tap a tool to format it — tap again to undo the format.
            </span>
          </div>
        </div>
      ) : (
        /* ============ PREVIEW MODE ============ */
        <div ref={scrollRef} className="space-y-5">
          <div ref={contentRef} className="rounded-xl border bg-card p-5 shadow-sm">
            <MarkdownBody
              text={note.body.replace(/^#\s+.*\n+/, "")}
              opts={{
                notePath: note.path,
                wikiTitles,
                onToggleTask: toggleTask,
                onImageOp: imageOp,
                onOpenImage: openImage,
                findQuery,
                findActive,
              }}
            />
            {note.my_notes && (
              <>
                <Separator className="my-5" />
                <h2 className="mb-2 text-lg font-semibold">My notes</h2>
                <MarkdownBody text={note.my_notes.replace(/^## My notes\s*/, "")} opts={{ wikiTitles, findQuery }} />
              </>
            )}
          </div>

          {/* Connected notes — the v4 replacement for any graph view */}
          <ConnectedPanel note={note} onChanged={reload} />

          {/* References */}
          <ReferencesPanel note={note} onChanged={reload} />

          {/* Tags */}
          <TagsPanel note={note} onChanged={reload} />

          {/* Metadata */}
          <MetaPanel note={note} onChanged={reload} />

          {/* Attachments */}
          <AttachmentsPanel note={note} onChanged={reload} onInsert={(md) => {
            setDraft(note.raw + "\n\n" + md + "\n");
            setHash(note.hash);
            setEditing(true);
          }} />
        </div>
      )}

      {/* image full-screen viewer */}
      {viewer && (
        <Dialog open onOpenChange={() => setViewer(null)}>
          <DialogContent wide className="sm:max-w-4xl">
            <DialogHeader><DialogTitle>{viewer.alt || "Image"}</DialogTitle></DialogHeader>
            <img src={viewer.src} alt={viewer.alt} className="max-h-[65vh] w-full rounded-lg object-contain" />
            <DialogFooter>
              <Button variant="outline" asChild>
                <a href={viewer.src} download>Download original</a>
              </Button>
              <Button variant="outline" onClick={() => setViewer(null)}>Close</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}

/* ------------------------------------------------------------------ */

function QuickInfoTable({ rows, notePath }: { rows: { label: string; value: string; group: string | null }[]; notePath: string }) {
  const groups: Record<string, typeof rows> = {};
  for (const r of rows) {
    const g = r.group ?? "";
    (groups[g] ??= []).push(r);
  }
  return (
    <div className="space-y-2.5">
      {Object.entries(groups).map(([g, rs]) => (
        <div key={g}>
          {g && <div className="mb-1 text-xs font-semibold uppercase tracking-wide text-primary">{g}</div>}
          <div className="grid gap-x-6 gap-y-1 sm:grid-cols-2">
            {rs.map((r, i) => (
              <div key={i} className="flex gap-2 text-sm">
                <span className="w-36 shrink-0 font-medium text-muted-foreground">{r.label}</span>
                <span className="min-w-0 flex-1">
                  {r.label.toLowerCase() === "image" && /\.(png|jpe?g|gif|webp|svg|bmp)$/i.test(r.value.trim()) ? (
                    <img
                      src={thumbUrl(`${noteFolder(notePath)}/${r.value.trim()}`, 320)}
                      alt={r.label}
                      className="max-h-28 rounded-lg border"
                    />
                  ) : (
                    <MarkdownBody text={r.value} opts={{}} className="[&>*]:my-0" />
                  )}
                </span>
              </div>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
}

/* ---------------- Connected notes panel (no graph) ---------------- */

function ConnectedPanel({ note, onChanged }: { note: NoteView; onChanged: () => void }) {
  const [addOpen, setAddOpen] = useState(false);
  const [newTarget, setNewTarget] = useState("");
  const known = new Set(
    [...note.connected.map((c) => c.toLowerCase()), ...note.incoming.map((c) => c.split("/").slice(-2, -1)[0].toLowerCase())]
  );

  const titleOf = (p: string) => p.split("/").slice(-2, -1)[0] ?? p;

  const removeConn = (t: string) =>
    api.removeConnection(note.path, [t]).then(onChanged).catch((e) => toast.error(e.message));

  return (
    <Card>
      <CardContent className="p-5">
        <div className="mb-3 flex items-center gap-2">
          <Repeat2 className="h-4 w-4 text-primary" />
          <span className="font-semibold">Connected notes</span>
          <Badge variant="secondary">{note.connected.length + note.incoming.length}</Badge>
          <Button size="sm" variant="outline" className="ml-auto" onClick={() => setAddOpen(true)}>
            <Link2 className="h-3.5 w-3.5" /> Connect a note
          </Button>
        </div>
        <div className="grid gap-4 sm:grid-cols-2">
          <div>
            <div className="mb-1.5 text-xs font-semibold uppercase tracking-wide text-muted-foreground">Connects to</div>
            {note.connected.length === 0 && <div className="text-sm text-muted-foreground">No outgoing connections yet.</div>}
            <div className="space-y-1">
              {note.connected.map((c) => (
                <div key={c} className="group flex items-center gap-2 rounded-lg border bg-card px-3 py-2">
                  <FileText className="h-3.5 w-3.5 shrink-0 text-primary" />
                  <Link to={noteHref(c)} className="min-w-0 flex-1 truncate text-sm hover:text-primary">{c}</Link>
                  <button className="opacity-0 transition-opacity group-hover:opacity-100" title="Remove connection" onClick={() => removeConn(c)}>
                    <X className="h-3.5 w-3.5 text-destructive" />
                  </button>
                </div>
              ))}
            </div>
          </div>
          <div>
            <div className="mb-1.5 text-xs font-semibold uppercase tracking-wide text-muted-foreground">Referenced by</div>
            {note.incoming.length === 0 && <div className="text-sm text-muted-foreground">Nothing links here yet.</div>}
            <div className="space-y-1">
              {note.incoming.map((p) => (
                <div key={p} className="flex items-center gap-2 rounded-lg border bg-card px-3 py-2">
                  <FileText className="h-3.5 w-3.5 shrink-0 text-emerald-500" />
                  <Link to={noteHref(p)} className="min-w-0 flex-1 truncate text-sm hover:text-primary">{titleOf(p)}</Link>
                  <ArrowUpRight className="h-3.5 w-3.5 shrink-0 text-muted-foreground" />
                </div>
              ))}
            </div>
          </div>
        </div>
        {note.linked_in_text.length > 0 && (
          <>
            <Separator className="my-4" />
            <div className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">Linked in the text</div>
            <div className="mt-1.5 flex flex-wrap gap-1.5">
              {note.linked_in_text.map((l, i) => (
                <Badge key={i} variant="outline" className="gap-1.5 py-1">
                  <Link to={noteHref(l.target)} className="hover:text-primary">{l.word}</Link>
                  <span className="text-muted-foreground">→ {l.target}</span>
                  <button title="Unlink (keep the words)" onClick={() =>
                    api.unlinkWord(note.path, l.word).then(onChanged).catch((e) => toast.error(e.message))
                  }>
                    <X className="h-3 w-3 text-destructive" />
                  </button>
                </Badge>
              ))}
            </div>
          </>
        )}
      </CardContent>

      <Dialog open={addOpen} onOpenChange={setAddOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Connect a note</DialogTitle>
            <DialogDescription>Only existing notes can be connected — type to search every note in the wiki.</DialogDescription>
          </DialogHeader>
          <SuggestInput value={newTarget} onChange={setNewTarget} kind="all" placeholder="Note name…" autoFocus
            onSubmit={(v) => {
              if (!v.trim()) return;
              api.addConnection(note.path, [v.trim()])
                .then(() => { setAddOpen(false); setNewTarget(""); onChanged(); toast.success("Connected"); })
                .catch((e) => toast.error(e.message));
            }} />
          <DialogFooter>
            <Button variant="outline" onClick={() => setAddOpen(false)}>Cancel</Button>
            <Button
              onClick={() => {
                api.addConnection(note.path, [newTarget.trim()])
                  .then(() => { setAddOpen(false); setNewTarget(""); onChanged(); toast.success("Connected"); })
                  .catch((e) => toast.error(e.message));
              }}
              disabled={!newTarget.trim()}
            >
              Connect
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </Card>
  );
}

/* ---------------- references ---------------- */

function ReferencesPanel({ note, onChanged }: { note: NoteView; onChanged: () => void }) {
  const [title, setTitle] = useState("");
  const [url, setUrl] = useState("");
  return (
    <Card>
      <CardContent className="p-5">
        <div className="mb-3 font-semibold">Reference sources</div>
        {note.references.length === 0 && (
          <div className="text-sm text-muted-foreground">No references yet — proof of where a fact came from.</div>
        )}
        <ul className="space-y-1.5">
          {note.references.map((r, i) => (
            <li key={i} className="group flex items-center gap-2 text-sm">
              <a href={r.url} target="_blank" rel="noreferrer" className="min-w-0 flex-1 truncate text-primary hover:underline">
                {r.title} <span className="text-muted-foreground">— {r.url}</span>
              </a>
              {r.accessed && <span className="shrink-0 text-xs text-muted-foreground">accessed {r.accessed}</span>}
              <button className="opacity-0 group-hover:opacity-100" onClick={() =>
                api.removeReference(note.path, r.url).then(onChanged).catch((e) => toast.error(e.message))
              }>
                <X className="h-3.5 w-3.5 text-destructive" />
              </button>
            </li>
          ))}
        </ul>
        <div className="mt-3 flex flex-wrap gap-2">
          <Input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Title" className="w-48" />
          <Input value={url} onChange={(e) => setUrl(e.target.value)} placeholder="example.com — https is added for you" className="min-w-56 flex-1" />
          <Button variant="outline" disabled={!url.trim()} onClick={() =>
            api.addReference(note.path, { title: title.trim() || url.trim(), url: normalizeUrl(url) })
              .then(() => { setTitle(""); setUrl(""); onChanged(); })
              .catch((e) => toast.error(e.message))
          }>
            <Link2 className="h-3.5 w-3.5" /> Add
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}

/* ---------------- tags ---------------- */

function TagsPanel({ note, onChanged }: { note: NoteView; onChanged: () => void }) {
  const [newTag, setNewTag] = useState("");
  return (
    <Card>
      <CardContent className="p-5">
        <div className="mb-3 flex items-center gap-2">
          <TagIcon className="h-4 w-4 text-primary" />
          <span className="font-semibold">Tags</span>
          <Badge variant="secondary">{note.tags.length}</Badge>
        </div>
        <div className="flex flex-wrap gap-1.5">
          {note.tags.map((t) => (
            <TagChip key={t} tag={t} onRemove={() =>
              api.editTags(note.path, [], [t]).then(onChanged).catch((e) => toast.error(e.message))
            } />
          ))}
          {note.tags.length === 0 && <span className="text-sm text-muted-foreground">No tags yet.</span>}
        </div>
        <div className="mt-3 max-w-sm">
          <SuggestInput
            value={newTag}
            onChange={setNewTag}
            kind="tag"
            placeholder="Add a tag — every existing tag appears below as you type"
            onSubmit={(v) => {
              if (!v.trim()) return;
              api.editTags(note.path, [v.trim()]).then(() => { setNewTag(""); onChanged(); }).catch((e) => toast.error(e.message));
            }}
          />
        </div>
      </CardContent>
    </Card>
  );
}

/* ---------------- metadata ---------------- */

function MetaPanel({ note, onChanged }: { note: NoteView; onChanged: () => void }) {
  const [created, setCreated] = useState(note.meta.created ?? "");
  const [updated, setUpdated] = useState(note.meta.updated ?? "");
  const [pinned, setPinned] = useState(note.meta.pinned ?? "no");
  useEffect(() => {
    setCreated(note.meta.created ?? "");
    setUpdated(note.meta.updated ?? "");
    setPinned(note.meta.pinned ?? "no");
  }, [note]);
  return (
    <Card>
      <CardContent className="p-5">
        <div className="mb-3 font-semibold">Metadata</div>
        <div className="grid gap-3 sm:grid-cols-3">
          <div className="space-y-1"><Label>Created</Label><Input value={created} onChange={(e) => setCreated(e.target.value)} /></div>
          <div className="space-y-1"><Label>Updated</Label><Input value={updated} onChange={(e) => setUpdated(e.target.value)} /></div>
          <div className="space-y-1">
            <Label>Pinned</Label>
            <select
              value={pinned}
              onChange={(e) => setPinned(e.target.value)}
              className="h-9 w-full rounded-md border border-input bg-transparent px-3 text-sm"
            >
              <option value="no">no</option>
              <option value="yes">yes</option>
            </select>
          </div>
        </div>
        <Button variant="outline" size="sm" className="mt-3" onClick={() =>
          api.setMetadata(note.path, { created, updated, pinned }).then(onChanged).catch((e) => toast.error(e.message))
        }>
          Save metadata
        </Button>
      </CardContent>
    </Card>
  );
}

/* ---------------- attachments ---------------- */

function AttachmentsPanel({ note, onChanged, onInsert }: { note: NoteView; onChanged: () => void; onInsert: (md: string) => void }) {
  const fileRef = useRef<HTMLInputElement>(null);
  const upload = (file: File) => {
    const reader = new FileReader();
    reader.onload = () => {
      const b64 = String(reader.result).split(",")[1];
      api
        .imageAdd(note.path, file.name, b64)
        .then((r: any) => {
          toast.success(`Added ${r.file}`);
          onChanged();
        })
        .catch((e) => toast.error(e.message));
    };
    reader.readAsDataURL(file);
  };
  return (
    <Card>
      <CardContent className="p-5">
        <div className="mb-3 flex items-center gap-2">
          <ImagePlus className="h-4 w-4 text-primary" />
          <span className="font-semibold">Attachments</span>
          <Badge variant="secondary">{note.attachments.length}</Badge>
          <Button variant="outline" size="sm" className="ml-auto" onClick={() => fileRef.current?.click()}>
            <ImagePlus className="h-3.5 w-3.5" /> Upload image
          </Button>
          <input
            ref={fileRef}
            type="file"
            accept="image/*"
            className="hidden"
            onChange={(e) => {
              const f = e.target.files?.[0];
              if (f) upload(f);
              e.target.value = "";
            }}
          />
        </div>
        {note.attachments.length === 0 ? (
          <div className="text-sm text-muted-foreground">
            No images yet. Upload one, then place it with <code>![alt](attachments/name.png)</code> —
            consecutive images arrange into a grid with move and size controls.
          </div>
        ) : (
          <div className="grid grid-cols-3 gap-2 sm:grid-cols-5">
            {note.attachments.map((a) => (
              <div key={a} className="group relative overflow-hidden rounded-lg border">
                <img src={thumbUrl(`${noteFolder(note.path)}/attachments/${a}`, 320)} alt={a} className="h-24 w-full object-cover" />
                <div className="absolute inset-0 flex items-end justify-center gap-1 bg-black/50 p-1 opacity-0 transition-opacity group-hover:opacity-100">
                  <Button size="iconSm" variant="secondary" title="Insert into the note" onClick={() =>
                    onInsert(`![${a.replace(/\.[a-z]+$/i, "")}](${noteFolder(note.path)}/attachments/${a})`)
                  }>
                    <Pencil className="h-3 w-3" />
                  </Button>
                  <Button size="iconSm" variant="destructive" title="Delete" onClick={() =>
                    api.imageDelete(note.path, a)
                      .then((r: any) => {
                        if (r.warning) { if (confirm(r.message)) return api.imageDelete(note.path, a).then(onChanged); }
                        else { toast.success("Deleted (kept in backup history)"); onChanged(); }
                      })
                      .catch((e) => toast.error(e.message))
                  }>
                    <Trash2 className="h-3 w-3" />
                  </Button>
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}

function noteFolder(path: string): string {
  // database/<folder>/<Note>/<Note>.md -> database/<folder>/<Note>
  return path.replace(/\/[^/]+$/, "");
}

/* =================== editor toolbar + smart tools =================== */

function EditorToolbar({
  draft, setDraft, textareaRef, note, onSaved,
}: {
  draft: string;
  setDraft: (t: string) => void;
  textareaRef: React.RefObject<HTMLTextAreaElement>;
  note: NoteView;
  onSaved: () => void;
}) {
  const [tableOpen, setTableOpen] = useState(false);
  const [linkOpen, setLinkOpen] = useState(false);
  const [imgOpen, setImgOpen] = useState(false);

  const ta = () => textareaRef.current;

  const replaceRange = (start: number, end: number, text: string, cursor?: number) => {
    const t = draft.slice(0, start) + text + draft.slice(end);
    setDraft(t);
    requestAnimationFrame(() => {
      const el = ta();
      if (el) {
        const pos = cursor ?? start + text.length;
        el.focus();
        el.setSelectionRange(pos, pos);
      }
    });
  };

  const getSelection = () => {
    const el = ta();
    if (!el) return { start: 0, end: 0, text: "" };
    return { start: el.selectionStart, end: el.selectionEnd, text: draft.slice(el.selectionStart, el.selectionEnd) };
  };

  /* smart wrap: select a word and tap to format; tap again to undo; with no
     selection insert the pair with the cursor inside (never selects marks). */
  const smartWrap = (marker: string) => {
    const { start, end, text } = getSelection();
    const before = draft.slice(0, start);
    const after = draft.slice(end);
    if (text) {
      // selection already wrapped by the marker? unwrap.
      if (text.startsWith(marker) && text.endsWith(marker) && text.length >= marker.length * 2) {
        const inner = text.slice(marker.length, text.length - marker.length);
        replaceRange(start, end, inner, start + inner.length);
        return;
      }
      if (before.endsWith(marker) && after.startsWith(marker)) {
        replaceRange(start - marker.length, end + marker.length, text, start);
        return;
      }
      replaceRange(start, end, marker + text + marker, start + marker.length + text.length);
    } else {
      // expand to the word under the cursor
      const wordStart = before.search(/[A-Za-z0-9\u00c0-\u024f]+(?=[^A-Za-z0-9\u00c0-\u024f]*$)/);
      if (wordStart !== -1 && wordStart === start - (before.length - wordStart)) {
        // find word bounds around the cursor
        let s = start, e = start;
        while (s > 0 && /[A-Za-z0-9\u00c0-\u024f]/.test(draft[s - 1])) s--;
        while (e < draft.length && /[A-Za-z0-9\u00c0-\u024f]/.test(draft[e])) e++;
        const word = draft.slice(s, e);
        if (before.slice(0, s).endsWith(marker) && draft.slice(e).startsWith(marker)) {
          replaceRange(s - marker.length, e + marker.length, word, s);
        } else {
          replaceRange(s, e, marker + word + marker, s + marker.length + word.length);
        }
        return;
      }
      replaceRange(start, end, marker + marker, start + marker.length);
    }
  };

  /* smart prefix: toggle `## `, `- `, `- [ ] `, `> ` per line; cursor lands
     right after the prefix. */
  const smartPrefix = (prefix: string) => {
    const { start, end } = getSelection();
    const lineStart = draft.lastIndexOf("\n", Math.max(0, start - 1)) + 1;
    let lineEnd = draft.indexOf("\n", end);
    if (lineEnd === -1) lineEnd = draft.length;
    const block = draft.slice(lineStart, lineEnd);
    const lines = block.split("\n");
    const allHave = lines.every((l) => l.trimStart().startsWith(prefix.trim()) || l.trimStart().startsWith(prefix));
    const toggled = lines
      .map((l) => {
        if (allHave && l.trimStart().startsWith(prefix.trim())) {
          return l.replace(prefix, "");
        }
        return prefix + l;
      })
      .join("\n");
    replaceRange(lineStart, lineEnd, toggled, lineStart + prefix.length);
  };

  const insertHr = () => {
    const { start, end } = getSelection();
    replaceRange(start, end, "\n---\n");
  };

  const insertMath = () => {
    const { start, end, text } = getSelection();
    if (text) replaceRange(start, end, `$${text}$`, start + 1 + text.length + 1);
    else replaceRange(start, end, "$$", start + 1);
  };

  return (
    <>
      {/* STICKY markdown toolbar — stays at the top while the editor scrolls */}
      <div className="sb-sticky flex flex-wrap items-center gap-1 rounded-t-lg border border-b-0 bg-background/95 p-1.5 shadow-sm">
        <ToolButton title="Bold (**)" onClick={() => smartWrap("**")}><Bold /></ToolButton>
        <ToolButton title="Italic (*)" onClick={() => smartWrap("*")}><Italic /></ToolButton>
        <ToolButton title="Strikethrough (~~)" onClick={() => smartWrap("~~")}><span className="line-through">S</span></ToolButton>
        <ToolButton title="Heading (##)" onClick={() => smartPrefix("## ")}><Heading2 /></ToolButton>
        <ToolButton title="Bullet list (- )" onClick={() => smartPrefix("- ")}><List /></ToolButton>
        <ToolButton title="Numbered list (1. )" onClick={() => smartPrefix("1. ")}><ListOrdered /></ToolButton>
        <ToolButton title="Task (- [ ] )" onClick={() => smartPrefix("- [ ] ")}><CheckSquare /></ToolButton>
        <ToolButton title="Quote (> )" onClick={() => smartPrefix("> ")}><Quote /></ToolButton>
        <ToolButton title="Inline code (`)" onClick={() => smartWrap("`")}><Code /></ToolButton>
        <ToolButton title="Code block" onClick={() => {
          const { start, end } = getSelection();
          replaceRange(start, end, "\n```\n" + draft.slice(start, end) + "\n```\n", start + 5);
        }}><span className="text-[10px] font-bold">{'{}'}</span></ToolButton>
        <Separator orientation="vertical" className="mx-1 h-6" />
        <ToolButton title="Table — opens the grid editor" onClick={() => setTableOpen(true)}><Table2 /></ToolButton>
        <ToolButton title="Link a word to a note or a website" onClick={() => setLinkOpen(true)}><Link2 /></ToolButton>
        <ToolButton title="Insert an image" onClick={() => setImgOpen(true)}><ImagePlus /></ToolButton>
        <ToolButton title="Math ($…$)" onClick={insertMath}><Sigma /></ToolButton>
        <ToolButton title="Horizontal rule" onClick={insertHr}><Minus /></ToolButton>
      </div>

      <TableEditorDialog
        open={tableOpen}
        setOpen={setTableOpen}
        draft={draft}
        setDraft={setDraft}
        textareaRef={textareaRef}
      />
      <LinkDialog
        open={linkOpen}
        setOpen={setLinkOpen}
        draft={draft}
        setDraft={setDraft}
        textareaRef={textareaRef}
      />
      <ImageDialog
        open={imgOpen}
        setOpen={setImgOpen}
        setDraft={setDraft}
        draft={draft}
        textareaRef={textareaRef}
        note={note}
        onUploaded={onSaved}
      />
    </>
  );
}

function ToolButton({ title, onClick, children }: { title: string; onClick: () => void; children: React.ReactNode }) {
  return (
    <button
      type="button"
      title={title}
      onMouseDown={(e) => e.preventDefault()}
      onClick={onClick}
      className="inline-flex h-8 w-8 items-center justify-center rounded-md text-sm transition-colors hover:bg-accent hover:text-accent-foreground"
    >
      {children}
    </button>
  );
}

/* ---------------- table editor ---------------- */

function parseTableAt(ta: HTMLTextAreaElement | null, draft: string): { start: number; end: number; rows: string[][] } | null {
  if (!ta) return null;
  const pos = ta.selectionStart;
  const lines = draft.split("\n");
  // which line is the cursor on?
  let charCount = 0;
  let cursorLine = 0;
  for (let i = 0; i < lines.length; i++) {
    charCount += lines[i].length + 1;
    if (pos < charCount) { cursorLine = i; break; }
  }
  const isTableLine = (l: string) => /^\s*\|.*\|\s*$/.test(l);
  if (!isTableLine(lines[cursorLine])) return null;
  let startLine = cursorLine;
  while (startLine > 0 && isTableLine(lines[startLine - 1])) startLine--;
  let endLine = cursorLine;
  while (endLine < lines.length - 1 && isTableLine(lines[endLine + 1])) endLine++;
  const rows = lines.slice(startLine, endLine + 1).map((l) =>
    l.trim().replace(/^\||\|$/g, "").split("|").map((c) => c.trim())
  );
  // drop the separator row
  const body = rows.filter((r, i) => !(i === 1 && r.every((c) => /^:?-{2,}:?$/.test(c))));
  let char = 0;
  for (let i = 0; i < startLine; i++) char += lines[i].length + 1;
  return {
    start: char,
    end: char + lines.slice(startLine, endLine + 1).join("\n").length,
    rows: body,
  };
}

function gridToMarkdown(rows: string[][]): string {
  const cols = Math.max(...rows.map((r) => r.length), 1);
  const norm = rows.map((r) => {
    const c = [...r];
    while (c.length < cols) c.push("");
    return c;
  });
  const head = norm[0];
  const sep = " | " + Array.from({ length: cols }, () => "---").join(" | ") + " |";
  const lines = ["| " + head.join(" | ") + " |", sep];
  for (const r of norm.slice(1)) lines.push("| " + r.join(" | ") + " |");
  return lines.join("\n");
}

function TableEditorDialog({
  open, setOpen, draft, setDraft, textareaRef,
}: {
  open: boolean;
  setOpen: (v: boolean) => void;
  draft: string;
  setDraft: (t: string) => void;
  textareaRef: React.RefObject<HTMLTextAreaElement>;
}) {
  const existing = useMemo(() => (open ? parseTableAt(textareaRef.current, draft) : null), [open, draft, textareaRef]);
  const [rows, setRows] = useState<string[][]>([["Column A", "Column B", "Column C"], ["", "", ""], ["", "", ""]]);

  useEffect(() => {
    if (open) setRows(existing ? existing.rows.map((r) => [...r]) : [["Column A", "Column B", "Column C"], ["", "", ""], ["", "", ""]]);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open]);

  const setCell = (r: number, c: number, v: string) =>
    setRows(rows.map((row, ri) => (ri === r ? row.map((cell, ci) => (ci === c ? v : cell)) : row)));
  const addRow = () => setRows([...rows, new Array(rows[0].length).fill("")]);
  const addCol = () => setRows(rows.map((r) => [...r, ""]));
  const delRow = (r: number) => rows.length > 2 && setRows(rows.filter((_, i) => i !== r));
  const delCol = (c: number) => rows[0].length > 1 && setRows(rows.map((r) => r.filter((_, i) => i !== c)));

  const apply = () => {
    const md = gridToMarkdown(rows);
    if (existing) {
      setDraft(draft.slice(0, existing.start) + md + draft.slice(existing.end));
      toast.success("Table updated in place");
    } else {
      const ta = textareaRef.current;
      const pos = ta ? ta.selectionStart : draft.length;
      setDraft(draft.slice(0, pos) + "\n" + md + "\n" + draft.slice(pos));
      toast.success("Table inserted");
    }
    setOpen(false);
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogContent wide>
        <DialogHeader>
          <DialogTitle>Table editor</DialogTitle>
          <DialogDescription>
            {existing ? "The table at the cursor — edit cells, then Update rewrites it in place." : "No table at the cursor — Insert writes a new one."}
          </DialogDescription>
        </DialogHeader>
        <div className="overflow-x-auto">
          <table className="w-full border-collapse text-sm">
            <tbody>
              {rows.map((row, ri) => (
                <tr key={ri}>
                  <td className="w-8 border-0 align-middle">
                    <button
                      className="p-1 text-muted-foreground hover:text-destructive disabled:opacity-30"
                      title="Delete this row"
                      disabled={rows.length <= 2}
                      onClick={() => delRow(ri)}
                    >
                      <X className="h-3.5 w-3.5" />
                    </button>
                  </td>
                  {row.map((cell, ci) => (
                    <td key={ci} className="border border-border p-0">
                      <input
                        value={cell}
                        onChange={(e) => setCell(ri, ci, e.target.value)}
                        className={cn(
                          "w-full min-w-28 bg-transparent px-2.5 py-1.5 outline-none focus:bg-accent/60",
                          ri === 0 && "font-semibold"
                        )}
                        placeholder={`R${ri + 1}C${ci + 1}`}
                      />
                    </td>
                  ))}
                  <td className="w-8 border-0" />
                </tr>
              ))}
              <tr>
                <td className="border-0" />
                {rows[0]?.map((_, ci) => (
                  <td key={ci} className="border-0 text-center">
                    <button
                      className="p-1 text-muted-foreground hover:text-destructive disabled:opacity-30"
                      title="Delete this column"
                      disabled={rows[0].length <= 1}
                      onClick={() => delCol(ci)}
                    >
                      <X className="h-3.5 w-3.5" />
                    </button>
                  </td>
                ))}
                <td className="border-0" />
              </tr>
            </tbody>
          </table>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" onClick={addRow}>+ Row</Button>
          <Button variant="outline" size="sm" onClick={addCol}>+ Column</Button>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
          <Button onClick={apply}>{existing ? "Update table" : "Insert table"}</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

/* ---------------- link dialog ---------------- */

function LinkDialog({
  open, setOpen, draft, setDraft, textareaRef,
}: {
  open: boolean;
  setOpen: (v: boolean) => void;
  draft: string;
  setDraft: (t: string) => void;
  textareaRef: React.RefObject<HTMLTextAreaElement>;
}) {
  const [word, setWord] = useState("");
  const [target, setTarget] = useState("");
  const [mode, setMode] = useState<"note" | "web">("note");
  const [notes, setNotes] = useState<{ title: string }[]>([]);

  useEffect(() => {
    if (open) {
      const ta = textareaRef.current;
      const sel = ta ? draft.slice(ta.selectionStart, ta.selectionEnd) : "";
      setWord(sel.trim());
      setTarget("");
      api.search({ q: "", page_size: 200 }).then((r) => setNotes(r.results.map((x) => ({ title: x.title })))).catch(() => {});
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open]);

  const apply = () => {
    const ta = textareaRef.current;
    const w = word.trim();
    if (!w) return;
    let repl: string;
    if (mode === "note") {
      const t = target.trim();
      if (!t) return;
      repl = w === t ? `[[${t}]]` : `[[${t}|${w}]]`;
    } else {
      if (!target.trim()) return;
      repl = `[${w}](${normalizeUrl(target)})`;
    }
    const start = ta ? ta.selectionStart : draft.length;
    const end = ta ? ta.selectionEnd : draft.length;
    // if the selection IS the word, replace it
    const isSel = start !== end && draft.slice(start, end).trim() === w;
    if (isSel) {
      setDraft(draft.slice(0, start) + repl + draft.slice(end));
    } else {
      // replace the first occurrence of the word after the cursor
      const idx = draft.indexOf(w, start);
      const at = idx === -1 ? draft.indexOf(w) : idx;
      if (at === -1) {
        setDraft(draft.slice(0, start) + repl + draft.slice(start));
      } else {
        setDraft(draft.slice(0, at) + repl + draft.slice(at + w.length));
      }
    }
    setOpen(false);
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Link a word</DialogTitle>
          <DialogDescription>To any note in the wiki, or to any website (https is added for you).</DialogDescription>
        </DialogHeader>
        <div className="space-y-3">
          <div className="grid grid-cols-2 gap-2">
            <label className={cn("cursor-pointer rounded-lg border p-3 text-sm", mode === "note" && "border-primary ring-1 ring-primary")}>
              <input type="radio" className="mr-2" checked={mode === "note"} onChange={() => setMode("note")} />
              To a note (wiki link)
            </label>
            <label className={cn("cursor-pointer rounded-lg border p-3 text-sm", mode === "web" && "border-primary ring-1 ring-primary")}>
              <input type="radio" className="mr-2" checked={mode === "web"} onChange={() => setMode("web")} />
              To a website
            </label>
          </div>
          <div className="space-y-1.5">
            <Label>Word to link</Label>
            <Input value={word} onChange={(e) => setWord(e.target.value)} />
          </div>
          {mode === "note" ? (
            <div className="space-y-1.5">
              <Label>Target note (type-ahead of every note)</Label>
              <input
                list="sb-note-titles"
                value={target}
                onChange={(e) => setTarget(e.target.value)}
                className="flex h-9 w-full rounded-md border border-input bg-transparent px-3 py-1 text-sm"
                placeholder="Note name…"
              />
              <datalist id="sb-note-titles">
                {notes.map((n) => <option key={n.title} value={n.title} />)}
              </datalist>
            </div>
          ) : (
            <div className="space-y-1.5">
              <Label>Website</Label>
              <Input value={target} onChange={(e) => setTarget(e.target.value)} placeholder="example.com/page" />
            </div>
          )}
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
          <Button onClick={apply} disabled={!word.trim() || !target.trim()}>Insert link</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

/* ---------------- image dialog ---------------- */

function ImageDialog({
  open, setOpen, setDraft, draft, textareaRef, note, onUploaded,
}: {
  open: boolean;
  setOpen: (v: boolean) => void;
  setDraft: (t: string) => void;
  draft: string;
  textareaRef: React.RefObject<HTMLTextAreaElement>;
  note: NoteView;
  onUploaded: () => void;
}) {
  const fileRef = useRef<HTMLInputElement>(null);
  const [alt, setAlt] = useState("");
  const [src, setSrc] = useState("");
  const [existing, setExisting] = useState<string[]>([]);

  useEffect(() => {
    if (open) {
      setSrc("");
      setAlt("");
      setExisting(note.attachments);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open]);

  const insert = (path: string, altText: string) => {
    const ta = textareaRef.current;
    const pos = ta ? ta.selectionStart : draft.length;
    const line = `![${altText}](${path})`;
    setDraft(draft.slice(0, pos) + "\n" + line + "\n" + draft.slice(pos));
    setOpen(false);
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Insert an image</DialogTitle>
          <DialogDescription>
            Upload a new image to attachments/, or place one that is already there.
            Images placed next to each other render as a grid with move + size controls.
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-3">
          <div className="space-y-1.5">
            <Label>Alt text (optional size: <code>alt|50</code> = 50% wide)</Label>
            <Input value={alt} onChange={(e) => setAlt(e.target.value)} placeholder="The pan, mid-cook" />
          </div>
          <div className="flex gap-2">
            <Button variant="outline" onClick={() => fileRef.current?.click()}>
              <ImagePlus className="h-4 w-4" /> Upload…
            </Button>
            <input
              ref={fileRef}
              type="file"
              accept="image/*"
              className="hidden"
              onChange={(e) => {
                const f = e.target.files?.[0];
                e.target.value = "";
                if (!f) return;
                const reader = new FileReader();
                reader.onload = () => {
                  const b64 = String(reader.result).split(",")[1];
                  api
                    .imageAdd(note.path, f.name, b64)
                    .then((r: any) => {
                      toast.success(`Uploaded ${r.file}`);
                      onUploaded();
                      insert(r.file, alt || f.name.replace(/\.[a-z]+$/i, ""));
                    })
                    .catch((err) => toast.error(err.message));
                };
                reader.readAsDataURL(f);
              }}
            />
          </div>
          {existing.length > 0 && (
            <div>
              <div className="mb-1.5 text-xs font-semibold uppercase tracking-wide text-muted-foreground">Already in attachments</div>
              <div className="grid grid-cols-4 gap-2">
                {existing.map((a) => (
                  <button key={a} className="overflow-hidden rounded-lg border hover:border-primary" onClick={() =>
                    insert(`${noteFolder(note.path)}/attachments/${a}`, alt || a.replace(/\.[a-z]+$/i, ""))
                  }>
                    <img src={thumbUrl(`${noteFolder(note.path)}/attachments/${a}`, 200)} alt={a} className="h-16 w-full object-cover" />
                  </button>
                ))}
              </div>
            </div>
          )}
          <div className="space-y-1.5">
            <Label>…or an image path</Label>
            <Input value={src} onChange={(e) => setSrc(e.target.value)} placeholder="attachments/pasta-1.png" />
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
          <Button disabled={!src.trim()} onClick={() => insert(src.trim(), alt)}>Insert</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
