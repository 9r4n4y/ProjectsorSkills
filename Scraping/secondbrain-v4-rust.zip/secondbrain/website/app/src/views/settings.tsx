import React, { useEffect, useState } from "react";
import { toast } from "sonner";
import { Palette, Settings2, Server } from "lucide-react";
import { api } from "@/lib/api";
import { THEMES, useTheme } from "@/components/shared/theme";
import { Button, Card, CardContent, Input, Label, Badge } from "@/components/ui/primitives";
import { Switch } from "@/components/ui/overlays";
import { cn } from "@/lib/utils";

export default function SettingsView() {
  const { theme, setTheme } = useTheme();
  const [settings, setSettings] = useState<Record<string, any> | null>(null);
  const [fontSize, setFontSize] = useState(() => Number(localStorage.getItem("sb-font-size") ?? 16));

  useEffect(() => {
    api.settings().then((r) => setSettings(r.settings)).catch((e) => toast.error(e.message));
  }, []);

  useEffect(() => {
    document.documentElement.style.fontSize = fontSize + "px";
    localStorage.setItem("sb-font-size", String(fontSize));
  }, [fontSize]);

  const save = (patch: Record<string, unknown>) => {
    const next = { ...settings, ...patch };
    setSettings(next);
    api.updateSettings(patch).then(() => toast.success("Settings saved")).catch((e) => toast.error(e.message));
  };

  return (
    <div className="mx-auto max-w-3xl space-y-5">
      <h1 className="flex items-center gap-2 text-xl font-bold"><Settings2 className="h-5 w-5 text-primary" /> Settings</h1>

      <Card>
        <CardContent className="space-y-3 p-5">
          <div className="flex items-center gap-2 font-semibold"><Palette className="h-4 w-4 text-primary" /> Theme</div>
          <div className="text-sm text-muted-foreground">
            12 themes: 6 dark (Grey is the default) and 6 light — the light themes never use white;
            the background is a deeper tint and interactive cards are lighter shades of the same hue.
          </div>
          <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
            {THEMES.map((t) => (
              <button
                key={t.id}
                onClick={() => setTheme(t.id)}
                className={cn(
                  "flex items-center gap-2 rounded-lg border px-2.5 py-2 text-xs transition-colors hover:bg-accent",
                  theme === t.id && "border-primary ring-1 ring-primary"
                )}
              >
                <span className="h-4 w-4 rounded-full border border-black/20" style={{ background: t.swatch }} />
                {t.label}
              </button>
            ))}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="space-y-4 p-5">
          <div className="font-semibold">Reading</div>
          <div className="space-y-1.5">
            <Label>Text size: {fontSize}px</Label>
            <input type="range" min={13} max={20} value={fontSize} onChange={(e) => setFontSize(Number(e.target.value))} className="w-full accent-[hsl(var(--primary))]" />
          </div>
        </CardContent>
      </Card>

      {settings && (
        <Card>
          <CardContent className="space-y-4 p-5">
            <div className="font-semibold">Search & ranking</div>
            <div className="grid gap-3 sm:grid-cols-2">
              <div className="space-y-1.5">
                <Label>Results per page</Label>
                <Input
                  type="number"
                  value={settings.page_size ?? 20}
                  onChange={(e) => setSettings({ ...settings, page_size: Number(e.target.value) })}
                  onBlur={() => save({ page_size: Number(settings.page_size ?? 20) })}
                />
              </div>
              <div className="flex items-center justify-between rounded-lg border px-3 py-2">
                <div>
                  <div className="text-sm font-medium">Typo tolerance</div>
                  <div className="text-xs text-muted-foreground">One wrong letter for words of 5+.</div>
                </div>
                <Switch
                  checked={!!settings.typo_tolerance}
                  onCheckedChange={(v) => save({ typo_tolerance: v })}
                />
              </div>
            </div>
            <div className="space-y-1">
              <div className="text-sm font-medium">Ranking weights</div>
              <div className="flex flex-wrap gap-1.5">
                {Object.entries(settings.ranking_weights ?? {}).map(([k, v]) => (
                  <Badge key={k} variant="secondary">{k} {Math.round((v as number) * 100)}%</Badge>
                ))}
              </div>
              <div className="text-xs text-muted-foreground">
                Tune these from the AI tools (update_settings) or edit core/settings.json —
                every change takes effect on the next search.
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {settings && (
        <Card>
          <CardContent className="space-y-3 p-5">
            <div className="flex items-center gap-2 font-semibold"><Server className="h-4 w-4 text-primary" /> Server</div>
            <div className="text-sm text-muted-foreground">
              Port <code>{settings.server_port}</code> · bind <code>{settings.server_bind}</code> (local only by default).
              The default theme is <code>{settings.default_theme}</code>.
            </div>
            <Button
              variant="outline"
              size="sm"
              onClick={() => api.rebuildIndex().then((r) => toast.success(`Index rebuilt: ${r.notes} notes`)).catch((e) => toast.error(e.message))}
            >
              Rebuild search index
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
