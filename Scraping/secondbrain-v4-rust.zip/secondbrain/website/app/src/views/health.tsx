import React, { useEffect, useState } from "react";
import { ShieldCheck, RefreshCw, Wrench, AlertTriangle, CheckCircle2 } from "lucide-react";
import { toast } from "sonner";
import { api } from "@/lib/api";
import type { HealthData } from "@/lib/types";
import { Button, Card, CardContent, Skeleton, Badge } from "@/components/ui/primitives";
import { noteHref } from "@/lib/api";
import { Link } from "react-router-dom";

const LABELS: Record<string, string> = {
  broken_links: "Broken wiki links",
  notes_without_tags: "Notes without tags",
  notes_without_connections: "Notes without connections",
  tags_used_once: "Tags used only once",
  near_duplicate_tags: "Near-duplicate tags",
  unapproved_tags: "Unapproved tags",
  tags_missing_from_master: "Tags missing from the master list",
  proposed_tags: "Proposed tags",
  notes_without_dates: "Notes without dates",
  unreferenced_attachments: "Unreferenced attachments",
  structure_problems: "Structure problems",
};

export default function Health() {
  const [data, setData] = useState<HealthData | null>(null);

  const reload = () => api.health().then(setData).catch((e) => toast.error(e.message));
  useEffect(() => { reload(); }, []);

  if (!data) return <Skeleton className="h-64" />;

  const fix = (key: string, items: any[]) => {
    const hints: Record<string, (item: any) => { action: string; params: any }> = {
      broken_links: (it) => ({ action: "remove_broken_links", params: { note: it.note, link: it.link } }),
      near_duplicate_tags: (it) => ({ action: "merge_tags", params: { from: it.tags[0], into: it.tags[1] } }),
      unapproved_tags: (it) => ({ action: "approve_tag", params: { tag: it } }),
      tags_missing_from_master: (it) => ({ action: "approve_tag", params: { tag: it } }),
      notes_without_dates: (it) => ({ action: "fix_missing_dates", params: { note: it } }),
      unreferenced_attachments: (it) => ({ action: "remove_stray_attachment", params: { note: it.note, file: it.file } }),
    };
    return Promise.all(
      items.map((item) => {
        const h = hints[key]?.(item);
        if (!h) return Promise.resolve();
        return api.healthFix(h.action, h.params).catch((e) => toast.error(e.message));
      })
    ).then(() => { toast.success("Fixes applied (each one is recorded in the undo journal)"); reload(); });
  };

  return (
    <div className="space-y-5">
      <div className="flex items-center gap-2">
        <h1 className="text-xl font-bold">Health</h1>
        {data.ok
          ? <Badge variant="success"><CheckCircle2 className="mr-1 h-3 w-3" /> every check ran clean</Badge>
          : <Badge variant="secondary"><AlertTriangle className="mr-1 h-3 w-3" /> findings below</Badge>}
        <Button variant="outline" size="sm" className="ml-auto" onClick={reload}><RefreshCw className="h-3.5 w-3.5" /> Re-run</Button>
      </div>

      <div className="grid gap-3 md:grid-cols-2">
        {Object.entries(data.checks).map(([key, check]) => {
          const n = Array.isArray(check.items) ? check.items.length : 0;
          return (
            <Card key={key}>
              <CardContent className="p-4">
                <div className="flex items-center gap-2">
                  <ShieldCheck className={n === 0 ? "h-4 w-4 text-emerald-500" : "h-4 w-4 text-amber-500"} />
                  <span className="font-medium">{LABELS[key] ?? key}</span>
                  <Badge variant={n === 0 ? "success" : "secondary"} className="ml-auto">{check.error ? "error" : n}</Badge>
                </div>
                {check.error && <div className="mt-2 rounded-md bg-destructive/10 p-2 text-xs text-destructive">{check.error}</div>}
                {n > 0 && (
                  <ul className="mt-2 max-h-40 space-y-1 overflow-y-auto text-xs text-muted-foreground">
                    {check.items.map((it: any, i: number) => (
                      <li key={i} className="flex items-start justify-between gap-2">
                        <span className="min-w-0">
                          {typeof it === "string"
                            ? <Link className="hover:text-primary" to={noteHref(it)}>{it.split("/").slice(1, -1).join("/") || it}</Link>
                            : JSON.stringify(it)}
                        </span>
                      </li>
                    ))}
                  </ul>
                )}
                {check.fixable && n > 0 && !check.error && (
                  <Button variant="outline" size="sm" className="mt-3" onClick={() => fix(key, check.items as any[])}>
                    <Wrench className="h-3.5 w-3.5" /> Fix all
                  </Button>
                )}
              </CardContent>
            </Card>
          );
        })}
      </div>
    </div>
  );
}
