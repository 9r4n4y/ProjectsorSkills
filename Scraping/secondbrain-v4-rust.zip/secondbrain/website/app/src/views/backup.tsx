import React, { useState } from "react";
import { DatabaseBackup, Eye, PlayCircle, ShieldCheck } from "lucide-react";
import { toast } from "sonner";
import { api } from "@/lib/api";
import { Button, Card, CardContent, Input, Label, Skeleton } from "@/components/ui/primitives";
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from "@/components/ui/overlays";

export default function Backup() {
  const [to, setTo] = useState("");
  const [scope, setScope] = useState("whole");
  const [direction, setDirection] = useState("backup");
  const [preview, setPreview] = useState<any>(null);
  const [result, setResult] = useState<any>(null);
  const [busy, setBusy] = useState(false);

  const target = () => {
    if (!to.trim()) { toast.error("Choose a backup folder first (it must live OUTSIDE the project)."); return null; }
    return to.trim();
  };

  return (
    <div className="mx-auto max-w-3xl space-y-5">
      <h1 className="flex items-center gap-2 text-xl font-bold"><DatabaseBackup className="h-5 w-5 text-primary" /> Backup</h1>

      <Card>
        <CardContent className="space-y-4 p-5">
          <div className="text-sm text-muted-foreground">
            The backup makes the chosen folder <b>byte-identical</b> to the project: every file is re-hashed
            on both sides and success is only reported when every hash matches. Replaced files are kept in
            a dated <code>.versions/</code> folder. The live project is only ever read.
          </div>
          <div className="grid gap-3 sm:grid-cols-3">
            <div className="space-y-1.5 sm:col-span-1">
              <Label>1 · Backup folder</Label>
              <Input value={to} onChange={(e) => setTo(e.target.value)} placeholder="/path/to/backup" />
            </div>
            <div className="space-y-1.5">
              <Label>Scope</Label>
              <Select value={scope} onValueChange={setScope}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="whole">whole project</SelectItem>
                  <SelectItem value="database">database only</SelectItem>
                  <SelectItem value="inbox">inbox only</SelectItem>
                  <SelectItem value="logs">logs only</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label>Direction</Label>
              <Select value={direction} onValueChange={setDirection}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="backup">backup (project → copy)</SelectItem>
                  <SelectItem value="restore">restore (copy → project)</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" disabled={busy} onClick={() => {
              const t = target(); if (!t) return;
              setBusy(true);
              apiPostPreview({ to: t, scope, direction }).then(setPreview).catch((e) => toast.error(e.message)).finally(() => setBusy(false));
            }}><Eye className="h-4 w-4" /> Preview</Button>
            <Button variant="hero" disabled={busy || !preview} onClick={() => {
              const t = target(); if (!t) return;
              setBusy(true);
              apiPost("/api/backup/run", { to: t, scope, direction, keep: 10 })
                .then((r: any) => { setResult(r); toast.success(r.message ?? "Backup finished"); })
                .catch((e) => toast.error(e.message))
                .finally(() => setBusy(false));
            }}><PlayCircle className="h-4 w-4" /> Run</Button>
            <Button variant="outline" disabled={busy || !to.trim()} onClick={() => {
              apiPost("/api/backup/verify", { to: to.trim(), scope })
                .then((r: any) => toast.success(r.identical ? "Verified: byte-identical." : "Differences found — see the run list."))
                .catch((e) => toast.error(e.message));
            }}><ShieldCheck className="h-4 w-4" /> Verify</Button>
          </div>
        </CardContent>
      </Card>

      {preview && (
        <Card>
          <CardContent className="p-5">
            <div className="mb-2 font-semibold">Preview</div>
            <pre className="max-h-64 overflow-auto whitespace-pre-wrap rounded-lg bg-muted/40 p-3 text-xs">{preview.preview}</pre>
          </CardContent>
        </Card>
      )}
      {result && (
        <Card>
          <CardContent className="p-5">
            <div className="mb-2 font-semibold">Result {result.identical ? "✅" : "⚠️"}</div>
            <div className="text-sm text-muted-foreground">{result.message}</div>
            <div className="mt-1 text-xs text-muted-foreground">
              copied {result.copied} · removed {result.removed}
            </div>
            {result.differences?.length > 0 && (
              <pre className="mt-2 max-h-40 overflow-auto whitespace-pre-wrap rounded-lg bg-muted/40 p-3 text-xs">{result.differences.join("\n")}</pre>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
}

async function apiPostPreview(body: any) {
  const r = await fetch("/api/backup/preview", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  const j = await r.json();
  if (!r.ok || j.error) throw new Error(j.error ?? "Preview failed");
  return j;
}

function apiPost(url: string, body: any) {
  return fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  }).then(async (r) => {
    const j = await r.json();
    if (!r.ok || j.error) throw new Error(j.error ?? "Request failed");
    return j;
  });
}
