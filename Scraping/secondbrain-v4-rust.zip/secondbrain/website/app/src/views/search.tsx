import React, { useCallback, useEffect, useRef, useState } from "react";
import { Link, useSearchParams } from "react-router-dom";
import {
  Search, ChevronDown, Save, X, Info, SlidersHorizontal, BookOpen,
} from "lucide-react";
import { toast } from "sonner";
import { api, noteHref } from "@/lib/api";
import type { SearchResponse, SearchResult } from "@/lib/types";
import { Button, Card, CardContent, Input, Label, Badge, Skeleton, Separator } from "@/components/ui/primitives";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, Popover, PopoverTrigger, PopoverContent, RadioGroup, RadioGroupItem } from "@/components/ui/overlays";
import { SuggestInput } from "@/components/shared/suggest-input";
import { TagChip } from "@/components/shared/tag-badge";
import { Kbd } from "@/components/shared/kbd";
import { cn } from "@/lib/utils";

const MODES = [
  { id: "rank", label: "Ranking only", desc: "Nothing is excluded — tags and words only order the results." },
  { id: "strict_keyword", label: "Strict keyword", desc: "Only notes containing EVERY query word (synonyms satisfy it; \"quotes\" are an exact phrase)." },
  { id: "strict_tag", label: "Strict tag", desc: "Only notes carrying ALL selected tags." },
];

const SCOPES = [
  { id: "everything", label: "Everything" },
  { id: "file name", label: "File name" },
  { id: "tags", label: "Tags" },
  { id: "headings", label: "Headings" },
  { id: "body", label: "Body" },
  { id: "folder path", label: "Folder path" },
];

export default function SearchView() {
  const [sp, setSp] = useSearchParams();
  const [q, setQ] = useState(sp.get("q") ?? "");
  const [mode, setMode] = useState(sp.get("mode") ?? "rank");
  const [tags, setTags] = useState<string[]>((sp.get("tags") ?? "").split(",").filter(Boolean));
  const [folders, setFolders] = useState<string[]>((sp.get("folders") ?? "").split(",").filter(Boolean));
  const [folderOnly, setFolderOnly] = useState(sp.get("folder_only") === "1");
  const [scopes, setScopes] = useState<string[]>(["everything"]);
  const [dateFrom, setDateFrom] = useState(sp.get("date_from") ?? "");
  const [dateTo, setDateTo] = useState(sp.get("date_to") ?? "");
  const [res, setRes] = useState<SearchResponse | null>(null);
  const [busy, setBusy] = useState(false);
  const [showMore, setShowMore] = useState(false);
  const [helpOpen, setHelpOpen] = useState(false);
  const [saveOpen, setSaveOpen] = useState(false);
  const [saveName, setSaveName] = useState("");
  const offsetRef = useRef(0);

  const run = useCallback(
    (offset: number, append: boolean) => {
      setBusy(true);
      api
        .search({
          q,
          mode,
          tags: tags.join(","),
          folders: folders.join(","),
          folder_only: folderOnly,
          scope: scopes.join(","),
          date_from: dateFrom,
          date_to: dateTo,
          offset,
        })
        .then((r) => {
          offsetRef.current = offset;
          setRes((prev) =>
            append && prev ? { ...r, results: [...prev.results, ...r.results] } : r
          );
          setShowMore(offset + 20 < r.total);
        })
        .catch((e) => toast.error(e.message))
        .finally(() => setBusy(false));
    },
    [q, mode, tags, folders, folderOnly, scopes, dateFrom, dateTo]
  );

  // search on mount (when a ?q= arrives) and when the query params change
  useEffect(() => {
    if (sp.get("q") !== null) {
      setQ(sp.get("q") ?? "");
      run(0, false);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [sp]);

  const submit = () => {
    setSp({ q });
    run(0, false);
  };

  const toggleScope = (id: string) => {
    if (id === "everything") return setScopes(["everything"]);
    let next = scopes.filter((s) => s !== "everything");
    next = next.includes(id) ? next.filter((s) => s !== id) : [...next, id];
    setScopes(next.length ? next : ["everything"]);
  };

  return (
    <div className="space-y-5">
      <div className="flex items-center gap-2">
        <h1 className="text-xl font-bold">Search</h1>
        <Button variant="outline" size="sm" className="ml-auto" onClick={() => setHelpOpen(true)}>
          <BookOpen className="h-3.5 w-3.5" /> How to use
        </Button>
      </div>

      {/* query bar */}
      <form className="flex gap-2" onSubmit={(e) => { e.preventDefault(); submit(); }}>
        <div className="relative flex-1">
          <Search className="absolute left-3 top-2.5 h-4.5 w-4.5 text-muted-foreground" />
          <Input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder='Every word of every note is searched — try "one pot" or pasta'
            className="h-11 pl-9 text-base"
          />
        </div>
        <Button type="submit" variant="hero" size="lg" disabled={busy}>Search</Button>
      </form>

      {/* 1 · how should it match */}
      <Card>
        <CardContent className="space-y-4 p-5">
          <div className="text-sm font-semibold"><span className="mr-2 rounded bg-primary/15 px-1.5 py-0.5 text-primary">1</span> How should it match?</div>
          <RadioGroup value={mode} onValueChange={setMode} className="grid gap-2 sm:grid-cols-3">
            {MODES.map((m) => (
              <label key={m.id} className={cn(
                "flex cursor-pointer items-start gap-2.5 rounded-lg border p-3 transition-colors hover:bg-accent",
                mode === m.id && "border-primary ring-1 ring-primary"
              )}>
                <RadioGroupItem value={m.id} className="mt-0.5" />
                <span>
                  <span className="block text-sm font-medium">{m.label}</span>
                  <span className="block text-xs text-muted-foreground">{m.desc}</span>
                </span>
              </label>
            ))}
          </RadioGroup>
          <div>
            <div className="mb-1.5 text-xs font-semibold uppercase tracking-wide text-muted-foreground">Search in</div>
            <div className="flex flex-wrap gap-1.5">
              {SCOPES.map((s) => (
                <button
                  key={s.id}
                  onClick={() => toggleScope(s.id)}
                  className={cn(
                    "rounded-full border px-3 py-1 text-xs transition-colors hover:bg-accent",
                    scopes.includes(s.id) ? "border-primary bg-primary/10 text-primary" : "text-muted-foreground"
                  )}
                >
                  {s.label}
                </button>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* 2 · narrow */}
      <Card>
        <CardContent className="space-y-4 p-5">
          <div className="text-sm font-semibold"><span className="mr-2 rounded bg-primary/15 px-1.5 py-0.5 text-primary">2</span> Narrow by tags & folders</div>
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-1.5">
              <Label>Tags (must be real tags — type to see them all)</Label>
              <SuggestInput
                value=""
                kind="tag"
                placeholder="Add a tag…"
                onSubmit={(v) => { if (v && !tags.includes(v)) setTags([...tags, v]); }}
              />
              <div className="flex flex-wrap gap-1.5">
                {tags.map((t) => (
                  <TagChip key={t} tag={t} onRemove={() => setTags(tags.filter((x) => x !== t))} />
                ))}
              </div>
            </div>
            <div className="space-y-1.5">
              <Label>Folders (hard boundary — sub-folders included)</Label>
              <SuggestInput
                value=""
                kind="folder"
                placeholder="Add a folder…"
                onSubmit={(v) => { if (v && !folders.includes(v)) setFolders([...folders, v]); }}
              />
              <div className="flex flex-wrap gap-1.5">
                {folders.map((f) => (
                  <Badge key={f} variant="secondary" className="gap-1 py-1">
                    {f}
                    <button onClick={() => setFolders(folders.filter((x) => x !== f))}><X className="h-3 w-3" /></button>
                  </Badge>
                ))}
                {folders.length > 0 && (
                  <label className="flex items-center gap-1.5 text-xs text-muted-foreground">
                    <input type="checkbox" checked={folderOnly} onChange={(e) => setFolderOnly(e.target.checked)} />
                    this folder only
                  </label>
                )}
              </div>
            </div>
          </div>
          <div className="grid gap-3 sm:grid-cols-2">
            <div className="space-y-1.5">
              <Label>Updated from</Label>
              <Input type="date" value={dateFrom} onChange={(e) => setDateFrom(e.target.value)} />
            </div>
            <div className="space-y-1.5">
              <Label>Updated to</Label>
              <Input type="date" value={dateTo} onChange={(e) => setDateTo(e.target.value)} />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* results */}
      {res === null && busy && <Skeleton className="h-40" />}
      {res && (
        <div className="space-y-3">
          <div className="flex flex-wrap items-center gap-2 text-sm text-muted-foreground">
            <span><b className="text-foreground">{res.total}</b> note{res.total === 1 ? "" : "s"} · {res.elapsed_ms} ms</span>
            {res.fallback_used && <Badge variant="outline">closest matches (no direct hits)</Badge>}
            {res.query.query_tags.length > 0 && <span>tags detected: {res.query.query_tags.join(", ")}</span>}
            <Button variant="outline" size="sm" className="ml-auto" onClick={() => setSaveOpen(true)}>
              <Save className="h-3.5 w-3.5" /> Save this search
            </Button>
          </div>
          {res.notice && (
            <div className="rounded-lg border border-amber-500/40 bg-amber-500/10 p-3 text-sm">{res.notice}</div>
          )}
          {res.results.length === 0 && !res.notice && (
            <div className="rounded-lg border border-dashed p-8 text-center text-sm text-muted-foreground">
              Nothing matched. Relax the modes or widen the folder boundary.
            </div>
          )}
          {res.results.map((r) =>
            "score" in r && r.score !== null ? (
              <ResultCard key={r.path} r={r as SearchResult} />
            ) : (
              <ConnectedExtra key={r.path} r={r as any} />
            )
          )}
          {showMore && (
            <Button variant="outline" className="w-full" onClick={() => run(offsetRef.current + 20, true)}>
              Show 20 more
            </Button>
          )}
        </div>
      )}

      {/* how to use */}
      <Dialog open={helpOpen} onOpenChange={setHelpOpen}>
        <DialogContent wide>
          <DialogHeader><DialogTitle>How to use search</DialogTitle></DialogHeader>
          <div className="space-y-2 text-sm text-muted-foreground">
            <p><b className="text-foreground">Everything is searched.</b> The full text of every note (body, headings, quick info, tags, file names and folder paths) is indexed — nothing hidden. Ranking only orders; nothing is filtered out.</p>
            <p><b className="text-foreground">Words</b> are lowercased, accents stripped, endings stemmed (recipe ≈ recipes), one wrong letter tolerated for words of 5+ letters, and filler words (the, a, of…) are dropped — negations (no, not, without) are kept.</p>
            <p><b className="text-foreground">Synonyms</b> count 0.7: quick ≈ fast, dish ≈ meal — your own words always count fully. Words matching a tag (or a tag synonym) become query tags.</p>
            <p><b className="text-foreground">"Quoted words"</b> are an exact phrase. Strict keyword requires every word; strict tag requires every selected tag.</p>
            <p><b className="text-foreground">Folders</b> are a hard boundary: with a folder selected the search never looks outside it (sub-folders included).</p>
            <p><b className="text-foreground">Every result explains itself</b> — a plain-language reason plus the exact signal bars below the score.</p>
          </div>
        </DialogContent>
      </Dialog>

      {/* save search */}
      <Dialog open={saveOpen} onOpenChange={setSaveOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle>Save this search</DialogTitle></DialogHeader>
          <Input value={saveName} onChange={(e) => setSaveName(e.target.value)} placeholder="Name, e.g. weeknight recipes" autoFocus />
          <DialogFooter>
            <Button variant="outline" onClick={() => setSaveOpen(false)}>Cancel</Button>
            <Button
              disabled={!saveName.trim()}
              onClick={() =>
                api.savedSearchSave(saveName.trim(), { q, mode, tags, folders, folder_only: folderOnly, scope: scopes, date_from: dateFrom, date_to: dateTo })
                  .then(() => { setSaveOpen(false); setSaveName(""); toast.success("Search saved — it appears on Home"); })
                  .catch((e) => toast.error(e.message))
              }
            >
              Save
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function ResultCard({ r }: { r: SearchResult }) {
  const [openWhy, setOpenWhy] = useState(false);
  const applied = Object.entries(r.breakdown ?? {}).filter(([, v]) => v.applied);
  return (
    <Card className="transition-colors hover:border-primary/40">
      <CardContent className="p-4">
        <div className="flex items-start gap-3">
          <div className="min-w-0 flex-1">
            <Link to={noteHref(r.path)} className="text-base font-semibold hover:text-primary">{r.title}</Link>
            <div className="mt-0.5 flex flex-wrap items-center gap-1.5 text-xs text-muted-foreground">
              <span>{r.folder || "database"}</span>
              {r.updated && <span>· updated {r.updated}</span>}
              {r.pinned && <Badge variant="secondary">pinned</Badge>}
              {r.tags.slice(0, 4).map((t) => <Badge key={t} variant="outline">{t}</Badge>)}
            </div>
            <p className="mt-2 line-clamp-2 text-sm text-muted-foreground">{r.snippet}</p>
          </div>
          <div className="shrink-0 text-right">
            <div className="text-2xl font-bold text-primary">{r.score}</div>
            <div className="text-[10px] uppercase tracking-wide text-muted-foreground">score</div>
          </div>
        </div>
        <div className="mt-2 flex items-center gap-2 text-xs text-muted-foreground">
          <Info className="h-3.5 w-3.5 shrink-0" />
          <span className="min-w-0 flex-1">{r.rank_reason}</span>
          <button className="shrink-0 underline hover:text-primary" onClick={() => setOpenWhy(!openWhy)}>
            Why this ranking
          </button>
        </div>
        {openWhy && (
          <div className="mt-3 space-y-1.5 rounded-lg border bg-muted/30 p-3">
            {applied.map(([k, v]) => (
              <div key={k} className="flex items-center gap-2 text-xs">
                <span className="w-20 capitalize text-muted-foreground">{k}</span>
                <div className="h-2 flex-1 overflow-hidden rounded-full bg-muted">
                  <div className="h-full rounded-full bg-primary" style={{ width: `${Math.min(100, v.points * 100)}%` }} />
                </div>
                <span className="w-10 text-right tabular-nums">{v.points.toFixed(2)}</span>
                <span className="w-24 text-muted-foreground">weight {Math.round(v.weight * 100)}%</span>
              </div>
            ))}
            <div className="text-[11px] text-muted-foreground">
              coverage {r.coverage} · signals that did not apply gave their weight to the ones above.
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

function ConnectedExtra({ r }: { r: SearchResult }) {
  return (
    <Card>
      <CardContent className="p-4">
        <div className="flex items-center gap-3">
          <Link to={noteHref(r.path)} className="font-medium hover:text-primary">{r.title}</Link>
          <Badge variant="outline">connected to a top result</Badge>
          <span className="ml-auto text-xs text-muted-foreground">{r.folder}</span>
        </div>
      </CardContent>
    </Card>
  );
}
