import React, { useEffect, useState } from "react";
import { Plus, ScrollText, History, Undo2, RefreshCw } from "lucide-react";
import { toast } from "sonner";
import { api } from "@/lib/api";
import type { LogRow, EditHistoryRow, JournalRow } from "@/lib/types";
import { Button, Card, CardContent, Input, Label, Skeleton, Badge, Separator } from "@/components/ui/primitives";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, Tabs, TabsList, TabsTrigger, TabsContent, AlertDialog, AlertDialogContent, AlertDialogTitle, AlertDialogDescription, AlertDialogCancel, AlertDialogAction } from "@/components/ui/overlays";

/* LOGS PAGE — v4 rules (LOGS.md):
   - logs/ holds MANUAL entries only (written here, or by the AI via
     add_log_entry). Nothing in the engine writes log files by itself.
   - The ONE automatic file is the note-edit history (edits.md): which note
     was edited and which lines were added/removed.
   - Undo runs only when you press the button, from the internal journal. */

export default function Logs() {
  const [tab, setTab] = useState("manual");
  const [logs, setLogs] = useState<LogRow[] | null>(null);
  const [history, setHistory] = useState<EditHistoryRow[]>([]);
  const [journal, setJournal] = useState<JournalRow[]>([]);
  const [viewLog, setViewLog] = useState<{ name: string; text: string } | null>(null);
  const [newOpen, setNewOpen] = useState(false);
  const [undoTarget, setUndoTarget] = useState<JournalRow | null>(null);

  const reload = () => {
    api.logs(200).then((r) => setLogs(r.logs)).catch((e) => toast.error(e.message));
    api.editHistory(120).then((r) => setHistory(r.history)).catch(() => {});
    api.journal().then((r) => setJournal(r.changes)).catch(() => {});
  };
  useEffect(() => { reload(); }, []);

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center gap-2">
        <h1 className="text-xl font-bold">Logs</h1>
        <Button variant="outline" size="sm" className="ml-auto" onClick={reload}><RefreshCw className="h-3.5 w-3.5" /> Refresh</Button>
        <Button size="sm" onClick={() => setNewOpen(true)}><Plus className="h-3.5 w-3.5" /> New log entry</Button>
      </div>

      <Tabs value={tab} onValueChange={setTab}>
        <TabsList>
          <TabsTrigger value="manual"><ScrollText className="h-3.5 w-3.5" /> Manual entries</TabsTrigger>
          <TabsTrigger value="edits"><History className="h-3.5 w-3.5" /> Edit history (automatic)</TabsTrigger>
          <TabsTrigger value="undo"><Undo2 className="h-3.5 w-3.5" /> Undo journal</TabsTrigger>
        </TabsList>

        <TabsContent value="manual">
          <div className="space-y-2">
            {logs === null ? <Skeleton className="h-24" /> : logs.length === 0 ? (
              <div className="rounded-lg border border-dashed p-6 text-sm text-muted-foreground">
                No manual log entries yet. The engine never writes this list by itself —
                you (or the AI, after a structural change) add entries with “New log entry”.
              </div>
            ) : (
              logs.map((l) => (
                <button key={l.file} className="flex w-full items-center gap-3 rounded-lg border bg-card px-4 py-2.5 text-left hover:border-primary/50"
                  onClick={() => api.log(l.file).then(setViewLog)}>
                  <div className="min-w-0 flex-1">
                    <div className="truncate text-sm font-medium">{l.title}</div>
                    <div className="text-xs text-muted-foreground">{l.date}</div>
                  </div>
                  <Badge variant={l.who === "AI" ? "default" : "secondary"}>{l.who}</Badge>
                </button>
              ))
            )}
          </div>
        </TabsContent>

        <TabsContent value="edits">
          <div className="mb-2 text-xs text-muted-foreground">
            This is the ONE automatic log (logs/edits.md): every note edit with its added and removed lines.
          </div>
          <div className="space-y-2">
            {history.length === 0 && <div className="rounded-lg border border-dashed p-6 text-sm text-muted-foreground">No edits recorded yet.</div>}
            {history.map((h, i) => (
              <Card key={i}>
                <CardContent className="p-3.5">
                  <div className="flex flex-wrap items-center gap-2 text-sm">
                    <span className="font-medium">{h.note}</span>
                    <Badge variant="secondary">{h.who}</Badge>
                    <span className="ml-auto text-xs text-muted-foreground">{h.when}</span>
                  </div>
                  {h.lines_added && <div className="mt-1.5 text-xs text-emerald-500">+ {h.lines_added}</div>}
                  {h.lines_removed && <div className="text-xs text-destructive">− {h.lines_removed}</div>}
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="undo">
          <div className="mb-2 text-xs text-muted-foreground">
            Every write records how to reverse it in the internal journal. Nothing ever reverses itself —
            undo happens only when you press the button.
          </div>
          <div className="space-y-2">
            {journal.length === 0 && <div className="rounded-lg border border-dashed p-6 text-sm text-muted-foreground">No changes recorded yet.</div>}
            {journal.map((c) => (
              <div key={c.id} className="flex items-center gap-3 rounded-lg border bg-card px-4 py-2.5">
                <div className="min-w-0 flex-1">
                  <div className="truncate text-sm font-medium">{c.title}</div>
                  <div className="text-xs text-muted-foreground">{c.when} · {c.who} · {c.steps} step{c.steps === 1 ? "" : "s"}</div>
                </div>
                <Button variant="outline" size="sm" onClick={() => setUndoTarget(c)}>
                  <Undo2 className="h-3.5 w-3.5" /> Undo
                </Button>
              </div>
            ))}
          </div>
        </TabsContent>
      </Tabs>

      {/* view log */}
      <Dialog open={viewLog !== null} onOpenChange={(v) => !v && setViewLog(null)}>
        <DialogContent wide>
          <DialogHeader><DialogTitle>{viewLog?.name}</DialogTitle></DialogHeader>
          <pre className="max-h-96 overflow-auto whitespace-pre-wrap rounded-lg border bg-muted/40 p-3 text-xs">{viewLog?.text}</pre>
        </DialogContent>
      </Dialog>

      <NewLogDialog open={newOpen} setOpen={setNewOpen} onDone={reload} />

      <AlertDialog open={undoTarget !== null} onOpenChange={(v) => !v && setUndoTarget(null)}>
        <AlertDialogContent>
          <AlertDialogTitle>Undo “{undoTarget?.title}”?</AlertDialogTitle>
          <AlertDialogDescription>
            This reverses the recorded change (files restored to their previous content).
            The undo itself is recorded in the journal. Nothing is ever reversed automatically.
          </AlertDialogDescription>
          <div className="flex justify-end gap-2">
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={() => {
              if (!undoTarget) return;
              api.undo(undoTarget.id)
                .then(() => { toast.success("Undone"); setUndoTarget(null); reload(); })
                .catch((e) => toast.error(e.message));
            }}>Undo</AlertDialogAction>
          </div>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

function NewLogDialog({ open, setOpen, onDone }: { open: boolean; setOpen: (v: boolean) => void; onDone: () => void }) {
  const [who, setWho] = useState("user");
  const [title, setTitle] = useState("");
  const [details, setDetails] = useState("");
  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>New log entry</DialogTitle>
        </DialogHeader>
        <div className="space-y-3">
          <div className="space-y-1.5">
            <Label>Who</Label>
            <Input value={who} onChange={(e) => setWho(e.target.value)} placeholder="user or AI (or the AI's name)" />
          </div>
          <div className="space-y-1.5">
            <Label>Title</Label>
            <Input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="e.g. Restructured the search page" autoFocus />
          </div>
          <div className="space-y-1.5">
            <Label>Details</Label>
            <textarea
              value={details}
              onChange={(e) => setDetails(e.target.value)}
              className="h-32 w-full rounded-md border border-input bg-transparent p-2.5 text-sm"
              placeholder={"- What was done\n- Why"}
            />
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
          <Button disabled={!title.trim()} onClick={() =>
            api.createLog(who || "user", title.trim(), details)
              .then(() => { setOpen(false); setTitle(""); setDetails(""); toast.success("Log entry written"); onDone(); })
              .catch((e) => toast.error(e.message))
          }>Write entry</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
