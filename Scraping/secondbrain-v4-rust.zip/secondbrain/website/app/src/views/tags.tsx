import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { Tag as TagIcon, Search, RefreshCw, PenLine, Merge, Trash2, Check, FileText } from "lucide-react";
import { toast } from "sonner";
import { api, noteHref } from "@/lib/api";
import type { TagsData } from "@/lib/types";
import { Button, Card, CardContent, Input, Label, Skeleton, Badge } from "@/components/ui/primitives";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/overlays";
import { SuggestInput } from "@/components/shared/suggest-input";
import { TagChip } from "@/components/shared/tag-badge";

export default function Tags() {
  const [data, setData] = useState<TagsData | null>(null);
  const [filter, setFilter] = useState("");
  const [preview, setPreview] = useState<any>(null);
  const [action, setAction] = useState<{ kind: "rename" | "merge" | "remove"; tag: string } | null>(null);
  const [target, setTarget] = useState("");
  const [masterOpen, setMasterOpen] = useState(false);
  const [masterText, setMasterText] = useState("");

  const reload = () => api.tags().then(setData).catch((e) => toast.error(e.message));
  useEffect(() => { reload(); }, []);

  if (!data) return <Skeleton className="h-64" />;

  const rows = data.rows.filter((r) => r.tag.toLowerCase().includes(filter.toLowerCase()));

  const runPreview = (kind: "rename" | "merge" | "remove", tag: string, to: string) => {
    if (kind === "rename") api.tagRename(tag, to, false).then(setPreview);
    if (kind === "merge") api.tagMerge(tag, to, false).then(setPreview);
    if (kind === "remove") api.tagRemove(tag, false).then(setPreview);
  };
  const runApply = () => {
    if (!preview) return;
    const p: any = { run: true };
    const body = action?.kind === "rename"
      ? api.tagRename(preview.from, preview.to, true)
      : action?.kind === "merge"
        ? api.tagMerge(preview.from, preview.into, true)
        : api.tagRemove(preview.tag, true);
    body.then(() => {
      setPreview(null);
      setAction(null);
      setTarget("");
      reload();
      toast.success("Applied everywhere — notes and master list updated together");
    }).catch((e) => toast.error(e.message));
  };

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center gap-2">
        <h1 className="text-xl font-bold">Tags</h1>
        <Badge variant="secondary">{data.rows.length} in use</Badge>
        <div className="ml-auto flex gap-2">
          <Button variant="outline" size="sm" onClick={reload}><RefreshCw className="h-3.5 w-3.5" /> Refresh</Button>
          <Button variant="outline" size="sm" onClick={() => {
            api.masterTags().then((r) => { setMasterText(r.text); setMasterOpen(true); });
          }}><PenLine className="h-3.5 w-3.5" /> _tags.md editor</Button>
        </div>
      </div>

      <div className="max-w-md">
        <div className="relative">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input value={filter} onChange={(e) => setFilter(e.target.value)} placeholder="Filter tags…" className="pl-8" />
        </div>
      </div>

      {(data.unapproved.length > 0 || data.proposed.length > 0 || data.near_duplicates.length > 0) && (
        <Card>
          <CardContent className="space-y-3 p-4">
            {data.unapproved.length > 0 && (
              <div>
                <div className="mb-1.5 text-xs font-semibold uppercase tracking-wide text-muted-foreground">Unapproved (used on notes, missing from the master list)</div>
                <div className="flex flex-wrap gap-1.5">
                  {data.unapproved.map((t) => (
                    <Badge key={t} variant="secondary" className="gap-1 py-1">
                      {t}
                      <button className="inline-flex items-center gap-0.5 text-emerald-500 hover:underline"
                        onClick={() => api.tagsMasterAdd([t]).then((r) => { toast.success(`Approved: ${r.added.join(", ")}`); reload(); })}>
                        <Check className="h-3 w-3" /> approve
                      </button>
                    </Badge>
                  ))}
                </div>
              </div>
            )}
            {data.proposed.length > 0 && (
              <div>
                <div className="mb-1.5 text-xs font-semibold uppercase tracking-wide text-muted-foreground">Proposed by the AI</div>
                <div className="flex flex-wrap gap-1.5">
                  {data.proposed.map((t) => (
                    <Badge key={t} variant="outline" className="gap-1 py-1">
                      {t}
                      <button className="inline-flex items-center gap-0.5 text-emerald-500 hover:underline"
                        onClick={() => api.tagsMasterAdd([t]).then(() => { toast.success(`Approved: ${t}`); reload(); })}>
                        <Check className="h-3 w-3" /> approve
                      </button>
                    </Badge>
                  ))}
                </div>
              </div>
            )}
            {data.near_duplicates.length > 0 && (
              <div>
                <div className="mb-1.5 text-xs font-semibold uppercase tracking-wide text-muted-foreground">Near-duplicate pairs (one letter apart)</div>
                <div className="flex flex-wrap gap-1.5">
                  {data.near_duplicates.map((p, i) => (
                    <Badge key={i} variant="outline" className="gap-1 py-1">
                      {p.tags[0]} ≈ {p.tags[1]}
                      <button className="text-primary hover:underline" onClick={() => {
                        setAction({ kind: "merge", tag: p.tags[0] });
                        setTarget(p.tags[1]);
                        runPreview("merge", p.tags[0], p.tags[1]);
                      }}>merge</button>
                    </Badge>
                  ))}
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      )}

      <div className="flex flex-wrap gap-2">
        {rows.map((r) => (
          <TagMenu
            key={r.tag}
            tag={r.tag}
            count={r.count}
            onAction={(kind) => {
              setAction({ kind, tag: r.tag });
              setTarget("");
            }}
          />
        ))}
        {rows.length === 0 && <div className="text-sm text-muted-foreground">No tags match “{filter}”.</div>}
      </div>

      {/* action dialog with preview */}
      <Dialog open={action !== null} onOpenChange={(v) => !v && setAction(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="capitalize">
              {action?.kind} tag “{action?.tag}”
            </DialogTitle>
          </DialogHeader>
          {action?.kind === "rename" && (
            <div className="space-y-2">
              <Label>New tag name</Label>
              <Input value={target} onChange={(e) => setTarget(e.target.value)} placeholder="NEW-tag" />
              <Button variant="outline" size="sm" disabled={!target.trim()} onClick={() => runPreview("rename", action.tag, target)}>
                Preview
              </Button>
            </div>
          )}
          {action?.kind === "merge" && (
            <div className="space-y-2">
              <Label>Merge into</Label>
              <SuggestInput value={target} onChange={(v) => { setTarget(v); }} kind="tag" />
              <Button variant="outline" size="sm" disabled={!target.trim()} onClick={() => runPreview("merge", action.tag, target)}>
                Preview
              </Button>
            </div>
          )}
          {action?.kind === "remove" && (
            <div className="text-sm text-muted-foreground">
              Removes “{action.tag}” from every note and from _tags.md. Preview first:
              <Button variant="outline" size="sm" className="ml-2" onClick={() => runPreview("remove", action.tag, "")}>Preview</Button>
            </div>
          )}
          {preview && (
            <div className="rounded-lg border bg-muted/40 p-3 text-sm">
              <div className="mb-1 font-medium">Preview — {preview.notes?.length ?? 0} note(s) affected</div>
              <div className="max-h-40 space-y-1 overflow-y-auto">
                {(preview.notes ?? []).map((n: any) => (
                  <div key={n.file} className="text-xs">
                    <span className="font-mono">{n.file}</span>: {n.old?.join(", ")} → <span className="text-primary">{n.new?.join(", ")}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => { setAction(null); setPreview(null); }}>Cancel</Button>
            <Button disabled={!preview} onClick={runApply}>Apply everywhere</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* master editor */}
      <Dialog open={masterOpen} onOpenChange={setMasterOpen}>
        <DialogContent wide>
          <DialogHeader><DialogTitle>_tags.md — the master vocabulary</DialogTitle></DialogHeader>
          <textarea
            value={masterText}
            onChange={(e) => setMasterText(e.target.value)}
            className="h-96 w-full rounded-lg border border-input bg-transparent p-3 font-mono text-xs"
            spellCheck={false}
          />
          <DialogFooter>
            <Button variant="outline" onClick={() => setMasterOpen(false)}>Cancel</Button>
            <Button onClick={() => api.tagsMasterSave(masterText).then(() => { setMasterOpen(false); reload(); toast.success("Master tag list saved"); }).catch((e) => toast.error(e.message))}>
              Save
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function TagMenu({ tag, count, onAction }: { tag: string; count: number; onAction: (kind: "rename" | "merge" | "remove") => void }) {
  const [open, setOpen] = useState(false);
  const [notes, setNotes] = useState<{ path: string; title: string; folder: string }[] | null>(null);

  return (
    <div className="relative">
      <button
        className="flex items-center gap-1.5 rounded-full border bg-card px-3 py-1.5 text-sm shadow-sm transition-all hover:-translate-y-0.5 hover:border-primary/50"
        onClick={() => {
          if (!open) api.tagNotes(tag).then((r) => setNotes(r.notes));
          setOpen(!open);
        }}
      >
        <TagIcon className="h-3.5 w-3.5 text-primary" />
        {tag}
        <span className="text-xs text-muted-foreground">{count}</span>
      </button>
      {open && (
        <div className="absolute left-0 top-full z-40 mt-1 w-80 rounded-xl border bg-popover p-3 shadow-xl animate-in fade-in">
          <div className="mb-2 flex items-center justify-between">
            <span className="text-sm font-semibold">{tag}</span>
            <div className="flex gap-1">
              <Button variant="ghost" size="iconSm" title="Rename everywhere" onClick={() => { setOpen(false); onAction("rename"); }}><PenLine className="h-3.5 w-3.5" /></Button>
              <Button variant="ghost" size="iconSm" title="Merge into another tag" onClick={() => { setOpen(false); onAction("merge"); }}><Merge className="h-3.5 w-3.5" /></Button>
              <Button variant="ghost" size="iconSm" title="Remove everywhere" onClick={() => { setOpen(false); onAction("remove"); }}><Trash2 className="h-3.5 w-3.5 text-destructive" /></Button>
            </div>
          </div>
          <div className="max-h-48 space-y-0.5 overflow-y-auto">
            {notes === null ? "…" : notes.map((n) => (
              <Link key={n.path} to={noteHref(n.path)} onClick={() => setOpen(false)}
                className="flex items-center gap-2 rounded-md px-2 py-1.5 text-sm hover:bg-accent">
                <FileText className="h-3.5 w-3.5 text-muted-foreground" />
                <span className="truncate">{n.title}</span>
              </Link>
            ))}
            {notes?.length === 0 && <div className="text-xs text-muted-foreground">No notes carry this tag yet.</div>}
          </div>
        </div>
      )}
    </div>
  );
}
