# Master Tag Vocabulary

Tags are written `MAJOR-sub-subsub`. A dash separates levels, an underscore
stands for a space, and a comma separates entries in `tags.txt`. Matching
ignores capital letters; by convention major tags are written in capitals.
A deep tag also counts for its parents: a note tagged
`FOOD-pasta-vegetarian` is also found by `FOOD-pasta` and by `FOOD`.

A tag that is not listed under **Approved tags** below is flagged by the
auto tag extractor and cannot be picked in search. The AI proposes new tags
under **Proposed tags**; they become usable once you approve them by moving
them up here.

## Approved tags

### TEST

### COOKING
- COOKING-weeknight: weeknight, weekday dinner, quick dinner
- COOKING-baking: bake, baking
- COOKING-lunchbox: lunchbox

### FOOD
- FOOD-pasta: pasta, noodles
- FOOD-pasta-vegetarian: vegetarian pasta
- FOOD-soup: soup, broth, stew
- FOOD-bread: bread, loaf
- FOOD-garlic: garlic
- FOOD-salad: salad

### INGREDIENT
- INGREDIENT-garlic: garlic clove
- INGREDIENT-lentils: lentil, lentils, dal
- INGREDIENT-tomato: tomato, tomatoes
- INGREDIENT-basil: basil

### METHOD
- METHOD-stovetop-one_pot: one pot, stovetop
- METHOD-oven: oven, roast

### SEASON
- SEASON-spring: spring
- SEASON-autumn: autumn, fall

### LANGUAGE
- LANGUAGE-spanish-vocabulary: spanish words, spanish vocab
- LANGUAGE-english-vocabulary: english words

### LEARNING
- LEARNING-vocabulary: vocabulary, words, terms
- LEARNING-grammar: grammar

### PROJECT
- PROJECT-secondbrain: secondbrain, second brain
- PROJECT-garden: garden, gardening

### TOOL
- TOOL-markdown: markdown
- TOOL-python: python

### PLANT
- PLANT-tomato: tomato plant, tomatoes
- PLANT-basil: basil plant

## Synonyms

General search synonyms, one line per word: `word: synonym, synonym`.
The user's own words count fully; synonyms count 0.7 (spec 3.3).

- quick: fast, rapid, speedy
- recipe: dish, meal
- vegetable: veggie
- image: photo, picture
- word: vocabulary, term
- fix: repair
- soup: broth, stew
- cook: make, prepare

## Proposed tags

New tags proposed by the AI land here and become usable once you approve
them (move them under **Approved tags**). Empty right now.