//! SecondBrain backup CLI (Rust, v4) — byte-identical backup / restore /
//! verify. Usage:
//!   secondbrain-backup --to /path/to/backup --direction backup --scope whole --yes
//!   secondbrain-backup --to /path/to/backup --direction restore --yes
//!   secondbrain-backup --to /path/to/backup --verify

use sbcore::{backup as bk, paths};

fn main() {
    let args: Vec<String> = std::env::args().collect();
    let mut to: Option<String> = None;
    let mut direction = "backup".to_string();
    let mut scope = "whole".to_string();
    let mut keep = 10usize;
    let mut yes = false;
    let mut verify = false;
    let mut it = args.iter().skip(1);
    while let Some(a) = it.next() {
        match a.as_str() {
            "--to" => to = it.next().map(String::from),
            "--direction" => direction = it.next().unwrap_or(&"backup".to_string()).clone(),
            "--scope" => scope = it.next().unwrap_or(&"whole".to_string()).clone(),
            "--keep" => keep = it.next().and_then(|v| v.parse().ok()).unwrap_or(10),
            "--yes" | "-y" => yes = true,
            "--verify" => verify = true,
            "--help" | "-h" => {
                println!("Usage: secondbrain-backup --to <folder OUTSIDE the project> [--direction backup|restore] [--scope whole|database|inbox|logs|<rel>] [--keep N] [--yes] [--verify]");
                std::process::exit(0);
            }
            _ => {}
        }
    }

    let to = match to {
        Some(t) => t,
        None => {
            eprintln!("Error: --to is required (a folder OUTSIDE the project).");
            std::process::exit(2);
        }
    };
    let target = match bk::resolve_target(&to) {
        Ok(t) => t,
        Err(e) => {
            eprintln!("Error: {e}");
            std::process::exit(2);
        }
    };

    if verify {
        match bk::verify(&target, &scope) {
            Ok(rep) => {
                println!("{}", serde_json::to_string(&rep).unwrap_or_default());
                let identical = rep["identical"].as_bool().unwrap_or(false);
                std::process::exit(if identical { 0 } else { 1 });
            }
            Err(e) => {
                eprintln!("Error: {e}");
                std::process::exit(2);
            }
        }
    }

    // Preview first, always.
    let (src_m, dst_m) = match direction.as_str() {
        "restore" => (
            bk::manifest(&target, &scope).expect("manifest"),
            bk::manifest(paths::ROOT.as_path(), &scope).expect("manifest"),
        ),
        _ => (
            bk::manifest(paths::ROOT.as_path(), &scope).expect("manifest"),
            bk::manifest(&target, &scope).expect("manifest"),
        ),
    };
    let cmp = bk::compare(&src_m, &dst_m);
    println!("Preview ({direction}, scope {scope}):");
    println!("{}", serde_json::to_value(&cmp).map(|v| bk::preview(&v)).unwrap_or_default().as_str().unwrap_or("").to_string());
    if !yes {
        println!("\nDry run only: pass --yes to apply.");
        return;
    }

    let opts = bk::RunOptions {
        direction: &direction,
        target: &target,
        scope: &scope,
        keep,
        who: "user",
    };
    match bk::run(&opts) {
        Ok(rep) => {
            println!("{}", serde_json::to_string(&rep).unwrap_or_default());
                    let identical = rep["identical"].as_bool().unwrap_or(false);
            std::process::exit(if identical { 0 } else { 1 });
        }
        Err(e) => {
            eprintln!("Error: {e}");
            std::process::exit(2);
        }
    }
}
