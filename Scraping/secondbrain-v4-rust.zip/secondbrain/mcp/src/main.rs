//! SecondBrain MCP server (Rust, v4).
//!
//! A thin layer over the core engine: the same parser, the same search
//! engine and the same store as the website, so the AI has every capability
//! the user has — nothing hidden and nothing missing.
//!
//! Transport: newline-delimited JSON-RPC 2.0 on stdio (the standard MCP
//! stdio transport). Methods: initialize, tools/list, tools/call, ping.
//!
//! Run from an MCP client config:
//!   {"command": "/path/to/secondbrain/target/release/secondbrain-mcp"}
//!
//! v4 rules enforced in the engine:
//! - paths outside the allowed structure are refused,
//! - ALL TAGS ARE INDEPENDENT — a tag used on any note is added to the
//!   Approved tags of _tags.md at once,
//! - every write is recorded in the internal undo journal; the ONLY thing
//!   written automatically to logs/ is the note-edit history (logs/edits.md
//!   — which note, which lines added/removed). Manual log entries (the AI's
//!   included) go through `add_log_entry`,
//! - 'My notes' is append-only,
//! - the AI must ask before creating a new folder: the tools answer
//!   needs_approval=true until approve_new_folder=true is sent.

use sbcore::{backup as bk, editlog, error::Result, healthcheck, images, indexer, logger, parser, paths, search, store, tags as tags_mod, textutil::key_of, SbError};
use serde_json::{json, Value};
use std::collections::HashMap;
use std::io::{BufRead, Write};

const PROTOCOL_VERSION: &str = "2024-11-05";

// --------------------------------------------------------------------------
// Tool implementations
// --------------------------------------------------------------------------

fn resolve_note(path_or_name: &str) -> Result<String> {
    let p = store::note_md_path(path_or_name);
    if p.exists() {
        return Ok(paths::rel(&p));
    }
    if let Some(found) = store::note_exists(path_or_name) {
        return Ok(paths::rel(&found));
    }
    Err(SbError::NotFound(format!(
        "Note {path_or_name:?} not found in this wiki."
    )))
}

fn ensure_folder(folder_rel: &str, approve_new_folder: bool) -> Result<Option<Value>> {
    if folder_rel.trim().is_empty() {
        return Ok(None);
    }
    let folder = paths::safe_join_rel(paths::DATABASE.as_path(), folder_rel)?;
    if !folder.exists() {
        if !approve_new_folder {
            return Ok(Some(json!({
                "needs_approval": true,
                "question": format!(
                    "The folder {folder_rel:?} does not exist. The AI must ask before creating a new folder. Ask the user; if they approve, call again with approve_new_folder=true."
                ),
            })));
        }
        let parts: Vec<&str> = folder_rel.split('/').filter(|s| !s.is_empty()).collect();
        let (parent, leaf) = parts.split_at(parts.len().saturating_sub(1));
        store::create_folder(&parent.join("/"), leaf.first().unwrap_or(&""), "ai", None)?;
    }
    Ok(None)
}

fn t_search_notes(a: &Value) -> Result<Value> {
    let idx = indexer::load_index()?;
    let arr = |k: &str| -> Vec<String> {
        a.get(k)
            .and_then(|v| v.as_array())
            .map(|x| x.iter().filter_map(|s| s.as_str().map(String::from)).collect())
            .unwrap_or_default()
    };
    Ok(search::search(
        &idx,
        a.get("query").and_then(|v| v.as_str()).unwrap_or(""),
        a.get("mode").and_then(|v| v.as_str()).unwrap_or("rank"),
        &arr("tags"),
        &arr("folders"),
        a.get("folder_only").and_then(|v| v.as_bool()).unwrap_or(false),
        &{
            let sc = arr("scope");
            if sc.is_empty() { vec!["everything".to_string()] } else { sc }
        },
        a.get("tag_mode").and_then(|v| v.as_str()).unwrap_or("rank"),
        a.get("keyword_mode").and_then(|v| v.as_str()).unwrap_or("rank"),
        a.get("include_connected").and_then(|v| v.as_bool()).unwrap_or(false),
        a.get("status").and_then(|v| v.as_str()),
        a.get("date_from").and_then(|v| v.as_str()),
        a.get("date_to").and_then(|v| v.as_str()),
        &arr("limit_to"),
        a.get("offset").and_then(|v| v.as_i64()).unwrap_or(0).max(0) as usize,
        a.get("page_size").and_then(|v| v.as_i64()).map(|v| v.max(1) as usize),
    ))
}

fn t_suggest_tags(a: &Value) -> Result<Value> {
    store::suggest(
        a.get("query").and_then(|v| v.as_str()).unwrap_or(""),
        a.get("kind").and_then(|v| v.as_str()).unwrap_or("all"),
    )
}

fn t_list_tags(_a: &Value) -> Result<Value> {
    let ext = tags_mod::extract_all_notes_tags()?;
    let mt = tags_mod::load_master()?;
    Ok(json!({
        "tree": ext["tree"],
        "counts": ext["counts"],
        "unapproved": ext["unapproved"],
        "proposed": ext["proposed"],
        "near_duplicates": ext["near_duplicates"],
        "used_once": ext["used_once"],
        "approved": mt.all_tags(),
    }))
}

fn t_list_folders(_a: &Value) -> Result<Value> {
    Ok(json!({
        "tree": store::folder_tree(),
        "subjects": store::list_subjects(),
    }))
}

fn t_read_note(a: &Value) -> Result<Value> {
    let rp = resolve_note(a.get("path").and_then(|v| v.as_str()).or_else(|| a.get("name").and_then(|v| v.as_str())).unwrap_or(""))?;
    let p = paths::ROOT.join(&rp);
    let idx = indexer::load_index()?;
    let text = std::fs::read_to_string(&p)?;
    let doc = parser::parse_note(&text, &rp);
    let tags_file = p.parent().unwrap().join("tags.txt");
    let note_tags = if tags_file.exists() {
        tags_mod::parse_tags_txt(&std::fs::read_to_string(&tags_file)?)?
    } else {
        Vec::new()
    };
    let folder = idx.files.get(&rp).map(|e| e.folder.clone()).unwrap_or_default();
    Ok(json!({
        "path": rp,
        "name": doc.title,
        "raw": doc.raw,
        "hash": store::text_sha256(&doc.raw),
        "folder": folder,
        "tags": note_tags,
        "meta": doc.meta,
        "quick_info_rows": doc.quick_info_rows.iter().map(|r| json!({
            "label": r.label, "value": r.value, "group": r.group,
        })).collect::<Vec<_>>(),
        "tasks": store::note_tasks(&rp, None),
        "connected": doc.connected,
        "references": doc.references,
        "incoming": idx.backlinks.get(&rp).cloned().unwrap_or_default(),
        "broken_links": idx.broken_links.get(&rp).cloned().unwrap_or_default(),
    }))
}

fn t_get_connections(a: &Value) -> Result<Value> {
    let rp = resolve_note(a.get("path").and_then(|v| v.as_str()).unwrap_or(""))?;
    let idx = indexer::load_index()?;
    let text = std::fs::read_to_string(paths::ROOT.join(&rp))?;
    let doc = parser::parse_note(&text, &rp);
    let titles: std::collections::HashSet<String> =
        idx.files.values().map(|e| key_of(&e.title)).collect();
    Ok(json!({
        "connected": doc.connected.iter().map(|t| json!({
            "name": t, "exists": titles.contains(&key_of(t)),
        })).collect::<Vec<_>>(),
        "linked_in_text": doc.linked_in_text.iter().map(|(t, w)| json!({"target": t, "word": w})).collect::<Vec<_>>(),
        "backlinks": idx.backlinks.get(&rp).cloned().unwrap_or_default(),
        "references": doc.references,
    }))
}

fn t_create_note(a: &Value) -> Result<Value> {
    let folder = a.get("folder").and_then(|v| v.as_str()).unwrap_or("");
    if let Some(gate) = ensure_folder(folder, a.get("approve_new_folder").and_then(|v| v.as_bool()).unwrap_or(false))? {
        return Ok(gate);
    }
    let tags: Vec<String> = a
        .get("tags")
        .and_then(|v| v.as_array())
        .map(|x| x.iter().filter_map(|s| s.as_str().map(String::from)).collect())
        .unwrap_or_default();
    store::create_note(
        folder,
        a.get("name").and_then(|v| v.as_str()).unwrap_or(""),
        Some(&tags),
        a.get("text").and_then(|v| v.as_str()),
        a.get("quick_info").and_then(|v| v.as_str()),
        "ai",
        a.get("reason").and_then(|v| v.as_str()).unwrap_or(""),
    )
}

fn t_edit_note(a: &Value) -> Result<Value> {
    let rp = resolve_note(a.get("path").and_then(|v| v.as_str()).unwrap_or(""))?;
    store::save_note_text(
        &rp,
        a.get("text").and_then(|v| v.as_str()).unwrap_or(""),
        a.get("base_hash").and_then(|v| v.as_str()),
        "ai",
        a.get("force").and_then(|v| v.as_bool()).unwrap_or(false),
        a.get("reason").and_then(|v| v.as_str()).unwrap_or(""),
    )
}

fn t_append_my_notes(a: &Value) -> Result<Value> {
    let rp = resolve_note(a.get("path").and_then(|v| v.as_str()).unwrap_or(""))?;
    store::append_to_my_notes(
        &rp,
        a.get("text").and_then(|v| v.as_str()).unwrap_or(""),
        "ai",
        a.get("reason").and_then(|v| v.as_str()).unwrap_or(""),
    )
}

fn t_move_note(a: &Value) -> Result<Value> {
    let rp = resolve_note(a.get("path").and_then(|v| v.as_str()).unwrap_or(""))?;
    if let Some(folder) = a.get("folder").and_then(|v| v.as_str()) {
        if !folder.is_empty() && !paths::DATABASE.join(folder).exists() {
            if let Some(gate) = ensure_folder(folder, true)? {
                return Ok(gate);
            }
        }
    }
    store::move_note(
        &rp,
        a.get("folder").and_then(|v| v.as_str()).unwrap_or(""),
        a.get("name").and_then(|v| v.as_str()),
        "ai",
    )
}

fn t_rename_note(a: &Value) -> Result<Value> {
    let rp = resolve_note(a.get("path").and_then(|v| v.as_str()).unwrap_or(""))?;
    store::move_note(
        &rp,
        "",
        a.get("name").and_then(|v| v.as_str()).map(|s| s.to_string()).as_deref(),
        "ai",
    )
}

fn t_edit_tags(a: &Value) -> Result<Value> {
    let rp = resolve_note(a.get("path").and_then(|v| v.as_str()).unwrap_or(""))?;
    let arr = |k: &str| -> Option<Vec<String>> {
        a.get(k)
            .and_then(|v| v.as_array())
            .map(|x| x.iter().filter_map(|s| s.as_str().map(String::from)).collect())
    };
    store::edit_tags(&rp, arr("add"), arr("remove"), "ai")
}

fn t_connect_notes(a: &Value) -> Result<Value> {
    let rp = resolve_note(a.get("path").and_then(|v| v.as_str()).unwrap_or(""))?;
    let arr = |k: &str| -> Option<Vec<String>> {
        a.get(k)
            .and_then(|v| v.as_array())
            .map(|x| x.iter().filter_map(|s| s.as_str().map(String::from)).collect())
    };
    store::edit_connections(&rp, arr("add"), arr("remove"), a.get("edit_link"), "ai")
}

fn t_add_reference(a: &Value) -> Result<Value> {
    let rp = resolve_note(a.get("path").and_then(|v| v.as_str()).unwrap_or(""))?;
    store::edit_references(
        &rp,
        a.get("add"),
        a.get("remove_url").and_then(|v| v.as_str()),
        "ai",
    )
}

fn t_edit_quick_info(a: &Value) -> Result<Value> {
    let rp = resolve_note(a.get("path").and_then(|v| v.as_str()).unwrap_or(""))?;
    store::set_quick_info(&rp, a.get("text").and_then(|v| v.as_str()), "ai")
}

fn t_add_attachment(a: &Value) -> Result<Value> {
    use base64::Engine;
    let rp = resolve_note(a.get("path").and_then(|v| v.as_str()).unwrap_or(""))?;
    let data = a
        .get("data_base64")
        .and_then(|v| v.as_str())
        .and_then(|s| base64::engine::general_purpose::STANDARD.decode(s).ok())
        .ok_or_else(|| SbError::Invalid("Missing or invalid data_base64.".into()))?;
    images::add_attachment(
        &rp,
        a.get("filename").and_then(|v| v.as_str()).unwrap_or(""),
        &data,
        "ai",
    )
}

fn t_edit_links(a: &Value) -> Result<Value> {
    let rp = resolve_note(a.get("path").and_then(|v| v.as_str()).unwrap_or(""))?;
    store::edit_links(
        &rp,
        a.get("word").and_then(|v| v.as_str()).unwrap_or(""),
        a.get("target").and_then(|v| v.as_str()),
        a.get("make_note").and_then(|v| v.as_bool()).unwrap_or(true),
        "ai",
    )
}

fn t_edit_metadata(a: &Value) -> Result<Value> {
    let rp = resolve_note(a.get("path").and_then(|v| v.as_str()).unwrap_or(""))?;
    store::set_metadata(&rp, a.get("meta").unwrap_or(&json!({})), "ai")
}

fn t_export_metadata(a: &Value) -> Result<Value> {
    let rp = resolve_note(a.get("path").and_then(|v| v.as_str()).unwrap_or(""))?;
    Ok(json!({"path": rp, "text": store::export_metadata(&rp)?}))
}

fn t_crop_image(a: &Value) -> Result<Value> {
    let rp = resolve_note(a.get("path").and_then(|v| v.as_str()).unwrap_or(""))?;
    images::crop_image(
        &rp,
        a.get("filename").and_then(|v| v.as_str()).unwrap_or(""),
        a.get("rect").unwrap_or(&json!({})),
        a.get("mode").and_then(|v| v.as_str()).unwrap_or("keep_both"),
        "ai",
    )
}

fn t_delete_image(a: &Value) -> Result<Value> {
    let rp = resolve_note(a.get("path").and_then(|v| v.as_str()).unwrap_or(""))?;
    images::delete_image(
        &rp,
        a.get("filename").and_then(|v| v.as_str()).unwrap_or(""),
        "ai",
    )
}

fn t_rename_tag(a: &Value) -> Result<Value> {
    store::rename_tag(
        a.get("from").and_then(|v| v.as_str()).unwrap_or(""),
        a.get("to").and_then(|v| v.as_str()).unwrap_or(""),
        "ai",
        a.get("run").and_then(|v| v.as_bool()).unwrap_or(false),
    )
}

fn t_merge_tags(a: &Value) -> Result<Value> {
    store::merge_tags(
        a.get("from").and_then(|v| v.as_str()).unwrap_or(""),
        a.get("into").and_then(|v| v.as_str()).unwrap_or(""),
        "ai",
        a.get("run").and_then(|v| v.as_bool()).unwrap_or(false),
    )
}

fn t_health_check(_a: &Value) -> Result<Value> {
    let idx = indexer::load_index()?;
    Ok(healthcheck::health_check(&idx))
}

fn t_health_fix(a: &Value) -> Result<Value> {
    healthcheck::health_fix(
        a.get("action").and_then(|v| v.as_str()).unwrap_or(""),
        a.get("params").unwrap_or(&json!({})),
        "ai",
    )
}

fn t_toggle_task(a: &Value) -> Result<Value> {
    let rp = resolve_note(a.get("path").and_then(|v| v.as_str()).unwrap_or(""))?;
    store::toggle_task(
        &rp,
        a.get("index").and_then(|v| v.as_i64()).unwrap_or(0).max(0) as usize,
        "ai",
        None,
    )
}

fn backup_target(a: &Value) -> Result<std::path::PathBuf> {
    let target = a
        .get("to")
        .and_then(|v| v.as_str())
        .map(String::from)
        .or_else(|| {
            store::load_settings()
                .get("backup_destination")
                .and_then(|v| v.as_str())
                .map(String::from)
        })
        .ok_or_else(|| {
            SbError::Invalid(
                "No backup folder given. Pass 'to' (a folder OUTSIDE the project) or set backup_destination in core/settings.json.".into(),
            )
        })?;
    bk::resolve_target(&target)
}

fn t_backup_preview(a: &Value) -> Result<Value> {
    let t = backup_target(a)?;
    let scope = a.get("scope").and_then(|v| v.as_str()).unwrap_or("whole");
    let direction = a.get("direction").and_then(|v| v.as_str()).unwrap_or("backup");
    let (src_m, dst_m) = match direction {
        "restore" => (bk::manifest(&t, scope)?, bk::manifest(paths::ROOT.as_path(), scope)?),
        _ => (bk::manifest(paths::ROOT.as_path(), scope)?, bk::manifest(&t, scope)?),
    };
    let cmp = bk::compare(&src_m, &dst_m);
    Ok(json!({
        "direction": direction, "to": t.to_string_lossy(), "scope": scope,
        "counts": {
            "unchanged": cmp["unchanged"].as_array().map(|a| a.len()).unwrap_or(0),
            "changed": cmp["changed"].as_array().map(|a| a.len()).unwrap_or(0),
            "new": cmp["new"].as_array().map(|a| a.len()).unwrap_or(0),
            "removed": cmp["removed"].as_array().map(|a| a.len()).unwrap_or(0),
            "moved": cmp["moved"].as_array().map(|a| a.len()).unwrap_or(0),
        },
        "preview": bk::preview(&cmp),
    }))
}

fn t_backup_run(a: &Value) -> Result<Value> {
    let t = backup_target(a)?;
    let opts = bk::RunOptions {
        direction: a.get("direction").and_then(|v| v.as_str()).unwrap_or("backup"),
        target: &t,
        scope: a.get("scope").and_then(|v| v.as_str()).unwrap_or("whole"),
        keep: a.get("keep").and_then(|v| v.as_u64()).unwrap_or(10) as usize,
        who: "AI",
    };
    bk::run(&opts)
}

fn t_backup_restore(a: &Value) -> Result<Value> {
    let mut a = a.clone();
    if let Some(obj) = a.as_object_mut() {
        obj.insert("direction".into(), json!("restore"));
    }
    t_backup_run(&a)
}

fn t_backup_verify(a: &Value) -> Result<Value> {
    let t = backup_target(a)?;
    bk::verify(&t, a.get("scope").and_then(|v| v.as_str()).unwrap_or("whole"))
}

fn t_undo_change(a: &Value) -> Result<Value> {
    Ok(json!({"log": editlog::apply_undo(
        a.get("log").or_else(|| a.get("change")).and_then(|v| v.as_str()).unwrap_or(""),
        "ai",
    )?}))
}

fn t_saved_searches(a: &Value) -> Result<Value> {
    let action = a.get("action").and_then(|v| v.as_str()).unwrap_or("list");
    match action {
        "save" => store::save_search(
            a.get("name").and_then(|v| v.as_str()).unwrap_or(""),
            a.get("params").unwrap_or(&json!({})),
            "ai",
        ),
        "delete" => store::delete_saved_search(a.get("name").and_then(|v| v.as_str()).unwrap_or("")),
        "run" => {
            let idx = indexer::load_index()?;
            let params = a
                .get("params")
                .cloned()
                .or_else(|| {
                    store::saved_searches()
                        .into_iter()
                        .find(|x| x.get("name").and_then(|n| n.as_str()) == a.get("name").and_then(|n| n.as_str()))
                        .and_then(|x| x.get("params").cloned())
                })
                .unwrap_or(json!({}));
            let param_query = params
                .get("query")
                .and_then(|v| v.as_str())
                .unwrap_or("")
                .to_string();
            let get = |k: &str| params.get(k).cloned().unwrap_or(Value::Null);
            let arr = |k: &str| -> Vec<String> {
                get(k)
                    .as_array()
                    .map(|x| x.iter().filter_map(|s| s.as_str().map(String::from)).collect())
                    .unwrap_or_default()
            };
            Ok(search::search(
                &idx,
                a.get("query")
                    .and_then(|v| v.as_str())
                    .filter(|s| !s.is_empty())
                    .unwrap_or(&param_query),
                get("mode").as_str().unwrap_or("rank"),
                &arr("tags"),
                &arr("folders"),
                get("folder_only").as_bool().unwrap_or(false),
                &arr("scope"),
                get("tag_mode").as_str().unwrap_or("rank"),
                get("keyword_mode").as_str().unwrap_or("rank"),
                get("include_connected").as_bool().unwrap_or(false),
                get("status").as_str(),
                get("date_from").as_str(),
                get("date_to").as_str(),
                &arr("limit_to"),
                0,
                None,
            ))
        }
        _ => Ok(json!({"saved_searches": store::saved_searches()})),
    }
}

fn t_file_note(a: &Value) -> Result<Value> {
    let mut text = a.get("text").and_then(|v| v.as_str()).map(String::from);
    if text.is_none() {
        if let Some(inbox_file) = a.get("inbox_file").and_then(|v| v.as_str()) {
            let p = paths::safe_join_rel(paths::INBOX.as_path(), inbox_file)?;
            if !p.exists() {
                return Err(SbError::NotFound(format!("Inbox file {inbox_file:?} not found.")));
            }
            text = Some(std::fs::read_to_string(&p)?);
        }
    }
    let folder = a.get("folder").and_then(|v| v.as_str()).unwrap_or("");
    if let Some(gate) = ensure_folder(folder, a.get("approve_new_folder").and_then(|v| v.as_bool()).unwrap_or(false))? {
        return Ok(gate);
    }
    let tags: Vec<String> = a
        .get("tags")
        .and_then(|v| v.as_array())
        .map(|x| x.iter().filter_map(|s| s.as_str().map(String::from)).collect())
        .unwrap_or_default();
    store::file_note(
        text.as_deref().unwrap_or(""),
        a.get("name").and_then(|v| v.as_str()).unwrap_or(""),
        folder,
        Some(tags),
        "ai",
        a.get("reason").and_then(|v| v.as_str()).unwrap_or(""),
        a.get("approve_new_folder").and_then(|v| v.as_bool()).unwrap_or(false),
    )
}

fn t_get_structure(_a: &Value) -> Result<Value> {
    let read = |n: &str| -> String {
        std::fs::read_to_string(paths::ROOT.join(n)).unwrap_or_default()
    };
    Ok(json!({
        "allowed_structure": {
            "root_files": paths::ROOT_FILES,
            "top_folders": paths::TOP_FOLDERS,
            "note_folder": ["<Note Name>.md", "tags.txt", "attachments/"],
            "database": "Subject folders to any depth; optional _subject.md per folder (Purpose, Template, Sensitivity, Inherits).",
        },
        "README.md": read("README.md"),
        "StructureOFnotes.md": read("StructureOFnotes.md"),
    }))
}

fn t_approve_tags(a: &Value) -> Result<Value> {
    let mt = tags_mod::load_master()?;
    let mut approved: Vec<String> = Vec::new();
    let mut unknown: Vec<String> = Vec::new();
    for t in a
        .get("tags")
        .and_then(|v| v.as_array())
        .map(|x| x.iter().filter_map(|s| s.as_str().map(String::from)).collect::<Vec<_>>())
        .unwrap_or_default()
    {
        let t = tags_mod::validate_tag(&t)?;
        if mt.proposed.iter().any(|p| key_of(p) == key_of(&t)) {
            approved.push(t);
        } else if mt.has(&t) {
            approved.push(t);
        } else {
            unknown.push(t);
        }
    }
    let master_path = paths::ROOT.join("_tags.md");
    let old = std::fs::read_to_string(&master_path)?;
    let mut out: Vec<String> = Vec::new();
    for ln in old.lines() {
        let stripped = ln.trim();
        if let Some(entry) = stripped.strip_prefix("- ") {
            let cand = entry
                .split(':')
                .next()
                .unwrap_or("")
                .split(',')
                .next()
                .unwrap_or("")
                .trim();
            if approved.iter().any(|t| key_of(t) == key_of(cand))
                && mt.proposed.iter().any(|p| key_of(p) == key_of(cand))
            {
                continue;
            }
        }
        out.push(ln.to_string());
    }
    let mut new_text = out.join("\n");
    if !approved.is_empty() {
        new_text = tags_mod::reinsert_approved_into(&new_text, &approved);
    }
    if new_text != old {
        store::atomic_write(&master_path, &new_text)?;
        logger::new_log(
            "ai",
            &format!(
                "Approved tag{} {}",
                if approved.len() > 1 { "s" } else { "" },
                approved.join(", ")
            ),
            "- Moved from *Proposed tags* to *Approved tags* in `_tags.md` at the user's direction.",
        );
    }
    Ok(json!({"approved": approved, "unknown": unknown}))
}

fn t_add_log_entry(a: &Value) -> Result<Value> {
    // v4: the AI writes MANUAL log entries with its name + a title, exactly
    // like on the website Log page. Required after any structural change.
    let who = a
        .get("who")
        .and_then(|v| v.as_str())
        .filter(|s| !s.is_empty())
        .unwrap_or("AI");
    let name = logger::new_log(
        who,
        a.get("title").and_then(|v| v.as_str()).unwrap_or("Change"),
        a.get("details").and_then(|v| v.as_str()).unwrap_or(""),
    );
    Ok(json!({"ok": true, "file": name}))
}

fn t_get_edit_history(_a: &Value) -> Result<Value> {
    Ok(json!({"history": editlog::edit_history(100)}))
}

fn t_get_settings(_a: &Value) -> Result<Value> {
    Ok(json!({"settings": store::load_settings()}))
}

fn t_update_settings(a: &Value) -> Result<Value> {
    let mut s = store::load_settings();
    if let Some(settings) = a.get("settings").and_then(|v| v.as_object()) {
        if let Some(obj) = s.as_object_mut() {
            for (k, v) in settings {
                obj.insert(k.clone(), v.clone());
            }
        }
    }
    store::save_settings(&s)?;
    Ok(json!({"ok": true, "settings": s}))
}

fn t_list_notes(_a: &Value) -> Result<Value> {
    let idx = indexer::load_index()?;
    Ok(json!({
        "notes": idx.files.iter().map(|(rp, e)| json!({
            "path": rp, "title": e.title, "folder": e.folder,
            "tags": e.tags, "updated": e.updated, "pinned": e.pinned,
        })).collect::<Vec<_>>(),
        "total": idx.n,
    }))
}

// --------------------------------------------------------------------------
// Tool definitions
// --------------------------------------------------------------------------

fn s(props: Value) -> Value {
    json!({"type": "object", "properties": props})
}

fn s_req(props: Value, required: &[&str]) -> Value {
    json!({"type": "object", "properties": props, "required": required})
}

fn STR() -> Value { json!({"type": "string"}) }
fn BOOL() -> Value { json!({"type": "boolean"}) }
fn NUM() -> Value { json!({"type": "number"}) }
fn ARR_S() -> Value { json!({"type": "array", "items": {"type": "string"}}) }

type ToolFn = fn(&Value) -> Result<Value>;

struct Tool {
    name: &'static str,
    description: &'static str,
    schema: Value,
    func: ToolFn,
}

macro_rules! tool {
    ($name:expr, $desc:expr, $schema:expr, $func:expr) => {
        Tool { name: $name, description: $desc, schema: $schema, func: $func }
    };
}

fn tools() -> Vec<Tool> {
    let scope_enum = json!({"type": "array", "items": {"type": "string", "enum": [
        "everything", "file name", "tags", "headings", "body", "folder path"]}});
    vec![
        tool!("search_notes",
            "Run the full ranking search (same engine as the website). Returns ranked NOTES with score breakdowns, never text chunks. Modes: rank (default; tags/keywords only boost), strict_keyword (every query word required), strict_tag (all selected tags required).",
            s_req(json!({
                "query": STR(), "tags": ARR_S(), "folders": ARR_S(), "folder_only": BOOL(),
                "scope": scope_enum,
                "tag_mode": json!({"type": "string", "enum": ["rank", "require"]}),
                "keyword_mode": json!({"type": "string", "enum": ["rank", "require"]}),
                "mode": json!({"type": "string", "enum": ["rank", "strict_keyword", "strict_tag"]}),
                "include_connected": BOOL(), "status": STR(), "date_from": STR(), "date_to": STR(),
                "limit_to": ARR_S(), "offset": NUM(), "page_size": NUM(),
            }), &[]),
            t_search_notes),
        tool!("suggest_tags",
            "Type-ahead over existing tags, folders and NOTE NAMES (same as the website inputs). Only things that exist can be chosen; kind=note previews matching note titles.",
            s(json!({"query": STR(), "kind": json!({"type": "string", "enum": ["all", "tag", "folder", "note"]})})),
            t_suggest_tags),
        tool!("list_tags",
            "GET ALL TAG DATA: the flat tag list with usage counts, unapproved tags, near-duplicates, used-once tags and proposed tags.",
            s(json!({})),
            t_list_tags),
        tool!("list_folders",
            "The subject folder tree with note counts; private folders marked.",
            s(json!({})),
            t_list_folders),
        tool!("list_subjects", "Alias of list_folders: the subject folder tree.", s(json!({})), t_list_folders),
        tool!("list_notes",
            "Every note in the wiki with path, title, folder, tags, updated date and pinned flag.",
            s(json!({})),
            t_list_notes),
        tool!("read_note",
            "The full text and metadata of one note (by rel path or unique note name).",
            s_req(json!({"path": STR(), "name": STR()}), &["path"]),
            t_read_note),
        tool!("get_connections",
            "GET ALL CONNECTION DATA of a note: connected notes (out), incoming links (in), links written in text, and the reference sources.",
            s_req(json!({"path": STR()}), &["path"]),
            t_get_connections),
        tool!("file_note",
            "The librarian's main tool: file a raw note (text or an inbox file) into the deepest matching folder, or add the material to an existing note. Asks before creating a folder; tags used are synced into the master list automatically.",
            s_req(json!({"name": STR(), "text": STR(), "inbox_file": STR(), "folder": STR(), "tags": ARR_S(), "reason": STR(), "approve_new_folder": BOOL()}), &["name"]),
            t_file_note),
        tool!("create_note",
            "Note making: create a note (folder with <Note Name>.md, tags.txt and attachments/). New folders need approve_new_folder=true after asking the user.",
            s_req(json!({"name": STR(), "folder": STR(), "text": STR(), "tags": ARR_S(), "quick_info": STR(), "reason": STR(), "approve_new_folder": BOOL()}), &["name"]),
            t_create_note),
        tool!("edit_note",
            "Edit a note's raw Markdown. 'My notes' is append-only; existing lines cannot be changed. Pass base_hash (from read_note) to detect concurrent edits.",
            s_req(json!({"path": STR(), "text": STR(), "base_hash": STR(), "force": BOOL(), "reason": STR()}), &["path", "text"]),
            t_edit_note),
        tool!("append_my_notes",
            "Append a line/entry at the end of the user's 'My notes' section (the only allowed change there).",
            s_req(json!({"path": STR(), "text": STR(), "reason": STR()}), &["path", "text"]),
            t_append_my_notes),
        tool!("move_note",
            "Move a note to another folder and/or rename it; every link to it is rewritten.",
            s_req(json!({"path": STR(), "folder": STR(), "name": STR()}), &["path"]),
            t_move_note),
        tool!("rename_note", "Rename a note (stays in its folder); links rewritten.",
            s_req(json!({"path": STR(), "name": STR()}), &["path", "name"]),
            t_rename_note),
        tool!("edit_tags",
            "Add or remove tags on a note. Tags are independent flat names; any tag used is added to the Approved tags of _tags.md at once.",
            s_req(json!({"path": STR(), "add": ARR_S(), "remove": ARR_S(), "reason": STR()}), &["path"]),
            t_edit_tags),
        tool!("connect_notes",
            "Add/remove connected notes ([[File Name]] lines) or edit a link written in text (change target or unlink).",
            s_req(json!({"path": STR(), "add": ARR_S(), "remove": ARR_S(),
                "edit_link": json!({"type": "object", "properties": {"target": STR(), "word": STR(), "new_target": STR(), "unlink": BOOL()}}),
            }), &["path"]),
            t_connect_notes),
        tool!("add_reference",
            "Add or remove a reference source ([Title](url) with the date accessed).",
            s_req(json!({"path": STR(), "add": json!({"type": "object", "properties": {"title": STR(), "url": STR(), "accessed": STR()}, "required": ["url"]}), "remove_url": STR()}), &["path"]),
            t_add_reference),
        tool!("edit_quick_info",
            "Replace the note's quick info block (the raw text between :::quick-info and :::).",
            s_req(json!({"path": STR(), "text": STR()}), &["path", "text"]),
            t_edit_quick_info),
        tool!("add_attachment",
            "Add an image to a note's attachments/ folder (base64 data).",
            s_req(json!({"path": STR(), "filename": STR(), "data_base64": STR()}), &["path", "filename", "data_base64"]),
            t_add_attachment),
        tool!("edit_links",
            "Change which words are a link and where it points (make_note=true for a wiki link, false for a web address), or remove the link and keep the words (target=null).",
            s_req(json!({"path": STR(), "word": STR(), "target": STR(), "make_note": BOOL()}), &["path", "word"]),
            t_edit_links),
        tool!("edit_metadata",
            "Change the note's metadata block (Created, Updated, Pinned, ...).",
            s_req(json!({"path": STR(), "meta": json!({"type": "object"})}), &["path"]),
            t_edit_metadata),
        tool!("export_metadata",
            "The per-note plain-text export: file name, exact file location, tags on the note, every tag used in the wiki with counts, dates, connected notes (both directions), references and attachments.",
            s_req(json!({"path": STR()}), &["path"]),
            t_export_metadata),
        tool!("crop_image",
            "Crop an image. The crop is saved as a NEW image; mode 'replace' backs the original up first, 'keep_both' keeps both.",
            s_req(json!({"path": STR(), "filename": STR(),
                "rect": json!({"type": "object", "properties": {"x": NUM(), "y": NUM(), "w": NUM(), "h": NUM()}}),
                "mode": json!({"type": "string", "enum": ["replace", "keep_both"]}),
            }), &["path", "filename", "rect"]),
            t_crop_image),
        tool!("delete_image",
            "Delete an image; warns when the note still points to it and keeps the old file in backup history.",
            s_req(json!({"path": STR(), "filename": STR()}), &["path", "filename"]),
            t_delete_image),
        tool!("rename_tag",
            "Rename a tag everywhere. Returns a preview of every affected note first; run=true writes.",
            s_req(json!({"from": STR(), "to": STR(), "run": BOOL()}), &["from", "to"]),
            t_rename_tag),
        tool!("merge_tags",
            "Merge one tag into another across all notes, with preview; run=true writes.",
            s_req(json!({"from": STR(), "into": STR(), "run": BOOL()}), &["from", "into"]),
            t_merge_tags),
        tool!("approve_tags",
            "The user approved proposed tags: move them from *Proposed tags* to *Approved tags* in _tags.md.",
            s_req(json!({"tags": ARR_S()}), &["tags"]),
            t_approve_tags),
        tool!("health_check",
            "GET HEALTH DATA: broken links, notes with no tags, tags used once, near-duplicate tags, notes with no connections, files outside the allowed structure. Every check is fault-isolated; fixable findings say so.",
            s(json!({})),
            t_health_check),
        tool!("get_health_data",
            "Alias of health_check: the full health report of the notes system as JSON.",
            s(json!({})),
            t_health_check),
        tool!("health_fix",
            "Apply one repair from the health check: remove_broken_links (note + link/links), remove_stray_attachment (note + file), fix_missing_dates (note), merge_tags (from + into), approve_tag (tag or tags).",
            s_req(json!({"action": STR(), "params": json!({"type": "object"})}), &["action"]),
            t_health_fix),
        tool!("toggle_task",
            "Tick or untick the Nth checklist item of a note (0-based, document order). Returns the new text and hash.",
            s_req(json!({"path": STR(), "index": NUM()}), &["path", "index"]),
            t_toggle_task),
        tool!("backup_preview",
            "Preview a backup run: what is unchanged, changed, new, removed or moved.",
            s(json!({"to": STR(), "scope": STR(), "direction": json!({"type": "string", "enum": ["backup", "restore"]})})),
            t_backup_preview),
        tool!("backup_run",
            "Run the backup: copy only changed/new files, move renamed ones, keep replaced files in .versions/, verify every hash.",
            s_req(json!({"to": STR(), "scope": STR(), "keep": NUM()}), &["to"]),
            t_backup_run),
        tool!("backup_restore",
            "Restore the project from a backup copy (same preview + hash check as backup_run).",
            s_req(json!({"to": STR(), "scope": STR(), "keep": NUM()}), &["to"]),
            t_backup_restore),
        tool!("backup_verify",
            "Verify that the backup copy matches the live project by SHA-256.",
            s_req(json!({"to": STR(), "scope": STR()}), &["to"]),
            t_backup_verify),
        tool!("undo_change",
            "Reverse a change using its journal id (from the undo journal; nothing reverses automatically).",
            s_req(json!({"log": STR()}), &["log"]),
            t_undo_change),
        tool!("saved_searches",
            "List, save, delete or run saved searches (query + folders + tags + modes).",
            s(json!({"action": json!({"type": "string", "enum": ["list", "save", "delete", "run"]}), "name": STR(), "params": json!({"type": "object"}), "query": STR()})),
            t_saved_searches),
        tool!("get_structure",
            "The allowed folder/file structure plus the full text of README.md and StructureOFnotes.md.",
            s(json!({})),
            t_get_structure),
        tool!("add_log_entry",
            "v4 LOG RULE: write a MANUAL log entry to logs/ under your name. You MUST call this after any structural change you make to the app (new feature, changed behavior, renamed tool). Nothing else writes logs automatically.",
            s_req(json!({"title": STR(), "details": STR(), "who": STR()}), &["title", "details"]),
            t_add_log_entry),
        tool!("get_edit_history",
            "The automatic note-edit history (logs/edits.md): which notes were edited and which lines were added/removed.",
            s(json!({})),
            t_get_edit_history),
        tool!("get_settings",
            "GET the current settings: ranking weights, coverage base, synonym weight, page size, typo tolerance, BM25 parameters, theme, server settings and saved searches.",
            s(json!({})),
            t_get_settings),
        tool!("update_settings",
            "CHANGE RANK / ADVANCED SETTINGS before searching: any subset of settings (e.g. ranking_weights, coverage_base, synonym_weight, page_size, typo_tolerance, typo_min_length, max_word_groups, closeness_window_tokens, bm25, default_theme, server_port). Changes take effect on the next search.",
            s_req(json!({"settings": json!({"type": "object"})}), &["settings"]),
            t_update_settings),
    ]
}

fn tool_defs() -> Value {
    json!(tools()
        .iter()
        .map(|t| json!({"name": t.name, "description": t.description, "inputSchema": t.schema}))
        .collect::<Vec<_>>())
}

// --------------------------------------------------------------------------
// JSON-RPC over stdio
// --------------------------------------------------------------------------

fn handle(msg: &Value) -> Option<Value> {
    let method = msg.get("method").and_then(|m| m.as_str()).unwrap_or("");
    let mid = msg.get("id").cloned();
    let is_notification = mid.is_none() || mid.as_ref() == Some(&Value::Null);
    let _err = |code: i64, message: String| -> Value {
        json!({"jsonrpc": "2.0", "id": mid, "error": {"code": code, "message": message}})
    };
    let result: Value = match method {
        "initialize" => {
            let requested = msg
                .get("params")
                .and_then(|p| p.get("protocolVersion"))
                .cloned()
                .unwrap_or(json!(PROTOCOL_VERSION));
            json!({
                "protocolVersion": requested,
                "capabilities": {"tools": {"listChanged": false}},
                "serverInfo": {"name": "secondbrain", "version": "4.0.0", "title": "SecondBrain librarian"},
            })
        }
        m if m.starts_with("notifications/") => return None,
        "ping" => json!({}),
        "tools/list" => json!({"tools": tool_defs()}),
        "tools/call" => {
            let params = msg.get("params").cloned().unwrap_or(json!({}));
            let name = params.get("name").and_then(|n| n.as_str()).unwrap_or("").to_string();
            let args = params.get("arguments").cloned().unwrap_or(json!({}));
            let tool = tools().into_iter().find(|t| t.name == name);
            match tool {
                None => return Some(_err(-32602, format!("Unknown tool: {name}"))),
                Some(t) => match (t.func)(&args) {
                    Ok(out) => {
                        let needs_approval =
                            out.get("needs_approval").and_then(|v| v.as_bool()).unwrap_or(false);
                        let text = serde_json::to_string_pretty(&out).unwrap_or_default();
                        json!({
                            "content": [{"type": "text", "text": text}],
                            "isError": needs_approval,
                        })
                    }
                    Err(e) => {
                        let is_needs = matches!(e, SbError::NeedsApproval { .. });
                        if is_needs {
                            let question = match e {
                                SbError::NeedsApproval { question } => question,
                                _ => String::new(),
                            };
                            json!({
                                "content": [{"type": "text", "text": serde_json::to_string_pretty(&json!({
                                    "needs_approval": true, "question": question,
                                })).unwrap_or_default()}],
                                "isError": true,
                            })
                        } else {
                            json!({
                                "content": [{"type": "text", "text": serde_json::to_string_pretty(&json!({
                                    "error": e.to_string(),
                                })).unwrap_or_default()}],
                                "isError": true,
                            })
                        }
                    }
                },
            }
        }
        "shutdown" | "exit" => std::process::exit(0),
        other => return Some(_err(-32601, format!("Method not found: {other}"))),
    };
    if is_notification {
        return None;
    }
    Some(json!({"jsonrpc": "2.0", "id": mid, "result": result}))
}

fn main() {
    let _ = indexer::load_index(); // warm the index once at startup
    let stdin = std::io::stdin();
    let mut stdout = std::io::stdout();
    for line in stdin.lock().lines() {
        let Ok(line) = line else { break };
        let line = line.trim();
        if line.is_empty() {
            continue;
        }
        let msg: Value = match serde_json::from_str(line) {
            Ok(m) => m,
            Err(_) => {
                let err = json!({"jsonrpc": "2.0", "id": null, "error": {"code": -32700, "message": "Parse error"}});
                writeln!(stdout, "{err}").ok();
                stdout.flush().ok();
                continue;
            }
        };
        match handle(&msg) {
            Some(reply) => {
                writeln!(stdout, "{reply}").ok();
                stdout.flush().ok();
            }
            None => continue,
        }
    }
}
