import { useCallback, useEffect, useRef, useState } from "react";
import { ArrowLeftRight, ChevronLeft, ChevronRight, Download, Expand, FileArchive, ImageDown, Loader2, Lock, Minus, MoveVertical, Plus, RefreshCw, Rows3, Shrink, Timer, X, MousePointerClick } from "lucide-react";
import type { FitMode, PageInfo, ReaderMode } from "@comiclib/shared";
import { api } from "@/lib/backend";
import { useStore } from "@/lib/store";
import { useBackClose } from "@/lib/hooks";
import { matchesShortcut } from "@/lib/shortcuts";
import { Button } from "@/components/ui/button";
import { cn } from "@/utils/cn";
import { PageImage } from "./PageImage";

const MODES: { value: ReaderMode; label: string; icon: React.ElementType }[] = [
  { value: "scroll", label: "Scroll", icon: Rows3 },
  { value: "paged", label: "Tap pages", icon: MousePointerClick },
  { value: "auto", label: "Auto", icon: Timer },
];
const MODE_HINT: Record<ReaderMode, string> = {
  scroll: "Continuous vertical scroll (pinch or double-tap to zoom)",
  paged: "Instant tap on narrow left/right edges to turn pages",
  auto: "Turns the page by itself; touch to pause",
};
const SECONDS = [3, 5, 8, 12, 20, 30, 60];
const MAX_ZOOM = 4;

/** Narrow, thick-thumb-friendly invisible edge tap zone width (56px..96px, ~18% viewport width). */
function edgeZoneWidth(viewportWidth: number): number {
  return Math.max(56, Math.min(96, Math.round(viewportWidth * 0.18)));
}

export function Reader() {
  const reader = useStore((s) => s.reader);
  if (!reader) return null;
  return <ReaderInner key={`${reader.id}:${reader.page}`} readerId={reader.id} initialPage={reader.page} />;
}

function ReaderInner({ readerId, initialPage }: { readerId: string; initialPage: number }) {
  const comic = useStore((s) => s.comics.find((c) => c.id === readerId));
  const settings = useStore((s) => s.settings);
  const setSettings = useStore((s) => s.setSettings);
  const close = useStore((s) => s.closeReader);
  const recordProgress = useStore((s) => s.recordProgress);
  const toast = useStore((s) => s.toast);
  const [pages, setPages] = useState<PageInfo[] | null>(null);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [index, setIndex] = useState(Math.max(0, initialPage));
  const [controls, setControls] = useState(true);
  const [locked, setLocked] = useState(false);
  const lockedRef = useRef(false);
  lockedRef.current = locked;
  const [exportOpen, setExportOpen] = useState(false);
  const [exporting, setExporting] = useState<null | "page" | "comic">(null);

  // Tap/Auto zoom state — `zoomAnim` is ONLY true for deliberate double-tap or +/- zoom, NEVER during page changes or gestures!
  const [zoom, setZoom] = useState({ s: 1, x: 0, y: 0 });
  const [zoomAnim, setZoomAnim] = useState(false);

  // Scroll mode zoom state
  const [scrollZoom, setScrollZoom] = useState({ s: 1, x: 0, y: 0 });
  const scrollZoomRef = useRef({ s: 1, x: 0, y: 0 });
  const [scrollInteracting, setScrollInteracting] = useState(false);

  const [held, setHeld] = useState(false);
  const [remain, setRemain] = useState(1);
  const [full, setFull] = useState(false);
  const hideTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const viewportRef = useRef<HTMLDivElement>(null);
  const pagedStageRef = useRef<HTMLDivElement>(null);
  const scrollViewportRef = useRef<HTMLDivElement>(null);
  const scrollStageRef = useRef<HTMLDivElement>(null);
  const mode = settings.readerMode;
  const fit = settings.fit;
  const panSens = Math.max(0.5, Math.min(2.5, Number.isFinite(settings.zoomPanSensitivity) ? settings.zoomPanSensitivity : 1));
  const panSensRef = useRef(panSens);
  panSensRef.current = panSens;
  const n = pages?.length ?? comic?.pages ?? 0;

  useBackClose(true, () => {
    if (lockedRef.current) {
      setLocked(false);
      setControls(true);
    } else {
      close();
    }
  });

  const [scrub, setScrub] = useState<number | null>(null);
  const dragging = useRef(false);
  const scrubbing = useRef(false);

  const loadPages = useCallback(() => {
    setPages(null);
    setLoadError(null);
    let live = true;
    void api
      .pages(readerId)
      .then((p) => {
        if (!live) return;
        const list = Array.isArray(p) ? p : [];
        setPages(list);
        if (list.length > 0) {
          const clamped = Math.max(0, Math.min(list.length - 1, initialPage));
          initial.current = clamped;
          setIndex(clamped);
        }
      })
      .catch((e) => {
        if (!live) return;
        setLoadError((e as Error)?.message || "Could not open this comic.");
        setPages([]);
      });
    return () => {
      live = false;
    };
  }, [readerId, initialPage]);

  useEffect(() => loadPages(), [loadPages]);

  /** Instant, zero-flicker page switch: resets zoom synchronously with transition OFF so there is zero bounce/flash. */
  const go = useCallback(
    (i: number) => {
      if (n <= 0) return;
      const t = Math.max(0, Math.min(n - 1, i));
      setIndex((cur) => {
        if (t !== cur) {
          setZoomAnim(false);
          zoomRef.current = { s: 1, x: 0, y: 0 };
          setZoom({ s: 1, x: 0, y: 0 });
        }
        return t;
      });
    },
    [n],
  );

  // remember the page (debounced) and mark the comic as read at the end
  useEffect(() => {
    if (!pages || pages.length === 0) return;
    const t = setTimeout(() => recordProgress(readerId, index, pages.length), 500);
    return () => clearTimeout(t);
  }, [index, pages, readerId, recordProgress]);

  // Eagerly preload & decode neighboring pages (-1..+3) in memory so 1-tap page turns are instant 120Hz zero-flicker
  const preloadedRef = useRef<Map<string, HTMLImageElement>>(new Map());
  useEffect(() => {
    if (!pages || pages.length === 0 || mode === "scroll") return;
    const cache = preloadedRef.current;
    for (let i = Math.max(0, index - 1); i <= Math.min(pages.length - 1, index + 3); i++) {
      const url = pages[i].url;
      if (cache.has(url)) continue;
      void api
        .resolveImage(url)
        .then((u) => {
          if (!u || cache.has(url)) return;
          const img = new Image();
          img.decoding = "async";
          img.src = u;
          void img.decode?.().catch(() => undefined);
          cache.set(url, img);
          if (cache.size > 16) {
            const firstKey = cache.keys().next().value;
            if (firstKey) cache.delete(firstKey);
          }
        })
        .catch(() => undefined);
    }
  }, [index, pages, mode]);

  // controls auto-hide (suppressed while locked; stays open while export menu is open)
  const poke = useCallback(() => {
    if (lockedRef.current) return;
    setControls(true);
    if (hideTimer.current) clearTimeout(hideTimer.current);
    hideTimer.current = setTimeout(() => {
      setExportOpen((open) => {
        if (!open) setControls(false);
        return open;
      });
    }, 2800);
  }, []);
  useEffect(() => {
    poke();
    return () => {
      if (hideTimer.current) clearTimeout(hideTimer.current);
    };
  }, [poke]);

  const enterLockMode = useCallback(() => {
    setExportOpen(false);
    setControls(false);
    setLocked(true);
    if (hideTimer.current) clearTimeout(hideTimer.current);
  }, []);

  const exitLockMode = useCallback(() => {
    lockedRef.current = false;
    setLocked(false);
    setControls(true);
    if (hideTimer.current) clearTimeout(hideTimer.current);
    hideTimer.current = setTimeout(() => {
      setExportOpen((open) => {
        if (!open) setControls(false);
        return open;
      });
    }, 3200);
  }, []);

  // auto-next timer with visible countdown, paused while touching
  useEffect(() => {
    if (mode !== "auto" || !pages || pages.length === 0) return;
    setRemain(1);
    const total = settings.autoNextSec * 1000;
    let left = total;
    const id = setInterval(() => {
      if (held || exportOpen) return;
      left -= 100;
      setRemain(Math.max(0, left / total));
      if (left <= 0) {
        left = total;
        if (index < pages.length - 1) go(index + 1);
      }
    }, 100);
    return () => clearInterval(id);
  }, [mode, pages, index, settings.autoNextSec, held, exportOpen, go]);

  const scrollRef = useRef<HTMLDivElement>(null);
  const stripInnerRef = useRef<HTMLDivElement>(null);
  const scrollBy = (dir: 1 | -1) => scrollRef.current?.scrollBy({ top: dir * scrollRef.current.clientHeight * 0.85, behavior: "smooth" });

  const toggleFull = useCallback(() => {
    if (document.fullscreenElement) void document.exitFullscreen();
    else void document.documentElement.requestFullscreen?.().catch(() => undefined);
  }, []);
  useEffect(() => {
    const h = () => setFull(!!document.fullscreenElement);
    document.addEventListener("fullscreenchange", h);
    return () => {
      document.removeEventListener("fullscreenchange", h);
      if (document.fullscreenElement) void document.exitFullscreen();
    };
  }, []);

  /** Clamp zoom scale and pan offsets for any viewport-sized GPU stage. */
  const clampFor = useCallback((el: HTMLElement | null, sRaw: number, xRaw: number, yRaw: number) => {
    const s = Number.isFinite(sRaw) ? Math.max(1, Math.min(MAX_ZOOM, sRaw)) : 1;
    if (s <= 1.01) return { s: 1, x: 0, y: 0 };
    const w = el?.clientWidth || window.innerWidth || 360;
    const h = el?.clientHeight || window.innerHeight || 640;
    const maxX = ((s - 1) * w) / 2;
    const maxY = ((s - 1) * h) / 2;
    const x = Number.isFinite(xRaw) ? Math.max(-maxX, Math.min(maxX, xRaw)) : 0;
    const y = Number.isFinite(yRaw) ? Math.max(-maxY, Math.min(maxY, yRaw)) : 0;
    return { s, x, y };
  }, []);

  const clampZoom = useCallback(
    (sRaw: number, xRaw: number, yRaw: number) => clampFor(viewportRef.current, sRaw, xRaw, yRaw),
    [clampFor],
  );

  const clampScrollZoom = useCallback(
    (sRaw: number, xRaw: number, yRaw: number) => clampFor(scrollViewportRef.current, sRaw, xRaw, yRaw),
    [clampFor],
  );

  const cancelScrollMomentumRef = useRef<() => void>(() => {});

  const setScrollZoomSmooth = useCallback(
    (nextS: number, nextX?: number, nextY?: number) => {
      cancelScrollMomentumRef.current();
      const cur = scrollZoomRef.current;
      const clamped = clampScrollZoom(nextS, nextX ?? cur.x, nextY ?? cur.y);
      scrollZoomRef.current = clamped;
      setScrollInteracting(false);
      setScrollZoom(clamped);
    },
    [clampScrollZoom],
  );

  // ---- Pure GPU 120Hz pinch + pan + constant-speed inertial comic scroll for Scroll Mode ----
  const scrollGestureActive = useRef(false);
  useEffect(() => {
    if (mode !== "scroll" || !pages || pages.length === 0) return;
    const vp = scrollViewportRef.current;
    const stage = scrollStageRef.current;
    const scroller = scrollRef.current;
    if (!vp || !stage || !scroller) return;

    let pinchSt: { d0: number; s0: number; x0: number; y0: number; cx0: number; cy0: number; fx: number; fy: number } | null = null;
    let panSt: { lastX: number; lastY: number; lastT: number; vx: number; vy: number; moved: boolean } | null = null;
    let rafId = 0;
    let momentumRaf = 0;

    const paint = () => {
      rafId = 0;
      const z = scrollZoomRef.current;
      stage.style.transform = z.s > 1 ? `translate3d(${z.x}px, ${z.y}px, 0) scale(${z.s})` : "translate3d(0, 0, 0) scale(1)";
    };
    const schedulePaint = () => {
      if (!rafId) rafId = requestAnimationFrame(paint);
    };

    const stopMomentum = () => {
      if (momentumRaf) {
        cancelAnimationFrame(momentumRaf);
        momentumRaf = 0;
      }
    };
    cancelScrollMomentumRef.current = stopMomentum;

    const applyPanAndScroll = (moveX: number, moveY: number) => {
      const z = scrollZoomRef.current;
      if (z.s <= 1) return false;
      const w = vp.clientWidth || window.innerWidth || 360;
      const h = vp.clientHeight || window.innerHeight || 640;
      const maxX = ((z.s - 1) * w) / 2;
      const maxY = ((z.s - 1) * h) / 2;

      const nextX = Math.max(-maxX, Math.min(maxX, z.x + moveX));
      const rawY = z.y + moveY;
      let nextY = rawY;
      let scrolled = false;
      if (rawY > maxY) {
        nextY = maxY;
        const before = scroller.scrollTop;
        scroller.scrollTop = Math.max(0, before - (rawY - maxY));
        scrolled = scroller.scrollTop !== before;
      } else if (rawY < -maxY) {
        nextY = -maxY;
        const maxTop = Math.max(0, scroller.scrollHeight - scroller.clientHeight);
        const before = scroller.scrollTop;
        scroller.scrollTop = Math.min(maxTop, before - (rawY + maxY));
        scrolled = scroller.scrollTop !== before;
      }
      const changed = nextX !== z.x || nextY !== z.y;
      scrollZoomRef.current = { s: z.s, x: nextX, y: nextY };
      if (changed) schedulePaint();
      return changed || scrolled;
    };

    const startMomentum = (initVx: number, initVy: number) => {
      stopMomentum();
      let vx = initVx;
      let vy = initVy;
      let prevT = performance.now();
      stage.style.transition = "none";
      const step = (now: number) => {
        const dt = Math.min(32, Math.max(1, now - prevT));
        prevT = now;
        const moved = applyPanAndScroll(vx * dt, vy * dt);
        const decay = Math.pow(0.94, dt / 16.67);
        vx *= decay;
        vy *= decay;
        if (moved && Math.hypot(vx, vy) > 0.03) {
          momentumRaf = requestAnimationFrame(step);
        } else {
          momentumRaf = 0;
          if (rafId) {
            cancelAnimationFrame(rafId);
            paint();
          }
          setScrollInteracting(false);
          setScrollZoom({ ...scrollZoomRef.current });
        }
      };
      momentumRaf = requestAnimationFrame(step);
    };

    const onTouchStart = (e: TouchEvent) => {
      stopMomentum();
      if (e.touches.length === 2) {
        const a = e.touches[0], b = e.touches[1];
        const rect = vp.getBoundingClientRect();
        const cx0 = (a.clientX + b.clientX) / 2;
        const cy0 = (a.clientY + b.clientY) / 2;
        const z = scrollZoomRef.current;
        pinchSt = {
          d0: Math.max(12, Math.hypot(a.clientX - b.clientX, a.clientY - b.clientY)),
          s0: z.s,
          x0: z.x,
          y0: z.y,
          cx0,
          cy0,
          fx: cx0 - (rect.left + rect.width / 2),
          fy: cy0 - (rect.top + rect.height / 2),
        };
        panSt = null;
        scrollGestureActive.current = true;
        stage.style.transition = "none";
        setScrollInteracting(true);
      } else if (e.touches.length === 1 && scrollZoomRef.current.s > 1) {
        const t = e.touches[0];
        pinchSt = null;
        panSt = { lastX: t.clientX, lastY: t.clientY, lastT: performance.now(), vx: 0, vy: 0, moved: false };
        scrollGestureActive.current = true;
        stage.style.transition = "none";
        setScrollInteracting(true);
      }
    };

    const onTouchMove = (e: TouchEvent) => {
      if (e.touches.length === 2 && pinchSt) {
        e.preventDefault();
        const a = e.touches[0], b = e.touches[1];
        const d = Math.hypot(a.clientX - b.clientX, a.clientY - b.clientY);
        if (d < 1) return;
        const cx = (a.clientX + b.clientX) / 2;
        const cy = (a.clientY + b.clientY) / 2;
        const nextS = Math.max(1, Math.min(MAX_ZOOM, pinchSt.s0 * (d / pinchSt.d0)));
        const k = nextS / pinchSt.s0;
        const rawX = pinchSt.x0 * k + pinchSt.fx * (1 - k) + (cx - pinchSt.cx0);
        const rawY = pinchSt.y0 * k + pinchSt.fy * (1 - k) + (cy - pinchSt.cy0);
        scrollZoomRef.current = clampScrollZoom(nextS, rawX, rawY);
        schedulePaint();
      } else if (e.touches.length === 1 && panSt && scrollZoomRef.current.s > 1) {
        e.preventDefault();
        const t = e.touches[0];
        const now = performance.now();
        const dt = Math.max(1, now - panSt.lastT);
        const sens = panSensRef.current;
        const moveX = (t.clientX - panSt.lastX) * sens;
        const moveY = (t.clientY - panSt.lastY) * sens;
        panSt.lastX = t.clientX;
        panSt.lastY = t.clientY;
        panSt.lastT = now;
        if (Math.abs(moveX) + Math.abs(moveY) > 3) panSt.moved = true;

        if (dt < 120) {
          const instVx = Math.max(-4, Math.min(4, moveX / dt));
          const instVy = Math.max(-4, Math.min(4, moveY / dt));
          panSt.vx = panSt.vx * 0.65 + instVx * 0.35;
          panSt.vy = panSt.vy * 0.65 + instVy * 0.35;
        } else {
          panSt.vx = 0;
          panSt.vy = 0;
        }

        applyPanAndScroll(moveX, moveY);
      }
    };

    const onTouchEnd = (e: TouchEvent) => {
      if (pinchSt && e.touches.length === 1) {
        pinchSt = null;
        if (scrollZoomRef.current.s > 1) {
          const t = e.touches[0];
          panSt = { lastX: t.clientX, lastY: t.clientY, lastT: performance.now(), vx: 0, vy: 0, moved: true };
          return;
        }
      }
      if (e.touches.length === 0 && (pinchSt || panSt)) {
        const finishedPan = panSt;
        pinchSt = null;
        panSt = null;
        if (rafId) {
          cancelAnimationFrame(rafId);
          paint();
        }
        scrollGestureActive.current = false;
        const stale = finishedPan ? performance.now() - finishedPan.lastT > 85 : true;
        if (finishedPan && finishedPan.moved && !stale && scrollZoomRef.current.s > 1 && Math.hypot(finishedPan.vx, finishedPan.vy) > 0.14) {
          startMomentum(finishedPan.vx, finishedPan.vy);
        } else {
          setScrollInteracting(false);
          setScrollZoom({ ...scrollZoomRef.current });
        }
      }
    };

    vp.addEventListener("touchstart", onTouchStart, { passive: true });
    vp.addEventListener("touchmove", onTouchMove, { passive: false });
    vp.addEventListener("touchend", onTouchEnd, { passive: true });
    vp.addEventListener("touchcancel", onTouchEnd, { passive: true });

    return () => {
      stopMomentum();
      cancelScrollMomentumRef.current = () => {};
      if (rafId) cancelAnimationFrame(rafId);
      scrollGestureActive.current = false;
      vp.removeEventListener("touchstart", onTouchStart);
      vp.removeEventListener("touchmove", onTouchMove);
      vp.removeEventListener("touchend", onTouchEnd);
      vp.removeEventListener("touchcancel", onTouchEnd);
    };
  }, [mode, pages, clampScrollZoom]);

  const scrollLastTapRef = useRef<{ t: number; x: number; y: number }>({ t: 0, x: 0, y: 0 });
  const scrollTapTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const onScrollClick = (e: React.MouseEvent) => {
    if (scrollGestureActive.current) return;
    setExportOpen(false);
    const now = Date.now();
    const dx = Math.abs(e.clientX - scrollLastTapRef.current.x);
    const dy = Math.abs(e.clientY - scrollLastTapRef.current.y);
    if (now - scrollLastTapRef.current.t < 300 && dx < 36 && dy < 36) {
      if (scrollTapTimer.current) clearTimeout(scrollTapTimer.current);
      scrollLastTapRef.current.t = 0;
      if (scrollZoomRef.current.s > 1.05) {
        setScrollZoomSmooth(1, 0, 0);
      } else {
        const vp = scrollViewportRef.current;
        const rect = vp?.getBoundingClientRect();
        const fx = rect ? e.clientX - (rect.left + rect.width / 2) : 0;
        const fy = rect ? e.clientY - (rect.top + rect.height / 2) : 0;
        const targetS = 2.2;
        setScrollZoomSmooth(targetS, -fx * (targetS - 1), -fy * (targetS - 1));
      }
      return;
    }
    scrollLastTapRef.current = { t: now, x: e.clientX, y: e.clientY };
    scrollTapTimer.current = setTimeout(() => {
      if (!lockedRef.current) poke();
    }, 220);
  };

  // ---- Ultra-snappy 120Hz Tap-to-Next & Zoom/Pan pointer handling (ZERO swipe-to-next, ZERO flicker!) ----
  const ptrs = useRef(new Map<number, { x: number; y: number }>());
  const pinch = useRef<{ d: number; s: number; zx: number; zy: number } | null>(null);
  const drag = useRef<{ x: number; y: number; zx: number; zy: number; moved: boolean } | null>(null);
  const zoomRef = useRef(zoom);
  zoomRef.current = zoom;
  const lastTap = useRef({ t: 0, x: 0 });
  const tapTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const pagedRafRef = useRef(0);

  const paintPagedDirect = useCallback(() => {
    pagedRafRef.current = 0;
    const el = pagedStageRef.current;
    if (!el) return;
    const z = zoomRef.current;
    el.style.transform = z.s > 1 ? `translate3d(${z.x}px, ${z.y}px, 0) scale(${z.s})` : "translate3d(0, 0, 0) scale(1)";
  }, []);

  const schedulePagedPaint = useCallback(() => {
    if (!pagedRafRef.current) pagedRafRef.current = requestAnimationFrame(paintPagedDirect);
  }, [paintPagedDirect]);

  useEffect(() => {
    return () => {
      if (pagedRafRef.current) cancelAnimationFrame(pagedRafRef.current);
      if (tapTimer.current) clearTimeout(tapTimer.current);
    };
  }, []);

  const dist = () => {
    const vals = [...ptrs.current.values()];
    if (vals.length < 2) return 0;
    return Math.hypot(vals[0].x - vals[1].x, vals[0].y - vals[1].y);
  };

  const onDown = (e: React.PointerEvent) => {
    setExportOpen(false);
    setHeld(true);
    ptrs.current.set(e.pointerId, { x: e.clientX, y: e.clientY });
    (e.currentTarget as HTMLElement).setPointerCapture?.(e.pointerId);
    if (ptrs.current.size === 2) {
      drag.current = null;
      setZoomAnim(false);
      if (pagedStageRef.current) pagedStageRef.current.style.transition = "none";
      pinch.current = { d: Math.max(10, dist()), s: zoomRef.current.s, zx: zoomRef.current.x, zy: zoomRef.current.y };
    } else if (ptrs.current.size === 1) {
      pinch.current = null;
      drag.current = { x: e.clientX, y: e.clientY, zx: zoomRef.current.x, zy: zoomRef.current.y, moved: false };
    }
  };

  const onMove = (e: React.PointerEvent) => {
    if (!ptrs.current.has(e.pointerId)) return;
    ptrs.current.set(e.pointerId, { x: e.clientX, y: e.clientY });
    if (pinch.current && ptrs.current.size === 2) {
      const curD = dist();
      if (curD < 1) return;
      const ratio = curD / pinch.current.d;
      const nextScale = pinch.current.s * ratio;
      zoomRef.current = clampZoom(nextScale, pinch.current.zx * (nextScale / pinch.current.s), pinch.current.zy * (nextScale / pinch.current.s));
      schedulePagedPaint();
    } else if (drag.current && ptrs.current.size === 1) {
      const dx = e.clientX - drag.current.x;
      const dy = e.clientY - drag.current.y;
      if (Math.abs(dx) + Math.abs(dy) > 8) drag.current.moved = true;
      if (zoomRef.current.s > 1) {
        if (pagedStageRef.current) pagedStageRef.current.style.transition = "none";
        const sens = panSensRef.current;
        zoomRef.current = clampZoom(zoomRef.current.s, drag.current.zx + dx * sens, drag.current.zy + dy * sens);
        schedulePagedPaint();
      }
    }
  };

  const onCancel = (e: React.PointerEvent) => {
    ptrs.current.delete(e.pointerId);
    if (ptrs.current.size < 2) pinch.current = null;
    if (ptrs.current.size === 0) {
      drag.current = null;
      setHeld(false);
      setZoom({ ...zoomRef.current });
    }
  };

  const onUp = (e: React.PointerEvent) => {
    ptrs.current.delete(e.pointerId);
    if (ptrs.current.size === 1 && pinch.current) {
      pinch.current = null;
      const [rem] = [...ptrs.current.values()];
      drag.current = { x: rem.x, y: rem.y, zx: zoomRef.current.x, zy: zoomRef.current.y, moved: true };
      return;
    }
    if (ptrs.current.size < 2) pinch.current = null;
    if (ptrs.current.size === 0) {
      setHeld(false);
      if (pagedRafRef.current) {
        cancelAnimationFrame(pagedRafRef.current);
        paintPagedDirect();
      }
      const d = drag.current;
      drag.current = null;
      if (d && !d.moved) {
        handlePagedTap(e.clientX, (e.currentTarget as HTMLElement).getBoundingClientRect());
      } else {
        // Sync final pinch/pan zoom state with zero jump
        setZoomAnim(false);
        setZoom({ ...zoomRef.current });
      }
    }
  };

  /**
   * 0ms-latency narrow left/right edge tap zones (works whether zoomed or unzoomed!).
   * Center area handles double-tap zoom and single-tap UI toggle.
   */
  const handlePagedTap = (clientX: number, rect: DOMRect) => {
    const x = clientX - rect.left;
    const w = rect.width || window.innerWidth || 360;
    const edge = edgeZoneWidth(w);

    // Narrow left edge -> instant previous page (0ms delay, zero flicker)
    if (x <= edge) {
      if (tapTimer.current) clearTimeout(tapTimer.current);
      lastTap.current.t = 0;
      go(index - 1);
      return;
    }
    // Narrow right edge -> instant next page (0ms delay, zero flicker)
    if (x >= w - edge) {
      if (tapTimer.current) clearTimeout(tapTimer.current);
      lastTap.current.t = 0;
      go(index + 1);
      return;
    }

    // Center zone: double-tap zoom, single-tap UI toggle
    const now = Date.now();
    if (now - lastTap.current.t < 280) {
      if (tapTimer.current) clearTimeout(tapTimer.current);
      lastTap.current.t = 0;
      setZoomAnim(true);
      const next = zoomRef.current.s > 1 ? { s: 1, x: 0, y: 0 } : clampZoom(2.2, (w / 2 - x) * 1.1, 0);
      zoomRef.current = next;
      setZoom(next);
      return;
    }
    lastTap.current = { t: now, x };
    tapTimer.current = setTimeout(() => {
      if (lockedRef.current) return;
      if (zoomRef.current.s > 1) {
        poke();
      } else {
        setControls((c) => !c);
        poke();
      }
    }, 220);
  };

  // ---- scroll mode: exact target page jump + layout-shift pinning + thick black dividers ------------
  const initial = useRef(Math.max(0, initialPage));
  const restoring = useRef(false);
  const restoreGraceUntil = useRef(0);

  const pageEls = () => [...(scrollRef.current?.querySelectorAll<HTMLElement>("[data-page]") ?? [])];

  const scrollToPage = useCallback((i: number) => {
    const root = scrollRef.current;
    if (!root) return;
    const el = root.querySelector<HTMLElement>(`[data-page="${i}"]`);
    if (!el) return;
    const scale = scrollZoomRef.current.s || 1;
    const delta = (el.getBoundingClientRect().top - root.getBoundingClientRect().top) / scale;
    root.scrollTop = Math.max(0, root.scrollTop + delta);
  }, []);

  useEffect(() => {
    if (mode !== "scroll" || !pages || pages.length === 0 || !scrollRef.current) return;
    const root = scrollRef.current;
    let raf = 0;
    const track = () => {
      raf = 0;
      if (scrubbing.current || restoring.current) return;
      const els = pageEls();
      if (els.length === 0) return;
      const rootRect = root.getBoundingClientRect();
      const mid = rootRect.top + rootRect.height * 0.35;
      let lo = 0, hi = els.length - 1;
      while (lo < hi) {
        const m = (lo + hi + 1) >> 1;
        if (els[m].getBoundingClientRect().top <= mid) lo = m;
        else hi = m - 1;
      }
      setIndex((cur) => (cur === lo ? cur : lo));
    };
    const onScroll = () => {
      if (!raf) raf = requestAnimationFrame(track);
    };

    const target = Math.max(0, Math.min(pages.length - 1, initial.current));
    if (target > 0) {
      restoring.current = true;
      restoreGraceUntil.current = Date.now() + 300;
      setIndex(target);
      const pin = () => {
        if (!restoring.current) return;
        scrollToPage(target);
      };
      pin();
      const raf1 = requestAnimationFrame(() => {
        pin();
        requestAnimationFrame(pin);
      });
      const ro = typeof ResizeObserver !== "undefined" && stripInnerRef.current
        ? new ResizeObserver(() => {
            if (restoring.current) pin();
          })
        : null;
      if (ro && stripInnerRef.current) ro.observe(stripInnerRef.current);

      const stop = () => {
        if (Date.now() < restoreGraceUntil.current) return;
        restoring.current = false;
        ro?.disconnect();
      };
      root.addEventListener("touchmove", stop, { passive: true });
      root.addEventListener("wheel", stop, { passive: true });
      root.addEventListener("pointerdown", stop, { passive: true });
      const t = setTimeout(() => {
        restoring.current = false;
        ro?.disconnect();
      }, 6000);
      root.addEventListener("scroll", onScroll, { passive: true });
      return () => {
        cancelAnimationFrame(raf1);
        clearTimeout(t);
        ro?.disconnect();
        root.removeEventListener("scroll", onScroll);
        root.removeEventListener("touchmove", stop);
        root.removeEventListener("wheel", stop);
        root.removeEventListener("pointerdown", stop);
        if (raf) cancelAnimationFrame(raf);
      };
    }

    root.addEventListener("scroll", onScroll, { passive: true });
    return () => {
      root.removeEventListener("scroll", onScroll);
      if (raf) cancelAnimationFrame(raf);
    };
  }, [mode, pages, scrollToPage]);

  const [loadedPages, setLoadedPages] = useState<Set<number>>(() => new Set());
  const markLoaded = (i: number) => setLoadedPages((s) => (s.has(i) ? s : new Set(s).add(i)));
  const onStripImageLoad = (i: number) => () => {
    markLoaded(i);
    if (restoring.current && i <= initial.current) {
      requestAnimationFrame(() => scrollToPage(initial.current));
    }
  };

  // ---- scrubber ---------------------------------------------------------------------------------------------------
  const commitScrub = (v: number) => {
    dragging.current = false;
    setScrub(null);
    const target = Math.max(0, Math.min(Math.max(0, n - 1), v));
    if (mode === "scroll") {
      cancelScrollMomentumRef.current();
      restoring.current = false;
      initial.current = target;
      scrollToPage(target);
      setIndex(target);
      setTimeout(() => {
        scrollToPage(target);
        scrubbing.current = false;
      }, 150);
    } else {
      scrubbing.current = false;
      go(target);
    }
    poke();
  };
  const onScrubChange = (v: number) => {
    poke();
    if (!dragging.current) return commitScrub(v);
    scrubbing.current = true;
    setScrub(v);
    if (mode === "scroll") scrollToPage(v);
  };
  const shown = Math.min(scrub ?? index, Math.max(0, n - 1));

  // ---- direct export (current page or full comic) -----------------------------------------------------------------
  const handleExportPage = useCallback(async () => {
    setExportOpen(false);
    setExporting("page");
    try {
      const res = await api.exportPage(readerId, shown);
      if (res.cancelled) return;
      if (res.ok) toast(`Exported page ${shown + 1}${res.filename ? ` (${res.filename})` : ""}`);
      else toast("Could not export page", "error");
    } catch (e) {
      toast((e as Error)?.message || "Could not export page", "error");
    } finally {
      setExporting(null);
    }
  }, [readerId, shown, toast]);

  const handleExportComic = useCallback(async () => {
    setExportOpen(false);
    setExporting("comic");
    try {
      const res = await api.exportComic(readerId);
      if (res.cancelled) return;
      if (res.ok) toast(`Exported comic (${res.pages ?? n} pages)`);
      else toast("Could not export comic", "error");
    } catch (e) {
      toast((e as Error)?.message || "Could not export comic", "error");
    } finally {
      setExporting(null);
    }
  }, [readerId, n, toast]);

  // ---- Configurable Reader Keyboard Shortcuts ----
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const tag = (e.target as HTMLElement)?.tagName;
      if (tag === "INPUT" || tag === "SELECT" || tag === "TEXTAREA") return;
      const scroll = mode === "scroll";
      const next = () => (scroll ? scrollBy(1) : go(index + 1));
      const prev = () => (scroll ? scrollBy(-1) : go(index - 1));

      if (matchesShortcut(e, settings, "readerClose")) {
        e.preventDefault();
        if (lockedRef.current) exitLockMode();
        else if (exportOpen) setExportOpen(false);
        else if (!document.fullscreenElement) close();
        return;
      }
      if (matchesShortcut(e, settings, "readerLockUi")) {
        e.preventDefault();
        if (lockedRef.current) exitLockMode();
        else enterLockMode();
        return;
      }
      if (matchesShortcut(e, settings, "readerNext") || e.key === "PageDown" || (e.key === " " && !e.shiftKey) || (scroll && e.key === "ArrowDown")) {
        e.preventDefault();
        next();
      } else if (matchesShortcut(e, settings, "readerPrev") || e.key === "PageUp" || (e.key === " " && e.shiftKey) || (scroll && e.key === "ArrowUp")) {
        e.preventDefault();
        prev();
      } else if (e.key === "Home") {
        e.preventDefault();
        go(0);
      } else if (e.key === "End") {
        e.preventDefault();
        go(n - 1);
      } else if (matchesShortcut(e, settings, "readerFullscreen")) {
        e.preventDefault();
        toggleFull();
      } else if (matchesShortcut(e, settings, "readerZoomIn")) {
        e.preventDefault();
        if (scroll) setScrollZoomSmooth(scrollZoomRef.current.s + 0.5);
        else {
          setZoomAnim(true);
          const nextZ = clampZoom(zoomRef.current.s + 0.5, zoomRef.current.x, zoomRef.current.y);
          zoomRef.current = nextZ;
          setZoom(nextZ);
        }
      } else if (matchesShortcut(e, settings, "readerZoomOut")) {
        e.preventDefault();
        if (scroll) {
          const cur = scrollZoomRef.current;
          setScrollZoomSmooth(cur.s - 0.5, cur.s <= 1.5 ? 0 : cur.x, cur.s <= 1.5 ? 0 : cur.y);
        } else {
          setZoomAnim(true);
          const cur = zoomRef.current;
          const nextZ = clampZoom(cur.s - 0.5, cur.s <= 1.5 ? 0 : cur.x, cur.s <= 1.5 ? 0 : cur.y);
          zoomRef.current = nextZ;
          setZoom(nextZ);
        }
      } else if (matchesShortcut(e, settings, "readerZoomReset")) {
        e.preventDefault();
        if (scroll) setScrollZoomSmooth(1, 0, 0);
        else {
          setZoomAnim(true);
          zoomRef.current = { s: 1, x: 0, y: 0 };
          setZoom({ s: 1, x: 0, y: 0 });
        }
      } else if (matchesShortcut(e, settings, "readerExportPage")) {
        e.preventDefault();
        void handleExportPage();
      } else {
        return;
      }
      if (!lockedRef.current) poke();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [mode, go, index, n, settings, toggleFull, clampZoom, setScrollZoomSmooth, close, poke, exportOpen, enterLockMode, exitLockMode, handleExportPage]);

  const curIdx = Math.min(index, Math.max(0, (pages?.length ?? 1) - 1));
  const page = pages?.[curIdx];
  const title = comic?.name ?? "";
  const showUi = controls && !locked;
  const barCls = cn("absolute inset-x-0 z-10 flex bg-[#1d1b3b]/92 px-3 text-white backdrop-blur-sm transition-opacity duration-200", showUi ? "opacity-100" : "pointer-events-none opacity-0");
  const imgFit = fit === "width" ? "w-full h-auto" : "max-h-full max-w-full object-contain";
  const isZoomed = zoom.s > 1;
  const isScrollZoomed = scrollZoom.s > 1;
  const activeZoom = mode === "scroll" ? scrollZoom.s : zoom.s;

  return (
    <div className="fixed inset-0 z-[60] bg-black text-white" role="dialog" aria-label={`Reading ${title}`} onPointerMove={(e) => e.pointerType === "mouse" && !locked && poke()}>
      <div className={cn(barCls, "top-0 safe-t min-h-14 items-center gap-1 border-b-[2.5px] border-[#0e0d22]")} onPointerDown={(e) => e.stopPropagation()}>
        <Button variant="ghost" size="icon" aria-label="Close reader" onClick={close} faceClassName="text-white [@media(hover:hover)]:group-hover:bg-white/15"><X /></Button>
        <div className="min-w-0 flex-1">
          <div className="truncate text-[15px] font-medium" title={title}>{title}</div>
          <div className="text-xs text-white/70">{n > 0 ? `Page ${shown + 1} of ${n}` : "No pages"}</div>
        </div>
        {pages && pages.length > 0 && (
          <div className="flex items-center gap-0.5">
            <Button
              variant="ghost"
              size="icon"
              aria-label="Zoom out"
              title="Zoom out"
              disabled={activeZoom <= 1.01}
              onClick={() => {
                if (mode === "scroll") {
                  const cur = scrollZoomRef.current;
                  setScrollZoomSmooth(cur.s - 0.5, cur.s <= 1.5 ? 0 : cur.x, cur.s <= 1.5 ? 0 : cur.y);
                } else {
                  setZoomAnim(true);
                  const cur = zoomRef.current;
                  const nextZ = clampZoom(cur.s - 0.5, cur.s <= 1.5 ? 0 : cur.x, cur.s <= 1.5 ? 0 : cur.y);
                  zoomRef.current = nextZ;
                  setZoom(nextZ);
                }
                poke();
              }}
              faceClassName="text-white [@media(hover:hover)]:group-hover:bg-white/15"
            >
              <Minus />
            </Button>
            {activeZoom > 1.01 && (
              <Button
                variant="ghost"
                size="sm"
                aria-label="Reset zoom"
                title="Reset zoom to 100%"
                onClick={() => {
                  if (mode === "scroll") setScrollZoomSmooth(1, 0, 0);
                  else {
                    setZoomAnim(true);
                    zoomRef.current = { s: 1, x: 0, y: 0 };
                    setZoom({ s: 1, x: 0, y: 0 });
                  }
                  poke();
                }}
                faceClassName="text-white px-2 [@media(hover:hover)]:group-hover:bg-white/15"
              >
                {Math.round(activeZoom * 100)}%
              </Button>
            )}
            <Button
              variant="ghost"
              size="icon"
              aria-label="Zoom in"
              title="Zoom in"
              disabled={activeZoom >= MAX_ZOOM}
              onClick={() => {
                if (mode === "scroll") setScrollZoomSmooth(scrollZoomRef.current.s + 0.5);
                else {
                  setZoomAnim(true);
                  const nextZ = clampZoom(zoomRef.current.s + 0.5, zoomRef.current.x, zoomRef.current.y);
                  zoomRef.current = nextZ;
                  setZoom(nextZ);
                }
                poke();
              }}
              faceClassName="text-white [@media(hover:hover)]:group-hover:bg-white/15"
            >
              <Plus />
            </Button>
          </div>
        )}
        {pages && pages.length > 0 && (
          <Button
            variant="ghost"
            size="icon"
            aria-label="Lock UI"
            title="Lock mode (hide all UI)"
            onClick={enterLockMode}
            faceClassName="text-white [@media(hover:hover)]:group-hover:bg-white/15"
          >
            <Lock />
          </Button>
        )}
        {pages && pages.length > 0 && (
          <div className="relative">
            <Button
              variant="ghost"
              size="icon"
              aria-label="Export page or comic"
              aria-expanded={exportOpen}
              title="Export page or comic"
              disabled={exporting !== null}
              onClick={() => {
                setExportOpen((v) => !v);
                poke();
              }}
              faceClassName="text-white [@media(hover:hover)]:group-hover:bg-white/15"
            >
              {exporting ? <Loader2 className="animate-spin" /> : <Download />}
            </Button>
            {exportOpen && (
              <div
                role="menu"
                aria-label="Export options"
                className="absolute right-0 top-12 z-30 flex w-56 flex-col gap-1 rounded-[20px] border-[2.5px] border-[#0e0d22] bg-[#252250] p-2 text-white shadow-[0_6px_0_#0e0d22]"
              >
                <button
                  type="button"
                  role="menuitem"
                  onClick={() => void handleExportPage()}
                  className="flex h-10 w-full items-center gap-2.5 rounded-full px-3 text-left text-[13px] font-bold hover:bg-white/10 active:bg-white/20"
                >
                  <ImageDown className="size-4 shrink-0 text-butter" />
                  <span className="truncate">Export page {shown + 1}</span>
                </button>
                <button
                  type="button"
                  role="menuitem"
                  onClick={() => void handleExportComic()}
                  className="flex h-10 w-full items-center gap-2.5 rounded-full px-3 text-left text-[13px] font-bold hover:bg-white/10 active:bg-white/20"
                >
                  <FileArchive className="size-4 shrink-0 text-mint" />
                  <span className="truncate">Export full comic (.cbz)</span>
                </button>
              </div>
            )}
          </div>
        )}
        {mode !== "scroll" && (
          <Button variant="ghost" size="icon" aria-label={fit === "width" ? "Fit whole page" : "Fit page width"} title={fit === "width" ? "Fit whole page" : "Fit page width"} onClick={() => { setSettings({ fit: (fit === "width" ? "height" : "width") as FitMode }); setZoomAnim(false); zoomRef.current = { s: 1, x: 0, y: 0 }; setZoom({ s: 1, x: 0, y: 0 }); }} faceClassName="text-white [@media(hover:hover)]:group-hover:bg-white/15">
            {fit === "width" ? <MoveVertical /> : <ArrowLeftRight />}
          </Button>
        )}
        <Button variant="ghost" size="icon" aria-label="Toggle fullscreen" title="Fullscreen" onClick={toggleFull} className="hidden md:inline-flex" faceClassName="text-white [@media(hover:hover)]:group-hover:bg-white/15">{full ? <Shrink /> : <Expand />}</Button>
      </div>

      {!pages ? (
        <div className="flex size-full items-center justify-center text-sm text-white/70">Loading pages</div>
      ) : loadError ? (
        <div className="flex size-full flex-col items-center justify-center gap-3 px-6 text-center">
          <div className="font-display text-lg text-peach">Could not open comic</div>
          <p className="max-w-xs text-sm text-white/75">{loadError}</p>
          <div className="flex gap-2">
            <Button variant="outline" onClick={close}>Close</Button>
            <Button onClick={loadPages}><RefreshCw />Retry</Button>
          </div>
        </div>
      ) : pages.length === 0 ? (
        <div className="flex size-full flex-col items-center justify-center gap-3 px-6 text-center">
          <div className="font-display text-lg">No pages found</div>
          <p className="max-w-xs text-sm text-white/75">This comic folder has no readable images, or storage permission was revoked.</p>
          <Button variant="outline" onClick={close}>Close</Button>
        </div>
      ) : mode === "scroll" ? (
        <div
          ref={scrollViewportRef}
          className="relative size-full select-none overflow-hidden"
          style={{ touchAction: isScrollZoomed ? "none" : "pan-y" }}
          onClick={onScrollClick}
        >
          <div
            ref={scrollStageRef}
            className="size-full"
            style={{
              transform: isScrollZoomed ? `translate3d(${scrollZoom.x}px, ${scrollZoom.y}px, 0) scale(${scrollZoom.s})` : "translate3d(0, 0, 0) scale(1)",
              transformOrigin: "center center",
              willChange: isScrollZoomed || scrollInteracting ? "transform" : "auto",
              backfaceVisibility: "hidden",
              WebkitBackfaceVisibility: "hidden",
              transition: scrollInteracting ? "none" : "transform 170ms ease-out",
            }}
          >
            <div ref={scrollRef} className="reader-strip relative size-full overflow-y-auto overflow-x-hidden overscroll-contain">
              <div ref={stripInnerRef} className="mx-auto max-w-3xl">
                {pages.map((p, i) => (
                  <div key={p.name} data-page={i} className="block w-full leading-[0]" style={loadedPages.has(i) ? undefined : { minHeight: "60dvh", background: "#17152f" }}>
                    <PageImage
                      url={p.url}
                      fallbackUrl={p.fallbackUrl}
                      lazy={Math.abs(i - initial.current) > 2}
                      onLoad={onStripImageLoad(i)}
                      onFail={() => markLoaded(i)}
                      className="block h-auto w-full"
                    />
                    {i < pages.length - 1 && (
                      <div className="h-2.5 w-full border-y border-white/15 bg-black" aria-hidden="true" />
                    )}
                  </div>
                ))}
                <div className="py-10 text-center text-sm text-white/60">End of comic</div>
              </div>
            </div>
          </div>
        </div>
      ) : (
        <div
          ref={viewportRef}
          className="relative size-full select-none overflow-hidden"
          style={{ touchAction: !isZoomed && fit === "width" ? "pan-y" : "none" }}
          onPointerDown={onDown}
          onPointerMove={onMove}
          onPointerUp={onUp}
          onPointerCancel={onCancel}
        >
          {/* Persistent, zero-remount, zero-flicker 120Hz page stage */}
          <div className={cn("size-full", fit === "width" && !isZoomed ? "overflow-y-auto overscroll-contain" : "overflow-hidden")}>
            <div
              ref={pagedStageRef}
              className="flex min-h-full w-full items-center justify-center"
              style={{
                height: fit === "height" || isZoomed ? "100%" : undefined,
                transform: isZoomed ? `translate3d(${zoom.x}px, ${zoom.y}px, 0) scale(${zoom.s})` : "translate3d(0, 0, 0) scale(1)",
                transformOrigin: "center center",
                willChange: "transform",
                backfaceVisibility: "hidden",
                WebkitBackfaceVisibility: "hidden",
                transition: zoomAnim ? "transform 150ms cubic-bezier(0.22, 1, 0.36, 1)" : "none",
              }}
            >
              {page && <PageImage url={page.url} fallbackUrl={page.fallbackUrl} className={cn("block", imgFit)} />}
            </div>
          </div>

          {mode === "auto" && !locked && (
            <div className="pointer-events-none absolute bottom-24 right-4 flex items-center gap-2 rounded-full bg-black/60 py-1 pl-2 pr-3 text-xs text-white/80" aria-label={`Next page in ${Math.ceil(remain * settings.autoNextSec)} seconds`}>
              <svg width="18" height="18" viewBox="0 0 18 18" aria-hidden><circle cx="9" cy="9" r="7" fill="none" stroke="currentColor" strokeOpacity=".25" strokeWidth="2" /><circle cx="9" cy="9" r="7" fill="none" stroke="currentColor" strokeWidth="2" strokeDasharray={44} strokeDashoffset={44 * (1 - remain)} transform="rotate(-90 9 9)" /></svg>
              {held ? "Paused" : `${Math.ceil(remain * settings.autoNextSec)}s`}
            </div>
          )}
          <button aria-label="Previous page" onClick={(e) => { e.stopPropagation(); go(index - 1); }} onPointerDown={(e) => e.stopPropagation()} className={cn("absolute left-2 top-1/2 hidden size-11 -translate-y-1/2 items-center justify-center rounded-full bg-black/50 text-white transition-opacity md:flex", showUi ? "opacity-100" : "pointer-events-none opacity-0")}><ChevronLeft /></button>
          <button aria-label="Next page" onClick={(e) => { e.stopPropagation(); go(index + 1); }} onPointerDown={(e) => e.stopPropagation()} className={cn("absolute right-2 top-1/2 hidden size-11 -translate-y-1/2 items-center justify-center rounded-full bg-black/50 text-white transition-opacity md:flex", showUi ? "opacity-100" : "pointer-events-none opacity-0")}><ChevronRight /></button>
        </div>
      )}

      {/* Lock Mode: zero reader UI — only a small thin Edge Panel tab on the right edge; tap to return UI */}
      {locked && (
        <button
          type="button"
          aria-label="Unlock reader UI"
          title="Tap to unlock UI"
          onPointerDown={(e) => e.stopPropagation()}
          onClick={(e) => {
            e.stopPropagation();
            exitLockMode();
          }}
          className="group fixed right-0 top-1/2 z-30 flex h-24 w-7 -translate-y-1/2 touch-manipulation items-center justify-end bg-transparent focus-visible:outline-none"
        >
          <span className="flex h-20 w-2.5 items-center justify-center rounded-l-full border-y-2 border-l-2 border-[#0e0d22] bg-lilac/70 shadow-[-2px_2px_0_#0e0d22] backdrop-blur-sm transition-[width,background-color] duration-150 group-active:w-3.5 group-active:bg-lilac">
            <span className="h-7 w-0.5 rounded-full bg-[#2d2a55]/60" />
          </span>
        </button>
      )}

      <div className={cn(barCls, "bottom-0 safe-b flex-col gap-1.5 border-t-[2.5px] border-[#0e0d22] py-2")} onPointerDown={(e) => e.stopPropagation()}>
        <div className="flex w-full items-center gap-2">
          <button
            type="button"
            aria-label="Previous page"
            disabled={shown <= 0}
            onClick={() => {
              const target = Math.max(0, shown - 1);
              if (mode === "scroll") {
                cancelScrollMomentumRef.current();
                restoring.current = false;
                initial.current = target;
                scrollToPage(target);
                setIndex(target);
              } else {
                go(target);
              }
              poke();
            }}
            className="flex size-9 shrink-0 items-center justify-center rounded-full border-2 border-[#0e0d22] bg-[#252250] text-white disabled:opacity-40 active:scale-90 active:bg-white/20"
          >
            <ChevronLeft className="size-4" />
          </button>
          <span className="w-9 text-right text-xs tabular-nums text-white/80">{n > 0 ? shown + 1 : 0}</span>
          <input
            type="range"
            min={0}
            max={Math.max(0, n - 1)}
            step={1}
            value={shown}
            onChange={(e) => onScrubChange(+e.target.value)}
            onPointerDown={(e) => { e.stopPropagation(); dragging.current = true; scrubbing.current = true; poke(); }}
            onPointerUp={(e) => { e.stopPropagation(); if (dragging.current) commitScrub(scrub ?? index); }}
            onPointerCancel={() => { if (dragging.current) commitScrub(scrub ?? index); }}
            onKeyDown={(e) => e.stopPropagation()}
            aria-label="Page scrubber"
            aria-valuetext={`Page ${shown + 1} of ${n}`}
            style={{ "--p": n > 1 ? shown / (n - 1) : 0 } as React.CSSProperties}
            className="scrubber min-w-0 flex-1"
          />
          <span className="w-9 text-xs tabular-nums text-white/80">{n}</span>
          <button
            type="button"
            aria-label="Next page"
            disabled={shown >= n - 1}
            onClick={() => {
              const target = Math.min(n - 1, shown + 1);
              if (mode === "scroll") {
                cancelScrollMomentumRef.current();
                restoring.current = false;
                initial.current = target;
                scrollToPage(target);
                setIndex(target);
              } else {
                go(target);
              }
              poke();
            }}
            className="flex size-9 shrink-0 items-center justify-center rounded-full border-2 border-[#0e0d22] bg-[#252250] text-white disabled:opacity-40 active:scale-90 active:bg-white/20"
          >
            <ChevronRight className="size-4" />
          </button>
          {mode === "auto" && (
            <select value={settings.autoNextSec} onChange={(e) => setSettings({ autoNextSec: +e.target.value })} aria-label="Seconds per page" className="h-9 rounded-full border-2 border-[#0e0d22] bg-[#252250] px-2.5 text-xs font-bold text-white">
              {SECONDS.map((v) => <option key={v} value={v}>{v} s</option>)}
            </select>
          )}
        </div>
        <div role="radiogroup" aria-label="Reading mode" className="grid w-full grid-cols-3 gap-1 rounded-full border-[2.5px] border-[#0e0d22] bg-[#252250] p-1">
          {MODES.map((m) => (
            <button key={m.value} role="radio" aria-checked={mode === m.value} title={MODE_HINT[m.value]} onClick={() => { cancelScrollMomentumRef.current(); setSettings({ readerMode: m.value }); initial.current = index; setZoomAnim(false); zoomRef.current = { s: 1, x: 0, y: 0 }; setZoom({ s: 1, x: 0, y: 0 }); scrollZoomRef.current = { s: 1, x: 0, y: 0 }; setScrollZoom({ s: 1, x: 0, y: 0 }); poke(); }} className={cn("flex h-11 min-w-0 touch-manipulation items-center justify-center gap-1.5 rounded-full border-2 px-1 text-[13px] font-bold transition-colors", mode === m.value ? "border-[#0e0d22] bg-butter text-on" : "border-transparent text-white/80 active:bg-white/15")}>
              <m.icon className="size-4 shrink-0" /><span className="truncate">{m.label}</span>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
