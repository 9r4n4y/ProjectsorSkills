// Browser preview backend. Implements NativeApi with a generated library so the UI can be explored without a device.
// Extraction is simulated with the real shared JobQueue, layer helpers and verification rules.

import {
  type ApiEvent,
  type ArchiveRecord,
  type ComicRecord,
  DEFAULT_SETTINGS,
  type FolderRecord,
  type HealthCheck,
  type ImportApply,
  type InitInfo,
  JobQueue,
  type LayerResult,
  type NativeApi,
  type PageInfo,
  type Settings,
  type StatePatch,
  type TagDef,
  type TrashItem,
  type VerificationReport,
  layer,
  normalizeText,
  skipped,
  summarizeLayers,
} from "@comiclib/shared";

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

function rng(seed: number) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
const hash = (s: string) => [...s].reduce((h, c) => (Math.imul(h, 31) + c.charCodeAt(0)) >>> 0, 7);

const svgUrl = (svg: string) => `data:image/svg+xml;utf8,${encodeURIComponent(svg)}`;
const thumbCache = new Map<string, string>();

/** Geometric generated cover, 2:3. */
function cover(seed: number, w = 200, label = ""): string {
  const key = `${seed}:${w}:${label}`;
  const hit = thumbCache.get(key);
  if (hit) return hit;
  const r = rng(seed);
  const h = Math.round((w * 3) / 2);
  const hue = Math.floor(r() * 360);
  const bg = `hsl(${hue} 14% 22%)`;
  const c1 = `hsl(${hue} 40% 62%)`;
  const c2 = `hsl(${(hue + 40) % 360} 28% 78%)`;
  const shapes: string[] = [];
  const kind = Math.floor(r() * 3);
  for (let i = 0; i < 4; i++) {
    const x = r() * w;
    const y = r() * h;
    const s = 24 + r() * w * 0.4;
    const fill = i % 2 ? c1 : c2;
    if ((kind + i) % 3 === 0) shapes.push(`<circle cx="${x}" cy="${y}" r="${s / 2}" fill="${fill}" opacity=".85"/>`);
    else if ((kind + i) % 3 === 1) shapes.push(`<rect x="${x - s / 2}" y="${y - s / 2}" width="${s}" height="${s * 0.7}" fill="${fill}" opacity=".8"/>`);
    else shapes.push(`<polygon points="${x},${y - s / 2} ${x + s / 2},${y + s / 2} ${x - s / 2},${y + s / 2}" fill="${fill}" opacity=".8"/>`);
  }
  const text = label ? `<text x="${w / 2}" y="${h - 14}" text-anchor="middle" font-family="sans-serif" font-size="${Math.round(w / 14)}" fill="${c2}">${label}</text>` : "";
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${w}" height="${h}" viewBox="0 0 ${w} ${h}"><rect width="${w}" height="${h}" fill="${bg}"/>${shapes.join("")}<rect x="0" y="${h * 0.78}" width="${w}" height="${h * 0.22}" fill="${bg}" opacity=".92"/>${text}</svg>`;
  const url = svgUrl(svg);
  if (thumbCache.size > 3000) thumbCache.clear();
  thumbCache.set(key, url);
  return url;
}

const ADJ = ["Silent", "Harbor", "Winter", "Paper", "Garden", "Iron", "Echo", "Lantern", "Orbit", "Meadow", "Copper", "Tidal", "Velvet", "Northern", "Hollow", "Quiet", "Glass", "Amber"];
const NOUN = ["Sisters", "Letters", "Atlas", "Station", "Orchard", "Compass", "Archive", "Season", "Signal", "Bridge", "Tales", "Almanac", "Harvest", "Courier"];
const AUTHORS = ["Aoki Rin", "Brandt", "Chen Wei", "Dubois", "Esposito", "Fujimoto", "Garcia", "Hansen", "Ivanova", "Jensen", "Kovacs", "Lindqvist", "Moreau", "Novak"];
const TAGS = ["color", "black and white", "romance", "action", "mystery", "slice of life", "fantasy", "sci-fi", "drama", "short", "series", "award winner", "reprint", "anthology"];

function buildComics(): { comics: ComicRecord[]; folders: FolderRecord[] } {
  const r = rng(42);
  const comics: ComicRecord[] = [];
  const now = Date.now();
  for (let i = 0; i < 640; i++) {
    const a = AUTHORS[Math.floor(r() * AUTHORS.length)];
    const series = r() < 0.3 ? `Series ${String.fromCharCode(65 + Math.floor(r() * 3))}` : "";
    const base = `${ADJ[Math.floor(r() * ADJ.length)]} ${NOUN[Math.floor(r() * NOUN.length)]}`;
    const vol = `Vol. ${String(1 + Math.floor(r() * 12)).padStart(2, "0")}`;
    const decor = r();
    const name = decor < 0.2 ? `[${a.split(" ")[0]}] ${base} (${2008 + Math.floor(r() * 17)})` : decor < 0.35 ? `${base}'s Chronicle - ${vol}` : `${base} ${vol}`;
    const folder = series ? `${a}/${series}` : a;
    const pages = 12 + Math.floor(r() * 56);
    const tags = TAGS.filter(() => r() < 0.14);
    comics.push({
      id: `d${i}`,
      path: `/Comics/${folder}/${name}`,
      relPath: `${folder}/${name}`,
      name,
      folder,
      author: a,
      pages,
      size: pages * (180_000 + Math.floor(r() * 400_000)),
      mtime: now - Math.floor(r() * 4e10),
      addedAt: now - Math.floor(r() * 2e10),
      favorite: r() < 0.05,
      read: r() < 0.2,
      lastPage: 0,
      lastReadAt: r() < 0.06 ? now - Math.floor(r() * 5e8) : 0,
      tags,
      thumbRev: 0,
      verification: r() < 0.15 ? "green" : undefined,
    });
  }
  return { comics: dedupe(comics), folders: foldersOf(comics) };
}

function dedupe(c: ComicRecord[]): ComicRecord[] {
  const seen = new Set<string>();
  return c.filter((x) => (seen.has(x.relPath) ? false : (seen.add(x.relPath), true)));
}

function foldersOf(comics: ComicRecord[], extra: string[] = []): FolderRecord[] {
  const map = new Map<string, FolderRecord>();
  const get = (p: string) => {
    let f = map.get(p);
    if (!f) {
      const i = p.lastIndexOf("/");
      f = { path: p, name: p.slice(i + 1), parent: i < 0 ? "" : p.slice(0, i), kind: i < 0 ? "author" : "folder", comics: 0, size: 0 };
      map.set(p, f);
    }
    return f;
  };
  for (const e of extra) get(e);
  for (const c of comics) {
    let p = c.folder;
    while (p) {
      const f = get(p);
      f.comics++;
      f.size += c.size;
      p = p.includes("/") ? p.slice(0, p.lastIndexOf("/")) : "";
    }
  }
  return [...map.values()].sort((a, b) => a.path.localeCompare(b.path));
}

const passLayers = (): LayerResult[] => [
  layer(1, "pass", "Archive test passed (7z)"),
  layer(2, "pass", "48 entries match the archive listing"),
  layer(3, "pass", "48 checksum(s) verified"),
  layer(4, "pass", "48 files, 31457280 bytes match"),
  layer(5, "pass", "48 images decoded"),
  layer(6, "pass", "Page numbering is continuous"),
  layer(7, "pass", "No empty or tiny files"),
  layer(8, "pass", "1 manifest(s) written"),
  layer(9, "pass", "48 files and sizes match"),
  layer(10, "pass", "1 comic(s) indexed with valid thumbnails"),
];

const STORE_KEY = "comiclib-demo-state-v1";

export function createDemoApi(): NativeApi {
  const base = buildComics();
  let comics = base.comics;
  let extraFolders: string[] = [];
  let tagDefs: TagDef[] = TAGS.map((name) => ({ name }));
  let settings: Settings = { ...DEFAULT_SETTINGS };
  let passwords: { id: string; label: string; value: string }[] = [{ id: "p1", label: "Common password", value: "comics123" }];
  let trash: (TrashItem & { archive: ArchiveRecord })[] = [];
  let reports: VerificationReport[] = [];
  let demoSessionUnlocked = false;
  const listeners = new Map<ApiEvent, Set<(p: unknown) => void>>();
  const emit = (e: ApiEvent, p: unknown = {}) => listeners.get(e)?.forEach((cb) => cb(p));

  try {
    const saved = JSON.parse(localStorage.getItem(STORE_KEY) ?? "null");
    if (saved) {
      settings = { ...settings, ...saved.settings };
      const byId = new Map<string, any>(saved.comics ?? []);
      comics = comics.map((c) => (byId.has(c.id) ? { ...c, ...byId.get(c.id) } : c));
      tagDefs = saved.tagDefs ?? tagDefs;
    }
  } catch {
    /* ignore corrupt preview state */
  }
  const persist = () => {
    try {
      localStorage.setItem(
        STORE_KEY,
        JSON.stringify({ settings, tagDefs, comics: comics.map((c) => [c.id, { favorite: c.favorite, read: c.read, lastPage: c.lastPage, lastReadAt: c.lastReadAt, tags: c.tags }]) }),
      );
    } catch {
      /* storage full */
    }
  };

  const mkArchive = (name: string, folder: string, status: ArchiveRecord["status"], size: number, extra: Partial<ArchiveRecord> = {}): ArchiveRecord => ({
    id: "a_" + hash(folder + name).toString(16),
    path: `/Comics/${folder}/${name}.cbz`,
    relPath: `${folder}/${name}.cbz`,
    name,
    folder,
    author: folder.split("/")[0],
    size,
    parts: [`${name}.cbz`],
    missingParts: [],
    encrypted: false,
    status,
    targetName: name,
    ...extra,
  });
  const MB = 1024 * 1024;
  let archives: ArchiveRecord[] = [
    mkArchive("Paper Courier Vol. 01", "Aoki Rin", "pending", 142 * MB),
    mkArchive("Paper Courier Vol. 02", "Aoki Rin", "pending", 128 * MB),
    mkArchive("Winter Almanac", "Brandt", "pending", 96 * MB),
    mkArchive("Harbor Tales Vol. 03", "Chen Wei", "pending", 210 * MB),
    mkArchive("Echo Station (Gap in pages)", "Dubois", "pending", 64 * MB),
    mkArchive("Locked Orchard Vol. 01", "Esposito", "pending", 88 * MB, { encrypted: true }),
    mkArchive("Locked Orchard Vol. 02", "Esposito", "pending", 91 * MB, { encrypted: true }),
    mkArchive("Corrupt Signal Vol. 01", "Fujimoto", "pending", 77 * MB),
    mkArchive("Amber Bridge", "Garcia/Series A", "pending", 54 * MB),
    mkArchive("Tidal Compass Vol. 04", "Hansen", "pending", 160 * MB),
    mkArchive("Hollow Letters (split)", "Ivanova", "failed", 300 * MB, { parts: ["Hollow Letters.7z.001", "Hollow Letters.7z.003"], missingParts: ["Hollow Letters.7z.002"], detail: "Missing volume(s): Hollow Letters.7z.002" }),
    mkArchive("Velvet Meadow Vol. 05", "Jensen", "done", 118 * MB, { uncompressed: 121 * MB }),
    mkArchive("Quiet Harvest Vol. 02", "Kovacs", "done", 102 * MB, { uncompressed: 104 * MB }),
    mkArchive("Glass Atlas", "Lindqvist", "done", 83 * MB, { uncompressed: 84 * MB }),
  ];
  const sizeMB = (n: number) => n * MB;
  reports = archives
    .filter((a) => a.status === "done")
    .map((a) => ({
      id: a.id, subject: a.name, archiveRelPath: a.relPath, archiveSize: a.size, comicIds: [], outputRelPaths: [`${a.folder}/${a.name}`],
      layers: passLayers(), status: "green" as const, state: "done" as const, attempts: [{ n: 1, engine: "7z", mode: "extract", ok: true, ms: 4200 }], warnings: [], manual: false,
      uncompressed: a.uncompressed ?? sizeMB(100), extractedBytes: a.uncompressed ?? sizeMB(100), updatedAt: Date.now(),
    }));
  reports.push({
    id: archives.find((a) => a.status === "failed")!.id, subject: "Hollow Letters (split)", archiveRelPath: "Ivanova/Hollow Letters.7z.001", archiveSize: 300 * MB, comicIds: [], outputRelPaths: [],
    layers: [layer(1, "fail", "Volumes are missing", ["missing: Hollow Letters.7z.002"]), ...Array.from({ length: 9 }, (_, i) => skipped(i + 2, "Not reached"))],
    status: "red", state: "failed", error: "Missing volume(s): Hollow Letters.7z.002", attempts: [], warnings: [], manual: false, uncompressed: 0, extractedBytes: 0, updatedAt: Date.now(),
  });

  const queue = new JobQueue({ concurrency: 2 });
  queue.subscribe((s) => emit("jobs", s));

  queue.register<{ archiveId: string; password?: string }>("extract", async (ctx) => {
    const a = archives.find((x) => x.id === ctx.payload.archiveId);
    if (!a) return;
    a.status = "extracting";
    emit("library");
    const steps = 24;
    for (let i = 0; i <= steps; i++) {
      if (ctx.signal.aborted) {
        a.status = "queued";
        emit("library");
        return;
      }
      ctx.progress({ fraction: (i / steps) * 0.95, message: i < 4 ? "Testing integrity" : i < 18 ? "Extracting" : "Verifying", bytes: (a.size * i) / steps, totalBytes: a.size });
      await sleep(70 + Math.random() * 60);
    }
    const rep: VerificationReport = {
      id: a.id, subject: a.name, archiveRelPath: a.relPath, archiveSize: a.size, comicIds: [], outputRelPaths: [], layers: passLayers(), status: "green", state: "done",
      attempts: [{ n: 1, engine: "7z", mode: "extract", ok: true, ms: 3000 }], warnings: [], manual: false, uncompressed: Math.round(a.size * 1.02), extractedBytes: Math.round(a.size * 1.02), updatedAt: Date.now(),
    };
    const fail = (state: ArchiveRecord["status"], msg: string, layers: LayerResult[], status: "red" | "amber") => {
      a.status = state;
      a.detail = msg;
      reports = [...reports.filter((r) => r.id !== a.id), { ...rep, layers, status, state, error: msg, engineOutput: `7-Zip 24.08\nERROR: ${msg}\n`, attempts: [{ n: 1, engine: "7z", mode: "extract", ok: false, error: msg, ms: 900 }, { n: 2, engine: "7za", mode: "alternate engine, entry by entry", ok: false, error: msg, ms: 1100 }], uncompressed: 0 }];
    };
    if (/Locked/.test(a.name) && !ctx.payload.password && !passwords.some((p) => p.value === "locked")) {
      fail("needs_password", "Password required", [layer(1, "warn", "Archive is encrypted and no saved password matched"), ...Array.from({ length: 9 }, (_, i) => skipped(i + 2, "Not reached"))], "amber");
      return;
    }
    if (/Corrupt/.test(a.name)) {
      fail("quarantined", "Archive integrity test failed with every engine", [layer(1, "fail", "Archive test failed (7z)", ["Data Error in 'Corrupt Signal Vol. 01.cbz/034.jpg'. File is broken", "CRC Failed"]), ...Array.from({ length: 9 }, (_, i) => skipped(i + 2, "Not reached"))], "red");
      return;
    }
    const count = 8 + Math.floor(Math.random() * 3);
    const folder = a.folder;
    const n: ComicRecord = {
      id: "d_x" + hash(a.id), path: `/Comics/${folder}/${a.targetName}`, relPath: `${folder}/${a.targetName}`, name: a.targetName, folder, author: a.author,
      pages: 30 + Math.floor(Math.random() * 20), size: a.size, mtime: Date.now(), addedAt: Date.now(), favorite: false, read: false, lastPage: 0, lastReadAt: 0, tags: [], thumbRev: 0, verification: "green",
    };
    comics = [n, ...comics.filter((c) => c.id !== n.id)];
    rep.comicIds = [n.id];
    rep.outputRelPaths = [n.relPath];
    if (/Gap/.test(a.name)) rep.layers[5] = layer(6, "warn", "1 numbering issue(s)", ["missing page number(s): 17, 18"]);
    rep.status = summarizeLayers(rep.layers);
    reports = [...reports.filter((r) => r.id !== a.id), rep];
    a.status = "done";
    a.uncompressed = rep.uncompressed;
    a.detail = undefined;
    void count;
    emit("library");
  });
  queue.register("verify", async (ctx) => {
    for (let i = 0; i < 10 && !ctx.signal.aborted; i++) {
      ctx.progress({ fraction: i / 10, message: "Verifying" });
      await sleep(90);
    }
    const id = (ctx.payload as { id: string }).id;
    reports = reports.map((r) => (r.id === id || r.comicIds.includes(id) ? { ...r, updatedAt: Date.now() } : r));
    emit("library");
  });
  queue.register("scan", async (ctx) => {
    for (let i = 0; i < 8; i++) {
      ctx.progress({ fraction: i / 8, message: `${i * 80} comics` });
      await sleep(60);
    }
  });

  const snapshot = () => ({
    root: "/Comics (browser preview)",
    comics,
    folders: foldersOf(comics, extraFolders),
    archives: archives.filter((a) => a.status !== "deleted"),
    tags: tagDefs,
    reports,
    trash: trash.map(({ archive: _a, ...t }) => t),
  });

  const counts = () => ({ comics: comics.length, tags: new Set(comics.flatMap((c) => c.tags.map(normalizeText))).size, favorites: comics.filter((c) => c.favorite).length, read: comics.filter((c) => c.read).length });
  let backups: Record<string, string> = {};

  const api: Partial<NativeApi> & { platform: "demo" } = {
    platform: "demo",
    async init(): Promise<InitInfo> {
      return {
        platform: "demo", appVersion: "1.0.0", root: "/Comics (browser preview)", settings, savedPasswordCount: passwords.length, needsOnboarding: false, demo: true,
        permissions: { allFiles: "granted", safFolder: "unsupported", notifications: "granted", foregroundService: "unsupported", wakeLock: "unsupported", batteryOptimization: "unsupported" },
        env: { os: navigator.platform || "browser", cpus: navigator.hardwareConcurrency || 4, freeBytes: 182 * 1024 ** 3 },
      };
    },
    async pickFolder() { return "/Comics (browser preview)"; },
    async setRoot() { /* preview library is fixed */ },
    async getLibrary() { return snapshot(); },
    async scan() {
      await new Promise<void>((res) => { const j = queue.add("scan", "Scanning library", {}); const off = queue.subscribe(() => queue.get(j.id)?.state === "done" && (off(), res())); });
      return { comics: comics.length, folders: foldersOf(comics).length, archives: archives.length, added: 0, removed: 0, moved: 0, updated: 0, ms: 480 };
    },
    async saveState(p: StatePatch) {
      if (p.comics) {
        const m = new Map(p.comics.map((c) => [c.id, c]));
        comics = comics.map((c) => (m.has(c.id) ? { ...c, ...m.get(c.id)! } : c));
      }
      if (p.tagDefs) for (const d of p.tagDefs) if (!tagDefs.some((t) => normalizeText(t.name) === normalizeText(d.name))) tagDefs = [...tagDefs, d];
      if (p.deleteTags) {
        const rm = new Set(p.deleteTags.map(normalizeText));
        tagDefs = tagDefs.filter((t) => !rm.has(normalizeText(t.name)));
      }
      if (p.settings) settings = { ...settings, ...p.settings };
      persist();
    },
    async pages(id: string): Promise<PageInfo[]> {
      const c = comics.find((x) => x.id === id);
      if (!c) return [];
      const seed = hash(id);
      return Array.from({ length: c.pages }, (_, i) => ({ name: `${String(i + 1).padStart(3, "0")}.jpg`, url: cover(seed + i * 7919, 480, String(i + 1)), size: 300_000 }));
    },
    thumbUrl: (c, size) => cover(hash(c.id), size === "s" ? 200 : 320),
    async ensureThumb() { /* generated on demand */ },
    async resolveImage(u: string) { return u; },
    async getJobs() { return queue.state(); },
    async extractAll() { await api.extractArchives!(archives.filter((a) => a.status === "pending").map((a) => a.id)); },
    async extractArchives(ids, opts) {
      if (opts?.password && opts.applyToSimilar) passwords = [...passwords, { id: "p" + Date.now(), label: "Added from prompt", value: opts.password }];
      if (opts?.password) passwords = [...passwords, { id: "p" + Date.now(), label: "Added from prompt", value: opts.password }];
      const targets = new Set(ids);
      if (opts?.applyToSimilar) archives.filter((a) => a.status === "needs_password").forEach((a) => targets.add(a.id));
      for (const id of targets) {
        const a = archives.find((x) => x.id === id);
        if (!a || a.status === "extracting") continue;
        a.status = "queued";
        queue.add("extract", `Extract ${a.name}`, { archiveId: id, password: opts?.password ?? (/Locked/.test(a.name) && opts?.password) }, { group: "extract", totalBytes: a.size });
      }
      emit("library");
    },
    async reverify(ids) { ids.forEach((id) => queue.add("verify", `Verify ${id}`, { id }, { group: "verify" })); },
    async jobControl(action, id) {
      if (action === "pause") queue.pauseAll();
      else if (action === "resume") queue.resumeAll();
      else if (action === "cancel") (id ? queue.cancel(id) : queue.cancelAll());
      else if (action === "retry" && id) queue.retry(id);
      else if (action === "clear") queue.clearFinished();
    },
    async skipArchive(id) { const a = archives.find((x) => x.id === id); if (a) a.status = "skipped"; emit("library"); },
    async markManual(id, v) { reports = reports.map((r) => (r.id === id ? { ...r, manual: v } : r)); emit("library"); },
    async openFolder() { /* not available in a browser */ },
    async moveComics(ids, dest) {
      comics = comics.map((c) => (ids.includes(c.id) ? { ...c, folder: dest, author: dest.split("/")[0] ?? "", relPath: `${dest}/${c.name}` } : c));
      emit("library");
      return ids.map((id) => ({ id, ok: true }));
    },
    async createFolder(parent, name) { const p = parent ? `${parent}/${name}` : name; extraFolders = [...extraFolders, p]; emit("library"); return p; },
    async previewDelete(ids) {
      await sleep(600);
      const ok = archives.filter((a) => ids.includes(a.id));
      return { ok: ok.length > 0, archives: ok.map((a) => ({ id: a.id, name: a.name, size: a.size, folders: [`${a.folder}/${a.targetName}`] })), totalBytes: ok.reduce((s, a) => s + a.size, 0), failures: [] };
    },
    async confirmDelete(ids) {
      await sleep(500);
      const moved = archives.filter((a) => ids.includes(a.id));
      trash = [...trash, ...moved.map((a) => ({ id: a.id, name: a.name, originalPath: a.path, size: a.size, deletedAt: Date.now(), archive: a }))];
      moved.forEach((a) => (a.status = "deleted"));
      emit("library");
      return { ok: true, moved: moved.length, failures: [] };
    },
    async trashList() { return trash.map(({ archive: _a, ...t }) => t); },
    async trashRestore(id) { const t = trash.find((x) => x.id === id); if (t) t.archive.status = "done"; trash = trash.filter((x) => x.id !== id); emit("library"); },
    async trashEmpty() { const n = trash.length; trash = []; emit("library"); return n; },
    async listPasswords() { return passwords.map(({ id, label }) => ({ id, label })); },
    async addPassword(label, value) { passwords = [...passwords, { id: "p" + Date.now(), label, value }]; },
    async removePassword(id) { passwords = passwords.filter((p) => p.id !== id); },
    async exportPasswords() { return passwords.map((p) => p.value); },
    async sizeReport() {
      const per = new Map<string, { folder: string; bytes: number; archives: number; archiveBytes: number }>();
      const slot = (f: string) => per.get(f) ?? per.set(f, { folder: f, bytes: 0, archives: 0, archiveBytes: 0 }).get(f)!;
      comics.forEach((c) => (slot(c.author).bytes += c.size));
      archives.forEach((a) => { const s = slot(a.author); s.archives++; s.archiveBytes += a.size; });
      const ex = comics.reduce((s, c) => s + c.size, 0);
      const ab = archives.reduce((s, a) => s + a.size, 0);
      return {
        rootBytes: ex + ab, archiveBytes: ab, extractedBytes: ex, archiveUncompressed: archives.reduce((s, a) => s + (a.uncompressed ?? 0), 0),
        perFolder: [...per.values()].sort((a, b) => b.bytes - a.bytes),
        comparisons: archives.filter((a) => a.uncompressed).map((a) => ({ archive: a.name, uncompressed: a.uncompressed!, extracted: Math.round(a.uncompressed! * 0.999), ok: true })),
      };
    },
    async folderCheck() {
      const f = foldersOf(comics, extraFolders).length;
      return { diskFolders: f, diskComics: comics.length, libraryFolders: f, libraryComics: comics.length, mismatches: [] };
    },
    async fixFolders() { return api.scan!(); },
    async exportPage(comicId, pageIndex) {
      const c = comics.find((x) => x.id === comicId);
      const list = await api.pages!(comicId);
      const p = list[Math.max(0, Math.min(list.length - 1, pageIndex))];
      if (!p) return { ok: false };
      const filename = `${(c?.name ?? "comic").replace(/[^\w.-]+/g, "_")}_page_${String(pageIndex + 1).padStart(3, "0")}.svg`;
      const a = document.createElement("a");
      a.href = p.url;
      a.download = filename;
      a.click();
      return { ok: true, filename, pages: 1 };
    },
    async exportComic(comicId) {
      const c = comics.find((x) => x.id === comicId);
      const list = await api.pages!(comicId);
      if (!list.length) return { ok: false };
      const enc = new TextEncoder();
      const crcTable = new Uint32Array(256);
      for (let i = 0; i < 256; i++) {
        let v = i;
        for (let k = 0; k < 8; k++) v = v & 1 ? 0xedb88320 ^ (v >>> 1) : v >>> 1;
        crcTable[i] = v >>> 0;
      }
      const crcOf = (b: Uint8Array) => {
        let v = 0xffffffff;
        for (let i = 0; i < b.length; i++) v = crcTable[(v ^ b[i]) & 0xff] ^ (v >>> 8);
        return (v ^ 0xffffffff) >>> 0;
      };
      const parts: Uint8Array[] = [];
      const central: Uint8Array[] = [];
      let offset = 0;
      for (let i = 0; i < list.length; i++) {
        const res = await fetch(list[i].url);
        const data = new Uint8Array(await res.arrayBuffer());
        const name = enc.encode(`${String(i + 1).padStart(3, "0")}.svg`);
        const crc = crcOf(data);
        const lh = new Uint8Array(30);
        const lv = new DataView(lh.buffer);
        lv.setUint32(0, 0x04034b50, true);
        lv.setUint16(4, 20, true);
        lv.setUint32(14, crc, true);
        lv.setUint32(18, data.length, true);
        lv.setUint32(22, data.length, true);
        lv.setUint16(26, name.length, true);
        parts.push(lh, name, data);
        const ch = new Uint8Array(46);
        const cv = new DataView(ch.buffer);
        cv.setUint32(0, 0x02014b50, true);
        cv.setUint16(4, 20, true);
        cv.setUint16(6, 20, true);
        cv.setUint32(16, crc, true);
        cv.setUint32(20, data.length, true);
        cv.setUint32(24, data.length, true);
        cv.setUint16(28, name.length, true);
        cv.setUint32(42, offset, true);
        central.push(ch, name);
        offset += lh.length + name.length + data.length;
      }
      const cdLen = central.reduce((s, a) => s + a.length, 0);
      const eocd = new Uint8Array(22);
      const ev = new DataView(eocd.buffer);
      ev.setUint32(0, 0x06054b50, true);
      ev.setUint16(8, list.length, true);
      ev.setUint16(10, list.length, true);
      ev.setUint32(12, cdLen, true);
      ev.setUint32(16, offset, true);
      const filename = `${(c?.name ?? "comic").replace(/[^\w.-]+/g, "_")}.cbz`;
      const blob = new Blob([...parts, ...central, eocd], { type: "application/zip" });
      const a = document.createElement("a");
      a.href = URL.createObjectURL(blob);
      a.download = filename;
      a.click();
      return { ok: true, filename, pages: list.length };
    },
    async saveTextFile(name, text) {
      const a = document.createElement("a");
      a.href = URL.createObjectURL(new Blob([text], { type: "application/json" }));
      a.download = name;
      a.click();
      return name;
    },
    pickTextFile: () => new Promise((resolve) => {
      const i = document.createElement("input");
      i.type = "file";
      i.accept = "application/json,.json";
      i.onchange = async () => resolve(i.files?.[0] ? await i.files[0].text() : null);
      i.oncancel = () => resolve(null);
      i.click();
    }),
    async backupDb() { const id = `backup-${Date.now()}.db`; backups[id] = JSON.stringify({ comics, tagDefs }); return id; },
    async restoreBackup(id) { const b = JSON.parse(backups[id]); comics = b.comics; tagDefs = b.tagDefs; persist(); emit("library"); },
    async applyImport(a: ImportApply) {
      const before = counts();
      const backupId = await api.backupDb!();
      await api.saveState!({ comics: a.comics, tagDefs: a.tagDefs, settings: a.settings });
      emit("library");
      return { before, after: counts(), backupId, applied: a.comics.length };
    },
    async runHealth(repair) {
      await sleep(500);
      const checks: HealthCheck[] = [
        { id: "db", title: "Database integrity", status: "green", summary: "Healthy, schema v2", details: ["FTS rows match comics"], repairable: false },
        { id: "disk", title: "Library versus disk", status: "green", summary: `${comics.length} comics and ${foldersOf(comics).length} folders match`, details: [], repairable: false },
        { id: "thumbs", title: "Thumbnails", status: repair ? "green" : "amber", summary: repair ? "All thumbnails present" : "3 missing or corrupt", details: repair ? [] : ["Silent Atlas Vol. 02", "Iron Compass Vol. 07", "Echo Courier Vol. 01"], repairable: !repair },
        { id: "manifests", title: "Extracted comics versus manifests", status: "green", summary: "20 sampled comics match their manifests", details: [], repairable: false },
        { id: "meta", title: "Metadata consistency", status: "green", summary: "14 tags consistent", details: [], repairable: false },
        { id: "dups", title: "Duplicate comics", status: "green", summary: "No duplicates found", details: [], repairable: false },
        { id: "env", title: "Storage, permissions and service", status: "green", summary: "182.0 GB free, file access granted, queue running", details: [], repairable: false },
      ];
      return { ranAt: Date.now(), checks, log: repair ? [`${new Date().toISOString()}  Regenerated 3 thumbnail(s)`] : [] };
    },
    async setSystemBars() {},
    async setKeepScreenOn() {},
    async getSessionUnlocked() { return demoSessionUnlocked; },
    async setSessionUnlocked(v) { demoSessionUnlocked = v; },
    async getPermissions() { return (await api.init!()).permissions; },
    async requestPermission() { return (await api.init!()).permissions; },
    async openSystemSettings() { /* not applicable */ },
    async diagnostics() { return `Folio v5.1 (browser preview)\nUser agent: ${navigator.userAgent}\nComics: ${comics.length}`; },
    async copyText(t) { await navigator.clipboard?.writeText(t).catch(() => undefined); },
    on(e, cb) {
      (listeners.get(e) ?? listeners.set(e, new Set()).get(e)!).add(cb);
      return () => listeners.get(e)?.delete(cb);
    },
  };
  backups = {};
  return api as NativeApi;
}
