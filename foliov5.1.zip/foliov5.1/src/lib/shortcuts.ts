import type { Settings } from "@comiclib/shared";

export type ShortcutAction =
  | "openSearch"
  | "toggleEdgePanel"
  | "goLibrary"
  | "goTags"
  | "goSettings"
  | "toggleSelectMode"
  | "lockApp"
  | "readerNext"
  | "readerPrev"
  | "readerZoomIn"
  | "readerZoomOut"
  | "readerZoomReset"
  | "readerFullscreen"
  | "readerLockUi"
  | "readerExportPage"
  | "readerClose";

export interface ShortcutDef {
  id: ShortcutAction;
  group: "Navigation & Library" | "Comic Reader";
  label: string;
  description: string;
  defaultKey: string;
}

export const SHORTCUT_DEFS: ShortcutDef[] = [
  { id: "openSearch", group: "Navigation & Library", label: "Focus search", description: "Jump directly to the library search bar", defaultKey: "/" },
  { id: "toggleEdgePanel", group: "Navigation & Library", label: "Toggle Edge Panel", description: "Open or close the right-edge navigation panel", defaultKey: "m" },
  { id: "goLibrary", group: "Navigation & Library", label: "Go to Library", description: "Switch to the main comics grid", defaultKey: "g" },
  { id: "goTags", group: "Navigation & Library", label: "Go to Tags", description: "Open the Tags management screen", defaultKey: "t" },
  { id: "goSettings", group: "Navigation & Library", label: "Open Settings", description: "Switch to the Settings screen", defaultKey: "," },
  { id: "toggleSelectMode", group: "Navigation & Library", label: "Toggle Select mode", description: "Start or exit bulk comic selection in the library", defaultKey: "s" },
  { id: "lockApp", group: "Navigation & Library", label: "Lock app now", description: "Immediately lock Folio (when App Lock is enabled)", defaultKey: "l" },

  { id: "readerNext", group: "Comic Reader", label: "Next page", description: "Go to next page (or scroll down in Scroll mode)", defaultKey: "ArrowRight" },
  { id: "readerPrev", group: "Comic Reader", label: "Previous page", description: "Go to previous page (or scroll up in Scroll mode)", defaultKey: "ArrowLeft" },
  { id: "readerZoomIn", group: "Comic Reader", label: "Zoom in", description: "Increase page zoom level", defaultKey: "=" },
  { id: "readerZoomOut", group: "Comic Reader", label: "Zoom out", description: "Decrease page zoom level", defaultKey: "-" },
  { id: "readerZoomReset", group: "Comic Reader", label: "Reset zoom", description: "Reset page zoom back to 100%", defaultKey: "0" },
  { id: "readerFullscreen", group: "Comic Reader", label: "Toggle fullscreen", description: "Enter or exit fullscreen mode", defaultKey: "f" },
  { id: "readerLockUi", group: "Comic Reader", label: "Toggle Reader Lock Mode", description: "Hide or restore all reader UI bars", defaultKey: "k" },
  { id: "readerExportPage", group: "Comic Reader", label: "Export current page", description: "Export the currently opened comic page", defaultKey: "e" },
  { id: "readerClose", group: "Comic Reader", label: "Close reader", description: "Exit the comic reader back to library", defaultKey: "Escape" },
];

export const DEFAULT_SHORTCUTS: Record<ShortcutAction, string> = SHORTCUT_DEFS.reduce(
  (acc, d) => {
    acc[d.id] = d.defaultKey;
    return acc;
  },
  {} as Record<ShortcutAction, string>,
);

/** Normalize a KeyboardEvent into a canonical binding string like "Ctrl+Shift+K" or "ArrowRight". */
export function eventToBinding(e: KeyboardEvent): string | null {
  const k = e.key;
  if (k === "Control" || k === "Shift" || k === "Alt" || k === "Meta") return null;
  const parts: string[] = [];
  if (e.ctrlKey || e.metaKey) parts.push("Ctrl");
  if (e.altKey) parts.push("Alt");
  if (e.shiftKey && k.length > 1) parts.push("Shift");
  const normKey = k === " " ? "Space" : k.length === 1 ? k.toLowerCase() : k;
  parts.push(normKey);
  return parts.join("+");
}

export function getBinding(settings: Settings, action: ShortcutAction): string {
  const custom = settings.shortcuts?.[action];
  return custom !== undefined ? custom : DEFAULT_SHORTCUTS[action];
}

export function matchesShortcut(e: KeyboardEvent, settings: Settings, action: ShortcutAction): boolean {
  const binding = getBinding(settings, action);
  if (!binding) return false;
  const pressed = eventToBinding(e);
  if (!pressed) return false;
  if (pressed === binding) return true;
  // Also allow "+" to trigger default "=" zoom-in smoothly
  if (action === "readerZoomIn" && binding === "=" && e.key === "+") return true;
  return false;
}

export function formatBinding(binding: string): string {
  if (!binding) return "Unbound";
  return binding
    .replace("ArrowRight", "→")
    .replace("ArrowLeft", "←")
    .replace("ArrowUp", "↑")
    .replace("ArrowDown", "↓")
    .replace("Escape", "Esc")
    .replace("Space", "Space");
}
