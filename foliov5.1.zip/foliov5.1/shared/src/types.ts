// Shared domain types used by the UI, the Electron main process and the demo backend.

export type Platform = "electron" | "android" | "demo";
export type Tri = "green" | "amber" | "red";
export type LayerStatus = "pass" | "warn" | "fail" | "skip";

export interface Fingerprint {
  pages: number;
  /** SHA-256 over the ordered list of page sizes */
  sizes: string;
  /** SHA-256 of the first page */
  first: string;
  /** SHA-256 of the last page */
  last: string;
}

export interface ComicRecord {
  id: string;
  /** absolute path on the device */
  path: string;
  /** path relative to the mother folder, "/" separated */
  relPath: string;
  name: string;
  /** relative path of the containing folder, "" when directly under the mother folder */
  folder: string;
  /** top-level (author) folder name, "" when none */
  author: string;
  pages: number;
  size: number;
  mtime: number;
  addedAt: number;
  favorite: boolean;
  read: boolean;
  lastPage: number;
  lastReadAt: number;
  tags: string[];
  fp?: Fingerprint;
  /** bumped when the thumbnail is regenerated */
  thumbRev: number;
  verification?: Tri;
}

export interface FolderRecord {
  path: string;
  name: string;
  parent: string;
  kind: "author" | "folder";
  /** comics in this folder including descendants */
  comics: number;
  size: number;
}

export type ArchiveStatus =
  | "pending"
  | "queued"
  | "extracting"
  | "verifying"
  | "done"
  | "needs_password"
  | "needs_input"
  | "no_images"
  | "failed"
  | "quarantined"
  | "skipped"
  | "deleted";

export interface ArchiveRecord {
  id: string;
  path: string;
  relPath: string;
  name: string;
  folder: string;
  author: string;
  size: number;
  parts: string[];
  missingParts: string[];
  encrypted: boolean;
  status: ArchiveStatus;
  /** folder the archive extracts to (name without extension) */
  targetName: string;
  uncompressed?: number;
  detail?: string;
}

export interface TagDef {
  name: string;
  color?: string;
}

export interface LayerResult {
  layer: number;
  name: string;
  status: LayerStatus;
  summary: string;
  details: string[];
}

export interface AttemptLog {
  n: number;
  engine: string;
  mode: string;
  ok: boolean;
  error?: string;
  ms: number;
}

export interface VerificationReport {
  id: string;
  subject: string;
  archiveRelPath: string;
  archiveSize: number;
  comicIds: string[];
  outputRelPaths: string[];
  layers: LayerResult[];
  status: Tri;
  state: ArchiveStatus;
  error?: string;
  engineOutput?: string;
  attempts: AttemptLog[];
  warnings: string[];
  manual: boolean;
  uncompressed: number;
  extractedBytes: number;
  updatedAt: number;
}

export type JobState = "queued" | "running" | "paused" | "done" | "failed" | "cancelled";

export interface JobRecord {
  id: string;
  kind: string;
  title: string;
  state: JobState;
  progress: number;
  done: number;
  total: number;
  bytes: number;
  totalBytes: number;
  speed: number;
  etaSec: number | null;
  message: string;
  error?: string;
  attempts: number;
  createdAt: number;
  startedAt?: number;
  finishedAt?: number;
  group?: string;
  payload: unknown;
}

export type Theme = "system" | "light" | "dark";
export type SortKey = "name" | "added" | "modified" | "pages" | "lastRead";
export type ReaderMode = "scroll" | "paged" | "auto";
export type FitMode = "width" | "height";

export interface AppLockSlot {
  id: 1 | 2 | 3;
  label: string;
  salt: string;
  hash: string;
  iter: number;
}

export interface AppLockConfig {
  enabled: boolean;
  mode: "close" | "idle";
  idleMinutes: number;
  slots: AppLockSlot[];
}

export interface Settings {
  theme: Theme;
  density: number; // 1..5
  sort: SortKey;
  sortDir: "asc" | "desc";
  readerMode: ReaderMode;
  fit: FitMode;
  autoNextSec: number;
  workers: number;
  collision: "suffix" | "ask";
  closeToTray: boolean;
  healthOnStart: boolean;
  autoExtractNew: boolean;
  tagMode: "and" | "or";
  pageSize: number; // comics per page, default 20
  zoomPanSensitivity: number; // 0.5..2.5, default 1.0
  keepScreenAwake?: boolean;
  shortcuts?: Record<string, string>;
  appLock?: AppLockConfig;
}

export const DEFAULT_SETTINGS: Settings = {
  theme: "system",
  density: 2,
  sort: "name",
  sortDir: "asc",
  readerMode: "paged",
  fit: "width",
  autoNextSec: 8,
  workers: 0,
  collision: "suffix",
  closeToTray: true,
  healthOnStart: true,
  autoExtractNew: false,
  tagMode: "and",
  pageSize: 20,
  zoomPanSensitivity: 1,
  keepScreenAwake: false,
};

export type PermState = "granted" | "denied" | "unsupported" | "unknown";

export interface PermissionStatus {
  allFiles: PermState;
  safFolder: PermState;
  notifications: PermState;
  foregroundService: PermState;
  wakeLock: PermState;
  batteryOptimization: PermState;
}

export interface HealthCheck {
  id: string;
  title: string;
  status: Tri;
  summary: string;
  details: string[];
  repairable: boolean;
}

export interface HealthReport {
  ranAt: number;
  checks: HealthCheck[];
  log: string[];
}

export interface SizeReport {
  rootBytes: number;
  archiveBytes: number;
  extractedBytes: number;
  archiveUncompressed: number;
  perFolder: { folder: string; bytes: number; archives: number; archiveBytes: number }[];
  comparisons: { archive: string; uncompressed: number; extracted: number; ok: boolean }[];
}

export interface FolderCheck {
  diskFolders: number;
  diskComics: number;
  libraryFolders: number;
  libraryComics: number;
  mismatches: { path: string; reason: string }[];
}

export interface TrashItem {
  id: string;
  name: string;
  originalPath: string;
  size: number;
  deletedAt: number;
}

export interface DeletePreview {
  ok: boolean;
  archives: { id: string; name: string; size: number; folders: string[] }[];
  totalBytes: number;
  failures: { id: string; name: string; reason: string }[];
}

export interface ScanSummary {
  comics: number;
  folders: number;
  archives: number;
  added: number;
  removed: number;
  moved: number;
  updated: number;
  ms: number;
}

export interface LibrarySnapshot {
  root: string | null;
  comics: ComicRecord[];
  folders: FolderRecord[];
  archives: ArchiveRecord[];
  tags: TagDef[];
  reports: VerificationReport[];
  trash: TrashItem[];
}
