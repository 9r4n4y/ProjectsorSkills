import { type ComicRecord, type ComicSeries, naturalCompare, normalizeText, similarity, tokenize } from "@comiclib/shared";

export interface ResolvedSeries {
  series: ComicSeries;
  /** 0-based index of the current comic in `parts` */
  partIndex: number;
  totalParts: number;
  parts: ComicRecord[];
  prev: ComicRecord | null;
  next: ComicRecord | null;
}

export interface RankedCandidate {
  comic: ComicRecord;
  score: number;
  isStrongMatch: boolean;
}

/**
 * Strip trailing volume / part / chapter / episode / issue indicators so
 * "Silent Atlas Vol. 01" and "Silent Atlas Part 2" share the exact same core title.
 */
export function stripPartTokens(name: string): string {
  let s = name.trim();
  // Remove trailing bracketed/parenthesized counters like "(1)", "[Part 2]", "(Ch. 03)"
  s = s.replace(/\s*[\[(]\s*(?:vol(?:ume)?|part|pt|ch(?:apter)?|ep(?:isode)?|issue|book|bk|#)?\s*\.?\s*\d+[a-z]?\s*[\])]\s*$/i, "");
  // Remove trailing "Vol. 01", "Part 2", "Ch 3", "#04", "- 2", etc.
  s = s.replace(/[\s\-_:–—]+(?:vol(?:ume)?|part|pt|ch(?:apter)?|ep(?:isode)?|issue|book|bk|no\.?|#)\s*\.?\s*\d+[a-z]?\s*$/i, "");
  // Remove plain trailing number like "My Comic 02"
  s = s.replace(/[\s\-_:–—]+\d{1,4}\s*$/i, "");
  return s.trim() || name.trim();
}

/** Resolve the series containing `comicId`, automatically ignoring deleted comic IDs. */
export function findSeriesForComic(
  seriesList: readonly ComicSeries[] | undefined,
  comicId: string,
  comics: readonly ComicRecord[],
): ResolvedSeries | null {
  if (!seriesList?.length) return null;
  const byId = new Map(comics.map((c) => [c.id, c]));
  for (const series of seriesList) {
    if (!series.comicIds.includes(comicId)) continue;
    const parts = series.comicIds.map((id) => byId.get(id)).filter((c): c is ComicRecord => !!c);
    if (parts.length < 2) continue;
    const partIndex = parts.findIndex((c) => c.id === comicId);
    if (partIndex < 0) continue;
    return {
      series,
      partIndex,
      totalParts: parts.length,
      parts,
      prev: partIndex > 0 ? parts[partIndex - 1] : null,
      next: partIndex < parts.length - 1 ? parts[partIndex + 1] : null,
    };
  }
  return null;
}

/** Fast lookup map: comicId -> { partNumber (1-based), totalParts, seriesId, seriesName }. */
export function buildSeriesBadgeMap(
  seriesList: readonly ComicSeries[] | undefined,
  comics: readonly ComicRecord[],
): Map<string, { partNumber: number; totalParts: number; seriesId: string; seriesName: string }> {
  const out = new Map<string, { partNumber: number; totalParts: number; seriesId: string; seriesName: string }>();
  if (!seriesList?.length) return out;
  const validIds = new Set(comics.map((c) => c.id));
  for (const s of seriesList) {
    const valid = s.comicIds.filter((id) => validIds.has(id));
    if (valid.length < 2) continue;
    valid.forEach((id, idx) => {
      out.set(id, { partNumber: idx + 1, totalParts: valid.length, seriesId: s.id, seriesName: s.name });
    });
  }
  return out;
}

/**
 * Rank all comics (excluding `excludeIds`) so the comics with the closest matching name
 * to `anchor` appear right at the top, followed by all other comics.
 */
export function rankCandidatesByName(
  anchor: ComicRecord,
  allComics: readonly ComicRecord[],
  query: string,
  excludeIds?: ReadonlySet<string>,
): RankedCandidate[] {
  const anchorCore = normalizeText(stripPartTokens(anchor.name));
  const anchorNorm = normalizeText(anchor.name);
  const anchorTokens = new Set(tokenize(anchorCore));
  const nq = normalizeText(query);
  const qTokens = tokenize(query);

  const scored: RankedCandidate[] = [];

  for (const c of allComics) {
    if (c.id === anchor.id) continue;
    if (excludeIds?.has(c.id)) continue;

    const cNorm = normalizeText(c.name);
    const cFolder = normalizeText(c.folder);
    const cAuthor = normalizeText(c.author);

    if (nq) {
      const hay = `${cNorm} ${cAuthor} ${cFolder}`;
      const matched = hay.includes(nq) || (qTokens.length > 0 && qTokens.every((t) => hay.includes(t)));
      if (!matched) continue;
    }

    const cCore = normalizeText(stripPartTokens(c.name));
    let score = 0;

    // 1. Exact core-title match (e.g., "Silent Atlas Vol. 01" vs "Silent Atlas Vol. 02")
    if (anchorCore.length >= 2 && cCore === anchorCore) {
      score += 1000;
    } else if (anchorCore.length >= 3 && (cCore.startsWith(anchorCore) || anchorCore.startsWith(cCore))) {
      score += 520;
    }

    // 2. Shared prefix ratio
    let prefix = 0;
    const minLen = Math.min(anchorNorm.length, cNorm.length);
    while (prefix < minLen && anchorNorm[prefix] === cNorm[prefix]) prefix++;
    if (prefix >= 3) score += Math.min(260, prefix * 18);

    // 3. Token overlap (Jaccard on core title tokens)
    const cTokens = tokenize(cCore);
    if (anchorTokens.size > 0 && cTokens.length > 0) {
      let overlap = 0;
      for (const t of cTokens) if (anchorTokens.has(t)) overlap++;
      if (overlap > 0) {
        const union = new Set([...anchorTokens, ...cTokens]).size;
        score += Math.round((overlap / union) * 420);
      }
    }

    // 4. Character similarity fallback
    score += Math.round(similarity(anchorCore, cCore) * 200);

    // 5. Same folder / same author bonus
    if (anchor.folder && c.folder === anchor.folder) score += 110;
    else if (anchor.author && c.author === anchor.author) score += 55;

    // 6. Query match boost when searching
    if (nq) {
      if (cNorm === nq) score += 300;
      else if (cNorm.startsWith(nq)) score += 180;
      else if (cNorm.includes(nq)) score += 90;
    }

    scored.push({
      comic: c,
      score,
      isStrongMatch: score >= 480,
    });
  }

  scored.sort((a, b) => {
    // Keep strong matches grouped together in clean natural part order if scores are close
    if (a.isStrongMatch && b.isStrongMatch && Math.abs(a.score - b.score) < 90) {
      return naturalCompare(a.comic.name, b.comic.name);
    }
    return b.score - a.score || naturalCompare(a.comic.name, b.comic.name);
  });

  return scored;
}

function makeSeriesId(): string {
  return `s_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 7)}`;
}

/**
 * Connect `targetComic` into `anchorComic`'s series at exact 1-based `partNumber` (1..N+1).
 * If `anchorComic` is not yet in a series, creates a new series starting with `anchorComic`.
 * Ensures a comic belongs to at most one series cleanly.
 */
export function setComicPartPosition(
  seriesList: readonly ComicSeries[] | undefined,
  anchorComic: ComicRecord,
  targetComic: ComicRecord,
  partNumber: number,
): ComicSeries[] {
  const list = (seriesList ?? []).map((s) => ({ ...s, comicIds: [...s.comicIds] }));
  let current = list.find((s) => s.comicIds.includes(anchorComic.id));

  // Remove targetComic from any OTHER series so there are never duplicate/conflicting chains
  for (const s of list) {
    if (s !== current) {
      s.comicIds = s.comicIds.filter((id) => id !== targetComic.id);
    }
  }

  if (!current) {
    current = {
      id: makeSeriesId(),
      name: stripPartTokens(anchorComic.name),
      comicIds: [anchorComic.id],
    };
    list.push(current);
  }

  const withoutTarget = current.comicIds.filter((id) => id !== targetComic.id);
  const insertAt = Math.max(0, Math.min(withoutTarget.length, Math.round(partNumber) - 1));
  withoutTarget.splice(insertAt, 0, targetComic.id);
  current.comicIds = withoutTarget;

  return list.filter((s) => s.comicIds.length >= 2);
}

/** Reorder a part inside a series from `fromIndex` to `toIndex`. */
export function moveSeriesPart(
  seriesList: readonly ComicSeries[] | undefined,
  seriesId: string,
  fromIndex: number,
  toIndex: number,
): ComicSeries[] {
  const list = (seriesList ?? []).map((s) => ({ ...s, comicIds: [...s.comicIds] }));
  const s = list.find((x) => x.id === seriesId);
  if (!s) return list;
  if (fromIndex < 0 || fromIndex >= s.comicIds.length) return list;
  const clampedTo = Math.max(0, Math.min(s.comicIds.length - 1, toIndex));
  const [item] = s.comicIds.splice(fromIndex, 1);
  s.comicIds.splice(clampedTo, 0, item);
  return list;
}

/** Remove one comic from a series; automatically cleans up the series if fewer than 2 parts remain. */
export function removeSeriesPart(
  seriesList: readonly ComicSeries[] | undefined,
  seriesId: string,
  comicId: string,
): ComicSeries[] {
  return (seriesList ?? [])
    .map((s) => (s.id === seriesId ? { ...s, comicIds: s.comicIds.filter((id) => id !== comicId) } : s))
    .filter((s) => s.comicIds.length >= 2);
}

/** Rename a series cleanly. */
export function renameSeries(
  seriesList: readonly ComicSeries[] | undefined,
  seriesId: string,
  name: string,
): ComicSeries[] {
  const trimmed = name.trim();
  if (!trimmed) return [...(seriesList ?? [])];
  return (seriesList ?? []).map((s) => (s.id === seriesId ? { ...s, name: trimmed } : s));
}

/** Disconnect all parts in a series. */
export function dissolveSeries(
  seriesList: readonly ComicSeries[] | undefined,
  seriesId: string,
): ComicSeries[] {
  return (seriesList ?? []).filter((s) => s.id !== seriesId);
}
