import { useEffect, useMemo, useState } from "react";
import { ArrowDown, ArrowUp, BookOpen, Eye, Link2, Plus, Search, Sparkles, Trash2, Unlink, X } from "lucide-react";
import type { ComicRecord, PageInfo } from "@comiclib/shared";
import { api } from "@/lib/backend";
import { useStore } from "@/lib/store";
import {
  dissolveSeries,
  findSeriesForComic,
  moveSeriesPart,
  rankCandidatesByName,
  removeSeriesPart,
  renameSeries,
  setComicPartPosition,
  stripPartTokens,
} from "@/lib/series";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge, Input } from "@/components/ui/controls";
import { PageImage } from "@/features/reader/PageImage";
import { Thumb } from "./ComicCard";
import { cn } from "@/utils/cn";

interface Props {
  anchorComic: ComicRecord;
  onClose: () => void;
  onJumpToPart?: (comic: ComicRecord) => void;
  zIndex?: number;
}

const PAGE_BATCH = 50;

export function ConnectPartsModal({ anchorComic, onClose, onJumpToPart, zIndex = 80 }: Props) {
  const comics = useStore((s) => s.comics);
  const settings = useStore((s) => s.settings);
  const setSettings = useStore((s) => s.setSettings);
  const toast = useStore((s) => s.toast);

  const [query, setQuery] = useState("");
  const [limit, setLimit] = useState(PAGE_BATCH);
  const [previewComic, setPreviewComic] = useState<ComicRecord | null>(null);
  const [previewPages, setPreviewPages] = useState<PageInfo[] | null>(null);
  const [seriesNameDraft, setSeriesNameDraft] = useState<string>("");

  const resolved = useMemo(
    () => findSeriesForComic(settings.series, anchorComic.id, comics),
    [settings.series, anchorComic.id, comics],
  );

  // Sync editable series title when resolved series changes
  useEffect(() => {
    setSeriesNameDraft(resolved?.series.name ?? stripPartTokens(anchorComic.name));
  }, [resolved?.series.id, resolved?.series.name, anchorComic.name]);

  // Connected parts list: if not yet connected, show anchorComic as Part 1 ready to connect more
  const connectedParts: ComicRecord[] = useMemo(
    () => (resolved ? resolved.parts : [anchorComic]),
    [resolved, anchorComic],
  );
  const connectedSet = useMemo(() => new Set(connectedParts.map((c) => c.id)), [connectedParts]);

  // Rank remaining comics with most-matching names at the top
  const ranked = useMemo(
    () => rankCandidatesByName(anchorComic, comics, query, connectedSet),
    [anchorComic, comics, query, connectedSet],
  );

  useEffect(() => {
    setLimit(PAGE_BATCH);
  }, [query]);

  // Load sample preview pages when user taps a comic to inspect its photo preview & full name
  useEffect(() => {
    if (!previewComic) {
      setPreviewPages(null);
      return;
    }
    let live = true;
    setPreviewPages(null);
    void api
      .pages(previewComic.id)
      .then((list) => {
        if (live) setPreviewPages(Array.isArray(list) ? list.slice(0, 8) : []);
      })
      .catch(() => {
        if (live) setPreviewPages([]);
      });
    return () => {
      live = false;
    };
  }, [previewComic]);

  const nextPartNumber = connectedParts.length + 1;

  const handleAssignPart = (target: ComicRecord, partNumber: number) => {
    const nextSeries = setComicPartPosition(settings.series, anchorComic, target, partNumber);
    setSettings({ series: nextSeries });
    toast(`Set "${target.name}" as Part ${partNumber}`);
  };

  const handleMovePart = (fromIdx: number, toIdx: number) => {
    if (!resolved) return;
    setSettings({ series: moveSeriesPart(settings.series, resolved.series.id, fromIdx, toIdx) });
  };

  const handleRemovePart = (comicId: string) => {
    if (!resolved) return;
    setSettings({ series: removeSeriesPart(settings.series, resolved.series.id, comicId) });
    toast("Removed part from series");
  };

  const handleRenameSeries = () => {
    if (!resolved) return;
    const trimmed = seriesNameDraft.trim();
    if (!trimmed || trimmed === resolved.series.name) return;
    setSettings({ series: renameSeries(settings.series, resolved.series.id, trimmed) });
    toast("Updated series name");
  };

  const handleDissolve = () => {
    if (!resolved) return;
    setSettings({ series: dissolveSeries(settings.series, resolved.series.id) });
    toast("Disconnected all parts");
  };

  const visibleCandidates = ranked.slice(0, limit);
  const partChoices = Array.from({ length: Math.min(20, nextPartNumber) }, (_, i) => i + 1);

  return (
    <Dialog open onOpenChange={(o) => !o && onClose()}>
      <DialogContent
        title="Connect Comic Parts"
        description="Link related comics into Part 1, 2, 3, 4… Tap any comic to view its full name and page photo preview."
        size="lg"
        zIndex={zIndex}
        className="sm:h-[min(800px,90dvh)]"
      >
        <div className="relative flex min-h-0 flex-1 flex-col overflow-hidden">
          <div className="min-h-0 flex-1 overflow-y-auto overscroll-contain p-4">
            {/* Section 1: Connected Series Parts */}
            <section className="mb-5 rounded-[20px] border-2 border-ink bg-muted/60 p-3.5">
              <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
                <div className="flex min-w-0 flex-1 items-center gap-2">
                  <Link2 className="size-4 shrink-0 text-accent" />
                  {resolved ? (
                    <Input
                      value={seriesNameDraft}
                      onChange={(e) => setSeriesNameDraft(e.target.value)}
                      onBlur={handleRenameSeries}
                      onKeyDown={(e) => {
                        if (e.key === "Enter") {
                          (e.target as HTMLInputElement).blur();
                        }
                      }}
                      aria-label="Series name"
                      className="h-8 max-w-xs text-sm font-bold"
                    />
                  ) : (
                    <span className="truncate text-sm font-bold">Series order (add a comic below to connect)</span>
                  )}
                </div>
                <div className="flex items-center gap-1.5">
                  <Badge tone={resolved ? "ok" : undefined}>
                    {connectedParts.length} {connectedParts.length === 1 ? "part" : "parts"}
                  </Badge>
                  {resolved && (
                    <Button type="button" size="sm" variant="ghost" onClick={handleDissolve} title="Disconnect all parts">
                      <Unlink />Unlink all
                    </Button>
                  )}
                </div>
              </div>

              <ol className="flex flex-col gap-2">
                {connectedParts.map((c, idx) => {
                  const isAnchor = c.id === anchorComic.id;
                  return (
                    <li
                      key={c.id}
                      className={cn(
                        "flex items-center gap-2.5 rounded-[16px] border-2 border-ink bg-surface p-2 transition-colors",
                        isAnchor && "ring-2 ring-accent/50",
                      )}
                    >
                      <button
                        type="button"
                        onClick={() => setPreviewComic(c)}
                        className="w-11 shrink-0 transition-transform active:scale-95"
                        aria-label={`Preview ${c.name}`}
                      >
                        <Thumb comic={c} size="s" className="rounded-[10px] border-[2px] shadow-none" />
                      </button>

                      <button
                        type="button"
                        onClick={() => setPreviewComic(c)}
                        className="min-w-0 flex-1 text-left"
                      >
                        <div className="mb-0.5 flex flex-wrap items-center gap-1.5">
                          <span className={cn("inline-flex items-center rounded-full border-2 border-ink px-2 py-0.5 text-[11px] font-extrabold tabular-nums", isAnchor ? "bg-butter text-on" : "bg-lilac text-on")}>
                            Part {idx + 1}
                          </span>
                          {isAnchor && <span className="text-[11px] font-bold text-accent">Opened</span>}
                          <span className="text-[11px] tabular-nums text-sub">{c.pages}p</span>
                        </div>
                        <div className="break-words text-[13px] font-bold leading-snug text-fg">{c.name}</div>
                      </button>

                      <div className="flex shrink-0 flex-wrap items-center justify-end gap-1">
                        {resolved && (
                          <>
                            <select
                              aria-label={`Part number for ${c.name}`}
                              value={idx + 1}
                              onChange={(e) => handleMovePart(idx, Number(e.target.value) - 1)}
                              className="h-8 rounded-full border-2 border-ink bg-muted px-2 text-xs font-bold text-fg"
                            >
                              {connectedParts.map((_, n) => (
                                <option key={n + 1} value={n + 1}>
                                  Pt {n + 1}
                                </option>
                              ))}
                            </select>
                            <Button
                              type="button"
                              size="icon"
                              variant="ghost"
                              disabled={idx === 0}
                              aria-label="Move part up"
                              onClick={() => handleMovePart(idx, idx - 1)}
                              className="size-8"
                            >
                              <ArrowUp className="size-3.5" />
                            </Button>
                            <Button
                              type="button"
                              size="icon"
                              variant="ghost"
                              disabled={idx === connectedParts.length - 1}
                              aria-label="Move part down"
                              onClick={() => handleMovePart(idx, idx + 1)}
                              className="size-8"
                            >
                              <ArrowDown className="size-3.5" />
                            </Button>
                          </>
                        )}
                        {onJumpToPart && !isAnchor && (
                          <Button
                            type="button"
                            size="sm"
                            variant="outline"
                            onClick={() => {
                              onClose();
                              onJumpToPart(c);
                            }}
                            title={`Open Part ${idx + 1}`}
                          >
                            <BookOpen />Open
                          </Button>
                        )}
                        {resolved && (
                          <Button
                            type="button"
                            size="icon"
                            variant="ghost"
                            aria-label={`Remove ${c.name} from series`}
                            onClick={() => handleRemovePart(c.id)}
                            className="size-8 text-sub hover:text-bad"
                          >
                            <Trash2 className="size-3.5" />
                          </Button>
                        )}
                      </div>
                    </li>
                  );
                })}
              </ol>
            </section>

            {/* Section 2: Search & Connect Other Comics (Best Name Matches at Top) */}
            <section className="flex flex-col gap-3">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="flex items-center gap-1.5 text-sm font-bold">
                  <Sparkles className="size-4 text-accent" />
                  <span>Add comics to this series</span>
                </div>
                <span className="text-xs text-sub">Closest matching names appear first</span>
              </div>

              <div className="relative">
                <Search className="pointer-events-none absolute left-3.5 top-1/2 size-4 -translate-y-1/2 text-sub" />
                <Input
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  placeholder="Search comics by name, author, or folder"
                  aria-label="Search comics to connect"
                  className="pl-10 pr-10"
                />
                {query && (
                  <button
                    type="button"
                    aria-label="Clear search"
                    onClick={() => setQuery("")}
                    className="absolute right-1.5 top-1/2 flex size-8 -translate-y-1/2 items-center justify-center rounded-full text-sub hover:bg-muted hover:text-fg"
                  >
                    <X className="size-4" />
                  </button>
                )}
              </div>

              {visibleCandidates.length === 0 ? (
                <div className="rounded-[18px] border-2 border-dashed border-line p-6 text-center text-[13px] text-sub">
                  {query ? `No other comics match "${query}".` : "All comics in your library are already connected here."}
                </div>
              ) : (
                <ul className="flex flex-col gap-2">
                  {visibleCandidates.map(({ comic: c, isStrongMatch }) => (
                    <li
                      key={c.id}
                      className={cn(
                        "flex items-center gap-2.5 rounded-[16px] border-2 p-2 transition-colors",
                        isStrongMatch ? "border-ink bg-mint/15" : "border-line bg-surface hover:border-ink/60",
                      )}
                    >
                      <button
                        type="button"
                        onClick={() => setPreviewComic(c)}
                        className="w-12 shrink-0 transition-transform active:scale-95"
                        aria-label={`Preview ${c.name}`}
                      >
                        <Thumb comic={c} size="s" className="rounded-[10px] border-[2px] shadow-none" />
                      </button>

                      <button
                        type="button"
                        onClick={() => setPreviewComic(c)}
                        className="min-w-0 flex-1 text-left"
                      >
                        <div className="flex flex-wrap items-center gap-1.5">
                          {isStrongMatch && (
                            <span className="inline-flex items-center rounded-full border border-ink bg-mint px-2 py-0.5 text-[10px] font-extrabold text-on">
                              Best match
                            </span>
                          )}
                          <span className="text-[11px] tabular-nums text-sub">
                            {c.pages} pages{c.author ? ` · ${c.author}` : ""}
                          </span>
                        </div>
                        <div className="mt-0.5 break-words text-[13px] font-bold leading-snug text-fg">
                          {c.name}
                        </div>
                        {c.folder && <div className="truncate text-[11px] text-sub">{c.folder}</div>}
                      </button>

                      <div className="flex shrink-0 items-center gap-1.5">
                        <Button
                          type="button"
                          size="icon"
                          variant="ghost"
                          aria-label={`Preview photos of ${c.name}`}
                          title="View full name & photo preview"
                          onClick={() => setPreviewComic(c)}
                          className="size-8"
                        >
                          <Eye className="size-4" />
                        </Button>
                        <select
                          aria-label={`Pick part number for ${c.name}`}
                          value=""
                          onChange={(e) => {
                            const val = Number(e.target.value);
                            if (val >= 1) handleAssignPart(c, val);
                          }}
                          className="h-8 rounded-full border-2 border-ink bg-surface px-2 text-xs font-bold text-fg"
                        >
                          <option value="" disabled>
                            Part…
                          </option>
                          {partChoices.map((n) => (
                            <option key={n} value={n}>
                              Part {n}
                            </option>
                          ))}
                        </select>
                        <Button
                          type="button"
                          size="sm"
                          onClick={() => handleAssignPart(c, nextPartNumber)}
                          title={`Add as Part ${nextPartNumber}`}
                        >
                          <Plus />Pt {nextPartNumber}
                        </Button>
                      </div>
                    </li>
                  ))}
                </ul>
              )}

              {ranked.length > limit && (
                <div className="flex justify-center pt-1">
                  <Button type="button" variant="outline" size="sm" onClick={() => setLimit((l) => l + PAGE_BATCH)}>
                    Show more ({ranked.length - limit} remaining)
                  </Button>
                </div>
              )}
            </section>
          </div>

          {/* Inline Photo & Full-Name Preview Sheet when tapping any comic */}
          {previewComic && (
            <div
              className="absolute inset-0 z-20 flex flex-col bg-surface"
              role="region"
              aria-label={`Preview of ${previewComic.name}`}
            >
              <div className="flex items-start justify-between gap-3 border-b-2 border-ink bg-muted/60 p-4">
                <div className="min-w-0 flex-1">
                  <div className="text-[11px] font-bold uppercase tracking-wide text-accent">Comic Preview</div>
                  <h3 className="mt-0.5 break-words font-display text-base font-extrabold leading-snug text-fg">
                    {previewComic.name}
                  </h3>
                  <div className="mt-1 flex flex-wrap items-center gap-2 text-xs text-sub">
                    <span>{previewComic.pages} pages</span>
                    {previewComic.author && <span>· Author: {previewComic.author}</span>}
                    {previewComic.folder && <span>· {previewComic.folder}</span>}
                  </div>
                </div>
                <Button type="button" size="icon" variant="outline" aria-label="Close preview" onClick={() => setPreviewComic(null)}>
                  <X />
                </Button>
              </div>

              <div className="min-h-0 flex-1 overflow-y-auto p-4">
                <div className="mb-4 flex flex-wrap items-center gap-2 rounded-[16px] border-2 border-ink bg-muted p-3">
                  <span className="text-xs font-bold text-sub">Assign as:</span>
                  {Array.from({ length: Math.min(8, nextPartNumber) }, (_, i) => i + 1).map((num) => {
                    const currentIdx = connectedParts.findIndex((x) => x.id === previewComic.id);
                    const isCurrentPart = currentIdx === num - 1;
                    return (
                      <Button
                        key={num}
                        type="button"
                        size="sm"
                        variant={isCurrentPart ? "default" : "outline"}
                        onClick={() => {
                          handleAssignPart(previewComic, num);
                          setPreviewComic(null);
                        }}
                      >
                        Part {num}
                      </Button>
                    );
                  })}
                  {nextPartNumber > 8 && (
                    <Button
                      type="button"
                      size="sm"
                      onClick={() => {
                        handleAssignPart(previewComic, nextPartNumber);
                        setPreviewComic(null);
                      }}
                    >
                      + Part {nextPartNumber}
                    </Button>
                  )}
                </div>

                {previewPages === null ? (
                  <div className="grid grid-cols-2 gap-2.5 sm:grid-cols-4">
                    {Array.from({ length: 4 }, (_, i) => (
                      <div key={i} className="skeleton aspect-[2/3] rounded-md" />
                    ))}
                  </div>
                ) : previewPages.length === 0 ? (
                  <div className="mx-auto max-w-[200px]">
                    <Thumb comic={previewComic} size="m" />
                  </div>
                ) : (
                  <div className="grid grid-cols-2 gap-2.5 sm:grid-cols-4">
                    {previewPages.map((p, i) => (
                      <div key={p.name} className="relative aspect-[2/3] overflow-hidden rounded-[12px] border-2 border-ink bg-muted">
                        <PageImage url={p.url} fallbackUrl={p.fallbackUrl} className="size-full object-cover" lazy={i > 3} />
                        <span className="absolute bottom-1 right-1 rounded-sm bg-black/70 px-1.5 text-[11px] font-bold tabular-nums text-white">
                          {i + 1}
                        </span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
