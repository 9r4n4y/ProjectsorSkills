import { useCallback, useLayoutEffect, useMemo, useRef, useState } from "react";
import type { ComicRecord } from "@comiclib/shared";
import { buildSeriesBadgeMap } from "@/lib/series";
import { useStore } from "@/lib/store";
import { ComicCard } from "./ComicCard";
import { columnsFor } from "./gridColumns";

/** One page of comics in a plain, perfectly aligned grid. The page scrolls as a whole, so nothing is pinned. */
export function ComicGrid({ items }: { items: ComicRecord[] }) {
  const ref = useRef<HTMLDivElement>(null);
  const [width, setWidth] = useState(0);
  const density = useStore((s) => s.settings.density);
  const series = useStore((s) => s.settings.series);
  const allComics = useStore((s) => s.comics);
  const seriesBadges = useMemo(() => buildSeriesBadgeMap(series, allComics), [series, allComics]);
  const selectMode = useStore((s) => s.selectMode);
  const selected = useStore((s) => s.selected);
  const highlightId = useStore((s) => s.highlightId);
  const { openQuick, toggleSelect, setSelectMode, setSelected } = useStore.getState();

  useLayoutEffect(() => {
    const el = ref.current!;
    const ro = new ResizeObserver(() => setWidth(el.clientWidth));
    ro.observe(el);
    setWidth(el.clientWidth);
    return () => ro.disconnect();
  }, []);

  const gap = width < 640 ? 12 : 16;
  const cols = Math.max(1, columnsFor(width, gap, density));

  const onOpen = useCallback((c: ComicRecord) => openQuick(c.id), [openQuick]);
  const onSelect = useCallback((c: ComicRecord) => toggleSelect(c.id), [toggleSelect]);
  const onLong = useCallback(
    (c: ComicRecord) => {
      setSelectMode(true);
      setSelected([c.id]);
      navigator.vibrate?.(10);
    },
    [setSelectMode, setSelected],
  );

  return (
    <div ref={ref} className="grid w-full items-start" style={{ gap, gridTemplateColumns: `repeat(${cols}, minmax(0, 1fr))` }} role="list" aria-label="Comics">
      {width > 0 &&
        items.map((c) => (
          <div role="listitem" key={c.id} style={{ minWidth: 0 }}>
            <ComicCard comic={c} selectMode={selectMode} selected={selected.has(c.id)} highlight={highlightId === c.id} partLabel={seriesBadges.get(c.id) ? `Pt ${seriesBadges.get(c.id)!.partNumber}/${seriesBadges.get(c.id)!.totalParts}` : undefined} onOpen={onOpen} onSelect={onSelect} onLongPress={onLong} />
          </div>
        ))}
    </div>
  );
}

export function GridSkeleton() {
  return (
    <div className="grid gap-4 p-6" style={{ gridTemplateColumns: "repeat(auto-fill, minmax(148px, 1fr))" }} aria-busy="true" aria-label="Loading comics">
      {Array.from({ length: 18 }, (_, i) => (
        <div key={i} className="flex flex-col gap-2">
          <div className="skeleton aspect-[2/3] rounded-md" />
          <div className="skeleton h-9 rounded-sm" />
        </div>
      ))}
    </div>
  );
}
