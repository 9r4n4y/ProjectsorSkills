import { useCallback, useEffect, useMemo, useState } from "react";
import { BookOpen, Download, FolderInput, FolderOpen, Heart, LayoutGrid, Link2, Loader2, RefreshCw, Tag } from "lucide-react";
import { type PageInfo, formatBytes } from "@comiclib/shared";
import { api } from "@/lib/backend";
import { findSeriesForComic } from "@/lib/series";
import { useStore } from "@/lib/store";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge, TriIcon } from "@/components/ui/controls";
import { PageImage } from "@/features/reader/PageImage";
import { cn } from "@/utils/cn";
import { MoveDialog, TagEditor } from "./Dialogs";
import { ConnectPartsModal } from "./ConnectPartsModal";

const PREVIEW_COLS_KEY = "folio_preview_grid_cols";
const PREVIEW_COL_OPTIONS = [2, 3, 4, 5, 6] as const;

function readInitialPreviewCols(): number {
  try {
    const raw = localStorage.getItem(PREVIEW_COLS_KEY);
    const n = raw ? Number(raw) : NaN;
    if (PREVIEW_COL_OPTIONS.includes(n as (typeof PREVIEW_COL_OPTIONS)[number])) return n;
  } catch {
    // ignore storage errors
  }
  return typeof window !== "undefined" && window.innerWidth >= 640 ? 4 : 3;
}

/** In-place modal over the grid: no navigation, so scroll position, filters and selection are untouched. */
export function QuickLook() {
  const id = useStore((s) => s.quickId);
  const comics = useStore((s) => s.comics);
  const comic = comics.find((c) => c.id === id);
  const series = useStore((s) => s.settings.series);
  const openQuick = useStore((s) => s.openQuick);
  const close = useStore((s) => s.closeQuick);
  const openReader = useStore((s) => s.openReader);
  const toggleFavorite = useStore((s) => s.toggleFavorite);
  const toast = useStore((s) => s.toast);
  const openInfo = useStore((s) => s.info);
  const [pages, setPages] = useState<PageInfo[] | null>(null);
  const [loadErr, setLoadErr] = useState<string | null>(null);
  const [exporting, setExporting] = useState(false);
  const [previewCols, setPreviewCols] = useState<number>(readInitialPreviewCols);
  const [tags, setTags] = useState(false);
  const [move, setMove] = useState(false);
  const [partsOpen, setPartsOpen] = useState(false);
  const seriesInfo = useMemo(() => (id ? findSeriesForComic(series, id, comics) : null), [series, id, comics]);
  const open = !!id && !!comic;

  const updatePreviewCols = (cols: number) => {
    setPreviewCols(cols);
    try {
      localStorage.setItem(PREVIEW_COLS_KEY, String(cols));
    } catch {
      // ignore storage errors
    }
  };

  const loadPages = useCallback((comicId: string) => {
    setPages(null);
    setLoadErr(null);
    let live = true;
    void api
      .pages(comicId)
      .then((p) => {
        if (!live) return;
        setPages(Array.isArray(p) ? p : []);
      })
      .catch((e) => {
        if (!live) return;
        setLoadErr((e as Error)?.message || "Could not load comic pages.");
        setPages([]);
      });
    return () => {
      live = false;
    };
  }, []);

  useEffect(() => {
    if (!id) {
      setPages(null);
      setLoadErr(null);
      return;
    }
    return loadPages(id);
  }, [id, loadPages]);

  if (!comic) return null;
  const read = () => {
    const rid = comic.id;
    close();
    setTimeout(() => openReader(rid), 0);
  };
  const handleExportComic = async () => {
    setExporting(true);
    try {
      const res = await api.exportComic(comic.id);
      if (res.cancelled) return;
      if (res.ok) toast(`Exported comic (${res.pages ?? comic.pages} pages)`);
      else toast("Could not export comic", "error");
    } catch (e) {
      toast((e as Error)?.message || "Could not export comic", "error");
    } finally {
      setExporting(false);
    }
  };
  const resume = comic.lastPage > 0 && comic.lastPage < comic.pages - 1;
  return (
    <>
      <Dialog open={open} onOpenChange={(o) => !o && close()}>
        <DialogContent title={comic.name} size="lg" onCloseAutoFocus={(e) => e.preventDefault()} className="sm:h-[min(760px,88dvh)]">
          <div className="flex min-h-0 flex-1 flex-col overflow-y-auto sm:flex-row sm:overflow-hidden">
            <aside className="flex shrink-0 flex-col gap-4 border-b border-line p-5 sm:w-72 sm:overflow-y-auto sm:border-b-0 sm:border-r">
              <dl className="grid grid-cols-[84px_1fr] gap-x-3 gap-y-2 text-[13px]">
                <dt className="text-sub">Name</dt><dd className="break-words" title={comic.name}>{comic.name}</dd>
                <dt className="text-sub">Folder</dt><dd className="break-words">{comic.folder || "Mother folder"}</dd>
                {comic.author && <><dt className="text-sub">Author</dt><dd>{comic.author}</dd></>}
                <dt className="text-sub">Pages</dt><dd className="tabular-nums">{comic.pages}</dd>
                <dt className="text-sub">Size</dt><dd className="tabular-nums">{formatBytes(comic.size)}</dd>
                <dt className="text-sub">Progress</dt><dd>{comic.read ? "Read" : comic.lastPage > 0 ? `Page ${comic.lastPage + 1} of ${comic.pages}` : "Not started"}</dd>
                {comic.verification && <><dt className="text-sub">Verified</dt><dd className="flex items-center gap-1.5"><TriIcon tri={comic.verification} />{comic.verification === "green" ? "All checks passed" : comic.verification === "amber" ? "Warnings" : "Failed"}</dd></>}
              </dl>
              <div>
                <div className="mb-2 text-[13px] text-sub">Tags</div>
                <div className="flex flex-wrap gap-1.5">
                  {comic.tags.length ? comic.tags.map((t) => <Badge key={t}>{t}</Badge>) : <span className="text-[13px] text-sub">No tags</span>}
                </div>
              </div>
              {seriesInfo && (
                <div className="rounded-[16px] border-2 border-ink bg-muted/70 p-2.5">
                  <div className="mb-1.5 flex items-center justify-between gap-2 text-xs font-bold">
                    <span className="truncate text-fg" title={seriesInfo.series.name}>{seriesInfo.series.name}</span>
                    <Badge tone="accent">Pt {seriesInfo.partIndex + 1}/{seriesInfo.totalParts}</Badge>
                  </div>
                  <div className="flex flex-wrap gap-1">
                    {seriesInfo.parts.map((p, idx) => (
                      <button
                        key={p.id}
                        type="button"
                        onClick={() => p.id !== comic.id && openQuick(p.id)}
                        title={p.name}
                        className={cn(
                          "h-7 rounded-full border-2 border-ink px-2.5 text-[11px] font-extrabold tabular-nums transition-colors",
                          p.id === comic.id ? "bg-butter text-on" : "bg-surface text-fg hover:bg-lilac hover:text-on",
                        )}
                      >
                        Pt {idx + 1}
                      </button>
                    ))}
                  </div>
                </div>
              )}
              <div className="flex flex-col gap-2">
                <Button size="lg" onClick={read}><BookOpen />{resume ? `Resume at page ${comic.lastPage + 1}` : "Read"}</Button>
                <Button variant="secondary" onClick={() => setPartsOpen(true)}>
                  <Link2 />{seriesInfo ? `Connected parts (${seriesInfo.partIndex + 1}/${seriesInfo.totalParts})` : "Connect parts"}
                </Button>
                <div className="grid grid-cols-4 gap-2">
                  <Button variant={comic.favorite ? "default" : "outline"} aria-pressed={comic.favorite} aria-label="Toggle favorite" title="Favorite" onClick={() => toggleFavorite([comic.id])}><Heart className={comic.favorite ? "fill-current" : ""} /></Button>
                  <Button variant="outline" aria-label="Edit tags" title="Edit tags" onClick={() => setTags(true)}><Tag /></Button>
                  <Button variant="outline" aria-label="Move comic" title="Move comic" onClick={() => setMove(true)}><FolderInput /></Button>
                  <Button variant="outline" aria-label="Export comic" title="Export comic (.cbz)" disabled={exporting} onClick={() => void handleExportComic()}>
                    {exporting ? <Loader2 className="animate-spin" /> : <Download />}
                  </Button>
                </div>
                {openInfo?.platform === "electron" && <Button variant="ghost" onClick={() => void api.openFolder({ comicId: comic.id })}><FolderOpen />Open folder</Button>}
              </div>
            </aside>
            <section className="flex min-h-[320px] flex-1 flex-col p-4 sm:overflow-y-auto" aria-label="Pages">
              <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
                <span className="flex items-center gap-1.5 text-xs font-bold text-sub">
                  <LayoutGrid className="size-3.5" />
                  Per row
                </span>
                <div role="radiogroup" aria-label="Preview images per row" className="inline-flex items-center gap-1 rounded-full border-2 border-ink bg-muted p-0.5">
                  {PREVIEW_COL_OPTIONS.map((cols) => (
                    <button
                      key={cols}
                      type="button"
                      role="radio"
                      aria-checked={previewCols === cols}
                      aria-label={`${cols} per row`}
                      onClick={() => updatePreviewCols(cols)}
                      className={cn(
                        "flex h-7 min-w-7 items-center justify-center rounded-full px-2 text-xs font-bold tabular-nums transition-[background-color,transform] duration-150 active:scale-90 touch-manipulation",
                        previewCols === cols ? "border-2 border-ink bg-butter text-on shadow-[0_2px_0_var(--ink)]" : "border-2 border-transparent text-sub hover:text-fg",
                      )}
                    >
                      {cols}
                    </button>
                  ))}
                </div>
              </div>
              {loadErr ? (
                <div className="flex h-full min-h-[220px] flex-col items-center justify-center gap-3 text-center">
                  <p className="max-w-xs text-sm text-bad">{loadErr}</p>
                  <Button variant="outline" size="sm" onClick={() => loadPages(comic.id)}><RefreshCw />Retry</Button>
                </div>
              ) : (
                <div className="grid gap-2.5" style={{ gridTemplateColumns: `repeat(${previewCols}, minmax(0, 1fr))` }}>
                  {pages === null
                    ? Array.from({ length: 12 }, (_, i) => <div key={i} className="skeleton aspect-[2/3] rounded-md" />)
                    : pages.map((p, i) => (
                        <button key={p.name} title={p.name} onClick={() => { const rid = comic.id; close(); setTimeout(() => openReader(rid, i), 0); }} className="group relative aspect-[2/3] overflow-hidden rounded-md border border-line bg-muted transition-transform duration-150 active:scale-95">
                          <PageImage url={p.url} fallbackUrl={p.fallbackUrl} className="size-full object-cover" lazy />
                          <span className="absolute bottom-1 right-1 rounded-sm bg-black/60 px-1.5 text-[11px] tabular-nums text-white">{i + 1}</span>
                        </button>
                      ))}
                </div>
              )}
            </section>
          </div>
        </DialogContent>
      </Dialog>
      {tags && <TagEditor ids={[comic.id]} onClose={() => setTags(false)} />}
      {move && <MoveDialog ids={[comic.id]} onClose={() => setMove(false)} />}
      {partsOpen && (
        <ConnectPartsModal
          anchorComic={comic}
          onClose={() => setPartsOpen(false)}
          onJumpToPart={(target) => {
            close();
            setTimeout(() => openReader(target.id, 0), 0);
          }}
        />
      )}
    </>
  );
}
