import { memo, useEffect, useRef, useState } from "react";
import { Check, Heart } from "lucide-react";
import type { ComicRecord } from "@comiclib/shared";
import { api } from "@/lib/backend";
import { useStore } from "@/lib/store";
import { cn } from "@/utils/cn";

const bust = (src: string, n: number) => (n && !src.startsWith("data:") ? `${src}${src.includes("?") ? "&" : "?"}r=${n}` : src);

export function Thumb({ comic, size = "m", className }: { comic: Pick<ComicRecord, "id" | "thumbRev">; size?: "s" | "m"; className?: string }) {
  const [state, setState] = useState<"loading" | "ok" | "err">("loading");
  const [attempt, setAttempt] = useState(0);
  const tick = useStore((s) => s.thumbTick);
  useEffect(() => {
    if (state === "err") {
      setState("loading");
      setAttempt((a) => a + 1);
    }
    // a new batch of thumbnails finished: retry the ones that failed
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tick]);
  const src = bust(api.thumbUrl(comic, size), attempt);
  return (
    <div className={cn("relative aspect-[2/3] w-full overflow-hidden rounded-[16px] border-[2.5px] border-ink bg-muted shadow-[0_3px_0_var(--ink)]", className)}>
      {state !== "ok" && <div className={cn("absolute inset-0", state === "loading" && "skeleton")} />}
      {state !== "err" && (
        <img
          key={attempt}
          src={src}
          alt=""
          loading="lazy"
          decoding="async"
          draggable={false}
          onLoad={() => setState("ok")}
          onError={() => {
            if (attempt < 2) void api.ensureThumb(comic.id).then(() => setAttempt((a) => a + 1));
            else setState("err");
          }}
          className={cn("size-full object-cover transition-opacity duration-200", state === "ok" ? "opacity-100" : "opacity-0")}
        />
      )}
    </div>
  );
}

export const TITLE_H = 36;

interface Props {
  comic: ComicRecord;
  selectMode: boolean;
  selected: boolean;
  highlight: boolean;
  partLabel?: string;
  onOpen: (c: ComicRecord) => void;
  onSelect: (c: ComicRecord) => void;
  onLongPress: (c: ComicRecord) => void;
}

export const ComicCard = memo(function ComicCard({ comic: c, selectMode, selected, highlight, partLabel, onOpen, onSelect, onLongPress }: Props) {
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const fired = useRef(false);
  const clear = () => {
    if (timer.current) clearTimeout(timer.current);
    timer.current = null;
  };
  const progress = c.lastPage > 0 && c.pages > 0 ? Math.min(1, (c.lastPage + 1) / c.pages) : 0;
  return (
    <button
      data-comic-id={c.id}
      title={c.name}
      aria-label={`${c.name}, ${c.pages} pages${c.favorite ? ", favorite" : ""}`}
      aria-pressed={selectMode ? selected : undefined}
      onPointerDown={(e) => {
        if (e.pointerType === "mouse") return;
        fired.current = false;
        timer.current = setTimeout(() => {
          fired.current = true;
          onLongPress(c);
        }, 450);
      }}
      onPointerUp={clear}
      onPointerLeave={clear}
      onPointerCancel={clear}
      onContextMenu={(e) => e.preventDefault()}
      onClick={() => {
        if (fired.current) {
          fired.current = false;
          return;
        }
        selectMode ? onSelect(c) : onOpen(c);
      }}
      className={cn("group flex w-full flex-col gap-2 touch-manipulation rounded-[18px] text-left outline-offset-2", highlight && "card-highlight")}
    >
      <div className="pointer-events-none flex w-full flex-col gap-2 transition-transform duration-500 ease-spring group-active:scale-[0.96] group-active:duration-100">
      <div className="relative">
        <Thumb comic={c} />
        {c.favorite && (
          <span className="absolute right-2 top-2 flex size-7 items-center justify-center rounded-full border-2 border-ink bg-peach text-on">
            <Heart className="size-3.5 fill-current" />
          </span>
        )}
        {selectMode && (
          <span className={cn("absolute left-2 top-2 flex size-7 items-center justify-center rounded-full border-2 border-ink", selected ? "bg-mint text-on" : "bg-surface/80")}>
            {selected && <Check className="size-3.5" />}
          </span>
        )}
        {partLabel && (
          <span className="absolute bottom-2 left-2 rounded-full border-2 border-ink bg-butter px-2 py-0.5 text-[10px] font-extrabold leading-tight text-on shadow-[0_2px_0_var(--ink)]">
            {partLabel}
          </span>
        )}
        {selected && <span className="pointer-events-none absolute inset-0 rounded-[14px] ring-4 ring-inset ring-lilac" />}
        {progress > 0 && !c.read && (
          <span className="absolute inset-x-0 bottom-0 h-2 border-t-2 border-ink bg-black/40">
            <span className="stamp-fill block h-full" style={{ width: `${progress * 100}%` }} />
          </span>
        )}
        <span className="pointer-events-none absolute inset-0 rounded-[14px] bg-black/0 transition-colors duration-150 group-hover:bg-black/10" />
      </div>
      <span className="clamp-2 block px-0.5 text-[13px] font-bold leading-[18px] text-fg" style={{ height: TITLE_H }}>
        {c.name}
      </span>
      </div>
    </button>
  );
});
