# Folio v6.1

## Highlights
- **See All Tags & Authors Everywhere with Progressive "View more":**
  - Upgraded the universal `TagEditor` (used in Quick Look, Bulk Select bar, Folder/Tag/Author bulk tagging, Edge Panel, and Tags screen) so BOTH **Tags** and **Authors** now display **all** existing tags/authors sorted by usage count instead of capping at 12.
  - Added compact Android-friendly **`View more (+16)`**, **`Show all`**, and **`Show less`** controls for both current tags/authors and available tags/authors—tapping **View more** reveals more on demand without cluttering small screens.
  - Added the same progressive **`View more (+30)` / `Show all`** pagination to the Search **Tags | Authors** filter panel and the **Tags & Authors** management screen.
- **Zero-Overlap UI Audit & Pill Refinements:**
  - Replaced fixed-height `h-8` tag/author pills with auto-expanding `min-h-9 h-auto max-w-full py-1.5` wrapping pills (`break-words` + `shrink-0` icons) so long tag/author names never clip or overlap adjacent rows.
  - Refactored `Tags.tsx` and `FilterPanels.tsx` rows with clean `flex-wrap`, `gap-y-2`, and uniform `size-9` icon buttons so action buttons never squeeze or overlap text on narrow Android screens.
