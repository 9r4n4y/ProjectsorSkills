import { useMemo, useState } from "react";
import { Check, CheckSquare, ChevronDown, GitMerge, Pencil, Plus, Search, Tag as TagIcon, Trash2, User, X } from "lucide-react";
import { authorTagName, authorTagsOf, countAuthors, countTags, isAuthorTag, normalTagsOf, normalizeText, tagKey, toAuthorTag } from "@comiclib/shared";
import { useStore } from "@/lib/store";
import { Button } from "@/components/ui/button";
import { EmptyState, Input, Segmented } from "@/components/ui/controls";
import { Card, PageShell } from "@/components/PageShell";
import { TagEditor } from "@/features/library/Dialogs";

export function Tags() {
  const comics = useStore((s) => s.comics);
  const defs = useStore((s) => s.tags);
  const renameTag = useStore((s) => s.renameTag);
  const deleteTag = useStore((s) => s.deleteTag);
  const clearFilters = useStore((s) => s.clearFilters);
  const setFilters = useStore((s) => s.setFilters);
  const setScreen = useStore((s) => s.setScreen);
  const setSelectMode = useStore((s) => s.setSelectMode);
  const setSelected = useStore((s) => s.setSelected);
  const toast = useStore((s) => s.toast);
  const TAGS_BATCH = 30;
  const [tab, setTab] = useState<"tags" | "authors">("tags");
  const [q, setQ] = useState("");
  const [limit, setLimit] = useState(TAGS_BATCH);
  const [edit, setEdit] = useState<{ name: string; mode: "rename" | "merge" | "delete" } | null>(null);
  const [value, setValue] = useState("");
  const [bulk, setBulk] = useState<{ name: string; ids: string[] } | null>(null);

  const list = useMemo(() => {
    const counts = tab === "authors" ? countAuthors(comics) : countTags(comics);
    const all = new Map<string, { name: string; count: number }>();
    for (const d of defs) {
      if (tab === "authors") {
        if (!isAuthorTag(d.name)) continue;
        const clean = authorTagName(d.name);
        if (clean) all.set(tagKey(clean), { name: clean, count: counts.get(tagKey(clean))?.count ?? 0 });
      } else {
        if (isAuthorTag(d.name)) continue;
        all.set(tagKey(d.name), { name: d.name, count: counts.get(tagKey(d.name))?.count ?? 0 });
      }
    }
    for (const [k, v] of counts) all.set(k, v);
    const nq = normalizeText(q);
    return [...all.values()].filter((t) => !nq || normalizeText(t.name).includes(nq)).sort((a, b) => b.count - a.count || a.name.localeCompare(b.name));
  }, [comics, defs, q, tab]);

  const idsForItem = (name: string) =>
    tab === "authors"
      ? comics.filter((c) => authorTagsOf(c.tags).some((a) => tagKey(a) === tagKey(name))).map((c) => c.id)
      : comics.filter((c) => normalTagsOf(c.tags).some((t) => tagKey(t) === tagKey(name))).map((c) => c.id);

  const show = (name: string) => {
    clearFilters();
    setFilters(tab === "authors" ? { authorsIn: [name] } : { tagsIn: [name] });
    setScreen("library");
  };

  const selectAllWithTag = (name: string) => {
    const ids = idsForItem(name);
    clearFilters();
    setFilters(tab === "authors" ? { authorsIn: [name] } : { tagsIn: [name] });
    setSelectMode(true);
    setSelected(ids);
    setScreen("library");
  };

  const commit = () => {
    if (!edit) return;
    const rawFrom = tab === "authors" ? toAuthorTag(edit.name) : edit.name;
    if (edit.mode === "delete") {
      deleteTag(rawFrom);
      toast(`Deleted ${tab === "authors" ? "author" : "tag"} "${edit.name}"`);
    } else if (value.trim()) {
      const rawTo = tab === "authors" ? toAuthorTag(value.trim()) : value.trim();
      renameTag(rawFrom, rawTo);
      toast(edit.mode === "merge" ? `Merged "${edit.name}" into "${value.trim()}"` : `Renamed to "${value.trim()}"`);
    }
    setEdit(null);
    setValue("");
  };

  const RowIcon = tab === "authors" ? User : TagIcon;

  return (
    <PageShell title={tab === "authors" ? "Authors" : "Tags"} description={`${list.length} ${tab} across ${comics.length.toLocaleString()} comics`}>
      <div className="flex flex-wrap items-center gap-3">
        <Segmented
          label="Tags or Authors"
          value={tab}
          onChange={(v) => {
            setTab(v);
            setEdit(null);
            setQ("");
            setLimit(TAGS_BATCH);
          }}
          options={[
            { value: "tags", label: "Tags" },
            { value: "authors", label: "Authors" },
          ]}
        />
        <div className="relative min-w-[200px] max-w-md flex-1">
          <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-sub" />
          <Input value={q} onChange={(e) => { setQ(e.target.value); setLimit(TAGS_BATCH); }} placeholder={tab === "authors" ? "Search authors" : "Search tags"} aria-label={tab === "authors" ? "Search authors" : "Search tags"} className="pl-9" />
        </div>
      </div>
      {list.length === 0 ? (
        <EmptyState
          icon={RowIcon}
          title={tab === "authors" ? "No author tags yet" : "No tags yet"}
          text={tab === "authors" ? "Open any comic (or select comics) and tap Tags → Authors to assign an author." : "Open any comic and choose the tag button to add one. Select several comics to tag them together."}
        />
      ) : (
        <Card>
          <ul className="-mx-4 -my-4 divide-y divide-line">
            {list.slice(0, limit).map((t) => (
              <li key={t.name} className="flex flex-col gap-2 px-4 py-3">
                <div className="flex flex-wrap items-center justify-between gap-x-2 gap-y-2">
                  <button onClick={() => show(t.name)} className="flex min-w-[140px] flex-1 items-center gap-2.5 text-left" title={`Show comics with this ${tab === "authors" ? "author" : "tag"}`}>
                    <RowIcon className="size-4 shrink-0 text-sub" />
                    <span className="min-w-0 flex-1 break-words text-sm font-bold leading-snug">{t.name}</span>
                    <span className="shrink-0 text-[13px] tabular-nums text-sub">{t.count}</span>
                  </button>
                  <div className="flex shrink-0 flex-wrap items-center gap-1">
                    {t.count > 0 && (
                      <>
                        <button type="button" aria-label={`Add tags to all comics with ${t.name}`} title={`Add or edit tags on all ${t.count} comics`} onClick={() => setBulk({ name: t.name, ids: idsForItem(t.name) })} className="flex size-9 items-center justify-center rounded-full border-2 border-transparent text-fg hover:border-ink/40 hover:bg-muted active:scale-90"><Plus className="size-4" /></button>
                        <button type="button" aria-label={`Select all comics with ${t.name}`} title={`Select all ${t.count} comics in library`} onClick={() => selectAllWithTag(t.name)} className="flex size-9 items-center justify-center rounded-full border-2 border-transparent text-fg hover:border-ink/40 hover:bg-muted active:scale-90"><CheckSquare className="size-4" /></button>
                      </>
                    )}
                    <button type="button" aria-label={`Rename ${t.name}`} onClick={() => { setEdit({ name: t.name, mode: "rename" }); setValue(t.name); }} className="flex size-9 items-center justify-center rounded-full border-2 border-transparent text-fg hover:border-ink/40 hover:bg-muted active:scale-90"><Pencil className="size-4" /></button>
                    <button type="button" aria-label={`Merge ${t.name}`} onClick={() => { setEdit({ name: t.name, mode: "merge" }); setValue(""); }} className="flex size-9 items-center justify-center rounded-full border-2 border-transparent text-fg hover:border-ink/40 hover:bg-muted active:scale-90"><GitMerge className="size-4" /></button>
                    <button type="button" aria-label={`Delete ${t.name}`} onClick={() => setEdit({ name: t.name, mode: "delete" })} className="flex size-9 items-center justify-center rounded-full border-2 border-transparent text-sub hover:border-ink/40 hover:bg-muted hover:text-bad active:scale-90"><Trash2 className="size-4" /></button>
                  </div>
                </div>
                {edit?.name === t.name && (
                  <form className="flex flex-wrap items-center gap-2 pb-1" onSubmit={(e) => { e.preventDefault(); commit(); }}>
                    {edit.mode === "delete" ? (
                      <span className="text-[13px]">Remove "{t.name}" from {t.count} comic{t.count === 1 ? "" : "s"}? The comics are not touched.</span>
                    ) : (
                      <>
                        <Input autoFocus list={edit.mode === "merge" ? "merge-targets" : undefined} value={value} onChange={(e) => setValue(e.target.value)} placeholder={edit.mode === "merge" ? "Merge into tag" : "New name"} aria-label={edit.mode === "merge" ? "Target tag" : "New tag name"} className="max-w-xs" />
                        {edit.mode === "merge" && <datalist id="merge-targets">{list.filter((x) => x.name !== t.name).map((x) => <option key={x.name} value={x.name} />)}</datalist>}
                      </>
                    )}
                    <Button type="submit" size="sm" variant={edit.mode === "delete" ? "danger" : "default"}><Check />{edit.mode === "delete" ? "Delete" : edit.mode === "merge" ? "Merge" : "Rename"}</Button>
                    <Button type="button" size="sm" variant="ghost" onClick={() => setEdit(null)}><X />Cancel</Button>
                  </form>
                )}
              </li>
            ))}
            {list.length > limit && (
              <li className="flex flex-wrap items-center justify-center gap-2 px-4 py-3">
                <button
                  type="button"
                  onClick={() => setLimit((n) => n + TAGS_BATCH)}
                  className="inline-flex h-9 items-center gap-1.5 rounded-full border-2 border-ink bg-butter px-4 text-xs font-extrabold text-on shadow-[0_2px_0_var(--ink)] active:translate-y-0.5 active:shadow-none"
                >
                  <ChevronDown className="size-3.5" />
                  View more (+{Math.min(TAGS_BATCH, list.length - limit)})
                </button>
                <button
                  type="button"
                  onClick={() => setLimit(list.length)}
                  className="inline-flex h-9 items-center rounded-full border-2 border-ink bg-surface px-3.5 text-xs font-bold text-fg active:scale-95"
                >
                  Show all ({list.length})
                </button>
              </li>
            )}
          </ul>
        </Card>
      )}
      {bulk && <TagEditor ids={bulk.ids} initialTab={tab} title={`Edit tags/authors for ${bulk.name} (${bulk.ids.length})`} onClose={() => setBulk(null)} />}
    </PageShell>
  );
}
