import { useMemo, useState } from "react";
import { CheckSquare, ChevronDown, Folder, Minus, Plus, Search, Tag, User } from "lucide-react";
import { authorTagName, authorTagsOf, countAuthors, countFolders, countTags, isAuthorTag, normalTagsOf, normalizeText, tagKey, toggleInEx } from "@comiclib/shared";
import { useStore } from "@/lib/store";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Input, Segmented } from "@/components/ui/controls";
import { Button } from "@/components/ui/button";
import { cn } from "@/utils/cn";
import { TagEditor } from "./Dialogs";

function IncExRow({
  label,
  sub,
  count,
  indent,
  inc,
  exc,
  onInc,
  onExc,
  onBulkTag,
  onSelectAll,
  icon: Icon,
}: {
  label: string;
  sub?: string;
  count: number;
  indent?: number;
  inc: boolean;
  exc: boolean;
  onInc: () => void;
  onExc: () => void;
  onBulkTag?: () => void;
  onSelectAll?: () => void;
  icon: React.ElementType;
}) {
  return (
    <li className="flex min-h-12 items-center gap-2 border-b border-line/60 px-3 py-2" style={{ paddingLeft: 12 + (indent ?? 0) * 16 }}>
      <button
        aria-label={`Include ${label}`}
        aria-pressed={inc}
        onClick={onInc}
        className={cn("flex size-9 shrink-0 items-center justify-center rounded-full border-2 transition-[background-color,transform] duration-300 ease-spring active:brightness-90 touch-manipulation pointer-coarse:size-10", inc ? "border-ink bg-mint text-on" : "border-line text-sub hover:bg-muted hover:text-fg")}
      >
        <Plus className="size-4" />
      </button>
      <button type="button" onClick={onInc} className="flex min-w-0 flex-1 items-center gap-2 text-left">
        <Icon className="size-4 shrink-0 text-sub" />
        <div className="min-w-0 flex-1">
          <div className={cn("truncate text-sm", exc && "text-sub line-through")} title={sub ?? label}>{label}</div>
          {sub && <div className="truncate text-xs text-sub">{sub}</div>}
        </div>
        <span className="shrink-0 text-xs tabular-nums text-sub">{count}</span>
      </button>
      {count > 0 && onBulkTag && (
        <button
          type="button"
          aria-label={`Add tags to all comics in ${label}`}
          title={`Add or remove tags for all ${count} comics`}
          onClick={onBulkTag}
          className="flex size-8 shrink-0 items-center justify-center rounded-full border-2 border-line text-sub hover:border-ink hover:bg-muted hover:text-fg active:scale-90"
        >
          <Tag className="size-3.5" />
        </button>
      )}
      {count > 0 && onSelectAll && (
        <button
          type="button"
          aria-label={`Select all comics in ${label}`}
          title={`Select all ${count} comics in library`}
          onClick={onSelectAll}
          className="flex size-8 shrink-0 items-center justify-center rounded-full border-2 border-line text-sub hover:border-ink hover:bg-muted hover:text-fg active:scale-90"
        >
          <CheckSquare className="size-3.5" />
        </button>
      )}
      <button
        aria-label={`Exclude ${label}`}
        aria-pressed={exc}
        onClick={onExc}
        className={cn("flex size-9 shrink-0 items-center justify-center rounded-full border-2 transition-[background-color,transform] duration-300 ease-spring active:brightness-90 touch-manipulation pointer-coarse:size-10", exc ? "border-ink bg-peach text-on" : "border-line text-sub hover:bg-muted hover:text-fg")}
      >
        <Minus className="size-4" />
      </button>
    </li>
  );
}

export function FilterPanels() {
  const panel = useStore((s) => s.panel);
  const set = useStore((s) => s.set);
  return (
    <Dialog open={panel !== null} onOpenChange={(o) => !o && set({ panel: null })}>
      {panel === "tags" && <TagPanel />}
      {panel === "folders" && <FolderPanel />}
    </Dialog>
  );
}

function TagPanel() {
  const comics = useStore((s) => s.comics);
  const defs = useStore((s) => s.tags);
  const f = useStore((s) => s.filters);
  const set = useStore((s) => s.set);
  const setFilters = useStore((s) => s.setFilters);
  const clearFilters = useStore((s) => s.clearFilters);
  const setSettings = useStore((s) => s.setSettings);
  const setSelectMode = useStore((s) => s.setSelectMode);
  const setSelected = useStore((s) => s.setSelected);
  const FILTER_BATCH = 30;
  const [tab, setTab] = useState<"tags" | "authors">("tags");
  const [q, setQ] = useState("");
  const [limit, setLimit] = useState(FILTER_BATCH);
  const [bulk, setBulk] = useState<{ title: string; ids: string[] } | null>(null);

  const tagList = useMemo(() => {
    const counts = countTags(comics);
    const all = new Map<string, { name: string; count: number }>();
    for (const d of defs) {
      if (isAuthorTag(d.name)) continue;
      all.set(tagKey(d.name), { name: d.name, count: counts.get(tagKey(d.name))?.count ?? 0 });
    }
    for (const [k, v] of counts) all.set(k, v);
    const nq = normalizeText(q);
    return [...all.values()].filter((t) => !nq || normalizeText(t.name).includes(nq)).sort((a, b) => b.count - a.count || a.name.localeCompare(b.name));
  }, [comics, defs, q]);

  const authorList = useMemo(() => {
    const counts = countAuthors(comics);
    const all = new Map<string, { name: string; count: number }>();
    for (const d of defs) {
      if (!isAuthorTag(d.name)) continue;
      const clean = authorTagName(d.name);
      if (clean) all.set(tagKey(clean), { name: clean, count: counts.get(tagKey(clean))?.count ?? 0 });
    }
    for (const [k, v] of counts) all.set(k, v);
    const nq = normalizeText(q);
    return [...all.values()].filter((a) => !nq || normalizeText(a.name).includes(nq)).sort((a, b) => b.count - a.count || a.name.localeCompare(b.name));
  }, [comics, defs, q]);

  const toggleTag = (name: string, kind: "in" | "ex") => {
    const r = toggleInEx(f.tagsIn, f.tagsEx, name, kind);
    setFilters({ tagsIn: r.inc, tagsEx: r.exc });
  };
  const toggleAuthor = (name: string, kind: "in" | "ex") => {
    const r = toggleInEx(f.authorsIn, f.authorsEx, name, kind);
    setFilters({ authorsIn: r.inc, authorsEx: r.exc });
  };
  const idsForTag = (name: string) => comics.filter((c) => normalTagsOf(c.tags).some((t) => tagKey(t) === tagKey(name))).map((c) => c.id);
  const idsForAuthor = (name: string) => comics.filter((c) => authorTagsOf(c.tags).some((a) => tagKey(a) === tagKey(name))).map((c) => c.id);

  const selectTagComics = (name: string) => {
    const ids = idsForTag(name);
    clearFilters();
    setFilters({ tagsIn: [name] });
    setSelectMode(true);
    setSelected(ids);
    set({ panel: null });
  };
  const selectAuthorComics = (name: string) => {
    const ids = idsForAuthor(name);
    clearFilters();
    setFilters({ authorsIn: [name] });
    setSelectMode(true);
    setSelected(ids);
    set({ panel: null });
  };

  const tagActiveCount = f.tagsIn.length + f.tagsEx.length;
  const authorActiveCount = f.authorsIn.length + f.authorsEx.length;

  return (
    <>
      <DialogContent
        title={tab === "tags" ? "Filter by tag" : "Filter by author"}
        description={
          tab === "tags"
            ? `${tagList.length} tags. Tap or press plus to include, minus to exclude.`
            : `${authorList.length} authors. Tap or press plus to select an author, minus to exclude.`
        }
        panel
      >
        <div className="flex flex-col gap-3 border-b border-line p-4">
          <div className="flex justify-center">
            <Segmented
              label="Filter category"
              value={tab}
              onChange={(v) => {
                setTab(v);
                setQ("");
                setLimit(FILTER_BATCH);
              }}
              options={[
                { value: "tags", label: tagActiveCount ? `Tags (${tagActiveCount})` : "Tags" },
                { value: "authors", label: authorActiveCount ? `Authors (${authorActiveCount})` : "Authors" },
              ]}
            />
          </div>
          <div className="relative">
            <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-sub" />
            <Input
              autoFocus
              value={q}
              onChange={(e) => { setQ(e.target.value); setLimit(FILTER_BATCH); }}
              placeholder={tab === "tags" ? "Search tags" : "Search authors"}
              className="pl-9"
              aria-label={tab === "tags" ? "Search tags" : "Search authors"}
            />
          </div>
          {tab === "tags" && (
            <div className="flex items-center justify-between gap-3">
              <span className="text-[13px] text-sub">Included tags match</span>
              <Segmented label="Tag combination" value={f.tagMode} onChange={(v) => (setFilters({ tagMode: v }), setSettings({ tagMode: v }))} options={[{ value: "and", label: "All (AND)" }, { value: "or", label: "Any (OR)" }]} />
            </div>
          )}
        </div>

        {tab === "tags" ? (
          <ul className="min-h-0 flex-1 overflow-y-auto">
            {tagList.slice(0, limit).map((t) => (
              <IncExRow
                key={t.name}
                icon={Tag}
                label={t.name}
                count={t.count}
                inc={f.tagsIn.some((x) => tagKey(x) === tagKey(t.name))}
                exc={f.tagsEx.some((x) => tagKey(x) === tagKey(t.name))}
                onInc={() => toggleTag(t.name, "in")}
                onExc={() => toggleTag(t.name, "ex")}
                onBulkTag={() => setBulk({ title: `Add/edit tags on #${t.name} (${t.count})`, ids: idsForTag(t.name) })}
                onSelectAll={() => selectTagComics(t.name)}
              />
            ))}
            {tagList.length > limit && (
              <li className="flex flex-wrap items-center justify-center gap-2 p-3">
                <button
                  type="button"
                  onClick={() => setLimit((n) => n + FILTER_BATCH)}
                  className="inline-flex h-9 items-center gap-1.5 rounded-full border-2 border-ink bg-butter px-4 text-xs font-extrabold text-on shadow-[0_2px_0_var(--ink)] active:translate-y-0.5 active:shadow-none"
                >
                  <ChevronDown className="size-3.5" />
                  View more (+{Math.min(FILTER_BATCH, tagList.length - limit)})
                </button>
                <button
                  type="button"
                  onClick={() => setLimit(tagList.length)}
                  className="inline-flex h-9 items-center rounded-full border-2 border-ink bg-surface px-3.5 text-xs font-bold text-fg active:scale-95"
                >
                  Show all ({tagList.length})
                </button>
              </li>
            )}
            {!tagList.length && <li className="p-6 text-center text-[13px] text-sub">No tag matches "{q}".</li>}
          </ul>
        ) : (
          <ul className="min-h-0 flex-1 overflow-y-auto">
            {authorList.slice(0, limit).map((a) => (
              <IncExRow
                key={a.name}
                icon={User}
                label={a.name}
                count={a.count}
                inc={f.authorsIn.some((x) => tagKey(x) === tagKey(a.name))}
                exc={f.authorsEx.some((x) => tagKey(x) === tagKey(a.name))}
                onInc={() => toggleAuthor(a.name, "in")}
                onExc={() => toggleAuthor(a.name, "ex")}
                onBulkTag={() => setBulk({ title: `Tag all comics by ${a.name} (${a.count})`, ids: idsForAuthor(a.name) })}
                onSelectAll={() => selectAuthorComics(a.name)}
              />
            ))}
            {authorList.length > limit && (
              <li className="flex flex-wrap items-center justify-center gap-2 p-3">
                <button
                  type="button"
                  onClick={() => setLimit((n) => n + FILTER_BATCH)}
                  className="inline-flex h-9 items-center gap-1.5 rounded-full border-2 border-ink bg-butter px-4 text-xs font-extrabold text-on shadow-[0_2px_0_var(--ink)] active:translate-y-0.5 active:shadow-none"
                >
                  <ChevronDown className="size-3.5" />
                  View more (+{Math.min(FILTER_BATCH, authorList.length - limit)})
                </button>
                <button
                  type="button"
                  onClick={() => setLimit(authorList.length)}
                  className="inline-flex h-9 items-center rounded-full border-2 border-ink bg-surface px-3.5 text-xs font-bold text-fg active:scale-95"
                >
                  Show all ({authorList.length})
                </button>
              </li>
            )}
            {!authorList.length && (
              <li className="p-6 text-center text-[13px] text-sub">
                {q ? `No author matches "${q}".` : "No author tags added yet. Open a comic (or select comics) and tap Tags → Authors to add one."}
              </li>
            )}
          </ul>
        )}

        <div className="flex items-center justify-between gap-2 border-t border-line p-3">
          {tab === "tags" ? (
            <Button variant="ghost" size="sm" onClick={() => setFilters({ tagsIn: [], tagsEx: [] })} disabled={!tagActiveCount}>
              Clear tags
            </Button>
          ) : (
            <Button variant="ghost" size="sm" onClick={() => setFilters({ authorsIn: [], authorsEx: [] })} disabled={!authorActiveCount}>
              Clear authors
            </Button>
          )}
          <Button variant="ghost" size="sm" onClick={clearFilters}>Clear all</Button>
        </div>
      </DialogContent>
      {bulk && <TagEditor ids={bulk.ids} title={bulk.title} onClose={() => setBulk(null)} />}
    </>
  );
}

function FolderPanel() {
  const comics = useStore((s) => s.comics);
  const folders = useStore((s) => s.folders);
  const f = useStore((s) => s.filters);
  const set = useStore((s) => s.set);
  const setFilters = useStore((s) => s.setFilters);
  const clearFilters = useStore((s) => s.clearFilters);
  const setSelectMode = useStore((s) => s.setSelectMode);
  const setSelected = useStore((s) => s.setSelected);
  const [q, setQ] = useState("");
  const [bulk, setBulk] = useState<{ title: string; ids: string[] } | null>(null);
  const counts = useMemo(() => countFolders(comics), [comics]);
  const list = useMemo(() => {
    const nq = normalizeText(q);
    return folders.filter((x) => !nq || normalizeText(x.path).includes(nq));
  }, [folders, q]);
  const toggle = (p: string, kind: "in" | "ex") => {
    const r = toggleInEx(f.foldersIn, f.foldersEx, p, kind);
    setFilters({ foldersIn: r.inc, foldersEx: r.exc });
  };
  const idsForFolder = (p: string) => comics.filter((c) => c.folder === p || c.folder.startsWith(`${p}/`)).map((c) => c.id);
  const selectFolderComics = (p: string) => {
    const ids = idsForFolder(p);
    clearFilters();
    setFilters({ foldersIn: [p] });
    setSelectMode(true);
    setSelected(ids);
    set({ panel: null });
  };
  return (
    <>
      <DialogContent title="Filter by folder" description="Plus includes, minus excludes, tag icon tags the whole folder, check icon selects all comics in it." panel>
        <div className="border-b border-line p-4">
          <div className="relative">
            <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-sub" />
            <Input autoFocus value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search folders" className="pl-9" aria-label="Search folders" />
          </div>
        </div>
        <ul className="min-h-0 flex-1 overflow-y-auto">
          {list.map((x) => {
            const count = counts.get(x.path) ?? 0;
            return (
              <IncExRow
                key={x.path}
                icon={Folder}
                label={x.name}
                sub={x.parent ? x.parent : x.kind === "author" ? "Author folder" : undefined}
                indent={q ? 0 : x.path.split("/").length - 1}
                count={count}
                inc={f.foldersIn.includes(x.path)}
                exc={f.foldersEx.includes(x.path)}
                onInc={() => toggle(x.path, "in")}
                onExc={() => toggle(x.path, "ex")}
                onBulkTag={() => setBulk({ title: `Tag folder: ${x.name} (${count})`, ids: idsForFolder(x.path) })}
                onSelectAll={() => selectFolderComics(x.path)}
              />
            );
          })}
          {!list.length && <li className="p-6 text-center text-[13px] text-sub">No folder matches "{q}".</li>}
        </ul>
        <div className="flex items-center justify-between gap-2 border-t border-line p-3">
          <Button variant="ghost" size="sm" onClick={() => setFilters({ foldersIn: [], foldersEx: [] })} disabled={!f.foldersIn.length && !f.foldersEx.length}>Clear folders</Button>
          <Button variant="ghost" size="sm" onClick={clearFilters}>Clear all</Button>
        </div>
      </DialogContent>
      {bulk && <TagEditor ids={bulk.ids} title={bulk.title} onClose={() => setBulk(null)} />}
    </>
  );
}
