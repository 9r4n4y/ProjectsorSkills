# SecondBrain — a universal personal notes system (v1.2)

## What changed in 1.2 — the UI was rebuilt from zero with shadcn/ui

The entire frontend was **deleted and rewritten** as a React single-page app
built 100% on **shadcn/ui** components (Radix primitives + Tailwind CSS).
None of the old vanilla-JS interface remains. Same engine, same files, same
API — a completely new interface:

- **Real shadcn/ui everywhere** — Button, Card, Dialog, AlertDialog,
  DropdownMenu, Select, Tabs, Checkbox, Switch, RadioGroup, Popover, Command
  (cmdk), Tooltip, Badge, Breadcrumb, Table, Collapsible, Sheet, Skeleton,
  Sonner toasts, lucide icons. Nothing hand-rolled.
- **Sidebar app shell** — Home / Files / Tags / Graph / Search / Health /
  Backup in a fixed sidebar (mobile: a slide-in sheet), a top bar with the
  one-step Back button, and Light / Dark / System theming.
- **Command palette** — press `Ctrl/⌘ + K` (or `/`) anywhere to jump to any
  note or page instantly.
- **Minimal, user-friendly pages** — every screen was redesigned around one
  clear job: a quiet home with stats and quick actions, a two-step guided
  search, a focused reading view with the Connected-branch map, and a clean
  icon toolbar editor with the smart Markdown tools, table editor and link
  dialog.
- **Honest empty states and skeletons** while data loads.
- The UI sources live in `website/app/` (TypeScript + Vite). Rebuild after
  changing them with `website/app/deploy.sh` (needs Node 18+); the compiled
  app ships prebuilt in `website/static/`.
- **Health-check fix that v1.1 promised:** the structure check could still
  die with `name 'add' is not defined` (the helper was missing inside two of
  its sub-checks, and the new UI folder triggered them). Both sub-checks now
  define the helper, the whitelist knows the new `website/app` and
  `static/assets` layout, and `python3 core/test_v11.py` re-verifies it
  (17/17 passing).

## What changed in 1.1

- **All tags are independent.** The sub-tag hierarchy is gone: no "deep tag
  counts for its parents" rule, no implied levels. A tag is one flat name.
- **Tags always stay in sync.** A tag used on any note (website or AI) is
  added to the Approved tags of `_tags.md` at the same moment.
- **Note verification was removed.** There is no verified/unverified status
  anywhere.
- **The health check can no longer crash** (`name 'add' is not defined` is
  fixed) — every check runs fault-isolated and fixable problems get a
  one-click repair button.
- **Smart Markdown toolbar.** Tools no longer select what they insert; the
  cursor always lands where you keep typing. Select a word and tap any tool
  to format it; tap again to undo the format. New table editor UI, link
  word → note or site, find-in-note that works in edit AND preview mode.
- **Tappable checklists** in the rendered note; the tick is saved to the
  file (or to your unsaved draft preview).
- **Connected notes** are one unified branch picture (outgoing + incoming,
  no backlink wording); click a branch to isolate it.
- **Back button** in the top bar (one step back, Alt+←).
- **https:// is automatic** — write `example.com`, the app writes the rest.
- **Backup is byte-identical**: after copying, EVERY file in scope is
  re-hashed on both sides; the live project is only ever read.
- **Logs** are written only by the user or the AI, always with a name;
  nothing is ever reversed automatically.
- **Total UI remake** — a shadcn/ui-style token design system with
  Aceternity-style gradients, a real brain logo (black SVG, no emoji), a
  fixed pushpin icon, a Files browser, and restructured search with a
  How-to-use guide.
- **Search explains itself**: every result carries a plain-language reason;
  the confusing "not applicable — weight shared" rows are gone.

## Quick explanation (read this first)

SecondBrain is a single-user notes system that keeps **all knowledge as plain
Markdown files in plain folders**. There is no database, no cloud and no
vendor lock-in — the files outlive any app. A **local website** reads those
files and presents them in a clean, searchable interface, an **AI librarian**
(MCP server) can search, read and file notes for you under strict safety
rules, and a **ranking search engine** finds notes by tags, keywords,
synonyms and links — no semantic model, no embeddings, fast enough to run
instantly on a personal collection.

Knowledge is organized in three ways at once: **folders** (each note has one
home, called its subject), **global tags** (many per note, independent flat
names, searchable across all folders and always in sync), and **wiki links**
(`[[File Name]]`, shown as one connected picture).

The project is one folder, `secondbrain/`, with 4 files and 7 folders at the
top level:

```
secondbrain/
├── README.md               this file
├── SKILL.md                the complete manual for the AI librarian
├── StructureOFnotes.md     the exact rulebook for how notes are written
├── _tags.md                the master tag vocabulary (approved, synonyms, proposed)
├── database/               every note lives here, as <Subject>/.../<Note Name>/
├── inbox/                  raw unsorted notes waiting to be filed
├── logs/                   one log file per change, never edited or deleted
├── core/                   the shared engine (parser, index, search, tags, checks)
├── mcp/                    the AI tool server (a thin layer over core)
├── website/                the local viewer and editor (a thin layer over core)
│   └── app/                UI 2.0 sources (React + shadcn/ui; rebuild with deploy.sh)
└── backup/                 the backup, sync and restore tool
```

**How to start**

1.  `python3 website/server.py` — opens `http://localhost:8765` in your
    browser. Everything is on this computer; nothing leaves it.
2.  Look at the example notes under `database/`. Each note is a folder
    holding `<Note Name>.md`, `tags.txt` and an `attachments/` folder.
3.  Drop messy thoughts into `inbox/` and let the AI librarian file them,
    or create notes directly on the website ("New note").
4.  Back up with `python3 backup/backup.py --to /path/to/backup --yes`
    (the backup folder must live **outside** the project).
5.  To connect an AI assistant, point its MCP client at
    `mcp/server.py` — see "The AI tools" below.

Everything else on this page is the deep explanation.

---

## Purpose

SecondBrain exists to keep a person's knowledge in a form that is:

- **Minimal effort** — a note is a text file in a folder; nothing else is
  required.
- **Universally extensible** — any new subject, tag or note type can be
  added without changing the system. New subject = new folder. New tag =
  one line in `_tags.md`.
- **Searchable, taggable and connected** — the ranking engine orders notes
  by how well they match, the tag system is global, and wiki links tie
  notes together with automatic backlinks.
- **Durable** — plain UTF-8 Markdown with LF line endings, readable in any
  editor, on any operating system, forever.
- **Auditable** — every change, by you or by the AI, writes one log file in
  `logs/` naming who made it. The AI can never overwrite your words and
  never invents facts. Nothing is reversed automatically: undo always asks
  and records who asked.
- **Recoverable** — the backup tool makes the chosen folder **byte-identical**
  to the project, keeps every replaced file in a dated `.versions/` folder,
  re-hashes EVERY file in scope before it calls a run successful, and never
  writes anything inside the live project.

## The folder structure and every fixed file

The structure is strict on purpose: the health check reports anything that
is not on the allowed list, and the tools refuse to create anything outside
it (spec 16). Anything new needs your approval and an update to the
structure files.

### Top level — 4 files, 7 folders

| Path | What it is |
| --- | --- |
| `README.md` | this file |
| `SKILL.md` | the complete AI manual (vocabulary, rules, tools, examples) |
| `StructureOFnotes.md` | the exact note format rulebook |
| `_tags.md` | master tag vocabulary: approved tags, per-tag synonyms, general synonyms, proposed tags |
| `database/` | every note, as subject folders to any depth |
| `inbox/` | raw notes waiting for the AI librarian (plain `.md`/`.txt`) |
| `logs/` | `YYYY-MM-DD_HH-MM-SS_<title>.md`, one per change, append-only history |
| `core/` | the shared engine, listed below, plus `settings.json` and `.cache/` |
| `mcp/` | the MCP tool server |
| `website/` | the local website |
| `backup/` | the backup tool |

### Inside `database/`

Subject folders nest to any depth (`Learning › Languages › Vocabulary`). A
subject folder may contain an optional `_subject.md` with four fields:

```
Purpose: coffee and tea
Template: Tasting Note
Sensitivity: private
Inherits: sensitivity
```

`Sensitivity: private` hides and locks the folder and excludes it from the
search index (inherited by sub-folders unless overridden). `Template` names
a note whose body is used when creating notes here.

Each note lives in its **own folder**, named exactly like the note:

```
database/Recipes/Quick Vegetable Pasta for Weeknights/
├── Quick Vegetable Pasta for Weeknights.md   the note itself
├── tags.txt                                  its tags, comma separated
└── attachments/                              images used by the note
```

File names are detailed and descriptive (they are the wiki links) and are
unique across the whole wiki, even ignoring capital letters.

### The fixed source files (each named here, as the structure requires)

**`core/` — the one engine shared by the website, the MCP server and the
backup tool:**

| File | Role |
| --- | --- |
| `__init__.py` | marks `core` as a Python package |
| `paths.py` | project layout, safe names, the allowed-structure check |
| `textutil.py` | normalization, tokenizer, stemmer, edit distance, typo buckets |
| `tags.py` | tag notation, `tags.txt`, the `_tags.md` master, the auto tag extractor |
| `parser.py` | the ONE note parser: quick info, sections, links, references, metadata |
| `store.py` | every write operation (create/edit/move, tags, connections, images, inbox filing) |
| `logger.py` | writes the log files and executes undo from them |
| `indexer.py` | the incremental index (only re-parses notes whose hash changed) |
| `search.py` | the ranking search pipeline (spec 3) |
| `healthcheck.py` | fault-isolated health checks + one-click fix actions |
| `images.py` | attachments: add, crop (optional Pillow), delete with backup history |
| `test_ranking.py` | the fixed test set of queries with expected top results |
| `test_v11.py` | the v1.1 verification suite (runs in a sandbox copy) |
| `settings.json` | ranking weights, page size, defaults — tunable |
| `.cache/` | generated index, safe to delete; rebuilt from the files at any time |

**`website/` — the local site:**

| File | Role |
| --- | --- |
| `server.py` | local HTTP server: the JSON API + static files (standard library only) |
| `static/index.html` | the single-page app shell |
| `static/style.css` | the four themes, layout, print stylesheet |
| `static/js/md.js` | the Markdown renderer (blocks carry their source lines) |
| `static/js/api.js` | fetch wrapper, icons, toasts, modals, tag chips, theme |
| `static/js/note.js` | note view + editor, image viewer, crop, anchors |
| `static/js/views.js` | home, search, tag browser, graph, health, tools, backup pages |
| `static/js/app.js` | router, top bar, keyboard shortcuts |
| `static/vendor/katex/` | bundled KaTeX (offline LaTeX math; no CDN is ever contacted) |

**`mcp/server.py`** — the MCP server: newline-delimited JSON-RPC 2.0 on
stdio; exposes the full tool set (below).

**`backup/backup.py`** — the backup, sync and restore tool (CLI and API).

## The tag notation (v1.1: all tags independent)

Tags are plain text a non-coder can edit:

- A note's `tags.txt` holds comma-separated entries:
  `COOKING-weeknight, FOOD-pasta-vegetarian, METHOD-stovetop-one_pot`
- **Every tag is one independent name.** Dashes and underscores are just
  characters; `FOOD-pasta-vegetarian` has no relationship to `FOOD-pasta`
  or `FOOD` — nothing is implied, nothing propagates. Search matches a tag
  exactly (capitals ignored).
- A space inside a tag name is written as an underscore
  (`HOME_REPAIR-wall_painting`); commas never appear inside a tag.
- **Always in sync:** a tag used on a note — added on the website, by the
  AI, or in a `tags.txt` by hand — appears in the Approved tags of
  `_tags.md` at once, and the Tags page lists every tag in use with its
  count. The global index and the per-file tags cannot drift apart.
- `_tags.md` is the master vocabulary. Under `## Approved tags` every tag
  is listed (grouped under `### MAJOR` headings for readability only, each
  line optionally `TAG: synonym, synonym`). The `## Synonyms` section maps
  general search words (`quick: fast, rapid, speedy`). `## Proposed tags`
  holds tags the AI wants to add; they become usable when you approve them
  (one click on the Tags page).

## Search: modes, scopes and ranking

The engine (spec 3) has **no semantic model**. It ranks *notes*, never text
chunks; tags and keywords are boosters, not filters. Three modes:

- **Ranking only** (default) — nothing is excluded; signals only order.
- **Strict keyword** — only notes containing *every* query word (any
  order; synonyms satisfy it; `"quoted words"` are an exact phrase).
- **Strict tag** — only notes carrying *all* selected tags.

You can also pick subjects (a hard boundary — the search never looks
outside, sub-folders included, with a *this folder only* toggle), pick tags
(only real tags can be chosen; every available tag shows up as you type),
choose the scope (file name / tags / headings / body / folder path), and
filter by date. A **How to use** button on the search page explains all of
it in plain language.

Every query is understood the same way on the website and from the AI:
lowercased, accents stripped, dashes/underscores as spaces, filler words
dropped but negations kept, words stemmed so endings match, one wrong
letter tolerated for words of five or more letters, words matching an
approved tag (or a tag synonym) becoming query tags. Query words expand
into concept groups (the word, its stem, its synonyms — your words count
fully, synonyms 0.7, and a note earns a group once through its best term).

Candidates come from tag hits, keyword hits, neighbors (notes sharing at
least two tags with a top-5 hit or connected to one) and a fallback that
keeps results from ever being blank. Every candidate is scored:

| Signal | Weight |
| --- | --- |
| Tags (exact match only — tags are independent; rarer tags count more) | 34% |
| Title and aliases (share of groups found) | 24% |
| Headings and quick-info labels (BM25) | 14% |
| Neighbors | 12% |
| Body (BM25, length-normalized) | 10% |
| Closeness (words near each other / same section) | 6% |

`final = 100 × weighted sum × coverage`, where coverage is
`0.4 + 0.6 × (share of query groups matched)` — matching every part of the
query beats matching one part many times. Signals that do not apply have
their weight shared among the rest; each signal is scaled against the best
candidate; an exact title or alias match ranks first; a neighbor-only note
never outranks a direct match; ties break by more groups matched, more
recently updated, then title A–Z — identical on every run. Results come 20
at a time (*Show 20 more* continues the same list), and every result
explains itself: a one-sentence reason plus *Why this ranking* with the
exact signal bars (only the signals that actually applied).

The weights live in `core/settings.json`. `python3 core/test_ranking.py`
runs the fixed query set and fails loudly if ranking regresses.

## The website (v1.1)

Run `python3 website/server.py` (options: `--port`, `--bind`,
`--no-browser`, `--rebuild`). It listens on this computer only; opening it
to the home network is an explicit setting (`server_bind` in
`core/settings.json`).

- **Top bar** — a real **Back button** (one step back, `Alt+←`), the brain
  logo (black SVG, no emoji), Home / Files / Tags / Graph / Health /
  Backup, New note, theme and text size.
- **Home** — gradient hero with search, saved searches, stat cards, pinned
  and recently updated notes.
- **Search** — structured in two numbered groups (*How should it match?*
  and *Narrow by tags & folders*), a **How to use** guide, scopes with
  plain labels, date range, *Show 20 more*, and per-result score badges
  with a reason sentence and the *Why this ranking* signal bars.
- **Note page** — breadcrumbs; the quick info card; the rendered note with
  **tappable checklist boxes** (the tick is saved to the file, or to your
  unsaved draft preview); then **Connected notes** — one unified branch
  map (SVG): the note in the middle, outgoing branches right, incoming
  left; click a branch to isolate it, *Show all branches* resets — then
  **Reference sources** (type `example.com`, https is added for you), a
  **Tags panel** (chips with × to remove; typing shows every existing tag
  with its note count), and the **Metadata** panel. Plus Copy note, Export
  metadata (now includes the exact file location, all tags on the note and
  every tag used in the wiki), Print/PDF, pin, and **Find in note**
  (`Ctrl+F`) which highlights every hit in the rendered note and jumps
  between them — in edit mode it selects and scrolls the editor instead.
- **Editing** — raw Markdown with a smart toolbar: tools never select what
  they insert, the cursor lands exactly where you continue (inside the
  `**` of bold, right after `## `), select a word and tap any tool to
  format it (tap again to undo). **Table** opens a real table editor (add
  and remove rows/columns, type in cells, update in place). **Link**
  connects the selected word to any note or website. Saving checks the
  file hash first and asks before overwriting; switching edit/preview
  never throws your place.
- **Images** — render exactly where their Markdown sits; many images
  arrange into a tidy grid; click for full screen with **crop** (saved as
  a new image, then replace-with-backup or keep both), **delete**
  (confirmation, warning, backup history) and **download**; resize each
  image in the viewer.
- **Tags page** — one flat list of independent tags with counts; per-tag
  actions (see the notes, rename, remove everywhere), add/rename/merge
  with a preview of every affected note, one-click approval for proposed
  and unapproved tags, and the `_tags.md` raw editor.
- **Files** — a real folder browser: click into any folder, see its notes
  and subfolders as cards, create a note or subfolder **right here**,
  rename/move/delete the folder, private folders marked.
- **Graph** — the connection graph of notes and links; click a node to
  open the note.
- **Health** — fault-isolated check cards (a broken check can never take
  the page down), each fixable finding with a **one-click repair** (remove
  broken links, merge duplicate tags, approve tags, fill dates, delete
  stray attachments) — and the log history with **Undo** buttons that
  always ask first.
- **Backup** — a three-step page: choose folder + scope + direction,
  preview, run & verify. Success means byte-identical: every file in scope
  re-hashed on both sides.

Four themes (Light, Dark, Coffee, Orange), remembered. Reading font and
text size adjustable. Keyboard: `/` opens search, `e` toggles edit on a
note, `Ctrl+S` saves in the editor, `Ctrl+F` finds in the note, `Alt+←`
goes back.

## The AI tools (MCP)

Point any MCP client at:

```json
{"command": "python3", "args": ["/absolute/path/to/secondbrain/mcp/server.py"]}
```

The AI gets 36 tools — everything the website can do, nothing hidden:
`search_notes`, `suggest_tags`, `list_tags`, `list_folders` /
`list_subjects`, `read_note`, `get_connections`, `file_note`,
`create_note`, `edit_note`, `append_my_notes`, `move_note`,
`rename_note`, `edit_tags`, `connect_notes`, `add_reference`,
`edit_quick_info`, `add_attachment`, `edit_links`, `edit_metadata`,
`export_metadata`, `crop_image`, `delete_image`, `rename_tag`,
`merge_tags`, `approve_tags`, `health_check`, `health_fix`, `toggle_task`,
`backup_preview`, `backup_run`, `backup_restore`, `backup_verify`,
`undo_change`, `saved_searches`, `get_structure`.

The librarian rules are enforced in the engine, not in prompts: paths
outside the structure are refused; every tag used is added to the master
list at once (independent tags, always in sync); every write logs itself
with a name; there is no verification status; *My notes* is append-only;
and the AI must ask before creating a new folder — the tools return
`needs_approval` until the request carries `approve_new_folder=true`,
which only happens after you agreed.

## Backup and restore

`python3 backup/backup.py --to <folder outside the project> [--direction
backup|restore] [--scope whole|database|inbox|logs|<relative path>]
[--yes] [--keep 10]` and `--verify` to check a copy.

1.  Manifests both sides: path, size, SHA-256 for every file.
2.  Sorts each file: unchanged, changed (even by one word), new, removed,
    moved (same hash, new path).
3.  Shows a preview with counts and waits for approval (unless `--yes`).
4.  Copies only changed and new files, moves renamed ones, and keeps every
    replaced or removed file in a dated `.versions/` folder.
5.  Re-hashes **EVERY file in scope** on both sides — the run reports
    success only when the copy is byte-identical, and it says so.
6.  Never touches the live project in the backup direction: the run
    report is filed inside the backup copy (`.backup-runs/`), so the root
    project is only ever read.

Every copy lands via a temporary file first, so an interrupted run leaves
nothing half-written. Retention prunes old `.versions/` folders. Every run
leaves a report in the backup copy's `.backup-runs/` folder, naming who
started it. The same preview and hash check serve both directions (update
the backup from the project, or restore the project from the backup).
Paths behave the same on Windows, macOS and Linux.

## Tests

`python3 core/test_v11.py` copies the whole project into a temporary
sandbox and verifies the v1.1 guarantees end to end — the health-crash
regression, independent tags and master sync, removal of verification,
ranking reasons, checklist toggles, auto-https, the complete export,
search modes, helpful create-note errors, log names, undo, byte-identical
backup with the root untouched, all 36 MCP tools over real stdio JSON-RPC,
the website over HTTP, and a clean structure check at the end.

## How to extend the project

- **New subject** — create a folder (website: Tools, or your file
  manager); optionally add `_subject.md`.
- **New tag** — one line under `## Approved tags` in `_tags.md` (or Add
  tag on the Tags page); then use it in any `tags.txt`.
- **New synonym** — one line in `## Synonyms`.
- **A structural change** (new folder or file type, renamed section, new
  tool, changed notation) — needs your approval, an update to the
  structure files (`README.md`, and `SKILL.md` /
  `StructureOFnotes.md` where affected), and its log entry lists those
  updates. Any file created by a build step must be named in this
  README.

## Performance and portability

Local only, no accounts, no tracking, nothing leaves the machine. UTF-8
with LF line endings; no file-name characters any system forbids; names
unique even ignoring capitals. The index is a cache — it updates only
notes whose hash changed and can always be rebuilt from the files
(`python3 website/server.py --rebuild`). Search targets well under 100 ms
on 10,000 notes; the grid uses thumbnails; long lists load as you scroll.
The smallest set of dependencies does the job: **none** are required
(Python standard library only); Pillow is optional, only for AI-side image
cropping; KaTeX is bundled for offline math rendering.
