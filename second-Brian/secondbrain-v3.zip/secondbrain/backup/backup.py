"""SecondBrain backup, sync and restore tool (v1.1).

Makes the selected backup folder IDENTICAL to the project - byte for byte:

1. Records every file's path, size and SHA-256 hash on both sides.
2. Sorts each file as unchanged, changed, new, removed or moved.
3. Shows a preview with counts and waits for approval.
4. Copies only changed and new files, moves renamed ones, and keeps every
   replaced or removed file in a dated .versions/ folder.
5. Re-hashes EVERY single file in scope afterwards - not only the files it
   wrote - and the run only reports success when every hash matches, so the
   copy is provably identical right down to the bytes.
6. The live project is only ever READ in the backup direction: the tool
   never writes, moves or deletes anything inside the project when updating
   a backup. (The explicit restore direction writes to the project; that is
   its job and it is confirmed separately.)

Usage:
  python3 backup/backup.py --to /path/to/backup --direction backup --scope whole
  python3 backup/backup.py --to /path/to/backup --direction restore --yes
  python3 backup/backup.py --to /path/to/backup --verify

Scopes: whole | database | inbox | logs | a relative folder or file path.
"""
from __future__ import annotations

import argparse
import datetime as _dt
import hashlib
import json
import shutil
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
EXCLUDE = {".cache", "__pycache__", ".tmp", ".tmp-write", ".backup-runs"}
VERSIONS = ".versions"


def sha256_of(p: Path) -> str:
    h = hashlib.sha256()
    with open(p, "rb") as fh:
        for chunk in iter(lambda: fh.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def manifest(base: Path, scope: str) -> dict[str, dict]:
    """{relative path: {size, sha256}} for every file under base+scope."""
    root = base if scope in ("whole", "", ".") else base / scope
    out: dict[str, dict] = {}
    if not root.exists():
        return out
    for p in sorted(root.rglob("*")):
        if not p.is_file() or p.is_symlink():
            continue
        if any(part in EXCLUDE or part == VERSIONS for part in p.parts):
            continue
        rel = p.relative_to(base).as_posix()
        st = p.stat()
        out[rel] = {"size": st.st_size, "sha256": sha256_of(p)}
    return out


def compare(live_m: dict, old_m: dict) -> dict[str, list[str]]:
    cmp = {"unchanged": [], "changed": [], "new": [], "removed": [], "moved": []}
    old_by_hash: dict[str, list[str]] = {}
    for path, meta in old_m.items():
        old_by_hash.setdefault(meta["sha256"], []).append(path)
    live_by_hash: dict[str, list[str]] = {}
    for path, meta in live_m.items():
        live_by_hash.setdefault(meta["sha256"], []).append(path)
    for path, meta in live_m.items():
        if path in old_m:
            if old_m[path]["sha256"] == meta["sha256"]:
                cmp["unchanged"].append(path)
            else:
                cmp["changed"].append(path)
        else:
            cmp["new"].append(path)
    for path in old_m:
        if path not in live_m:
            # removed here - unless the same content moved somewhere new
            h = old_m[path]["sha256"]
            moved = False
            if h in live_by_hash:
                for new_path in live_by_hash[h]:
                    if new_path not in old_m:
                        cmp["moved"].append(f"{path} -> {new_path}")
                        moved = True
                        break
            if not moved:
                cmp["removed"].append(path)
    return cmp


def preview(cmp: dict) -> str:
    lines = [
        f"  unchanged: {len(cmp['unchanged'])}",
        f"  changed:   {len(cmp['changed'])}",
        f"  new:       {len(cmp['new'])}",
        f"  removed:   {len(cmp['removed'])}",
        f"  moved:     {len(cmp['moved'])}",
    ]
    for k in ("changed", "new", "removed", "moved"):
        for p in cmp[k][:40]:
            lines.append(f"    [{k}] {p}")
        if len(cmp[k]) > 40:
            lines.append(f"    [{k}] ... and {len(cmp[k]) - 40} more")
    return "\n".join(lines)


def _atomic_copy(src: Path, dst: Path):
    dst.parent.mkdir(parents=True, exist_ok=True)
    tmp = dst.with_name(dst.name + ".tmp-backup")
    shutil.copy2(src, tmp)
    tmp.replace(dst)


def keep_old(dst: Path, backup_root: Path) -> str | None:
    """Move the file that is about to be replaced/removed into the dated
    .versions/ folder. Nothing is overwritten or deleted without first
    being kept (spec 7 Safety)."""
    if not dst.exists():
        return None
    stamp = _dt.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    rel = dst.relative_to(backup_root)
    keep_path = backup_root / VERSIONS / stamp / rel
    keep_path.parent.mkdir(parents=True, exist_ok=True)
    shutil.move(str(dst), str(keep_path))
    return str(keep_path.relative_to(backup_root))


def prune_versions(backup_root: Path, keep: int):
    versions = backup_root / VERSIONS
    if not versions.exists() or keep <= 0:
        return
    stamps = sorted((d for d in versions.iterdir() if d.is_dir()),
                    key=lambda d: d.name, reverse=True)
    for old in stamps[keep:]:
        shutil.rmtree(old, ignore_errors=True)


def run(direction: str, target: Path, scope: str, approve: bool,
        keep_versions: int, log_fn=print, who: str = "user") -> dict:
    """direction 'backup': project -> target. 'restore': target -> project.
    Returns a report dict; raises SystemExit on hash mismatch."""
    if direction == "backup":
        src_base, dst_base = ROOT, target
    else:
        src_base, dst_base = target, ROOT
    src_m = manifest(src_base, scope)
    dst_m = manifest(dst_base, scope)
    cmp = compare(src_m, dst_m)

    log_fn("Preview")
    log_fn(preview(cmp))
    todo = cmp["changed"] + cmp["new"]
    moves = [tuple(m.split(" -> ", 1)) for m in cmp["moved"]]
    if not todo and not moves and not cmp["removed"]:
        log_fn("Nothing to do - everything is already up to date.")
        return {"ok": True, "compared": len(src_m), "written": 0}

    if not approve:
        answer = input(f"\nApply these changes ({direction}, scope={scope})? [y/N] ")
        if answer.strip().lower() not in {"y", "yes"}:
            log_fn("Cancelled. Nothing was written.")
            return {"ok": False, "cancelled": True}

    written: list[str] = []
    kept: list[str] = []
    # Changed and new files: copy to a temporary file, then rename.
    for rel in todo:
        dst = dst_base / rel
        if dst.exists():
            kept.append(keep_old(dst, dst_base))
        _atomic_copy(src_base / rel, dst)
        written.append(rel)
    # Moved: rename on the destination side.
    for old_rel, new_rel in moves:
        dst_old, dst_new = dst_base / old_rel, dst_base / new_rel
        if dst_old.exists() and not dst_new.exists():
            dst_new.parent.mkdir(parents=True, exist_ok=True)
            shutil.move(str(dst_old), str(dst_new))
            written.append(f"{old_rel} -> {new_rel}")
    # Removed on the source side: keep in .versions/, then delete.
    for rel in cmp["removed"]:
        dst = dst_base / rel
        if dst.exists():
            kept.append(keep_old(dst, dst_base))
            dst.unlink()

    prune_versions(dst_base, keep_versions)

    # v1.1: re-hash EVERY single file in scope on both sides. The run is
    # only successful when the copy is byte-identical to the source - not
    # merely when the files it wrote match.
    after = compare(manifest(src_base, scope), manifest(dst_base, scope))
    mismatches = after["changed"] + after["new"] + after["removed"]

    report = {
        "ok": not mismatches,
        "direction": direction,
        "scope": scope,
        "compared": len(src_m),
        "unchanged": len(cmp["unchanged"]),
        "changed": len(cmp["changed"]),
        "new": len(cmp["new"]),
        "removed": len(cmp["removed"]),
        "moved": len(moves),
        "written": written,
        "kept_in_versions": [k for k in kept if k],
        "hash_mismatches": mismatches,
        "identical": not mismatches,
        "verified_files": len(src_m) - len(mismatches),
    }
    log_fn("\nResult")
    log_fn(f"  written: {len(written)} file(s), kept in .versions/: "
           f"{len(report['kept_in_versions'])}, unchanged: {report['unchanged']}")
    if mismatches:
        log_fn(f"  HASH MISMATCH for {len(mismatches)} file(s): the run FAILED:")
        for m in mismatches:
            log_fn(f"    {m}")
        raise SystemExit(1)
    log_fn(f"  Every one of the {report['verified_files']} files in scope verified "
           "byte-identical by SHA-256. Run successful.")
    # v1.1: the run report is filed INSIDE THE BACKUP COPY (in the excluded
    # .backup-runs/ folder), never inside the live project - a backup run
    # must not interfere with the root project in any way.
    _write_run_log(dst_base, report, direction, cmp, who)
    return report


def _write_run_log(dst_base: Path, report: dict, direction: str, cmp: dict,
                   who: str = "user") -> str:
    """Every run leaves a report next to the backup copy (in the excluded
    .backup-runs/ folder). Logs are written by the user or the AI who
    started the run - no anonymous automatic entries, and the live project
    is never written to."""
    runs = dst_base / ".backup-runs"
    runs.mkdir(exist_ok=True)
    stamp = _dt.datetime.now()
    name = stamp.strftime("%Y-%m-%d_%H-%M-%S") + "_Backup_" + direction + ".md"
    body = [
        f"# Backup {direction}",
        "",
        f"- **When:** {stamp.strftime('%Y-%m-%d %H:%M:%S')}",
        f"- **Who:** {who}",
        f"- **Title:** Backup {direction} (scope {report['scope']})",
        "",
        "## What was done",
        "",
        f"- Compared {report['compared']} files with the {'backup copy' if direction == 'backup' else 'backup source'}.",
        f"- Unchanged: {report['unchanged']}, changed: {report['changed']}, "
        f"new: {report['new']}, removed: {report['removed']}, moved: {report['moved']}.",
        f"- Written files: {len(report['written'])}.",
        f"- Kept in .versions/: {len(report['kept_in_versions'])}.",
        f"- Hash verification: "
        + ("all matched." if report["ok"] else "MISMATCH - run failed."),
        "",
        "## File list",
        "",
        "```",
        preview(cmp),
        "```",
        "",
    ]
    tmp = runs / (name + ".tmp")
    tmp.write_text("\n".join(body), encoding="utf-8", newline="\n")
    tmp.replace(runs / name)
    return name


def verify(target: Path, scope: str, log_fn=print) -> dict:
    """Verify that the backup copy is byte-identical to the live project:
    every single file in scope is hashed on both sides. Returns a report
    with the per-file mismatches instead of just a boolean."""
    live_m, old_m = manifest(ROOT, scope), manifest(target, scope)
    cmp = compare(live_m, old_m)
    bad = cmp["changed"] + cmp["new"] + cmp["removed"]
    report = {
        "ok": not bad,
        "scope": scope,
        "files_compared": len(live_m),
        "identical": len(live_m) - len(bad),
        "differences": bad,
        "detail": {k: cmp[k][:100] for k in ("changed", "new", "removed", "moved")},
    }
    if bad:
        log_fn(f"Not in sync: {len(bad)} file(s) differ or are missing:")
        for p in bad[:40]:
            log_fn(f"  {p}")
        return report
    log_fn(f"Backup verified byte-identical: {len(live_m)} files match by SHA-256.")
    return report


def main():
    ap = argparse.ArgumentParser(description="SecondBrain backup tool")
    ap.add_argument("--to", required=True, help="backup folder (outside the project)")
    ap.add_argument("--direction", choices=["backup", "restore"], default="backup")
    ap.add_argument("--scope", default="whole",
                    help="whole | database | inbox | logs | a relative path")
    ap.add_argument("--yes", action="store_true", help="apply without asking")
    ap.add_argument("--keep", type=int, default=10,
                    help="how many dated .versions/ folders to keep")
    ap.add_argument("--verify", action="store_true",
                    help="only verify, change nothing")
    args = ap.parse_args()

    target = Path(args.to).expanduser().resolve()
    if target.resolve() == ROOT or ROOT in target.parents or target in ROOT.parents:
        print("The backup copy must live OUTSIDE the project folder.", file=sys.stderr)
        raise SystemExit(2)
    if not target.exists():
        if args.verify:
            print(f"Backup folder {target} does not exist.", file=sys.stderr)
            raise SystemExit(2)
        target.mkdir(parents=True)
        print(f"Created backup folder {target}")

    if args.verify:
        rep = verify(target, args.scope)
        raise SystemExit(0 if rep["ok"] else 1)
    run(args.direction, target, args.scope, args.yes, args.keep,
        who="user")   # a CLI run is always a user action


if __name__ == "__main__":
    main()
