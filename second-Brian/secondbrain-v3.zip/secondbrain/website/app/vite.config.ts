import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import path from "path";

// The UI builds into app/dist and is then synced into website/static
// (see deploy.sh). In dev, unknown /api /static /files /thumb requests are
// proxied to the local Python server (python3 website/server.py --no-browser).
export default defineConfig({
  plugins: [react()],
  base: "/",
  resolve: {
    alias: { "@": path.resolve(__dirname, "./src") },
  },
  server: {
    port: 5173,
    proxy: {
      "/api": "http://127.0.0.1:8765",
      "/files": "http://127.0.0.1:8765",
      "/thumb": "http://127.0.0.1:8765",
      "/static": "http://127.0.0.1:8765",
    },
  },
  build: {
    outDir: "dist",
    chunkSizeWarningLimit: 1500,
  },
});
