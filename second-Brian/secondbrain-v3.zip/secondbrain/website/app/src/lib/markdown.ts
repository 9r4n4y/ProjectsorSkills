/* Markdown renderer — faithful port of the v1.1 renderer (website/static/js/md.js).
 * Same duties, same output classes:
 *  - every block carries data-sl / data-el (source lines) so edit <-> preview
 *    switching never moves the view;
 *  - task items are real checkboxes carrying the global task index (data-task);
 *  - bare domains (example.com) become links automatically;
 *  - consecutive images form a tidy grid; KaTeX renders math when loaded. */

import { esc } from "./utils";

export interface MdCtx {
  src: (p: string) => string;
  missing: (t: string) => boolean;
  math: (tex: string, display: boolean) => string;
}

/* ---------------- inline ---------------- */

export function inline(raw: string, ctx: MdCtx): string {
  let s = esc(raw);
  const codes: string[] = [];
  s = s.replace(/`([^`]+)`/g, (_, c) => {
    codes.push(c);
    return "\u0000C" + (codes.length - 1) + "\u0000";
  });
  // images ![alt|60%](src) and ![alt](src)
  s = s.replace(/!\[([^\]|]*)\|([^\]]*)\]\(([^)\s]+)\)/g, (_, alt, w, src) =>
    `<img class="md-img" src="${ctx.src(src)}" alt="${alt}" style="width:${esc(w)}" loading="lazy" data-path="${esc(src)}">`);
  s = s.replace(/!\[([^\]]*)\]\(([^)\s]+)\)/g, (_, alt, src) =>
    `<img class="md-img" src="${ctx.src(src)}" alt="${alt}" loading="lazy" data-path="${esc(src)}">`);
  // wiki links [[Target]] and [[Target|word]]
  s = s.replace(/\[\[([^\]|]+)\|([^\]]+)\]\]/g, (_, t, w) =>
    `<a class="wikilink${ctx.missing(t) ? " missing" : ""}" href="#/note/${encodeURIComponent(t.trim())}" data-target="${esc(t.trim())}">${w}</a>`);
  s = s.replace(/\[\[([^\]]+)\]\]/g, (_, t) =>
    `<a class="wikilink${ctx.missing(t) ? " missing" : ""}" href="#/note/${encodeURIComponent(t.trim())}" data-target="${esc(t.trim())}">${t}</a>`);
  // markdown web links
  s = s.replace(/\[([^\]]+)\]\((https?:[^)\s]+)\)/g, (_, w, u) =>
    `<a class="weblink" href="${u}" target="_blank" rel="noopener">${w}</a>`);
  // bare domains become links: example.com, www.x.org/path (https auto)
  s = s.replace(/(^|[\s(>])([a-zA-Z0-9][a-zA-Z0-9-]*(?:\.[a-zA-Z0-9-]+)+)(\/[^\s<>"')]*)?/g,
    (m, pre, host, path) => {
      if (/\.(png|jpe?g|gif|webp|svg|css|js|json|md|txt|pdf)$/i.test(host + (path || ""))) return m;
      const url = "https://" + host + (path || "");
      return pre + `<a class="weblink" href="${url}" target="_blank" rel="noopener">${host}${path || ""}</a>`;
    });
  // footnotes
  s = s.replace(/\[\^([a-zA-Z0-9_-]+)\]/g, (_, id) =>
    `<sup class="fnref" data-fn="${id}">[${id}]</sup>`);
  // bold + italic
  s = s.replace(/\*\*([^*]+)\*\*/g, "<strong>$1</strong>");
  s = s.replace(/(^|[^*])\*([^*\n]+)\*/g, "$1<em>$2</em>");
  s = s.replace(/(^|[^_])_([^_\n]+)_(?![a-zA-Z0-9_])/g, "$1<em>$2</em>");
  // inline math
  s = s.replace(/\$([^$\n]+)\$/g, (_, m) => ctx.math(m, false));
  s = s.replace(/\u0000C(\d+)\u0000/g, (_, i) => "<code>" + codes[+i] + "</code>");
  return s;
}

/* ---------------- blocks ---------------- */

interface Item {
  indent: number;
  text: string;
  task: "on" | "off" | null;
  taskIndex: number | null;
  ordered: boolean;
  sub?: Item[];
}

function renderList(items: Item[], ctx: MdCtx, depth: number, ordered: boolean): string {
  const tag = ordered && depth === 0 ? "ol" : "ul";
  let html = `<${tag} class="md-list${depth ? " sub" : ""}">`;
  for (const it of items) {
    if (it.task) {
      html += `<li class="task${it.task === "on" ? " on" : ""}" data-task="${it.taskIndex}" title="Tap to tick / untick">` +
        `<span class="tick" role="checkbox" aria-checked="${it.task === "on"}">✓</span>` +
        `<span class="tasktext">${inline(it.text, ctx)}</span>`;
    } else {
      html += "<li>" + inline(it.text, ctx);
    }
    if (it.sub && it.sub.length) html += renderList(it.sub, ctx, depth + 1, it.ordered);
    html += "</li>";
  }
  return html + `</${tag}>`;
}

function splitRow(line: string): string[] {
  const s = line.trim().replace(/^\|/, "").replace(/\|$/, "");
  return s.split(/\s*\|\s*(?![^[]*\])/).map((c) => c.trim());
}

export function render(text: string, ctx: MdCtx): string {
  const lines = (text || "").split("\n");
  const out: string[] = [];
  let i = 0;
  const footnotes: Record<string, string> = {};
  let taskCounter = 0; // global checklist index, matches the server order

  const push = (html: string, sl: number, el: number, cls?: string) =>
    out.push(`<div class="blk ${cls || ""}" data-sl="${sl}" data-el="${el}">${html}</div>`);

  while (i < lines.length) {
    const line = lines[i];
    if (!line.trim()) { i++; continue; }

    // display math $$...$$
    if (/^\s*\$\$/.test(line)) {
      const mstart = i;
      const buf = [line.replace(/^\s*\$\$/, "")];
      if (/^(.*)\$\$\s*$/.test(line) && line.trim().length > 4) {
        i++;
      } else {
        i++;
        while (i < lines.length && !/\$\$\s*$/.test(lines[i])) { buf.push(lines[i]); i++; }
        if (i < lines.length) { buf.push(lines[i].replace(/\$\$\s*$/, "")); i++; }
      }
      push(ctx.math(buf.join("\n"), true), mstart, i - 1, "blk-math");
      continue;
    }

    // fenced code
    if (/^\s*```/.test(line)) {
      const cstart = i;
      const lang = line.replace(/^\s*```/, "").trim();
      i++;
      const code: string[] = [];
      while (i < lines.length && !/^\s*```/.test(lines[i])) { code.push(lines[i]); i++; }
      i++;
      push(`<pre class="md-code"><div class="code-lang">${esc(lang)}</div><code>${esc(code.join("\n"))}</code></pre>`,
        cstart, i - 1, "blk-code");
      continue;
    }

    // heading
    const h = line.match(/^(#{1,6})\s+(.*?)\s*#*\s*$/);
    if (h) {
      const lvl = Math.min(h[1].length + 1, 6);
      push(`<h${lvl}>${inline(h[2], ctx)}</h${lvl}>`, i, i, "blk-h");
      i++;
      continue;
    }

    // hr
    if (/^\s*(-{3,}|\*{3,}|_{3,})\s*$/.test(line)) {
      push("<hr>", i, i, "blk-hr");
      i++;
      continue;
    }

    // quote
    if (/^\s*>\s?/.test(line)) {
      const qstart = i;
      const qbuf: string[] = [];
      while (i < lines.length && /^\s*>\s?/.test(lines[i])) {
        qbuf.push(lines[i].replace(/^\s*>\s?/, ""));
        i++;
      }
      push(`<blockquote>${inline(qbuf.join(" "), ctx)}</blockquote>`, qstart, i - 1, "blk-quote");
      continue;
    }

    // table
    if (/^\s*\|.*\|\s*$/.test(line) && i + 1 < lines.length &&
        /^\s*\|?[\s:|-]+\|?\s*$/.test(lines[i + 1]) && lines[i + 1].includes("-")) {
      const tstart = i;
      const head = splitRow(line);
      i += 2;
      const rows: string[][] = [];
      while (i < lines.length && /^\s*\|.*\|\s*$/.test(lines[i])) {
        rows.push(splitRow(lines[i]));
        i++;
      }
      let html = '<div class="tablewrap"><table><thead><tr>';
      head.forEach((c) => { html += `<th>${inline(c, ctx)}</th>`; });
      html += "</tr></thead><tbody>";
      rows.forEach((r) => {
        html += "<tr>";
        head.forEach((_, ci) => { html += `<td>${inline(r[ci] || "", ctx)}</td>`; });
        html += "</tr>";
      });
      html += "</tbody></table></div>";
      push(html, tstart, i - 1, "blk-table");
      continue;
    }

    // footnote definition
    const fd = line.match(/^\s*\[\^([a-zA-Z0-9_-]+)\]:\s*(.*)$/);
    if (fd) {
      const fstart = i;
      const fbuf = [fd[2]];
      i++;
      while (i < lines.length && lines[i].trim() &&
             !/^(#{1,6}\s|[-*]\s|\d+\.\s|>|\||```|\[\^|!\[)/.test(lines[i].trim())) {
        fbuf.push(lines[i].trim());
        i++;
      }
      footnotes[fd[1]] = fbuf.join(" ");
      push(`<div class="fn-def" data-fn="${fd[1]}"><b>[${fd[1]}]</b> ${inline(fbuf.join(" "), ctx)}</div>`,
        fstart, i - 1, "blk-fn");
      continue;
    }

    // lists (incl. task lists)
    const li = line.match(/^(\s*)([-*]|\d+[.)])\s+(.*)$/);
    if (li) {
      const lstart = i;
      const ordered = /\d/.test(li[2]);
      const baseIndent = li[1].length;
      const items: Item[] = [];
      while (i < lines.length) {
        const m2 = lines[i].match(/^(\s*)([-*]|\d+[.)])\s+(.*)$/);
        if (m2 && m2[1].length <= baseIndent + 1) {
          const task = m2[3].match(/^\[([ xX])\]\s+(.*)$/);
          items.push({
            indent: m2[1].length,
            text: task ? task[2] : m2[3],
            task: task ? (task[1].toLowerCase() === "x" ? "on" : "off") : null,
            taskIndex: task ? taskCounter++ : null,
            ordered: /\d/.test(m2[2]),
          });
          i++;
        } else if (m2) {
          const task2 = m2[3].match(/^\[([ xX])\]\s+(.*)$/);
          if (items.length) {
            items[items.length - 1].sub = items[items.length - 1].sub || [];
            items[items.length - 1].sub!.push({
              indent: m2[1].length,
              text: task2 ? task2[2] : m2[3],
              task: task2 ? (task2[1].toLowerCase() === "x" ? "on" : "off") : null,
              taskIndex: task2 ? taskCounter++ : null,
              ordered: /\d/.test(m2[2]),
            });
          }
          i++;
        } else if (lines[i].trim() && /^\s{2,}\S/.test(lines[i]) && items.length) {
          items[items.length - 1].text += " " + lines[i].trim();
          i++;
        } else break;
      }
      items.forEach((it) => { if (!it.sub) it.sub = []; });
      push(renderList(items, ctx, 0, ordered), lstart, i - 1, "blk-list");
      continue;
    }

    // standalone image -> figure
    const imgOnly = line.match(/^\s*!\[([^\]]*)\]\(([^)\s]+)\)\s*$/);
    if (imgOnly) {
      push(`<figure class="md-figure"><img class="md-img" src="${ctx.src(imgOnly[2])}" alt="${esc(imgOnly[1])}" loading="lazy" data-path="${esc(imgOnly[2])}">` +
        (imgOnly[1] ? `<figcaption>${esc(imgOnly[1])}</figcaption>` : "") + "</figure>",
        i, i, "blk-img");
      i++;
      continue;
    }

    // paragraph
    const pstart = i;
    const pbuf: string[] = [];
    while (i < lines.length && lines[i].trim() &&
           !/^(#{1,6}\s|[-*]\s|\d+[.)]\s|>|\||```|\$\$|\[\^|!\[)/.test(lines[i].trim())) {
      pbuf.push(lines[i]);
      i++;
    }
    if (!pbuf.length) { pbuf.push(line); i++; }
    push(`<p>${inline(pbuf.join(" "), ctx)}</p>`, pstart, i - 1, "blk-p");
  }

  let html = out.join("");

  // 3+ consecutive image figures become a tidy grid (with thumbnails)
  html = html.replace(
    /<div class="blk blk-img" data-sl="(\d+)" data-el="(\d+)">(<figure[\s\S]*?<\/figure>)<\/div>/g,
    '<span class="grid-slot" data-sl="$1" data-el="$2">$3</span>');
  html = html.replace(
    /(<span class="grid-slot"[^>]*><figure[\s\S]*?<\/figure><\/span>\s*){3,}/g,
    (m) => '<div class="blk blk-imggrid">' + m + "</div>");
  html = html.replace(/(<div class="blk blk-imggrid">[\s\S]*?<\/div>)/g, (grid) =>
    grid.replace(/(src=")\/files\/([^"]+)(")/g, '$1/thumb?path=$2&w=480$3'));

  if (Object.keys(footnotes).length) {
    let fl = '<div class="blk blk-fnlist" data-sl="999999" data-el="999999"><h3>Footnotes</h3><ol class="fnlist">';
    for (const id of Object.keys(footnotes)) {
      fl += `<li id="fn-${id}">${inline(footnotes[id], ctx)}</li>`;
    }
    html += fl + "</ol></div>";
  }
  return html;
}

/* KaTeX helper shared by the note view and quick-info values. */
export function renderMath(tex: string, display: boolean): string {
  const K = (window as any).katex;
  if (K) {
    try {
      return K.renderToString(tex, { displayMode: display, throwOnError: false });
    } catch { /* fall through */ }
  }
  return display
    ? `<div class="math-fallback">$$${esc(tex)}$$</div>`
    : `<em>${esc(tex)}</em>`;
}
