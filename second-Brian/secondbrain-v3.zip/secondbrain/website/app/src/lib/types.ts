/* Shared API types — mirrors website/server.py responses. */

export interface NoteRef {
  path: string;
  title: string;
  folder: string;
  updated?: string;
}

export interface AppState {
  notes: number;
  recent: NoteRef[];
  pinned: NoteRef[];
  saved_searches: SavedSearch[];
  themes: string[];
  port: number;
  bind: string;
}

export interface SavedSearch {
  name: string;
  params: Record<string, string>;
}

export interface ScoreSignal {
  weight: number;
  points: number;
  applied?: boolean;
  [k: string]: unknown;
}

export interface SearchResult {
  path: string;
  title: string;
  folder: string;
  updated: string;
  tags: string[];
  snippet?: string;
  score?: number | null;
  rank_reason?: string;
  coverage?: number;
  breakdown?: Record<string, ScoreSignal>;
  direct?: boolean;
  connected_to?: string;
  neighbor_kind?: string;
}

export interface SearchResponse {
  total: number;
  results: SearchResult[];
  notice?: string;
  elapsed_ms: number;
  query: { query_tags: string[]; groups?: string[] };
}

export interface Suggestion {
  type: "tag" | "folder";
  name: string;
  path?: string;
  count: number;
  starts: boolean;
}

export interface TagsData {
  tags: string[];
  rows: { tag: string; count: number }[];
  counts: Record<string, number>;
  unapproved: string[];
  proposed: string[];
  near_duplicates: { tags: string[]; distance?: number }[];
  approved_unused: string[];
  majors: string[];
  approved: string[];
  tag_synonyms: Record<string, string[]>;
  general_synonyms: string[];
}

export interface FolderNode {
  name: string;
  path: string;
  private: boolean;
  notes: number;
  children: FolderNode[];
}

export interface FoldersData {
  tree: FolderNode;
  subjects: { name: string; path: string }[];
}

export interface GraphData {
  nodes: { id: string; title: string; folder: string; tags: string[] }[];
  edges: [string, string][];
}

export interface QiRow {
  label: string;
  value: string;
  group: string | null;
}

export interface NoteView {
  path: string;
  folder: string;
  title: string;
  raw: string;
  hash: string;
  quick_info_raw: string | null;
  quick_info_rows: QiRow[];
  headings: string[];
  body: string;
  connected: string[];
  linked_in_text: { target: string; word: string }[];
  references: { title: string; url: string; accessed?: string }[];
  meta: Record<string, string>;
  my_notes: string[];
  incoming: string[];
  tags: string[];
  tasks: unknown[];
  attachments: string[];
  pinned: boolean;
}

export interface HealthItem {
  note?: string;
  link?: string;
  tags?: string[];
  file?: string;
  reason?: string;
  path?: string;
  problem?: string;
  [k: string]: unknown;
}

export interface HealthCheck {
  items: HealthItem[] | string[];
  fixable?: boolean;
  error?: string;
}

export interface HealthData {
  checks: Record<string, HealthCheck>;
  [k: string]: unknown;
}

export interface LogRow {
  file: string;
  date: string;
  who: string;
  title: string;
  undoable: boolean;
}

export interface TagPreviewResult {
  from: string;
  to?: string;
  into?: string;
  tag?: string;
  notes: { file: string; old: string[]; new: string[] }[];
  [k: string]: unknown;
}
