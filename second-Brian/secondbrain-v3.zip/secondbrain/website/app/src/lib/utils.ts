import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

/** The user never types https:// — bare domains get it automatically. */
export function normalizeUrl(u: string): string {
  u = (u || "").trim();
  if (!u) return u;
  if (/^[a-zA-Z][a-zA-Z0-9+.-]*:\/\//.test(u)) return u;
  if (u.startsWith("#") || u.startsWith("/")) return u;
  return "https://" + u;
}

export function prettyUrl(u: string): string {
  return (u || "").replace(/^https?:\/\//, "").replace(/\/$/, "");
}

export function fmtDate(d?: string | null): string {
  return d || "—";
}

export function debounce<T extends (...args: any[]) => void>(fn: T, ms: number) {
  let h: ReturnType<typeof setTimeout>;
  return function (this: unknown, ...args: Parameters<T>) {
    clearTimeout(h);
    h = setTimeout(() => fn.apply(this, args), ms);
  };
}

const HUES: Record<string, number> = {};
export function tagHue(major: string): number {
  if (!HUES[major]) {
    let h = 0;
    for (const c of major) h = (h * 31 + c.charCodeAt(0)) % 360;
    HUES[major] = h;
  }
  return HUES[major];
}

export function tagStyle(tag: string): React.CSSProperties {
  return { "--tag-h": String(tagHue(tag.split("-")[0])) } as React.CSSProperties;
}

export const noteName = (p: string) => p.split("/").slice(-2)[0];

export function esc(s: string | null | undefined): string {
  return (s == null ? "" : "" + s)
    .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}
