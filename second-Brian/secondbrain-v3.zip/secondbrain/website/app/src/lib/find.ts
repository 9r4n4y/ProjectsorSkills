/* Find-in-note helpers (view mode: DOM highlight + jump; edit mode:
 * textarea selection + scroll). Port of the v1.1 find bar. */

export interface FindState {
  q: string;
  idx: number;
  hits: HTMLElement[];
}

export const newFindState = (): FindState => ({ q: "", idx: 0, hits: [] });

export function clearMarks(container: HTMLElement | null) {
  if (!container) return;
  container.querySelectorAll("mark.find-hit").forEach((m) => {
    const t = document.createTextNode(m.textContent || "");
    m.replaceWith(t);
  });
  container.normalize();
}

export function runFindDom(
  container: HTMLElement | null,
  q: string,
  reset: boolean,
  state: FindState,
): FindState {
  clearMarks(container);
  const next: FindState = { q, idx: 0, hits: [] };
  if (!q || !container) return next;
  const walker = document.createTreeWalker(container, NodeFilter.SHOW_TEXT, {
    acceptNode: (n) =>
      n.parentNode && (n.parentNode.nodeName === "SCRIPT" || n.parentNode.nodeName === "MARK")
        ? NodeFilter.FILTER_REJECT
        : NodeFilter.FILTER_ACCEPT,
  });
  const needle = q.toLowerCase();
  const nodes: Text[] = [];
  while (walker.nextNode()) nodes.push(walker.currentNode as Text);
  for (const node of nodes) {
    const text = node.nodeValue || "";
    const low = text.toLowerCase();
    let pos = low.indexOf(needle);
    if (pos < 0) continue;
    const frag = document.createDocumentFragment();
    let last = 0;
    while (pos >= 0) {
      frag.appendChild(document.createTextNode(text.slice(last, pos)));
      const mark = document.createElement("mark");
      mark.className = "find-hit";
      mark.textContent = text.slice(pos, pos + needle.length);
      frag.appendChild(mark);
      next.hits.push(mark);
      last = pos + needle.length;
      pos = low.indexOf(needle, last);
    }
    frag.appendChild(document.createTextNode(text.slice(last)));
    node.replaceWith(frag);
  }
  if (!reset) next.idx = Math.min(state.idx, Math.max(0, next.hits.length - 1));
  return next;
}

export function stepDom(state: FindState, dir: number): FindState {
  const n = state.hits.length;
  if (!n) return state;
  const idx = ((state.idx + dir) % n + n) % n;
  state.hits.forEach((m) => m.classList.remove("current"));
  const m = state.hits[idx];
  if (m) {
    m.classList.add("current");
    m.scrollIntoView({ block: "center", behavior: "smooth" });
  }
  return { ...state, idx };
}

/* Edit mode: operate on the textarea itself. */
export function editFind(
  ed: HTMLTextAreaElement,
  needle: string,
  startIdx: number,
): { idx: number; total: number } {
  if (!needle) return { idx: 0, total: 0 };
  const low = ed.value.toLowerCase();
  const hits: number[] = [];
  let pos = low.indexOf(needle.toLowerCase());
  while (pos >= 0) { hits.push(pos); pos = low.indexOf(needle.toLowerCase(), pos + needle.length); }
  if (!hits.length) return { idx: 0, total: 0 };
  const idx = ((startIdx % hits.length) + hits.length) % hits.length;
  const p = hits[idx];
  ed.focus();
  ed.setSelectionRange(p, p + needle.length);
  const line = ed.value.slice(0, p).split("\n").length;
  const lh = parseFloat(getComputedStyle(ed).lineHeight) || 24;
  ed.scrollTop = Math.max(0, (line - 4) * lh);
  return { idx, total: hits.length };
}

/* Edit <-> view scroll anchoring (so switching never moves the view). */
export interface Anchor {
  kind: "view" | "edit";
  sl: number;
  frac: number;
  line: number;
}

export function captureAnchor(body: HTMLElement | null, editor: HTMLTextAreaElement | null): Anchor | null {
  const container = body || editor;
  if (!container) return null;
  if (body && body.style.display !== "none" && body.offsetParent !== null) {
    const top = body.getBoundingClientRect().top;
    const blocks = body.querySelectorAll<HTMLElement>(".blk");
    for (const b of blocks) {
      const r = b.getBoundingClientRect();
      if (r.bottom > top + 1) {
        const frac = Math.min(1, Math.max(0, (top - r.top) / Math.max(1, r.height)));
        return { kind: "view", sl: +b.dataset.sl!, frac, line: 0 };
      }
    }
    return { kind: "view", sl: 0, frac: 0, line: 0 };
  }
  if (editor) {
    const lh = parseFloat(getComputedStyle(editor).lineHeight) || 21;
    return { kind: "edit", line: Math.floor(editor.scrollTop / lh), sl: 0, frac: 0 };
  }
  return null;
}

export function restoreAnchor(body: HTMLElement | null, editor: HTMLTextAreaElement | null, a: Anchor | null) {
  if (!a) return;
  if (a.kind === "edit" && editor) {
    const lh = parseFloat(getComputedStyle(editor).lineHeight) || 21;
    editor.scrollTop = a.line * lh;
    return;
  }
  if (!body) return;
  const top = body.getBoundingClientRect().top;
  const blocks = body.querySelectorAll<HTMLElement>(".blk");
  let target: HTMLElement | null = null;
  let best = -1;
  for (const b of blocks) {
    const sl = +b.dataset.sl!;
    if (sl <= a.sl && sl > best) { target = b; best = sl; }
  }
  if (!target && blocks.length) target = blocks[0];
  if (!target) return;
  const r = target.getBoundingClientRect();
  window.scrollTo({ top: window.scrollY + (r.top + a.frac * r.height - top), behavior: "auto" });
}
