import * as React from "react";
import { HashRouter, Routes, Route, NavLink, useNavigate } from "react-router-dom";
import {
  Network as GraphIcon, HeartPulse, Home, Menu, Moon, NotebookPen,
  Search as SearchIcon, Sun, Tags as TagsIcon, ArchiveRestore,
  ChevronLeft, Monitor, FolderOpen,
} from "lucide-react";

import { ThemeProvider, useTheme } from "@/components/shared/theme";
import { UiProvider } from "@/components/shared/ui-context";
import { NewNoteDialog } from "@/components/shared/new-note-dialog";
import { CommandPalette, openPalette } from "@/components/shared/command-palette";
import { BrainLogo } from "@/components/shared/logo";
import { Kbd } from "@/components/shared/kbd";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Sheet, SheetContent, SheetTitle } from "@/components/ui/sheet";
import { TooltipProvider } from "@/components/ui/tooltip";
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Toaster } from "@/components/ui/sonner";

import HomeView from "@/views/home";
import SearchView from "@/views/search";
import NoteView from "@/views/note";
import TagsView from "@/views/tags";
import FilesView from "@/views/files";
import GraphView from "@/views/graph";
import HealthView from "@/views/health";
import BackupView from "@/views/backup";

const NAV_ITEMS = [
  { to: "/", label: "Home", icon: Home, end: true },
  { to: "/files", label: "Files", icon: FolderOpen, end: false },
  { to: "/tags", label: "Tags", icon: TagsIcon, end: false },
  { to: "/graph", label: "Graph", icon: GraphIcon, end: false },
  { to: "/search", label: "Search", icon: SearchIcon, end: false },
  { to: "/health", label: "Health", icon: HeartPulse, end: false },
  { to: "/backup", label: "Backup", icon: ArchiveRestore, end: false },
];

function AltBackHandler() {
  const nav = useNavigate();
  React.useEffect(() => {
    const fn = (e: KeyboardEvent) => {
      if (e.altKey && e.key === "ArrowLeft") {
        e.preventDefault();
        if (window.history.length > 1) nav(-1);
        else nav("/");
      }
    };
    document.addEventListener("keydown", fn);
    return () => document.removeEventListener("keydown", fn);
  }, [nav]);
  return null;
}

function BackButton() {
  const nav = useNavigate();
  return (
    <Button
      variant="ghost"
      size="sm"
      onClick={() => (window.history.length > 1 ? nav(-1) : nav("/"))}
      title="Go back one step (Alt+←)"
      className="gap-1.5 text-muted-foreground"
    >
      <ChevronLeft className="h-4 w-4" />
      <span className="hidden sm:inline">Back</span>
    </Button>
  );
}

function ThemeMenu() {
  const { theme, setTheme, resolved } = useTheme();
  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" size="icon" title="Theme" aria-label="Theme">
          {resolved === "dark" ? <Moon /> : <Sun />}
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end">
        {(["light", "dark", "system"] as const).map((t) => (
          <DropdownMenuItem key={t} onClick={() => setTheme(t)} className={theme === t ? "bg-accent" : ""}>
            {t === "light" && <Sun />}
            {t === "dark" && <Moon />}
            {t === "system" && <Monitor />}
            {t[0].toUpperCase() + t.slice(1)}
          </DropdownMenuItem>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}

function PaletteTrigger({ className }: { className?: string }) {
  const isMac = typeof navigator !== "undefined" && /Mac/i.test(navigator.platform || "");
  return (
    <Button variant="outline" size="sm" className={className} onClick={() => openPalette.fn?.()}>
      <SearchIcon className="text-muted-foreground" />
      <span className="text-muted-foreground">Search…</span>
      <span className="ml-auto hidden items-center gap-0.5 pl-3 sm:flex">
        <Kbd>{isMac ? "⌘" : "Ctrl"}</Kbd>
        <Kbd>K</Kbd>
      </span>
    </Button>
  );
}

function SidebarBody({ onNavigate }: { onNavigate?: () => void }) {
  return (
    <div className="flex h-full flex-col gap-1 p-3">
      <a href="#/" className="mb-2 flex items-center gap-2.5 px-2 py-1.5" onClick={onNavigate}>
        <BrainLogo size={30} />
        <div className="leading-tight">
          <div className="text-[15px] font-semibold tracking-tight">SecondBrain</div>
          <div className="text-[11px] text-muted-foreground">plain Markdown · local only</div>
        </div>
      </a>
      {NAV_ITEMS.map((n) => (
        <NavLink
          key={n.to}
          to={n.to}
          end={n.end}
          onClick={onNavigate}
          className={({ isActive }) =>
            "flex items-center gap-2.5 rounded-md px-2.5 py-2 text-sm transition-colors " +
            (isActive
              ? "bg-accent text-accent-foreground font-medium"
              : "text-muted-foreground hover:bg-accent/60 hover:text-foreground")
          }
        >
          <n.icon className="h-4 w-4" />
          {n.label}
        </NavLink>
      ))}
      <div className="mt-auto px-2 pb-2 pt-3">
        <Separator className="mb-3" />
        <p className="text-[11px] leading-relaxed text-muted-foreground">
          SecondBrain 1.2 — notes as plain Markdown, one folder per note.
          Press <Kbd>/</Kbd> to search anywhere.
        </p>
      </div>
    </div>
  );
}

function Shell() {
  const [newOpen, setNewOpen] = React.useState(false);
  const [mobileNav, setMobileNav] = React.useState(false);
  const folderRef = React.useRef("");

  // "/" opens the palette when not typing in a field; "e" toggles the editor on a note page.
  React.useEffect(() => {
    const fn = (e: KeyboardEvent) => {
      const tag = (document.activeElement as HTMLElement)?.tagName || "";
      const inField = /input|textarea|select/i.test(tag);
      if (e.key === "/" && !inField) {
        e.preventDefault();
        openPalette.fn?.();
      }
      if ((e.key === "e" || e.key === "E") && !inField && window.location.hash.startsWith("#/note/")) {
        document.dispatchEvent(new CustomEvent("sb-edit-note"));
      }
    };
    document.addEventListener("keydown", fn);
    return () => document.removeEventListener("keydown", fn);
  }, []);

  const openNewNote = (folder = "") => {
    folderRef.current = folder || "";
    setNewOpen(true);
  };

  return (
    <UiProvider value={{ openNewNote }}>
      <div className="flex min-h-screen">
        {/* desktop sidebar */}
        <aside className="sticky top-0 hidden h-screen w-60 shrink-0 border-r bg-card/50 md:block no-print">
          <SidebarBody />
        </aside>

        {/* mobile nav */}
        <Sheet open={mobileNav} onOpenChange={setMobileNav}>
          <SheetContent side="left" className="w-64 p-0">
            <SheetTitle className="sr-only">Navigation</SheetTitle>
            <SidebarBody onNavigate={() => setMobileNav(false)} />
          </SheetContent>
        </Sheet>

        <div className="flex min-w-0 flex-1 flex-col">
          {/* topbar */}
          <header className="sticky top-0 z-40 flex h-14 items-center gap-1.5 border-b bg-background/85 px-3 backdrop-blur no-print">
            <Button variant="ghost" size="icon" className="md:hidden" onClick={() => setMobileNav(true)} aria-label="Menu">
              <Menu />
            </Button>
            <BackButton />
            <PaletteTrigger className="hidden w-64 justify-start lg:inline-flex" />
            <div className="flex-1" />
            <Button size="sm" onClick={() => openNewNote()} className="gap-1.5">
              <NotebookPen className="h-4 w-4" />
              <span className="hidden sm:inline">New note</span>
            </Button>
            <ThemeMenu />
          </header>

          <main className="min-w-0 flex-1">
            <Routes>
              <Route path="/" element={<HomeView />} />
              <Route path="/search" element={<SearchView />} />
              <Route path="/note/:name" element={<NoteView />} />
              <Route path="/tags" element={<TagsView />} />
              <Route path="/files/*" element={<FilesView />} />
              <Route path="/graph" element={<GraphView />} />
              <Route path="/health" element={<HealthView />} />
              <Route path="/backup" element={<BackupView />} />
              <Route path="*" element={<HomeView />} />
            </Routes>
          </main>
        </div>

        <NewNoteDialog open={newOpen} onOpenChange={setNewOpen} preFolder={folderRef.current} />
        <CommandPalette />
      </div>
    </UiProvider>
  );
}

export default function App() {
  return (
    <ThemeProvider>
      <TooltipProvider delayDuration={200}>
        <HashRouter>
          <AltBackHandler />
          <Shell />
        </HashRouter>
        <Toaster />
      </TooltipProvider>
    </ThemeProvider>
  );
}
