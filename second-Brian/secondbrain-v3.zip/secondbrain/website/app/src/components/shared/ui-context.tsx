import * as React from "react";

interface UiCtx {
  openNewNote: (folder?: string) => void;
}

const Ctx = React.createContext<UiCtx>({ openNewNote: () => {} });

export function UiProvider({ value, children }: { value: UiCtx; children: React.ReactNode }) {
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export const useUi = () => React.useContext(Ctx);
