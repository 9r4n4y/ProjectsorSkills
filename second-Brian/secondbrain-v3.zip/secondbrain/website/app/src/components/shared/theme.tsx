import * as React from "react";

type Theme = "light" | "dark" | "system";

interface ThemeCtx {
  theme: Theme;
  setTheme: (t: Theme) => void;
  resolved: "light" | "dark";
}

const Ctx = React.createContext<ThemeCtx>({
  theme: "system",
  setTheme: () => {},
  resolved: "light",
});

function apply(t: Theme): "light" | "dark" {
  const dark =
    t === "dark" ||
    (t === "system" && window.matchMedia("(prefers-color-scheme: dark)").matches);
  document.documentElement.classList.toggle("dark", dark);
  document.documentElement.style.colorScheme = dark ? "dark" : "light";
  return dark ? "dark" : "light";
}

export function ThemeProvider({ children }: { children: React.ReactNode }) {
  const [theme, setThemeState] = React.useState<Theme>(
    () => (localStorage.getItem("sb-theme") as Theme) || "system",
  );
  const [resolved, setResolved] = React.useState<"light" | "dark">("light");

  React.useEffect(() => {
    setResolved(apply(theme));
    const mq = window.matchMedia("(prefers-color-scheme: dark)");
    const fn = () => {
      if ((localStorage.getItem("sb-theme") as Theme) === "system") setResolved(apply("system"));
    };
    mq.addEventListener("change", fn);
    return () => mq.removeEventListener("change", fn);
  }, [theme]);

  const setTheme = (t: Theme) => {
    localStorage.setItem("sb-theme", t);
    setThemeState(t);
  };

  return <Ctx.Provider value={{ theme, setTheme, resolved }}>{children}</Ctx.Provider>;
}

export const useTheme = () => React.useContext(Ctx);
