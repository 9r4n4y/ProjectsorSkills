import * as React from "react";
import { useNavigate } from "react-router-dom";
import {
  CommandDialog, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList, CommandSeparator,
} from "@/components/ui/command";
import { api } from "@/lib/api";
import type { GraphData } from "@/lib/types";

export const openPalette = { fn: null as null | (() => void) };

/** ⌘K / Ctrl+K command palette: jump to pages, notes, tags and actions. */
export function CommandPalette() {
  const nav = useNavigate();
  const [open, setOpen] = React.useState(false);
  const [graph, setGraph] = React.useState<GraphData | null>(null);

  React.useEffect(() => {
    openPalette.fn = () => setOpen(true);
    return () => { openPalette.fn = null; };
  }, []);

  React.useEffect(() => {
    if (open && !graph) api.graph().then(setGraph).catch(() => {});
  }, [open, graph]);

  React.useEffect(() => {
    const down = (e: KeyboardEvent) => {
      if ((e.key === "k" || e.key === "K") && (e.metaKey || e.ctrlKey)) {
        e.preventDefault();
        setOpen((o) => !o);
      }
    };
    document.addEventListener("keydown", down);
    return () => document.removeEventListener("keydown", down);
  }, []);

  const go = (to: string) => { setOpen(false); nav(to); };

  return (
    <CommandDialog open={open} onOpenChange={setOpen} title="Command palette">
      <CommandInput placeholder="Search notes, jump anywhere…" />
      <CommandList>
        <CommandEmpty>No results found.</CommandEmpty>
        <CommandGroup heading="Notes">
          {(graph?.nodes || []).slice(0, 12).map((n) => (
            <CommandItem key={n.id} value={n.title} onSelect={() => go(`/note/${encodeURIComponent(n.title)}`)}>
              <span className="truncate">{n.title}</span>
              <span className="ml-auto text-xs text-muted-foreground">{n.folder || "database"}</span>
            </CommandItem>
          ))}
        </CommandGroup>
        <CommandSeparator />
        <CommandGroup heading="Pages">
          <CommandItem value="home" onSelect={() => go("/")}><span>Home</span></CommandItem>
          <CommandItem value="files" onSelect={() => go("/files")}><span>Files</span></CommandItem>
          <CommandItem value="tags" onSelect={() => go("/tags")}><span>Tags</span></CommandItem>
          <CommandItem value="graph" onSelect={() => go("/graph")}><span>Graph</span></CommandItem>
          <CommandItem value="search" onSelect={() => go("/search")}><span>Search</span></CommandItem>
          <CommandItem value="health" onSelect={() => go("/health")}><span>Health</span></CommandItem>
          <CommandItem value="backup" onSelect={() => go("/backup")}><span>Backup</span></CommandItem>
        </CommandGroup>
      </CommandList>
    </CommandDialog>
  );
}
