import * as React from "react";
import { toast } from "sonner";
import { Crop, Download, Trash2, X } from "lucide-react";
import {
  Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle,
} from "@/components/ui/dialog";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { Button } from "@/components/ui/button";
import { api } from "@/lib/api";

/** Fullscreen image viewer with crop, download, delete. Crop = drag a box on
 * the image; the crop is saved as a new image or replaces the original
 * (original is backed up first by the backend). */
export function ImageViewer({
  src,
  path,
  filename,
  notePath,
  onClose,
  onChanged,
}: {
  src: string;
  path: string;
  filename: string;
  notePath: string;
  onClose: () => void;
  onChanged: () => void;
}) {
  const [cropping, setCropping] = React.useState(false);
  const [rect, setRect] = React.useState<{ x: number; y: number; w: number; h: number } | null>(null);
  const [confirmDelete, setConfirmDelete] = React.useState(false);
  const [cropDialog, setCropDialog] = React.useState(false);
  const imgRef = React.useRef<HTMLImageElement>(null);
  const stageRef = React.useRef<HTMLDivElement>(null);
  const start = React.useRef<{ x: number; y: number } | null>(null);

  const toImgCoords = (e: React.MouseEvent) => {
    const img = imgRef.current!;
    const r = img.getBoundingClientRect();
    const sx = img.naturalWidth / r.width;
    const sy = img.naturalHeight / r.height;
    return {
      x: Math.max(0, Math.min(img.naturalWidth, (e.clientX - r.left) * sx)),
      y: Math.max(0, Math.min(img.naturalHeight, (e.clientY - r.top) * sy)),
    };
  };

  const onDown = (e: React.MouseEvent) => {
    if (!cropping) return;
    start.current = toImgCoords(e);
  };
  const onMove = (e: React.MouseEvent) => {
    if (!cropping || !start.current) return;
    const c = toImgCoords(e);
    const s = start.current;
    setRect({
      x: Math.round(Math.min(s.x, c.x)),
      y: Math.round(Math.min(s.y, c.y)),
      w: Math.round(Math.abs(c.x - s.x)),
      h: Math.round(Math.abs(c.y - s.y)),
    });
  };
  const onUp = () => {
    if (!cropping || !rect) return;
    if (rect.w < 5 || rect.h < 5) { setRect(null); return; }
    start.current = null;
    setCropDialog(true);
  };

  const finishCrop = async (mode: string) => {
    try {
      const out = await api.imageCrop(notePath, filename, rect!, mode);
      toast.success(
        mode === "replace"
          ? `Replaced; the original is backed up as ${out.original_backed_up_as}`
          : `New image saved: ${out.new_image}`,
      );
      setCropDialog(false);
      setCropping(false);
      setRect(null);
      onChanged();
      onClose();
    } catch (e: any) {
      toast.error(e.message);
    }
  };

  const doDelete = async () => {
    try {
      const out = await api.imageDelete(notePath, filename);
      toast[out.warning ? "warning" : "success"](
        out.warning ? out.message || "Warning" : "Deleted; the file is kept in backup history.",
      );
      setConfirmDelete(false);
      onChanged();
      onClose();
    } catch (e: any) {
      toast.error(e.message);
    }
  };

  return (
    <div className="fixed inset-0 z-[60] flex flex-col bg-black/90" role="dialog" aria-modal="true">
      <div className="flex items-center gap-2 p-3">
        <span className="mr-auto truncate font-mono text-xs text-white/70">{path}</span>
        <Button variant="secondary" size="sm" onClick={() => { setCropping((c) => !c); setRect(null); }}>
          <Crop /> {cropping ? "Cancel crop" : "Crop"}
        </Button>
        <a href={src} download={filename}>
          <Button variant="secondary" size="sm"><Download /> Download</Button>
        </a>
        <Button variant="destructive" size="sm" onClick={() => setConfirmDelete(true)}><Trash2 /> Delete</Button>
        <Button variant="secondary" size="icon" onClick={onClose} aria-label="Close"><X /></Button>
      </div>
      <div className="flex flex-1 items-center justify-center overflow-auto p-6">
        <div
          ref={stageRef}
          className="fs-stage"
          onMouseDown={onDown}
          onMouseMove={onMove}
          onMouseUp={onUp}
        >
          <img ref={imgRef} src={src} alt={filename} className="max-h-[80vh] max-w-full select-none rounded" draggable={false} />
          {cropping && rect && (
            <div
              className="crop-box"
              style={{
                left: `${(rect.x / imgRef.current!.naturalWidth) * 100}%`,
                top: `${(rect.y / imgRef.current!.naturalHeight) * 100}%`,
                width: `${(rect.w / imgRef.current!.naturalWidth) * 100}%`,
                height: `${(rect.h / imgRef.current!.naturalHeight) * 100}%`,
              }}
            />
          )}
        </div>
      </div>
      {cropping && (
        <p className="pb-3 text-center text-sm text-white/70">
          Drag a rectangle on the image, then choose what happens to the original.
        </p>
      )}

      <Dialog open={cropDialog} onOpenChange={setCropDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Crop is saved as a new image</DialogTitle>
            <DialogDescription>Rectangle {rect?.w} × {rect?.h} px. What should happen to the original?</DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setCropDialog(false)}>Cancel</Button>
            <Button variant="outline" onClick={() => finishCrop("keep_both")}>Keep both</Button>
            <Button onClick={() => finishCrop("replace")}>Replace the original (old one is backed up first)</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <AlertDialog open={confirmDelete} onOpenChange={setConfirmDelete}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete this image?</AlertDialogTitle>
            <AlertDialogDescription>
              The file is kept in backup history and you will be warned if the note still points to it.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction variant="destructive" onClick={doDelete}>Delete</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
