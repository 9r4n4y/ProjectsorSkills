import * as React from "react";
import { useNavigate } from "react-router-dom";
import { toast } from "sonner";
import {
  Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { SuggestInput } from "@/components/shared/suggest-input";
import { Badge } from "@/components/ui/badge";
import { api } from "@/lib/api";
import type { FolderNode } from "@/lib/types";

/** New-note dialog: always offers database root + every folder (creating the
 * very first note can never fail with "folder does not exist"), live tag
 * suggestions, and a disabled-while-working create button. */
export function NewNoteDialog({
  open,
  onOpenChange,
  preFolder = "",
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  preFolder?: string;
}) {
  const nav = useNavigate();
  const [folders, setFolders] = React.useState<FolderNode | null>(null);
  const [name, setName] = React.useState("");
  const [folder, setFolder] = React.useState(preFolder || "");
  const [tags, setTags] = React.useState<string[]>([]);
  const [tagDraft, setTagDraft] = React.useState("");
  const [busy, setBusy] = React.useState(false);

  React.useEffect(() => {
    if (!open) return;
    setName("");
    setTags([]);
    setTagDraft("");
    setFolder(preFolder || "");
    api.folders().then((f) => setFolders(f.tree)).catch(() => setFolders(null));
  }, [open, preFolder]);

  const addTag = (t: string) => {
    t = t.trim().replace(/\s+/g, "_");
    if (t && !tags.includes(t)) setTags((ts) => [...ts, t]);
    setTagDraft("");
  };

  const create = async () => {
    if (!name.trim()) { toast.error("Give the note a detailed name."); return; }
    setBusy(true);
    try {
      const out = await api.createNote(folder, name.trim(), tags);
      const added = out.master_updated || [];
      toast.success("Note created." + (added.length ? ` Tags added to the global list: ${added.join(", ")}` : ""));
      onOpenChange(false);
      nav(`/note/${encodeURIComponent(name.trim())}`);
    } catch (e: any) {
      toast.error(e.message);
      setBusy(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Create a new note</DialogTitle>
          <DialogDescription>
            The note gets its own folder with <code className="font-mono text-xs">&lt;name&gt;.md</code>, tags.txt and attachments/. Names are unique across the whole wiki.
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-4">
          <div className="space-y-1.5">
            <Label htmlFor="nn-name">Note name</Label>
            <Input
              id="nn-name"
              placeholder="e.g. Cold Brew Coffee Ratios"
              value={name}
              autoFocus
              onChange={(e) => setName(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && create()}
            />
          </div>
          <div className="space-y-1.5">
            <Label>Folder</Label>
            <Select value={folder} onValueChange={setFolder}>
              <SelectTrigger><SelectValue placeholder="database (root)" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="">database (root)</SelectItem>
                {flatten(folders).map((f) => (
                  <SelectItem key={f.path} value={f.path}>
                    <span style={{ paddingLeft: f.depth * 12 }}>{f.name}</span>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-1.5">
            <Label>Tags</Label>
            {tags.length > 0 && (
              <div className="flex flex-wrap gap-1.5">
                {tags.map((t) => (
                  <Badge key={t} variant="secondary" className="cursor-pointer" onClick={() => setTags((ts) => ts.filter((x) => x !== t))}>
                    {t} ✕
                  </Badge>
                ))}
              </div>
            )}
            <SuggestInput
              type="tag"
              value={tagDraft}
              onChange={setTagDraft}
              onSubmit={(s) => addTag(s.name)}
              placeholder="Type to see every existing tag…"
            />
            <p className="text-xs text-muted-foreground">Every tag you add is also added to the global tag list at once — they can never fall out of sync.</p>
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
          <Button onClick={create} disabled={busy}>
            {busy ? "Creating…" : "Create and open"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function flatten(node: FolderNode | null, depth = 0, acc: { name: string; path: string; depth: number }[] = []) {
  if (!node) return acc;
  (node.children || []).forEach((c) => {
    if (!c.private) {
      acc.push({ name: c.name, path: c.path, depth });
      flatten(c, depth + 1, acc);
    }
  });
  return acc;
}
