import * as React from "react";
import { cn } from "@/lib/utils";

export interface Branch {
  kind: "out" | "in";
  name: string;
}

/** The connected-notes map: this note in the middle, outgoing branches to the
 * right, incoming to the left. Click a branch to isolate it. */
export function BranchMap({
  title,
  outs,
  ins,
  selected,
  onSelect,
}: {
  title: string;
  outs: string[];
  ins: string[];
  selected: Branch | null;
  onSelect: (b: Branch | null) => void;
}) {
  const W = 560;
  const rowH = 44;
  const maxSide = Math.max(outs.length, ins.length, 1);
  const H = Math.max(120, maxSide * rowH + 40);
  const cx = W / 2;
  const cy = H / 2;

  const mk = (list: string[], side: "out" | "in") =>
    list.map((name, i) => ({
      name,
      side,
      y: H / 2 + (i - (list.length - 1) / 2) * rowH,
      x: side === "out" ? W - 95 - 6 : 95 + 6,
    }));
  const right = mk(outs, "out");
  const left = mk(ins, "in");

  const isSel = (side: string, name: string) =>
    !!selected && selected.kind === side && selected.name === name;

  return (
    <div className="overflow-x-auto rounded-lg border bg-muted/30 p-2">
      <svg width={W} height={H} viewBox={`0 0 ${W} ${H}`} className="mx-auto block max-w-full">
        {left.map((n) => <Edge key={"e-i-" + n.name} n={n} cx={cx} cy={cy} hot={isSel("in", n.name)} />)}
        {right.map((n) => <Edge key={"e-o-" + n.name} n={n} cx={cx} cy={cy} hot={isSel("out", n.name)} />)}

        {/* this note */}
        <g>
          <rect x={cx - 84} y={cy - 17} width={168} height={34} rx={10} className="fill-primary stroke-primary" />
          <text x={cx} y={cy + 4} textAnchor="middle" className="fill-primary-foreground text-[13px]">
            {truncate(title, 24)}
          </text>
        </g>

        {left.map((n) => (
          <BranchNode key={"i-" + n.name} n={n} selected={isSel("in", n.name)}
            onClick={() => onSelect(isSel("in", n.name) ? null : { kind: "in", name: n.name })} />
        ))}
        {right.map((n) => (
          <BranchNode key={"o-" + n.name} n={n} selected={isSel("out", n.name)}
            onClick={() => onSelect(isSel("out", n.name) ? null : { kind: "out", name: n.name })} />
        ))}
      </svg>
    </div>
  );
}

function Edge({ n, cx, cy, hot }: { n: { x: number; y: number }; cx: number; cy: number; hot: boolean }) {
  const bend = (n.x + cx) / 2;
  return (
    <path
      d={`M${cx} ${cy} C ${bend} ${cy}, ${bend} ${n.y}, ${n.x} ${n.y}`}
      className={cn("fill-none", hot ? "stroke-primary" : "stroke-border")}
      strokeWidth={hot ? 2 : 1.25}
    />
  );
}

function BranchNode({ n, selected, onClick }: { n: { x: number; y: number; name: string }; selected: boolean; onClick: () => void }) {
  const label = truncate(n.name, 22);
  const w = Math.max(64, label.length * 6.4 + 18);
  return (
    <g onClick={onClick} className="cursor-pointer">
      <rect
        x={n.x - w / 2} y={n.y - 14} width={w} height={28} rx={9}
        className={cn(
          "stroke-border transition-colors",
          selected ? "fill-primary/10 stroke-primary" : "fill-background hover:fill-accent",
        )}
      />
      <text x={n.x} y={n.y + 4} textAnchor="middle" className="fill-foreground text-[12px] select-none">{label}</text>
    </g>
  );
}

function truncate(s: string, n: number) {
  return s.length > n ? s.slice(0, n - 1) + "…" : s;
}
