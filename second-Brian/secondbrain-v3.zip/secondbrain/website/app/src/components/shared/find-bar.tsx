import * as React from "react";
import { ChevronDown, ChevronUp, X, Search } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { clearMarks, runFindDom, stepDom, editFind, type FindState } from "@/lib/find";

/** Find in note — highlights every hit in the rendered note and jumps with
 * ↑/↓ (view mode); in edit mode it selects the match in the textarea and
 * scrolls it into view. Esc closes. */
export function FindBar({
  containerRef,
  editorRef,
  onClose,
}: {
  containerRef: React.RefObject<HTMLElement | null>;
  editorRef: React.RefObject<HTMLTextAreaElement | null>;
  onClose: () => void;
}) {
  const [q, setQ] = React.useState("");
  const [count, setCount] = React.useState({ idx: 0, total: 0 });
  const stateRef = React.useRef<FindState>({ q: "", idx: 0, hits: [] });
  const inputRef = React.useRef<HTMLInputElement>(null);

  React.useEffect(() => {
    inputRef.current?.focus();
  }, []);

  const domMode = !!containerRef.current;

  const apply = (reset: boolean, val?: string) => {
    const needle = val ?? q;
    if (domMode) {
      const s = runFindDom(containerRef.current, needle, reset, stateRef.current);
      stateRef.current = s;
      const stepped = stepDom({ ...s, idx: reset ? 0 : s.idx }, 0);
      stateRef.current = stepped;
      setCount({ idx: stepped.idx, total: stepped.hits.length });
    } else if (editorRef.current) {
      const r = editFind(editorRef.current, needle, reset ? 0 : count.idx);
      setCount(r);
    }
  };

  const step = (dir: number) => {
    if (domMode) {
      const s = stepDom(stateRef.current, dir);
      stateRef.current = s;
      setCount({ idx: s.idx, total: s.hits.length });
    } else if (editorRef.current) {
      setCount(editFind(editorRef.current, q, count.idx + dir));
    }
  };

  const close = () => {
    clearMarks(containerRef.current);
    onClose();
  };

  return (
    <div className="sticky top-2 z-30 mx-auto flex w-fit items-center gap-1.5 rounded-lg border bg-popover/95 p-1.5 shadow-lg backdrop-blur no-print">
      <Search className="ml-1 h-4 w-4 text-muted-foreground" />
      <Input
        ref={inputRef}
        value={q}
        onChange={(e) => { setQ(e.target.value); apply(true, e.target.value); }}
        onKeyDown={(e) => {
          if (e.key === "Enter") { e.preventDefault(); step(e.shiftKey ? -1 : 1); }
          if (e.key === "Escape") close();
        }}
        placeholder="Find in note…"
        className="h-8 w-56 border-0 shadow-none focus-visible:ring-0"
      />
      <span className="min-w-14 text-center text-xs tabular-nums text-muted-foreground">
        {count.total ? `${count.idx + 1} / ${count.total}` : q ? "0 / 0" : ""}
      </span>
      <Button variant="ghost" size="iconSm" onClick={() => step(-1)} title="Previous (Shift+Enter)" aria-label="Previous match">
        <ChevronUp />
      </Button>
      <Button variant="ghost" size="iconSm" onClick={() => step(1)} title="Next (Enter)" aria-label="Next match">
        <ChevronDown />
      </Button>
      <Button variant="ghost" size="iconSm" onClick={close} title="Close (Esc)" aria-label="Close find bar">
        <X />
      </Button>
    </div>
  );
}
