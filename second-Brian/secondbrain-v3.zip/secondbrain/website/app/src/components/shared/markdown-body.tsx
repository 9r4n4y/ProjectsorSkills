import * as React from "react";
import { render, type MdCtx } from "@/lib/markdown";
import { cn, esc } from "@/lib/utils";

/** The rendered note body. Renders the block HTML produced by the shared
 * renderer and delegates clicks: task ticks (real checkboxes wired to the
 * server), image fullscreen, Alt+click image resize. */
export function MarkdownBody({
  text,
  ctx,
  onTask,
  onImage,
  className,
  bodyRef,
}: {
  text: string;
  ctx: MdCtx;
  onTask: (index: number) => void;
  onImage: (img: HTMLImageElement) => void;
  className?: string;
  bodyRef?: React.MutableRefObject<HTMLElement | null>;
}) {
  const html = React.useMemo(() => render(text, ctx), [text, ctx]);
  const ref = React.useRef<HTMLElement | null>(null);

  React.useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const handler = (e: MouseEvent) => {
      const t = e.target as HTMLElement;
      const task = t.closest("li.task");
      if (task) {
        e.preventDefault();
        onTask(+(task as HTMLElement).dataset.task!);
        return;
      }
      const img = t.closest("img.md-img") as HTMLImageElement | null;
      if (img) {
        if (e.altKey) {
          const widths = ["40%", "60%", "80%", "100%"];
          const cur = img.style.width || "100%";
          const next = widths[(widths.indexOf(cur) + 1) % widths.length];
          img.style.width = next;
          e.preventDefault();
          return;
        }
        onImage(img);
      }
    };
    el.addEventListener("click", handler);
    return () => el.removeEventListener("click", handler);
  }, [onTask, onImage]);

  return (
    <article
      ref={(node) => {
        ref.current = node;
        if (bodyRef) {
          if (typeof bodyRef === "object") (bodyRef as React.MutableRefObject<HTMLElement | null>).current = node;
          else if (typeof bodyRef === "function") (bodyRef as (n: HTMLElement | null) => void)(node);
        }
      }}
      className={cn("md-body", className)}
      dangerouslySetInnerHTML={{ __html: html }}
      style={{ ["--note-size" as string]: "var(--note-size, 17px)" }}
    />
  );
}

/** Build the renderer context for a given note path. */
export function useMdCtx(path: string, titles: Set<string>): MdCtx {
  return React.useMemo(
    () => ({
      src: (p: string) => {
        if (/^https?:/.test(p)) return p;
        const np = p.replace(/^\.?\//, "");
        if (np.startsWith("attachments/")) {
          return "/files/" + path.split("/").slice(0, -1).join("/") + "/" + np;
        }
        return "/files/database/" + np;
      },
      missing: (t: string) => !titles.has(t.trim()),
      math: (tex: string, display: boolean) => {
        const K = (window as any).katex;
        if (K) {
          try { return K.renderToString(tex, { displayMode: display, throwOnError: false }); } catch { /* noop */ }
        }
        return display ? `<div class="math-fallback">$$${esc(tex)}$$</div>` : `<em>${esc(tex)}</em>`;
      },
    }),
    [path, titles],
  );
}
