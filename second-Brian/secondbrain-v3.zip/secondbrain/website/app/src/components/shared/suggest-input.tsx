import * as React from "react";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Input } from "@/components/ui/input";
import { Tag, Folder } from "lucide-react";
import { api } from "@/lib/api";
import type { Suggestion } from "@/lib/types";
import { cn, debounce } from "@/lib/utils";

/** An input that suggests EXISTING tags/folders while typing (never a dead end). */
export function SuggestInput({
  value,
  onChange,
  onSubmit,
  type = "all",
  placeholder,
  className,
  autoFocus,
}: {
  value: string;
  onChange: (v: string) => void;
  onSubmit?: (s: Suggestion) => void;
  type?: "all" | "tag" | "folder";
  placeholder?: string;
  className?: string;
  autoFocus?: boolean;
}) {
  const [open, setOpen] = React.useState(false);
  const [sugs, setSugs] = React.useState<Suggestion[]>([]);
  const [active, setActive] = React.useState(0);

  const refresh = React.useMemo(
    () =>
      debounce(async (q: string) => {
        const res = await api.suggest(q, type);
        setSugs(res.suggestions || []);
        setActive(0);
      }, 120),
    [type],
  );

  React.useEffect(() => {
    refresh(value);
  }, [value, refresh]);

  const pick = (s: Suggestion) => {
    if (onSubmit) {
      onSubmit(s);
    } else {
      onChange(s.name);
    }
    setOpen(false);
  };

  return (
    <Popover open={open && sugs.length > 0}>
      <PopoverTrigger asChild>
        <div className="relative w-full">
          <Input
            value={value}
            autoFocus={autoFocus}
            placeholder={placeholder}
            className={className}
            onChange={(e) => {
              onChange(e.target.value);
              setOpen(true);
            }}
            onFocus={() => setOpen(true)}
            onBlur={() => setTimeout(() => setOpen(false), 150)}
            onKeyDown={(e) => {
              if (!open) return;
              if (e.key === "ArrowDown") { e.preventDefault(); setActive((a) => Math.min(a + 1, sugs.length - 1)); }
              if (e.key === "ArrowUp") { e.preventDefault(); setActive((a) => Math.max(a - 1, 0)); }
              if (e.key === "Enter" && sugs[active]) { e.preventDefault(); pick(sugs[active]); }
              if (e.key === "Escape") setOpen(false);
            }}
          />
        </div>
      </PopoverTrigger>
      <PopoverContent
        className="w-[--radix-popover-trigger-width] p-1"
        onOpenAutoFocus={(e) => e.preventDefault()}
        align="start"
      >
        {sugs.map((s, i) => (
          <button
            key={s.type + s.name}
            className={cn(
              "flex w-full items-center gap-2 rounded-md px-2 py-1.5 text-left text-sm",
              i === active ? "bg-accent text-accent-foreground" : "hover:bg-accent",
            )}
            onMouseDown={(e) => {
              e.preventDefault();
              pick(s);
            }}
            onMouseEnter={() => setActive(i)}
          >
            {s.type === "tag" ? <Tag className="h-3.5 w-3.5 text-muted-foreground" /> : <Folder className="h-3.5 w-3.5 text-muted-foreground" />}
            <span className="truncate">{s.name}</span>
            <span className="ml-auto text-xs text-muted-foreground">
              {s.type} · {s.count} note{s.count === 1 ? "" : "s"}
            </span>
          </button>
        ))}
      </PopoverContent>
    </Popover>
  );
}
