import * as React from "react";
import { Link } from "react-router-dom";
import { Tag, X } from "lucide-react";
import { cn, tagStyle } from "@/lib/utils";

/** Deterministic, colored tag badge (hue from the tag's first group). */
export function TagBadge({
  tag,
  onRemove,
  className,
  count,
}: {
  tag: string;
  onRemove?: () => void;
  className?: string;
  count?: number;
}) {
  return (
    <span
      className={cn(
        "tag-chip inline-flex max-w-full items-center gap-1 rounded-md px-2 py-0.5 text-xs font-medium",
        className,
      )}
      style={tagStyle(tag)}
    >
      <Link
        to={`/search?tags=${encodeURIComponent(tag)}&run=1`}
        className="inline-flex items-center gap-1 truncate hover:underline"
        title={count != null ? `${count} note${count === 1 ? "" : "s"}` : tag}
      >
        <Tag className="h-3 w-3 shrink-0 opacity-60" />
        <span className="truncate">{tag}</span>
        {count != null && <span className="opacity-60">{count}</span>}
      </Link>
      {onRemove && (
        <button
          onClick={(e) => {
            e.preventDefault();
            e.stopPropagation();
            onRemove();
          }}
          className="rounded p-0.5 hover:bg-black/10 dark:hover:bg-white/10"
          aria-label={`Remove tag ${tag}`}
        >
          <X className="h-3 w-3" />
        </button>
      )}
    </span>
  );
}
