import { MoreHorizontal } from "lucide-react";
import { cn, noteName } from "@/lib/utils";

/** The SecondBrain brand: a brain drawn on a black rounded square (no emoji). */
export function BrainLogo({ size = 28, className }: { size?: number; className?: string }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 32 32"
      aria-label="SecondBrain"
      className={cn("shrink-0", className)}
    >
      <rect width="32" height="32" rx="7" fill="#000000" />
      <path
        d="M12.5 7.5c-2.5 0-4.5 1.9-4.5 4.2 0 .9.3 1.7.8 2.4-1.1.7-1.8 1.9-1.8 3.3 0 2.1 1.7 3.8 3.9 3.8h.4c.5 1.5 2 2.6 3.7 2.6 1.1 0 2.1-.4 2.8-1.2.7.8 1.7 1.2 2.8 1.2 1.7 0 3.2-1.1 3.7-2.6h.4c2.2 0 3.9-1.7 3.9-3.8 0-1.4-.7-2.6-1.8-3.3.5-.7.8-1.5.8-2.4 0-2.3-2-4.2-4.5-4.2-.6 0-1.2.1-1.7.3C20.4 6 18.6 4.5 16.5 4.5S12.6 6 12 7.8c-.5-.2-1-.3-1.5-.3z"
        fill="none" stroke="#fff" strokeWidth="1.6"
      />
      <path
        d="M16.5 7v18M12 12.5c1.5.8 3 2.5 4.5 2.5s3-1.7 4.5-2.5M11 18.5c1.7.6 3.5 2 5.5 2s3.8-1.4 5.5-2"
        fill="none" stroke="#fff" strokeWidth="1.2"
      />
    </svg>
  );
}

export { MoreHorizontal, noteName };
