import * as React from "react";
import { Link, useParams, useNavigate } from "react-router-dom";
import { toast } from "sonner";
import {
  GitBranch as BranchIcon, Copy, Download, Eye, FileText,
  House, Link2, Pin, Printer, Save, Search, Settings2, Tag, X,
  Bold, Italic, Code, SquareRadical, Heading2, List, ListTodo, TextQuote,
  Superscript, Minus, Table, ImagePlus, Pencil, Plus,
} from "lucide-react";

import { api } from "@/lib/api";
import type { NoteView as NoteData } from "@/lib/types";
import { cn, esc, normalizeUrl, prettyUrl } from "@/lib/utils";
import { captureAnchor, restoreAnchor, newFindState } from "@/lib/find";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Skeleton } from "@/components/ui/skeleton";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";
import {
  Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  Breadcrumb, BreadcrumbItem, BreadcrumbLink, BreadcrumbList, BreadcrumbPage, BreadcrumbSeparator,
} from "@/components/ui/breadcrumb";

import { TagBadge } from "@/components/shared/tag-badge";
import { SuggestInput } from "@/components/shared/suggest-input";
import { BranchMap, type Branch } from "@/components/shared/branch-map";
import { MarkdownBody, useMdCtx } from "@/components/shared/markdown-body";
import { ImageViewer } from "@/components/shared/image-viewer";
import { FindBar } from "@/components/shared/find-bar";

export default function NoteView() {
  const { name = "" } = useParams();
  const [note, setNote] = React.useState<NoteData | null>(null);
  const [error, setError] = React.useState<string | null>(null);
  const [titles, setTitles] = React.useState<Set<string>>(new Set());
  const [editMode, setEditMode] = React.useState(false);
  const [draft, setDraft] = React.useState<string | null>(null);
  const [branchSel, setBranchSel] = React.useState<Branch | null>(null);
  const [findOpen, setFindOpen] = React.useState(false);
  const [viewer, setViewer] = React.useState<{ src: string; path: string } | null>(null);
  const [editorText, setEditorText] = React.useState("");

  const bodyRef = React.useRef<HTMLDivElement | null>(null);
  const editorRef = React.useRef<HTMLTextAreaElement | null>(null);

  const load = React.useCallback(async () => {
    try {
      const n = await api.note(name);
      // the server keeps the '# Title' line inside raw; the rendered body
      // must not repeat the title heading
      const parsed = stripBlocks(n.raw);
      if (parsed.body) n.body = parsed.body;
      setNote(n);
      setError(null);
      const g = await api.graph();
      setTitles(new Set(g.nodes.map((x) => x.title)));
    } catch (e: any) {
      setError(e.message);
    }
  }, [name]);

  React.useEffect(() => {
    setEditMode(false);
    setDraft(null);
    setBranchSel(null);
    setFindOpen(false);
    load();
  }, [load]);

  // "e" shortcut opens the editor
  React.useEffect(() => {
    const fn = () => { if (!editMode && note) startEdit(); };
    document.addEventListener("sb-edit-note", fn);
    return () => document.removeEventListener("sb-edit-note", fn);
  });

  const mdCtx = useMdCtx(note?.path || "", titles);

  async function startEdit() {
    if (!note) return;
    if (draft !== null) {
      setEditorText(draft);
      setEditMode(true);
      return;
    }
    setEditorText(note.raw);
    setEditMode(true);
  }

  async function reload(keepMode = false) {
    const anchor = !keepMode ? captureAnchor(bodyRef.current, editorRef.current) : null;
    await load();
    if (anchor && !keepMode) {
      requestAnimationFrame(() => restoreAnchor(bodyRef.current, editorRef.current, anchor));
    }
  }

  async function toggleTask(idx: number) {
    if (!note) return;
    const y = window.scrollY;
    try {
      const out = await api.toggleTask(note.path, idx, draft ?? undefined);
      if (draft !== null) {
        const updated = { ...note, raw: out.text, body: stripBlocks(out.text).body };
        setDraft(out.text);
        setNote(updated);
      } else {
        const updated = { ...note, raw: out.text, hash: out.hash || note.hash, body: stripBlocks(out.text).body };
        setNote(updated);
      }
      requestAnimationFrame(() => window.scrollTo(0, y));
      toast.success("Ticked. Saved.");
    } catch (e: any) {
      toast.error(e.message);
    }
  }

  if (error) {
    return (
      <div className="mx-auto max-w-2xl px-4 py-16 text-center">
        <p className="text-lg font-medium">This note does not exist.</p>
        <p className="mt-1 text-sm text-muted-foreground">{error}</p>
        <Button className="mt-4" onClick={() => window.history.back()}>Go back</Button>
      </div>
    );
  }

  if (!note) {
    return (
      <div className="mx-auto w-full max-w-5xl space-y-4 px-4 py-8 sm:px-6">
        <Skeleton className="h-5 w-64" />
        <Skeleton className="h-10 w-96 max-w-full" />
        <div className="grid gap-6 md:grid-cols-[1fr_260px]">
          <div className="space-y-3">
            {Array.from({ length: 6 }).map((_, i) => <Skeleton key={i} className="h-5 w-full" />)}
          </div>
          <Skeleton className="h-48 rounded-xl" />
        </div>
      </div>
    );
  }

  const outs = note.connected || [];
  const ins = (note.incoming || []).map((p) => p.split("/").slice(-2)[0]);
  const connCount = outs.length + ins.length;
  const folderBits = (note.folder || "").split("/").filter(Boolean);

  /* ============================== VIEW MODE ============================== */
  if (!editMode) {
    return (
      <div className="mx-auto w-full max-w-6xl px-4 py-6 sm:px-6">
        {findOpen && (
          <FindBar containerRef={bodyRef} editorRef={editorRef} onClose={() => setFindOpen(false)} />
        )}

        <div className="mb-3 flex flex-wrap items-center gap-2 no-print">
          <Breadcrumb>
            <BreadcrumbList>
              <BreadcrumbItem>
                <BreadcrumbLink asChild><Link to="/"><House className="h-3.5 w-3.5" /></Link></BreadcrumbLink>
              </BreadcrumbItem>
              {folderBits.map((f) => (
                <React.Fragment key={f}>
                  <BreadcrumbSeparator />
                  <BreadcrumbItem><span className="text-muted-foreground">{f}</span></BreadcrumbItem>
                </React.Fragment>
              ))}
              <BreadcrumbSeparator />
              <BreadcrumbItem><BreadcrumbPage>{note.title}</BreadcrumbPage></BreadcrumbItem>
            </BreadcrumbList>
          </Breadcrumb>
          <div className="ml-auto flex items-center gap-1">
            <Tooltip>
              <TooltipTrigger asChild>
                <Button variant="ghost" size="iconSm" onClick={() => setFindOpen(true)} title="Find in note (Ctrl+F)">
                  <Search />
                </Button>
              </TooltipTrigger>
              <TooltipContent>Find in note — Ctrl+F</TooltipContent>
            </Tooltip>
            <Button
              variant={note.pinned ? "secondary" : "ghost"}
              size="sm"
              className="gap-1.5"
              onClick={async () => {
                await api.togglePin(note.path);
                toast.success(note.pinned ? "Unpinned." : "Pinned to home.");
                reload();
              }}
            >
              <Pin className={cn("h-4 w-4", note.pinned && "fill-current")} />
              {note.pinned ? "Pinned" : "Pin"}
            </Button>
          </div>
        </div>

        {/* title + actions */}
        <div className="mb-5 flex flex-wrap items-start justify-between gap-3">
          <h1 className="min-w-0 text-3xl font-semibold tracking-tight">{note.title}</h1>
          <div className="flex flex-wrap items-center gap-2 no-print">
            <Button onClick={startEdit}><Pencil /> Edit</Button>
            <Button
              variant="outline"
              onClick={async () => {
                const withoutMeta = note.raw.replace(/:::meta\n[\s\S]*?:::\s*$/, "").trimEnd();
                try {
                  await navigator.clipboard.writeText(withoutMeta);
                  toast.success("Note copied as raw Markdown.");
                } catch {
                  toast.error("Clipboard blocked by the browser; copy from Edit mode instead.");
                }
              }}
            >
              <Copy /> Copy
            </Button>
            <Button variant="outline" asChild>
              <a href={api.exportUrl(note.path)}><Download /> Export metadata</a>
            </Button>
            <Button variant="outline" onClick={() => window.print()}><Printer /> Print / PDF</Button>
          </div>
        </div>

        <div className="grid gap-8 lg:grid-cols-[1fr_260px]">
          {/* main column */}
          <div className="min-w-0">
            <MarkdownBody
              text={note.body}
              ctx={mdCtx}
              onTask={toggleTask}
              onImage={(img) => setViewer({ src: img.src, path: img.dataset.path || "" })}
              bodyRef={bodyRef}
            />

            {/* connected notes */}
            <section className="mt-10">
              <PanelTitle icon={BranchIcon} title="Connected notes" count={`${connCount} connection${connCount === 1 ? "" : "s"}`} />
              <BranchMap title={note.title} outs={outs} ins={ins} selected={branchSel} onSelect={setBranchSel} />
              <ConnectionRows note={note} outs={outs} ins={ins} branchSel={branchSel} onClear={() => setBranchSel(null)} onChanged={() => reload()} titles={titles} />
            </section>

            {/* references */}
            <ReferencesPanel note={note} onChanged={() => reload()} />

            {/* tags */}
            <TagsPanel note={note} onChanged={() => reload()} />

            {/* metadata */}
            <MetaPanel note={note} onChanged={() => reload()} />
          </div>

          {/* quick info rail */}
          <aside className="no-print">
            {note.quick_info_rows?.length > 0 && (
              <QuickInfoCard note={note} onChanged={() => reload()} onImage={(img) => setViewer({ src: img.src, path: img.dataset.path || "" })} />
            )}
          </aside>
        </div>

        {viewer && (
          <ImageViewer
            src={viewer.src}
            path={viewer.path}
            filename={viewer.path.split("/").pop() || "image"}
            notePath={note.path}
            onClose={() => setViewer(null)}
            onChanged={() => reload()}
          />
        )}
      </div>
    );
  }

  /* ============================== EDIT MODE ============================== */
  return (
    <EditView
      note={note}
      titles={titles}
      editorText={editorText}
      setEditorText={setEditorText}
      editorRef={editorRef}
      findOpen={findOpen}
      setFindOpen={setFindOpen}
      onCancel={() => { setDraft(null); setEditMode(false); reload(true); }}
      onPreview={() => {
        setDraft(editorText);
        setEditMode(false);
      }}
      onSaved={(hash) => {
        setDraft(null);
        setEditMode(false);
        reload();
      }}
    />
  );
}

/* ------------------------------------------------------------------ */

function PanelTitle({ icon: Icon, title, count }: { icon: any; title: string; count?: string }) {
  return (
    <div className="mb-2.5 flex items-center gap-2">
      <Icon className="h-4 w-4 text-muted-foreground" />
      <h2 className="text-sm font-semibold">{title}</h2>
      {count && <span className="text-xs text-muted-foreground">· {count}</span>}
    </div>
  );
}

function ConnectionRows({
  note, outs, ins, branchSel, onClear, onChanged, titles,
}: {
  note: NoteData;
  outs: string[];
  ins: string[];
  branchSel: Branch | null;
  onClear: () => void;
  onChanged: () => void;
  titles: Set<string>;
}) {
  const [input, setInput] = React.useState("");
  const inText = note.linked_in_text || [];
  const show = (kind: string, name: string) => !branchSel || (branchSel.kind === kind && branchSel.name === name);

  const connect = async (t: string) => {
    if (!t.trim()) return;
    try {
      await api.addConnection(note.path, [t.trim()]);
      toast.success(`Connected to ${t.trim()}.`);
      setInput("");
      onChanged();
    } catch (e: any) { toast.error(e.message); }
  };

  return (
    <div className="mt-3">
      <ul className="space-y-1">
        {outs.filter((t) => show("out", t)).map((t) => (
          <li key={t} className="group flex items-center gap-2 rounded-md px-2 py-1.5 text-sm hover:bg-accent/50">
            <Badge variant="outline" className="shrink-0 text-[10px]">links out</Badge>
            <Link to={`/note/${encodeURIComponent(t)}`} className="truncate hover:underline">{t}</Link>
            <button
              className="ml-auto rounded p-1 text-muted-foreground opacity-0 transition hover:text-destructive group-hover:opacity-100"
              title="Remove this connection"
              onClick={async () => {
                await api.removeConnection(note.path, [t]);
                toast.success("Connection removed.");
                onChanged();
              }}
            >
              <X className="h-3.5 w-3.5" />
            </button>
          </li>
        ))}
        {ins.filter((t) => show("in", t)).map((t) => (
          <li key={t} className="flex items-center gap-2 rounded-md px-2 py-1.5 text-sm hover:bg-accent/50">
            <Badge variant="outline" className="shrink-0 text-[10px]">links here</Badge>
            <Link to={`/note/${encodeURIComponent(t)}`} className="truncate hover:underline">{t}</Link>
          </li>
        ))}
        {!branchSel && inText.map((l) => (
          <li key={l.word} className="group flex items-center gap-2 rounded-md px-2 py-1.5 text-sm hover:bg-accent/50">
            <Badge variant="outline" className="shrink-0 text-[10px]">in text</Badge>
            <span className="truncate">
              “{l.word}” → <Link to={`/note/${encodeURIComponent(l.target)}`} className="hover:underline">{l.target}</Link>
            </span>
            <button
              className="ml-auto rounded p-1 text-muted-foreground opacity-0 transition hover:text-destructive group-hover:opacity-100"
              title="Unlink these words"
              onClick={async () => {
                await api.unlinkWord(note.path, l.word);
                toast.success("Link removed, the words stay.");
                onChanged();
              }}
            >
              <X className="h-3.5 w-3.5" />
            </button>
          </li>
        ))}
      </ul>
      {outs.length + ins.length + inText.length === 0 && (
        <p className="px-2 py-2 text-sm text-muted-foreground">No connections yet — add one below.</p>
      )}
      {branchSel && (
        <Button variant="ghost" size="sm" className="mt-1" onClick={onClear}>
          <BranchIcon /> Show all branches
        </Button>
      )}
      <div className="mt-3 flex gap-2">
        <Input
          value={input}
          list="all-notes"
          placeholder="Connect to an existing note…"
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && connect(input)}
        />
        <datalist id="all-notes">
          {Array.from(titles).sort().map((t) => <option key={t} value={t} />)}
        </datalist>
        <Button variant="outline" onClick={() => connect(input)}>Connect</Button>
      </div>
    </div>
  );
}

function ReferencesPanel({ note, onChanged }: { note: NoteData; onChanged: () => void }) {
  const [title, setTitle] = React.useState("");
  const [url, setUrl] = React.useState("");
  const refs = note.references || [];

  const add = async () => {
    const u = normalizeUrl(url);
    if (!/^https?:\/\//.test(u)) { toast.error("That does not look like a web address."); return; }
    await api.addReference(note.path, { title: title.trim() || prettyUrl(u), url: u });
    toast.success("Reference source added.");
    setTitle("");
    setUrl("");
    onChanged();
  };

  return (
    <section className="mt-10">
      <PanelTitle icon={Link2} title="Reference sources" count={String(refs.length)} />
      <ul className="space-y-1">
        {refs.map((r) => (
          <li key={r.url} className="group flex items-center gap-2 rounded-md px-2 py-1.5 text-sm hover:bg-accent/50">
            <a href={r.url} target="_blank" rel="noopener" className="truncate hover:underline">
              {r.title || prettyUrl(r.url)}
            </a>
            {r.accessed && <span className="shrink-0 text-xs text-muted-foreground">— accessed {r.accessed}</span>}
            <button
              className="ml-auto rounded p-1 text-muted-foreground opacity-0 transition hover:text-destructive group-hover:opacity-100"
              title="Remove"
              onClick={async () => {
                await api.removeReference(note.path, r.url);
                onChanged();
              }}
            >
              <X className="h-3.5 w-3.5" />
            </button>
          </li>
        ))}
      </ul>
      {!refs.length && <p className="px-2 py-1 text-sm text-muted-foreground">No reference sources yet.</p>}
      <div className="mt-3 grid gap-2 sm:grid-cols-[1fr_1fr_auto]">
        <Input value={title} placeholder="Title" onChange={(e) => setTitle(e.target.value)} />
        <Input value={url} placeholder="example.com  (https:// is added for you)" onChange={(e) => setUrl(e.target.value)} />
        <Button variant="outline" onClick={add}>Add</Button>
      </div>
    </section>
  );
}

function TagsPanel({ note, onChanged }: { note: NoteData; onChanged: () => void }) {
  const [draft, setDraft] = React.useState("");
  const add = async (name: string) => {
    name = (name || "").trim().replace(/\s+/g, "_").split(",")[0];
    if (!name) return;
    try {
      await api.editTags(note.path, [name]);
      toast.success(`Tag added: ${name} (the global tag list is in sync).`);
      setDraft("");
      onChanged();
    } catch (e: any) { toast.error(e.message); }
  };
  return (
    <section className="mt-10">
      <PanelTitle icon={Tag} title="Tags" count="independent, always in sync with the global list" />
      <div className="flex flex-wrap gap-1.5">
        {(note.tags || []).map((t) => (
          <TagBadge
            key={t}
            tag={t}
            onRemove={async () => {
              await api.editTags(note.path, undefined, [t]);
              toast.success(`Tag removed: ${t}`);
              onChanged();
            }}
          />
        ))}
        {!note.tags?.length && <p className="text-sm text-muted-foreground">No tags yet.</p>}
      </div>
      <div className="mt-3 flex max-w-md gap-2">
        <SuggestInput
          type="tag"
          value={draft}
          onChange={setDraft}
          onSubmit={(s) => add(s.name)}
          placeholder="Add a tag — existing ones appear as you type…"
        />
        <Button variant="outline" onClick={() => add(draft)}>Add</Button>
      </div>
    </section>
  );
}

function MetaPanel({ note, onChanged }: { note: NoteData; onChanged: () => void }) {
  const [formOpen, setFormOpen] = React.useState(false);
  const [rawOpen, setRawOpen] = React.useState(false);
  const m = note.meta || {};
  const row = (k: string) => (
    <div className="flex items-baseline gap-3 px-2 py-1.5 text-sm odd:bg-muted/30">
      <span className="w-20 shrink-0 capitalize text-muted-foreground">{k}</span>
      <span className="min-w-0 truncate">{m[k] || "—"}</span>
    </div>
  );
  return (
    <section className="mt-10">
      <PanelTitle icon={Settings2} title="Metadata" />
      <div className="max-w-xl rounded-lg border">
        {row("created")}
        {row("updated")}
        {row("pinned")}
      </div>
      <div className="mt-3 flex gap-2">
        <Button variant="outline" size="sm" onClick={() => setFormOpen(true)}>Edit as form</Button>
        <Button variant="outline" size="sm" onClick={() => setRawOpen(true)}>Edit raw block</Button>
      </div>

      <MetaFormDialog open={formOpen} onOpenChange={setFormOpen} note={note} onChanged={onChanged} />
      <MetaRawDialog open={rawOpen} onOpenChange={setRawOpen} note={note} onChanged={onChanged} />
    </section>
  );
}

function MetaFormDialog({ open, onOpenChange, note, onChanged }: any) {
  const [created, setCreated] = React.useState("");
  const [updated, setUpdated] = React.useState("");
  const [pinned, setPinned] = React.useState("");
  React.useEffect(() => {
    if (open) {
      setCreated(note.meta?.created || "");
      setUpdated(note.meta?.updated || "");
      setPinned(note.meta?.pinned || "");
    }
  }, [open]);
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-sm">
        <DialogHeader><DialogTitle>Edit metadata</DialogTitle></DialogHeader>
        <div className="space-y-3">
          <Field label="Created" value={created} onChange={setCreated} />
          <Field label="Updated" value={updated} onChange={setUpdated} />
          <Field label="Pinned" value={pinned} onChange={setPinned} />
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
          <Button
            onClick={async () => {
              await api.setMetadata(note.path, { created, updated, pinned });
              toast.success("Metadata saved.");
              onOpenChange(false);
              onChanged();
            }}
          >
            Save
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function MetaRawDialog({ open, onOpenChange, note, onChanged }: any) {
  const [text, setText] = React.useState("");
  React.useEffect(() => {
    if (open) {
      const m = note.meta || {};
      setText(Object.keys(m).map((k) => k.charAt(0).toUpperCase() + k.slice(1) + ": " + m[k]).join("\n"));
    }
  }, [open]);
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader><DialogTitle>Metadata block (raw)</DialogTitle></DialogHeader>
        <Textarea value={text} rows={6} onChange={(e) => setText(e.target.value)} className="font-mono text-xs" />
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
          <Button
            onClick={async () => {
              const meta: Record<string, string> = {};
              text.split("\n").forEach((ln) => {
                const mm = ln.match(/^([A-Za-z][A-Za-z0-9 _-]*):\s*(.*)$/);
                if (mm) meta[mm[1].toLowerCase()] = mm[2];
              });
              delete meta.status; // verification removed in v1.1
              await api.setMetadata(note.path, meta);
              toast.success("Metadata saved.");
              onOpenChange(false);
              onChanged();
            }}
          >
            Save
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function Field({ label, value, onChange }: { label: string; value: string; onChange: (v: string) => void }) {
  return (
    <div className="space-y-1.5">
      <label className="text-sm font-medium">{label}</label>
      <Input value={value} onChange={(e) => onChange(e.target.value)} />
    </div>
  );
}

function QuickInfoCard({ note, onChanged, onImage }: { note: NoteData; onChanged: () => void; onImage: (img: HTMLImageElement) => void }) {
  const [open, setOpen] = React.useState(false);
  const [text, setText] = React.useState("");
  const rows = note.quick_info_rows || [];
  return (
    <Card className="sticky top-20">
      <CardHeader className="pb-2">
        <CardTitle className="flex items-center justify-between text-sm">
          <span className="flex items-center gap-2"><FileText className="h-4 w-4 text-muted-foreground" /> Quick info</span>
          <Button
            variant="ghost"
            size="iconSm"
            title="Edit card"
            onClick={() => {
              setText(note.quick_info_raw === "raw" ? "" : note.quick_info_raw || "");
              setOpen(true);
            }}
          >
            <Pencil />
          </Button>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-2 pt-0">
        {rows.map((r, i) => {
          const prev = i > 0 ? rows[i - 1] : null;
          const showGroup = r.group && (!prev || prev.group !== r.group);
          return (
            <React.Fragment key={i}>
              {showGroup && (
                <div className="pt-1 text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">{r.group}</div>
              )}
              {r.label.toLowerCase() === "image" ? (
                <img
                  src={mdSrc(note.path, r.value)}
                  className="w-full cursor-zoom-in rounded-lg border"
                  loading="lazy"
                  data-path={r.value}
                  onClick={(e) => onImage(e.currentTarget)}
                />
              ) : (
                <div className="flex items-baseline justify-between gap-2 text-sm">
                  <span className="shrink-0 text-muted-foreground">{r.label}</span>
                  <span className="min-w-0 text-right" dangerouslySetInnerHTML={{ __html: inlineLite(r.value, note.path) }} />
                </div>
              )}
            </React.Fragment>
          );
        })}
      </CardContent>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Edit quick info card</DialogTitle>
            <DialogDescription>
              One line per fact, <b>Label: value</b>. A line starting with <b>##</b> begins a named group.
            </DialogDescription>
          </DialogHeader>
          <Textarea value={text} rows={10} onChange={(e) => setText(e.target.value)} className="font-mono text-xs" />
          <DialogFooter>
            <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
            <Button
              onClick={async () => {
                try {
                  await api.setQuickInfo(note.path, text);
                  toast.success("Quick info saved.");
                  setOpen(false);
                  onChanged();
                } catch (e: any) { toast.error(e.message); }
              }}
            >
              Save card
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </Card>
  );
}

function mdSrc(path: string, p: string): string {
  if (/^https?:/.test(p)) return p;
  const np = p.replace(/^\.?\//, "");
  if (np.startsWith("attachments/")) return "/files/" + path.split("/").slice(0, -1).join("/") + "/" + np;
  return "/files/database/" + np;
}

function inlineLite(v: string, path: string): string {
  let s = esc(v);
  s = s.replace(/\[\[([^\]|]+)\|([^\]]+)\]\]/g, (_, t, w) =>
    `<a href="#/note/${encodeURIComponent(t.trim())}">${w}</a>`);
  s = s.replace(/\[\[([^\]]+)\]\]/g, (_, t) =>
    `<a href="#/note/${encodeURIComponent(t.trim())}">${t}</a>`);
  s = s.replace(/https?:\/\/[^\s<>"']+/g, (u) => `<a href="${u}" target="_blank" rel="noopener">${prettyUrl(u)}</a>`);
  return s;
}

/* ============================== EDIT MODE ============================== */

function stripBlocks(text: string) {
  let body = text.replace(/^# .*\n/, "");
  const qiM = body.match(/:::quick-info\n([\s\S]*?)\n:::/);
  if (qiM) body = body.replace(qiM[0], "");
  const metaM = body.match(/:::meta\n([\s\S]*?)\n:::/);
  if (metaM) body = body.replace(metaM[0], "");
  return { body: body.trim() };
}

function EditView({
  note, titles, editorText, setEditorText, editorRef, findOpen, setFindOpen,
  onCancel, onPreview, onSaved,
}: {
  note: NoteData;
  titles: Set<string>;
  editorText: string;
  setEditorText: (t: string) => void;
  editorRef: React.RefObject<HTMLTextAreaElement | null>;
  findOpen: boolean;
  setFindOpen: (v: boolean) => void;
  onCancel: () => void;
  onPreview: () => void;
  onSaved: (hash: string) => void;
}) {
  const [conflict, setConflict] = React.useState<{ message: string; current_hash: string } | null>(null);
  const [saveState, setSaveState] = React.useState("");

  const smartWrap = (before: string, after: string) => {
    const ed = editorRef.current;
    if (!ed) return;
    let s = ed.selectionStart, e = ed.selectionEnd;
    if (s === e) {
      const val = ed.value;
      const isWord = (ch: string) => /[\w'’-]/.test(ch);
      while (s > 0 && isWord(val[s - 1])) s--;
      while (e < val.length && isWord(val[e])) e++;
      if (s === e) {
        // insert empty pair, cursor in the middle
        const nv = val.slice(0, s) + before + after + val.slice(e);
        setEditorText(nv);
        requestAnimationFrame(() => { ed.setSelectionRange(s + before.length, s + before.length); ed.focus(); });
        return;
      }
    }
    const val = ed.value;
    const word = val.slice(s, e);
    const already = val.slice(s - before.length, s) === before && val.slice(e, e + after.length) === after;
    if (already) {
      const nv = val.slice(0, s - before.length) + word + val.slice(e + after.length);
      setEditorText(nv);
      const pos = s - before.length + word.length;
      requestAnimationFrame(() => { ed.setSelectionRange(pos, pos); ed.focus(); });
    } else {
      const nv = val.slice(0, s) + before + word + after + val.slice(e);
      setEditorText(nv);
      const pos = s + before.length + word.length;
      requestAnimationFrame(() => { ed.setSelectionRange(pos, pos); ed.focus(); });
    }
  };

  const smartPrefix = (prefix: string) => {
    const ed = editorRef.current;
    if (!ed) return;
    const val = ed.value;
    let s = val.lastIndexOf("\n", ed.selectionStart - 1) + 1;
    let e = val.indexOf("\n", ed.selectionEnd);
    if (e < 0) e = val.length;
    const line = val.slice(s, e);
    let newLine: string;
    if (line.startsWith(prefix)) {
      newLine = line.slice(prefix.length);
    } else {
      newLine = prefix + line;
    }
    const nv = val.slice(0, s) + newLine + val.slice(e);
    setEditorText(nv);
    const pos = s + (newLine.startsWith(prefix) ? prefix.length : 0);
    requestAnimationFrame(() => { ed.setSelectionRange(pos, pos); ed.focus(); });
  };

  const insertAt = (text: string) => {
    const ed = editorRef.current;
    if (!ed) return;
    const s = ed.selectionStart;
    const nv = ed.value.slice(0, s) + text + ed.value.slice(ed.selectionEnd);
    setEditorText(nv);
    requestAnimationFrame(() => { ed.setSelectionRange(s + text.length, s + text.length); ed.focus(); });
  };

  const save = async (force = false) => {
    setSaveState("Saving…");
    try {
      const out = await api.saveNote(note.path, editorText, note.hash, force);
      if (out.conflict) {
        setConflict({ message: out.message || "The file changed while it was open.", current_hash: out.current_hash || "" });
        setSaveState("");
        return;
      }
      setSaveState("Saved " + new Date().toLocaleTimeString());
      toast.success("Saved. One log file recorded the change.");
      onSaved(out.hash);
    } catch (e: any) {
      setSaveState("");
      toast.error(e.message);
    }
  };

  const TOOLS: { name: string; icon: any; run: () => void; sep?: boolean }[][] = [
    [
      { name: "Bold", icon: Bold, run: () => smartWrap("**", "**") },
      { name: "Italic", icon: Italic, run: () => smartWrap("*", "*") },
      { name: "Code", icon: Code, run: () => smartWrap("`", "`") },
      { name: "Math", icon: SquareRadical, run: () => smartWrap("$$", "$$") },
    ],
    [
      { name: "Heading", icon: Heading2, run: () => smartPrefix("## ") },
      { name: "List", icon: List, run: () => smartPrefix("- ") },
      { name: "Task", icon: ListTodo, run: () => smartPrefix("- [ ] ") },
      { name: "Quote", icon: TextQuote, run: () => smartPrefix("> ") },
    ],
    [
      { name: "Footnote", icon: Superscript, run: () => insertAt("[^1]") },
      { name: "Line", icon: Minus, run: () => insertAt("\n---\n") },
    ],
    [
      { name: "Table", icon: Table, run: () => setTableOpen(true) },
      { name: "Link", icon: Link2, run: () => setLinkOpen(true) },
      { name: "Find", icon: Search, run: () => setFindOpen(true) },
    ],
  ];

  const [tableOpen, setTableOpen] = React.useState(false);
  const [linkOpen, setLinkOpen] = React.useState(false);

  return (
    <div className="mx-auto w-full max-w-4xl px-4 py-6 sm:px-6">
      {findOpen && <FindBar containerRef={{ current: null }} editorRef={editorRef} onClose={() => setFindOpen(false)} />}

      <div className="mb-3 flex items-center gap-3">
        <h1 className="min-w-0 truncate text-xl font-semibold tracking-tight">{note.title}</h1>
        <span className="ml-auto shrink-0 text-xs text-muted-foreground">{saveState}</span>
      </div>

      <div className="mb-3 flex flex-wrap items-center gap-2 no-print">
        <Button size="sm" onClick={() => save()}><Save /> Save</Button>
        <Button size="sm" variant="outline" onClick={onPreview}><Eye /> Preview</Button>
        <Button size="sm" variant="ghost" onClick={onCancel}>Cancel</Button>
        <div className="flex-1" />
        <ImageUpload notePath={note.path} onInsert={(md) => insertAt(md)} />
      </div>

      {/* toolbar */}
      <div className="sticky top-[4.25rem] z-20 mb-2 flex flex-wrap items-center gap-1 rounded-lg border bg-background/95 p-1 backdrop-blur no-print">
        {TOOLS.map((group, gi) => (
          <React.Fragment key={gi}>
            {gi > 0 && <Separator orientation="vertical" className="mx-1 h-6" />}
            {group.map((t) => (
              <Tooltip key={t.name}>
                <TooltipTrigger asChild>
                  <Button variant="ghost" size="iconSm" onClick={t.run} aria-label={t.name}>
                    <t.icon className="h-4 w-4" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>{t.name}</TooltipContent>
              </Tooltip>
            ))}
          </React.Fragment>
        ))}
      </div>

      <Textarea
        ref={editorRef as any}
        value={editorText}
        onChange={(e) => setEditorText(e.target.value)}
        spellCheck={false}
        className="min-h-[55vh] w-full resize-y rounded-xl border bg-background p-5 font-mono text-[13.5px] leading-relaxed shadow-inner focus-visible:ring-0"
        onKeyDown={(e) => {
          if ((e.ctrlKey || e.metaKey) && e.key === "s") { e.preventDefault(); save(); }
          if (e.key === "Tab") { e.preventDefault(); insertAt("  "); }
        }}
      />
      <p className="mt-2 text-xs text-muted-foreground no-print">
        Select a word and tap any tool to format it — tap the same tool again to undo. The cursor lands
        exactly where you keep typing. Shortcuts: <b>Ctrl/Cmd+S</b> save, <b>Ctrl/Cmd+F</b> find.
      </p>

      <TableEditorDialog
        open={tableOpen}
        onOpenChange={setTableOpen}
        getEditor={() => editorRef.current}
        editorText={editorText}
        setEditorText={setEditorText}
      />
      <LinkDialog
        open={linkOpen}
        onOpenChange={setLinkOpen}
        titles={titles}
        editorRef={editorRef}
        editorText={editorText}
        setEditorText={setEditorText}
      />

      <AlertDialog open={!!conflict} onOpenChange={(v) => !v && setConflict(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>The file changed while it was open</AlertDialogTitle>
            <AlertDialogDescription>{conflict?.message}</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => {
                window.location.reload();
              }}
            >
              Reload my editor with the new file
            </AlertDialogAction>
            <AlertDialogAction
              onClick={async () => {
                if (!conflict) return;
                await api.saveNote(note.path, editorText, conflict.current_hash, true);
                toast.success("Overwritten. The previous text is in the log.");
                setConflict(null);
                onSaved("");
              }}
            >
              Overwrite with my version
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

function ImageUpload({ notePath, onInsert }: { notePath: string; onInsert: (md: string) => void }) {
  const inpRef = React.useRef<HTMLInputElement>(null);
  return (
    <>
      <input
        ref={inpRef}
        type="file"
        accept="image/*"
        className="hidden"
        onChange={async (e) => {
          const f = e.target.files?.[0];
          if (!f) return;
          const b64 = await new Promise<string>((res) => {
            const r = new FileReader();
            r.onload = () => res((r.result as string).split(",")[1]);
            r.readAsDataURL(f);
          });
          try {
            const out = await api.imageAdd(notePath, f.name, b64);
            onInsert("\n![" + f.name.replace(/\.[a-z]+$/i, "") + "](" + out.file + ")\n");
            toast.success("Image added to attachments/ and placed in the note.");
          } catch (err: any) { toast.error(err.message); }
        }}
      />
      <Button size="sm" variant="outline" onClick={() => inpRef.current?.click()}>
        <ImagePlus /> Image
      </Button>
    </>
  );
}

/* ---------------- table editor ---------------- */

function parseTableAt(val: string, selStart: number, selEnd: number) {
  const lineStart = val.lastIndexOf("\n", selStart - 1) + 1;
  let a = lineStart;
  while (a > 0) {
    const prev = val.lastIndexOf("\n", a - 2) + 1;
    if (val.slice(prev, a).trim().startsWith("|")) a = prev;
    else break;
  }
  let b = val.indexOf("\n", selEnd);
  if (b < 0) b = val.length;
  while (true) {
    const nb = val.indexOf("\n", b + 1);
    const next = val.slice(b + 1, nb < 0 ? val.length : nb);
    if (next.trim().startsWith("|") && nb >= 0) b = nb;
    else break;
  }
  const block = val.slice(a, b);
  const lines = block.split("\n").filter((l) => l.trim().startsWith("|"));
  if (!lines.length || !lines.some((l) => l.includes("-") && l.includes("|"))) return null;
  const split = (l: string) =>
    l.trim().replace(/^\|/, "").replace(/\|$/, "").split("|").map((c) => c.trim());
  return { start: a, end: b, header: split(lines[0]), rows: lines.slice(2).map(split) };
}

function gridToMarkdown(header: string[], rows: string[][]) {
  const clean = (s: string) => (s || "").replace(/\|/g, "\\|").replace(/\n/g, " ");
  const w = header.length;
  const pad = (arr: string[]) => {
    const a = arr.slice(0, w);
    while (a.length < w) a.push("");
    return a;
  };
  const out = [
    "| " + pad(header).map(clean).join(" | ") + " |",
    "| " + header.map(() => "---").join(" | ") + " |",
  ];
  rows.forEach((r) => out.push("| " + pad(r).map(clean).join(" | ") + " |"));
  return out.join("\n");
}

function TableEditorDialog({
  open, onOpenChange, getEditor, editorText, setEditorText,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  getEditor: () => HTMLTextAreaElement | null;
  editorText: string;
  setEditorText: (t: string) => void;
}) {
  const existing = React.useMemo(
    () => (open && getEditor() ? parseTableAt(editorText, getEditor()!.selectionStart, getEditor()!.selectionEnd) : null),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [open],
  );
  const [header, setHeader] = React.useState<string[]>([]);
  const [rows, setRows] = React.useState<string[][]>([]);

  React.useEffect(() => {
    if (open) {
      setHeader(existing ? existing.header.slice() : ["Column A", "Column B"]);
      setRows(existing ? existing.rows.map((r) => r.slice()) : [["", ""], ["", ""]]);
    }
  }, [open]);

  const update = (fn: () => void) => { fn(); };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-3xl">
        <DialogHeader>
          <DialogTitle>{existing ? "Edit this table" : "Insert a table"}</DialogTitle>
          <DialogDescription>Click a cell to type. Rows and columns can be added or removed below.</DialogDescription>
        </DialogHeader>
        <div className="max-h-[50vh] overflow-auto rounded-lg border">
          <table className="w-full border-collapse text-sm">
            <thead>
              <tr>
                {header.map((h, ci) => (
                  <th key={ci} className="border-b p-0">
                    <input
                      value={h}
                      onChange={(e) => setHeader(header.map((x, i) => (i === ci ? e.target.value : x)))}
                      className="w-full bg-muted/50 px-3 py-2 font-semibold outline-none focus:bg-muted"
                      placeholder="Header"
                    />
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {rows.map((r, ri) => (
                <tr key={ri}>
                  {header.map((_, ci) => (
                    <td key={ci} className="border-b p-0">
                      <input
                        value={r[ci] || ""}
                        onChange={(e) => setRows(rows.map((row, i) =>
                          i === ri ? row.map((x, j) => (j === ci ? e.target.value : x)) : row))}
                        className="w-full px-3 py-1.5 outline-none focus:bg-muted/50"
                      />
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <div className="flex flex-wrap gap-2">
          <Button variant="outline" size="sm" onClick={() => update(() => { setHeader([...header, "New column"]); setRows(rows.map((r) => [...r, ""])); })}>
            <Plus /> Column
          </Button>
          <Button variant="outline" size="sm" onClick={() => { if (header.length > 1) { setHeader(header.slice(0, -1)); setRows(rows.map((r) => r.slice(0, -1))); } }}>
            − Column
          </Button>
          <Button variant="outline" size="sm" onClick={() => update(() => setRows([...rows, header.map(() => "")]))}>
            <Plus /> Row
          </Button>
          <Button variant="outline" size="sm" onClick={() => { if (rows.length > 1) setRows(rows.slice(0, -1)); }}>
            − Row
          </Button>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
          <Button
            onClick={() => {
              const ed = getEditor();
              if (!ed) return;
              const md = gridToMarkdown(header, rows);
              if (existing) {
                const nv = editorText.slice(0, existing.start) + md + editorText.slice(existing.end);
                setEditorText(nv);
              } else {
                const s = ed.selectionStart;
                const prefix = s > 0 && editorText[s - 1] !== "\n" ? "\n" : "";
                const nv = editorText.slice(0, s) + prefix + md + "\n" + editorText.slice(ed.selectionEnd);
                setEditorText(nv);
              }
              onOpenChange(false);
              toast.success(existing ? "Table updated." : "Table inserted.");
            }}
          >
            {existing ? "Update table" : "Insert table"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

/* ---------------- link dialog ---------------- */

function LinkDialog({
  open, onOpenChange, titles, editorRef, editorText, setEditorText,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  titles: Set<string>;
  editorRef: React.RefObject<HTMLTextAreaElement | null>;
  editorText: string;
  setEditorText: (t: string) => void;
}) {
  const ed = editorRef.current;
  const [word, setWord] = React.useState("");
  const [target, setTarget] = React.useState("");
  const [url, setUrl] = React.useState("");

  React.useEffect(() => {
    if (!open || !ed) return;
    let s = ed.selectionStart, e = ed.selectionEnd;
    if (s === e) {
      const val = ed.value;
      const isWord = (ch: string) => /[\w'’-]/.test(ch);
      while (s > 0 && isWord(val[s - 1])) s--;
      while (e < val.length && isWord(val[e])) e++;
    }
    setWord(s !== e ? ed.value.slice(s, e) : "");
    setTarget("");
    setUrl("");
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open]);

  const place = (mk: (w: string) => string, w: string) => {
    const ed2 = editorRef.current;
    if (!ed2) return;
    const s = ed2.selectionStart, e = ed2.selectionEnd;
    const nv = editorText.slice(0, s) + mk(w) + editorText.slice(e);
    setEditorText(nv);
    requestAnimationFrame(() => ed2.focus());
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Link the selected word</DialogTitle>
          <DialogDescription>
            Pick a note to connect to, or type a web address — <b>https:// is added automatically</b> (just write example.com).
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-3">
          <Field label="Link text" value={word} onChange={setWord} />
          <div className="space-y-1.5">
            <label className="text-sm font-medium">Connect to a note</label>
            <Input
              value={target}
              list="wl-notes"
              placeholder="start typing a note name…"
              onChange={(e) => setTarget(e.target.value)}
            />
            <datalist id="wl-notes">
              {Array.from(titles).sort().map((t) => <option key={t} value={t} />)}
            </datalist>
          </div>
          <Field label="— or — a website" value={url} onChange={setUrl} />
        </div>
        <DialogFooter className="flex-col gap-2 sm:flex-row">
          <Button
            variant="outline"
            onClick={() => {
              if (!target.trim()) { toast.error("Choose a note to link to."); return; }
              if (!titles.has(target.trim())) { toast.error("No such note in this wiki."); return; }
              place((w) => `[[${target.trim()}|${w || target.trim()}]]`, word);
            }}
          >
            Link to note
          </Button>
          <Button
            onClick={() => {
              const u = normalizeUrl(url);
              if (!/^https?:\/\//.test(u)) { toast.error("That is not a web address."); return; }
              place((w) => `[${w || "link"}](${u})`, word);
            }}
          >
            Link to website
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
