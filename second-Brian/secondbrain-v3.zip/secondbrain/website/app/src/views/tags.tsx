import * as React from "react";
import { Link } from "react-router-dom";
import { toast } from "sonner";
import {
  GitMerge, Pencil, Plus, Search, Tag as TagIcon, Trash2,
} from "lucide-react";

import { api } from "@/lib/api";
import type { TagsData, TagPreviewResult } from "@/lib/types";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import {
  Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle,
} from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { TagBadge } from "@/components/shared/tag-badge";
import { SuggestInput } from "@/components/shared/suggest-input";

export default function TagsView() {
  const [data, setData] = React.useState<TagsData | null>(null);
  const [filter, setFilter] = React.useState("");
  const [dlg, setDlg] = React.useState<null | { kind: "add" | "rename" | "merge" | "remove"; pre?: string }>(null);
  const [masterOpen, setMasterOpen] = React.useState(false);

  const load = React.useCallback(() => {
    api.tags().then(setData).catch((e) => toast.error(e.message));
  }, []);
  React.useEffect(load, [load]);

  const rows = (data?.rows || []).filter((r) =>
    !filter || r.tag.toLowerCase().includes(filter.toLowerCase()));

  return (
    <div className="mx-auto w-full max-w-5xl px-4 py-6 sm:px-6">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h1 className="flex items-center gap-2 text-2xl font-semibold tracking-tight">
            <TagIcon className="h-5 w-5 text-muted-foreground" /> Tags
          </h1>
          <p className="mt-1 max-w-2xl text-sm text-muted-foreground">
            Every tag is independent — there are no sub-tags and nothing is implied. Tags used on notes
            always appear here and in the master list; they can never fall out of sync.
          </p>
        </div>
        <div className="relative w-full sm:w-64">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input value={filter} onChange={(e) => setFilter(e.target.value)} placeholder="Filter tags…" className="pl-8" />
        </div>
      </div>

      <div className="mt-4 flex flex-wrap gap-2">
        <Button onClick={() => setDlg({ kind: "add" })}><Plus /> Add tag</Button>
        <Button variant="outline" onClick={() => setDlg({ kind: "rename" })}><Pencil /> Rename tag</Button>
        <Button variant="outline" onClick={() => setDlg({ kind: "merge" })}><GitMerge /> Merge tags</Button>
        <Button variant="outline" onClick={() => setDlg({ kind: "remove" })}><Trash2 /> Remove tag</Button>
        <Button variant="outline" onClick={() => setMasterOpen(true)}>Edit master list raw</Button>
      </div>

      {!data ? (
        <div className="mt-6 space-y-2">
          {Array.from({ length: 5 }).map((_, i) => <Skeleton key={i} className="h-12 rounded-lg" />)}
        </div>
      ) : (
        <>
          <Card className="mt-5 overflow-hidden p-0">
            <div className="grid grid-cols-[1fr_72px_auto] gap-2 border-b bg-muted/50 px-4 py-2.5 text-xs font-semibold uppercase tracking-wide text-muted-foreground">
              <span>Tag</span>
              <span className="text-right">Notes</span>
              <span className="w-56">Actions</span>
            </div>
            <div>
              {rows.map((r) => (
                <div
                  key={r.tag}
                  className="group grid grid-cols-[1fr_72px_auto] items-center gap-2 border-b px-4 py-2.5 last:border-0 hover:bg-accent/40"
                >
                  <span className="flex min-w-0 flex-wrap items-center gap-2">
                    <TagBadge tag={r.tag} count={r.count} />
                    {!data.approved.includes(r.tag) && (
                      <Badge variant="outline" className="text-[10px]">not in master list</Badge>
                    )}
                  </span>
                  <span className="text-right text-sm tabular-nums text-muted-foreground">{r.count}</span>
                  <span className="flex w-56 justify-end gap-1 opacity-80 transition-opacity group-hover:opacity-100">
                    <Button variant="ghost" size="sm" className="h-7 px-2 text-xs" onClick={() => tagNotes(r.tag)}>notes</Button>
                    <Button variant="ghost" size="sm" className="h-7 px-2 text-xs" onClick={() => setDlg({ kind: "rename", pre: r.tag })}>rename</Button>
                    <Button variant="ghost" size="sm" className="h-7 px-2 text-xs text-destructive hover:text-destructive" onClick={() => setDlg({ kind: "remove", pre: r.tag })}>
                      remove everywhere
                    </Button>
                  </span>
                </div>
              ))}
              {!rows.length && (
                <div className="px-4 py-8 text-center text-sm text-muted-foreground">
                  {filter ? "No tags match the filter." : "No tags yet — add them on a note."}
                </div>
              )}
            </div>
          </Card>

          {data.proposed.length > 0 && (
            <Alert className="mt-4">
              <TagIcon />
              <AlertTitle>Proposed by the AI (not yet approved)</AlertTitle>
              <AlertDescription className="flex flex-wrap items-center gap-2 pt-1">
                {data.proposed.map((t) => (
                  <span key={t} className="inline-flex items-center gap-1">
                    <TagBadge tag={t} />
                    <Button
                      size="sm"
                      variant="outline"
                      className="h-6 px-2 text-xs"
                      onClick={async () => { await api.tagApprove([t]); toast.success("Added to the master list."); load(); }}
                    >
                      approve
                    </Button>
                  </span>
                ))}
              </AlertDescription>
            </Alert>
          )}

          {data.unapproved.length > 0 && (
            <Alert className="mt-3">
              <TagIcon />
              <AlertTitle>In use but not in the master list</AlertTitle>
              <AlertDescription className="flex flex-wrap items-center gap-2 pt-1">
                {data.unapproved.map((t) => (
                  <span key={t} className="inline-flex items-center gap-1">
                    <TagBadge tag={t} />
                    <Button
                      size="sm"
                      variant="outline"
                      className="h-6 px-2 text-xs"
                      onClick={async () => { await api.tagApprove([t]); toast.success("Added to the master list."); load(); }}
                    >
                      add to master
                    </Button>
                  </span>
                ))}
              </AlertDescription>
            </Alert>
          )}

          {data.near_duplicates.length > 0 && (
            <Alert className="mt-3">
              <TagIcon />
              <AlertTitle>Possible near-duplicates</AlertTitle>
              <AlertDescription className="flex flex-wrap items-center gap-2 pt-1">
                {data.near_duplicates.map((n, i) => (
                  <span key={i} className="inline-flex items-center gap-1 text-sm">
                    {n.tags.join(" ↔ ")}
                    <Button
                      size="sm"
                      variant="outline"
                      className="h-6 px-2 text-xs"
                      onClick={() => setDlg({ kind: "merge", pre: n.tags[0] })}
                    >
                      merge
                    </Button>
                  </span>
                ))}
              </AlertDescription>
            </Alert>
          )}
        </>
      )}

      {dlg && (
        <TagDialog
          kind={dlg.kind}
          pre={dlg.pre || ""}
          onClose={() => setDlg(null)}
          onDone={load}
        />
      )}
      {data && <MasterEditor open={masterOpen} onOpenChange={setMasterOpen} onDone={load} />}
    </div>
  );
}

async function tagNotes(tag: string) {
  const res = await api.tagNotes(tag);
  // simple info toast listing the notes (the full manager is on each note page)
  if (!res.notes.length) {
    toast.info(`No notes carry “${tag}”.`);
    return;
  }
  const names = res.notes.map((n) => n.title).slice(0, 8).join(", ");
  toast.info(`${res.notes.length} note(s) tagged “${tag}”: ${names}${res.notes.length > 8 ? "…" : ""}`, {
    description: "Open a note to manage its tags, or use Rename / Remove here for every note at once.",
    duration: 8000,
  });
}

function TagDialog({ kind, pre, onClose, onDone }: { kind: "add" | "rename" | "merge" | "remove"; pre: string; onClose: () => void; onDone: () => void }) {
  const [from, setFrom] = React.useState(pre);
  const [to, setTo] = React.useState("");
  const [preview, setPreview] = React.useState<TagPreviewResult | null>(null);
  const [mode, setMode] = React.useState(kind);
  const [busy, setBusy] = React.useState(false);

  const titles = {
    add: "Add a tag",
    rename: "Rename a tag",
    merge: "Merge tags",
    remove: "Remove a tag everywhere",
  };

  const doPreview = async () => {
    setBusy(true);
    try {
      let res: TagPreviewResult;
      if (mode === "rename") res = await api.tagRename(from.trim(), to.trim());
      else if (mode === "merge") res = await api.tagMerge(from.trim(), to.trim());
      else if (mode === "remove") res = await api.tagRemove(from.trim());
      else res = { from, notes: [] } as any;
      setPreview(res);
    } catch (e: any) {
      toast.error(e.message);
    }
    setBusy(false);
  };

  const doRun = async () => {
    setBusy(true);
    try {
      if (mode === "rename") await api.tagRename(from.trim(), to.trim(), true);
      else if (mode === "merge") await api.tagMerge(from.trim(), to.trim(), true);
      else if (mode === "remove") await api.tagRemove(from.trim(), true);
      else await api.tagApprove([from.trim()]);
      toast.success("Done. Every change is logged and can be undone.");
      setPreview(null);
      onClose();
      onDone();
    } catch (e: any) {
      toast.error(e.message);
    }
    setBusy(false);
  };

  return (
    <>
      <Dialog open onOpenChange={(v) => !v && onClose()}>
        <DialogContent className="sm:max-w-sm">
          <DialogHeader>
            <DialogTitle>{titles[mode]}</DialogTitle>
            <DialogDescription>
              {mode === "add" && "Adds the tag to the master list so it is offered everywhere."}
              {mode === "rename" && "Preview first — nothing changes until you apply it to every note listed."}
              {mode === "merge" && "Preview first — nothing changes until you apply it to every note listed."}
              {mode === "remove" && "Preview first — nothing changes until you apply it to every note listed."}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-3">
            <div className="space-y-1.5">
              <label className="text-sm font-medium">{mode === "merge" ? "Tag to merge" : "Tag"}</label>
              <SuggestInput type="tag" value={from} onChange={setFrom} placeholder="e.g. FOOD-pasta" />
            </div>
            {mode === "rename" && (
              <div className="space-y-1.5">
                <label className="text-sm font-medium">New name</label>
                <Input value={to} onChange={(e) => setTo(e.target.value)} placeholder="FOOD-noodles" />
              </div>
            )}
            {mode === "merge" && (
              <div className="space-y-1.5">
                <label className="text-sm font-medium">Merge into (existing tag)</label>
                <SuggestInput type="tag" value={to} onChange={setTo} placeholder="FOOD-bread" />
              </div>
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={onClose}>Cancel</Button>
            {mode === "add" ? (
              <Button disabled={!from.trim() || busy} onClick={doRun}>Add to master list</Button>
            ) : (
              <Button
                variant={mode === "remove" ? "destructive" : "default"}
                disabled={!from.trim() || (mode !== "remove" && !to.trim()) || busy}
                onClick={doPreview}
              >
                Preview {mode === "rename" ? "rename" : mode === "merge" ? "merge" : "removal"}
              </Button>
            )}
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {preview && (
        <PreviewDialog
          title={
            (mode === "merge" ? `Merge ${preview.from} into ${preview.into}` :
             mode === "remove" ? `Remove ${preview.tag || preview.from}` :
             `Rename ${preview.from} → ${preview.to}`)
          }
          preview={preview}
          onCancel={() => setPreview(null)}
          onApply={doRun}
          busy={busy}
        />
      )}
    </>
  );
}

function PreviewDialog({ title, preview, onCancel, onApply, busy }: {
  title: string;
  preview: TagPreviewResult;
  onCancel: () => void;
  onApply: () => void;
  busy: boolean;
}) {
  return (
    <Dialog open onOpenChange={(v) => !v && onCancel()}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle>Confirm: {title}</DialogTitle>
          <DialogDescription>
            {(preview.notes || []).length} note(s) will change. The master list is updated in the same change.
            Every change is logged and can be undone.
          </DialogDescription>
        </DialogHeader>
        <div className="max-h-64 overflow-auto rounded-lg border p-3 text-sm">
          {(preview.notes || []).map((n, i) => (
            <div key={i} className="border-b py-2 last:border-0">
              <b>{n.file}</b>
              <div className="mt-0.5 text-muted-foreground">
                {n.old.join(", ")} <span className="text-foreground">→</span> {n.new.join(", ")}
              </div>
            </div>
          ))}
          {!(preview.notes || []).length && <p className="text-muted-foreground">No notes affected.</p>}
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onCancel}>Cancel</Button>
          <Button onClick={onApply} disabled={busy}>Apply to every note listed</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function MasterEditor({ open, onOpenChange, onDone }: { open: boolean; onOpenChange: (v: boolean) => void; onDone: () => void }) {
  const [text, setText] = React.useState("");
  React.useEffect(() => {
    if (open) api.masterTags().then((m) => setText(m.text)).catch((e) => toast.error(e.message));
  }, [open]);
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>Edit _tags.md (master tag list)</DialogTitle>
          <DialogDescription>The global list every note syncs with.</DialogDescription>
        </DialogHeader>
        <Textarea value={text} rows={16} onChange={(e) => setText(e.target.value)} className="font-mono text-xs" />
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
          <Button
            onClick={async () => {
              await api.tagMasterSave(text);
              toast.success("_tags.md saved.");
              onOpenChange(false);
              onDone();
            }}
          >
            Save master list
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
