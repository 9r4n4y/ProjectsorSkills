import * as React from "react";
import { Link, useSearchParams } from "react-router-dom";
import {
  CircleHelp, Folder, ListFilter, Plus, Save, Search as SearchIcon,
  SlidersHorizontal, Tag, X,
} from "lucide-react";
import { toast } from "sonner";

import { api } from "@/lib/api";
import type { SearchResult, SearchResponse, Suggestion } from "@/lib/types";
import { cn, fmtDate } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Checkbox } from "@/components/ui/checkbox";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Separator } from "@/components/ui/separator";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import {
  Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle,
} from "@/components/ui/dialog";
import {
  Popover, PopoverContent, PopoverTrigger,
} from "@/components/ui/popover";
import { TagBadge } from "@/components/shared/tag-badge";

const SCOPES = ["everything", "file name", "tags", "headings", "body", "folder path"];

const MODES = [
  { id: "rank", label: "Smart ranking", desc: "loose match, best first" },
  { id: "strict_keyword", label: "All words", desc: "every word must appear" },
  { id: "strict_tag", label: "By tags", desc: "the tags must match" },
];

export default function SearchView() {
  const [sp, setSp] = useSearchParams();
  const [q, setQ] = React.useState(sp.get("q") || "");
  const [mode, setMode] = React.useState(sp.get("mode") || "rank");
  const [tags, setTags] = React.useState((sp.get("tags") || "").split(",").filter(Boolean));
  const [folders, setFolders] = React.useState((sp.get("folders") || "").split(",").filter(Boolean));
  const [folderOnly, setFolderOnly] = React.useState(sp.get("folder_only") === "1");
  const [scope, setScope] = React.useState<string[]>(
    (sp.get("scope") || "everything").split(",").filter(Boolean),
  );
  const [includeConnected, setIncludeConnected] = React.useState(sp.get("include_connected") === "1");
  const [dateFrom, setDateFrom] = React.useState(sp.get("date_from") || "");
  const [dateTo, setDateTo] = React.useState(sp.get("date_to") || "");
  const [limitTo, setLimitTo] = React.useState((sp.get("limit_to") || "").split(",").filter(Boolean));

  const [res, setRes] = React.useState<SearchResponse | null>(null);
  const [offset, setOffset] = React.useState(0);
  const [helpOpen, setHelpOpen] = React.useState(false);
  const [saveOpen, setSaveOpen] = React.useState(false);
  const [saveName, setSaveName] = React.useState("");

  const params = React.useCallback((): Record<string, string> => {
    const p: Record<string, string> = { q, mode, scope: scope.join(","), tag_mode: mode === "strict_tag" ? "require" : "rank", kw_mode: mode === "strict_keyword" ? "require" : "rank" };
    if (tags.length) p.tags = tags.join(",");
    if (folders.length) p.folders = folders.join(",");
    if (folderOnly) p.folder_only = "1";
    if (includeConnected) p.include_connected = "1";
    if (dateFrom) p.date_from = dateFrom;
    if (dateTo) p.date_to = dateTo;
    if (limitTo.length) p.limit_to = limitTo.join(",");
    return p;
  }, [q, mode, tags, folders, folderOnly, scope, includeConnected, dateFrom, dateTo, limitTo]);

  React.useEffect(() => {
    if (sp.get("run") === "1" || sp.get("q")) {
      doSearch(0);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [sp]);

  async function doSearch(off: number) {
    try {
      const p = params();
      const out = await api.search({ ...p, offset: off });
      setRes((prev) =>
        off === 0
          ? out
          : { ...out, results: [...(prev?.results || []), ...out.results] },
      );
      setOffset(off);
    } catch (e: any) {
      toast.error(e.message);
    }
  }

  React.useEffect(() => {
    const t = setTimeout(() => {
      if (sp.get("q") !== null) doSearch(0);
    }, 250);
    return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [q, mode, tags, folders, folderOnly, scope, includeConnected, dateFrom, dateTo, limitTo]);

  return (
    <div className="mx-auto w-full max-w-5xl px-4 py-6 sm:px-6">
      {/* search bar */}
      <div className="flex flex-wrap gap-2">
        <Input
          id="s-q"
          value={q}
          autoFocus
          placeholder="Search…  (press /)"
          className="h-11 text-base"
          onChange={(e) => setQ(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && doSearch(0)}
        />
        <Button className="h-11 px-5" onClick={() => doSearch(0)}>
          <SearchIcon /> Search
        </Button>
        <Button variant="outline" className="h-11" onClick={() => setHelpOpen(true)}>
          <CircleHelp /> How to use
        </Button>
      </div>

      {/* 1 · how should it match? */}
      <section className="mt-5">
        <h2 className="mb-2.5 flex items-center gap-2 text-sm font-semibold text-foreground">
          <SearchIcon className="h-4 w-4 text-muted-foreground" />
          1 · How should it match?
        </h2>
        <div className="rounded-xl border bg-card p-4">
          <RadioGroup value={mode} onValueChange={setMode} className="grid gap-2 sm:grid-cols-3">
            {MODES.map((m) => (
              <Label
                key={m.id}
                htmlFor={"mode-" + m.id}
                className={cn(
                  "flex cursor-pointer items-start gap-2.5 rounded-lg border p-3 transition-colors hover:bg-accent/50",
                  mode === m.id && "border-primary bg-accent/60",
                )}
              >
                <RadioGroupItem id={"mode-" + m.id} value={m.id} className="mt-0.5" />
                <span>
                  <span className="block text-sm font-medium leading-tight">{m.label}</span>
                  <span className="mt-0.5 block text-xs text-muted-foreground">{m.desc}</span>
                </span>
              </Label>
            ))}
          </RadioGroup>
          <Separator className="my-3.5" />
          <div className="flex flex-wrap items-center gap-x-5 gap-y-3">
            <div className="flex flex-wrap items-center gap-x-3.5 gap-y-2">
              <span className="text-xs font-medium text-muted-foreground">Search in</span>
              {SCOPES.map((s) => (
                <label key={s} className="flex cursor-pointer items-center gap-1.5 text-sm">
                  <Checkbox
                    checked={scope.includes(s)}
                    onCheckedChange={(c) => {
                      if (c) {
                        setScope(s === "everything" ? ["everything"] : [...scope.filter((x) => x !== "everything"), s]);
                      } else {
                        const nx = scope.filter((x) => x !== s);
                        setScope(nx.length ? nx : ["everything"]);
                      }
                    }}
                  />
                  {s}
                </label>
              ))}
            </div>
            <label className="ml-auto flex cursor-pointer items-center gap-2 text-sm text-muted-foreground">
              also show notes connected to the results
              <Switch checked={includeConnected} onCheckedChange={setIncludeConnected} />
            </label>
          </div>
        </div>
      </section>

      {/* 2 · narrow by */}
      <section className="mt-4">
        <h2 className="mb-2.5 flex items-center gap-2 text-sm font-semibold text-foreground">
          <ListFilter className="h-4 w-4 text-muted-foreground" />
          2 · Narrow by tags & folders
        </h2>
        <div className="rounded-xl border bg-card p-4">
          <div className="flex flex-wrap items-center gap-2">
            {tags.map((t) => (
              <Badge key={t} variant="secondary" className="gap-1.5 py-1 pl-2 pr-1">
                <Tag className="h-3 w-3 opacity-60" />
                {t}
                <button className="rounded p-0.5 hover:bg-black/10 dark:hover:bg-white/10" onClick={() => setTags(tags.filter((x) => x !== t))}>
                  <X className="h-3 w-3" />
                </button>
              </Badge>
            ))}
            {folders.map((f) => (
              <Badge key={f} variant="secondary" className="gap-1.5 py-1 pl-2 pr-1">
                <Folder className="h-3 w-3 opacity-60" />
                {f}
                <button className="rounded p-0.5 hover:bg-black/10 dark:hover:bg-white/10" onClick={() => setFolders(folders.filter((x) => x !== f))}>
                  <X className="h-3 w-3" />
                </button>
              </Badge>
            ))}
            <AddFilter onAdd={(s) => {
              if (s.type === "tag") setTags((ts) => (ts.includes(s.name) ? ts : [...ts, s.name]));
              else setFolders((fs) => (fs.includes(s.name) ? fs : [...fs, s.name]));
            }} />
            {folders.length > 0 && (
              <label className="ml-2 flex cursor-pointer items-center gap-1.5 text-xs text-muted-foreground">
                <Checkbox checked={folderOnly} onCheckedChange={(c) => setFolderOnly(!!c)} />
                this folder only (no sub-folders)
              </label>
            )}
          </div>
          <Separator className="my-3.5" />
          <div className="flex flex-wrap items-center gap-2 text-sm">
            <span className="text-xs font-medium text-muted-foreground">Updated</span>
            <Input type="date" value={dateFrom} onChange={(e) => setDateFrom(e.target.value)} className="h-8 w-40" />
            <span className="text-xs text-muted-foreground">to</span>
            <Input type="date" value={dateTo} onChange={(e) => setDateTo(e.target.value)} className="h-8 w-40" />
            {(dateFrom || dateTo) && (
              <Button variant="ghost" size="sm" onClick={() => { setDateFrom(""); setDateTo(""); }}>
                clear
              </Button>
            )}
          </div>
        </div>
      </section>

      {res?.notice && (
        <div className="mt-4 rounded-lg border bg-muted/40 px-4 py-2.5 text-sm text-muted-foreground">{res.notice}</div>
      )}

      {/* results */}
      <div className="mt-4 space-y-3">
        {!res && (sp.get("q") ? (
          Array.from({ length: 3 }).map((_, i) => <Skeleton key={i} className="h-36 rounded-xl" />)
        ) : (
          <div className="rounded-xl border border-dashed p-10 text-center text-sm text-muted-foreground">
            Type a search above — results appear as you type. Press <b>/</b> anywhere in the app to open the quick palette.
          </div>
        ))}
        {res && (
          <div className="flex flex-wrap items-center gap-x-2 gap-y-1 text-xs text-muted-foreground">
            <span>{res.total} result(s) · ranked in {res.elapsed_ms} ms</span>
            {res.query.query_tags.length > 0 && (
              <span>· tags understood: {res.query.query_tags.join(", ")}</span>
            )}
            {limitTo.length > 0 && (
              <button className="underline underline-offset-2 hover:text-foreground" onClick={() => setLimitTo([])}>
                · within: {limitTo.join(", ")} (clear)
              </button>
            )}
          </div>
        )}
        {res?.results.map((r, i) => <ResultCard key={r.path + i} r={r} />)}
        {res && res.results.length < res.total && (
          <div className="flex justify-center pt-2">
            <Button variant="outline" onClick={() => doSearch(offset + 20)}>Show 20 more</Button>
          </div>
        )}
        {res && (
          <div className="flex justify-center pt-1">
            <Button variant="ghost" size="sm" onClick={() => setSaveOpen(true)}>
              <Save /> Save this search
            </Button>
          </div>
        )}
      </div>

      {/* how-to dialog */}
      <Dialog open={helpOpen} onOpenChange={setHelpOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>How to use search</DialogTitle>
          </DialogHeader>
          <div className="space-y-3 text-sm leading-relaxed">
            <p><b>1 · How should it match?</b></p>
            <p>
              <b>Smart ranking</b> (default) — loose match: notes that mention your words, your tags or their
              synonyms rank first. A note carrying the exact tag always beats one that only mentions the word.<br />
              <b>All words</b> — every word you typed must appear in the note.<br />
              <b>By tags</b> — the note must carry the tag; other words then rank within.
            </p>
            <p><i>Search in</i> limits where the words are looked for. <i>Also show connected notes</i> appends the neighbors of the top results.</p>
            <p><b>2 · Narrow by tags & folders</b></p>
            <p>Type to pick existing tags or folders — they are hard boundaries: search never looks outside a chosen folder. The date range filters by the Updated date.</p>
            <p><b>Reading the results</b></p>
            <p>Each result shows a score badge and one plain sentence explaining why it ranked there. Open <i>Why this ranking</i> for the exact signal bars.</p>
          </div>
          <DialogFooter>
            <Button onClick={() => setHelpOpen(false)}>Got it</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* save search dialog */}
      <Dialog open={saveOpen} onOpenChange={setSaveOpen}>
        <DialogContent className="sm:max-w-sm">
          <DialogHeader>
            <DialogTitle>Save this search</DialogTitle>
          </DialogHeader>
          <Input
            value={saveName}
            placeholder="e.g. quick veggie dinners"
            autoFocus
            onChange={(e) => setSaveName(e.target.value)}
            onKeyDown={async (e) => {
              if (e.key === "Enter" && saveName.trim()) {
                await api.saveSearch(saveName.trim(), params());
                toast.success("Saved search pinned to the home page.");
                setSaveOpen(false);
                setSaveName("");
              }
            }}
          />
          <DialogFooter>
            <Button variant="outline" onClick={() => setSaveOpen(false)}>Cancel</Button>
            <Button
              disabled={!saveName.trim()}
              onClick={async () => {
                await api.saveSearch(saveName.trim(), params());
                toast.success("Saved search pinned to the home page.");
                setSaveOpen(false);
                setSaveName("");
              }}
            >
              Save
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function AddFilter({ onAdd }: { onAdd: (s: Suggestion) => void }) {
  const [open, setOpen] = React.useState(false);
  const [q, setQ] = React.useState("");
  const [sugs, setSugs] = React.useState<Suggestion[]>([]);

  React.useEffect(() => {
    let live = true;
    api.suggest(q, "all").then((r) => { if (live) setSugs(r.suggestions || []); }).catch(() => {});
    return () => { live = false; };
  }, [q]);

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button variant="outline" size="sm" className="gap-1.5 border-dashed text-muted-foreground">
          <Plus className="h-3.5 w-3.5" /> Add tag or folder…
        </Button>
      </PopoverTrigger>
      <PopoverContent align="start" className="w-72 p-1">
        <Input
          autoFocus
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="existing ones appear as you type…"
          className="h-8 border-0 shadow-none focus-visible:ring-0"
        />
        <div className="max-h-56 overflow-auto">
          {sugs.map((s) => (
            <button
              key={s.type + s.name}
              className="flex w-full items-center gap-2 rounded-md px-2 py-1.5 text-left text-sm hover:bg-accent"
              onClick={() => { onAdd(s); setOpen(false); setQ(""); }}
            >
              {s.type === "tag" ? <Tag className="h-3.5 w-3.5 text-muted-foreground" /> : <Folder className="h-3.5 w-3.5 text-muted-foreground" />}
              <span className="truncate">{s.name}</span>
              <span className="ml-auto text-xs text-muted-foreground">{s.type} · {s.count}</span>
            </button>
          ))}
          {!sugs.length && <p className="px-2 py-4 text-center text-xs text-muted-foreground">No matches.</p>}
        </div>
      </PopoverContent>
    </Popover>
  );
}

function ResultCard({ r }: { r: SearchResult }) {
  const connected = r.score == null;
  return (
    <Card className={cn("transition-colors hover:bg-accent/30", r.direct === false && "border-dashed")}>
      <CardContent className="p-4">
        <div className="flex items-start justify-between gap-3">
          <Link
            to={`/note/${encodeURIComponent(r.title)}`}
            className="min-w-0 truncate text-[15px] font-medium underline-offset-2 hover:underline"
          >
            {r.title}
          </Link>
          {connected ? (
            <Badge variant="secondary" className="shrink-0">connected to {(r.connected_to || "").split("/").slice(-2)[0]}</Badge>
          ) : (
            <Badge className="shrink-0 tabular-nums">{Math.round((r.score || 0) * 100)}</Badge>
          )}
        </div>
        <div className="mt-1 flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-muted-foreground">
          <span className="inline-flex items-center gap-1"><Folder className="h-3 w-3" />{r.folder || "database"}</span>
          <span>updated {fmtDate(r.updated)}</span>
          {r.neighbor_kind && <Badge variant="outline">{r.neighbor_kind} only</Badge>}
        </div>
        {r.tags?.length > 0 && (
          <div className="mt-2 flex flex-wrap gap-1.5">
            {r.tags.map((t) => <TagBadge key={t} tag={t} />)}
          </div>
        )}
        {r.rank_reason && (
          <p className="mt-2 flex items-start gap-1.5 text-xs text-muted-foreground">
            <SlidersHorizontal className="mt-0.5 h-3 w-3 shrink-0" />
            {r.rank_reason}
          </p>
        )}
        {r.snippet && <p className="mt-1.5 line-clamp-2 text-sm text-foreground/80">…{r.snippet}…</p>}
        {!connected && r.breakdown && <WhyRanking r={r} />}
      </CardContent>
    </Card>
  );
}

const SIGNAL_NAMES: Record<string, string> = {
  tags: "Tags", title: "Title & aliases", headings: "Headings",
  neighbors: "Neighbors", body: "Body", closeness: "Word closeness",
};

function WhyRanking({ r }: { r: SearchResult }) {
  const breakdown = r.breakdown || {};
  const applied = Object.keys(breakdown).filter((k) => breakdown[k].applied);
  if (!applied.length) return null;
  const maxPts = Math.max(...applied.map((k) => breakdown[k].points || 0), 0.001);
  const rows = applied.sort((a, b) => breakdown[b].points - breakdown[a].points);
  return (
    <Collapsible className="mt-2.5">
      <CollapsibleTrigger className="group flex items-center gap-1 text-xs font-medium text-muted-foreground hover:text-foreground">
        Why this ranking
        <svg className="h-3 w-3 transition-transform group-data-[state=open]:rotate-90" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.5">
          <path d="M6 4l4 4-4 4" />
        </svg>
      </CollapsibleTrigger>
      <CollapsibleContent>
        <div className="mt-2 space-y-1.5 rounded-lg border bg-muted/30 p-3">
          {rows.map((k) => {
            const v = breakdown[k];
            const pct = Math.round((v.points / maxPts) * 100);
            return (
              <div key={k} className="flex items-center gap-3 text-xs">
                <span className="w-28 shrink-0 truncate">
                  {SIGNAL_NAMES[k] || k}
                  <span className="ml-1 text-muted-foreground">{Math.round(v.weight * 100)}%</span>
                </span>
                <div className="h-2 flex-1 overflow-hidden rounded-full bg-border">
                  <div className="h-full rounded-full bg-primary/70" style={{ width: pct + "%" }} />
                </div>
                <span className="w-14 shrink-0 text-right tabular-nums text-muted-foreground">
                  {(v.points * 100).toFixed(1)} pts
                </span>
              </div>
            );
          })}
          <p className="pt-1 text-[11px] leading-relaxed text-muted-foreground">
            Coverage {Math.round((r.coverage || 0) * 100)}% of the search words were found in this note.
            Signals that do not apply to this query are left out and their weight is shared among the others.
          </p>
        </div>
      </CollapsibleContent>
    </Collapsible>
  );
}
