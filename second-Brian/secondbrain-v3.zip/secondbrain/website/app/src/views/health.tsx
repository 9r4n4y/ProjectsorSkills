import * as React from "react";
import { Link } from "react-router-dom";
import { toast } from "sonner";
import { CheckCircle2, HeartPulse, ScrollText, Undo2, Wrench, XCircle } from "lucide-react";

import { api } from "@/lib/api";
import type { HealthData, HealthCheck, LogRow } from "@/lib/types";
import { noteName } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription,
  AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";

const LABELS: Record<string, string> = {
  broken_links: "Broken links",
  notes_without_tags: "Notes with no tags",
  notes_without_connections: "Notes with no connections",
  tags_used_once: "Tags used once",
  near_duplicate_tags: "Near-duplicate tags",
  unapproved_tags: "Tags not in the master list",
  tags_missing_from_master: "Tags missing from the master list",
  proposed_tags: "Proposed by the AI",
  notes_without_dates: "Notes without dates",
  unreferenced_attachments: "Unreferenced attachments",
  structure_problems: "Structure problems",
};

export default function HealthView() {
  const [h, setH] = React.useState<HealthData | null>(null);
  const [logs, setLogs] = React.useState<LogRow[] | null>(null);
  const [logText, setLogText] = React.useState<{ name: string; text: string } | null>(null);
  const [undoTarget, setUndoTarget] = React.useState<string | null>(null);

  const load = React.useCallback(() => {
    api.health().then(setH).catch((e) => toast.error(e.message));
    api.logs(30).then((r) => setLogs(r.logs)).catch((e) => toast.error(e.message));
  }, []);
  React.useEffect(load, [load]);

  const fix = async (action: string, params: Record<string, unknown>) => {
    try {
      const out = await api.healthFix(action, params);
      toast.success(out.message || "Fixed. The change is logged and can be undone.");
      load();
    } catch (e: any) {
      toast.error(e.message);
    }
  };

  return (
    <div className="mx-auto w-full max-w-5xl px-4 py-6 sm:px-6">
      <h1 className="flex items-center gap-2 text-2xl font-semibold tracking-tight">
        <HeartPulse className="h-5 w-5 text-muted-foreground" /> Health check
      </h1>
      <p className="mt-1 max-w-2xl text-sm text-muted-foreground">
        Every check runs on its own — one failing check can never break the page. Fixable problems have a
        one-click repair; every fix is logged and can be undone.
      </p>

      <div className="mt-5 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
        {!h
          ? Array.from({ length: 6 }).map((_, i) => <Skeleton key={i} className="h-40 rounded-xl" />)
          : Object.keys(LABELS).map((key) => (
              <HealthCard key={key} k={key} c={(h.checks || {})[key]} onFix={fix} />
            ))}
      </div>

      <h2 className="mb-1 mt-10 flex items-center gap-2 text-xl font-semibold tracking-tight">
        <ScrollText className="h-5 w-5 text-muted-foreground" /> Logs
      </h2>
      <p className="max-w-2xl text-sm text-muted-foreground">
        One new log file after every edit, written by the user or the AI — never automatically. Nothing is
        ever reversed by itself; Undo always asks first.
      </p>

      <div className="mt-4 overflow-hidden rounded-xl border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>When</TableHead>
              <TableHead>By</TableHead>
              <TableHead>Title</TableHead>
              <TableHead className="w-32" />
            </TableRow>
          </TableHeader>
          <TableBody>
            {(logs || []).map((l) => (
              <TableRow key={l.file}>
                <TableCell className="whitespace-nowrap text-muted-foreground">{l.date}</TableCell>
                <TableCell>
                  <Badge variant={l.who === "AI" ? "secondary" : "outline"}>{l.who}</Badge>
                </TableCell>
                <TableCell className="max-w-0 truncate">{l.title}</TableCell>
                <TableCell className="text-right">
                  <Button
                    variant="ghost"
                    size="sm"
                    className="h-7 px-2 text-xs"
                    onClick={async () => {
                      const t = await api.log(l.file);
                      setLogText({ name: l.file, text: t.text });
                    }}
                  >
                    view
                  </Button>
                  {l.undoable && (
                    <Button
                      variant="ghost"
                      size="sm"
                      className="h-7 px-2 text-xs"
                      onClick={() => setUndoTarget(l.file)}
                    >
                      undo
                    </Button>
                  )}
                </TableCell>
              </TableRow>
            ))}
            {logs && !logs.length && (
              <TableRow><TableCell colSpan={4} className="py-8 text-center text-muted-foreground">No logs yet.</TableCell></TableRow>
            )}
          </TableBody>
        </Table>
      </div>

      <Dialog open={!!logText} onOpenChange={(v) => !v && setLogText(null)}>
        <DialogContent className="max-w-2xl">
          <DialogHeader><DialogTitle className="font-mono text-sm">{logText?.name}</DialogTitle></DialogHeader>
          <pre className="max-h-[60vh] overflow-auto whitespace-pre-wrap rounded-lg bg-muted/50 p-4 font-mono text-xs leading-relaxed">
            {logText?.text}
          </pre>
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!undoTarget} onOpenChange={(v) => !v && setUndoTarget(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Undo the change recorded in this log?</AlertDialogTitle>
            <AlertDialogDescription>
              Nothing is ever reversed without this confirmation.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={async () => {
                try {
                  await api.undo(undoTarget!);
                  toast.success("Change undone (the log records that you asked for it).");
                  load();
                } catch (e: any) { toast.error(e.message); }
                setUndoTarget(null);
              }}
            >
              Undo it
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

function HealthCard({ k, c, onFix }: { k: string; c?: HealthCheck; onFix: (a: string, p: Record<string, unknown>) => void }) {
  const check = c || { items: [], error: "missing" };
  const isErr = !!check.error;
  const items = (check.items || []) as any[];
  const count = isErr ? "check failed" : String(items.length);
  const ok = !isErr && items.length === 0;

  const fixBtn = (action: string, params: Record<string, unknown>, text: string) => (
    <Button
      size="sm"
      variant="outline"
      className="h-6 gap-1 px-2 text-[11px]"
      onClick={() => onFix(action, params)}
    >
      <Wrench className="h-3 w-3" /> {text}
    </Button>
  );

  const itemLine = (item: any, i: number) => {
    switch (k) {
      case "broken_links":
        return (
          <>
            <Link to={`/note/${encodeURIComponent(noteName(item.note))}`} className="hover:underline">{noteName(item.note)}</Link>
            {" → missing "}<b>{item.link}</b>
            {check.fixable && fixBtn("remove_broken_links", { note: item.note, link: item.link }, "remove link")}
          </>
        );
      case "notes_without_tags":
        return (
          <>
            <Link to={`/note/${encodeURIComponent(noteName(item))}`} className="hover:underline">{noteName(item)}</Link>
            <span className="text-muted-foreground"> — add tags on the note page</span>
          </>
        );
      case "notes_without_connections":
        return (
          <>
            <Link to={`/note/${encodeURIComponent(noteName(item))}`} className="hover:underline">{noteName(item)}</Link>
            <span className="text-muted-foreground"> — connect it from the note page</span>
          </>
        );
      case "near_duplicate_tags":
        return (
          <>
            {item.tags.join(" ↔ ")}
            {check.fixable && fixBtn("merge_tags", { from: item.tags[0], into: item.tags[1] }, "merge")}
          </>
        );
      case "unapproved_tags":
      case "tags_missing_from_master":
        return (
          <>
            {item}
            {check.fixable && fixBtn("approve_tag", { tags: [item] }, "add to master")}
          </>
        );
      case "proposed_tags":
        return (
          <>
            {item}
            {check.fixable && fixBtn("approve_tag", { tags: [item] }, "approve")}
          </>
        );
      case "notes_without_dates":
        return (
          <>
            <Link to={`/note/${encodeURIComponent(noteName(item))}`} className="hover:underline">{noteName(item)}</Link>
            {check.fixable && fixBtn("fix_missing_dates", { note: item }, "fill dates")}
          </>
        );
      case "unreferenced_attachments":
        return (
          <>
            {item.file} <span className="text-muted-foreground">{item.reason}</span>
            {check.fixable && fixBtn("remove_stray_attachment", { note: item.note, file: item.file }, "delete")}
          </>
        );
      case "structure_problems":
        return <><b>{item.path}</b> — <span className="text-muted-foreground">{item.problem}</span></>;
      case "tags_used_once":
        return <>{item} <span className="text-muted-foreground">used on one note only</span></>;
      default:
        return String(item);
    }
  };

  return (
    <Card>
      <CardHeader className="flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium">{LABELS[k]}</CardTitle>
        {isErr ? <Badge variant="destructive">error</Badge>
          : ok ? <Badge variant="success" className="gap-1"><CheckCircle2 className="h-3 w-3" /> all good</Badge>
          : <Badge variant="warning">{count}</Badge>}
      </CardHeader>
      <CardContent className="pt-0">
        {isErr ? (
          <p className="flex items-start gap-1.5 text-xs text-destructive"><XCircle className="mt-0.5 h-3.5 w-3.5 shrink-0" />{check.error}</p>
        ) : ok ? (
          <p className="text-xs text-muted-foreground">All good.</p>
        ) : (
          <ul className="space-y-1.5">
            {items.slice(0, 8).map((item, i) => (
              <li key={i} className="flex flex-wrap items-center gap-1.5 text-xs leading-relaxed">
                {itemLine(item, i)}
              </li>
            ))}
            {items.length > 8 && (
              <li className="text-xs text-muted-foreground">…and {items.length - 8} more</li>
            )}
          </ul>
        )}
      </CardContent>
    </Card>
  );
}
