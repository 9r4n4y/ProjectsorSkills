import * as React from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { toast } from "sonner";
import {
  FileText, Folder as FolderIcon, FolderPlus, MoreHorizontal,
  NotebookPen, Pencil, ArrowRightLeft, Trash2, Lock,
} from "lucide-react";

import { api } from "@/lib/api";
import type { FolderNode } from "@/lib/types";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import {
  Breadcrumb, BreadcrumbItem, BreadcrumbLink, BreadcrumbList, BreadcrumbPage, BreadcrumbSeparator,
} from "@/components/ui/breadcrumb";
import {
  Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription,
  AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { useUi } from "@/components/shared/ui-context";
import { TagBadge } from "@/components/shared/tag-badge";

export default function FilesView() {
  const { "*": wildcard = "" } = useParams();
  const rel = wildcard.replace(/^\/+|\/+$/g, "");
  const nav = useNavigate();
  const { openNewNote } = useUi();

  const [folders, setFolders] = React.useState<{ tree: FolderNode } | null>(null);
  const [graphNodes, setGraphNodes] = React.useState<{ title: string; folder: string; tags: string[] }[]>([]);
  const [newFolderOpen, setNewFolderOpen] = React.useState(false);
  const [renameOpen, setRenameOpen] = React.useState(false);
  const [moveOpen, setMoveOpen] = React.useState(false);
  const [deleteOpen, setDeleteOpen] = React.useState(false);

  const load = React.useCallback(() => {
    api.folders().then(setFolders).catch((e) => toast.error(e.message));
    api.graph().then((g) => setGraphNodes(g.nodes)).catch(() => {});
  }, []);
  React.useEffect(load, [load, rel]);

  // locate current node
  const node = React.useMemo(() => {
    if (!folders) return null;
    let cur: FolderNode = folders.tree;
    if (rel) {
      for (const part of rel.split("/")) {
        const next = (cur.children || []).find((c) => c.name === part);
        if (!next) return null;
        cur = next;
      }
    }
    return cur;
  }, [folders, rel]);

  const subs = (node?.children || []).map((c) => ({
    name: c.name,
    path: c.path,
    private: c.private,
    notes: c.notes || 0,
  }));
  const here = graphNodes.filter((n) => (n.folder || "") === rel);

  return (
    <div className="mx-auto w-full max-w-5xl px-4 py-6 sm:px-6">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h1 className="flex items-center gap-2 text-2xl font-semibold tracking-tight">
            <FolderIcon className="h-5 w-5 text-muted-foreground" /> Files
            {node?.private && <Badge variant="warning" className="gap-1"><Lock className="h-3 w-3" /> private — hidden from search</Badge>}
          </h1>
          <Breadcrumb className="mt-1.5">
            <BreadcrumbList>
              <BreadcrumbItem>
                <BreadcrumbLink asChild><Link to="/files">database</Link></BreadcrumbLink>
              </BreadcrumbItem>
              {rel && rel.split("/").map((part, i) => {
                const upto = rel.split("/").slice(0, i + 1).join("/");
                const last = i === rel.split("/").length - 1;
                return (
                  <React.Fragment key={upto}>
                    <BreadcrumbSeparator />
                    <BreadcrumbItem>
                      {last ? (
                        <BreadcrumbPage>{part}</BreadcrumbPage>
                      ) : (
                        <BreadcrumbLink asChild><Link to={"/files/" + upto}>{part}</Link></BreadcrumbLink>
                      )}
                    </BreadcrumbItem>
                  </React.Fragment>
                );
              })}
            </BreadcrumbList>
          </Breadcrumb>
        </div>
        <div className="flex flex-wrap gap-2">
          <Button size="sm" onClick={() => openNewNote(rel)}><NotebookPen /> New note here</Button>
          <Button size="sm" variant="outline" onClick={() => setNewFolderOpen(true)}><FolderPlus /> New subfolder</Button>
          {rel && (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button size="sm" variant="outline" aria-label="Folder actions"><MoreHorizontal /></Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem onClick={() => setRenameOpen(true)}><Pencil /> Rename this folder</DropdownMenuItem>
                <DropdownMenuItem onClick={() => setMoveOpen(true)}><ArrowRightLeft /> Move this folder</DropdownMenuItem>
                <DropdownMenuItem className="text-destructive focus:text-destructive" onClick={() => setDeleteOpen(true)}>
                  <Trash2 /> Delete (empty only)
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          )}
        </div>
      </div>

      {!folders ? (
        <div className="mt-6 grid gap-3 sm:grid-cols-3">
          {Array.from({ length: 6 }).map((_, i) => <Skeleton key={i} className="h-20 rounded-xl" />)}
        </div>
      ) : (
        <>
          {here.length > 0 && (
            <>
              <h2 className="mb-2.5 mt-6 text-sm font-semibold text-muted-foreground">Notes in this folder</h2>
              <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
                {here.map((n) => (
                  <Link key={n.title} to={`/note/${encodeURIComponent(n.title)}`}>
                    <Card className="group h-full transition-all hover:-translate-y-0.5 hover:shadow-md">
                      <CardContent className="flex items-center gap-3 p-4">
                        <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-primary/10">
                          <FileText className="h-4 w-4" />
                        </div>
                        <div className="min-w-0">
                          <div className="truncate text-sm font-medium">{n.title}</div>
                          <div className="mt-0.5 flex gap-1 truncate text-xs text-muted-foreground">
                            {(n.tags || []).slice(0, 3).map((t) => <span key={t}>{t}</span>).reduce((a, b, i) => (i ? [...a, " · ", b] : [b]), [] as any[])}
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </Link>
                ))}
              </div>
            </>
          )}

          {subs.length > 0 && (
            <>
              <h2 className="mb-2.5 mt-6 text-sm font-semibold text-muted-foreground">Subfolders</h2>
              <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
                {subs.map((c) => (
                  <Link key={c.path} to={"/files/" + c.path}>
                    <Card className="group h-full transition-all hover:-translate-y-0.5 hover:shadow-md">
                      <CardContent className="flex items-center gap-3 p-4">
                        <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-muted">
                          <FolderIcon className="h-4 w-4 text-muted-foreground" />
                        </div>
                        <div className="min-w-0">
                          <div className="truncate text-sm font-medium">{c.name}</div>
                          <div className="text-xs text-muted-foreground">
                            {c.notes} note{c.notes === 1 ? "" : "s"}{c.private ? " · private" : ""}
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </Link>
                ))}
              </div>
            </>
          )}

          {!here.length && !subs.length && (
            <div className="mt-8 rounded-xl border border-dashed p-10 text-center">
              <FolderIcon className="mx-auto h-8 w-8 text-muted-foreground/50" />
              <p className="mt-3 text-sm text-muted-foreground">This folder is empty.</p>
              <div className="mt-4 flex justify-center gap-2">
                <Button size="sm" onClick={() => openNewNote(rel)}><NotebookPen /> New note here</Button>
                <Button size="sm" variant="outline" onClick={() => setNewFolderOpen(true)}><FolderPlus /> New subfolder</Button>
              </div>
            </div>
          )}

          <p className="mt-8 text-xs text-muted-foreground">
            A folder is a subject; subjects nest to any depth. Folder chips in search are hard boundaries.
          </p>
        </>
      )}

      <NewFolderDialog open={newFolderOpen} onOpenChange={setNewFolderOpen} parent={rel} onDone={() => { load(); }} />
      <RenameFolderDialog open={renameOpen} onOpenChange={setRenameOpen} path={rel} name={node?.name || ""} onDone={(newRel) => { load(); nav("/files/" + newRel); }} />
      <MoveFolderDialog open={moveOpen} onOpenChange={setMoveOpen} path={rel} onDone={() => { load(); nav("/files"); }} />
      <DeleteFolderDialog open={deleteOpen} onOpenChange={setDeleteOpen} path={rel} onDone={() => { load(); nav("/files/" + rel.split("/").slice(0, -1).join("/")); }} />
    </div>
  );
}

function NewFolderDialog({ open, onOpenChange, parent, onDone }: {
  open: boolean; onOpenChange: (v: boolean) => void; parent: string; onDone: () => void;
}) {
  const [name, setName] = React.useState("");
  const [subject, setSubject] = React.useState("");
  React.useEffect(() => { if (open) { setName(""); setSubject(""); } }, [open]);
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Create a folder (a new subject)</DialogTitle>
          <DialogDescription>Folder trees can be any depth. An optional _subject.md describes its purpose and sensitivity.</DialogDescription>
        </DialogHeader>
        <div className="space-y-3">
          <div className="space-y-1.5">
            <Label>Parent</Label>
            <Input value={parent || "database (root)"} readOnly className="bg-muted/50 font-mono text-xs" />
          </div>
          <div className="space-y-1.5">
            <Label>Name</Label>
            <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g. Home Repair" autoFocus />
          </div>
          <div className="space-y-1.5">
            <Label>Optional _subject.md content</Label>
            <Textarea value={subject} onChange={(e) => setSubject(e.target.value)} rows={3} placeholder="Purpose: ..." />
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
          <Button
            disabled={!name.trim()}
            onClick={async () => {
              try {
                await api.folderCreate(parent, name.trim(), subject || undefined);
                toast.success("Folder created.");
                onOpenChange(false);
                onDone();
              } catch (e: any) { toast.error(e.message); }
            }}
          >
            Create
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function RenameFolderDialog({ open, onOpenChange, path, name, onDone }: {
  open: boolean; onOpenChange: (v: boolean) => void; path: string; name: string; onDone: (newRel: string) => void;
}) {
  const [val, setVal] = React.useState(name);
  React.useEffect(() => { if (open) setVal(name); }, [open, name]);
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-sm">
        <DialogHeader><DialogTitle>Rename folder</DialogTitle></DialogHeader>
        <Input value={val} onChange={(e) => setVal(e.target.value)} autoFocus />
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
          <Button
            disabled={!val.trim()}
            onClick={async () => {
              try {
                await api.folderRename(path, val.trim());
                toast.success("Renamed.");
                onOpenChange(false);
                onDone(path.split("/").slice(0, -1).concat(val.trim()).join("/"));
              } catch (e: any) { toast.error(e.message); }
            }}
          >
            Rename
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function MoveFolderDialog({ open, onOpenChange, path, onDone }: {
  open: boolean; onOpenChange: (v: boolean) => void; path: string; onDone: () => void;
}) {
  const [parent, setParent] = React.useState(path.split("/").slice(0, -1).join("/"));
  React.useEffect(() => { if (open) setParent(path.split("/").slice(0, -1).join("/")); }, [open, path]);
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-sm">
        <DialogHeader>
          <DialogTitle>Move folder</DialogTitle>
          <DialogDescription>New parent path (empty = database root).</DialogDescription>
        </DialogHeader>
        <Input value={parent} onChange={(e) => setParent(e.target.value)} placeholder={path.split("/").slice(0, -1).join("/")} className="font-mono text-xs" />
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
          <Button
            onClick={async () => {
              try {
                await api.folderMove(path, parent.trim());
                toast.success("Moved.");
                onOpenChange(false);
                onDone();
              } catch (e: any) { toast.error(e.message); }
            }}
          >
            Move
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function DeleteFolderDialog({ open, onOpenChange, path, onDone }: {
  open: boolean; onOpenChange: (v: boolean) => void; path: string; onDone: () => void;
}) {
  return (
    <AlertDialog open={open} onOpenChange={onOpenChange}>
      <AlertDialogContent>
        <AlertDialogHeader>
          <AlertDialogTitle>Delete this folder?</AlertDialogTitle>
          <AlertDialogDescription>Only empty folders can be deleted.</AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter>
          <AlertDialogCancel>Cancel</AlertDialogCancel>
          <AlertDialogAction
            variant="destructive"
            onClick={async () => {
              try {
                await api.folderDelete(path);
                toast.success("Deleted (it was empty).");
                onOpenChange(false);
                onDone();
              } catch (e: any) { toast.error(e.message); }
            }}
          >
            Delete
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
}
