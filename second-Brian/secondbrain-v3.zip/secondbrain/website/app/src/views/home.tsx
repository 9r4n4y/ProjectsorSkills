import * as React from "react";
import { Link, useNavigate } from "react-router-dom";
import {
  ArrowRight, Eye, FileText, FolderOpen, Network as GraphIcon,
  HeartPulse, NotebookPen, Pin, Search as SearchIcon, Tags as TagsIcon, X,
} from "lucide-react";
import { toast } from "sonner";

import { api } from "@/lib/api";
import type { AppState, NoteRef } from "@/lib/types";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Separator } from "@/components/ui/separator";
import { useUi } from "@/components/shared/ui-context";

export default function HomeView() {
  const [st, setSt] = React.useState<AppState | null>(null);
  const [q, setQ] = React.useState("");
  const nav = useNavigate();
  const { openNewNote } = useUi();

  React.useEffect(() => {
    api.state().then(setSt).catch((e) => toast.error(e.message));
  }, []);

  const go = () => nav("/search?q=" + encodeURIComponent(q));

  return (
    <div className="mx-auto w-full max-w-6xl px-4 py-8 sm:px-6">
      {/* hero */}
      <div className="animate-fade-up py-6 text-center sm:py-12">
        <h1 className="text-3xl font-semibold tracking-tight sm:text-4xl">
          Second<span className="text-muted-foreground">Brain</span>
        </h1>
        <p className="mx-auto mt-2 max-w-md text-balance text-sm text-muted-foreground sm:text-base">
          Your notes as plain Markdown — searchable, tagged, connected.
        </p>
        <div className="mx-auto mt-6 flex max-w-xl gap-2">
          <Input
            value={q}
            autoFocus
            placeholder="Search…  (press /)"
            className="h-11 text-base"
            onChange={(e) => setQ(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && go()}
          />
          <Button className="h-11 px-5" onClick={go}>
            <SearchIcon /> Search
          </Button>
        </div>
        {st && st.saved_searches.length > 0 && (
          <div className="mt-4 flex flex-wrap items-center justify-center gap-2">
            {st.saved_searches.map((s) => (
              <SavedChip key={s.name} name={s.name} params={s.params} onDeleted={() => api.state().then(setSt)} />
            ))}
          </div>
        )}
      </div>

      {/* stats */}
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        {!st ? (
          Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-24 rounded-xl" />)
        ) : (
          <>
            <StatCard icon={FileText} value={st.notes} label="notes" />
            <StatCard icon={Pin} value={st.pinned.length} label="pinned" />
            <StatCard icon={Eye} value={st.recent.length} label="recently updated" />
            <StatCard icon={SearchIcon} value={st.saved_searches.length} label="saved searches" />
          </>
        )}
      </div>

      {/* pinned + recent */}
      <div className="mt-4 grid gap-4 md:grid-cols-2">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-base">
              <Pin className="h-4 w-4 text-muted-foreground" /> Pinned
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-0">
            {st && st.pinned.length === 0 ? (
              <p className="text-sm text-muted-foreground">
                Nothing pinned yet — use the pin button on a note.
              </p>
            ) : (
              <ul className="-mx-2">
                {st?.pinned.map((n) => <NoteRow key={n.path} n={n} />)}
              </ul>
            )}
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-base">
              <Eye className="h-4 w-4 text-muted-foreground" /> Recently updated
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-0">
            <ul className="-mx-2">
              {st?.recent.map((n) => <NoteRow key={n.path} n={n} />)}
            </ul>
          </CardContent>
        </Card>
      </div>

      {/* quick actions */}
      <div className="mt-6 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <QuickCard to="/files" icon={FolderOpen} title="Files" desc="Browse every folder; create notes and folders right where you are." />
        <QuickCard to="/tags" icon={TagsIcon} title="Tags" desc="All tags — independent and in sync. Edit, rename, merge." />
        <QuickCard to="/graph" icon={GraphIcon} title="Graph" desc="See how notes connect." />
        <QuickCard to="/health" icon={HeartPulse} title="Health" desc="Automatic checks with one-click fixes." />
      </div>

      <div className="mt-8 flex justify-center pb-6">
        <Button variant="outline" onClick={() => openNewNote()}>
          <NotebookPen /> Write your first note
        </Button>
      </div>
    </div>
  );
}

function SavedChip({ name, params, onDeleted }: { name: string; params: Record<string, string>; onDeleted: () => void }) {
  const qs = new URLSearchParams(params).toString();
  return (
    <span className="group inline-flex items-center overflow-hidden rounded-md border bg-secondary text-secondary-foreground">
      <Link to={"/search?" + qs} className="inline-flex items-center gap-1.5 px-2.5 py-1 text-xs font-medium hover:bg-secondary/70">
        <SearchIcon className="h-3 w-3 opacity-60" />
        {name}
      </Link>
      <button
        className="h-full border-l px-1.5 py-1 text-muted-foreground opacity-60 transition hover:opacity-100 hover:text-destructive"
        title="Delete this saved search"
        onClick={async () => {
          await api.deleteSavedSearch(name);
          toast.success("Saved search deleted.");
          onDeleted();
        }}
      >
        <X className="h-3 w-3" />
      </button>
    </span>
  );
}

function StatCard({ icon: Icon, value, label }: { icon: any; value: number; label: string }) {
  return (
    <Card className="transition-colors hover:bg-accent/40">
      <CardContent className="flex items-center gap-3 p-4">
        <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-muted">
          <Icon className="h-4.5 w-4.5 h-[18px] w-[18px] text-muted-foreground" />
        </div>
        <div>
          <div className="text-xl font-semibold tabular-nums leading-none">{value}</div>
          <div className="mt-1 text-xs text-muted-foreground">{label}</div>
        </div>
      </CardContent>
    </Card>
  );
}

function NoteRow({ n }: { n: NoteRef }) {
  return (
    <li className="rounded-md">
      <Link
        to={`/note/${encodeURIComponent(n.title)}`}
        className="group flex items-baseline justify-between gap-3 px-2 py-1.5 text-sm hover:bg-accent/60"
      >
        <span className="truncate font-medium">{n.title}</span>
        <span className="shrink-0 text-xs text-muted-foreground">{n.folder || "database"}</span>
      </Link>
    </li>
  );
}

function QuickCard({ to, icon: Icon, title, desc }: { to: string; icon: any; title: string; desc: string }) {
  return (
    <Link to={to}>
      <Card className="group h-full transition-all hover:-translate-y-0.5 hover:shadow-md">
        <CardContent className="flex h-full items-start gap-3 p-4">
          <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-primary/10">
            <Icon className="h-4 w-4" />
          </div>
          <div className="min-w-0">
            <div className="flex items-center gap-1 text-sm font-medium">
              {title}
              <ArrowRight className="h-3.5 w-3.5 -translate-x-1 opacity-0 transition-all group-hover:translate-x-0 group-hover:opacity-100" />
            </div>
            <p className="mt-1 text-xs leading-relaxed text-muted-foreground">{desc}</p>
          </div>
        </CardContent>
      </Card>
    </Link>
  );
}
