import * as React from "react";
import { useNavigate } from "react-router-dom";
import { toast } from "sonner";
import { Network as GraphIcon } from "lucide-react";

import { api } from "@/lib/api";
import type { GraphData } from "@/lib/types";
import { tagHue } from "@/lib/utils";
import { useTheme } from "@/components/shared/theme";
import { Skeleton } from "@/components/ui/skeleton";

interface SimNode {
  id: string;
  title: string;
  hue: number;
  x: number;
  y: number;
  vx: number;
  vy: number;
}

export default function GraphView() {
  const [g, setG] = React.useState<GraphData | null>(null);
  const canvasRef = React.useRef<HTMLCanvasElement>(null);
  const nav = useNavigate();
  const { resolved } = useTheme();

  React.useEffect(() => {
    api.graph().then(setG).catch((e) => toast.error(e.message));
  }, []);

  React.useEffect(() => {
    if (!g || !canvasRef.current) return;
    const cv = canvasRef.current;
    const W = (cv.width = Math.min(1100, cv.parentElement!.clientWidth));
    const H = (cv.height = 620);
    const ctx = cv.getContext("2d")!;

    const nodes: SimNode[] = g.nodes.map((n, i) => ({
      id: n.id,
      title: n.title,
      hue: tagHue((n.tags[0] || "?").split("-")[0]),
      x: W / 2 + Math.cos(i * 2.4) * (100 + i * 8),
      y: H / 2 + Math.sin(i * 2.4) * (80 + i * 5),
      vx: 0,
      vy: 0,
    }));
    const byId = Object.fromEntries(nodes.map((n) => [n.id, n]));
    const edges = g.edges
      .map((e) => [byId[e[0]], byId[e[1]]] as [SimNode, SimNode])
      .filter((e) => e[0] && e[1]);

    for (let step = 0; step < 300; step++) {
      for (const a of nodes) {
        let fx = 0, fy = 0;
        for (const b of nodes) {
          if (a === b) continue;
          const dx = a.x - b.x, dy = a.y - b.y;
          const d2 = dx * dx + dy * dy + 40;
          fx += (dx / d2) * 900;
          fy += (dy / d2) * 900;
        }
        for (const [p, q] of edges) {
          if (p === a || q === a) {
            const other = p === a ? q : p;
            fx += (other.x - a.x) * 0.02;
            fy += (other.y - a.y) * 0.02;
          }
        }
        fx += (W / 2 - a.x) * 0.002;
        fy += (H / 2 - a.y) * 0.002;
        a.vx = (a.vx + fx) * 0.85;
        a.vy = (a.vy + fy) * 0.85;
      }
      for (const n of nodes) {
        n.x = Math.max(40, Math.min(W - 40, n.x + n.vx));
        n.y = Math.max(40, Math.min(H - 40, n.y + n.vy));
      }
    }

    const paint = () => {
      const style = getComputedStyle(document.documentElement);
      const border = style.getPropertyValue("--border").trim();
      const fg = style.getPropertyValue("--foreground").trim();
      ctx.clearRect(0, 0, W, H);
      ctx.strokeStyle = `hsl(${border})`;
      ctx.lineWidth = 1.25;
      for (const [p, q] of edges) {
        ctx.beginPath();
        ctx.moveTo(p.x, p.y);
        ctx.lineTo(q.x, q.y);
        ctx.stroke();
      }
      ctx.font = "11px -apple-system, BlinkMacSystemFont, Segoe UI, Roboto, sans-serif";
      ctx.textAlign = "center";
      for (const n of nodes) {
        ctx.beginPath();
        ctx.arc(n.x, n.y, 14, 0, 7);
        ctx.fillStyle = `hsl(${n.hue} 55% ${resolved === "dark" ? 38 : 72}%)`;
        ctx.fill();
        ctx.fillStyle = `hsl(${fg})`;
        ctx.fillText(n.title.length > 26 ? n.title.slice(0, 25) + "…" : n.title, n.x, n.y + 26);
      }
    };
    paint();

    let hit: SimNode | null = null;
    const onMove = (e: MouseEvent) => {
      const r = cv.getBoundingClientRect();
      const mx = e.clientX - r.left, my = e.clientY - r.top;
      hit = nodes.find((n) => Math.hypot(n.x - mx, n.y - my) < 16) || null;
      cv.style.cursor = hit ? "pointer" : "default";
    };
    const onClick = () => {
      if (hit) nav(`/note/${encodeURIComponent(hit.title)}`);
    };
    cv.addEventListener("mousemove", onMove);
    cv.addEventListener("click", onClick);
    return () => {
      cv.removeEventListener("mousemove", onMove);
      cv.removeEventListener("click", onClick);
    };
  }, [g, resolved, nav]);

  return (
    <div className="mx-auto w-full max-w-6xl px-4 py-6 sm:px-6">
      <h1 className="flex items-center gap-2 text-2xl font-semibold tracking-tight">
        <GraphIcon className="h-5 w-5 text-muted-foreground" /> Connection graph
      </h1>
      <p className="mt-1 text-sm text-muted-foreground">
        Every note and every link. Click a circle to open the note.
      </p>
      {!g ? (
        <Skeleton className="mt-5 h-[620px] w-full rounded-xl" />
      ) : (
        <div className="mt-5 overflow-hidden rounded-xl border bg-card p-2">
          <canvas ref={canvasRef} className="mx-auto block max-w-full" />
        </div>
      )}
    </div>
  );
}
