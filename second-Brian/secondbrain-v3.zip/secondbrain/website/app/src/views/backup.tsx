import * as React from "react";
import { toast } from "sonner";
import {
  ArchiveRestore, CheckCircle2, Database, Eye, HardDriveDownload, ShieldCheck, XCircle,
} from "lucide-react";

import { api } from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription,
  AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from "@/components/ui/alert-dialog";

export default function BackupView() {
  const [dir, setDir] = React.useState("");
  const [scope, setScope] = React.useState("whole");
  const [direction, setDirection] = React.useState("backup");
  const [preview, setPreview] = React.useState<string | null>(null);
  const [result, setResult] = React.useState<{ ok: boolean; json: string; verified?: number; diff?: string[] } | null>(null);
  const [confirmRun, setConfirmRun] = React.useState(false);

  const args = () => ({ to: dir.trim(), scope, direction });

  return (
    <div className="mx-auto w-full max-w-3xl px-4 py-6 sm:px-6">
      <h1 className="flex items-center gap-2 text-2xl font-semibold tracking-tight">
        <ArchiveRestore className="h-5 w-5 text-muted-foreground" /> Backup & restore
      </h1>
      <p className="mt-1 max-w-2xl text-sm text-muted-foreground">
        Makes the chosen folder IDENTICAL to the project — byte for byte — then verifies every single file
        by SHA-256. The project itself is only read; a backup run never changes anything inside it.
        Replaced or removed files are kept in a dated <code className="font-mono text-xs">.versions/</code> folder.
      </p>

      <div className="mt-6 space-y-4">
        <Step n={1} title="Choose the backup folder">
          <div className="grid gap-3 sm:grid-cols-3">
            <div className="space-y-1.5 sm:col-span-3">
              <Label>Backup folder (anywhere outside the project)</Label>
              <Input value={dir} onChange={(e) => setDir(e.target.value)} placeholder="/path/to/backup" className="font-mono text-xs" />
            </div>
            <div className="space-y-1.5">
              <Label>Scope</Label>
              <Select value={scope} onValueChange={setScope}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {["whole", "database", "inbox", "logs"].map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5 sm:col-span-2">
              <Label>Direction</Label>
              <Select value={direction} onValueChange={setDirection}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="backup">update backup from the project</SelectItem>
                  <SelectItem value="restore">restore project from the backup</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </Step>

        <Step n={2} title="Preview what changes">
          <Button variant="outline" disabled={!dir.trim()} onClick={async () => {
            try {
              const a = args();
              const r = await api.backupPreview(a.to, a.scope, a.direction);
              setPreview(r.preview);
            } catch (e: any) { toast.error(e.message); }
          }}>
            <Eye /> Preview what changes
          </Button>
          {preview && (
            <pre className="mt-3 max-h-72 overflow-auto whitespace-pre-wrap rounded-lg border bg-muted/40 p-3 font-mono text-xs leading-relaxed">{preview}</pre>
          )}
        </Step>

        <Step n={3} title="Run & verify every file">
          <div className="flex flex-wrap gap-2">
            <Button disabled={!dir.trim()} onClick={() => setConfirmRun(true)}>
              <ShieldCheck /> Run & verify every file
            </Button>
            <Button variant="outline" disabled={!dir.trim()} onClick={async () => {
              try {
                const a = args();
                const r = await api.backupVerify(a.to, a.scope);
                setResult(r.ok
                  ? { ok: true, json: "", verified: r.files_compared }
                  : { ok: false, json: "", diff: r.differences || [] });
              } catch (e: any) { toast.error(e.message); }
            }}>
              <CheckCircle2 /> Verify byte-identical now
            </Button>
          </div>

          {result && (
            <div className="mt-3">
              {result.ok ? (
                <p className="flex items-center gap-2 rounded-lg border border-emerald-500/40 bg-emerald-500/5 px-3 py-2.5 text-sm text-emerald-700 dark:text-emerald-400">
                  <CheckCircle2 className="h-4 w-4 shrink-0" />
                  Byte-identical: every one of the {result.verified} files in scope verified by SHA-256.
                </p>
              ) : (
                <div className="rounded-lg border border-destructive/40 bg-destructive/5 p-3 text-sm text-destructive">
                  <p className="flex items-center gap-2">
                    <XCircle className="h-4 w-4" /> Not identical: {result.diff?.length} file(s) differ. Run a backup first.
                  </p>
                  <pre className="mt-2 max-h-52 overflow-auto whitespace-pre-wrap font-mono text-xs">{result.diff?.slice(0, 60).join("\n")}</pre>
                </div>
              )}
            </div>
          )}
        </Step>
      </div>

      <AlertDialog open={confirmRun} onOpenChange={setConfirmRun}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Run the {direction} now?</AlertDialogTitle>
            <AlertDialogDescription>
              Changed and new files only are copied; replaced files are kept in .versions/; afterwards EVERY
              file in scope is re-hashed.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={async () => {
                try {
                  const a = args();
                  const r = await api.backupRun(a.to, a.scope, a.direction);
                  setResult({
                    ok: !!r.ok,
                    json: JSON.stringify(r, null, 1),
                    verified: r.verified_files,
                  });
                } catch (e: any) { toast.error(e.message); }
                setConfirmRun(false);
              }}
            >
              Run it
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {result?.json && (
        <Card className="mt-4">
          <CardContent className="p-0">
            <pre className="max-h-72 overflow-auto p-4 font-mono text-xs leading-relaxed">{result.json}</pre>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

function Step({ n, title, children }: { n: number; title: string; children: React.ReactNode }) {
  return (
    <Card>
      <CardContent className="flex gap-4 p-5">
        <div className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-primary text-sm font-semibold text-primary-foreground">
          {n}
        </div>
        <div className="min-w-0 flex-1">
          <h2 className="mb-3 text-sm font-semibold">{title}</h2>
          {children}
        </div>
      </CardContent>
    </Card>
  );
}
