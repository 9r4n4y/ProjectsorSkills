#!/usr/bin/env bash
# Build the shadcn UI and sync it into website/static (keeps vendor/).
set -euo pipefail
cd "$(dirname "$0")"
npm run build
STATIC="../static"
rm -rf "$STATIC/assets" "$STATIC/index.html"
cp -r dist/* "$STATIC/"
echo "Deployed to $STATIC (vendor/ preserved)."
