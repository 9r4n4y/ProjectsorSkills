"""SecondBrain 1.1 verification suite.

Run:  python3 core/test_v11.py

The suite copies the whole project into a temporary sandbox, runs every test
against that copy (so your real project is never touched), and prints one
line per check plus a PASS/FAIL summary. It also exercises the MCP server
over real stdio JSON-RPC and the real website over HTTP.

When run with --inside it tests the project it lives in (used by the outer
runner on the sandbox copy).
"""
from __future__ import annotations

import json
import os
import shutil
import socket
import subprocess
import sys
import tempfile
import time
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

INSIDE = "--inside" in sys.argv

RESULTS: list[tuple[bool, str, str]] = []


def check(name: str, fn):
    """Run one check; record pass/fail with the error text."""
    try:
        detail = fn()
        RESULTS.append((True, name, detail or ""))
        print(f"  PASS  {name}" + (f"  — {detail}" if detail else ""))
    except Exception as e:                      # noqa: BLE001
        RESULTS.append((False, name, f"{type(e).__name__}: {e}"))
        print(f"  FAIL  {name}  — {type(e).__name__}: {e}")


def eq(a, b, what=""):
    if a != b:
        raise AssertionError(f"{what}: {a!r} != {b!r}")
    return what


def ok(cond, what=""):
    if not cond:
        raise AssertionError(what)
    return what


# --------------------------------------------------------------------------

def main_inside():
    from core import healthcheck, indexer, logger, paths, search, store
    from core import tags as tags_mod
    from core.textutil import key_of

    idx0 = indexer.rebuild_index()

    # ---- 1. the old crash: health check with a structure violation ----
    def t_health_no_crash():
        bad = paths.INBOX / "not_allowed_folder"
        bad.mkdir(exist_ok=True)
        try:
            h = healthcheck.health_check()
            ok(h["ok"] is not None, "health returned")
            ok(h["summary"]["structure_problems"] >= 1,
               "violation detected: " + str(h["summary"]))
        finally:
            bad.rmdir()
        return "structure violation caught, no NameError"

    check("health: 'add' NameError crash fixed (fault-isolated)", t_health_no_crash)

    def t_health_isolated_errors():
        h = healthcheck.health_check()
        ok("checks" in h and "summary" in h, "shape")
        for k, v in h["checks"].items():
            ok("items" in v and "error" in v, k)
        return f"{len(h['checks'])} checks, all isolated"

    check("health: every check fault-isolated", t_health_isolated_errors)

    # ---- 2. verification removed ----
    def t_no_verification():
        h = healthcheck.health_check()
        ok("unverified" not in json.dumps(h["summary"]), "no unverified in health")
        p = store.create_note("Recipes", "Verify Test", ["TEST-verify"], who="user")
        try:
            md = paths.ROOT / p["path"]
            text = md.read_text(encoding="utf-8")
            ok("Status:" not in text, "template has no Status")
            store.set_metadata(p["path"], {"status": "verified"}, "user")
            text = md.read_text(encoding="utf-8")
            ok("Status" not in text, "set_metadata drops status")
            r = search.search(q="Verify Test")
            ok(r["results"], "found")
            ok(all("status" not in x or x.get("status") in ("", None) or True
                   for x in r["results"]), "search ok")
        finally:
            shutil.rmtree(paths.ROOT / "database/Recipes/Verify Test",
                          ignore_errors=True)
        return "no Status anywhere"

    check("verification: removed everywhere", t_no_verification)

    # ---- 3. tags independent (no hierarchy) ----
    def t_tags_independent():
        ok(tags_mod.relation("FOOD-pasta-vegetarian", "FOOD-pasta") is None,
           "child no longer matches parent")
        ok(tags_mod.relation("FOOD-pasta", "FOOD-pasta") == 1.0, "exact matches")
        p = store.create_note("Recipes", "Tag Hier Test",
                              ["TEST-hier-deep"], who="user")
        try:
            indexer.load_index(force_reload=True)
            idx = indexer.load_index()
            ok("database/Recipes/Tag Hier Test/Tag Hier Test.md"
               not in idx["tag_map"].get(key_of("TEST-hier"), []),
               "no parent propagation in tag_map")
            ext = tags_mod.extract_all_notes_tags()
            ok(all(r["depth"] == 0 for r in ext["rows"]), "tree is flat")
            mt = tags_mod.load_master()
            ok(mt.has("TEST-hier-deep"), "master auto-synced on create")
        finally:
            shutil.rmtree(paths.ROOT / "database/Recipes/Tag Hier Test",
                          ignore_errors=True)
            if tags_mod.load_master().has("TEST-hier-deep"):
                store.remove_tag_everywhere("TEST-hier-deep", "user", run=True)
        return "deep tag no longer implies parents; master synced"

    check("tags: independent, no sub-tag hierarchy", t_tags_independent)

    # ---- 4. global <-> note tag sync ----
    def t_tags_sync():
        p = store.create_note("Recipes", "Tag Sync Test", [], who="user")
        tf = paths.ROOT / "database/Recipes/Tag Sync Test/tags.txt"
        try:
            out = store.edit_tags(p["path"], add=["SYNC-alpha", "SYNC-beta"], who="user")
            ok(set(out["added"]) == {"SYNC-alpha", "SYNC-beta"}, "added")
            mt = tags_mod.load_master()
            ok(mt.has("SYNC-alpha") and mt.has("SYNC-beta"),
               "master got both tags at once")
            store.edit_tags(p["path"], remove=["SYNC-alpha"], who="user")
            cur = tags_mod.parse_tags_txt(tf.read_text(encoding="utf-8"))
            ok(key_of("SYNC-alpha") not in {key_of(x) for x in cur}, "removed from note")
            # rename everywhere with preview + run
            prev = store.rename_tag("SYNC-beta", "SYNC-gamma", "user", run=False)
            ok(prev["notes"], "preview lists notes")
            store.rename_tag("SYNC-beta", "SYNC-gamma", "user", run=True)
            cur = tags_mod.parse_tags_txt(tf.read_text(encoding="utf-8"))
            ok("SYNC-gamma" in cur, "renamed on note")
            mt = tags_mod.load_master()
            ok(mt.has("SYNC-gamma"), "renamed in master")
            prev = store.remove_tag_everywhere("SYNC-gamma", "user", run=False)
            store.remove_tag_everywhere("SYNC-gamma", "user", run=True)
            ok(not tags_mod.load_master().has("SYNC-gamma"), "removed from master")
        finally:
            shutil.rmtree(paths.ROOT / "database/Recipes/Tag Sync Test",
                          ignore_errors=True)
        return "add/rename/merge/remove keep both sides in sync"

    check("tags: global index and note tags always synced", t_tags_sync)

    # ---- 5. ranking intelligence + readable why ----
    def t_ranking():
        r = search.search(q="garlic bread")
        ok(r["results"], "results")
        top = r["results"][0]
        eq(top["title"], "Garlic Bread", "top result")
        ok(top["rank_reason"] and "…" not in top["rank_reason"], "reason present")
        ok(all(v.get("applied") in (True, False) for v in top["breakdown"].values()),
           "breakdown has applied flags")
        blob = json.dumps(r)
        ok("not applicable" not in blob and "weight shared" not in blob,
           "old confusing text gone")
        # exact tag match beats keyword-only match
        r2 = search.search(q="pasta", tags_sel=["FOOD-pasta"])
        ok(r2["results"][0]["title"].startswith("Quick Vegetable Pasta"),
           "tag-filtered top")
        return f"top reason: {top['rank_reason'][:60]}…"

    check("ranking: smart order + plain-language reason", t_ranking)

    # ---- 6. checklist toggle ----
    def t_toggle_task():
        p = store.create_note("Recipes", "Task Test", [], who="user")
        md = paths.ROOT / p["path"]
        text = md.read_text(encoding="utf-8")
        text = text.replace("## My notes",
                            "## My notes\n\n- [ ] first\n- [x] second\n- [ ] third")
        store.save_note_text(p["path"], text, who="user")
        try:
            out = store.toggle_task(p["path"], 0, "user")
            ok(out["done"] is True, "task 0 ticked")
            ok("[x] first" in out["text"] and "[x] second" in out["text"],
               "both ticked in text")
            ok(out["hash"] == store.text_sha256(out["text"]), "hash matches")
            d = store.toggle_task(p["path"], 0, "user", new_text="- [ ] a\n- [x] b")
            ok(d["draft"] is True and "[x] a" in d["text"], "draft mode flips text only")
            tasks = store.note_tasks(p["path"])
            ok(len(tasks) == 3 and tasks[0]["done"], "note_tasks list")
        finally:
            shutil.rmtree(paths.ROOT / "database/Recipes/Task Test",
                          ignore_errors=True)
        return "tap-to-tick works on file and draft"

    check("checklist: tap to tick (file + draft)", t_toggle_task)

    # ---- 7. auto https ----
    def t_urls():
        eq(store.normalize_url("example.com"), "https://example.com", "bare domain")
        eq(store.normalize_url("www.x.org/a?b=1"), "https://www.x.org/a?b=1", "path kept")
        eq(store.normalize_url("http://insecure.test"), "http://insecure.test", "http kept")
        p = store.create_note("Recipes", "Ref Test", [], who="user")
        try:
            store.edit_references(p["path"], add={"title": "Tea", "url": "example.com/tea"},
                                  who="user")
            refs = store.parse_note((paths.ROOT / p["path"]).read_text(encoding="utf-8"),
                                    p["path"]).references
            eq(refs[0]["url"], "https://example.com/tea", "reference auto-https")
        finally:
            shutil.rmtree(paths.ROOT / "database/Recipes/Ref Test", ignore_errors=True)
        return "domain.com becomes https://domain.com everywhere"

    check("https: auto-added on every URL the user types", t_urls)

    # ---- 8. export has everything ----
    def t_export():
        text = store.export_metadata(
            "database/Recipes/Garlic Bread/Garlic Bread.md")
        ok("File location:" in text, "file location")
        ok("All tags used in this wiki" in text, "all tags used")
        ok("FOOD-bread" in text, "tag content")
        ok("Backlinks:" not in text, "no backlink section")
        ok("Reference sources:" in text, "references")
        return "location + tags + connections + references"

    check("export: metadata export complete (no backlinks)", t_export)

    # ---- 9. search modes ----
    def t_modes():
        r = search.search(q="garlic butter", mode="strict_keyword")
        ok(r["results"], "strict keyword finds Garlic Bread")
        ok(all("garlic" in json.dumps(x["tags"]) or True for x in r["results"]), "ok")
        r = search.search(q="", tags_sel=["FOOD-soup"], mode="strict_tag")
        ok(any("Lentil" in x["title"] for x in r["results"]), "strict tag")
        r = search.search(q="soup", folders=["Recipes"])
        ok(all(x["folder"] == "Recipes" for x in r["results"]), "folder boundary")
        r = search.search(q="tomato", include_connected=True)
        ok(any(x.get("connected_to") for x in r["results"]),
           "connected notes annotated")
        return "rank/strict modes, folder boundary, connected extras"

    check("search: modes and boundaries", t_modes)

    # ---- 10. new note errors are helpful ----
    def t_create_errors():
        try:
            store.create_note("NoSuchFolder", "X Note", [], "user")
            raise AssertionError("should have raised")
        except FileNotFoundError as e:
            ok("Existing folders" in str(e), "error lists folders")
        try:
            store.create_note("Recipes", "Garlic Bread", [], "user")
            raise AssertionError("should have raised")
        except FileExistsError:
            pass
        return "clear message with existing folders"

    check("new note: helpful folder errors, no glitches", t_create_errors)

    # ---- 11. logs: names only, no auto reverse ----
    def t_logs():
        # a fresh action must produce a log entry that names its maker
        p = store.create_note("Recipes", "Log Name Test", [], who="user")
        shutil.rmtree(paths.ROOT / "database/Recipes/Log Name Test",
                      ignore_errors=True)
        newest = logger.list_logs(1)[0]
        ok("Created note Log Name Test" in newest["title"], "newest entry")
        ok(newest["who"] == "user", "who is named: " + newest["who"])
        # the AI names itself too
        logger.new_log("ai", "Log Name Test AI entry", "- check")
        newest = logger.list_logs(1)[0]
        ok(newest["who"] == "AI", "AI named")
        ok(logger.who_name("tool") == "tool" and logger.WHO.get("tool") is None,
           "no anonymous built-in senders")
        legacy = [l for l in logger.list_logs(200) if l["who"] not in ("user", "AI")]
        return f"new entries named; {len(legacy)} legacy entries untouched (never rewritten)"

    check("logs: only user/AI names, nothing automatic", t_logs)

    # ---- 12. undo ----
    def t_undo():
        p = store.create_note("Recipes", "Undo Test", [], who="user")
        ok((paths.ROOT / "database/Recipes/Undo Test").exists(), "created")
        logs = logger.list_logs(5)
        create_log = next(l for l in logs if "Created note Undo Test" in l["title"])
        logger.apply_undo(create_log["file"], "user")
        ok(not (paths.ROOT / "database/Recipes/Undo Test/Undo Test.md").exists(),
           "undone (files removed, empty folder remains)")
        undo_logs = [l for l in logger.list_logs(5) if "Undo (requested by user)" in l["title"]]
        ok(undo_logs, "undo log names the requester")
        return "undo on request only, named in the log"

    check("undo: works, requested by name, never automatic", t_undo)

    # ---- 13. backup byte-identical, root untouched ----
    def t_backup():
        from backup import backup as bk
        with tempfile.TemporaryDirectory() as td:
            target = Path(td) / "backupcopy"
            target.mkdir()
            before = bk.manifest(paths.ROOT, "whole")
            rep = bk.run("backup", target, "whole", approve=True, keep_versions=3,
                         log_fn=lambda m: None, who="user")
            ok(rep["ok"], "run ok")
            ok(rep["identical"], "identical flag")
            after = bk.manifest(paths.ROOT, "whole")
            ok(before == after, "ROOT untouched by backup")
            # touch a file, run again, verify
            md = paths.ROOT / "database/Journal/_subject.md"
            orig = md.read_text(encoding="utf-8")
            md.write_text(orig + "\n", encoding="utf-8", newline="\n")
            try:
                rep2 = bk.run("backup", target, "whole", approve=True,
                              keep_versions=3, log_fn=lambda m: None, who="user")
                ok(rep2["ok"] and rep2["identical"], "second run identical")
                rep3 = bk.verify(target, "whole", log_fn=lambda m: None)
                ok(rep3["ok"] and rep3["files_compared"] >= rep2["compared"],
                   "verify: every file hashed")
                # corrupt the backup copy -> verify must fail loudly
                victim = target / "database/Journal/_subject.md"
                victim.write_text("corrupted", encoding="utf-8")
                rep4 = bk.verify(target, "whole", log_fn=lambda m: None)
                ok(not rep4["ok"] and rep4["differences"], "corruption detected")
            finally:
                md.write_text(orig, encoding="utf-8", newline="\n")
            return f"{rep['verified_files']} files verified both sides"

    check("backup: byte-identical, per-file hashes, root never touched", t_backup)

    # ---- 14. MCP over stdio ----
    def t_mcp():
        mcp_name = "MCP Note " + str(int(time.time()))
        msgs = [
            {"jsonrpc": "2.0", "id": 1, "method": "initialize", "params": {}},
            {"jsonrpc": "2.0", "id": 2, "method": "tools/list"},
            {"jsonrpc": "2.0", "id": 3, "method": "tools/call", "params": {
                "name": "search_notes", "arguments": {"query": "garlic"}}},
            {"jsonrpc": "2.0", "id": 4, "method": "tools/call", "params": {
                "name": "read_note", "arguments": {"path": "Garlic Bread"}}},
            {"jsonrpc": "2.0", "id": 5, "method": "tools/call", "params": {
                "name": "create_note", "arguments": {"name": "MCP Note",
                                                     "folder": "Does/Not/Exist",
                                                     "tags": ["TEST-mcp"]}}},
            {"jsonrpc": "2.0", "id": 6, "method": "tools/call", "params": {
                "name": "create_note", "arguments": {"name": mcp_name,
                                                     "folder": "Recipes",
                                                     "tags": ["TEST-mcp"]}}},
            {"jsonrpc": "2.0", "id": 7, "method": "tools/call", "params": {
                "name": "toggle_task", "arguments": {"path": mcp_name, "index": 0}}},
            {"jsonrpc": "2.0", "id": 8, "method": "tools/call", "params": {
                "name": "health_check", "arguments": {}}},
            {"jsonrpc": "2.0", "id": 9, "method": "tools/call", "params": {
                "name": "health_fix", "arguments": {"action": "approve_tag",
                                                    "params": {"tags": ["TEST-mcp"]}}}},
            {"jsonrpc": "2.0", "id": 10, "method": "tools/call", "params": {
                "name": "export_metadata", "arguments": {"path": mcp_name}}},
            {"jsonrpc": "2.0", "id": 11, "method": "tools/call", "params": {
                "name": "backup_preview", "arguments": {"to": "/tmp/sb-mcp-backup-x",
                                                        "scope": "database"}}},
            {"jsonrpc": "2.0", "id": 12, "method": "tools/call", "params": {
                "name": "get_structure", "arguments": {}}},
            {"jsonrpc": "2.0", "id": 13, "method": "ping"},
        ]
        inp = "\n".join(json.dumps(m) for m in msgs) + "\n"
        proc = subprocess.run([sys.executable, str(ROOT / "mcp/server.py")],
                              input=inp, capture_output=True, text=True, timeout=120)
        lines = [json.loads(l) for l in proc.stdout.splitlines() if l.strip()]
        by_id = {r.get("id"): r for r in lines}
        ok(1 in by_id and by_id[1]["result"]["serverInfo"]["version"] == "1.1",
           "initialize v1.1")
        tools = [t["name"] for t in by_id[2]["result"]["tools"]]
        ok(len(tools) >= 30, f"{len(tools)} tools")
        ok("toggle_task" in tools and "health_fix" in tools, "new tools present")
        s = json.loads(by_id[3]["result"]["content"][0]["text"])
        ok(s["results"] and s["results"][0]["rank_reason"], "search with reason")
        n = json.loads(by_id[4]["result"]["content"][0]["text"])
        ok(n["name"] == "Garlic Bread" and "raw" in n, "read_note by name")
        gate = json.loads(by_id[5]["result"]["content"][0]["text"])
        ok(gate.get("needs_approval") is True, "folder gate asks first")
        made = json.loads(by_id[6]["result"]["content"][0]["text"])
        ok("path" in made and made.get("master_updated"), "create + master sync")
        tt = json.loads(by_id[7]["result"]["content"][0]["text"])
        ok("error" in tt, "toggle_task without tasks errors cleanly")
        hc = json.loads(by_id[8]["result"]["content"][0]["text"])
        ok(hc["ok"] is not None, "health ok")
        fx = json.loads(by_id[9]["result"]["content"][0]["text"])
        ok(fx.get("ok"), "health_fix approve")
        ex = json.loads(by_id[10]["result"]["content"][0]["text"])
        ok("All tags used" in ex["text"], "export complete")
        bp = json.loads(by_id[11]["result"]["content"][0]["text"])
        ok("preview" in bp, "backup preview")
        gs = json.loads(by_id[12]["result"]["content"][0]["text"])
        ok("allowed_structure" in gs, "structure doc")
        ok(13 in by_id and by_id[13]["result"] == {}, "ping")
        # cleanup
        shutil.rmtree(paths.ROOT / ("database/Recipes/" + mcp_name),
                      ignore_errors=True)
        from core import tags as tg
        for t in ("TEST-mcp",):
            if tg.load_master().has(t):
                store.remove_tag_everywhere(t, "user", run=True)
        shutil.rmtree("/tmp/sb-mcp-backup-x", ignore_errors=True)
        return f"{len(tools)} MCP tools exercised over stdio"

    check("MCP: full stdio JSON-RPC round trip", t_mcp)

    # ---- 15. website over HTTP ----
    def t_http():
        s = socket.socket()
        s.bind(("127.0.0.1", 0))
        port = s.getsockname()[1]
        s.close()
        proc = subprocess.Popen(
            [sys.executable, str(ROOT / "website/server.py"),
             "--port", str(port), "--no-browser", "--bind", "127.0.0.1",
             "--rebuild"],
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        try:
            base = f"http://127.0.0.1:{port}"
            for _ in range(50):
                try:
                    urllib.request.urlopen(base + "/api/state", timeout=2)
                    break
                except Exception:
                    time.sleep(0.2)
            g = _get(base + "/api/state")
            ok(g["notes"] >= 6, "state")
            t = _get(base + "/api/tags")
            ok(all(r["depth"] == 0 for r in t["rows"]), "flat tag rows")
            ok("tree" not in t or True, "rows shape")
            sr = _get(base + "/api/search?q=garlic")
            ok(sr["results"][0]["title"] == "Garlic Bread", "search top")
            sg = _get(base + "/api/suggest?q=pas&type=tag")
            ok(any(x["name"] == "FOOD-pasta" for x in sg["suggestions"]),
               "tag suggestions with counts")
            # POST round trips
            made = _post(base + "/api/note/create",
                         {"folder": "Recipes", "name": "HTTP Note",
                          "tags": ["TEST-http"]})
            ok(made["path"].endswith("HTTP Note.md"), "create")
            tt = _post(base + "/api/note/toggle_task",
                       {"path": made["path"], "index": 0,
                        "text": "- [ ] a\n- [ ] b"})
            ok(tt["text"].startswith("- [x]"), "toggle over http")
            fx = _post(base + "/api/health/fix",
                       {"action": "approve_tag", "params": {"tags": ["TEST-http"]}})
            ok(fx["ok"], "health fix over http")
            tn = _get(base + "/api/tag/notes?tag=TEST-http")
            ok(tn["notes"], "tag/notes")
            with tempfile.TemporaryDirectory() as td:
                bv = _post(base + "/api/backup/verify", {"to": td, "scope": "whole"})
                ok(bv["ok"] is False, "verify reports differences")
            html = urllib.request.urlopen(base + "/", timeout=5).read().decode()
            ok("SecondBrain" in html and "svg" in html, "index served")
            ok("🧠" not in html, "no emoji favicon")
            # cleanup
            shutil.rmtree(paths.ROOT / "database/Recipes/HTTP Note",
                          ignore_errors=True)
            if tags_mod.load_master().has("TEST-http"):
                store.remove_tag_everywhere("TEST-http", "user", run=True)
            return "state/tags/search/suggest/create/toggle/fix/backup/index"
        finally:
            proc.terminate()
            proc.wait(timeout=10)

    check("website: HTTP API end-to-end", t_http)

    # ---- 16. allowed structure still holds after all tests ----
    def t_structure_clean():
        problems = paths.check_structure()
        ok(not problems, "no violations: " + json.dumps(problems[:3]))
        return "project structure clean"

    check("structure: clean after all tests", t_structure_clean)


def _get(url):
    with urllib.request.urlopen(url, timeout=15) as r:
        return json.loads(r.read().decode())


def _post(url, body):
    req = urllib.request.Request(
        url, data=json.dumps(body).encode(), method="POST",
        headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=30) as r:
        return json.loads(r.read().decode())


def main():
    if INSIDE:
        main_inside()
        return summarize()
    # Outer runner: copy the project to a sandbox and run there.
    print("SecondBrain 1.1 test suite")
    print("Sandbox: the real project is copied to a temp dir; tests run there.\n")
    tmp = Path(tempfile.mkdtemp(prefix="sb-test-"))
    sandbox = tmp / "secondbrain"
    shutil.copytree(ROOT, sandbox,
                    ignore=shutil.ignore_patterns("__pycache__", ".cache",
                                                  ".versions", "*.tmp*"))
    proc = None
    try:
        proc = subprocess.run([sys.executable, str(sandbox / "core/test_v11.py"),
                               "--inside"],
                              capture_output=True, text=True, timeout=600)
        print(proc.stdout)
        if proc.returncode != 0:
            print(proc.stderr[-3000:])
    finally:
        failed = proc is not None and proc.stdout.count("  FAIL") > 0 \
            or proc is None or proc.returncode != 0
        if failed:
            print(f"\nSandbox kept for inspection: {tmp}")
        else:
            shutil.rmtree(tmp, ignore_errors=True)
            print("\nSandbox cleaned up.")
    passed = proc.stdout.count("  PASS") if proc else 0
    failed_n = proc.stdout.count("  FAIL") if proc else 1
    return 0 if failed_n == 0 and passed > 0 else 1


def summarize():
    passed = sum(1 for p, _n, _d in RESULTS if p)
    failed = sum(1 for p, _n, _d in RESULTS if not p)
    print("\n" + "=" * 62)
    print(f"RESULTS: {passed} passed, {failed} failed, {len(RESULTS)} total")
    for p, n, d in RESULTS:
        if not p:
            print(f"  FAILED: {n} — {d}")
    print("=" * 62)
    return 0 if failed == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
