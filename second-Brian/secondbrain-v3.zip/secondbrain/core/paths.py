"""SecondBrain core: project layout, name rules and allowed structure.

The allowed structure (spec 16) is enforced here. Every tool refuses to
create anything outside it, and the health check reports violations.
"""
from __future__ import annotations

import re
import unicodedata
from pathlib import Path

from .textutil import key_of  # noqa: F401  (re-exported for convenience)

# --------------------------------------------------------------------------
# Project layout
# --------------------------------------------------------------------------

def project_root() -> Path:
    """secondbrain/ root (the folder that contains core/)."""
    here = Path(__file__).resolve().parent      # .../secondbrain/core
    root = here.parent
    if (root / "core").exists() and (root / "database").exists():
        return root
    for cand in [here, *here.parents]:
        if (cand / "core").exists() and (cand / "database").exists():
            return cand
    return root


ROOT = project_root()
DATABASE = ROOT / "database"
INBOX = ROOT / "inbox"
LOGS = ROOT / "logs"
CORE = ROOT / "core"
MCP = ROOT / "mcp"
WEBSITE = ROOT / "website"
BACKUP = ROOT / "backup"
CACHE = CORE / ".cache"

ROOT_FILES = ["README.md", "SKILL.md", "StructureOFnotes.md", "_tags.md",
              "FIXES.md"]
TOP_FOLDERS = ["database", "inbox", "logs", "core", "mcp", "website", "backup"]

IMAGE_EXTS = {".png", ".jpg", ".jpeg", ".gif", ".webp", ".svg", ".bmp"}

FORBIDDEN_NAME_CHARS = re.compile(r'[\\/:*?"<>|\x00-\x1f]')

# Source files of the project (named in README.md). Everything else in these
# folders is a structure violation.
CORE_FILES = [
    "__init__.py", "paths.py", "textutil.py", "tags.py", "parser.py",
    "store.py", "logger.py", "indexer.py", "search.py", "healthcheck.py",
    "images.py", "test_ranking.py", "test_v11.py", "settings.json",
]
# v1.2: the UI is a compiled React (shadcn/ui) app. Sources live in
# website/app, the build output in website/static/assets.
WEBSITE_FILES = ["server.py"]
WEBSITE_FOLDERS = ["static", "app"]           # allowed folders inside website/
WEBSITE_STATIC = ["index.html", "favicon.svg"]  # top-level static files
WEBSITE_STATIC_DIRS = ["assets", "vendor"]      # allowed folders inside static/
WEBSITE_APP_META = {"package.json", "package-lock.json", "tsconfig.json", "tsconfig.tsbuildinfo",
                    "vite.config.ts", "tailwind.config.js", "postcss.config.js",
                    "index.html", "deploy.sh"}
WEBSITE_APP_DIRS = {"src", "node_modules", "dist"}
MCP_FILES = ["server.py"]
BACKUP_FILES = ["backup.py"]


# --------------------------------------------------------------------------
# Name rules (spec 17: safe on Windows, macOS, Linux)
# --------------------------------------------------------------------------

def clean_name(name: str) -> str:
    """Normalize a note/folder display name. Raises ValueError when the
    name cannot be used on every operating system."""
    name = unicodedata.normalize("NFC", (name or "").strip())
    name = re.sub(r"\s+", " ", name)
    if not name or name in {".", ".."}:
        raise ValueError("Empty name is not allowed.")
    if FORBIDDEN_NAME_CHARS.search(name):
        raise ValueError('Names may not contain \\ / : * ? " < > | or control characters.')
    if name.endswith((" ", ".", ":")):
        name = name.rstrip(" .:")
    if not name:
        raise ValueError("Empty name is not allowed.")
    if len(name) > 120:
        raise ValueError("Name is longer than 120 characters.")
    return name


def rel(path: Path) -> str:
    """Path relative to the project root, always with forward slashes."""
    try:
        return path.resolve().relative_to(ROOT).as_posix()
    except ValueError:
        return str(path)


def safe_join(base: Path, *parts: str) -> Path:
    """Join parts under base and refuse any escape from base (no ..)."""
    p = base
    for part in parts:
        part = (part or "").strip().strip("/")
        if not part or part == "." or part == ".." or FORBIDDEN_NAME_CHARS.search(part):
            raise ValueError(f"Unsafe path element: {part!r}")
        p = p / part
    return p


# --------------------------------------------------------------------------
# Allowed-structure check
# --------------------------------------------------------------------------

def is_image(name: str) -> bool:
    return Path(name).suffix.lower() in IMAGE_EXTS


def check_structure() -> list[dict]:
    """Return a list of {path, problem} for every file or folder that is not
    on the allowed list. Used by the health check page and health_check tool."""
    problems: list[dict] = []

    def add(p: Path, problem: str):
        problems.append({"path": rel(p), "problem": problem})

    for child in sorted(ROOT.iterdir()):
        name = child.name
        if child.is_file():
            if name not in ROOT_FILES:
                add(child, "File not allowed at the top level (allowed: " + ", ".join(ROOT_FILES) + ")")
        elif child.is_dir():
            if name not in TOP_FOLDERS:
                add(child, "Folder not allowed at the top level (allowed: " + ", ".join(TOP_FOLDERS) + ")")
        else:
            add(child, "Symlinks and special files are not part of the structure")

    _check_database(problems)
    _check_flat(INBOX, problems)
    _check_logs(problems)
    _check_code_folder(CORE, CORE_FILES, {".cache"}, problems)
    _check_code_folder(MCP, MCP_FILES, set(), problems)
    _check_code_folder(BACKUP, BACKUP_FILES, set(), problems)
    _check_website(problems)
    return problems


def _check_website(problems: list[dict]):
    def add(p: Path, problem: str):
        problems.append({"path": rel(p), "problem": problem})

    for child in sorted(WEBSITE.iterdir()):
        if child.is_dir():
            if child.name not in WEBSITE_FOLDERS:
                add(child, "Only static/ and app/ are allowed inside website/")
            elif child.name == "static":
                for f in sorted(child.iterdir()):
                    if f.is_dir():
                        if f.name not in WEBSITE_STATIC_DIRS:
                            add(f, "Unexpected folder inside website/static/ (allowed: " + ", ".join(WEBSITE_STATIC_DIRS) + ")")
                    else:
                        if f.name not in WEBSITE_STATIC:
                            add(f, "Unexpected file inside website/static/ (allowed: " + ", ".join(WEBSITE_STATIC) + " and the assets/ + vendor/ folders)")
            else:
                # website/app: UI sources (built with npm; node_modules and
                # dist are tooling/output and allowed)
                for f in sorted(child.rglob("*")):
                    rp = f.relative_to(child)
                    if f.is_dir():
                        if rp.parts[0] not in WEBSITE_APP_DIRS:
                            add(f, "Unexpected folder inside website/app/")
                    else:
                        if rp.parts[0] in WEBSITE_APP_DIRS:
                            continue
                        if len(rp.parts) == 1 and f.name in WEBSITE_APP_META:
                            continue
                        add(f, "Unexpected file inside website/app/")
        else:
            if child.name not in WEBSITE_FILES:
                add(child, "Unexpected file inside website/ (allowed: " + ", ".join(WEBSITE_FILES) + ")")


def _check_code_folder(folder: Path, allowed: list[str], allowed_dirs: set, problems: list[dict]):
    if not folder.exists():
        return

    def add(p: Path, problem: str):
        problems.append({"path": rel(p), "problem": problem})

    for child in sorted(folder.iterdir()):
        if child.is_dir():
            if child.name not in allowed_dirs:
                add(child, f"Folder not allowed inside {folder.name}/")
        elif child.name not in allowed:
            add(child, f"File not named in README.md (allowed here: {', '.join(allowed)})")


def _check_database(problems: list[dict]):
    if not DATABASE.exists():
        return
    _check_subject_folder(DATABASE, problems)


def _check_subject_folder(folder: Path, problems: list[dict]):
    """Subject folders nest to any depth (spec 2.1). A folder that holds a
    '<name>.md' file named after itself is a note folder; anything else is a
    subject folder and is recursed into."""

    def add(p: Path, problem: str):
        problems.append({"path": rel(p), "problem": problem})

    for child in sorted(folder.iterdir()):
        if child.is_file():
            if child.name == "_subject.md":
                continue
            add(child, "Only note folders and _subject.md are allowed inside a subject folder")
        elif child.is_dir():
            if (child / (child.name + ".md")).exists():
                _check_note_folder(child, problems)
            else:
                _check_subject_folder(child, problems)


def _check_note_folder(note_dir: Path, problems: list[dict]):
    def add(p: Path, problem: str):
        problems.append({"path": rel(p), "problem": problem})

    expected_md = note_dir.name + ".md"
    found_md = False
    for child in sorted(note_dir.iterdir()):
        if child.is_file():
            if child.name == expected_md:
                found_md = True
            elif child.name == "tags.txt":
                continue
            else:
                add(child, "A note folder may only contain '<Note Name>.md' and 'tags.txt'")
        elif child.is_dir():
            if child.name == "attachments":
                for img in sorted(child.iterdir()):
                    if img.is_file() and not is_image(img.name):
                        add(img, "attachments/ holds image files only")
                    elif img.is_dir():
                        add(img, "Folders are not allowed inside attachments/")
            else:
                add(child, "Only attachments/ is allowed inside a note folder")
    if not found_md and any(note_dir.iterdir()):
        add(note_dir, "Note folder is missing its '<Note Name>.md' file")


def _check_flat(folder: Path, problems: list[dict]):
    if not folder.exists():
        return

    def add(p: Path, problem: str):
        problems.append({"path": rel(p), "problem": problem})

    for child in sorted(folder.rglob("*")):
        if child.is_dir():
            add(child, "Folders are not allowed inside inbox/")
        elif child.suffix.lower() not in {".md", ".txt"}:
            add(child, "Only .md and .txt files are allowed inside inbox/")


def _check_logs(problems: list[dict]):
    if not LOGS.exists():
        return

    def add(p: Path, problem: str):
        problems.append({"path": rel(p), "problem": problem})

    pat = re.compile(r"^\d{4}-\d{2}-\d{2}_\d{2}-\d{2}-\d{2}_.+\.md$")
    for child in sorted(LOGS.iterdir()):
        if child.is_file() and pat.match(child.name):
            continue
        add(child, "logs/ holds only files named YYYY-MM-DD_HH-MM-SS_<title>.md")
