"""SecondBrain core: logs and undo.

After every edit one new log file is created in logs/:
    YYYY-MM-DD_HH-MM-SS_<title>.md
with the full date and time, WHO made the change (always a name: `user`
`AI`, or the name the AI sends), the title, a detailed account (every file
touched, before/after, the reason) and an :::undo block holding everything
needed to reverse the change.

v1.1 logging rules:
- only the user or the AI create log entries - there is no background or
  automatic logging anywhere;
- every entry carries the maker's name;
- nothing is ever reversed automatically: an undo happens only when the
  user clicks Undo (or the AI calls undo_change for the user), and the
  resulting log entry names who asked for it.
Log files are never edited or deleted after they are written.
"""
from __future__ import annotations

import datetime as _dt
import json
import re
import shutil
from pathlib import Path

from . import paths

WHO = {"user": "user", "ai": "AI"}


def who_name(who: str) -> str:
    """Every log names its maker. Unknown senders are named as they sent
    themselves; the two built-in senders are `user` and `AI`."""
    if not who:
        return "user"
    return WHO.get(who, who)


def _slug(title: str) -> str:
    s = re.sub(r"[^A-Za-z0-9 _-]", "", title).strip().replace(" ", "_")
    return s[:60] or "Change"


def new_log(who: str, title: str, details: str, undo: dict | None = None,
            when: _dt.datetime | None = None) -> str:
    """Write one log file and return its name. undo is a JSON-serializable
    dict describing how to reverse the change."""
    now = when or _dt.datetime.now()
    name = now.strftime("%Y-%m-%d_%H-%M-%S") + "_" + _slug(title) + ".md"
    path = paths.LOGS / name
    paths.LOGS.mkdir(exist_ok=True)
    body = [
        f"# {title}",
        "",
        f"- **When:** {now.strftime('%Y-%m-%d %H:%M:%S')}",
        f"- **Who:** {who_name(who)}",
        f"- **Title:** {title}",
        "",
        "## What was done",
        "",
        details.strip(),
        "",
    ]
    if undo:
        body += [
            "## How to undo",
            "",
            ":::undo",
            json.dumps(undo, ensure_ascii=False, indent=1),
            ":::",
            "",
        ]
    body += ["---", "", "Log files are never edited or deleted after they are written.", ""]
    # Atomic write: temporary file first, then rename (spec 18).
    tmp = path.with_suffix(".tmp")
    tmp.write_text("\n".join(body), encoding="utf-8", newline="\n")
    tmp.replace(path)
    return name


# --------------------------------------------------------------------------
# Undo
# --------------------------------------------------------------------------

def _read_undo(log_path: Path) -> dict:
    text = log_path.read_text(encoding="utf-8")
    m = re.search(r":::undo\n(.*?)\n:::", text, re.DOTALL)
    if not m:
        raise ValueError("This log has no undo information.")
    return json.loads(m.group(1))


def _atomic_write(path: Path, data: str):
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp")
    tmp.write_text(data, encoding="utf-8", newline="\n")
    tmp.replace(path)


def apply_undo(log_name: str, who: str = "user") -> str:
    """Reverse the change recorded in a log file. Nothing ever reverses
    itself: this runs only when the user (or the AI on the user's behalf)
    asks for it. The undo log entry names who requested it."""
    log_path = paths.LOGS / log_name
    if not log_path.exists():
        raise FileNotFoundError(f"Log {log_name} not found.")
    undo = _read_undo(log_path)
    title = undo.get("title", "change")
    steps = undo.get("steps", [])
    details = [f"Undo of log `{log_name}` ({title}).",
               f"- Requested by: {who_name(who)} (nothing is reversed automatically).",
               ""]

    for step in reversed(steps):
        op = step.get("op")
        if op == "write":
            # step holds path, before (old content or null), after
            p = paths.ROOT / step["path"]
            if step.get("before") is None:
                if p.exists():
                    p.unlink()
                    details.append(f"- Removed `{step['path']}` (it did not exist before).")
            else:
                _atomic_write(p, step["before"])
                details.append(f"- Restored previous content of `{step['path']}`.")
        elif op == "move":
            src = paths.ROOT / step["to"]      # the change moved from->to; undo moves back
            dst = paths.ROOT / step["from"]
            if src.exists():
                dst.parent.mkdir(parents=True, exist_ok=True)
                shutil.move(str(src), str(dst))
                details.append(f"- Moved `{step['to']}` back to `{step['from']}`.")
        elif op == "mkdir":
            p = paths.ROOT / step["path"]
            if p.exists() and not any(p.iterdir()):
                p.rmdir()
                details.append(f"- Removed empty folder `{step['path']}`.")
        elif op == "copy":
            src = paths.ROOT / step["from"]
            dst = paths.ROOT / step["to"]
            if dst.exists():
                dst.unlink()
                details.append(f"- Removed copy `{step['to']}`.")

    return new_log(who, f"Undo (requested by {who_name(who)}): {title}",
                   "\n".join(details),
                   undo={"title": f"Undo: {title}", "steps": [
                       {"op": "note", "text": f"Redo by re-applying log {log_name}"}]})


def list_logs(limit: int = 100) -> list[dict]:
    """Newest first. Each row: file name, when, who, title, undoable."""
    out = []
    if not paths.LOGS.exists():
        return out
    pat = re.compile(r"^(\d{4}-\d{2}-\d{2})_(\d{2})-(\d{2})-(\d{2})_(.+)\.md$")
    files = [f for f in paths.LOGS.iterdir() if f.is_file() and pat.match(f.name)]
    # newest first; entries written within the same second keep their true
    # creation order via the file's mtime
    files.sort(key=lambda f: (f.name[:19], f.stat().st_mtime), reverse=True)
    for f in files[:limit]:
        m = pat.match(f.name)
        text = f.read_text(encoding="utf-8")
        who_m = re.search(r"\*\*Who:\*\* (.+)", text)
        title_m = re.search(r"^# (.+)$", text, re.MULTILINE)
        out.append({
            "file": f.name,
            "date": f"{m.group(1)} {m.group(2)}:{m.group(3)}:{m.group(4)}",
            "who": (who_m.group(1).strip() if who_m else "?"),
            "title": (title_m.group(1).strip() if title_m else m.group(5).replace("_", " ")),
            "undoable": ":::undo" in text,
        })
    return out


def read_log(log_name: str) -> str:
    path = paths.LOGS / Path(log_name).name
    if not path.exists():
        raise FileNotFoundError(f"Log {log_name} not found.")
    return path.read_text(encoding="utf-8")
