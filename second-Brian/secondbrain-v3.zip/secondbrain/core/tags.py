"""SecondBrain core: tags (v1.1).

ALL TAGS ARE INDEPENDENT. There is no sub-tag hierarchy any more: a tag is
one flat name, `FOOD-pasta` and `FOOD` have no relationship at all. Dashes
and underscores are simply characters in the name. Matching ignores case.

tags.txt holds the comma separated tags of one note. _tags.md is the master
vocabulary: approved tags (flat list, grouped only visually by major),
per-tag synonyms, a general synonym map and a Proposed tags section.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field

from . import paths
from .textutil import key_of, levenshtein_leq1, normalize

TAG_RE = re.compile(r"^[A-Za-z0-9_]+(?:-[A-Za-z0-9_]+)*$")


class TagError(ValueError):
    pass


def validate_tag(tag: str) -> str:
    tag = (tag or "").strip()
    if not tag:
        raise TagError("Empty tag.")
    if not TAG_RE.match(tag):
        raise TagError(
            f"Tag {tag!r} is not valid. Use letters, digits and underscores; "
            "dashes may separate words; spaces are written as underscores; no commas.")
    return tag


def major_of(tag: str) -> str:
    """Display helper only: the part before the first dash. It carries NO
    hierarchy meaning - every tag is independent."""
    return validate_tag(tag).split("-")[0]


def norm_tag(tag: str) -> str:
    return (tag or "").strip()


def same_tag(a: str, b: str) -> bool:
    return key_of(a) == key_of(b)


def relation(note_tag: str, query_tag: str) -> float | None:
    """Score of a (note tag, query tag) pair. Tags are independent, so only
    an exact (case-insensitive) match counts: 1.0, otherwise None."""
    return 1.0 if key_of(note_tag) == key_of(query_tag) else None


# --------------------------------------------------------------------------
# tags.txt
# --------------------------------------------------------------------------

def parse_tags_txt(text: str) -> list[str]:
    """Parse a tags.txt body: comma separated tags, one or more per line."""
    tags: list[str] = []
    seen: set[str] = set()
    for chunk in re.split(r"[,\n]", text or ""):
        t = chunk.strip()
        if not t:
            continue
        validate_tag(t)
        k = key_of(t)
        if k not in seen:
            seen.add(k)
            tags.append(t)
    return tags


def render_tags_txt(tags: list[str]) -> str:
    return ", ".join(tags) + "\n"


# --------------------------------------------------------------------------
# _tags.md master vocabulary
# --------------------------------------------------------------------------

@dataclass
class MasterTags:
    approved: dict[str, dict] = field(default_factory=dict)   # key -> {tag, synonyms, major}
    proposed: list[str] = field(default_factory=list)
    general_synonyms: dict[str, list[str]] = field(default_factory=dict)
    order: list[str] = field(default_factory=list)            # approved tags in file order

    def has(self, tag: str) -> bool:
        return key_of(tag) in self.approved

    def all_tags(self) -> list[str]:
        return [v["tag"] for v in self.approved.values()]


def parse_master(text: str) -> MasterTags:
    mt = MasterTags()
    section = None
    current_major = None
    for raw in (text or "").splitlines():
        line = raw.strip()
        if not line:
            continue
        low = line.lower()
        if low.startswith("## "):
            title = low[3:].strip()
            section = ("proposed" if "proposed" in title
                       else "synonyms" if "synonym" in title
                       else "approved")
            current_major = None
            continue
        if section == "approved":
            if low.startswith("### "):
                current_major = line[4:].strip()
                continue
            if line.startswith("- "):
                entry = line[2:].strip()
                tag, syn = entry, []
                if ":" in entry:
                    tag, syn_part = entry.split(":", 1)
                    tag = tag.strip()
                    syn = [s.strip() for s in syn_part.split(",") if s.strip()]
                try:
                    validate_tag(tag)
                except TagError:
                    continue
                k = key_of(tag)
                if k not in mt.approved:
                    mt.approved[k] = {
                        "tag": tag, "synonyms": syn,
                        "major": current_major or major_of(tag),
                    }
                    mt.order.append(k)
            continue
        if section == "proposed":
            if line.startswith("- "):
                t = line[2:].strip().split(":")[0].strip()
                try:
                    validate_tag(t)
                    if t not in mt.proposed:
                        mt.proposed.append(t)
                except TagError:
                    pass
            continue
        if section == "synonyms":
            if ":" in line and not line.startswith(("#", "<")):
                word, syn = line.split(":", 1)
                w = normalize(word)
                syns = [normalize(s) for s in syn.split(",") if normalize(s)]
                if w and syns:
                    mt.general_synonyms.setdefault(w, [])
                    for s in syns:
                        if s not in mt.general_synonyms[w]:
                            mt.general_synonyms[w].append(s)
    return mt


def load_master() -> MasterTags:
    return parse_master((paths.ROOT / "_tags.md").read_text(encoding="utf-8"))


def tag_synonym_to_tag(mt: MasterTags) -> dict[str, str]:
    """Map every approved tag name and every per-tag synonym (normalized) to
    the canonical tag."""
    out: dict[str, str] = {}
    for v in mt.approved.values():
        names = [v["tag"]] + list(v["synonyms"])
        for name in names:
            n = normalize(name).replace(" ", "-")
            out.setdefault(n, v["tag"])
            out.setdefault(normalize(name).replace(" ", "_"), v["tag"])
    return out


def add_to_master(tags: list[str], who: str = "user") -> list[str]:
    """Add tags to the Approved tags list in _tags.md so the global tag
    index and the tags on notes are ALWAYS in sync. A tag added to any note
    through the website immediately exists globally. Returns the tags that
    were actually added."""
    new = []
    mt = load_master()
    for t in tags or []:
        try:
            t = validate_tag(t)
        except TagError:
            continue
        if not mt.has(t) and all(key_of(t) != key_of(p) for p in mt.proposed):
            new.append(t)
        elif all(key_of(t) != key_of(p) for p in mt.proposed):
            pass
    # a tag sitting in Proposed that the user applies directly is approved
    promoted = [t for t in (tags or [])
                if any(key_of(validate_tag(t)) == key_of(p) for p in mt.proposed)]
    if not new and not promoted:
        return []
    master_path = paths.ROOT / "_tags.md"
    old = master_path.read_text(encoding="utf-8")
    text = old
    if promoted:
        text = _drop_proposed(text, promoted)
    if new:
        text = _insert_approved(text, new)
    if text != old:
        from . import logger
        paths.ROOT  # noqa: B018 - keep import order obvious
        logger.new_log(who, "Updated master tag list",
                       "- Tags added to Approved tags in `_tags.md`: "
                       + ", ".join(new + promoted)
                       + "\n- Reason: keep the global tag index in sync with note tags.",
                       undo={"title": "Update master tag list", "steps": [
                           {"op": "write", "path": "_tags.md", "before": old}]})
        atomic_master_write(master_path, text)
    return new + promoted


def _drop_proposed(text: str, tags: list[str]) -> str:
    keys = {key_of(t) for t in tags}
    out = []
    in_proposed = False
    for ln in text.splitlines():
        s = ln.strip()
        if s.lower().startswith("## "):
            in_proposed = "proposed" in s.lower()
        if in_proposed and s.startswith("- "):
            cand = s[2:].split(":")[0].split(",")[0].strip()
            if key_of(cand) in keys:
                continue
        out.append(ln)
    return "\n".join(out)


def _insert_approved(text: str, tags: list[str]) -> str:
    """Insert tags under their major heading (visual grouping only)."""
    lines = text.splitlines()
    out: list[str] = []
    inserted = set()
    done_major = False
    for ln in lines:
        out.append(ln)
        m = re.match(r"^###\s+(\S+)", ln.strip())
        if m:
            major = m.group(1)
            here = [t for t in tags if t not in inserted
                    and major_of(t).lower() == major.lower()]
            for t in here:
                out.append(f"- {t}")
                inserted.add(t)
            done_major = done_major or bool(here)
    rest = [t for t in tags if t not in inserted]
    if rest:
        final = []
        placed = False
        for i, ln in enumerate(out):
            final.append(ln)
            if not placed and re.match(r"(?im)^## Approved tags\s*$", ln.strip()):
                for t in rest:
                    final.append(f"\n### {major_of(t)}\n- {t}" if not _major_seen(out, t) else f"- {t}")
                placed = True
        out = final
    return "\n".join(out)


def _major_seen(lines: list[str], tag: str) -> bool:
    pat = re.compile(r"^###\s+(\S+)", re.IGNORECASE)
    for ln in lines:
        m = pat.match(ln.strip())
        if m and m.group(1).lower() == major_of(tag).lower():
            return True
    return False


def atomic_master_write(path: Path, text: str):
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp-write")
    tmp.write_text(text, encoding="utf-8", newline="\n")
    tmp.replace(path)


# --------------------------------------------------------------------------
# Auto tag extractor
# --------------------------------------------------------------------------

def extract_all_notes_tags() -> dict:
    """Scan the whole wiki and build the flat, independent list of every tag
    in use, with counts; flag unapproved tags and near-duplicates."""
    mt = load_master()
    used: dict[str, int] = {}
    per_note: dict[str, list[str]] = {}
    for tags_file in sorted(paths.DATABASE.rglob("tags.txt")):
        tags = parse_tags_txt(tags_file.read_text(encoding="utf-8"))
        per_note[str(tags_file.parent.relative_to(paths.DATABASE))] = tags
        for t in tags:
            used[t] = used.get(t, 0) + 1

    unapproved = sorted(t for t in used if not mt.has(t))

    # Near-duplicates: two different tags within one letter of each other.
    near: list[dict] = []
    keys = sorted(used)
    norm_of = {t: normalize(t.replace("_", " ").replace("-", " ")) for t in keys}
    for i, a in enumerate(keys):
        for b in keys[i + 1:]:
            if key_of(a) == key_of(b):
                continue
            if levenshtein_leq1(norm_of[a].replace(" ", ""),
                                norm_of[b].replace(" ", "")):
                near.append({"tags": [a, b]})

    missing_master = sorted(t for t in used if not mt.has(t))
    used_once = sorted(t for t, c in used.items() if c == 1)
    flat = sorted(used, key=lambda x: key_of(x))
    return {
        "tags": flat,
        "counts": used,
        # v1.1: the hierarchy tree is gone. `tree` and `rows` are a FLAT list
        # of independent tags (depth is always 0).
        "tree": {"children": {t: {"count": used[t], "children": {}} for t in flat}},
        "rows": [{"tag": t, "count": used[t], "depth": 0} for t in flat],
        "unapproved": unapproved,
        "near_duplicates": near,
        "missing_from_master": missing_master,
        "used_once": used_once,
        "proposed": mt.proposed,
        "per_note": per_note,
        "approved_unused": [v["tag"] for v in mt.approved.values()
                            if key_of(v["tag"]) not in {key_of(t) for t in used}],
    }


def tree_to_list(tree: dict, prefix: str = "") -> list[dict]:
    """Flatten the (now flat) tag structure into rows for the UI. Kept for
    compatibility: every row is an independent tag at depth 0."""
    rows = []
    for name in sorted(tree.get("children", {}), key=str.casefold):
        node = tree["children"][name]
        rows.append({"tag": name, "count": node.get("count", 0), "depth": 0})
    return rows
