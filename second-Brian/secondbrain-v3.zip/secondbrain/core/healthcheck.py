"""SecondBrain core: the health check (v1.1).

Every check runs inside its own guard: a failing check can never crash the
whole health page again (the old `name 'add' is not defined` crash came
from the structure check). Each check returns {items, error} and the page
shows a Fix button next to everything the engine can repair on request:

- remove broken [[links]]            (fix: remove_broken_links)
- remove a stray attachment          (fix: remove_stray_attachment)
- fill in missing Created/Updated    (fix: fix_missing_dates)
- merge a near-duplicate tag pair    (fix: merge_tags)
- approve a tag missing from master  (fix: approve_tag)
- remove an empty tag from master    (fix: approve/none)

Notes without tags or connections are listed as gentle advice only.
v1.1: note verification was removed, so there is no unverified check.
"""
from __future__ import annotations

import datetime as _dt
import re

from . import indexer, paths, store, tags as tags_mod
from .textutil import key_of


def _guard(fn):
    """Run one check; capture both its items and any exception."""
    try:
        return {"items": fn(), "error": None}
    except Exception as e:                       # noqa: BLE001
        return {"items": [], "error": f"{type(e).__name__}: {e}"}


def health_check(idx: dict | None = None) -> dict:
    if idx is None:
        idx = indexer.load_index()
    extractor = tags_mod.extract_all_notes_tags()
    files = idx["files"]

    broken = [{"note": rp, "link": name}
              for rp, names in idx.get("broken_links", {}).items() for name in names]

    no_tags = [rp for rp, e in files.items() if not e["tags"]]
    no_connections = [rp for rp in files
                      if not idx["graph"].get(rp)
                      and not idx["backlinks"].get(rp)]
    no_meta = [rp for rp, e in files.items()
               if not e["meta"].get("created") or not e["meta"].get("updated")]

    stray = _stray_attachments(files)

    checks = {
        "broken_links": _guard(lambda: broken),
        "notes_without_tags": _guard(lambda: no_tags),
        "notes_without_connections": _guard(lambda: no_connections),
        "tags_used_once": _guard(lambda: extractor["used_once"]),
        "near_duplicate_tags": _guard(lambda: extractor["near_duplicates"]),
        "unapproved_tags": _guard(lambda: extractor["unapproved"]),
        "tags_missing_from_master": _guard(lambda: extractor["missing_from_master"]),
        "proposed_tags": _guard(lambda: extractor["proposed"]),
        "notes_without_dates": _guard(lambda: no_meta),
        "unreferenced_attachments": _guard(lambda: stray),
        "structure_problems": _guard(lambda: paths.check_structure()),
    }

    fixable = {
        "broken_links": "Remove the broken links from the notes.",
        "near_duplicate_tags": "Merge the pair into one tag.",
        "unapproved_tags": "Approve the tag into the master list.",
        "tags_missing_from_master": "Approve the tag into the master list.",
        "notes_without_dates": "Fill Created/Updated from the file dates.",
        "unreferenced_attachments": "Delete the stray file (kept in backup history).",
        "structure_problems": "Show the path so you can move it manually.",
    }
    summary = {k: (len(v["items"]) if v["error"] is None else -1)
               for k, v in checks.items()}
    return {
        "ok": all(v["error"] is None for v in checks.values()),
        "summary": summary,
        "checks": {k: {"items": v["items"], "error": v["error"],
                       "fixable": bool(fixable.get(k))}
                   for k, v in checks.items()},
        "fix_hints": fixable,
    }


def _stray_attachments(files: dict) -> list[dict]:
    """Unreferenced images (kept in backup history after crop/delete)."""
    stray_attachments = []
    for md in store.list_note_files():
        att = md.parent / "attachments"
        if not att.exists():
            continue
        used = set()
        text = md.read_text(encoding="utf-8")
        for m in re.finditer(r"\((?:attachments/)?([^)]+)\)", text):
            used.add(m.group(1).split("/")[-1])
        doc_m = re.search(r"Image:\s*(\S+)", text)
        if doc_m:
            used.add(doc_m.group(1).split("/")[-1])
        for img in att.iterdir():
            if img.is_file() and img.name not in used:
                stray_attachments.append({"note": paths.rel(md), "file": img.name,
                                          "reason": "image not referenced in the note"
                                                    " (kept as backup history)"})
    return stray_attachments


# --------------------------------------------------------------------------
# Fix actions (each one logs and can be undone from the log)
# --------------------------------------------------------------------------

def health_fix(action: str, params: dict, who: str = "user") -> dict:
    """Apply one repair from the health page. Every action is logged and
    undoable like any other edit."""
    if action == "remove_broken_links":
        note = params["note"]
        p = paths.ROOT / note
        text = p.read_text(encoding="utf-8")
        old = text
        for name in params.get("links") or []:
            text = re.sub(r"\[\[" + re.escape(name) + r"(\|[^\]]*)?\]\]",
                          name, text)
        if params.get("link"):
            text = re.sub(r"\[\[" + re.escape(params["link"]) + r"(\|[^\]]*)?\]\]",
                          params["link"], text)
        if text == old:
            return {"ok": True, "message": "Nothing to remove."}
        store.atomic_write(p, text)
        from . import logger
        logger.new_log(who, f"Removed broken links in {p.stem}",
                       f"- File: `{note}`\n- The [[links]] that pointed at notes "
                       "that do not exist were replaced by their plain words.",
                       undo={"title": f"Remove broken links in {p.stem}", "steps": [
                           {"op": "write", "path": note, "before": old}]})
        return {"ok": True}

    if action == "remove_stray_attachment":
        from . import images
        return images.delete_image(params["note"], params["file"], who)

    if action == "fix_missing_dates":
        note = params["note"]
        p = paths.ROOT / note
        st = p.stat()
        created = _dt.date.fromtimestamp(st.st_ctime).isoformat()
        updated = _dt.date.fromtimestamp(st.st_mtime).isoformat()
        return store.set_metadata(note, {"created": created, "updated": updated}, who)

    if action == "merge_tags":
        return store.merge_tags(params["from"], params["into"], who, run=True)

    if action == "approve_tag":
        tags = params.get("tags") or ([params["tag"]] if params.get("tag") else [])
        added = tags_mod.add_to_master(tags, who)
        return {"ok": True, "added": added,
                "message": (", ".join(added) + " approved.") if added
                else "Already approved."}

    raise ValueError(f"Unknown health fix action: {action!r}")
