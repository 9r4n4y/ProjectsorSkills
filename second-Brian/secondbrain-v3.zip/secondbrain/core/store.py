"""SecondBrain core: the store - every write operation in one place.

The website, the MCP server and the backup tool all edit files through this
module, so the librarian rules, logging and atomic writes behave the same
everywhere (spec 5, 6, 15, 17).
"""
from __future__ import annotations

import datetime as _dt
import hashlib
import json
import re
import shutil
from pathlib import Path

from . import logger, paths, tags as tags_mod
from .parser import (NoteDoc, WIKI_LINK_RE, extract_blocks, parse_note,
                     parse_quick_info, render_meta, split_sections)
from .textutil import key_of, normalize

SETTINGS_PATH = paths.CORE / "settings.json"

DEFAULT_SETTINGS = {
    "ranking_weights": {
        "tags": 0.34, "title": 0.24, "headings": 0.14,
        "neighbors": 0.12, "body": 0.10, "closeness": 0.06,
    },
    "coverage_base": 0.4,
    "synonym_weight": 0.7,
    "page_size": 20,
    "max_word_groups": 12,
    "typo_tolerance": True,
    "typo_min_length": 5,
    "closeness_window_tokens": 40,
    "bm25": {"k1": 1.5, "b": 0.75},
    "default_theme": "light",
    "server_port": 8765,
    "server_bind": "127.0.0.1",
    "open_browser_on_start": True,
    "backup_versions_to_keep": 10,
    "saved_searches": [],
    "recent_searches": [],
}


def load_settings() -> dict:
    if SETTINGS_PATH.exists():
        try:
            data = json.loads(SETTINGS_PATH.read_text(encoding="utf-8"))
        except json.JSONDecodeError:
            data = {}
    else:
        data = {}
    merged = dict(DEFAULT_SETTINGS)
    merged.update(data)
    return merged


def save_settings(settings: dict):
    SETTINGS_PATH.parent.mkdir(parents=True, exist_ok=True)
    tmp = SETTINGS_PATH.with_suffix(".tmp")
    tmp.write_text(json.dumps(settings, indent=2, ensure_ascii=False) + "\n",
                   encoding="utf-8", newline="\n")
    tmp.replace(SETTINGS_PATH)


def today() -> str:
    return _dt.date.today().isoformat()


def now_iso() -> str:
    return _dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def sha256_of(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def text_sha256(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def atomic_write(path: Path, data: str):
    """Write to a temporary file, then swap it in: a crash never leaves a
    half-written note (spec 18)."""
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp-write")
    tmp.write_text(data, encoding="utf-8", newline="\n")
    tmp.replace(path)


# --------------------------------------------------------------------------
# Reading helpers
# --------------------------------------------------------------------------

def note_md_path(note_rel: str) -> Path:
    """database/<folder>/<Name>/<Name>.md from any of:
    'database/<folder>/<Name>/<Name>.md' or 'database/<folder>/<Name>'."""
    p = (paths.ROOT / note_rel)
    if p.suffix == ".md":
        return p
    return p / (p.name + ".md")


def note_exists(name: str) -> Path | None:
    """Find a note by its unique file name (case-insensitive)."""
    k = key_of(name)
    if not k:
        return None
    for md in paths.DATABASE.rglob("*.md"):
        if md.name != "_subject.md" and key_of(md.stem) == k:
            return md
    return None


def list_note_files() -> list[Path]:
    return [md for md in paths.DATABASE.rglob("*.md")
            if md.name != "_subject.md" and md.parent.name == md.stem]


def is_private(folder: Path) -> bool:
    """A subject folder with 'Sensitivity: private' in _subject.md is
    hidden, locked and excluded from the index (spec 4)."""
    subj = folder / "_subject.md"
    if subj.exists():
        m = re.search(r"(?im)^\s*Sensitivity:\s*private\s*$", subj.read_text(encoding="utf-8"))
        if m:
            return True
    if folder == paths.DATABASE or paths.DATABASE in folder.parents:
        pass
    for parent in [folder, *folder.parents]:
        if parent == paths.DATABASE.parent:
            break
        if (parent / "_subject.md").exists() and parent != folder:
            m = re.search(r"(?im)^\s*Sensitivity:\s*private\s*$",
                          (parent / "_subject.md").read_text(encoding="utf-8"))
            if m:
                return True
    return False


# --------------------------------------------------------------------------
# Note creation / editing
# --------------------------------------------------------------------------

def note_template(title: str, tags: list[str] | None = None,
                  quick_info: str | None = None) -> str:
    parts = [f"# {title}", ""]
    if quick_info:
        parts += [":::quick-info", quick_info.rstrip(), ":::", ""]
    parts += ["", "## My notes", "", "", "## Connected notes", "",
              "## Reference sources", "", render_meta({
                  "created": today(), "updated": today(), "pinned": "no"})]
    return "\n".join(parts) + "\n"


def available_folders() -> list[str]:
    """Relative folder paths a note may live in (for helpful errors)."""
    return [s["path"] for s in list_subjects()]


def create_note(folder_rel: str, name: str, tags: list[str] | None = None,
                text: str | None = None, quick_info: str | None = None,
                who: str = "user", reason: str = "") -> dict:
    """Create the note folder with <Note Name>.md, tags.txt and
    attachments/. The folder must exist; the error names the folders that
    DO exist so a typo is easy to spot."""
    name = paths.clean_name(name)
    folder_rel = (folder_rel or "").strip().strip("/").replace("\\", "/")
    folder = paths.safe_join(paths.DATABASE, *folder_rel.split("/")) if folder_rel \
        else paths.DATABASE
    if not folder.exists():
        avail = "\n".join("  - " + a for a in available_folders()) or "  - (database root only)"
        raise FileNotFoundError(
            f"Folder {folder_rel!r} does not exist. Existing folders you can "
            f"file into:\n{avail}\nCreate the folder first, then create the note.")
    existing = {key_of(p.stem) for p in list_note_files()}
    if key_of(name) in existing:
        raise FileExistsError(f"Note names are unique across the whole wiki: "
                              f"{name!r} already exists elsewhere.")

    note_dir = folder / name
    md_path = note_dir / (name + ".md")     # inside the note folder
    if note_dir.exists() or md_path.exists():
        raise FileExistsError(f"A note named {name!r} already exists there.")
    (note_dir / "attachments").mkdir(parents=True, exist_ok=False)

    body = text if text is not None else note_template(name, quick_info=quick_info)
    atomic_write(md_path, body)

    tag_list = []
    for t in (tags or []):
        t = tags_mod.validate_tag(t)
        if all(key_of(t) != key_of(x) for x in tag_list):
            tag_list.append(t)
    # v1.1: tags applied by the user exist globally at once - the master
    # list and the note tags are always in sync.
    synced = tags_mod.add_to_master(tag_list, who)
    atomic_write(note_dir / "tags.txt", tags_mod.render_tags_txt(tag_list))

    logger.new_log(who, f"Created note {name}",
                   f"- Note folder: `{paths.rel(note_dir)}`\n"
                   f"- Note file: `{paths.rel(md_path)}`\n"
                   f"- Tags: {', '.join(tag_list) if tag_list else '(none)'}"
                   + (f"\n- Added to the master tag list: {', '.join(synced)}" if synced else "")
                   + (f"\n- Reason: {reason}" if reason else ""),
                   undo={"title": f"Create note {name}", "steps": [
                       {"op": "write", "path": paths.rel(md_path), "before": None},
                       {"op": "write", "path": paths.rel(note_dir / 'tags.txt'), "before": None},
                       {"op": "mkdir", "path": paths.rel(note_dir / 'attachments')},
                   ]})
    return {"path": paths.rel(md_path), "master_updated": synced}


def save_note_text(note_rel: str, new_text: str, base_hash: str | None = None,
                   who: str = "user", force: bool = False, reason: str = "") -> dict:
    """Edit a note. Checks the file hash first: if the file changed while it
    was open, the caller is asked before overwriting (spec 11)."""
    p = paths.ROOT / note_rel
    if not p.exists():
        raise FileNotFoundError(f"Note {note_rel} not found.")
    old = p.read_text(encoding="utf-8")
    current_hash = text_sha256(old)
    if base_hash and base_hash != current_hash and not force:
        return {"conflict": True, "current_hash": current_hash,
                "message": "This file changed while it was open (for example the "
                           "AI filed something). Reload or overwrite?"}

    # 'My notes' is append-only: refuse to shrink or alter it.
    old_doc, new_doc = parse_note(old, note_rel), parse_note(new_text, note_rel)
    if old_doc.my_notes and not new_doc.my_notes.startswith(old_doc.my_notes):
        raise PermissionError("'My notes' is append-only: existing lines cannot "
                              "be changed or removed.")
    if old_doc.my_notes and old_doc.my_notes != new_doc.my_notes:
        # appending is fine
        pass

    new_text = _touch_updated(new_text)
    atomic_write(p, new_text)
    logger.new_log(who, f"Edited note {p.stem}",
                   f"- File: `{note_rel}`\n- Reason: {reason or 'manual edit'}\n\n"
                   "**Before**\n\n```markdown\n" + old[:4000] + ("\n... (truncated)" if len(old) > 4000 else "")
                   + "\n```\n\n**After**\n\n```markdown\n" + new_text[:4000]
                   + ("\n... (truncated)" if len(new_text) > 4000 else "") + "\n```",
                   undo={"title": f"Edit note {p.stem}", "steps": [
                       {"op": "write", "path": note_rel, "before": old}]})
    return {"ok": True, "hash": text_sha256(new_text)}


def _touch_updated(text: str) -> str:
    """Set Updated: today in the metadata block."""
    def repl(m):
        content = m.group(2)
        lines = content.splitlines()
        found = False
        for i, ln in enumerate(lines):
            if re.match(r"(?i)^Updated:", ln.strip()):
                lines[i] = f"Updated: {today()}"
                found = True
        if not found:
            lines.append(f"Updated: {today()}")
        return m.group(1) + "\n".join(lines) + "\n:::"

    return re.sub(r"(:::meta\n)(.*?)\n:::", repl, text, count=1, flags=re.DOTALL) \
        if ":::meta" in text else text


def append_to_my_notes(note_rel: str, addition: str, who: str = "ai",
                       reason: str = "") -> dict:
    """The only way anyone may touch 'My notes': appending at the end."""
    p = paths.ROOT / note_rel
    text = p.read_text(encoding="utf-8")
    doc = parse_note(text, note_rel)
    if "## My notes" in text:
        new_text = text.replace("## My notes",
                                "## My notes\n" + addition.rstrip() + "\n", 1)
    else:
        new_text = text + "\n## My notes\n" + addition.rstrip() + "\n"
    new_text = _touch_updated(new_text)
    atomic_write(p, new_text)
    logger.new_log(who, f"Appended to My notes of {p.stem}",
                   f"- File: `{note_rel}`\n- Added:\n\n> {addition.strip()}\n"
                   + (f"\n- Reason: {reason}" if reason else ""),
                   undo={"title": f"Append to My notes of {p.stem}", "steps": [
                       {"op": "write", "path": note_rel, "before": text}]})
    return {"ok": True}


def move_note(note_rel: str, new_folder_rel: str, new_name: str | None = None,
              who: str = "user") -> dict:
    """Move a note to another folder and/or rename it. Links are rewritten
    everywhere (spec 10, 11)."""
    p = paths.ROOT / note_rel
    if not p.exists():
        raise FileNotFoundError(f"Note {note_rel} not found.")
    old_name = p.parent.name
    new_name = paths.clean_name(new_name) if new_name else old_name
    new_folder = paths.safe_join(paths.DATABASE, *new_folder_rel.split("/")) \
        if new_folder_rel else paths.DATABASE
    if not new_folder.exists():
        raise FileNotFoundError(f"Folder {new_folder_rel!r} does not exist.")
    new_dir = new_folder / new_name
    if new_dir.exists():
        raise FileExistsError(f"Target {paths.rel(new_dir)} already exists.")
    if new_name.lower() != old_name.lower() and note_exists(new_name):
        raise FileExistsError(f"Note names are unique across the whole wiki: "
                              f"{new_name!r} already exists.")

    # 1. Move the folder with everything in it.
    new_dir.parent.mkdir(parents=True, exist_ok=True)
    shutil.move(str(p.parent), str(new_dir))
    new_rel = paths.rel(new_dir / (new_name + ".md"))

    # 2. Rewrite every link in every note when the name changed.
    rewrites = []
    if key_of(new_name) != key_of(old_name):
        for md in list_note_files():
            text = md.read_text(encoding="utf-8")

            def sub(m, old=old_name, new=new_name):
                inner = m.group(0)
                return "[[" + new + (m.group(1) or "") + "]]"

            new_text, n = re.subn(
                r"\[\[" + re.escape(old_name) + r"(\|[^\]]*)?\]\]", sub, text,
                flags=re.IGNORECASE)
            if n:
                atomic_write(md, new_text)
                rewrites.append({"file": paths.rel(md), "links_updated": n})

    logger.new_log(who, f"Moved note {old_name}" +
                   (f" and renamed it to {new_name}" if key_of(new_name) != key_of(old_name) else ""),
                   f"- From: `{note_rel}`\n- To: `{new_rel}`\n"
                   + (f"- Links rewritten in {len(rewrites)} note(s):\n"
                      + "".join(f"  - `{r['file']}` ({r['links_updated']} links)\n"
                                for r in rewrites) if rewrites else "- No name change, no links rewritten."),
                   undo={"title": f"Move note {old_name}", "steps": [
                       {"op": "move", "from": note_rel, "to": new_rel},
                       *[{"op": "write", "path": r["file"], "before":
                          (paths.ROOT / r["file"]).read_text(encoding="utf-8")}
                         for r in rewrites]]})
    return {"path": new_rel, "rewrites": rewrites}


def delete_folder(folder_rel: str, who: str = "user") -> dict:
    """Delete an empty subject folder (non-empty folders are refused; the
    user deletes note folders by deleting the note folder in their file
    manager - the structure files explain this)."""
    folder = paths.safe_join(paths.DATABASE, *folder_rel.split("/")) \
        if folder_rel else paths.DATABASE
    if folder == paths.DATABASE:
        raise ValueError("database/ itself cannot be deleted.")
    if not folder.exists():
        raise FileNotFoundError(f"Folder {folder_rel} not found.")
    if any(folder.iterdir()):
        raise ValueError("Folder is not empty; move or remove its notes first.")
    folder.rmdir()
    logger.new_log(who, f"Deleted empty folder {folder.name}",
                   f"- Removed `{paths.rel(folder)}\\u00b4" if False else
                   f"- Removed `{paths.rel(folder)}`",
                   undo={"title": f"Delete folder {folder.name}", "steps": [
                       {"op": "mkdir", "path": paths.rel(folder)}]})
    return {"ok": True}


# --------------------------------------------------------------------------
# Folder operations
# --------------------------------------------------------------------------

def create_folder(parent_rel: str, name: str, who: str = "user",
                  subject_md: str | None = None) -> dict:
    name = paths.clean_name(name)
    parent = paths.safe_join(paths.DATABASE, *parent_rel.split("/")) \
        if parent_rel else paths.DATABASE
    folder = parent / name
    if folder.exists():
        raise FileExistsError(f"Folder {name!r} already exists there.")
    folder.mkdir(parents=True)
    if subject_md:
        atomic_write(folder / "_subject.md", subject_md.rstrip() + "\n")
    logger.new_log(who, f"Created folder {name}",
                   f"- Folder: `{paths.rel(folder)}`"
                   + (f"\n- Wrote `_subject.md` describing its purpose." if subject_md else ""),
                   undo={"title": f"Create folder {name}", "steps": [
                       {"op": "mkdir", "path": paths.rel(folder)},
                       *([{"op": "write", "path": paths.rel(folder / '_subject.md'),
                           "before": None}] if subject_md else [])]})
    return {"path": paths.rel(folder)}


def rename_folder(folder_rel: str, new_name: str, who: str = "user") -> dict:
    folder = paths.safe_join(paths.DATABASE, *folder_rel.split("/"))
    if folder == paths.DATABASE:
        raise ValueError("database/ itself cannot be renamed.")
    new_name = paths.clean_name(new_name)
    new_folder = folder.parent / new_name
    if new_folder.exists():
        raise FileExistsError(f"Folder {new_name!r} already exists.")
    shutil.move(str(folder), str(new_folder))
    logger.new_log(who, f"Renamed folder {folder.name} to {new_name}",
                   f"- From: `{paths.rel(folder)}`\n- To: `{paths.rel(new_folder)}`\n"
                   "- Wiki links use file names, so no note link needed rewriting.",
                   undo={"title": f"Rename folder {folder.name}", "steps": [
                       {"op": "move", "from": paths.rel(folder), "to": paths.rel(new_folder)}]})
    return {"path": paths.rel(new_folder)}


def move_folder(folder_rel: str, new_parent_rel: str, who: str = "user") -> dict:
    folder = paths.safe_join(paths.DATABASE, *folder_rel.split("/"))
    new_parent = paths.safe_join(paths.DATABASE, *new_parent_rel.split("/")) \
        if new_parent_rel else paths.DATABASE
    if new_parent == folder or folder in new_parent.parents:
        raise ValueError("A folder cannot move inside itself.")
    new_folder = new_parent / folder.name
    if new_folder.exists():
        raise FileExistsError(f"Folder {folder.name!r} already exists there.")
    shutil.move(str(folder), str(new_folder))
    logger.new_log(who, f"Moved folder {folder.name}",
                   f"- From: `{paths.rel(folder)}`\n- To: `{paths.rel(new_folder)}`",
                   undo={"title": f"Move folder {folder.name}", "steps": [
                       {"op": "move", "from": paths.rel(folder), "to": paths.rel(new_folder)}]})
    return {"path": paths.rel(new_folder)}


# --------------------------------------------------------------------------
# Folder tree / subject files
# --------------------------------------------------------------------------

def folder_tree() -> dict:
    """Folder tree with note counts, private folders marked (spec 4)."""
    def build(folder: Path) -> dict:
        node = {"name": folder.name if folder != paths.DATABASE else "database",
                "path": paths.rel(folder) if folder != paths.DATABASE else "",
                "notes": 0, "private": is_private(folder), "children": []}
        for child in sorted(folder.iterdir(), key=lambda p: p.name.lower()):
            if child.is_dir():
                if child.name == "attachments":
                    continue
                if child.is_dir() and (child / (child.name + ".md")).exists():
                    node["notes"] += 1 if not node["private"] else 0
                    continue
                node["children"].append(build(child))
        return node

    return build(paths.DATABASE)


def list_subjects() -> list[dict]:
    """Flat list of subject folders for pickers."""
    out = []
    for folder in sorted(paths.DATABASE.rglob("*")):
        if folder.is_dir() and folder != paths.DATABASE:
            if folder.name == "attachments" or (folder / (folder.name + ".md")).exists():
                continue
            out.append({"path": paths.rel(folder).removeprefix("database/"),
                        "name": folder.name,
                        "private": is_private(folder)})
    return out


# --------------------------------------------------------------------------
# Tags on notes, master tags
# --------------------------------------------------------------------------

def edit_tags(note_rel: str, add: list[str] | None = None,
              remove: list[str] | None = None, who: str = "user") -> dict:
    """Add or remove tags on one note. v1.1: every tag added through the
    website/API also lands in the Approved tags of _tags.md immediately, so
    the global tag index and the per-note tags can never drift apart."""
    p = paths.ROOT / note_rel
    tags_file = p.parent / "tags.txt"
    old_raw = tags_file.read_text(encoding="utf-8") if tags_file.exists() else ""
    current = tags_mod.parse_tags_txt(old_raw)
    added, removed = [], []
    keys = {key_of(t) for t in current}
    for t in add or []:
        t = tags_mod.validate_tag(t)
        if key_of(t) not in keys:
            current.append(t)
            keys.add(key_of(t))
            added.append(t)
    for t in remove or []:
        before = len(current)
        current = [x for x in current if key_of(x) != key_of(tags_mod.validate_tag(t))]
        if len(current) < before:
            removed.append(t)
    if added or removed:
        atomic_write(tags_file, tags_mod.render_tags_txt(current))
        # keep the global vocabulary in sync with what is used on notes
        synced = tags_mod.add_to_master(added, who)
        logger.new_log(who, f"Edited tags of {p.stem}",
                       f"- File: `{paths.rel(tags_file)}`\n"
                       f"- Added: {', '.join(added) or '(none)'}\n"
                       f"- Removed: {', '.join(removed) or '(none)'}\n"
                       f"- Now: {', '.join(current) or '(none)'}"
                       + (f"\n- Added to the master tag list: {', '.join(synced)}" if synced else ""),
                       undo={"title": f"Edit tags of {p.stem}", "steps": [
                           {"op": "write", "path": paths.rel(tags_file), "before": old_raw}]})
    return {"tags": current, "added": added, "removed": removed}


def rename_tag(old: str, new: str, who: str = "user",
               run: bool = False) -> dict:
    """Rename one tag everywhere (tags are independent: no sub-tags, so
    exactly the matching tag is renamed). Returns a preview first;
    run=True writes."""
    old, new = tags_mod.validate_tag(old), tags_mod.validate_tag(new)
    affected = []
    for tf in paths.DATABASE.rglob("tags.txt"):
        raw = tf.read_text(encoding="utf-8")
        cur = tags_mod.parse_tags_txt(raw)
        changed = False
        out = []
        for t in cur:
            if tags_mod.same_tag(t, old):
                if new not in out:
                    out.append(new)
                changed = True
            elif t not in out:
                out.append(t)
        if changed:
            affected.append({"file": paths.rel(tf), "old": cur, "new": out})
    preview = {"from": old, "to": new, "notes": affected}
    if not run:
        return preview

    master_path = paths.ROOT / "_tags.md"
    master_old = master_path.read_text(encoding="utf-8")
    pattern = re.compile(r"(?im)^(\s*-\s*)" + re.escape(old) + r"(\s*:.*)?$")
    master_new, n_master = pattern.subn(lambda m: m.group(1) + new + (m.group(2) or ""), master_old)
    for a in affected:
        atomic_write(paths.ROOT / a["file"], tags_mod.render_tags_txt(a["new"]))
    if n_master:
        atomic_write(master_path, master_new)
    logger.new_log(who, f"Renamed tag {old} to {new}",
                   f"- Renamed in {len(affected)} notes' tags.txt and {n_master} master entries.\n"
                   + "".join(f"- `{a['file']}`: {', '.join(a['old'])} -> {', '.join(a['new'])}\n"
                             for a in affected),
                   undo={"title": f"Rename tag {old}", "steps": [
                       {"op": "write", "path": "_tags.md", "before": master_old},
                       *[{"op": "write", "path": a["file"], "before":
                          tags_mod.render_tags_txt(a["old"])} for a in affected]]})
    return preview


def merge_tags(src: str, dst: str, who: str = "user", run: bool = False) -> dict:
    """Merge one tag into another across all notes, with preview.
    Tags are independent, so only the exact source tag is merged."""
    src, dst = tags_mod.validate_tag(src), tags_mod.validate_tag(dst)
    affected = []
    for tf in paths.DATABASE.rglob("tags.txt"):
        raw = tf.read_text(encoding="utf-8")
        cur = tags_mod.parse_tags_txt(raw)
        if not any(tags_mod.same_tag(t, src) for t in cur):
            continue
        out = []
        for t in cur:
            t2 = dst if tags_mod.same_tag(t, src) else t
            if t2 not in out:
                out.append(t2)
        affected.append({"file": paths.rel(tf), "old": cur, "new": out})
    preview = {"from": src, "into": dst, "notes": affected}
    if not run:
        return preview
    master_path = paths.ROOT / "_tags.md"
    master_old = master_path.read_text(encoding="utf-8")
    master_new = _remove_tag_from_master(master_old, src)
    for a in affected:
        atomic_write(paths.ROOT / a["file"], tags_mod.render_tags_txt(a["new"]))
    atomic_write(master_path, master_new)
    logger.new_log(who, f"Merged tag {src} into {dst}",
                   f"- Merged into {len(affected)} notes.\n"
                   + "".join(f"- `{a['file']}`: {', '.join(a['old'])} -> {', '.join(a['new'])}\n"
                             for a in affected),
                   undo={"title": f"Merge tag {src}", "steps": [
                       {"op": "write", "path": "_tags.md", "before": master_old},
                       *[{"op": "write", "path": a["file"], "before":
                          tags_mod.render_tags_txt(a["old"])} for a in affected]]})
    return preview


def remove_tag_everywhere(tag: str, who: str = "user", run: bool = False) -> dict:
    """Remove one tag from every note and from _tags.md (preview first)."""
    tag = tags_mod.validate_tag(tag)
    affected = []
    for tf in paths.DATABASE.rglob("tags.txt"):
        raw = tf.read_text(encoding="utf-8")
        cur = tags_mod.parse_tags_txt(raw)
        out = [t for t in cur if not tags_mod.same_tag(t, tag)]
        if out != cur:
            affected.append({"file": paths.rel(tf), "old": cur, "new": out})
    preview = {"tag": tag, "notes": affected}
    if not run:
        return preview
    master_path = paths.ROOT / "_tags.md"
    master_old = master_path.read_text(encoding="utf-8")
    master_new = _remove_tag_from_master(master_old, tag)
    for a in affected:
        atomic_write(paths.ROOT / a["file"], tags_mod.render_tags_txt(a["new"]))
    atomic_write(master_path, master_new)
    logger.new_log(who, f"Removed tag {tag}",
                   f"- Removed from {len(affected)} notes and from _tags.md.",
                   undo={"title": f"Remove tag {tag}", "steps": [
                       {"op": "write", "path": "_tags.md", "before": master_old},
                       *[{"op": "write", "path": a["file"], "before":
                          tags_mod.render_tags_txt(a["old"])} for a in affected]]})
    return preview


def _remove_tag_from_master(master: str, tag: str) -> str:
    lines = []
    for ln in master.splitlines():
        m = re.match(r"^\s*-\s*([A-Za-z0-9_\-]+)", ln)
        if m and tags_mod.same_tag(m.group(1), tag):
            continue
        lines.append(ln)
    return "\n".join(lines)


def edit_master_tags(new_text: str, who: str = "user") -> dict:
    """Rewrite _tags.md wholesale (website tag editor)."""
    master_path = paths.ROOT / "_tags.md"
    old = master_path.read_text(encoding="utf-8")
    atomic_write(master_path, new_text)
    logger.new_log(who, "Edited master tag list",
                   f"- File: `_tags.md`\n\n**Before**\n\n```markdown\n{old[:2000]}\n```\n\n"
                   f"**After**\n\n```markdown\n{new_text[:2000]}\n```",
                   undo={"title": "Edit master tags", "steps": [
                       {"op": "write", "path": "_tags.md", "before": old}]})
    return {"ok": True}


# --------------------------------------------------------------------------
# Quick info, connections, references, links, metadata
# --------------------------------------------------------------------------

def set_quick_info(note_rel: str, qi_text: str | None, who: str = "user") -> dict:
    p = paths.ROOT / note_rel
    text = p.read_text(encoding="utf-8")
    old_doc = parse_note(text, note_rel)
    old_block = ""
    if old_doc.quick_info_raw is not None:
        m = re.search(r":::quick-info\n.*?\n:::", text, re.DOTALL)
        old_block = m.group(0) if m else ""

    if qi_text is None or qi_text.strip() == "":
        new_text = text.replace(old_block + "\n\n", "", 1) if old_block else text
        new_text = new_text.replace(old_block + "\n", "", 1) if old_block else new_text
    else:
        parse_quick_info(qi_text)   # validate
        new_block = ":::quick-info\n" + qi_text.rstrip() + "\n:::"
        if old_block:
            new_text = text.replace(old_block, new_block, 1)
        else:
            # insert after the H1 title line
            lines = text.splitlines(keepends=True)
            for i, ln in enumerate(lines):
                if ln.startswith("# "):
                    lines.insert(i + 1, "\n" + new_block + "\n")
                    break
            else:
                lines.insert(0, new_block + "\n")
            new_text = "".join(lines)
    new_text = _touch_updated(new_text)
    atomic_write(p, new_text)
    logger.new_log(who, f"Edited quick info of {p.stem}",
                   f"- File: `{note_rel}`\n\n**Before**\n\n```\n{old_block}\n```\n\n"
                   f"**After**\n\n```\n{(qi_text or '').rstrip()}\n```",
                   undo={"title": f"Edit quick info of {p.stem}", "steps": [
                       {"op": "write", "path": note_rel, "before": text}]})
    return {"ok": True}


def set_metadata(note_rel: str, meta: dict, who: str = "user") -> dict:
    """v1.1: note verification was removed. Status is no longer forced or
    shown; the block keeps Created/Updated/Pinned."""
    p = paths.ROOT / note_rel
    text = p.read_text(encoding="utf-8")
    old_doc = parse_note(text, note_rel)
    m = re.search(r":::meta\n.*?\n:::", text, re.DOTALL)
    old_block = m.group(0) if m else ""
    merged = dict(old_doc.meta)
    merged.update({k: v for k, v in meta.items() if v is not None})
    merged.pop("status", None)          # verification removed in v1.1
    new_block = render_meta(merged)
    new_text = text.replace(old_block, new_block, 1) if old_block else \
        text.rstrip() + "\n\n" + new_block + "\n"
    atomic_write(p, new_text)
    logger.new_log(who, f"Edited metadata of {p.stem}",
                   f"- File: `{note_rel}`\n- New metadata: {merged}",
                   undo={"title": f"Edit metadata of {p.stem}", "steps": [
                       {"op": "write", "path": note_rel, "before": text}]})
    return {"ok": True, "meta": merged}


def edit_connections(note_rel: str, add: list[str] | None = None,
                     remove: list[str] | None = None,
                     edit_link: dict | None = None, who: str = "user") -> dict:
    """Add or remove a connection (an [[File Name]] line in the Connected
    notes section). Adding uses existing file names only (spec 10)."""
    p = paths.ROOT / note_rel
    text = p.read_text(encoding="utf-8")
    old = text
    doc = parse_note(text, note_rel)
    targets = list(doc.connected)

    for t in remove or []:
        if t not in targets:
            existing = note_exists(t)
            if not existing:
                raise FileNotFoundError(f"No note named {t!r}.")
            t = existing.stem
        targets = [x for x in targets if key_of(x) != key_of(t)]

    for t in add or []:
        existing = note_exists(t)
        if not existing:
            raise ValueError(f"A connection to a note that does not exist cannot "
                             f"be created: {t!r} is not in this wiki.")
        t = existing.stem
        if key_of(t) != key_of(doc.title) and not any(key_of(x) == key_of(t) for x in targets):
            targets.append(t)

    if edit_link:
        # edit a linked-in-text connection: change target of [[old|word]]
        old_target = edit_link.get("target", "")
        word = edit_link.get("word")
        new_target = edit_link.get("new_target")
        unlink = edit_link.get("unlink")
        def _sub(m):
            tgt = m.group(1).strip()
            if key_of(tgt) == key_of(old_target) and (word is None or (m.group(2) or tgt).strip() == word):
                if unlink:
                    return (m.group(2) or tgt)
                if new_target:
                    return "[[" + new_target + ("|" + m.group(2) if m.group(2) else "") + "]]"
            return m.group(0)
        text = WIKI_LINK_RE.sub(_sub, text)

    # rebuild the Connected notes section
    def rebuild_section(src_text: str, title: str, lines: list[str]) -> str:
        pat = re.compile(r"(^## " + re.escape(title) + r"\s*$)(.*?)(?=^## |\Z)",
                         re.MULTILINE | re.DOTALL)
        block = "\n" + ("".join(l + "\n" for l in lines) if lines else "") 
        if pat.search(src_text):
            return pat.sub(lambda m: m.group(1) + block, src_text)
        return src_text.rstrip() + "\n\n## " + title + "\n" + block

    text = rebuild_section(text, "Connected notes", [f"[[{t}]]" for t in targets])
    if text == old:
        return {"ok": True, "connected": targets}
    text = _touch_updated(text)
    atomic_write(p, text)
    logger.new_log(who, f"Edited connections of {p.stem}",
                   f"- File: `{note_rel}`\n- Added: {', '.join(add or []) or '(none)'}\n"
                   f"- Removed: {', '.join(remove or []) or '(none)'}\n"
                   f"- Connected now: {', '.join(targets) or '(none)'}",
                   undo={"title": f"Edit connections of {p.stem}", "steps": [
                       {"op": "write", "path": note_rel, "before": old}]})
    return {"ok": True, "connected": targets}


def normalize_url(url: str) -> str:
    """v1.1: the user never has to type https:// - a bare domain such as
    `example.com` or `www.example.com/x` becomes `https://example.com`.
    http:// links the user typed on purpose are kept."""
    u = (url or "").strip()
    if not u:
        return u
    if re.match(r"^[a-zA-Z][a-zA-Z0-9+.-]*://", u):
        return u                       # already has a scheme
    if u.startswith("#") or u.startswith("/"):
        return u                       # in-page anchor or server path
    return "https://" + u


def edit_references(note_rel: str, add: dict | None = None,
                    remove_url: str | None = None, who: str = "user") -> dict:
    p = paths.ROOT / note_rel
    text = p.read_text(encoding="utf-8")
    old = text
    doc = parse_note(text, note_rel)
    refs = list(doc.references)
    if remove_url:
        refs = [r for r in refs if r["url"] != remove_url]
    if add:
        url = normalize_url(add.get("url", ""))
        if not url.startswith("http"):
            raise ValueError("A reference needs a web address, for example "
                             "example.com (https:// is added automatically).")
        refs.append({"title": add.get("title") or url,
                     "url": url,
                     "accessed": add.get("accessed") or today()})
    lines = [f"- [{r['title']}]({r['url']})" + (f" — accessed {r['accessed']}" if r["accessed"] else "")
             for r in refs]

    pat = re.compile(r"(^## Reference sources\s*$)(.*?)(?=^## |\Z)",
                     re.MULTILINE | re.DOTALL)
    block = "\n" + ("".join(l + "\n" for l in lines) if lines else "")
    if pat.search(text):
        text = pat.sub(lambda m: m.group(1) + block, text)
    else:
        text = text.rstrip() + "\n\n## Reference sources\n" + block
    if text != old:
        text = _touch_updated(text)
        atomic_write(p, text)
        logger.new_log(who, f"Edited reference sources of {p.stem}",
                       f"- File: `{note_rel}`\n- References now: {len(refs)}",
                       undo={"title": f"Edit references of {p.stem}", "steps": [
                           {"op": "write", "path": note_rel, "before": old}]})
    return {"ok": True, "references": refs}


def edit_links(note_rel: str, word: str, new_target: str | None,
               make_note: bool = True, who: str = "user") -> dict:
    """Change which words are a link and where it points, or remove the
    link and keep the words (spec 10: Links on words)."""
    p = paths.ROOT / note_rel
    text = p.read_text(encoding="utf-8")
    old = text
    if new_target is None:      # unlink, keep the words
        pat = re.compile(r"\[\[" + re.escape(word) + r"\]\]|\[\[[^\]|]+\|" + re.escape(word) + r"\]\]")
        text = pat.sub(word, text)
    elif make_note:
        existing = note_exists(new_target)
        if not existing:
            raise ValueError(f"No note named {new_target!r} in this wiki.")
        text = text.replace(word, f"[[{existing.stem}|{word}]]", 1)
    else:
        text = text.replace(word, f"[{word}]({new_target})", 1)
    if text != old:
        text = _touch_updated(text)
        atomic_write(p, text)
        logger.new_log(who, f"Edited links in {p.stem}",
                       f"- File: `{note_rel}`\n- Word: {word}\n- New target: {new_target}",
                       undo={"title": f"Edit links in {p.stem}", "steps": [
                           {"op": "write", "path": note_rel, "before": old}]})
    return {"ok": True}


def export_metadata(note_rel: str) -> str:
    """v1.1 complete plain-text export: exact file location, every tag on
    this note, every tag used in the whole wiki with counts, dates,
    connected notes (incoming and outgoing, no backlink wording), reference
    sources and attachments."""
    p = paths.ROOT / note_rel
    doc = parse_note(p.read_text(encoding="utf-8"), note_rel)
    tags_file = p.parent / "tags.txt"
    note_tags = tags_mod.parse_tags_txt(
        tags_file.read_text(encoding="utf-8")) if tags_file.exists() else []
    # incoming connections: notes that connect TO this note (shown as part
    # of the Connected notes picture, not as a separate 'backlink' section)
    incoming = []
    for md in list_note_files():
        other = parse_note(md.read_text(encoding="utf-8"), paths.rel(md))
        if any(key_of(c) == key_of(doc.title) for c in other.connected):
            incoming.append(md.parent.name)
    atts = sorted(x.name for x in (p.parent / "attachments").iterdir()) \
        if (p.parent / "attachments").exists() else []

    ext = tags_mod.extract_all_notes_tags()
    L = ["File name: " + doc.title,
         "File location: database/" + p.parent.relative_to(paths.DATABASE).as_posix()
         + "/" + p.name,
         "Folder path: " + (p.parent.parent.relative_to(paths.DATABASE).as_posix()
                            if p.parent.parent != paths.DATABASE else "(root)"),
         "Tags: " + (", ".join(note_tags) or "(none)"),
         "Created: " + doc.meta.get("created", ""),
         "Updated: " + doc.meta.get("updated", ""),
         "Pinned: " + doc.meta.get("pinned", "no"),
         "",
         "Connected notes:"]
    L += [f"  - {c}" for c in doc.connected] or ["  (none)"]
    L += ["", "Connected from (other notes link here):"]
    L += [f"  - {b}" for b in incoming] or ["  (none)"]
    L += ["", "Reference sources:"]
    L += [f"  - {r['title']} <{r['url']}>" for r in doc.references] or ["  (none)"]
    L += ["", "Attachments:"]
    L += [f"  - attachments/{a}" for a in atts] or ["  (none)"]
    L += ["", "All tags used in this wiki (tag — times used):"]
    L += [f"  - {t} — {ext['counts'][t]}" for t in ext["tags"]] or ["  (none)"]
    return "\n".join(L) + "\n"


def toggle_task(note_rel: str, task_index: int, who: str = "user",
                new_text: str | None = None) -> dict:
    """Tick/untick the Nth task checkbox of a note (0-based, in document
    order) and return the new raw text + hash so the editor stays in sync.
    Used by the clickable checkboxes in the rendered preview.
    new_text: when given (preview of an unsaved draft), the flip is applied
    to that text and returned WITHOUT writing the file."""
    if new_text is not None:
        flipped, done, found = _flip_task(new_text, task_index)
        if not found:
            raise ValueError(f"Task #{task_index} was not found in this text.")
        return {"ok": True, "text": flipped, "done": done, "draft": True}
    p = paths.ROOT / note_rel
    if not p.exists():
        raise FileNotFoundError(f"Note {note_rel} not found.")
    old = p.read_text(encoding="utf-8")
    flipped, done, found = _flip_task(old, task_index)
    if not found:
        raise ValueError(f"Task #{task_index} was not found in this note.")
    atomic_write(p, flipped)
    logger.new_log(who, f"Toggled a checklist item in {p.stem}",
                   f"- File: `{note_rel}`\n- Task #{task_index} is now "
                   f"{'done' if done else 'not done'}.",
                   undo={"title": f"Toggle task in {p.stem}", "steps": [
                       {"op": "write", "path": note_rel, "before": old}]})
    return {"ok": True, "text": flipped, "done": done, "hash": text_sha256(flipped)}


_TASK_RE = re.compile(r"^(\s*(?:[-*]|\d+[.)])\s+)\[([ xX])\](\s+)(.*)$")


def _flip_task(text: str, task_index: int) -> tuple[str, bool, bool]:
    """Return (new_text, now_done, found) after flipping task number
    task_index. The text is otherwise byte-for-byte unchanged."""
    n = -1
    out = []
    done_now = False
    found = False
    for ln in text.splitlines(keepends=False):
        m = _TASK_RE.match(ln)
        if m:
            n += 1
            if n == task_index:
                tick = m.group(2)
                new_tick = " " if tick.lower() == "x" else "x"
                done_now = new_tick == "x"
                found = True
                ln = m.group(1) + "[" + new_tick + "]" + m.group(3) + m.group(4)
        out.append(ln)
    trailing = "\n" if text.endswith("\n") else ""
    return "\n".join(out) + trailing, done_now, found


def note_tasks(note_rel: str, text: str | None = None) -> list[dict]:
    """List the tasks of a note: [{index, done, text, line}] for the UI."""
    raw = text if text is not None else (paths.ROOT / note_rel).read_text(encoding="utf-8")
    out = []
    for i, ln in enumerate(raw.splitlines()):
        m = _TASK_RE.match(ln)
        if m:
            out.append({"index": len(out), "done": m.group(2).lower() == "x",
                        "text": m.group(4), "line": i})
    return out


def toggle_pin(note_rel: str, who: str = "user") -> dict:
    p = paths.ROOT / note_rel
    doc = parse_note(p.read_text(encoding="utf-8"), note_rel)
    pinned = doc.meta.get("pinned", "no").lower() == "yes"
    return set_metadata(note_rel, {"pinned": "no" if pinned else "yes"}, who)


# --------------------------------------------------------------------------
# Saved searches (kept in settings.json - no extra files, spec 16)
# --------------------------------------------------------------------------

def saved_searches() -> list[dict]:
    return load_settings().get("saved_searches", [])


def save_search(name: str, params: dict, who: str = "user") -> dict:
    s = load_settings()
    lst = [x for x in s.get("saved_searches", []) if x["name"] != name]
    lst.append({"name": name, "params": params})
    s["saved_searches"] = lst
    save_settings(s)
    logger.new_log(who, f"Saved search {name}", f"- Saved search parameters: {json.dumps(params)[:500]}")
    return {"ok": True, "saved": lst}


def delete_saved_search(name: str) -> dict:
    s = load_settings()
    s["saved_searches"] = [x for x in s.get("saved_searches", []) if x["name"] != name]
    save_settings(s)
    return {"ok": True}


# --------------------------------------------------------------------------
# AI librarian support (spec 5, 6, 15)
# --------------------------------------------------------------------------

def propose_tags(tags: list[str], who: str = "ai", reason: str = "") -> dict:
    """A tag that is not in _tags.md cannot be applied. The AI proposes it
    under the *Proposed tags* heading; it becomes usable once the user
    approves it (spec 15)."""
    mt = tags_mod.load_master()
    new = []
    for t in tags or []:
        t = tags_mod.validate_tag(t)
        if not mt.has(t) and all(key_of(t) != key_of(x) for x in mt.proposed):
            new.append(t)
    if not new:
        return {"proposed": []}
    master_path = paths.ROOT / "_tags.md"
    old = master_path.read_text(encoding="utf-8")
    add = "".join(f"- {t}\n" for t in new)
    if re.search(r"(?im)^## Proposed tags\s*$", old):
        new_text = re.sub(r"(?im)^(## Proposed tags\s*)$",
                          lambda m: m.group(1) + "\n" + add.rstrip("\n") + "\n",
                          old, count=1)
        # place the lines after the section's prose (append at end of file
        # section: simplest correct spot is directly under the heading)
        if new_text == old:
            new_text = old.rstrip() + "\n" + add
    else:
        new_text = old.rstrip() + "\n\n## Proposed tags\n\n" + add
    atomic_write(master_path, new_text)
    logger.new_log(who, f"Proposed tag{'s' if len(new) > 1 else ''} {', '.join(new)}",
                   f"- Added under *Proposed tags* in `_tags.md`: {', '.join(new)}"
                   + (f"\n- Reason: {reason}" if reason else ""),
                   undo={"title": f"Propose tags {', '.join(new)}", "steps": [
                       {"op": "write", "path": "_tags.md", "before": old}]})
    return {"proposed": new}


def file_note(text: str, name: str, folder_rel: str = "", tags: list[str] | None = None,
              who: str = "ai", reason: str = "") -> dict:
    """The librarian's main tool (spec 5): file a raw/inbox note, or add the
    new material to an existing note. The user's text is never overwritten;
    everything the AI adds is marked unverified (spec 6)."""
    name = paths.clean_name(name)
    tags = [tags_mod.validate_tag(t) for t in (tags or [])]
    text = (text or "").strip()
    if not text:
        raise ValueError("file_note needs some content to file.")
    existing = note_exists(name)
    if existing:
        p = existing
        old = p.read_text(encoding="utf-8")
        block = f"### Filed {today()}" + (f" — {reason}" if reason else "") \
            + "\n\n" + text + "\n"
        if "## My notes" in old:
            new_text = old.replace("## My notes", block + "\n## My notes", 1)
        else:
            new_text = old.rstrip() + "\n\n" + block
        new_text = _touch_updated(new_text)
        atomic_write(p, new_text)
        proposed = propose_tags(tags, who, reason or "filed with note update")["proposed"]
        logger.new_log(who, f"Filed new material into {p.stem}",
                       f"- File: `{paths.rel(p)}`\n- Action: updated (added a dated "
                       f"'Filed' subsection; nothing already written was changed)\n"
                       f"- New material:\n\n```markdown\n{text[:2000]}\n```"
                       + (f"\n- Proposed tags: {', '.join(proposed)}" if proposed else "")
                       + (f"\n- Reason: {reason}" if reason else ""),
                       undo={"title": f"File into {p.stem}", "steps": [
                           {"op": "write", "path": paths.rel(p), "before": old}]})
        return {"filed_into": paths.rel(p), "action": "updated",
                "proposed_tags": proposed}

    folder = paths.safe_join(paths.DATABASE, *folder_rel.split("/")) if folder_rel \
        else paths.DATABASE
    if not folder.exists():
        raise FileNotFoundError(
            f"Folder {folder_rel!r} does not exist. The AI must ask before "
            "creating a new folder; call again with approve_new_folder=true "
            "only after the user agreed.")
    body = (f"# {name}\n\n" + text + "\n\n## My notes\n\n## Connected notes\n\n"
            "## Reference sources\n\n" + render_meta(
                {"created": today(), "updated": today(), "pinned": "no"}))
    out = create_note(folder_rel, name, tags, text=body, who=who,
                      reason=reason or "filed from raw note")
    proposed = propose_tags(tags, who, reason or "filed with new note")["proposed"]
    out["action"] = "created"
    out["proposed_tags"] = proposed
    return out
