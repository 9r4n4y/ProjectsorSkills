# Search engine changed to BM25 + grep (v4.2)

- **When:** 2026-11-02 17:58:00
- **Who:** developer (Z.ai)
- **Title:** Search engine changed to BM25 + grep

## What was done

- The ranking algorithm is totally changed: a field-weighted BM25 (BM25F)
  over six fields (title, aliases, headings, tags, body, folder path) is now
  the one ranking algorithm. The old weighted multi-signal ranker and the
  strict/ranking modes are removed.
- Grep added as an optional exact stage: keywords that must appear in the
  note literally (capitals ignored, AND-combined). BM25-only, grep-only, or
  both — the user chooses per search.
- Advanced options kept: scopes (everything / file name / tags / headings /
  body / folder path), folder boundaries, tag filters, dates. Selected tags
  are now hard filters.
- Settings moved to BM25 knobs: bm25 {k1,b}, bm25_field_weights (6 fields),
  phrase_weight; ranking_weights and closeness_window_tokens removed.
- search_notes + /api/search take `grep` instead of mode/tag_mode/keyword_mode;
  saved searches carry grep keywords.
- Index format bumped to v101 (per-field term frequencies, shared document
  frequency); old caches rebuild automatically.
- Docs updated everywhere: README.md, SKILL.md, FIXES.md,
  StructureOFnotes.md, in-app help.

## Verification

- cargo test: 21 unit tests + the BM25/grep suite (38 checks) + structure
  examples — all PASS.
- 37 live HTTP API checks and 32 live MCP stdio checks — all PASS.

---

Log files are never edited or deleted after they are written.
