#!/usr/bin/env bash
# SecondBrain v4.2.2 — build (if needed) and start the local website.
set -euo pipefail
cd "$(dirname "$0")"
if [ -x bin/secondbrain-website ]; then
  exec ./bin/secondbrain-website "$@"
fi
if [ ! -x target/release/secondbrain-website ]; then
  echo "Building SecondBrain (first run compiles the engine, ~1-2 minutes)…"
  cargo build --release
fi
exec ./target/release/secondbrain-website "$@"
