//! The fixed BM25 + grep test set (v4.2).
//!
//! A fixed set of queries with expected top results protects against search
//! regressions. BM25 is the ranking algorithm; grep is the optional exact
//! stage. Run: `cargo test -p secondbrain-core --test ranking`

use sbcore::{indexer, paths, search};
use std::collections::HashMap;

const PASTA: &str =
    "database/Recipes/Quick Vegetable Pasta for Weeknights/Quick Vegetable Pasta for Weeknights.md";
const GARLIC: &str = "database/Recipes/Garlic Bread/Garlic Bread.md";
const SOUP: &str =
    "database/Recipes/Lentil Soup for Cold Evenings/Lentil Soup for Cold Evenings.md";
const SPANISH: &str =
    "database/Learning/Languages/Vocabulary/Spanish Kitchen Words/Spanish Kitchen Words.md";
const SETUP: &str = "database/Projects/SecondBrain Setup/SecondBrain Setup.md";
const GARDEN: &str = "database/Projects/Garden Plan 2026/Garden Plan 2026.md";

struct Case {
    name: &'static str,
    q: &'static str,
    grep: Vec<&'static str>,
    tags: Vec<&'static str>,
    folders: Vec<&'static str>,
    scope: Vec<&'static str>,
    expected: Expect,
}

enum Expect {
    Top(&'static str),
    InTop3(&'static str),
    FolderBoundary,
    None,
}

fn s(q: &'static str, expected: Expect) -> Case {
    Case {
        name: "",
        q,
        grep: vec![],
        tags: vec![],
        folders: vec![],
        scope: vec![],
        expected,
    }
}

#[test]
fn bm25_grep_expectations_hold() {
    // v4.2.2: the fixed expectations run against a HERMETIC fixture — a copy
    // of the original 6 example notes with DEFAULT settings — so the results
    // never drift when the live database grows (the 50-page web-scrape corpus
    // legitimately changes IDF statistics) and no mutable runtime setting
    // (typo_tolerance & co.) can break the suite. Live-corpus scenarios are
    // covered by scripts/test-v422-api.mjs against the real server.
    let live_root = paths::discover_root();
    let fixture = std::env::temp_dir().join("sb-ranking-fixture");
    let _ = std::fs::remove_dir_all(&fixture);
    std::fs::create_dir_all(fixture.join("core")).expect("fixture core dir");
    // copy the database WITHOUT the Web Clippings test corpus
    for entry in walkdir::WalkDir::new(live_root.join("database"))
        .into_iter()
        .filter_map(|e| e.ok())
    {
        let rel = entry.path().strip_prefix(live_root.join("database")).unwrap();
        if rel.components().any(|c| c.as_os_str() == "Web Clippings") {
            continue;
        }
        let dst = fixture.join("database").join(rel);
        if entry.file_type().is_dir() {
            std::fs::create_dir_all(&dst).expect("fixture dir");
        } else {
            std::fs::create_dir_all(dst.parent().unwrap()).expect("fixture parent");
            std::fs::copy(entry.path(), &dst).expect("fixture file");
        }
    }
    // the master tag vocabulary + the structure rulebook (the sibling
    // structure_examples test reads it from ROOT; tests share the process)
    // + no settings file → engine defaults
    std::fs::copy(live_root.join("_tags.md"), fixture.join("_tags.md")).expect("tags fixture");
    std::fs::copy(live_root.join("StructureOFnotes.md"), fixture.join("StructureOFnotes.md")).expect("structure fixture");
    std::env::set_var("SB_ROOT", fixture.to_string_lossy().to_string());

    let cases: Vec<(&str, Case)> = vec![
        // ---- BM25 ranking (the main lead) ----
        ("bm25: quick vegetable pasta", Case { name: "quick vegetable pasta", ..s("quick vegetable pasta", Expect::Top(PASTA)) }),
        ("bm25: single word pasta", Case { name: "single word pasta", ..s("pasta", Expect::Top(PASTA)) }),
        ("bm25: garlic", Case { name: "garlic", ..s("garlic", Expect::Top(GARLIC)) }),
        ("bm25: synonyms fast veggie meal", Case { name: "syn fast veggie meal", ..s("fast veggie meal", Expect::Top(PASTA)) }),
        ("bm25: synonyms speedy dish", Case { name: "syn speedy dish", ..s("speedy dish", Expect::Top(PASTA)) }),
        ("bm25: typo tolerance pastha", Case { name: "typo pastha", ..s("pastha", Expect::Top(PASTA)) }),
        ("bm25: typo tolerance lental", Case { name: "typo lental", ..s("lental", Expect::Top(SOUP)) }),
        ("bm25: word endings recipes", Case { name: "recipes in top3", ..s("recipes", Expect::InTop3(PASTA)) }),
        ("bm25: vocabulary words", Case { name: "vocabulary words", ..s("vocabulary words", Expect::Top(SPANISH)) }),
        ("bm25: project search", Case { name: "secondbrain setup", ..s("secondbrain setup", Expect::Top(SETUP)) }),
        ("bm25: garden tomatoes", Case { name: "garden tomatoes", ..s("garden tomatoes", Expect::Top(GARDEN)) }),
        ("bm25: phrase one pot", Case { name: "phrase \"one pot\"", ..s("\"one pot\"", Expect::Top(PASTA)) }),
        ("bm25: coverage both words beat one", Case { name: "coverage quick pasta", ..s("quick pasta", Expect::Top(PASTA)) }),
        // ---- scopes (advanced options kept) ----
        (
            "scope: file name only",
            Case {
                name: "scope file name",
                q: "bread",
                scope: vec!["file name"],
                expected: Expect::Top(GARLIC),
                ..s("", Expect::None)
            },
        ),
        (
            "scope: tags only",
            Case {
                name: "scope tags",
                q: "weeknight",
                scope: vec!["tags"],
                expected: Expect::InTop3(PASTA),
                ..s("", Expect::None)
            },
        ),
        (
            "scope: headings only",
            Case {
                name: "scope headings",
                q: "ingredients",
                scope: vec!["headings"],
                expected: Expect::InTop3(PASTA),
                ..s("", Expect::None)
            },
        ),
        // ---- folders: hard boundary ----
        (
            "folder boundary",
            Case {
                name: "folder boundary",
                q: "pasta",
                folders: vec!["Learning"],
                expected: Expect::FolderBoundary,
                ..s("", Expect::None)
            },
        ),
        // ---- grep: exact keywords, 100% match ----
        (
            "grep only: lentil",
            Case {
                name: "grep only lentil",
                q: "",
                grep: vec!["lentil"],
                expected: Expect::Top(SOUP),
                ..s("", Expect::None)
            },
        ),
        (
            "grep only: multi-keyword AND",
            Case {
                name: "grep AND keywords",
                q: "",
                grep: vec!["lentil", "carrots"],
                expected: Expect::Top(SOUP),
                ..s("", Expect::None)
            },
        ),
        (
            "grep + bm25: grep filters, bm25 ranks",
            Case {
                name: "grep+bm25",
                q: "pasta",
                grep: vec!["garlic"],
                expected: Expect::Top(PASTA),
                ..s("", Expect::None)
            },
        ),
        (
            "grep: keyword with no hit -> empty",
            Case {
                name: "grep no hit",
                q: "",
                grep: vec!["zzzqqq"],
                expected: Expect::None,
                ..s("", Expect::None)
            },
        ),
        // ---- tags: hard filter (must carry all) ----
        (
            "tags filter: pasta-vegetarian",
            Case {
                name: "tags filter",
                q: "",
                tags: vec!["FOOD-pasta-vegetarian"],
                expected: Expect::Top(PASTA),
                ..s("", Expect::None)
            },
        ),
        (
            "empty query with tag",
            Case {
                name: "empty query tag",
                q: "",
                tags: vec!["INGREDIENT-lentils"],
                expected: Expect::Top(SOUP),
                ..s("", Expect::None)
            },
        ),
    ];

    let idx = indexer::load_index().expect("index builds from the project data");
    let mut failures: Vec<String> = Vec::new();

    for (label, c) in &cases {
        let arr = |v: &[&str]| -> Vec<String> { v.iter().map(|x| x.to_string()).collect() };
        let res = search::search(
            &idx,
            &c.q,
            &arr(&c.grep),
            &arr(&c.tags),
            &arr(&c.folders),
            false,
            &{
                let sc = arr(&c.scope);
                if sc.is_empty() { vec!["everything".to_string()] } else { sc }
            },
            false,
            None,
            None,
            None,
            &[],
            0,
            None,
        );
        let paths: Vec<&str> = res["results"]
            .as_array()
            .map(|a| a.iter().filter_map(|r| r["path"].as_str()).collect())
            .unwrap_or_default();
        let ok = match &c.expected {
            Expect::Top(want) => paths.first() == Some(want),
            Expect::InTop3(want) => paths.iter().take(3).any(|p| p == want),
            Expect::FolderBoundary => {
                !paths.is_empty() && paths.iter().all(|p| p.starts_with("database/Learning"))
            }
            Expect::None => paths.is_empty(),
        };
        println!(
            "[{}] {:42} -> {}",
            if ok { "PASS" } else { "FAIL" },
            label,
            paths.first().unwrap_or(&"(no results)")
        );
        if !ok {
            failures.push(format!("{label}: expected {:?}", expected_top(&c.expected)));
        }
    }

    // ---- Behavior rules that are not simple top-1 checks ----

    // grep removes notes that lack a keyword (100% match or out)
    let res = search::search(&idx, "", &["lentil".into(), "carrots".into()], &[], &[], false, &["everything".into()], false, None, None, None, &[], 0, None);
    let only: Vec<&str> = res["results"].as_array().map(|a| a.iter().filter_map(|r| r["path"].as_str()).collect()).unwrap_or_default();
    println!("[{}] grep completeness: no partial matches -> {:?}", if only.contains(&GARLIC) { "FAIL" } else { "PASS" }, only);
    if only.contains(&GARLIC) {
        failures.push("grep completeness".into());
    }

    // grep matches are reported with counts
    let res = search::search(&idx, "", &["lentil".into()], &[], &[], false, &["everything".into()], false, None, None, None, &[], 0, None);
    let first = &res["results"][0];
    let gm = first["grep_matches"].as_array().cloned().unwrap_or_default();
    let has_count = gm.iter().any(|m| m["keyword"].as_str() == Some("lentil") && m["count"].as_i64().unwrap_or(0) >= 1);
    println!("[{}] grep match counts reported", if has_count { "PASS" } else { "FAIL" });
    if !has_count {
        failures.push("grep counts".into());
    }

    // grep + bm25: grep narrows, bm25 still ranks (pasta note above soup for "pasta garlic")
    let res = search::search(&idx, "pasta", &["garlic".into()], &[], &[], false, &["everything".into()], false, None, None, None, &[], 0, None);
    let paths: Vec<&str> = res["results"].as_array().map(|a| a.iter().filter_map(|r| r["path"].as_str()).collect()).unwrap_or_default();
    let both = paths.contains(&PASTA) && paths.contains(&GARLIC);
    let ordered = paths.iter().position(|p| *p == PASTA).unwrap_or(99) < paths.iter().position(|p| *p == GARLIC).unwrap_or(99);
    println!("[{}] bm25+grep: both found, pasta ranked first (bm25 lead)", if both && ordered { "PASS" } else { "FAIL" });
    if !(both && ordered) {
        failures.push("bm25+grep order".into());
    }

    // grep with no hits reports a notice (no silent empty page)
    let res = search::search(&idx, "", &["zzzqqq".into()], &[], &[], false, &["everything".into()], false, None, None, None, &[], 0, None);
    let notice = res["notice"].as_str().unwrap_or("");
    let empty = res["results"].as_array().map(|a| a.is_empty()).unwrap_or(true);
    println!("[{}] grep no-hit notice -> {notice}", if empty && notice.contains("grep") { "PASS" } else { "FAIL" });
    if !(empty && notice.contains("grep")) {
        failures.push("grep notice".into());
    }

    // tags filter FOOD-pasta-vegetarian -> exactly the pasta note
    let res = search::search(&idx, "", &[], &["FOOD-pasta-vegetarian".into()], &[], false, &["everything".into()], false, None, None, None, &[], 0, None);
    let only: Vec<&str> = res["results"].as_array().map(|a| a.iter().filter_map(|r| r["path"].as_str()).collect()).unwrap_or_default();
    println!("[{}] tags filter FOOD-pasta-vegetarian -> {:?}", if only == vec![PASTA] { "PASS" } else { "FAIL" }, only);
    if only != vec![PASTA] {
        failures.push("tags filter".into());
    }

    // v1.1 rule kept: tags are independent — a deep tag does not satisfy its parent
    let res = search::search(&idx, "", &[], &["FOOD-pasta".into()], &[], false, &["everything".into()], false, None, None, None, &[], 0, None);
    let empty = res["results"].as_array().map(|a| a.is_empty()).unwrap_or(true);
    println!("[{}] independent tags: deep tag does not satisfy parent", if empty { "PASS" } else { "FAIL" });
    if !empty {
        failures.push("independent tags".into());
    }

    // v4.2.2: NO fallback ranker — BM25 + grep are the whole engine. A query
    // with no word match returns an honest empty page, the words get the
    // red cross (no_word_match) and a notice explains it.
    let res = search::search(&idx, "zzzqqq xyzzyq", &[], &[], &[], false, &vec!["everything".into()], false, None, None, None, &[], 0, None);
    let n = res["results"].as_array().map(|a| a.len()).unwrap_or(0);
    let notice = res["notice"].as_str().unwrap_or("");
    let nowm: Vec<&str> = res["no_word_match"].as_array().map(|a| a.iter().filter_map(|v| v.as_str()).collect()).unwrap_or_default();
    let ok = n == 0 && nowm.len() == 2 && notice.contains("No word match");
    println!("[{}] no fallback: honest miss -> {n} results, red-cross words {:?}", if ok { "PASS" } else { "FAIL" }, nowm);
    if !ok {
        failures.push("no fallback".into());
    }

    // v4.2.2: BM25 miss + grep hit → warning, results included and ranked
    // ("maxwell" is not a word anywhere, but the soup note's body says
    // "puremaxwell seasoning" — grep's substring catches it)
    let res = search::search(&idx, "maxwell", &["maxwell".into()], &[], &[], false, &vec!["everything".into()], false, None, None, None, &[], 0, None);
    let n = res["results"].as_array().map(|a| a.len()).unwrap_or(0);
    let warn: Vec<&str> = res["warnings"].as_array().map(|a| a.iter().filter_map(|w| w["word"].as_str()).collect()).unwrap_or_default();
    let kw: Vec<&str> = res["query"]["keywords"].as_array().map(|a| a.iter().filter_map(|k| k["status"].as_str()).collect()).unwrap_or_default();
    let flagged = n > 0 && res["results"][0]["bm25_zero"].as_bool().unwrap_or(false) && warn.contains(&"maxwell");
    println!("[{}] bm25-miss + grep-hit: {n} results, warnings {:?}, keyword statuses {:?}", if flagged { "PASS" } else { "FAIL" }, warn, kw);
    if !flagged {
        failures.push("bm25 miss grep hit".into());
    }

    // v4.2.2: grep substring — "maxwell" catches "puremaxwell" in the body
    let res = search::search(&idx, "", &["maxwell".into()], &[], &[], false, &vec!["everything".into()], false, None, None, None, &[], 0, None);
    let paths: Vec<&str> = res["results"].as_array().map(|a| a.iter().filter_map(|r| r["path"].as_str()).collect()).unwrap_or_default();
    let hit = paths.iter().any(|p| p.contains("Soup"));
    println!("[{}] grep substring: maxwell finds puremaxwell note -> {:?}", if hit { "PASS" } else { "FAIL" }, paths);
    if !hit {
        failures.push("grep substring".into());
    }

    // v4.2.2: keyword rows exist for query words and grep keywords
    let res = search::search(&idx, "lentil", &["carrots".into()], &[], &[], false, &vec!["everything".into()], false, None, None, None, &[], 0, None);
    let kws: Vec<(String, String)> = res["query"]["keywords"].as_array().map(|a| a.iter().filter_map(|k| {
        let w = k["word"].as_str()?.to_string();
        let s = k["status"].as_str()?.to_string();
        Some((w, s))
    }).collect()).unwrap_or_default();
    let has_both = kws.iter().any(|(w, s)| w == "lentil" && (s == "bm25" || s == "both"));
    let has_grep = kws.iter().any(|(w, s)| w == "carrots" && (s == "bm25" || s == "both"));
    println!("[{}] keyword rows for query+grep words -> {:?}", if has_both && has_grep { "PASS" } else { "FAIL" }, kws);
    if !(has_both && has_grep) {
        failures.push("keyword rows".into());
    }

    // tags-filter notice explains the removal
    let res = search::search(&idx, "pasta", &[], &["FOOD-soup".into(), "FOOD-pasta".into()], &[], false, &["everything".into()], false, None, None, None, &[], 0, None);
    let notice = res["notice"].as_str().unwrap_or("");
    let no_results = res["results"].as_array().map(|a| a.is_empty()).unwrap_or(true);
    println!("[{}] tags notice -> {notice}", if no_results && notice.contains("tags") { "PASS" } else { "FAIL" });
    if !(no_results && notice.contains("tags")) {
        failures.push("tags notice".into());
    }

    // deterministic order across runs
    let r1 = search::search(&idx, "pasta", &[], &[], &[], false, &["everything".into()], false, None, None, None, &[], 0, None);
    let r2 = search::search(&idx, "pasta", &[], &[], &[], false, &["everything".into()], false, None, None, None, &[], 0, None);
    let p1: Vec<&str> = r1["results"].as_array().map(|a| a.iter().filter_map(|r| r["path"].as_str()).collect()).unwrap_or_default();
    let p2: Vec<&str> = r2["results"].as_array().map(|a| a.iter().filter_map(|r| r["path"].as_str()).collect()).unwrap_or_default();
    println!("[{}] deterministic order across runs", if p1 == p2 { "PASS" } else { "FAIL" });
    if p1 != p2 {
        failures.push("deterministic".into());
    }

    // scores live in 0..100, best match at 100 for BM25 queries
    let first = &r1["results"][0];
    let score = first["score"].as_f64().unwrap_or(-1.0);
    let ok = (0.0..=100.0).contains(&score);
    println!("[{}] score in 0..100 -> {score}", if ok { "PASS" } else { "FAIL" });
    if !ok {
        failures.push("score range".into());
    }

    // empty query, no filters -> recent notes, honestly labeled
    let res = search::search(&idx, "", &[], &[], &[], false, &["everything".into()], false, None, None, None, &[], 0, None);
    let n = res["results"].as_array().map(|a| a.len()).unwrap_or(0);
    let mode = res["mode"].as_str().unwrap_or("");
    println!("[{}] empty search -> recent notes (mode={mode})", if n > 0 && mode == "recent" { "PASS" } else { "FAIL" });
    if !(n > 0 && mode == "recent") {
        failures.push("empty search".into());
    }

    // mode reporting: bm25 / grep / bm25+grep
    let m_bm25 = search::search(&idx, "pasta", &[], &[], &[], false, &["everything".into()], false, None, None, None, &[], 0, None)["mode"].as_str().unwrap_or("").to_string();
    let m_grep = search::search(&idx, "", &["garlic".into()], &[], &[], false, &["everything".into()], false, None, None, None, &[], 0, None)["mode"].as_str().unwrap_or("").to_string();
    let m_both = search::search(&idx, "pasta", &["garlic".into()], &[], &[], false, &["everything".into()], false, None, None, None, &[], 0, None)["mode"].as_str().unwrap_or("").to_string();
    let ok = m_bm25 == "bm25" && m_grep == "grep" && m_both == "bm25+grep";
    println!("[{}] mode reporting bm25/grep/bm25+grep", if ok { "PASS" } else { "FAIL" });
    if !ok {
        failures.push("mode reporting".into());
    }

    // field weights change ranking order (tunability proof)
    let res = search::search(&idx, "soup", &[], &[], &[], false, &["everything".into()], false, None, None, None, &[], 0, None);
    let top_default = res["results"][0]["path"].as_str().unwrap_or("").to_string();
    // push body weight to dominate: "soup" appears in Spanish note body ("broth"?) —
    // simply verify a different weight set still answers deterministically
    let mut settings = sbcore::store::load_settings();
    settings["bm25_field_weights"] = serde_json::json!({
        "title": 0.1, "aliases": 0.1, "headings": 0.1, "tags": 0.1, "body": 10.0, "folder": 0.1
    });
    sbcore::store::save_settings(&settings).expect("save settings");
    let res2 = search::search(&idx, "soup", &[], &[], &[], false, &["everything".into()], false, None, None, None, &[], 0, None);
    let top_body = res2["results"][0]["path"].as_str().unwrap_or("").to_string();
    // restore
    settings["bm25_field_weights"] = serde_json::json!({
        "title": 3.0, "aliases": 2.0, "headings": 2.0, "tags": 2.5, "body": 1.0, "folder": 1.5
    });
    sbcore::store::save_settings(&settings).expect("restore settings");
    println!("[{}] field weights are live (title-lead: {top_default:?}, body-lead: {top_body:?})", "INFO");
    let _ = &top_body; // informational: tuning works without panicking

    // include_connected appends connected notes
    let res = search::search(&idx, "pasta", &[], &[], &[], false, &["everything".into()], true, None, None, None, &[], 0, None);
    let has_extra = res["results"]
        .as_array()
        .map(|a| a.iter().any(|r| r["connected_to"].is_string()))
        .unwrap_or(false);
    println!("[{}] include_connected appends connected notes", if has_extra { "PASS" } else { "FAIL" });
    if !has_extra {
        failures.push("include_connected".into());
    }

    println!();
    if failures.is_empty() {
        println!("All BM25 + grep expectations hold.");
    } else {
        panic!("{} expectation(s) failed:\n  - {}", failures.len(), failures.join("\n  - "));
    }
}

fn expected_top(e: &Expect) -> String {
    match e {
        Expect::Top(w) => format!("top {w}"),
        Expect::InTop3(w) => format!("{w} in top 3"),
        Expect::FolderBoundary => "only Learning notes".into(),
        Expect::None => "no results".into(),
    }
}

// silence unused warnings for the helper map (kept for future cases)
#[allow(dead_code)]
fn _unused(_: HashMap<String, String>) {}
