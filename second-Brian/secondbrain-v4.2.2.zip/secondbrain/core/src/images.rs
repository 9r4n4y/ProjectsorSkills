//! Images: attachments — add, crop (server-side via the `image` crate),
//! thumbnails, delete with backup history. A port of `core/images.py`.

use crate::error::{Result, SbError};
use crate::paths;
use crate::store;
use chrono::Local;
use serde_json::{json, Value};
use std::path::PathBuf;

pub fn attachment_path(note_rel: &str, filename: &str) -> Result<PathBuf> {
    let note_md = store::note_md_path(note_rel);
    let att = note_md.parent().unwrap().join("attachments");
    let name = std::path::Path::new(filename)
        .file_name()
        .and_then(|n| n.to_str())
        .ok_or_else(|| SbError::Invalid("Bad filename.".into()))?;
    if !paths::is_image(name) {
        return Err(SbError::Invalid("attachments/ holds image files only.".into()));
    }
    Ok(att.join(name))
}

pub fn add_attachment(note_rel: &str, filename: &str, data: &[u8], who: &str) -> Result<Value> {
    let mut target = attachment_path(note_rel, filename)?;
    std::fs::create_dir_all(target.parent().unwrap())?;
    // Same content already in this note's attachments? Point at the existing
    // file instead of writing a byte-identical copy with a new name.
    let incoming = store::text_sha256_bytes(data);
    if let Some(existing) = identical_attachment(target.parent().unwrap(), &incoming) {
        return Ok(json!({
            "file": format!("attachments/{}", existing),
            "bytes": existing_len(target.parent().unwrap(), &existing),
            "duplicate": true,
        }));
    }
    if target.exists() {
        let stem = target.file_stem().and_then(|s| s.to_str()).unwrap_or("img").to_string();
        let ext = target.extension().and_then(|e| e.to_str()).unwrap_or("png").to_string();
        target = target.with_file_name(format!(
            "{stem}-{}.{ext}",
            Local::now().format("%H%M%S")
        ));
    }
    std::fs::write(&target, data)?;
    crate::editlog::record_change(
        who,
        &format!("Added attachment {}", target.file_name().and_then(|n| n.to_str()).unwrap_or("")),
        vec![crate::editlog::UndoStep {
            op: "write".into(),
            path: Some(paths::rel(&target)),
            before: None,
            from: None,
            to: None,
        }],
    )?;
    Ok(json!({
        "file": format!("attachments/{}", target.file_name().and_then(|n| n.to_str()).unwrap_or("")),
        "bytes": data.len(),
    }))
}

/// Files with the same bytes already living in this attachments folder.
fn identical_attachment(dir: &std::path::Path, hash: &str) -> Option<String> {
    let mut names: Vec<String> = std::fs::read_dir(dir).ok()?
        .filter_map(|e| e.ok())
        .filter(|e| e.path().is_file())
        .filter_map(|e| e.file_name().to_str().map(String::from))
        .filter(|n| paths::is_image(n) && !n.contains(".deleted-") && !n.contains(".pre-crop-"))
        .collect();
    names.sort();
    for name in names {
        if let Ok(h) = store::sha256_of(&dir.join(&name)) {
            if h == hash {
                return Some(name);
            }
        }
    }
    None
}

fn existing_len(dir: &std::path::Path, name: &str) -> usize {
    std::fs::metadata(dir.join(name)).map(|m| m.len() as usize).unwrap_or(0)
}

/// Crop = save as a NEW image, then either replace the original in this note
/// (the old image is backed up first) or keep both.
pub fn crop_image(
    note_rel: &str,
    filename: &str,
    rect: &Value,
    mode: &str,
    who: &str,
) -> Result<Value> {
    let src = attachment_path(note_rel, filename)?;
    if !src.exists() {
        return Err(SbError::NotFound(format!("Image {filename} not found in {note_rel}.")));
    }
    let x = rect.get("x").and_then(|v| v.as_i64()).unwrap_or(0).max(0) as u32;
    let y = rect.get("y").and_then(|v| v.as_i64()).unwrap_or(0).max(0) as u32;
    let w = rect.get("w").and_then(|v| v.as_i64()).unwrap_or(0) as u32;
    let h = rect.get("h").and_then(|v| v.as_i64()).unwrap_or(0) as u32;
    let img = image::ImageReader::open(&src)
        .map_err(|e| SbError::Io(e.to_string()))?
        .decode()
        .map_err(|e| SbError::Invalid(format!("Could not read image: {e}")))?;
    let (width, height) = (img.width(), img.height());
    let x = x.min(width.saturating_sub(1));
    let y = y.min(height.saturating_sub(1));
    let w = w.min(width - x);
    let h = h.min(height - y);
    if w < 2 || h < 2 {
        return Err(SbError::Invalid("Crop rectangle is too small.".into()));
    }
    let cropped = img.crop_imm(x, y, w, h);
    let stamp = Local::now().format("%Y%m%d-%H%M%S");
    let stem = src.file_stem().and_then(|s| s.to_str()).unwrap_or("img").to_string();
    let ext = src
        .extension()
        .and_then(|e| e.to_str())
        .unwrap_or("png")
        .to_lowercase();
    let new_name = format!("{stem}-crop-{stamp}.{ext}");
    let new_path = src.parent().unwrap().join(&new_name);
    match ext.as_str() {
        "jpg" | "jpeg" => cropped.save_with_format(&new_path, image::ImageFormat::Jpeg)?,
        "webp" => cropped.save_with_format(&new_path, image::ImageFormat::WebP)?,
        "gif" => cropped.save_with_format(&new_path, image::ImageFormat::Gif)?,
        "bmp" => cropped.save_with_format(&new_path, image::ImageFormat::Bmp)?,
        _ => cropped.save_with_format(&new_path, image::ImageFormat::Png)?,
    }

    let mut old_renamed: Option<String> = None;
    if mode == "replace" {
        let orig = format!("{stem}.pre-crop-{stamp}.{ext}");
        std::fs::rename(&src, src.parent().unwrap().join(&orig))?;
        std::fs::rename(&new_path, &src)?;
        old_renamed = Some(orig);
    }
    crate::editlog::record_change(
        who,
        &format!("Cropped image {filename}"),
        vec![crate::editlog::UndoStep {
            op: "write".into(),
            path: Some(paths::rel(&new_path)),
            before: None,
            from: None,
            to: None,
        }],
    )?;
    let mut out = json!({
        "new_image": format!("attachments/{new_name}"),
        "w": w, "h": h,
    });
    if let Some(orig) = old_renamed {
        out["original_backed_up_as"] = json!(format!("attachments/{orig}"));
    }
    Ok(out)
}

fn thumb_path(src: &std::path::Path, width: u32) -> PathBuf {
    let meta = src.metadata().ok();
    let stamp = format!(
        "{}-{}",
        meta.as_ref().map(|m| m.len()).unwrap_or(0),
        meta.as_ref()
            .and_then(|m| m.modified().ok())
            .and_then(|t| t.duration_since(std::time::UNIX_EPOCH).ok())
            .map(|d| d.as_secs())
            .unwrap_or(0)
    );
    let stem = src.file_stem().and_then(|s| s.to_str()).unwrap_or("img");
    paths::CACHE.join("thumbs").join(format!("{stem}-{stamp}-w{width}.png"))
}

/// The image grid uses thumbnails; the full file loads only in full screen.
/// Returns a thumbnail path, or the original when resizing fails (the
/// browser scales it down instead).
/// GIFs are passed through UNTOUCHED: re-encoding to PNG would freeze the
/// animation on the first frame — the grid scales them with CSS instead.
pub fn thumbnail(src: &std::path::Path, width: u32) -> PathBuf {
    let width = width.clamp(80, 1600);
    let is_gif = src
        .extension()
        .and_then(|e| e.to_str())
        .map(|e| e.eq_ignore_ascii_case("gif"))
        .unwrap_or(false);
    if is_gif {
        return src.to_path_buf();
    }
    let out = thumb_path(src, width);
    if out.exists() {
        return out;
    }
    let img = match image::ImageReader::open(src) {
        Ok(r) => match r.decode() {
            Ok(i) => i,
            Err(_) => return src.to_path_buf(),
        },
        Err(_) => return src.to_path_buf(),
    };
    let ratio = if img.width() > 0 { width as f64 / img.width() as f64 } else { 1.0 };
    let small = img.resize(
        width,
        ((img.height() as f64 * ratio) as u32).max(1),
        image::imageops::FilterType::Lanczos3,
    );
    let _ = std::fs::create_dir_all(out.parent().unwrap());
    if small.save_with_format(&out, image::ImageFormat::Png).is_err() {
        return src.to_path_buf();
    }
    out
}

/// Delete asks for confirmation in the UI; the file itself is kept in
/// backup history by renaming it inside attachments/.
pub fn delete_image(note_rel: &str, filename: &str, who: &str) -> Result<Value> {
    let src = attachment_path(note_rel, filename)?;
    if !src.exists() {
        return Err(SbError::NotFound(format!("Image {filename} not found in {note_rel}.")));
    }
    let md = store::note_md_path(note_rel);
    let text = std::fs::read_to_string(&md).unwrap_or_default();
    if text.contains(filename) {
        return Ok(json!({
            "warning": true,
            "message": "This note still points to the image in its text. Remove or change that image Markdown first, or confirm you want to delete it anyway."
        }));
    }
    let stamp = Local::now().format("%Y%m%d-%H%M%S");
    let stem = src.file_stem().and_then(|s| s.to_str()).unwrap_or("img").to_string();
    let ext = src.extension().and_then(|e| e.to_str()).unwrap_or("png").to_string();
    let kept_name = format!("{stem}.deleted-{stamp}.{ext}");
    let kept = src.parent().unwrap().join(&kept_name);
    std::fs::rename(&src, &kept)?;
    crate::editlog::record_change(
        who,
        &format!("Deleted image {filename}"),
        vec![crate::editlog::UndoStep {
            op: "move".into(),
            path: None,
            before: None,
            from: Some(paths::rel(&src)),
            to: Some(paths::rel(&kept)),
        }],
    )?;
    Ok(json!({"deleted": true, "kept_as": format!("attachments/{kept_name}")}))
}
