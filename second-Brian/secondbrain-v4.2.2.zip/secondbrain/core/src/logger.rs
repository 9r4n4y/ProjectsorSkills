//! Logs and undo (v4 rules).
//!
//! v4 logging rules (see LOGS.md):
//! - `logs/` holds MANUAL entries only — written by the user (Log page) or
//!   by the AI on explicit instruction (the `add_log_entry` tool). The engine
//!   itself never creates files in `logs/` on its own.
//! - The ONE automatic file is `logs/edits.md` — the note-edit history
//!   (which note was edited, which lines were added and removed). See
//!   `editlog.rs`.
//! - Nothing is ever reversed automatically: undo runs only when the user
//!   (or the AI on the user's behalf) asks, and only through the internal
//!   undo journal (`core/.cache/undo-journal.json`), never through logs.
//! - Log files are never edited or deleted after they are written.

use crate::error::{Result, SbError};
use crate::paths;
use chrono::Local;
use once_cell::sync::Lazy;
use regex::Regex;

pub fn who_name(who: &str) -> String {
    match who {
        "" => "user".to_string(),
        "user" => "user".to_string(),
        "ai" => "AI".to_string(),
        other => other.to_string(),
    }
}

fn slug(title: &str) -> String {
    static BAD: Lazy<Regex> = Lazy::new(|| Regex::new(r"[^A-Za-z0-9 _-]").unwrap());
    let s = BAD.replace_all(title, "").trim().replace(' ', "_");
    let s = s.chars().take(60).collect::<String>();
    if s.is_empty() {
        "Change".to_string()
    } else {
        s
    }
}

/// Write one MANUAL log file and return its name. Only the user or the AI
/// (with a name and a title) call this — the engine never calls it by itself.
pub fn new_log(who: &str, title: &str, details: &str) -> String {
    let now = Local::now();
    let name = format!(
        "{}_{}.md",
        now.format("%Y-%m-%d_%H-%M-%S"),
        slug(title)
    );
    let path = paths::LOGS.join(&name);
    let _ = std::fs::create_dir_all(paths::LOGS.as_path());
    let body = format!(
        "# {title}\n\n- **When:** {}\n- **Who:** {}\n- **Title:** {title}\n\n## What was done\n\n{}\n\n---\n\nLog files are never edited or deleted after they are written.\n",
        now.format("%Y-%m-%d %H:%M:%S"),
        who_name(who),
        details.trim()
    );
    let tmp = path.with_extension("tmp");
    if std::fs::write(&tmp, body).is_ok() {
        let _ = std::fs::rename(&tmp, &path);
    }
    name
}

/// Newest first. Each row: file name, when, who, title.
pub fn list_logs(limit: usize) -> Vec<serde_json::Value> {
    static PAT: Lazy<Regex> =
        Lazy::new(|| Regex::new(r"^(\d{4}-\d{2}-\d{2})_(\d{2})-(\d{2})-(\d{2})_(.+)\.md$").unwrap());
    static WHO_RE: Lazy<Regex> = Lazy::new(|| Regex::new(r"\*\*Who:\*\* (.+)").unwrap());
    static TITLE_RE: Lazy<Regex> = Lazy::new(|| Regex::new(r"(?m)^# (.+)$").unwrap());

    let mut files: Vec<std::path::PathBuf> = Vec::new();
    if let Ok(rd) = std::fs::read_dir(paths::LOGS.as_path()) {
        for e in rd.filter_map(|e| e.ok()) {
            let p = e.path();
            if p.is_file() && PAT.is_match(p.file_name().and_then(|n| n.to_str()).unwrap_or(""))
            {
                files.push(p);
            }
        }
    }
    files.sort_by(|a, b| b.cmp(a)); // newest first by name
    let mut out = Vec::new();
    for f in files.into_iter().take(limit) {
        let name = f.file_name().and_then(|n| n.to_str()).unwrap_or("").to_string();
        let caps = PAT.captures(&name);
        let text = std::fs::read_to_string(&f).unwrap_or_default();
        let who = WHO_RE
            .captures(&text)
            .map(|c| c[1].trim().to_string())
            .unwrap_or_else(|| "?".into());
        let title = TITLE_RE
            .captures(&text)
            .map(|c| c[1].trim().to_string())
            .unwrap_or_default();
        let (date, time, fallback) = match &caps {
            Some(c) => (c[1].to_string(), format!("{}:{}:{}", &c[2], &c[3], &c[4]), c[5].to_string()),
            None => (String::new(), String::new(), name.clone()),
        };
        out.push(serde_json::json!({
            "file": name,
            "date": format!("{date} {time}"),
            "who": who,
            "title": if title.is_empty() { fallback.replace('_', " ") } else { title },
        }));
    }
    out
}

pub fn read_log(log_name: &str) -> Result<String> {
    let safe = std::path::Path::new(log_name)
        .file_name()
        .and_then(|n| n.to_str())
        .ok_or_else(|| SbError::Invalid("Bad log name.".into()))?;
    let path = paths::LOGS.join(safe);
    // accept both "edits" and "edits.md"
    let path = if path.exists() || safe.ends_with(".md") {
        path
    } else {
        paths::LOGS.join(format!("{safe}.md"))
    };
    if !path.exists() {
        return Err(SbError::NotFound(format!("Log {log_name} not found.")));
    }
    Ok(std::fs::read_to_string(path)?)
}
