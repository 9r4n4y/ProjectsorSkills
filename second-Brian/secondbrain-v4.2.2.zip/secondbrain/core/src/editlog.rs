//! The undo journal + the ONE automatic log (`logs/edits.md`).
//!
//! v4 log rules:
//! - `logs/` is manual only (see logger.rs). The engine writes exactly one
//!   automatic file: `logs/edits.md`, the note-edit history — which note was
//!   edited, when, and which lines were added and removed.
//! - Undo information lives in the internal journal
//!   `core/.cache/undo-journal.json` (NOT in logs/): every store operation
//!   records its reversal steps there under a change id. Undo runs only when
//!   the user asks; nothing is ever reversed automatically.

use crate::error::{Result, SbError};
use crate::paths;
use chrono::Local;
use once_cell::sync::Lazy;

#[derive(Debug, Clone, serde::Serialize, serde::Deserialize)]
pub struct UndoStep {
    pub op: String, // "write" | "move" | "mkdir" | "copy"
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub path: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub before: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub from: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub to: Option<String>,
}

#[derive(Debug, Clone, serde::Serialize, serde::Deserialize)]
pub struct Change {
    pub id: String,
    pub when: String,
    pub who: String,
    pub title: String,
    pub steps: Vec<UndoStep>,
}

pub fn journal_path() -> std::path::PathBuf {
    paths::CACHE.join("undo-journal.json")
}

fn load_journal() -> Vec<Change> {
    let text = match std::fs::read_to_string(journal_path()) {
        Ok(t) => t,
        Err(_) => return Vec::new(),
    };
    serde_json::from_str(&text).unwrap_or_default()
}

fn save_journal(changes: &[Change]) -> Result<()> {
    std::fs::create_dir_all(paths::CACHE.as_path())?;
    let tmp = journal_path().with_extension("tmp");
    std::fs::write(&tmp, serde_json::to_string(changes)?)?;
    std::fs::rename(&tmp, journal_path())?;
    Ok(())
}

/// Record a change with its undo steps. Returns the change id.
pub fn record_change(who: &str, title: &str, steps: Vec<UndoStep>) -> Result<String> {
    let mut journal = load_journal();
    let id = format!("c{:08x}", std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .map(|d| d.subsec_nanos() as u64 + d.as_secs() % 1_000_000_000)
        .unwrap_or(0));
    journal.push(Change {
        id: id.clone(),
        when: Local::now().format("%Y-%m-%d %H:%M:%S").to_string(),
        who: who.to_string(),
        title: title.to_string(),
        steps,
    });
    // keep the journal bounded: the most recent 500 changes
    if journal.len() > 500 {
        let start = journal.len() - 500;
        journal = journal.split_off(start);
    }
    save_journal(&journal)?;
    Ok(id)
}

pub fn list_changes(limit: usize) -> Vec<serde_json::Value> {
    let journal = load_journal();
    journal
        .iter()
        .rev()
        .take(limit)
        .map(|c| {
            serde_json::json!({
                "id": c.id, "when": c.when, "who": c.who, "title": c.title,
                "steps": c.steps.len(),
            })
        })
        .collect()
}

pub fn get_change(id: &str) -> Result<Change> {
    let journal = load_journal();
    journal
        .iter()
        .find(|c| c.id == id)
        .cloned()
        .ok_or_else(|| SbError::NotFound(format!("Change {id:?} not found in the journal.")))
}

fn atomic_write(path: &std::path::Path, data: &str) -> Result<()> {
    if let Some(parent) = path.parent() {
        std::fs::create_dir_all(parent)?;
    }
    let tmp = path.with_file_name(format!(
        "{}.tmp",
        path.file_name().and_then(|n| n.to_str()).unwrap_or("file")
    ));
    std::fs::write(&tmp, data)?;
    std::fs::rename(&tmp, path)?;
    Ok(())
}

/// Reverse the change recorded under `id`. Nothing ever reverses itself:
/// this runs only when the user (or the AI on the user's behalf) asks.
/// Returns a short report.
pub fn apply_undo(id: &str, who: &str) -> Result<String> {
    let change = get_change(id)?;
    let mut details = vec![
        format!("Undo of change `{}` ({}).", change.id, change.title),
        format!(
            "- Requested by: {} (the steps below were applied now).",
            crate::logger::who_name(who)
        ),
    ];
    for step in change.steps.iter().rev() {
        match step.op.as_str() {
            "write" => {
                let p = paths::ROOT.join(step.path.as_deref().unwrap_or(""));
                match &step.before {
                    None => {
                        if p.exists() {
                            let _ = std::fs::remove_file(&p);
                            details.push(format!(
                                "- Removed `{}` (it did not exist before).",
                                step.path.as_deref().unwrap_or("")
                            ));
                        }
                    }
                    Some(old) => {
                        atomic_write(&p, old)?;
                        details.push(format!(
                            "- Restored previous content of `{}`.",
                            step.path.as_deref().unwrap_or("")
                        ));
                    }
                }
            }
            "move" => {
                let src = paths::ROOT.join(step.to.as_deref().unwrap_or(""));
                let dst = paths::ROOT.join(step.from.as_deref().unwrap_or(""));
                if src.exists() {
                    if let Some(parent) = dst.parent() {
                        std::fs::create_dir_all(parent)?;
                    }
                    std::fs::rename(&src, &dst)?;
                    details.push(format!(
                        "- Moved `{}` back to `{}`.",
                        step.to.as_deref().unwrap_or(""),
                        step.from.as_deref().unwrap_or("")
                    ));
                }
            }
            "mkdir" => {
                let p = paths::ROOT.join(step.path.as_deref().unwrap_or(""));
                if p.is_dir()
                    && std::fs::read_dir(&p).map(|mut d| d.next().is_none()).unwrap_or(false)
                {
                    let _ = std::fs::remove_dir(&p);
                    details.push(format!(
                        "- Removed empty folder `{}`.",
                        step.path.as_deref().unwrap_or("")
                    ));
                }
            }
            "copy" => {
                let dst = paths::ROOT.join(step.to.as_deref().unwrap_or(""));
                if dst.exists() {
                    let _ = std::fs::remove_file(&dst);
                    details.push(format!(
                        "- Removed copy `{}`.",
                        step.to.as_deref().unwrap_or("")
                    ));
                }
            }
            _ => {}
        }
    }
    let title = format!("Undo (requested by {}): {}", crate::logger::who_name(who), change.title);
    // The undo record itself is journal-only; the report goes back to the UI.
    let _ = record_change(
        who,
        &title,
        vec![UndoStep {
            op: "note".into(),
            path: None,
            before: Some(format!("Redo by re-applying change {}", change.id)),
            from: None,
            to: None,
        }],
    )?;
    Ok(details.join("\n"))
}

// --------------------------------------------------------------------------
// The automatic note-edit history: logs/edits.md
// --------------------------------------------------------------------------

pub fn edits_path() -> std::path::PathBuf {
    paths::LOGS.join("edits.md")
}

/// A simple line diff: which lines were added and which were removed
/// (by content, in order of first appearance).
pub fn line_diff(old: &str, new: &str) -> (Vec<String>, Vec<String>) {
    let old_lines: Vec<&str> = old.lines().collect();
    let new_lines: Vec<&str> = new.lines().collect();
    let mut removed: Vec<String> = Vec::new();
    let mut added: Vec<String> = Vec::new();
    // LCS via dynamic programming on lines; bounded to keep it cheap.
    let cap = 4000;
    let (o, n): (Vec<&str>, Vec<&str>) = if old_lines.len() > cap {
        (old_lines[..cap].to_vec(), new_lines.clone())
    } else if new_lines.len() > cap {
        (old_lines.clone(), new_lines[..cap].to_vec())
    } else {
        (old_lines.clone(), new_lines.clone())
    };
    if o.len() * n.len() > 4_000_000 {
        // Fall back to counting-only diff for very large texts.
        for l in &o {
            if !n.contains(l) {
                removed.push((*l).to_string());
            }
        }
        for l in &n {
            if !o.contains(l) {
                added.push((*l).to_string());
            }
        }
        return (added, removed);
    }
    let rows = o.len();
    let cols = n.len();
    let mut dp = vec![0u32; (rows + 1) * (cols + 1)];
    for i in (0..rows).rev() {
        for j in (0..cols).rev() {
            dp[i * (cols + 1) + j] = if o[i] == n[j] {
                dp[(i + 1) * (cols + 1) + j + 1] + 1
            } else {
                dp[(i + 1) * (cols + 1) + j].max(dp[i * (cols + 1) + j + 1])
            };
        }
    }
    let (mut i, mut j) = (0usize, 0usize);
    while i < rows && j < cols {
        if o[i] == n[j] {
            i += 1;
            j += 1;
        } else if dp[(i + 1) * (cols + 1) + j] >= dp[i * (cols + 1) + j + 1] {
            removed.push(o[i].to_string());
            i += 1;
        } else {
            added.push(n[j].to_string());
            j += 1;
        }
    }
    while i < rows {
        removed.push(o[i].to_string());
        i += 1;
    }
    while j < cols {
        added.push(n[j].to_string());
        j += 1;
    }
    (added, removed)
}

fn diff_summary(lines: &[String], max: usize) -> String {
    if lines.is_empty() {
        return "(none)".to_string();
    }
    let shown: Vec<String> = lines
        .iter()
        .take(max)
        .map(|l| {
            let t = l.trim();
            if t.is_empty() {
                "(empty line)".to_string()
            } else {
                crate::textutil::truncate(t, 120)
            }
        })
        .collect();
    let mut out = shown.join(" | ");
    if lines.len() > max {
        out.push_str(&format!(" … (+{} more)", lines.len() - max));
    }
    out
}

/// Append one entry to `logs/edits.md` — the ONLY thing the engine adds to
/// logs/ automatically: which note was edited and which lines were
/// added/removed. Also stores the undo step in the journal.
pub fn record_note_edit(note_rel: &str, who: &str, old: &str, new: &str) -> Result<()> {
    let (added, removed) = line_diff(old, new);
    let now = Local::now();
    let title = note_rel
        .rsplit('/')
        .next()
        .unwrap_or(note_rel)
        .trim_end_matches(".md")
        .to_string();
    let entry = format!(
        "## {} — edited {} — by {}\n\
         - Note: {}\n\
         - Lines added: {} — {}\n\
         - Lines removed: {} — {}\n\n",
        now.format("%Y-%m-%d %H:%M:%S"),
        title,
        crate::logger::who_name(who),
        note_rel,
        added.len(),
        diff_summary(&added, 8),
        removed.len(),
        diff_summary(&removed, 8),
    );
    let path = edits_path();
    let mut text = match std::fs::read_to_string(&path) {
        Ok(t) => t,
        Err(_) => {
            "# Note edit history (automatic)\n\n\
             This file is the ONE thing the engine adds to logs/ by itself. \
             Every note edit lands here: which note, when, who, and which \
             lines were added and removed. Nothing else in logs/ is ever \
             written automatically — everything else is manual (see LOGS.md).\n\n"
                .to_string()
        }
    };
    text.push_str(&entry);
    atomic_write(&path, &text)
}

/// The parsed edit history for the UI / MCP (newest first).
pub fn edit_history(limit: usize) -> Vec<serde_json::Value> {
    let text = match std::fs::read_to_string(edits_path()) {
        Ok(t) => t,
        Err(_) => return Vec::new(),
    };
    static HEAD: Lazy<regex::Regex> = Lazy::new(|| {
        regex::Regex::new(
            r"^## (\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}) — edited (.+?) — by (.+)$",
        )
        .unwrap()
    });
    static FIELD: Lazy<regex::Regex> =
        Lazy::new(|| regex::Regex::new(r"^- (Note|Lines added|Lines removed): (.*)$").unwrap());
    let mut out: Vec<serde_json::Value> = Vec::new();
    let mut current: Option<serde_json::Map<String, serde_json::Value>> = None;
    for line in text.lines() {
        if let Some(c) = HEAD.captures(line) {
            if let Some(done) = current.take() {
                out.push(serde_json::Value::Object(done));
            }
            let mut m = serde_json::Map::new();
            m.insert("when".into(), serde_json::json!(c[1]));
            m.insert("note".into(), serde_json::json!(c[2]));
            m.insert("who".into(), serde_json::json!(c[3]));
            current = Some(m);
        } else if let Some(cur) = current.as_mut() {
            if let Some(f) = FIELD.captures(line) {
                let key = match &f[1] {
                    "Note" => "note_path",
                    "Lines added" => "lines_added",
                    _ => "lines_removed",
                };
                cur.insert(key.into(), serde_json::json!(f[2].trim()));
            }
        }
    }
    if let Some(done) = current.take() {
        out.push(serde_json::Value::Object(done));
    }
    out.into_iter().take(limit).collect()
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_line_diff() {
        let (added, removed) = line_diff("a\nb\nc", "a\nx\nc\nd");
        assert_eq!(added, vec!["x", "d"]);
        assert_eq!(removed, vec!["b"]);
    }
}
