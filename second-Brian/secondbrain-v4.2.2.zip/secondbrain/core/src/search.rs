//! The BM25 search engine with optional grep exact-matching.
//!
//! v4.2 replaces the old multi-signal weighted ranker (tags / title /
//! headings / neighbors / body / closeness with rank + strict modes).
//! **BM25 is now the ranking algorithm**: a field-weighted BM25 (BM25F)
//! scores every note over six fields — title, aliases, headings (incl. quick
//! info labels), body (incl. quick info values), tags and folder path.
//!
//! **Grep** is an optional, separate stage: a list of keywords that must
//! appear in the note *literally* (case ignored), AND-combined — a keyword
//! you put there matches 100% or the note is out. You decide per search:
//! - BM25 only (a query, no grep keywords) — ranked order, nothing excluded;
//! - grep only (no query, keywords set) — exact matches, ranked by hit count;
//! - both (query + keywords) — grep filters, BM25 ranks the survivors.
//!
//! Scopes (everything / file name / tags / headings / body / folder path)
//! narrow which fields are searched. Selected tags, folders, status and
//! dates are hard filters. A fallback keeps BM25-only results from ever
//! being blank. No semantic model, no embeddings — and it still ranks
//! notes, never text chunks.

use crate::indexer::{Index, NoteEntry};
use crate::paths;
use crate::store;
use crate::tags as tags_mod;
use crate::textutil::{
    is_filler, is_keep_word, key_of, levenshtein_leq1, normalize, stem, tokenize,
};
use std::collections::{BTreeMap, HashMap, HashSet};
use std::time::Instant;

// --------------------------------------------------------------------------
// Built-in general synonyms (the master file can add more)
// --------------------------------------------------------------------------

pub fn builtin_synonyms() -> HashMap<&'static str, Vec<&'static str>> {
    HashMap::from([
        ("quick", vec!["fast", "rapid", "speedy"]),
        ("fast", vec!["quick", "rapid", "speedy"]),
        ("rapid", vec!["quick", "fast", "speedy"]),
        ("speedy", vec!["quick", "fast", "rapid"]),
        ("recipe", vec!["dish", "meal"]),
        ("dish", vec!["recipe", "meal"]),
        ("meal", vec!["recipe", "dish"]),
        ("dinner", vec!["supper", "evening meal", "meal"]),
        ("lunch", vec!["midday meal", "meal"]),
        ("veggie", vec!["vegetable"]),
        ("vegetable", vec!["veggie"]),
        ("picture", vec!["image", "photo"]),
        ("photo", vec!["image", "picture"]),
        ("image", vec!["picture", "photo"]),
        ("word", vec!["vocabulary", "term"]),
        ("vocabulary", vec!["words", "terms"]),
        ("plan", vec!["planning", "idea"]),
        ("make", vec!["cook", "prepare"]),
    ])
}

// --------------------------------------------------------------------------
// Step 1: understand the query (unchanged from v4.1)
// --------------------------------------------------------------------------

#[derive(Debug, Clone, Default)]
pub struct Group {
    pub terms: Vec<(String, f64)>,
    pub phrase: bool,
    pub text: String,
    pub phrase_tokens: Vec<String>,
}

pub struct ParsedQuery {
    pub groups: Vec<Group>,
    pub query_tags: Vec<String>,
    pub phrases: Vec<String>,
    pub only_fillers: bool,
}

pub fn parse_query(q: &str, master: &tags_mod::MasterTags, settings: &serde_json::Value) -> ParsedQuery {
    static PHRASE_RE: once_cell::sync::Lazy<regex::Regex> =
        once_cell::sync::Lazy::new(|| regex::Regex::new(r#""([^"]+)""#).unwrap());
    let q = q.trim();
    let phrases: Vec<String> =
        PHRASE_RE.captures_iter(q).map(|c| c[1].to_string()).collect();
    let q_no_quotes = PHRASE_RE.replace_all(q, " ").to_string();
    let norm = normalize(&q_no_quotes);
    let all_words = tokenize(&norm);

    let only_fillers = !all_words.is_empty()
        && all_words.iter().all(|w| is_filler(w) && !is_keep_word(w));
    let words: Vec<String> = if only_fillers {
        all_words.clone()
    } else {
        all_words
            .iter()
            .filter(|w| !is_filler(w) || is_keep_word(w))
            .cloned()
            .collect()
    };

    let max_groups = settings
        .get("max_word_groups")
        .and_then(|v| v.as_i64())
        .unwrap_or(12) as usize;
    let mut groups: Vec<Group> = Vec::new();

    let tag_lookup = tags_mod::tag_synonym_to_tag(master);
    let mut query_tags: Vec<String> = Vec::new();

    // A word (or short run of words) matching an approved tag or a tag
    // synonym also becomes a query tag.
    {
        let mut found = false;
        'outer: for n in (2..=4).rev() {
            let mut i = 0;
            while i + n <= words.len() {
                let run = words[i..i + n].join(" ");
                if let Some(hit) = tag_lookup.get(&run.replace(' ', "-")) {
                    query_tags.push(hit.clone());
                    found = true;
                    break 'outer;
                }
                i += 1;
            }
        }
        let _ = found;
        for w in &words {
            if let Some(hit) = tag_lookup.get(w) {
                query_tags.push(hit.clone());
            }
        }
    }

    let mut gen_syn: HashMap<String, Vec<String>> = master.general_synonyms.clone();
    for (k, v) in builtin_synonyms() {
        gen_syn.entry(k.to_string()).or_insert_with(|| v.iter().map(|s| s.to_string()).collect());
    }

    let synonym_weight = settings
        .get("synonym_weight")
        .and_then(|v| v.as_f64())
        .unwrap_or(0.7);

    for w in &words {
        if groups.len() >= max_groups {
            break;
        }
        let s = stem(w);
        let mut terms: Vec<(String, f64)> = vec![(w.clone(), 1.0), (s.clone(), 1.0)];
        if let Some(syns) = gen_syn.get(w) {
            for syn in syns {
                for t in tokenize(syn) {
                    terms.push((t.clone(), synonym_weight));
                    terms.push((stem(&t), synonym_weight));
                }
            }
        }
        let mut seen: HashSet<String> = HashSet::new();
        terms.retain(|(t, _)| seen.insert(t.clone()));
        groups.push(Group { terms, phrase: false, text: w.clone(), phrase_tokens: Vec::new() });
    }
    for ph in &phrases {
        if groups.len() >= max_groups {
            break;
        }
        let toks = tokenize(ph);
        let terms: Vec<(String, f64)> =
            toks.first().map(|t| vec![(t.clone(), 1.0)]).unwrap_or_default();
        groups.push(Group {
            terms,
            phrase: true,
            text: ph.trim().to_string(),
            phrase_tokens: toks,
        });
    }

    // de-duplicate query tags, keep order
    let mut seen: HashSet<String> = HashSet::new();
    query_tags.retain(|t| seen.insert(key_of(t)));
    ParsedQuery { groups, query_tags, phrases, only_fillers }
}

// --------------------------------------------------------------------------
// Typo tolerance + fragment (prefix) expansion — kept from v4.1.
// These feed BM25 as term weights: exact 1.0, prefix 0.9, typo 0.7.
// Mid-word SUBSTRING matching is grep's exclusive job (v4.2.2) so the
// engines stay distinct: BM25 misses a word → red cross; grep still finds
// it inside a bigger word → amber warning, included in the ranking.
// --------------------------------------------------------------------------

fn typo_words(idx: &Index, w: &str, min_len: usize) -> Vec<String> {
    if w.chars().count() < min_len {
        return Vec::new();
    }
    let mut cands: HashSet<String> = HashSet::new();
    let mut variants: Vec<String> = vec![w.to_string()];
    let chars: Vec<char> = w.chars().collect();
    for i in 0..chars.len() {
        let v: String = chars
            .iter()
            .enumerate()
            .filter(|(j, _)| *j != i)
            .map(|(_, c)| c)
            .collect();
        variants.push(v);
    }
    for v in &variants {
        if let Some(bucket) = idx.typo_buckets.get(v) {
            for cand in bucket {
                if cand != w && levenshtein_leq1(w, cand) {
                    cands.insert(cand.clone());
                }
            }
        }
    }
    let mut out: Vec<String> = cands.into_iter().collect();
    out.sort();
    out
}

fn apply_typo_corrections(
    idx: &Index,
    groups: &mut Vec<Group>,
    settings: &serde_json::Value,
) -> bool {
    let min_len = settings
        .get("typo_min_length")
        .and_then(|v| v.as_i64())
        .unwrap_or(5) as usize;
    if !settings
        .get("typo_tolerance")
        .and_then(|v| v.as_bool())
        .unwrap_or(true)
    {
        return false;
    }
    let mut added = false;
    for g in groups.iter_mut() {
        if g.phrase || g.text.chars().count() < min_len {
            continue;
        }
        if g.terms.iter().any(|(t, _)| idx.df.contains_key(t) || idx.h_df.contains_key(t)) {
            continue;
        }
        for c in typo_words(idx, &g.text, min_len) {
            let w = settings
                .get("synonym_weight")
                .and_then(|v| v.as_f64())
                .unwrap_or(0.7);
            g.terms.push((c.clone(), w));
            g.terms.push((stem(&c), w));
            added = true;
        }
        let mut seen: HashSet<String> = HashSet::new();
        g.terms.retain(|(t, _)| seen.insert(t.clone()));
    }
    added
}

fn collect_vocab(idx: &Index) -> Vec<String> {
    let mut set: HashSet<String> = HashSet::new();
    for w in idx.all_df.keys() {
        set.insert(w.clone());
    }
    for e in idx.files.values() {
        for t in &e.title_tokens {
            set.insert(t.clone());
        }
        for t in tokenize(&e.tag_text) {
            set.insert(t);
        }
        for t in e.folder_path.split_whitespace() {
            set.insert(t.to_string());
        }
    }
    let mut out: Vec<String> = set.into_iter().collect();
    out.sort();
    out
}

/// Expand one query word into vocabulary words: exact (kept by the caller)
/// and prefix (0.9) — a fragment that BEGINS a word (garl → garlic) still
/// ranks, so search-as-you-type keeps working. Mid-word substring expansion
/// was REMOVED in v4.2.2: catching a keyword inside a bigger word
/// (maxwell → puremaxwell) is grep's job, and BM25 must stay word-level so
/// "no word match" (red cross) vs "grep found it" (amber warning) stay
/// honest and distinct. Deterministic order; caps keep the term list small.
fn expand_word(idx: &Index, vocab: &[String], word: &str, settings: &serde_json::Value) -> Vec<(String, f64)> {
    let prefix_min = settings
        .get("prefix_min_length")
        .and_then(|v| v.as_i64())
        .unwrap_or(2) as usize;
    let prefix_cap = settings
        .get("prefix_max_expansions")
        .and_then(|v| v.as_i64())
        .unwrap_or(12) as usize;

    let s = stem(word);
    let mut out: Vec<(String, f64)> = Vec::new();
    let mut seen: HashSet<String> = HashSet::new();
    let push = |w: &str, wt: f64, seen: &mut HashSet<String>, out: &mut Vec<(String, f64)>| {
        if seen.insert(w.to_string()) {
            out.push((w.to_string(), wt));
        }
    };

    let chars = word.chars().count();
    if chars == 0 {
        return out;
    }
    // Exact / stem vocabulary presence means no expansion is needed.
    let vocab_hit = |w: &str| idx.all_df.contains_key(w);
    if vocab_hit(word) || vocab_hit(&s) {
        return out;
    }

    let s_chars = s.chars().count();
    if chars >= prefix_min || s_chars >= prefix_min {
        for w in vocab {
            if w == &word || w == &s {
                continue;
            }
            if w.starts_with(word) || w.starts_with(&s) {
                push(w, 0.9, &mut seen, &mut out);
                if out.len() >= prefix_cap {
                    break;
                }
            }
        }
    }
    // NOTE: no mid-word substring expansion — that is grep's job (v4.2.2).
    out
}

/// Fold expansions into every non-phrase group.
fn apply_expansions(idx: &Index, groups: &mut [Group], settings: &serde_json::Value) -> bool {
    let vocab = collect_vocab(idx);
    let mut added = false;
    for g in groups.iter_mut() {
        if g.phrase || g.text.is_empty() {
            continue;
        }
        let expansions = expand_word(idx, &vocab, &g.text, settings);
        for (w, wt) in expansions {
            g.terms.push((w, wt));
            added = true;
        }
        let mut seen: HashSet<String> = HashSet::new();
        g.terms.retain(|(t, _)| seen.insert(t.clone()));
    }
    added
}

// --------------------------------------------------------------------------
// The BM25F fields
// --------------------------------------------------------------------------

pub const FIELDS: &[&str] = &["title", "aliases", "headings", "tags", "body", "folder"];

fn default_field_weight(field: &str) -> f64 {
    match field {
        "title" => 3.0,
        "aliases" => 2.0,
        "headings" => 2.0,
        "tags" => 2.5,
        "body" => 1.0,
        _ => 1.5, // folder
    }
}

fn field_weight(settings: &serde_json::Value, field: &str) -> f64 {
    settings
        .get("bm25_field_weights")
        .and_then(|w| w.get(field))
        .and_then(|v| v.as_f64())
        .unwrap_or_else(|| default_field_weight(field))
        .max(0.0)
}

/// Which BM25 fields take part for a given scope selection.
fn fields_for_scope(scope: &[String]) -> Vec<&'static str> {
    let everything = scope.is_empty() || scope.iter().any(|s| s == "everything");
    if everything {
        return FIELDS.to_vec();
    }
    let wants = |n: &str| scope.iter().any(|s| s == n);
    let mut out: Vec<&'static str> = Vec::new();
    if wants("file name") || wants("filename") {
        out.push("title");
        out.push("aliases");
    }
    if wants("tags") {
        out.push("tags");
    }
    if wants("headings") {
        out.push("headings");
    }
    if wants("body") {
        out.push("body");
    }
    if wants("folder path") {
        out.push("folder");
    }
    if out.is_empty() {
        FIELDS.to_vec()
    } else {
        out
    }
}

struct FieldRef<'a> {
    tf: &'a HashMap<String, i64>,
    len: usize,
    avgdl: f64,
}

fn field_ref<'a>(idx: &'a Index, e: &'a NoteEntry, field: &str) -> FieldRef<'a> {
    match field {
        "title" => FieldRef {
            tf: &e.title_words,
            len: e.title_tokens.len(),
            avgdl: idx.title_avgdl,
        },
        "aliases" => FieldRef {
            tf: &e.alias_words,
            len: e.alias_len,
            avgdl: idx.alias_avgdl,
        },
        "headings" => FieldRef {
            tf: &e.heading_words,
            len: e.heading_words.values().sum::<i64>() as usize,
            avgdl: idx.h_avgdl,
        },
        "tags" => FieldRef {
            tf: &e.tag_words,
            len: e.tag_len,
            avgdl: idx.tag_avgdl,
        },
        "body" => FieldRef {
            tf: &e.words,
            len: e.tokens.len(),
            avgdl: idx.avgdl,
        },
        _ => FieldRef {
            tf: &e.folder_words,
            len: e.folder_len,
            avgdl: idx.folder_avgdl,
        },
    }
}

/// The stem-token sequence of one field (used for phrase matching).
fn field_tokens(e: &NoteEntry, field: &str) -> Vec<String> {
    match field {
        "title" => e.title_tokens.clone(),
        "aliases" => e
            .aliases
            .iter()
            .flat_map(|a| tokenize(a))
            .collect(),
        "headings" => tokenize(&e.heading_text),
        "tags" => tokenize(&e.tag_text),
        "body" => e.tokens.clone(),
        _ => tokenize(&e.folder_path),
    }
}

/// BM25 contribution of one field for a bag of weighted terms.
fn bm25_field(
    tf: &HashMap<String, i64>,
    dl: usize,
    avgdl: f64,
    terms: &[(String, f64)],
    df: &HashMap<String, i64>,
    n_docs: usize,
    k1: f64,
    b: f64,
) -> f64 {
    let mut score = 0.0;
    for (term, wq) in terms {
        let f = *tf.get(term).unwrap_or(&0);
        if f == 0 {
            continue;
        }
        let dfc = *df.get(term).unwrap_or(&0);
        if dfc <= 0 {
            continue;
        }
        let idf = (1.0 + (n_docs as f64 - dfc as f64 + 0.5) / (dfc as f64 + 0.5)).ln();
        let denom = f as f64
            + k1 * (1.0 - b + b * (if avgdl > 0.0 { dl as f64 / avgdl } else { 1.0 }));
        score += wq * idf * (f as f64 * (k1 + 1.0)) / denom;
    }
    score
}

/// Count consecutive occurrences of a stemmed phrase in a token sequence.
fn phrase_count(phrase_tokens: &[String], tokens: &[String]) -> i64 {
    if phrase_tokens.is_empty() || tokens.len() < phrase_tokens.len() {
        return 0;
    }
    let mut n = 0i64;
    for i in 0..=(tokens.len() - phrase_tokens.len()) {
        let mut same = true;
        for j in 0..phrase_tokens.len() {
            if tokens[i + j] != phrase_tokens[j] {
                same = false;
                break;
            }
        }
        if same {
            n += 1;
        }
    }
    n
}

// --------------------------------------------------------------------------
// Grep — literal, case-insensitive, AND semantics
// --------------------------------------------------------------------------

/// A grep keyword normalized the same way note text is normalized.
pub fn grep_key(keyword: &str) -> String {
    normalize(keyword)
}

/// The literal texts a note offers to grep, per scope.
fn grep_texts(e: &NoteEntry, scope: &[String]) -> Vec<String> {
    let everything = scope.is_empty() || scope.iter().any(|s| s == "everything");
    let wants = |n: &str| everything || scope.iter().any(|s| s == n);
    let mut out = Vec::new();
    if wants("file name") || wants("filename") {
        out.push(normalize(&e.title));
        for a in &e.aliases {
            out.push(a.clone());
        }
    }
    if wants("tags") {
        out.push(
            e.tags
                .iter()
                .map(|t| t.replace('_', " "))
                .collect::<Vec<_>>()
                .join(" "),
        );
    }
    if wants("headings") {
        out.push(normalize(&e.headings.join(" ")));
        out.push(normalize(&e.qi_labels.join(" ")));
    }
    if wants("body") {
        out.push(e.snippet_text.clone());
    }
    if wants("folder path") {
        out.push(normalize(&e.folder.replace('/', " ")));
    }
    if everything {
        // one combined text so a keyword can span field boundaries is NOT
        // wanted; each field stays separate (a keyword lives in a field).
        out.push(normalize(&e.title));
        for a in &e.aliases {
            out.push(a.clone());
        }
        out.push(normalize(&e.headings.join(" ")));
        out.push(normalize(&e.qi_labels.join(" ")));
        out.push(e.snippet_text.clone());
        out.push(
            e.tags
                .iter()
                .map(|t| t.replace('_', " "))
                .collect::<Vec<_>>()
                .join(" "),
        );
        out.push(normalize(&e.folder.replace('/', " ")));
    }
    out
}

fn count_substring(hay: &str, needle: &str) -> usize {
    if needle.is_empty() {
        return 0;
    }
    let mut n = 0usize;
    let mut at = 0usize;
    while let Some(p) = hay[at..].find(needle) {
        n += 1;
        at += p + needle.len();
    }
    n
}

/// One grep keyword against one note → total occurrence count (0 = miss).
fn grep_count(e: &NoteEntry, kw: &str, scope: &[String]) -> usize {
    let texts = grep_texts(e, scope);
    texts.iter().map(|t| count_substring(t, kw)).sum()
}

// --------------------------------------------------------------------------
// Coverage helpers (share of query groups found anywhere in the note)
// --------------------------------------------------------------------------

fn group_in_text(g: &Group, texts: &[&str]) -> bool {
    if g.phrase {
        let toks: Vec<String> = g.phrase_tokens.iter().map(|t| stem(t)).collect();
        let joined = toks.join(" ");
        if joined.is_empty() {
            return false;
        }
        return texts.iter().any(|t| {
            let stem_text = tokenize(t).iter().map(|x| stem(x)).collect::<Vec<_>>().join(" ");
            stem_text.contains(&joined)
        });
    }
    for (term, _wt) in &g.terms {
        let s = stem(term);
        for t in texts {
            if t.is_empty() {
                continue;
            }
            let words: Vec<&str> = t.split_whitespace().collect();
            if words.contains(&term.as_str()) || words.contains(&s.as_str()) {
                return true;
            }
            let stemmed: Vec<String> = tokenize(t).iter().map(|x| stem(x)).collect();
            if stemmed.contains(&s) {
                return true;
            }
        }
    }
    false
}

fn all_note_texts(e: &NoteEntry) -> Vec<String> {
    let mut v = vec![normalize(&e.title)];
    v.extend(e.aliases.iter().cloned());
    v.push(e.heading_text.clone());
    v.push(e.snippet_text.clone());
    v.push(e.tag_text.clone());
    v.push(e.folder_path.clone());
    v
}

// --------------------------------------------------------------------------
// Scoring
// --------------------------------------------------------------------------

#[derive(Debug, Clone, Default)]
struct Scored {
    rp: String,
    /// raw BM25F (or grep-count) score before normalization
    raw: f64,
    /// per-field raw contributions (BM25 mode)
    field_raw: HashMap<String, f64>,
    /// grep keyword hits: (keyword as typed, count)
    grep_matches: Vec<(String, usize)>,
    matched_groups: usize,
    /// per query group: did BM25 terms of this group actually contribute?
    group_hits: Vec<bool>,
    title_hit: usize,
    direct: bool,
    /// BM25 had ZERO word matches for this note — it is here only because
    /// grep found the keyword literally (shown with a warning sign).
    bm25_zero: bool,
    recent_only: bool,
    score: f64,
    coverage: f64,
    breakdown: serde_json::Value,
}

// --------------------------------------------------------------------------
// Keyword-level match info (v4.2.2). One row per BM25 query word and per
// grep keyword: does the word exist for BM25 (df in the vocabulary), does
// grep find it literally, and how the UI must mark it:
//   "both"  — BM25 and grep both know the word        → green check
//   "bm25"  — only BM25 found it                      → plain check
//   "grep"  — BM25 has NO word match, grep does       → amber warning
//   "none"  — no engine found the word anywhere       → red cross
// --------------------------------------------------------------------------

#[derive(Debug, Clone)]
struct KeywordInfo {
    word: String,
    source: &'static str, // "query" | "phrase" | "grep"
    bm25_found: bool,
    bm25_df: i64,
    grep_found: bool,
    grep_notes: usize,
}

impl KeywordInfo {
    fn status(&self) -> &'static str {
        match (self.bm25_found, self.grep_found) {
            (true, true) => "both",
            (true, false) => "bm25",
            (false, true) => "grep",
            (false, false) => "none",
        }
    }
}

/// Does any term of a query group exist in the BM25 vocabulary, and with
/// what document frequency? (Typo / prefix / substring expansions already
/// folded into the group's terms — a hit through any of them counts.)
fn group_df(idx: &Index, g: &Group) -> i64 {
    let mut best = 0i64;
    for (t, _w) in &g.terms {
        let d = *idx.all_df.get(t).unwrap_or(&0);
        if d > best {
            best = d;
        }
    }
    best
}

// --------------------------------------------------------------------------
// Main entry
// --------------------------------------------------------------------------

#[allow(clippy::too_many_arguments)]
pub fn search(
    idx: &Index,
    q: &str,
    grep_keywords: &[String],
    tags_sel: &[String],
    folders: &[String],
    folder_only: bool,
    scope: &[String],
    include_connected: bool,
    status: Option<&str>,
    date_from: Option<&str>,
    date_to: Option<&str>,
    limit_to: &[String],
    offset: usize,
    limit: Option<usize>,
) -> serde_json::Value {
    let t0 = Instant::now();
    let settings = store::load_settings();
    let page_size = settings
        .get("page_size")
        .and_then(|v| v.as_i64())
        .unwrap_or(20) as usize;
    let limit = limit.unwrap_or(page_size);
    let master = match tags_mod::load_master() {
        Ok(m) => m,
        Err(_) => tags_mod::MasterTags::default(),
    };

    let k1 = settings
        .get("bm25")
        .and_then(|b| b.get("k1"))
        .and_then(|v| v.as_f64())
        .unwrap_or(1.5);
    let b_b = settings
        .get("bm25")
        .and_then(|b| b.get("b"))
        .and_then(|v| v.as_f64())
        .unwrap_or(0.75);
    let phrase_weight = settings
        .get("phrase_weight")
        .and_then(|v| v.as_f64())
        .unwrap_or(1.5);

    // ---- parse the BM25 query (typos + fragments kept from v4.1) ----
    let mut parsed = parse_query(q, &master, &settings);
    let mut query_tags = parsed.query_tags.clone();
    if apply_typo_corrections(idx, &mut parsed.groups, &settings) {
        let tag_lookup = tags_mod::tag_synonym_to_tag(&master);
        for g in &parsed.groups {
            for (t, wt) in &g.terms {
                if let Some(hit) = tag_lookup.get(t) {
                    if *wt < 1.0 {
                        query_tags.push(hit.clone());
                    }
                }
            }
        }
        let mut seen: HashSet<String> = HashSet::new();
        query_tags.retain(|t| seen.insert(key_of(t)));
    }
    if apply_expansions(idx, &mut parsed.groups, &settings) {
        let tag_lookup = tags_mod::tag_synonym_to_tag(&master);
        for g in &parsed.groups {
            for (t, wt) in &g.terms {
                if *wt < 1.0 {
                    if let Some(hit) = tag_lookup.get(t) {
                        query_tags.push(hit.clone());
                    }
                }
            }
        }
        let mut seen: HashSet<String> = HashSet::new();
        query_tags.retain(|t| seen.insert(key_of(t)));
    }

    // ---- grep keywords (literal, AND) ----
    let mut grep_norm: Vec<(String, String)> = Vec::new(); // (as typed, normalized)
    {
        let mut seen: HashSet<String> = HashSet::new();
        for kw in grep_keywords {
            let k = grep_key(kw);
            if k.is_empty() || !seen.insert(k.clone()) {
                continue;
            }
            grep_norm.push((kw.trim().to_string(), k));
        }
    }
    let has_grep = !grep_norm.is_empty();
    let has_q = !parsed.groups.is_empty();
    let has_tags = !tags_sel.is_empty();

    // ---- folder boundary: a hard boundary ----
    let mut universe: Vec<String> = idx.files.keys().cloned().collect();
    if !folders.is_empty() {
        let in_scope = |rp: &str| -> bool {
            for f in folders {
                let f = f.trim_matches('/');
                if f.is_empty() && !folder_only {
                    return true;
                }
                if rp.starts_with(&format!("database/{f}/")) || rp == format!("database/{f}") {
                    let note_folder = std::path::Path::new(rp)
                        .parent()
                        .map(|p| p.to_path_buf())
                        .unwrap_or_default();
                    let rel_folder = paths::rel(&note_folder)
                        .trim_start_matches("database/")
                        .to_string();
                    if folder_only {
                        if rel_folder == f {
                            return true;
                        }
                    } else if rel_folder == f || rel_folder.starts_with(&format!("{f}/")) {
                        return true;
                    }
                }
            }
            false
        };
        universe.retain(|rp| in_scope(rp));
    }

    // ---- status and date filters ----
    universe.retain(|rp| {
        let e = &idx.files[rp];
        if let Some(st) = status {
            if &e.status != st {
                return false;
            }
        }
        if let Some(df) = date_from {
            let u = if e.updated.is_empty() { "0000" } else { &e.updated };
            if u < df {
                return false;
            }
        }
        if let Some(dt) = date_to {
            let u = if e.updated.is_empty() { "9999" } else { &e.updated };
            if u > dt {
                return false;
            }
        }
        true
    });

    // ---- search within a chosen group of notes ----
    if !limit_to.is_empty() {
        let wanted: HashSet<String> = limit_to.iter().map(|t| key_of(t)).collect();
        universe.retain(|rp| {
            wanted.contains(&key_of(&idx.files[rp].title)) || limit_to.iter().any(|x| x == rp)
        });
    }

    let mut removed_by = HashMap::from([
        ("tags".to_string(), 0i64),
        ("grep".to_string(), 0i64),
    ]);

    // ---- selected tags are a hard filter (must carry all) ----
    if has_tags {
        let before = universe.len() as i64;
        universe.retain(|rp| {
            let carried: HashSet<String> = idx.files[rp].tags.iter().map(|t| key_of(t)).collect();
            tags_sel.iter().all(|st| carried.contains(&key_of(st)))
        });
        removed_by.insert("tags".to_string(), before - universe.len() as i64);
    }

    // ---- grep filter (AND: every keyword must literally appear) ----
    // Every keyword is counted on EVERY note (not just the survivors) so the
    // response can report per keyword how many notes contain it — that is
    // how "BM25 missed it, grep found it" warnings get their numbers.
    let mut grep_hits: HashMap<String, Vec<(String, usize)>> = HashMap::new();
    let mut grep_note_counts: Vec<usize> = vec![0; grep_norm.len()];
    if has_grep {
        let before = universe.len() as i64;
        universe.retain(|rp| {
            let e = &idx.files[rp];
            let mut hits: Vec<(String, usize)> = Vec::new();
            let mut ok = true;
            for (ki, (typed, norm)) in grep_norm.iter().enumerate() {
                let c = grep_count(e, norm, scope);
                if c > 0 {
                    grep_note_counts[ki] += 1;
                }
                if c == 0 {
                    ok = false;
                }
                hits.push((typed.clone(), c));
            }
            if ok {
                grep_hits.insert(rp.clone(), hits);
            }
            ok
        });
        removed_by.insert("grep".to_string(), before - universe.len() as i64);
    }

    // ---- keyword-level info: BM25 vocabulary existence × grep existence ----
    let mut keywords: Vec<KeywordInfo> = Vec::new();
    for g in &parsed.groups {
        let df = group_df(idx, g);
        let word = g.text.clone();
        // a query word that is ALSO a grep keyword carries grep evidence
        let (gfound, gnotes) = grep_norm
            .iter()
            .position(|(t, _)| grep_key(t) == grep_key(&word))
            .map(|i| (grep_note_counts[i] > 0, grep_note_counts[i]))
            .unwrap_or((false, 0));
        keywords.push(KeywordInfo {
            word,
            source: if g.phrase { "phrase" } else { "query" },
            bm25_found: df > 0,
            bm25_df: df,
            grep_found: gfound,
            grep_notes: gnotes,
        });
    }
    for (ki, (typed, _norm)) in grep_norm.iter().enumerate() {
        if parsed.groups.iter().any(|g| grep_key(&g.text) == grep_key(typed)) {
            continue; // already reported as a query word
        }
        // grep keyword as a BM25 term? (normalized + stemmed forms)
        let norm = grep_key(typed);
        let stemmed = stem(&norm);
        let df = [*idx.all_df.get(&norm).unwrap_or(&0), *idx.all_df.get(&stemmed).unwrap_or(&0)]
            .into_iter()
            .max()
            .unwrap_or(0);
        keywords.push(KeywordInfo {
            word: typed.clone(),
            source: "grep",
            bm25_found: df > 0,
            bm25_df: df,
            grep_found: grep_note_counts[ki] > 0,
            grep_notes: grep_note_counts[ki],
        });
    }

    // ---- score every note in the universe ----
    let active_fields = fields_for_scope(scope);
    let mut scored: Vec<Scored> = Vec::new();

    if has_q {
        // BM25 mode (with or without grep). Every note in the universe is
        // scored; notes with raw 0 do not match and drop out.
        let n_docs = idx.n.max(1);

        // phrase virtual terms: df = notes where the phrase occurs anywhere
        // (usize = the phrase's own group index, for keyword-match reporting)
        let mut phrase_defs: Vec<(usize, Vec<String>, i64)> = Vec::new();
        for (gi, g) in parsed.groups.iter().enumerate() {
            if g.phrase && g.phrase_tokens.len() >= 2 {
                let toks: Vec<String> = g.phrase_tokens.iter().map(|t| stem(t)).collect();
                let dfc: i64 = universe
                    .iter()
                    .filter(|rp| {
                        let e = &idx.files[*rp];
                        active_fields
                            .iter()
                            .any(|f| phrase_count(&toks, &field_tokens(e, f)) > 0)
                    })
                    .count() as i64;
                phrase_defs.push((gi, toks, dfc));
            }
        }

        let mut best: Vec<Scored> = Vec::new();
        for rp in &universe {
            let e = &idx.files[rp];
            let mut field_raw: HashMap<String, f64> = HashMap::new();
            let mut raw = 0.0;
            // per query group: did this group's BM25 terms contribute > 0?
            let mut group_hits: Vec<bool> = vec![false; parsed.groups.len()];
            for f in &active_fields {
                let fr = field_ref(idx, e, f);
                let mut s = bm25_field(
                    fr.tf,
                    fr.len,
                    if fr.avgdl > 0.0 { fr.avgdl } else { 1.0 },
                    &flatten_terms(&parsed.groups),
                    &idx.all_df,
                    n_docs,
                    k1,
                    b_b,
                );
                // phrases: virtual terms with tf = occurrence count
                for (gi, toks, dfc) in phrase_defs.iter() {
                    let tf = phrase_count(toks, &field_tokens(e, f));
                    if tf > 0 && *dfc > 0 {
                        let idf = (1.0 + (n_docs as f64 - *dfc as f64 + 0.5) / (*dfc as f64 + 0.5)).ln();
                        let avgdl = if fr.avgdl > 0.0 { fr.avgdl } else { 1.0 };
                        let denom = tf as f64 + k1 * (1.0 - b_b + b_b * (fr.len as f64 / avgdl));
                        s += phrase_weight * idf * (tf as f64 * (k1 + 1.0)) / denom;
                        if let Some(h) = group_hits.get_mut(*gi) {
                            *h = true;
                        }
                    }
                }
                // group-level BM25 contribution (keyword_matches reporting)
                for (gi, g) in parsed.groups.iter().enumerate() {
                    if group_hits[gi] {
                        continue;
                    }
                    if g.phrase {
                        continue; // handled through phrase_defs above
                    }
                    let gs = bm25_field(
                        fr.tf,
                        fr.len,
                        if fr.avgdl > 0.0 { fr.avgdl } else { 1.0 },
                        &g.terms,
                        &idx.all_df,
                        n_docs,
                        k1,
                        b_b,
                    );
                    if gs > 0.0 {
                        group_hits[gi] = true;
                    }
                }
                if s > 0.0 {
                    field_raw.insert(f.to_string(), s);
                    raw += s * field_weight(&settings, f);
                }
            }
            if raw <= 0.0 {
                continue;
            }
            let texts = all_note_texts(e);
            let text_refs: Vec<&str> = texts.iter().map(|s| s.as_str()).collect();
            let matched_groups = parsed
                .groups
                .iter()
                .filter(|g| group_in_text(g, &text_refs))
                .count();
            let title_norm = normalize(&e.title);
            let title_texts: Vec<&str> = std::iter::once(title_norm.as_str())
                .chain(e.aliases.iter().map(|a| a.as_str()))
                .collect();
            let title_hit = parsed
                .groups
                .iter()
                .filter(|g| group_in_text(g, &title_texts))
                .count();
            best.push(Scored {
                rp: rp.clone(),
                raw,
                field_raw,
                grep_matches: grep_hits.get(rp).cloned().unwrap_or_default(),
                matched_groups,
                group_hits,
                title_hit,
                direct: true,
                ..Default::default()
            });
        }

        if best.is_empty() {
            // BM25 found NO word match anywhere. With grep active, the notes
            // grep found literally still count — flagged bm25_zero (shown
            // with a warning sign, ranked by grep hits). Without grep the
            // result is honestly empty: the keywords get the red cross.
            if has_grep && !grep_hits.is_empty() {
                for (rp, hits) in &grep_hits {
                    let raw = hits.iter().map(|(_, c)| *c as f64).sum::<f64>();
                    best.push(Scored {
                        rp: rp.clone(),
                        raw,
                        field_raw: HashMap::new(),
                        grep_matches: hits.clone(),
                        direct: true,
                        bm25_zero: true,
                        ..Default::default()
                    });
                }
            }
            // no fallback: BM25 and grep are the whole engine. A miss is a
            // miss — the UI shows which words had no match (red cross).
        }
        scored = best;
    } else if has_grep {
        // grep only: exact matches ranked by total hit count.
        for (rp, hits) in &grep_hits {
            let raw = hits.iter().map(|(_, c)| *c as f64).sum::<f64>();
            scored.push(Scored {
                rp: rp.clone(),
                raw,
                field_raw: HashMap::new(),
                grep_matches: hits.clone(),
                matched_groups: 0,
                direct: true,
                ..Default::default()
            });
        }
    } else if has_tags {
        // tags only: every note carrying all the tags, ranked by how many
        // tags it carries, then recency (set in the sort).
        for rp in &universe {
            let e = &idx.files[rp];
            let carried: HashSet<String> = e.tags.iter().map(|t| key_of(t)).collect();
            let matched = tags_sel.iter().filter(|st| carried.contains(&key_of(st))).count();
            let raw = matched as f64;
            scored.push(Scored {
                rp: rp.clone(),
                raw,
                field_raw: HashMap::new(),
                matched_groups: matched,
                direct: true,
                ..Default::default()
            });
        }
    } else if !universe.is_empty() {
        // nothing to search: recently updated notes, honestly labeled.
        let mut recent: Vec<(String, String)> = universe
            .iter()
            .map(|rp| (idx.files[rp].updated.clone(), rp.clone()))
            .collect();
        recent.sort_by(|a, b| b.0.cmp(&a.0).then_with(|| a.1.cmp(&b.1)));
        for (_, rp) in recent.into_iter().take(20) {
            scored.push(Scored {
                rp,
                direct: false,
                recent_only: true,
                ..Default::default()
            });
        }
    }

    // ---- normalize scores to 0..100 and apply coverage ----
    let max_raw = scored
        .iter()
        .map(|x| x.raw)
        .fold(f64::NEG_INFINITY, f64::max);
    let scale = if max_raw > 0.0 { 1.0 / max_raw } else { 0.0 };
    let n_groups = parsed.groups.len();
    let coverage_base = settings
        .get("coverage_base")
        .and_then(|v| v.as_f64())
        .unwrap_or(0.4);

    // per-field normalization for the "why this ranking" bars
    let mut field_max: HashMap<String, f64> = HashMap::new();
    for x in &scored {
        for (f, v) in &x.field_raw {
            let m = field_max.entry(f.clone()).or_insert(0.0);
            if *v > *m {
                *m = *v;
            }
        }
    }
    let grep_max = scored
        .iter()
        .flat_map(|x| x.grep_matches.iter().map(|(_, c)| *c))
        .fold(0usize, usize::max) as f64;
    let active_fields_owned: Vec<String> = active_fields.iter().map(|s| s.to_string()).collect();
    let fw_total: f64 = active_fields_owned
        .iter()
        .map(|f| field_weight(&settings, f))
        .sum();

    for x in scored.iter_mut() {
        let mut breakdown = serde_json::Map::new();
        let mut wsum = 0.0;
        if x.raw > 0.0 {
            if !x.field_raw.is_empty() {
                for f in &active_fields_owned {
                    let raw_v = *x.field_raw.get(f).unwrap_or(&0.0);
                    let fm = *field_max.get(f).unwrap_or(&0.0);
                    let scaled = if fm > 0.0 { (raw_v / fm).min(1.0) } else { 0.0 };
                    let wf = field_weight(&settings, f);
                    let w = if fw_total > 0.0 { wf / fw_total } else { 0.0 };
                    // field points are weighted by the field's share of THIS
                    // note's raw score, so the bars sum to the real score
                    let share = if x.raw > 0.0 { raw_v * wf / x.raw } else { 0.0 };
                    let points = share;
                    wsum += points;
                    breakdown.insert(
                        f.clone(),
                        serde_json::json!({
                            "weight": (w * 10000.0).round() / 10000.0,
                            "raw": (raw_v * 10000.0).round() / 10000.0,
                            "scaled": (scaled * 10000.0).round() / 10000.0,
                            "points": (points * 10000.0).round() / 10000.0,
                            "applied": raw_v > 0.0,
                        }),
                    );
                }
            } else if has_grep {
                // grep-only scoring: keyword hit counts
                for (kw, c) in &x.grep_matches {
                    let scaled = if grep_max > 0.0 { (*c as f64 / grep_max).min(1.0) } else { 0.0 };
                    breakdown.insert(
                        format!("grep: {kw}"),
                        serde_json::json!({
                            "weight": 1.0,
                            "raw": *c,
                            "scaled": (scaled * 10000.0).round() / 10000.0,
                            "points": (scaled * 10000.0).round() / 10000.0,
                            "applied": true,
                        }),
                    );
                }
                wsum = 1.0;
            }
        }
        let coverage = if !has_q || n_groups == 0 {
            1.0
        } else {
            coverage_base + (1.0 - coverage_base) * (x.matched_groups as f64 / n_groups.max(1) as f64)
        };
        x.coverage = (coverage * 10000.0).round() / 10000.0;
        let base = if x.raw > 0.0 { 100.0 * x.raw * scale } else { 0.0 };
        x.score = (base * coverage * 100.0).round() / 100.0;
        x.breakdown = serde_json::Value::Object(breakdown);
        let _ = wsum;
    }

    // ---- sort: exact title/alias first, then score, groups, recency, A–Z ----
    let date_key = |d: &str| date_key(d);
    let qnorm = normalize(q);
    scored.sort_by(|a, b| {
        let exact = |x: &Scored| -> bool {
            x.direct
                && !qnorm.is_empty()
                && (qnorm == normalize(&idx.files[&x.rp].title)
                    || idx.files[&x.rp].aliases.iter().any(|a| qnorm == *a))
        };
        let (ea, eb) = (exact(a), exact(b));
        eb.cmp(&ea)
            .then_with(|| {
                let rank = |x: &Scored| if x.direct { 0 } else { 1 };
                rank(a).cmp(&rank(b))
            })
            .then_with(|| b.score.partial_cmp(&a.score).unwrap_or(std::cmp::Ordering::Equal))
            .then_with(|| b.matched_groups.cmp(&a.matched_groups))
            .then_with(|| date_key(&idx.files[&b.rp].updated).cmp(&date_key(&idx.files[&a.rp].updated)))
            .then_with(|| idx.files[&a.rp].title.to_lowercase().cmp(&idx.files[&b.rp].title.to_lowercase()))
    });

    let mut results: Vec<serde_json::Value> = scored
        .iter()
        .map(|x| present(idx, x, &parsed.groups, &grep_norm, has_q, has_grep, tags_sel.len()))
        .collect();

    // ---- include connected notes as extra results ----
    if include_connected && !scored.is_empty() {
        let top_hits: Vec<String> = scored.iter().take(5).map(|x| x.rp.clone()).collect();
        let mut seen: HashSet<String> = scored.iter().map(|x| x.rp.clone()).collect();
        let uni: HashSet<String> = universe.iter().cloned().collect();
        let mut extra: Vec<serde_json::Value> = Vec::new();
        for hit in &top_hits {
            let nbs = idx
                .graph
                .get(hit)
                .cloned()
                .unwrap_or_default()
                .into_iter()
                .chain(idx.backlinks.get(hit).cloned().unwrap_or_default());
            for nb in nbs {
                if !seen.contains(&nb) && uni.contains(&nb) {
                    seen.insert(nb.clone());
                    let e = &idx.files[&nb];
                    extra.push(serde_json::json!({
                        "path": nb, "title": e.title, "folder": e.folder,
                        "tags": e.tags, "status": e.status,
                        "updated": e.updated, "score": null,
                        "connected_to": hit,
                        "snippet": snippet(e, &parsed.groups),
                    }));
                }
            }
        }
        results.extend(extra);
    }

    let total = results.len();
    let page: Vec<serde_json::Value> = results
        .into_iter()
        .skip(offset)
        .take(limit)
        .collect();
    let elapsed = t0.elapsed().as_secs_f64() * 1000.0;

    // ---- warnings: BM25 missed a word, grep still found it (amber sign);
    //      no-match words (red cross) are reported as `no_word_match` ----
    let warnings: Vec<serde_json::Value> = keywords
        .iter()
        .filter(|k| k.status() == "grep")
        .map(|k| {
            serde_json::json!({
                "kind": "bm25_miss_grep_hit",
                "word": k.word,
                "grep_notes": k.grep_notes,
                "message": format!(
                    "BM25 has no word match for “{}” in any note, but grep found it literally in {} note{} — those results are included and ranked (by grep hits where BM25 scored zero).",
                    k.word, k.grep_notes, if k.grep_notes == 1 { "" } else { "s" }
                ),
            })
        })
        .collect();
    let no_word_match: Vec<String> = keywords
        .iter()
        .filter(|k| k.status() == "none")
        .map(|k| k.word.clone())
        .collect();

    let mut notice: Option<String> = None;
    if total == 0 {
        if !no_word_match.is_empty() {
            let kws: Vec<String> = no_word_match.iter().map(|w| format!("`{w}`")).collect();
            notice = Some(format!(
                "No word match for {} — BM25 and grep both found nothing (red ✗). Check the spelling or try a shorter word.",
                kws.join(", ")
            ));
        } else if has_grep && removed_by["grep"] > 0 {
            let kws: Vec<String> = grep_norm.iter().map(|(t, _)| format!("`{t}`")).collect();
            notice = Some(format!(
                "No note contains every grep keyword ({}). Grep is exact — remove a keyword or check its spelling.",
                kws.join(" and ")
            ));
        } else if removed_by["tags"] > 0 {
            notice = Some("No results: the selected tags removed all notes (every note must carry all of them). Remove a tag to widen the search.".into());
        } else if !folders.is_empty() {
            notice = Some("No results inside the selected folder boundary. Search never looks outside chosen folders - widen the folder selection or clear it.".into());
        }
    }

    serde_json::json!({
        "total": total,
        "offset": offset,
        "results": page,
        "notice": notice,
        "removed_by": removed_by,
        "mode": if has_q && has_grep { "bm25+grep" }
            else if has_grep { "grep" }
            else if has_q { "bm25" }
            else if has_tags { "tags" }
            else { "recent" },
        "query": {
            "groups": parsed.groups.iter().map(|g| g.text.clone()).collect::<Vec<_>>(),
            "query_tags": query_tags,
            "phrases": parsed.phrases,
            "grep": grep_norm.iter().map(|(t, _)| t.clone()).collect::<Vec<_>>(),
            "keywords": keywords.iter().map(|k| serde_json::json!({
                "word": k.word,
                "source": k.source,
                "bm25_found": k.bm25_found,
                "bm25_df": k.bm25_df,
                "grep_found": k.grep_found,
                "grep_notes": k.grep_notes,
                "status": k.status(),
            })).collect::<Vec<_>>(),
        },
        "warnings": warnings,
        "no_word_match": no_word_match,
        "elapsed_ms": (elapsed * 10.0).round() / 10.0,
    })
}

fn flatten_terms(groups: &[Group]) -> Vec<(String, f64)> {
    let mut out: Vec<(String, f64)> = Vec::new();
    for g in groups {
        if g.phrase {
            for t in &g.phrase_tokens {
                out.push((t.clone(), 1.0));
            }
        } else {
            out.extend(g.terms.iter().cloned());
        }
    }
    let mut seen: HashSet<String> = HashSet::new();
    out.retain(|(t, _)| seen.insert(t.clone()));
    out
}

pub fn date_key(d: &str) -> String {
    let mut padded = d.to_string();
    while padded.chars().count() < 10 {
        padded.push(' ');
    }
    padded
        .chars()
        .map(|c| char::from_u32(0x10FFFF - c as u32).unwrap_or('\u{0}'))
        .collect()
}

fn snippet(e: &NoteEntry, groups: &[Group]) -> String {
    let text = &e.snippet_text;
    if groups.is_empty() {
        return text.chars().take(200).collect();
    }
    let mut best_i = 0;
    for g in groups {
        let pos = group_positions(g, &e.tokens);
        if !pos.is_empty() {
            best_i = pos[0];
            break;
        }
    }
    let toks: Vec<&str> = text.split_whitespace().collect();
    let a = best_i.saturating_sub(12);
    let b = (best_i + 24).min(toks.len());
    toks[a..b].join(" ")
}

fn group_positions(g: &Group, tokens: &[String]) -> Vec<usize> {
    if g.phrase {
        let toks: Vec<String> = g.phrase_tokens.iter().map(|t| stem(t)).collect();
        let mut out = Vec::new();
        if !toks.is_empty() {
            for i in 0..tokens.len().saturating_sub(toks.len()) + 1 {
                if &tokens[i..i + toks.len()] == toks.as_slice() {
                    out.push(i);
                }
            }
        }
        return out;
    }
    let mut out = Vec::new();
    for (i, t) in tokens.iter().enumerate() {
        for (term, _wt) in &g.terms {
            if t == term {
                out.push(i);
            }
        }
    }
    out
}

/// Does this note contain the term in ANY BM25 field's term-frequency map?
fn note_has_term(e: &NoteEntry, term: &str) -> bool {
    e.words.contains_key(term)
        || e.title_words.contains_key(term)
        || e.tag_words.contains_key(term)
        || e.heading_words.contains_key(term)
        || e.folder_words.contains_key(term)
        || e.alias_words.contains_key(term)
}

fn present(
    idx: &Index,
    x: &Scored,
    groups: &[Group],
    grep_norm: &[(String, String)],
    has_q: bool,
    has_grep: bool,
    n_tags_sel: usize,
) -> serde_json::Value {
    let e = &idx.files[&x.rp];

    // ---- per-keyword match rows (query words ∪ grep keywords) ----
    // bm25 = BM25 terms of that word actually scored in THIS note;
    // grep  = the keyword appears literally in THIS note (count > 0).
    let mut keyword_matches: Vec<serde_json::Value> = Vec::new();
    let mut grep_only_words: Vec<String> = Vec::new();
    for (gi, g) in groups.iter().enumerate() {
        let bm25 = x.group_hits.get(gi).copied().unwrap_or(false);
        let gc = x
            .grep_matches
            .iter()
            .find(|(k, _)| grep_key(k) == grep_key(&g.text))
            .map(|(_, c)| *c)
            .unwrap_or(0);
        let grep = gc > 0;
        if grep && !bm25 {
            grep_only_words.push(g.text.clone());
        }
        keyword_matches.push(serde_json::json!({
            "word": g.text,
            "source": if g.phrase { "phrase" } else { "query" },
            "bm25": bm25,
            "grep": grep,
            "grep_count": gc,
        }));
    }
    for (typed, norm) in grep_norm {
        if groups.iter().any(|g| grep_key(&g.text) == grep_key(typed)) {
            continue; // already covered as a query word
        }
        let stemmed = stem(norm);
        let bm25 = note_has_term(e, norm) || note_has_term(e, &stemmed);
        let gc = x
            .grep_matches
            .iter()
            .find(|(k, _)| grep_key(k) == grep_key(typed))
            .map(|(_, c)| *c)
            .unwrap_or(0);
        let grep = gc > 0;
        if grep && !bm25 {
            grep_only_words.push(typed.clone());
        }
        keyword_matches.push(serde_json::json!({
            "word": typed,
            "source": "grep",
            "bm25": bm25,
            "grep": grep,
            "grep_count": gc,
        }));
    }

    serde_json::json!({
        "path": x.rp,
        "title": e.title,
        "folder": e.folder,
        "tags": e.tags,
        "status": e.status,
        "updated": e.updated,
        "pinned": e.pinned,
        "score": x.score,
        "coverage": x.coverage,
        "direct": x.direct,
        "matched_groups": x.matched_groups,
        "bm25_zero": x.bm25_zero,
        "grep_only_words": grep_only_words,
        "grep_matches": x.grep_matches.iter().map(|(k, c)| serde_json::json!({
            "keyword": k, "count": c,
        })).collect::<Vec<_>>(),
        "keyword_matches": keyword_matches,
        "rank_reason": rank_reason(x, groups.len(), has_q, has_grep, n_tags_sel),
        "breakdown": x.breakdown,
        "snippet": snippet(e, groups),
    })
}

fn rank_reason(x: &Scored, n_groups: usize, has_q: bool, has_grep: bool, n_tags_sel: usize) -> String {
    let mut bits: Vec<String> = Vec::new();
    if x.bm25_zero && has_q {
        bits.push("BM25 found no word match — included because grep found the keyword literally (ranked by grep hits)".into());
    }
    if !has_q && has_grep {
        let hits: Vec<String> = x
            .grep_matches
            .iter()
            .take(3)
            .map(|(k, c)| format!("`{k}` ×{c}"))
            .collect();
        if !hits.is_empty() {
            bits.push(format!("contains every grep keyword: {}", hits.join(", ")));
        }
    } else if has_grep && !x.grep_matches.is_empty() {
        bits.push("matches every grep keyword exactly".into());
    }
    if !has_q && n_tags_sel > 0 {
        bits.push(format!("carries all {n_tags_sel} selected tags"));
    }
    if has_q {
        let g = x.matched_groups;
        if g > 0 && n_groups > 0 {
            bits.push(format!("{g} of {n_groups} search words found (BM25)"));
        }
        if x.title_hit > 0 {
            bits.push("title matches the search".into());
        }
    }
    if x.recent_only {
        bits.push("recently updated (no search words given)".into());
    }
    if bits.is_empty() {
        bits.push("ranked by BM25 relevance".into());
    }
    let joined = bits.iter().take(3).cloned().collect::<Vec<_>>().join("; ");
    let mut c = joined.chars();
    match c.next() {
        Some(f) => f.to_uppercase().collect::<String>() + c.as_str() + ".",
        None => String::new(),
    }
}

/// Convenience used by the website and MCP for the /api/suggest endpoint.
pub fn suggest_for(q: &str, kind: &str) -> serde_json::Value {
    store::suggest(q, kind).unwrap_or_else(|_| serde_json::json!({"suggestions": []}))
}

/// A small BTreeMap type alias for deterministic result maps.
pub type RankedMap = BTreeMap<String, f64>;

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_date_key_order() {
        // more recent dates must sort BEFORE older dates in ascending order
        let a = date_key("2026-10-31");
        let b = date_key("2026-10-01");
        assert!(a < b);
    }

    #[test]
    fn test_parse_query() {
        let mt = tags_mod::MasterTags::default();
        let settings = serde_json::json!({});
        let pq = parse_query("quick pasta recipe", &mt, &settings);
        assert_eq!(pq.groups.len(), 3);
        assert_eq!(pq.groups[0].text, "quick");
        // "the" is filler and dropped
        let pq2 = parse_query("the pasta", &mt, &settings);
        assert_eq!(pq2.groups.len(), 1);
    }

    #[test]
    fn test_bm25_field_math() {
        let mut tf: HashMap<String, i64> = HashMap::new();
        tf.insert("garlic".into(), 2);
        let mut df: HashMap<String, i64> = HashMap::new();
        df.insert("garlic".into(), 3);
        let terms = vec![("garlic".to_string(), 1.0)];
        let s = bm25_field(&tf, 100, 200.0, &terms, &df, 10, 1.5, 0.75);
        assert!(s > 0.0);
        // a term absent from the field contributes nothing
        let s2 = bm25_field(&HashMap::new(), 100, 200.0, &terms, &df, 10, 1.5, 0.75);
        assert_eq!(s2, 0.0);
        // higher term weight scales linearly
        let s3 = bm25_field(&tf, 100, 200.0, &vec![("garlic".to_string(), 0.5)], &df, 10, 1.5, 0.75);
        assert!((s3 - s / 2.0).abs() < 1e-9);
    }

    #[test]
    fn test_phrase_count() {
        let toks: Vec<String> = ["one", "pot", "meal", "one", "pot"]
            .iter()
            .map(|s| s.to_string())
            .collect();
        let ph: Vec<String> = vec!["one".to_string(), "pot".to_string()];
        assert_eq!(phrase_count(&ph, &toks), 2);
        let ph2: Vec<String> = vec!["pot".to_string(), "meal".to_string()];
        assert_eq!(phrase_count(&ph2, &toks), 1);
        let ph3: Vec<String> = vec!["meal".to_string(), "pot".to_string()];
        assert_eq!(phrase_count(&ph3, &toks), 0);
    }

    #[test]
    fn test_count_substring() {
        assert_eq!(count_substring("one pot one pot one", "one pot"), 2);
        assert_eq!(count_substring("tomato soup", "tomat"), 1);
        assert_eq!(count_substring("garlic", "zzz"), 0);
        assert_eq!(count_substring("anything", ""), 0);
    }

    #[test]
    fn test_grep_key_and_scope_fields() {
        assert_eq!(grep_key("  Café "), "cafe");
        // everything → all six fields
        let sc: Vec<String> = vec![];
        assert_eq!(fields_for_scope(&sc).len(), FIELDS.len());
        let sc2: Vec<String> = vec!["tags".to_string()];
        assert_eq!(fields_for_scope(&sc2), vec!["tags"]);
        let sc3: Vec<String> = vec!["file name".to_string()];
        assert_eq!(fields_for_scope(&sc3), vec!["title", "aliases"]);
        let sc4: Vec<String> = vec!["body".to_string(), "headings".to_string()];
        assert_eq!(fields_for_scope(&sc4), vec!["headings", "body"]);
    }

    // ---- v4.2.2: grep is a SUBSTRING matcher over normalized text ----
    #[test]
    fn test_grep_substring_catches_inner_word() {
        // "maxwell" typed, "puremaxwell" in the note → grep catches it
        assert_eq!(count_substring("puremaxwell rules", "maxwell"), 1);
        assert_eq!(count_substring("maxwell maxwellmaxwell", "maxwell"), 3);
        assert_eq!(grep_key("Maxwell"), "maxwell");
        assert_eq!(grep_key("PUREMAXWELL"), "puremaxwell");
        // the note's normalized text keeps compound words together, so the
        // substring survives normalization exactly as typed
        let note_text = crate::textutil::normalize("PureMaxwell equations everywhere");
        assert!(count_substring(&note_text, "maxwell") > 0);
        // and a real miss stays a miss
        assert_eq!(count_substring(&note_text, "lentil"), 0);
    }

    // ---- v4.2.2: keyword status matrix (red cross / warning / check) ----
    #[test]
    fn test_keyword_status_matrix() {
        let mk = |bm25: bool, grep: bool| KeywordInfo {
            word: "w".into(),
            source: "query",
            bm25_found: bm25,
            bm25_df: if bm25 { 2 } else { 0 },
            grep_found: grep,
            grep_notes: if grep { 3 } else { 0 },
        };
        // both engines know the word
        assert_eq!(mk(true, true).status(), "both");
        // only BM25 knows the word (plain check)
        assert_eq!(mk(true, false).status(), "bm25");
        // BM25 has NO word match but grep finds it → amber warning, still ranked
        assert_eq!(mk(false, true).status(), "grep");
        // nobody finds the word → red cross
        assert_eq!(mk(false, false).status(), "none");
    }

    // ---- v4.2.2: per-note BM25 term presence for grep keywords ----
    #[test]
    fn test_note_has_term_reports_bm25_presence() {
        let mut e = NoteEntry::default();
        e.words.insert("puremaxwell".into(), 2);
        assert!(note_has_term(&e, "puremaxwell"));
        assert!(!note_has_term(&e, "maxwell")); // BM25 words are whole tokens
    }
}
