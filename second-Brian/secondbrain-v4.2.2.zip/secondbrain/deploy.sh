#!/usr/bin/env bash
# SecondBrain v4.2.2 — minimal deploy: copy the binary + static UI + database
# anywhere and run. No Docker, no package manager, no environment variables.
set -euo pipefail
cd "$(dirname "$0")"
PORT="${1:-8080}"
BIND="${2:-0.0.0.0}"
if [ ! -x bin/secondbrain-website ]; then
  echo "bin/secondbrain-website missing — build first: ./build.sh" >&2
  exit 1
fi
echo "Serving http://${BIND}:${PORT}/ (Ctrl+C to stop)"
exec ./bin/secondbrain-website --port "$PORT" --bind "$BIND"
