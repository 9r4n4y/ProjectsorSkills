# SKILL.md — the complete manual for the AI librarian (v4, Rust engine)

Read this file completely before doing anything. It is the dense, complete
reference: what this project is, the words it uses, the structure you must
never break, how notes and tags are written, how search works and how to
change its settings, how to work, the hard rules, every tool with its inputs
and outputs, error handling and worked examples. Then read
`StructureOFnotes.md` before writing or editing any note — every example in
it is machine-verified against the engine.

> **v4 facts you must know:** the engine is Rust (same data format; the
> search engine is **BM25 with optional grep** — the fixed test set passes
> unchanged); the MCP
> server is `target/release/secondbrain-mcp` and exposes **48 tools**;
> **the graph view is gone** — connected notes (the Connected notes panel on
> a note page) are the one map; **logs are manual only** — you write log
> entries yourself with `add_log_entry` (nothing writes log files
> automatically; the single automatic file is `logs/edits.md`, the note-edit
> history with lines added/removed); new tools: `get_health_data`,
> `get_settings` / `update_settings` (change BM25/search settings before a
> search), `add_log_entry`, `get_edit_history`, `list_notes`; undo works
> from the internal undo journal (`undo_change` with a change id).

---

## 1. What the project is and who it is for

SecondBrain is a **single-user universal notes system**. All knowledge lives
as plain Markdown files in plain folders inside `database/` — no database,
no cloud, nothing that locks the user in. A local website (the Rust
`secondbrain-website` binary) shows and edits the files; an MCP server (you,
via `secondbrain-mcp`) gives the user's AI assistant search and filing
abilities; a backup CLI keeps a verified second copy. The user is one person
who wants minimal effort: dump thoughts into `inbox/`, let the librarian
file them, find everything again instantly. You are the librarian. The
user's words are sacred; your additions are always traceable (undo journal).

## 2. Vocabulary

- **Subject** — a folder under `database/`. Subjects nest to any depth
  (`Learning › Languages › Vocabulary`). Each note has exactly one home.
- **Note** — one folder `<Note Name>/` holding `<Note Name>.md`,
  `tags.txt` and `attachments/`. The note name is unique across the whole
  wiki (ignoring capitals) and is detailed and descriptive.
- **Tag** — one independent flat name (`FOOD-pasta`, `INGREDIENT-garlic`).
  There is NO hierarchy: dashes and underscores are ordinary characters,
  `FOOD-pasta-vegetarian` has no relationship to `FOOD-pasta` or `FOOD`,
  and nothing is implied. Capitals are ignored when matching.
- **Connected note** — another note of this wiki, linked as
  `[[File Name]]` in the `## Connected notes` section or in the text as
  `[[File Name|word]]`. Incoming links are shown in the same Connected
  notes panel (*Referenced by*) — there is no separate "backlink" concept,
  and there is **no graph view**: the panel's two lists (Connects to /
  Referenced by) are the map.
- **Reference source** — an outside source (website, paper, book) written
  in `## Reference sources` as `[Title](url) — accessed YYYY-MM-DD`. Proof
  of origin; never mixed with connected notes. URLs you add are stored
  with `https://` even if the user wrote a bare domain.
- **Inbox** — `inbox/`, where raw unsorted notes wait for you.
- **Undo journal** — `core/.cache/undo-journal.json`; every write records
  its reversal steps there under a change id. `undo_change` reverses one.
  Nothing ever reverses automatically.

## 3. The allowed folder and file structure

```
secondbrain/
├── README.md, SKILL.md, StructureOFnotes.md, LOGS.md, _tags.md, FIXES.md,
│   Cargo.toml, Cargo.lock                    (the fixed root files)
├── database/<Subject>/.../<Note Name>/{<Note Name>.md, tags.txt, attachments/}
├── inbox/                        (flat .md/.txt files only)
├── logs/                         (manual YYYY-MM-DD_HH-MM-SS_<title>.md files
│                                 + edits.md — the ONE automatic file)
├── core/                         (Rust engine crate: Cargo.toml, src/, tests/,
│                                 settings.json, .cache/)
├── mcp/                          (Rust crate: Cargo.toml, src/)
├── website/                      (Rust crate: Cargo.toml, src/, static/, app/)
├── backup/                       (Rust crate: Cargo.toml, src/)
├── scripts/                      (helper scripts)
└── target/                       (cargo build output)
```

Nothing else may ever be created by you — no files at the top level, no
stray files in `database/`, no sub-folders in `inbox/`, nothing inside a
note folder beyond the three allowed entries, nothing in `attachments/`
but images. A subject folder may hold an optional `_subject.md` (Purpose,
Template, `Sensitivity: private`, Inherits). Private subjects are excluded
from the index and hidden; you must never file into them without being
asked to. The `health_check` tool reports violations; the write tools
refuse to create them.

## 4. The note format

The exact rulebook is **`StructureOFnotes.md`** — read it; every example in
it is verified by the test suite. In brief: the file starts with
`# The Note Title`, then optionally a `:::quick-info` block (`Label: value`
rows, `## Group` lines, `Image:` lines, `Common name`/`Aliases` = title
aliases), then the main text (any supported Markdown), then `## My notes`
(append-only), then `## Connected notes` (one `[[File Name]]` per line),
then `## Reference sources` (`[Title](url) — accessed date`), then a
`:::meta` block (Created/Updated/Pinned; there is no Status anywhere).
Supported Markdown: headings, bold, italic, strikethrough, lists, task
lists, tables, code blocks, quotes, footnotes, images placed exactly where
written (consecutive images render as a grid; `![alt|50](…)` sizes an
image), web links, wiki links, horizontal rules, `$…$` and `$$…$$` math.

## 5. Tags (independent and always in sync)

- Notation: one flat name per tag, commas between entries in `tags.txt`,
  underscores for spaces, capitals ignored. No levels, no parents, no
  propagation — `FOOD-pasta-vegetarian` matches only itself.
- `_tags.md` is the master vocabulary: `## Approved tags` (grouped under
  `### MAJOR` headings for readability only, each line optionally
  `TAG: synonym, synonym`), a general `## Synonyms` map
  (`quick: fast, rapid, speedy`), and `## Proposed tags`.
- **Automatic sync:** any tag you apply through `create_note` or
  `edit_tags` is added to the Approved tags of `_tags.md` at the same
  moment (the tool result names it under `master_updated`). Still call
  `list_tags` first and REUSE existing tags instead of inventing
  near-duplicates; the extractor flags near-duplicates and tags used once.
- `approve_tags` moves tags from Proposed to Approved at the user's
  direction.

## 6. The full search system — BM25 + optional grep (v4.2.2: honest marks, one engine)

One engine serves the website and you (`search_notes`), so results are
identical — this is asserted by a test (MCP and webapp must return the same
order for the same query). There is no semantic model; it ranks **notes**,
never chunks, and it reads the **whole** note — body, headings, quick-info
labels and values, tags, file names and folder paths are all indexed;
nothing hidden.

**BM25 and grep are the whole engine — nothing else.** There is NO fallback
ranker: a word nothing matches is an honest miss, reported as a red cross.

- **BM25 is the ranking algorithm.** A field-weighted BM25 (BM25F) scores
  every note over six fields: title ×3.0, aliases ×2.0, headings (incl.
  quick-info labels) ×2.0, tags ×2.5, body (incl. quick-info values) ×1.0,
  folder path ×1.5. Rarer words count more (shared IDF), longer fields are
  normalized (per-field avgdl, k1/b saturation), and coverage multiplies —
  matching more of the query's words beats matching one many times.
- **Grep is the optional exact stage — and it is SUBSTRING-exact.** Pass
  `grep` as a list of keywords (or a comma string); each must appear in the
  note **literally** (case ignored; a keyword inside a bigger word counts:
  typing `maxwell` catches `puremaxwell`). Keywords are AND-combined: a
  keyword matches 100% or the note is out. Use BM25 alone (query only),
  grep alone (empty query + keywords, ranked by hit count), or both (grep
  filters, BM25 ranks). Grep never falls back — a no-hit grep returns a
  `notice`, not nearest guesses.
- **Per-keyword evidence (v4.2.2).** Every query word and every grep keyword
  appears in `query.keywords[]` with `bm25_found` + `bm25_df` (does the word
  exist for BM25, in how many notes) and `grep_found` + `grep_notes` (does
  grep find it literally, in how many notes):
  - `status: "both"` — both engines know the word (UI: green ✓)
  - `status: "bm25"` — BM25 only (UI: plain ✓)
  - `status: "grep"` — **BM25 has NO word match anywhere but grep finds it**
    (UI: amber ⚠ warning). The results are still included and ranked —
    flagged `bm25_zero` per result with `grep_only_words`, and listed in
    `warnings[]`. Tell the user which words only grep caught.
  - `status: "none"` — neither engine finds it (UI: red ✗), also collected
    in `no_word_match[]` with an explanatory `notice`.
  Each result also carries `keyword_matches[]` — per word: `bm25` (its terms
  scored in THIS note), `grep` (appears literally in THIS note),
  `grep_count`. Use it to answer "what did BM25 and grep both match, and
  where did BM25 miss but grep catch?"
- **Scope:** everything (default), file name, tags, headings, body,
  folder path — narrows which fields BM25 searches and which texts grep
  scans.
- **Folders are a hard boundary:** with `folders` set, nothing outside
  them (their sub-folders included) is ever searched; `folder_only`
  limits to the folder itself. **Selected `tags` are hard filters** —
  every result carries all of them.
- **The query pipeline:** the query is lowercased, de-accented, dashes and
  underscores become spaces, filler words drop (negations like *no, not,
  without* stay), words are stemmed (`recipe` ≈ `recipes`), one wrong
  letter is tolerated for words of 5+ letters, word-PREFIX fragments expand
  against the vocabulary (`garl` → `garlic`; v4.2.2: mid-word substring
  expansion is REMOVED — catching a word inside a bigger word is grep's
  exclusive job, so the red-cross/warning marks stay honest), synonyms count
  0.7, and words matching an approved tag or tag synonym are reported as
  `query_tags`. `"Quoted phrases"` are BM25 virtual terms with
  occurrence-count tf, boosted by `phrase_weight` (1.5).
- **Ordering:** an exact title/alias match ranks first; then score, more
  groups matched, recently updated, title A–Z — deterministic. Results
  carry a one-sentence `rank_reason`, `grep_matches` (keyword → hit count)
  and a per-field `breakdown` — relay the reason when the user asks "why".
- **Defaults and limits:** top 20 (`page_size` setting); cap any call with
  `max_results` (alias of `page_size`) and page with `offset`. A BM25
  search where nothing matches returns an EMPTY page with the red-cross
  notice — no fallback junk (removed in v4.2.2). With grep keywords set and
  BM25 empty, grep's literal hits are still returned (amber-warning,
  ranked by grep hits). An empty query with tags lists the tag carriers; a
  fully empty search returns recently updated notes.
- **Tuning before a search:** call `get_settings` to read the live
  settings and `update_settings` to change any subset — `bm25` (k1, b),
  `bm25_field_weights` (the six fields), `phrase_weight`,
  `coverage_base`, `synonym_weight`, `page_size`, `max_word_groups`,
  `typo_tolerance`, `typo_min_length`, the prefix expansion limits,
  `default_theme`, `server_port`. Changes take effect on the next
  search, on the website too. Changing a weight that changes result ORDER
  for the user's normal searches is a structural change → log it (§7).

## 7. How to work

1. Read `SKILL.md` (this file) and `StructureOFnotes.md` first. They are
   also available via `get_structure` at any time.
2. Call `list_tags` before tagging; call `search_notes` (or
   `suggest_tags`) **before creating any note** — an existing note may
   already hold the knowledge.
3. File into the **deepest matching subject** that already exists; never
   invent subjects.
4. **Ask before creating a new folder.** The tools answer
   `needs_approval: true` with a question; ask the user, and only call
   again with `approve_new_folder: true` after they agreed.
5. **LOG RULES (v4 — binding):**
   - `logs/` is manual only. The engine never writes log files. Never
     edit or delete anything in `logs/` except by adding a new entry.
   - **You MUST add a log entry yourself after any structural change you
     make to the app** — a new feature, changed behavior, a renamed or
     added tool or file, a modified rule, or a settings change that alters
     the user's results. Use `add_log_entry` with a clear `title`, the
     `details` (what and why) and your `who` name. Do it before you report
     the change as done.
   - The ONE automatic file is `logs/edits.md` (the note-edit history:
     which note, which lines added/removed). Read it with
     `get_edit_history`. Do not edit it.
6. When you file an inbox note: read it (`file_note` accepts `inbox_file`
   or `text`), find or create the right note, connect it to related notes
   (`connect_notes`), and tell the user what you did and where.
7. Process `inbox/` when the user asks; leave the original file in place
   unless told otherwise.
8. When you change code or structure, verify with the tests:
   `cargo test` (unit + the BM25/grep suite + structure examples) — then log.

## 8. Hard rules

- **Never overwrite the user's text.** `edit_note` refuses any change that
  alters or removes existing `## My notes` lines (append with
  `append_my_notes` instead). Prefer adding dated sections over rewriting.
- **Never invent facts.** If you summarize or restate, stay inside what
  the sources (notes, references, the user) actually say.
- **Logs are manual and named.** Your manual log entries carry your name;
  never attempt to suppress, edit or delete log files or the journal, and
  never undo anything without the user asking for it — nothing is ever
  reversed automatically.
- **Never create files or folders outside the allowed structure** (see 3),
  and never create a folder without asking first.
- **Reuse existing tags** (call `list_tags` first); any new tag you apply
  lands in the master list automatically — keep the vocabulary tidy.
- Paths you pass are checked against the structure; anything outside is
  refused, no exceptions.

## 9. Exposed tools (48)

Every tool returns JSON in `content[0].text`. Errors come back as
`isError: true` with an `error` message — surface them to the user instead
of retrying blindly. A `needs_approval: true` result means: ask the user,
then retry with `approve_new_folder: true`.

| Tool | Inputs → does |
| --- | --- |
| `search_notes` | THE engine (same one as the website — no duplicate). `query, grep, tags, folders, folder_only, scope, include_connected, status, date_from, date_to, limit_to, offset, page_size, max_results` → ranked notes with score, `rank_reason`, `grep_matches`, coverage, per-field BM25 breakdown, and v4.2.2 keyword evidence: `query.keywords[]` (per word `bm25_found`/`bm25_df`/`grep_found`/`grep_notes`/`status`), `warnings[]` (BM25 missed, grep caught — still ranked), `no_word_match[]` (red cross), per result `keyword_matches[]` + `grep_only_words` + `bm25_zero`. Grep is substring-exact (`maxwell` catches `puremaxwell`). `max_results`/`page_size` cap the count. Example: `{"query": "quick pasta", "folders": ["Recipes"]}`, `{"grep": ["lentil"]}` or `{"query": "", "grep": ["lentil"], "max_results": 5}` |
| `suggest_tags` | `query, kind(all/tag/folder)` → type-ahead suggestions that really exist, with counts |
| `list_tags` | — → GET ALL TAG DATA: the flat tag list with usage counts, unapproved, near-duplicates, used-once and proposed tags |
| `list_folders` / `list_subjects` | — → the subject tree with note counts (private marked) |
| `list_notes` | — → every note with path, title, folder, tags, updated, pinned |
| `read_note` | `path` (rel path or note name) → full text, hash, meta, tags, tasks, incoming connections, broken links. Example: `{"path": "Garlic Bread"}` |
| `get_connections` | `path` → GET ALL CONNECTION DATA: connected notes (out, with exists flag), incoming links (in), in-text links, references |
| `file_note` | `name, text\|inbox_file, folder, tags, reason, approve_new_folder` → creates the note or appends a dated *Filed* block into an existing one; tags used are synced into the master list; asks before creating folders |
| `create_note` | `name, folder, text, tags, quick_info, reason, approve_new_folder` → creates the note folder with `.md`, `tags.txt`, `attachments/`; returns `master_updated` |
| `edit_note` | `path, text, base_hash, force, reason` → raw edit; refuses My-notes changes; pass `base_hash` from `read_note` to detect concurrent edits |
| `append_my_notes` | `path, text, reason` → appends at the end of the user's My notes |
| `move_note` | `path, folder, name` → moves and/or renames, rewriting every link |
| `rename_note` | `path, name` → renames in place, links rewritten |
| `delete_note` | `path, reason` → deletes the note folder, scrubs connections; one undo restores every text file |
| `edit_tags` | `path, add, remove, reason` → updates `tags.txt` and the master list together (always in sync) |
| `connect_notes` | `path, add, remove, edit_link{target, word, new_target, unlink}` → edits the Connected notes section and in-text links |
| `add_reference` | `path, add{title, url, accessed}, remove_url` → edits Reference sources (https added for bare domains) |
| `edit_quick_info` | `path, text` → replaces the `:::quick-info` block (raw text per StructureOFnotes 3) |
| `add_attachment` | `path, filename, data_base64` → adds an image to `attachments/` |
| `edit_links` | `path, word, target, make_note` → link words to a note or a URL, or unlink (target null) |
| `edit_metadata` | `path, meta{...}` → edits `:::meta` (Created/Updated/Pinned; Status is ignored) |
| `export_metadata` | `path` → the plain-text export: exact file location, all tags on the note, every tag used in the wiki, connected notes (both directions), references, attachments |
| `crop_image` | `path, filename, rect{x,y,w,h}, mode(replace/keep_both)` → crop saved as a NEW image (in-process, no external dependency) |
| `delete_image` | `path, filename` → warns if referenced; keeps the old file in backup history |
| `rename_tag` | `from, to, run` → preview first (`run` false), then rename the tag everywhere |
| `merge_tags` | `from, into, run` → preview first, then merge |
| `approve_tags` | `tags` → moves tags from Proposed to Approved **after the user agreed** |
| `health_check` / `get_health_data` | — → GET HEALTH DATA: fault-isolated checks (broken links, untagged notes, used-once tags, near-duplicates, no-connection notes, structure problems); fixable findings carry `fixable: true` |
| `health_fix` | `action, params` → apply one repair: `remove_broken_links`, `remove_stray_attachment`, `fix_missing_dates`, `merge_tags`, `approve_tag` |
| `toggle_task` | `path, index` → tick/untick the Nth checklist item; returns the new text + hash |
| `backup_preview` / `backup_run` / `backup_restore` / `backup_verify` | `to, scope, keep, direction` → the full backup tool; `to` must be outside the project; success = byte-identical after re-hashing every file |
| `undo_change` | `log` (a change id from the undo journal) → reverses that change; nothing reverses automatically |
| `saved_searches` | `action(list/save/delete/run), name, params, query` → saved searches |
| `get_structure` | — → the allowed structure + full `README.md` and `StructureOFnotes.md` |
| `add_log_entry` | `title, details, who` → writes a MANUAL log entry under your name. **Required after any structural change you make.** |
| `get_edit_history` | — → the automatic note-edit history (logs/edits.md): note, when, who, lines added/removed |
| `get_settings` | — → the live settings (BM25 k1/b, field weights, phrase weight, coverage, synonyms, page size, typo tolerance, theme, server) |
| `update_settings` | `settings{...}` → change any subset of the settings **before** searching; effective on the next search |

## 10. Error handling and worked examples

**Common errors and what they mean**

- `NeedsApproval` / `needs_approval: true` — you hit the folder gate. Ask
  the user; only then retry with `approve_new_folder: true`.
- `PermissionError: 'My notes' is append-only…` — you tried to change the
  user's section. Re-send the text with your addition appended after the
  existing lines, or use `append_my_notes`.
- `ValueError: Tag 'x y' is not valid…` — use underscores for spaces:
  `HOME_REPAIR-wall_painting`.
- `ValueError: A connection to a note that does not exist…` — check the
  spelling; only real note names can be linked. Use `suggest_tags`/search
  to find the right name.
- `conflict: true` from `edit_note` — the file changed since you read it
  (the user edited while you worked). Re-read with `read_note`, merge your
  changes, retry; only pass `force: true` if the user says so.

**Example — filing an inbox note.** The user says "file my inbox." You
read `inbox/film recommendation from Sara.txt`, then:

```
file_note {"name": "Perfect Days (film)",
           "inbox_file": "film recommendation from Sara.txt",
           "folder": "Reading", "tags": ["FILM-drama"]}
→ {"needs_approval": true, "question": "The folder 'Reading' does not exist…"}
```

You ask the user; they agree:

```
file_note {..., "approve_new_folder": true}
→ {"filed_into": "database/Reading/Perfect Days (film)/…md", "action": "created",
   "master_updated": ["FILM-drama"]}
connect_notes {"path": "Perfect Days (film)", "add": ["The Pragmatic Programmer"]}
add_log_entry {"title": "Filed inbox note", "details": "- Filed 'Perfect Days (film)' into Reading/ ...", "who": "AI"}
→ tell the user: filed under Reading, tag added to the master list, logged.
```

**Example — "what do I know about quick pasta?"**

```
search_notes {"query": "quick pasta recipe"}
→ first result "Quick Vegetable Pasta for Weeknights" (score 100.0,
  coverage 1.0, title and body BM25 fields applied)
read_note {"path": "Quick Vegetable Pasta for Weeknights"}
→ answer from the full text, quote it, and cite the note's references.
```

**Example — "notes that literally mention lentils AND carrots, but ranked
by relevance to soup."**

```
search_notes {"query": "soup", "grep": ["lentil", "carrots"]}
→ only notes containing both words literally; BM25 orders them;
  each result's grep_matches shows the hit counts.
```

**Example — the user wants body text to dominate before a search.**

```
get_settings {} → bm25_field_weights {title: 3.0, body: 1.0, ...}, typo_tolerance: true
update_settings {"settings": {"bm25_field_weights": {"title": 1.0,
  "aliases": 1.0, "headings": 1.0, "tags": 2.0, "body": 5.0, "folder": 1.0}}}
search_notes {"query": "..."}   # now ranked with the new weights
add_log_entry {...}             # a weight change that alters results is structural
```

**Example — the user corrects a note.** `read_note` first, then `edit_note`
with the full new text (their lines intact, your change visible), then say
what changed; the edit lands in the automatic edit history (lines
added/removed) and the undo journal.

### Tools added in v4.1

- `get_tag_notes {tag}` — every note carrying one tag: full paths, titles, folders, updated dates.
- `list_attachments {path}` — a note's image files: full path, size, and ready-made Markdown.
- `get_logs {name?}` — list the manual log files, or read one (`name=edits` is the automatic per-edit line log).
- `get_state` — whole-wiki snapshot: note count, recently updated, pinned, saved searches.
- `rebuild_index` — force a full re-index after big external changes.
