# SecondBrain 4.0 — every change and its proof

v4 is a full rewrite in Rust plus the requested feature set. Each item names
what changed and HOW it is proven. The automated suite is
`cargo test` (unit + ranking + structure examples); the end-to-end flows were
additionally exercised over the real HTTP API and the real MCP stdio server.

| # | Change | What actually happened | Proof |
| --- | --- | --- | --- |
| 1 | Rewrite the whole project in Rust | `core/` (engine crate: textutil, paths, tags, parser, store, editlog, logger, indexer, search, healthcheck, images, backup), `website/` (axum server), `mcp/` (stdio JSON-RPC server), `backup/` (CLI) — one cargo workspace. The data format and the JSON API shapes are unchanged. | `cargo build --workspace` succeeds; the JSON API answers the same routes (`/api/state`, `/api/search`, `/api/note`, …) against the original example database |
| 2 | Same functions, 100% | Every website route, every MCP tool capability and the backup tool from v1.2 exist in v4; the data written by v1.x loads unchanged. | The fixed ranking test set (17 queries + behavior rules) passes against the original example notes: `cargo test --test ranking` — all PASS |
| 3 | Remove the UI graphs; connected notes are the map | The Graph page and the SVG branch map were removed. The note page shows one Connected notes panel: *Connects to* and *Referenced by* lists with click-to-open and × to remove; linked-in-text connections listed and unlinkable. | `website/app/src/views/` contains no graph view; screenshots verified in the browser (dark + light) |
| 4 | Table editor via the Table button | Edit mode: cursor in a table + Table tool opens a grid dialog of the existing table (cells editable, +Row/+Column, per-row/column delete); Update rewrites the same lines in place; Insert writes a new table at the cursor. | Browser-verified: the pasta note's 9-row Ingredients table opened, a cell edit rewrote the exact table lines in the draft |
| 5 | Select Markdown → tap the tool | Smart wrap/prefix tools: selection is wrapped, an already-wrapped selection (or a word already surrounded) is unwrapped on the second tap; no-selection inserts the pair with the cursor inside; prefix tools toggle per line. | Toolbar code `smartWrap`/`smartPrefix` in `website/app/src/views/note.tsx`; browser-verified |
| 6 | Multi-image grid with move + size | Consecutive image lines render as a grid (≤3 columns). Hover controls: ←/→/↑/↓ reorder within the grid (up/down swap rows), size cycles 25→50→75→100%. Every change rewrites exactly the affected `![…](…)` lines and saves. | `imageOp` in note.tsx + `.sb-img-grid` CSS; verified in the browser on the Gallery group of the pasta note |
| 7 | 42 MCP tools incl. health data, tag data, connection data, settings | 36 v1.2 capabilities plus `get_health_data`, `get_settings`, `update_settings`, `add_log_entry`, `get_edit_history`, `list_notes`. `update_settings` changes ranking/advanced settings before a search. | `tools/list` returned 42 tool definitions over real stdio; search/read/create/settings/log calls verified live |
| 8 | StructureOFnotes.md fully verified | Every fenced example marked `verify=<name>` is extracted by a test and run through the real parser/tag/reference machinery (title, quick info rows + groups + image + alias, tasks, tables, sized images, wiki links, footnotes, tags.txt, reference line with accessed date, meta block). | `cargo test --test structure_examples` — PASS; the doc uses a 4-backtick fence so the nested code fence survives extraction |
| 9 | Preview under every typing bar | `SuggestInput` backs tag inputs, connected-note input, folder inputs and search filters: a live dropdown lists every existing tag/folder matching the text with note counts. | `website/app/src/components/shared/suggest-input.tsx`; visible in the Tags panel, Connect dialog, New-note dialog, Files move/rename, Search filters |
| 10 | Find bar + Markdown toolbar stick to the top | Both use `position: sticky; top: 0` inside the page (`sb-sticky`). The find bar works in preview (highlight + n/total + ↑/↓ jump) and edit mode (selects the match in the textarea and scrolls it into view). | CSS + FindBar component; browser-verified in both modes |
| 11 | Search covers the full note | The index holds body tokens (with section spans), heading tokens, quick-info labels (as headings) and values (as body), title tokens, tag text and folder path — nothing hidden. Scopes only narrow. | Ranking suite: body-only queries (`fast veggie meal`), heading/label hits, tag hits and folder-path boundaries all PASS |
| 12 | 12 themes; Grey default; light themes never white | Dark: grey (default; darker-tone grey background), ocean blue, forest, plum, crimson, amber. Light: sky, sage, rose, sand, lavender, paper — each background is a deeper tinted shade (L≈80-83%) and cards/buttons lighter shades (L≈90-93%) of the same hue; no pure white anywhere. | `src/index.css` theme tokens; verified in the browser (grey + sky screenshots) |
| 13 | New brain logo | A modern geometric brain SVG: two hemispheres, central fissure, synapse nodes + links, gradient stroke on a rounded plate; also the favicon. | `website/app/src/components/shared/logo.tsx`, `public/favicon.svg`; rendered in the top bar |
| 14 | shadcn/ui + HeroUI style | Radix primitives + Tailwind (shadcn/ui recipes) for Button/Card/Dialog/AlertDialog/DropdownMenu/Select/Tabs/Switch/Checkbox/Popover/Tooltip/RadioGroup + cmdk palette + sonner toasts; HeroUI-flavored gradient hero/cards/buttons (`.sb-hero`, `variant="hero"`). | `website/app/src/components/ui/`, index.css |
| 15 | LOGS: manual only + AI instruction + edits.md automatic | The engine writes log files nowhere. `logger::new_log` is called only from the manual endpoints (`/api/log/create`, `add_log_entry`) and the tag-approval flows the user drives. The single automatic file is `logs/edits.md` with lines added/removed per note edit. LOGS.md and SKILL.md instruct the AI to log after structural changes. | Fixture run: `create_note` wrote NO log file; `save_note_text` appended exactly one edits.md entry with the added/removed lines; manual entry via the tool landed as `YYYY-MM-DD_HH-MM-SS_Test_entry.md` |
| 16 | Undo journal | Every write records reversal steps in `core/.cache/undo-journal.json`; the Logs page and `undo_change` (change id) reverse a change only on request; the undo itself is journaled. | Fixture run: undo of a created note removed exactly its files and reported each step |
| 17 | Health checks + one-click fixes | 11 fault-isolated checks (broken links, no tags, no connections, used-once tags, near-duplicates, unapproved, missing-from-master, proposed, no dates, stray attachments, structure) with fix actions; a failing check shows an error card, never a broken page. | `/api/health` on the example database: ok=true with all 11 checks present |
| 18 | Byte-identical backup | manifest (size+sha256) → compare (unchanged/changed/new/removed/moved) → archive to `.versions/<stamp>/` → copy → re-hash EVERY file on both sides; success only when identical; the report is written inside the copy (`.backup-runs/`), the live project only read. | `secondbrain-backup --to … --verify` returns per-file differences; library used by CLI + API + MCP tools |
| 19 | Engine safety rules kept | append-only My notes, unique note names, folder gate with `needs_approval`, tag master sync, https auto-add, atomic writes, hash-conflict detection, private subjects excluded from the index. | Unit tests + the same behaviors exercised live during development |

## v4.1 — real-world testing round (bug hunt + fixes)

Everything below was reproduced first, fixed, then re-verified with automated
suites (75 API checks, 52 MCP tool calls, screenshot walk-through of the UI).

1. **Search could not catch fragments** — typing `garl` or `tomat` returned
   nothing because the engine only matched whole vocabulary words. The engine
   now expands every query word against the vocabulary: prefix hits (`garl` →
   `garlic`) rank at 0.9 weight, mid-word substring hits at 0.8, typos at 0.7
   as before. Search-as-you-type works; snippets, closeness and coverage all
   see the expanded words.
2. **Fallback results looked broken** — a query with no hits showed random
   notes with `0.00` scores. The search page now shows an explicit amber
   banner: "No note directly matched … these are the closest notes."
3. **Clicking a search result did not take you to the word** — results now
   open the note with the find bar pre-filled and the view scrolled to the
   first hit; multi-word queries land on the longest word when the phrase
   itself is split across paragraphs.
4. **Images added by hand-typed Markdown did not render** — `![x](attachments/p …)`
   resolved against the database root instead of the note's own folder. One
   resolver now accepts every spelling: `attachments/…` (note-relative),
   `Folder/Note/attachments/…`, `database/…`, or a full URL. The upload
   dialog inserts a path that renders; the hint text matches reality.
5. **Duplicate image files** — uploading the same picture twice wrote
   `name-HHMMSS.png` copies. Uploads are now deduplicated by content hash:
   identical bytes return the existing file (`"duplicate": true`).
6. **Images written inside a sentence** rendered as `[image: …]` text; they
   now render as inline images (click to enlarge), and links to attachments
   resolve like images.
7. **The full-screen viewer** used a raw relative path that 404'd; it now
   uses the real `/files/` URL.
8. **New-note dialog** — folder and tags inputs removed; only the note name
   (created in the folder you are browsing, database root at the top).
9. **MCP: rename_note moved notes to the database root** — the folder is now
   preserved. **move_note renamed the folder but not the .md file** — the file
   is renamed with the folder (a note file is always named exactly like its
   folder). Link rewriting unchanged.
10. **Five MCP tools added** (`get_tag_notes`, `list_attachments`, `get_logs`,
    `get_state`, `rebuild_index`) — 47 tools total; the AI can now fetch every
    tag's notes, every note's image files with ready-made Markdown, the logs,
    a whole-wiki snapshot and can force a re-index.
11. **`/api/suggest`** accepts `kind=` as an alias of `type=`; **`/api/log`**
    accepts `name=edits` without the `.md`; health-fix action names validated
    with a clear error.
12. **Backup verified by a destructive simulation**: backup (261 files,
    byte-identical, every file re-hashed) → verify → database wiped → restore
    through the same API (`direction: "restore"`) → `diff -r` byte-identical,
    all notes back. The Backup page, the `secondbrain-backup` CLI and the MCP
    backup tools share this engine.

## v4.2 — the BM25 + grep search engine

The search algorithm is **totally changed** as requested: BM25 is the main
lead, grep is an optional exact stage, and the old strict/ranking modes are
gone. Every change is proven below.

| # | Change | What actually happened | Proof |
| --- | --- | --- | --- |
| 1 | **BM25 is THE ranking algorithm** | `core/src/search.rs` rewritten: a field-weighted BM25 (BM25F) scores every note over six fields (title ×3.0, aliases ×2.0, headings ×2.0, tags ×2.5, body ×1.0, folder path ×1.5) with shared IDF, per-field length normalization and k1/b saturation. The old six-signal weighted ranker (tags 34% / title 24% / headings 14% / neighbors 12% / body 10% / closeness 6%) and the neighbors/closeness signals are deleted. | `cargo test --test ranking`: 23 fixed query cases (BM25 relevance, synonyms, typos, fragments, phrases, scopes, folders, tags) all PASS; the fixed API suite asserts score = 100 for the best match and 0..100 for all |
| 2 | **Grep — optional exact keywords (100% match)** | A separate keyword list (UI switch + chips; MCP `grep` array or comma string; API `grep=` param). Each keyword must appear in the note literally (case ignored, substring — `one pot` matches the phrase), AND-combined. BM25-only (default), grep-only (ranked by hit count), or both (grep filters, BM25 ranks). | Ranking suite: grep-only `lentil` → soup note only; `lentil+carrots` → exactly 1 note, garlic bread excluded; grep no-hit → 0 results + notice (no fallback — exact means exact); `grep_matches` counts verified (`lentil ×16`); API suite: multi-word keyword, AND semantics, notice text |
| 3 | **Strict/ranking modes removed** | The *Ranking only / Strict keyword / Strict tag* radio group is gone from the UI; `mode`, `tag_mode`, `keyword_mode` params are removed from the engine, the API and the MCP schema. Selected tags are now always hard filters (must carry all). Old params sent to `/api/search` are ignored gracefully. | UI: no mode radio group (grep card + scopes instead); API test "legacy mode params ignored gracefully" PASS; MCP `tools/list` schema has `grep`, no `mode` |
| 4 | **Advanced options kept** | Scopes (everything / file name / tags / headings / body / folder path) narrow the BM25 fields and the grep texts; folders stay a hard boundary; dates and status filter; saved searches carry grep keywords. | Ranking suite scope cases (file name, tags, headings) PASS; API tests for scopes, folder boundary, saved-search save/list/delete with grep |
| 5 | **Index upgraded for BM25F** | `core/src/indexer.rs`: per-field term frequencies (title/aliases/tags/folder), per-field lengths and average lengths, `all_df` (document frequency across all six fields, shared IDF). INDEX_VERSION → 101 (old caches rebuild automatically). | `cargo build` + all tests pass on the rebuilt index; the 6-note example database re-indexes cleanly |
| 6 | **Settings moved to BM25 knobs** | `core/settings.json` + defaults: `bm25` (k1 1.5, b 0.75), `bm25_field_weights` (six fields), `phrase_weight` 1.5, `coverage_base`, `synonym_weight`, typo + prefix/substring limits. `ranking_weights` and `closeness_window_tokens` deleted everywhere (engine, UI, MCP descriptions, docs). | API tests: settings endpoint exposes `bm25_field_weights`, `ranking_weights` gone; MCP `update_settings` round-trip (title weight 3.0 → 6.0 → restored) changes ranking live |
| 7 | **Phrases are BM25 virtual terms** | `"quoted words"` count literal occurrences per field (tf = occurrence count, df = notes containing the phrase) with a `phrase_weight` boost instead of being a strict-mode filter. | Ranking suite: `"one pot"` ranks the one-pot pasta note first |
| 8 | **Kept from v4.1** | Typo tolerance, fragment expansion (garl → garlic), synonyms (0.7), coverage multiplier, exact-title-first, deterministic ties, fallback-never-blank (BM25-only), `include_connected` extras, per-result explanations. | The same behaviors re-verified in the v4.2 suites: `pastha`/`lental` typo cases, `garl` fragment case, fallback 6-results case, determinism case, `include_connected` case — all PASS |
| 9 | **UI rebuilt around BM25 + grep** | Search page: grep card ("1 · Grep — keywords that must match 100%" with switch, keyword chips, hints), scopes + tags + folders + dates in card 2, live mode badge (BM25 / grep / BM25 + grep), grep hit badges on results (`lentil ×16`), per-field BM25 bars in *Why this ranking*, rewritten How-to-use dialog. Settings page shows the BM25 field weights and k1/b. Home action card and saved-search links updated. | UI rebuilt (`vite build`) and browser-verified; grep keywords are passed through saved searches and result→note jumps |
| 10 | **Docs updated everywhere** | README.md (intro, "What changed in 4.2", the full Search section, settings, tools, tests, version), SKILL.md (§6 rewritten, tool tables, examples), FIXES.md (this section), StructureOFnotes.md (connections/references wording), in-app help texts. | `grep -rn "ranking_weights\|strict_keyword\|strict_tag" README.md SKILL.md core/src` returns nothing |
| 11 | **End-to-end verification** | 21 unit tests + the BM25/grep suite (38 checks) + structure examples — all PASS. 37 live HTTP API checks and 32 live MCP stdio checks against the real binaries (search combinations, scopes, tags/folders, saved searches with grep, settings round-trips, regressions of every v4.1 fix: note read, health, folders, suggest, logs). | `cargo test` green; the two live suites in `scripts/test-v42-api.mjs` and `scripts/test-v42-mcp.cjs` — 69/69 checks PASS |

## v4.2.1 — the missed-stuff round (connect notes / quick card / find bar)

Every complaint from the re-test round, each fix proven by a live check.

| # | Complaint | Root cause | Fix + proof |
| --- | --- | --- | --- |
| 1 | "Connect-a-note search shows tags and folders — I want ONLY notes" | The dialog used `SuggestInput kind="all"`, which mixes tags, folders and notes. The backend already had a notes-only mode that was never wired up. | Dialog now sends `kind="note"`: `/api/suggest?q=so&type=note` returns only `Lentil Soup for Cold Evenings`; browser check — typing `so`/`gar` lists only note titles with a 📄 icon and their folder on the right. |
| 2 | Connections never showed after connecting (missed entirely) | **`parse_connected` only read `[[wiki links]]`, but "Connect a note" writes plain title lines** — the app wrote a format it could not read back, so every UI-made connection vanished on reload. | Parser now accepts plain titles, bullets and path forms (wiki links unchanged); unit test `test_parse_connected_plain_and_wiki`. Live proof: connect Garlic Bread → panel shows it → API reads it back → × removes it. |
| 3 | "Quick card layout — the text grid is off, up and down" | Quick-info values render through MarkdownBody; `.sb-prose p { my-3 }` (specificity 0,1,1) beat the `[&>*]:my-0` utility (0,1,0), so every `<p>` added 12px top+bottom and pushed rows out of line. | New `sb-compact` prose (zero vertical rhythm, `!important`) + plain text values render as bare text. DOM proof: label-top minus value-top = **0px on every row** (was ±12px). |
| 4 | "Find-in-note: ↑/↓ never takes me to the word, no special highlight on the selected one" | The module-level find counter was **never reset** (imported, never called): hit numbers drifted upward across renders, so `data-find-hit` never matched the bar's active index — the jump selector found nothing and the active class never applied. | `resetFindCounter()` on every render pass + a scroll-to-active-mark effect that runs after paint; ↑/↓ keys also work in the find input; My notes hits now highlight too. Browser proof: 3 hits for `lentil`, tapping ↓ moves 1→2→3→wraps, page scrolls (scrollY 0→66→382), active mark bg `rgba(250,201,56,.9)` (yellow) vs inactive `rgba(126,116,231,.45)`, counter `n / total` correct; clicking a search result lands on the first highlighted word. |
| 5 | Search ranking sanity ("confirm and verify") | Verified live, not broken | `lentil soup`→Lentil Soup 100; `garlic`→Garlic Bread 100; `pastha`/`lental` typos still hit; `weeknight` body-hit ranks the pasta note first. (Journal notes are excluded from search by design: `Sensitivity: private`.) |
| 6 | "My notes" section rendered TWICE on every note (missed) | The parser pushed the My-notes section into **both** `doc.body` and `doc.my_notes`, and the page rendered both. | Parser keeps My notes out of the body; indexer tokenizes it as its own paragraph so its words stay searchable. Proof: h2 list = `Ingredients, Method, My notes` (was duplicated); `q=freezes` (a word only in My notes) still finds the soup note at score 100. Index version → 102. |
| 7 | No way to delete a note at all (UI could only delete empty folders; no MCP tool) | Missing capability. | `store::delete_note` (removes the note folder, scrubs the title from other notes' Connected sections, journals every text file for one-step undo), `POST /api/note/delete`, MCP tool `delete_note` (48 tools now), and a trash button with confirm on the note page. Proof: delete → gone; undo restores note + tags.txt + connections; the misleading "(nothing is reversed automatically)" undo message is fixed. |
| 8 | Regression safety | — | `cargo test` 22+2 PASS; live suites: **37/37 API** (`scripts/test-v42-api.mjs`) and **32/32 MCP** (`scripts/test-v42-mcp.cjs`) against the final binaries. |

## v4.2.2 — BM25 + grep made honest, images fixed, one engine, UI taste

Every complaint from this round, each fix proven by a live check or an
automated suite (cargo test, 72 API checks, 42 MCP checks, browser DOM
assertions + VLM screenshot review).

| # | Complaint / request | Root cause | Fix + proof |
| --- | --- | --- | --- |
| 1 | "In health remove structural problems section" | The check existed since v1. | Removed from `health_check` (10 checks remain) and from the Health page labels. API test: `structure_problems` key gone, exactly 10 checks; browser check: no "Structure problems" card renders. |
| 2 | "The algo must ONLY use BM25 and grep — nothing else" | A jaccard-title "fallback ranker" invented pseudo-relevant notes when nothing matched, muddying what the engines actually found. | The fallback ranker is deleted. A miss is an honest miss: empty results + `no_word_match[]` + notice. Ranking test "no fallback: honest miss → 0 results, red-cross words [zzzqqq, xyzzyq]" PASS. |
| 3 | "If a BM25 keyword is not existing in notes, show the score as a red cross (no word match)" | The response had no per-keyword existence info. | New `query.keywords[]` per query word and grep keyword: `bm25_found`, `bm25_df`, `grep_found`, `grep_notes`, `status` (both/bm25/grep/none). UI renders red ✗ chips + a red notice for `status:"none"`. Tests: red-cross scenarios PASS (pure and mixed queries). |
| 4 | "If BM25 got no result but grep has it, show a warning sign but include it in ranking still" | Grep hits were silently merged without flags. | `warnings[]` (`bm25_miss_grep_hit`) + per-result `bm25_zero`, `grep_only_words`, `keyword_matches[]` (bm25/grep booleans + grep_count per word). Grep-rescued notes stay ranked (score = grep coverage). Ranking + API + MCP tests PASS; browser shows the amber banner and badge. |
| 5 | "Grep must catch maxwell inside puremaxwell — don't ignore it" | Grep always was substring-based, BUT BM25's own mid-word substring expansion (maxwell→puremaxwell @0.8) made the engines indistinguishable and hid the red-cross/warning distinction. | BM25 mid-word substring expansion REMOVED (word-prefix `garl→garlic` kept for search-as-you-type); substring matching is grep's exclusive job. New tests: `test_grep_substring_catches_inner_word`, ranking "grep substring: maxwell finds puremaxwell note" PASS. `substring_*` settings deleted. |
| 6 | "50 web scrapes (deepseek v4 flash KV cache GB, DGX Spark specs, 9r4n4y) — raw fetch into notes, don't read them" | — | `scripts/scrape50.py` + top-up: 50 notes created through the real note-creation API into `database/Web Clippings/<topic>/` (24 DeepSeek KV cache, 14 DGX Spark specs, 12 9r4n4y). Deterministic stdlib HTML→md conversion; content never read or printed (titles/byte counts only). |
| 7 | "Select some and do ranking tests to see any bug" | — | `scripts/test-v422-api.mjs`: 72/72 PASS on the 56-note database — BM25 ranking sanity (deepseek kv cache → DeepSeek pages, dgx spark specs → DGX pages, 9r4n4y → the user's notes, typo/fragment/phrase/coverage), red cross, warning, grep AND/substring, scopes, folder boundary, paging, saved searches, note lifecycle, image paths with spaces, GIF passthrough, health, settings. |
| 8 | "MCP must not have any dupe engine and must use our engine; AI can use one or two together and gets info what grep and BM both matched and in which BM didn't but grep does" | The MCP server was already a thin layer, but nothing PROVED the rankings matched, and the combined-evidence output didn't exist. | `search_notes` returns the same keyword evidence as the website. `scripts/test-v422-mcp.cjs`: 42/42 PASS incl. the one-engine assertion (MCP and webapp return the identical result order for the same query) and combined bm25+grep keyword_matches checks. |
| 9 | "MCP needs many configuration abilities (how many results, max results, specific tag data, anything)" | Only `page_size` existed. | `max_results` (alias of `page_size`) + `offset` paging + existing `tags`/`folders`/`scope`/`status`/dates/`limit_to`/`include_connected`; `get_tag_notes`/`list_tags` for tag data. MCP tests: max_results=4, page_size=2, offset=2 PASS. HTTP API also accepts both aliases now. |
| 10 | "Fix image crop — I want to crop free, select it, and the grid auto-adjusts without ugly spaces up/down" | No crop UI existed (server-side crop only); the grid mixed a spanned tile with short tiles in one row → vertical whitespace. | New `CropDialog`: drag ANY rectangle (free selection, dimmed overlay, live px readout), Replace (original backed up as `name.pre-crop-<stamp>`) or Keep both (crop inserted below, joining the grid). Grid: `auto-fill` tiles with equal 4:3 aspect, `dense` packing, size = k×k span (spans rows too, so no row ever mixes heights). Browser proof: full crop pipeline executed (draw → server crop → new file → markdown line → 6-tile grid); alignment check `aligned:true, drift:0`; VLM: "tiles align in neat rows … no ugly empty spaces; tight and well-organized". |
| 11 | "Images: when I add it says `![Snipaste_…](database/Recipes/Garlic Bread/attachments/….png)` but the image doesn't show" | The image regex `\(([^)\s]+)\)` rejected every path containing a SPACE — the line never parsed as an image at all. | All image/link regexes now match up to the closing paren; `resolveSrc` accepts raw spaces AND `%20`, resolves `attachments/…`, `Folder/Note/attachments/…`, `database/…`, URLs; hrefs percent-encode per segment. Browser proof: the exact user markdown renders (`imgCount:1`, `naturalWidth>0`); `/thumb` and `/files` serve the spaced path (200). |
| 12 | "Show image of most all formats, even GIF" | Thumbnails re-encoded EVERYTHING to static PNG (GIFs froze); avif/ico were refused. | GIFs bypass thumbnailing (original bytes served — animated); `.avif`/`.ico` accepted (decode failure falls back to serving the original); MIME map extended. Live proof: uploaded GIF → `/thumb` returns `image/gif`, original 435B (not a PNG). |
| 13 | "Buttons look plain ugly gradient, UI looks bad — choose good quality and taste" | The `hero` button variant was a `bg-gradient-to-r`; the home hero was two loud radial gradients. | Gradient variant retired: solid elevated primary with inset ring, pressed feedback (`active:scale`), softer outline hover, refined inputs/cards/focus rings; home hero is a flat card with a 3px primary accent line. VLM review: "clean and professional … flat card, thin accent, no heavy gradients … no visual glitches". |
| 14 | "Update SKILL.md, README and other files" | — | README (§4.2.2, tools, tests, version), SKILL.md (§6 + search tool doc), FIXES.md (this section), version bumped to 4.2.2 everywhere (Cargo.toml workspace, MCP serverInfo, banner). |
