//! SecondBrain local website (Rust, v4) — axum server.
//!
//! A thin layer over the core engine: one search engine serves the website
//! and the MCP server, so results are identical. The JSON API mirrors the
//! original Python server route-for-route, plus new v4 routes (settings,
//! manual log entries, edit history, undo journal).

use axum::body::Body;
use axum::extract::{Query, State};
use axum::http::{header, StatusCode, Uri};
use axum::response::{Response};
use axum::routing::{get, post};
use axum::Router;
use sbcore::{backup as bk, editlog, healthcheck, images, indexer, logger, parser, paths, search, store, tags as tags_mod, textutil::key_of, SbError};
use serde_json::{json, Value};
use std::collections::HashMap;
use std::path::{Path, PathBuf};

#[tokio::main]
async fn main() {
    let args: Vec<String> = std::env::args().collect();
    let mut port: Option<u16> = None;
    let mut bind: Option<String> = None;
    let mut no_browser = false;
    let mut rebuild = false;
    let mut it = args.iter().skip(1);
    while let Some(a) = it.next() {
        match a.as_str() {
            "--port" => port = it.next().and_then(|v| v.parse().ok()),
            "--bind" => bind = it.next().map(String::from),
            "--no-browser" => no_browser = true,
            "--rebuild" => rebuild = true,
            _ => {}
        }
    }

    let settings = store::load_settings();
    if rebuild {
        match indexer::rebuild_index() {
            Ok(idx) => println!("Index rebuilt: {} notes.", idx.n),
            Err(e) => eprintln!("Rebuild failed: {e}"),
        }
    }
    let port = port
        .or_else(|| settings.get("server_port").and_then(|v| v.as_u64()).map(|v| v as u16))
        .unwrap_or(8765);
    let bind = bind.unwrap_or_else(|| {
        settings
            .get("server_bind")
            .and_then(|v| v.as_str())
            .unwrap_or("127.0.0.1")
            .to_string()
    });

    let state = AppState { static_dir: paths::WEBSITE_DIR.join("static") };
    let app = Router::new()
        .route("/api/state", get(api_state))
        .route("/api/search", get(api_search))
        .route("/api/suggest", get(api_suggest))
        .route("/api/tags", get(api_tags))
        .route("/api/tag/notes", get(api_tag_notes))
        .route("/api/folders", get(api_folders))
        .route("/api/note", get(api_note))
        .route("/api/export", get(api_export))
        .route("/api/health", get(api_health))
        .route("/api/logs", get(api_logs))
        .route("/api/log", get(api_log))
        .route("/api/master_tags", get(api_master_tags))
        .route("/api/edit_history", get(api_edit_history))
        .route("/api/settings", get(api_settings_get).post(api_settings_post))
        .route("/api/journal", get(api_journal))
        .route("/api/note/create", post(api_note_create))
        .route("/api/note/save", post(api_note_save))
        .route("/api/note/move", post(api_note_move))
        .route("/api/note/delete", post(api_note_delete))
        .route("/api/note/append_my_notes", post(api_append_my_notes))
        .route("/api/note/toggle_task", post(api_toggle_task))
        .route("/api/note/tasks", post(api_note_tasks))
        .route("/api/folder/create", post(api_folder_create))
        .route("/api/folder/rename", post(api_folder_rename))
        .route("/api/folder/move", post(api_folder_move))
        .route("/api/folder/delete", post(api_folder_delete))
        .route("/api/tags/edit", post(api_tags_edit))
        .route("/api/tags/rename", post(api_tags_rename))
        .route("/api/tags/merge", post(api_tags_merge))
        .route("/api/tags/remove", post(api_tags_remove))
        .route("/api/tags/master", post(api_tags_master))
        .route("/api/tags/master/add", post(api_tags_master_add))
        .route("/api/quick_info", post(api_quick_info))
        .route("/api/metadata", post(api_metadata))
        .route("/api/pin", post(api_pin))
        .route("/api/health/fix", post(api_health_fix))
        .route("/api/connections", post(api_connections))
        .route("/api/references", post(api_references))
        .route("/api/links", post(api_links))
        .route("/api/image/add", post(api_image_add))
        .route("/api/image/crop", post(api_image_crop))
        .route("/api/image/delete", post(api_image_delete))
        .route("/api/undo", post(api_undo))
        .route("/api/log/create", post(api_log_create))
        .route("/api/saved_searches/save", post(api_saved_search_save))
        .route("/api/saved_searches/delete", post(api_saved_search_delete))
        .route("/api/backup/preview", post(api_backup_preview))
        .route("/api/backup/run", post(api_backup_run))
        .route("/api/backup/verify", post(api_backup_verify))
        .route("/api/index/rebuild", post(api_index_rebuild))
        .fallback(fallback_get)
        .with_state(state);

    let addr = format!("{bind}:{port}");
    let url = format!("http://{}:{}/", if bind == "127.0.0.1" { "localhost" } else { bind.as_str() }, port);
    println!("SecondBrain website (Rust v4.2.2) running at {url}  (local only, bind {bind})");
    println!("Press Ctrl+C to stop.");
    if !no_browser && settings.get("open_browser_on_start").and_then(|v| v.as_bool()).unwrap_or(true) {
        std::thread::spawn(move || {
            let _ = open::that(url);
        });
    }
    let listener = tokio::net::TcpListener::bind(&addr).await.expect("cannot bind port");
    axum::serve(listener, app).await.expect("server error");
}

#[derive(Clone)]
struct AppState {
    static_dir: PathBuf,
}

type Q = Query<HashMap<String, String>>;

fn json_response(v: Value, status: StatusCode) -> Response {
    let body = serde_json::to_string(&v).unwrap_or_else(|_| "{}".into());
    Response::builder()
        .status(status)
        .header(header::CONTENT_TYPE, "application/json; charset=utf-8")
        .header(header::CACHE_CONTROL, "no-store")
        .body(Body::from(body))
        .unwrap()
}

fn ok(v: Value) -> Response {
    json_response(v, StatusCode::OK)
}

fn err_response(e: &SbError) -> Response {
    let status = match e {
        SbError::NotFound(_) => StatusCode::NOT_FOUND,
        SbError::NeedsApproval { .. } => StatusCode::OK,
        _ => StatusCode::BAD_REQUEST,
    };
    let ty = match e {
        SbError::NotFound(_) => "FileNotFoundError",
        SbError::Exists(_) => "FileExistsError",
        SbError::Invalid(_) => "ValueError",
        SbError::Permission(_) => "PermissionError",
        SbError::NeedsApproval { .. } => "NeedsApproval",
        SbError::Io(_) => "IOError",
        SbError::Json(_) => "JSONError",
    };
    json_response(json!({"error": e.to_string(), "type": ty}), status)
}

async fn body_json(body: axum::body::Bytes) -> Value {
    if body.is_empty() {
        return json!({});
    }
    serde_json::from_slice(&body).unwrap_or_else(|_| json!({}))
}

fn mime_of(p: &Path) -> &'static str {
    match p.extension().and_then(|e| e.to_str()).unwrap_or("").to_lowercase().as_str() {
        "html" => "text/html",
        "css" => "text/css",
        "js" => "application/javascript",
        "json" => "application/json",
        "png" => "image/png",
        "jpg" | "jpeg" => "image/jpeg",
        "gif" => "image/gif",
        "webp" => "image/webp",
        "svg" => "image/svg+xml",
        "bmp" => "image/bmp",
        "avif" => "image/avif",
        "ico" => "image/x-icon",
        "woff" => "font/woff",
        "woff2" => "font/woff2",
        "ttf" => "font/ttf",
        "txt" => "text/plain",
        "map" => "application/json",
        _ => "application/octet-stream",
    }
}

fn serve_file(p: &Path, cache: bool) -> Response {
    if !p.exists() || !p.is_file() {
        return json_response(json!({"error": "not found"}), StatusCode::NOT_FOUND);
    }
    match std::fs::read(p) {
        Ok(data) => Response::builder()
            .status(StatusCode::OK)
            .header(header::CONTENT_TYPE, mime_of(p))
            .header(
                header::CACHE_CONTROL,
                if cache { "no-cache" } else { "no-store" },
            )
            .body(Body::from(data))
            .unwrap(),
        Err(_) => json_response(json!({"error": "not found"}), StatusCode::NOT_FOUND),
    }
}

fn note_view(md_path: &Path) -> Result<Value, SbError> {
    let rp = paths::rel(md_path);
    let text = std::fs::read_to_string(md_path)?;
    let doc = parser::parse_note(&text, &rp);
    let idx = indexer::load_index()?;
    let incoming = idx.backlinks.get(&rp).cloned().unwrap_or_default();
    let mut atts: Vec<String> = std::fs::read_dir(md_path.parent().unwrap().join("attachments"))
        .map(|rd| {
            rd.filter_map(|e| e.ok())
                .filter(|e| e.path().is_file())
                .filter_map(|e| e.file_name().into_string().ok())
                .collect()
        })
        .unwrap_or_default();
    atts.sort();
    let tags_file = md_path.parent().unwrap().join("tags.txt");
    let note_tags = if tags_file.exists() {
        tags_mod::parse_tags_txt(&std::fs::read_to_string(&tags_file)?)?
    } else {
        Vec::new()
    };
    let folder = md_path
        .parent()
        .and_then(|d| d.parent())
        .and_then(|d| d.strip_prefix(paths::DATABASE.as_path()).ok())
        .map(|d| d.to_string_lossy().replace('\\', "/"))
        .unwrap_or_default();
    Ok(json!({
        "path": rp,
        "folder": folder,
        "title": doc.title,
        "raw": doc.raw,
        "hash": store::text_sha256(&doc.raw),
        "quick_info_raw": doc.quick_info_raw,
        "quick_info_rows": doc.quick_info_rows.iter().map(|r| json!({
            "label": r.label, "value": r.value, "group": r.group,
        })).collect::<Vec<_>>(),
        "headings": doc.headings,
        "body": doc.body,
        "connected": doc.connected,
        "linked_in_text": doc.linked_in_text.iter().map(|(t, w)| json!({"target": t, "word": w})).collect::<Vec<_>>(),
        "references": doc.references,
        "meta": doc.meta,
        "my_notes": doc.my_notes,
        "incoming": incoming,
        "tags": note_tags,
        "tasks": store::note_tasks(&rp, None),
        "attachments": atts,
        "pinned": doc.meta.get("pinned").map(|v| v.to_lowercase() == "yes").unwrap_or(false),
    }))
}

fn resolve_note_path(path_or_name: &str) -> PathBuf {
    let p = store::note_md_path(path_or_name);
    if p.exists() {
        return p;
    }
    if let Some(found) = store::note_exists(path_or_name) {
        return found;
    }
    p
}

// --------------------------------------------------------------------------
// GET routes
// --------------------------------------------------------------------------

async fn api_state() -> Response {
    match indexer::load_index() {
        Ok(idx) => {
            let mut recent: Vec<(&String, &sbcore::indexer::NoteEntry)> =
                idx.files.iter().collect();
            recent.sort_by(|a, b| b.1.updated.cmp(&a.1.updated));
            let settings = store::load_settings();
            ok(json!({
                "notes": idx.n,
                "recent": recent.iter().take(8).map(|(rp, e)| json!({
                    "path": rp, "title": e.title, "folder": e.folder, "updated": e.updated,
                })).collect::<Vec<_>>(),
                "pinned": idx.files.iter().filter(|(_, e)| e.pinned).map(|(rp, e)| json!({
                    "path": rp, "title": e.title, "folder": e.folder,
                })).collect::<Vec<_>>(),
                "saved_searches": settings.get("saved_searches").cloned().unwrap_or(json!([])),
                "themes": [
                    "grey", "blue", "green", "plum", "crimson", "amber",
                    "sky", "sage", "rose", "sand", "lavender", "paper",
                ],
                "port": settings.get("server_port"),
                "bind": settings.get("server_bind"),
            }))
        }
        Err(e) => err_response(&e),
    }
}

async fn api_search(q: Q) -> Response {
    match indexer::load_index() {
        Ok(idx) => {
            let one = |k: &str, d: &str| q.get(k).cloned().unwrap_or_else(|| d.to_string());
            let many = |k: &str| -> Vec<String> {
                q.get(k)
                    .map(|v| v.split(',').map(String::from).collect())
                    .unwrap_or_default()
            };
            let tags_sel = many("tags");
            let folders_sel = many("folders");
            let grep_sel: Vec<String> = many("grep").into_iter().map(|s| s.trim().to_string()).filter(|s| !s.is_empty()).collect();
            let scope_sel: Vec<String> = {
                let sc = many("scope");
                if sc.is_empty() { vec!["everything".to_string()] } else { sc }
            };
            let limit_to = many("limit_to").into_iter().filter(|s| !s.is_empty()).collect::<Vec<_>>();
            // `page_size` and `max_results` both cap the result count (aliases)
            let limit: Option<usize> = ["page_size", "max_results"]
                .iter()
                .find_map(|k| q.get(*k).and_then(|v| v.parse::<usize>().ok()))
                .map(|v| v.max(1));
            let res = search::search(
                &idx,
                &one("q", ""),
                &grep_sel,
                &tags_sel,
                &folders_sel,
                one("folder_only", "0") == "1",
                &scope_sel,
                one("include_connected", "0") == "1",
                Some(one("status", "")).filter(|s| !s.is_empty()).as_deref(),
                Some(one("date_from", "")).filter(|s| !s.is_empty()).as_deref(),
                Some(one("date_to", "")).filter(|s| !s.is_empty()).as_deref(),
                &limit_to,
                one("offset", "0").parse().unwrap_or(0),
                limit,
            );
            ok(res)
        }
        Err(e) => err_response(&e),
    }
}

async fn api_suggest(q: Q) -> Response {
    let query = q.get("q").map(|s| s.as_str()).unwrap_or("");
    // accept both spellings; the UI says type, tools may say kind
    let kind = q
        .get("type")
        .or_else(|| q.get("kind"))
        .map(|s| s.as_str())
        .unwrap_or("all");
    match store::suggest(query, kind) {
        Ok(v) => ok(v),
        Err(e) => err_response(&e),
    }
}

async fn api_tags() -> Response {
    match (tags_mod::extract_all_notes_tags(), tags_mod::load_master()) {
        (Ok(ext), Ok(mt)) => {
            let majors: Vec<String> = {
                let mut v: Vec<String> = mt
                    .approved
                    .values()
                    .map(|t| t.major.clone())
                    .collect();
                v.sort();
                v.dedup();
                v
            };
            let tag_synonyms: serde_json::Map<String, Value> = mt
                .approved
                .iter()
                .map(|(k, v)| (k.clone(), json!(v.synonyms)))
                .collect();
            ok(json!({
                "tags": ext["tags"],
                "rows": ext["rows"],
                "counts": ext["counts"],
                "per_note": ext["per_note"],
                "unapproved": ext["unapproved"],
                "proposed": ext["proposed"],
                "near_duplicates": ext["near_duplicates"],
                "approved_unused": ext["approved_unused"],
                "majors": majors,
                "approved": mt.all_tags(),
                "tag_synonyms": tag_synonyms,
                "general_synonyms": mt.general_synonyms,
            }))
        }
        (Err(e), _) | (_, Err(e)) => err_response(&e),
    }
}

async fn api_tag_notes(q: Q) -> Response {
    let tag = q.get("tag").map(|s| s.as_str()).unwrap_or("");
    match indexer::load_index() {
        Ok(idx) => {
            let hits = idx.tag_map.get(&key_of(tag)).cloned().unwrap_or_default();
            ok(json!({
                "tag": tag,
                "notes": hits.iter().map(|rp| {
                    let e = &idx.files[rp];
                    json!({"path": rp, "title": e.title, "folder": e.folder, "tags": e.tags})
                }).collect::<Vec<_>>(),
            }))
        }
        Err(e) => err_response(&e),
    }
}

async fn api_folders() -> Response {
    ok(json!({
        "tree": store::folder_tree(),
        "subjects": store::list_subjects(),
    }))
}

async fn api_note(q: Q) -> Response {
    let path = q.get("path").map(|s| s.as_str()).unwrap_or("");
    if path.is_empty() {
        return json_response(json!({"error": "missing path"}), StatusCode::BAD_REQUEST);
    }
    let p = resolve_note_path(path);
    if !p.exists() {
        return json_response(
            json!({"error": format!("Note {path:?} not found.")}),
            StatusCode::NOT_FOUND,
        );
    }
    match note_view(&p) {
        Ok(v) => ok(v),
        Err(e) => err_response(&e),
    }
}

async fn api_export(q: Q) -> Response {
    let path = q.get("path").map(|s| s.as_str()).unwrap_or("");
    let p = resolve_note_path(path);
    if !p.exists() {
        return json_response(json!({"error": "not found"}), StatusCode::NOT_FOUND);
    }
    match store::export_metadata(&paths::rel(&p)) {
        Ok(text) => Response::builder()
            .status(StatusCode::OK)
            .header(header::CONTENT_TYPE, "text/plain; charset=utf-8")
            .header(
                header::CONTENT_DISPOSITION,
                format!(
                    "attachment; filename=\"{}.metadata.txt\"",
                    p.file_stem().and_then(|s| s.to_str()).unwrap_or("note")
                ),
            )
            .body(Body::from(text))
            .unwrap(),
        Err(e) => err_response(&e),
    }
}

async fn api_health() -> Response {
    match indexer::load_index() {
        Ok(idx) => ok(healthcheck::health_check(&idx)),
        Err(e) => err_response(&e),
    }
}

async fn api_logs(q: Q) -> Response {
    let limit: usize = q
        .get("limit")
        .and_then(|v| v.parse().ok())
        .unwrap_or(100);
    ok(json!({"logs": logger::list_logs(limit)}))
}

async fn api_log(q: Q) -> Response {
    let name = q.get("name").map(|s| s.as_str()).unwrap_or("");
    match logger::read_log(name) {
        Ok(text) => ok(json!({"name": name, "text": text})),
        Err(e) => err_response(&e),
    }
}

async fn api_master_tags() -> Response {
    match std::fs::read_to_string(paths::ROOT.join("_tags.md")) {
        Ok(text) => ok(json!({"text": text})),
        Err(e) => err_response(&SbError::Io(e.to_string())),
    }
}

async fn api_edit_history(q: Q) -> Response {
    let limit: usize = q
        .get("limit")
        .and_then(|v| v.parse().ok())
        .unwrap_or(100);
    ok(json!({"history": editlog::edit_history(limit)}))
}

async fn api_settings_get() -> Response {
    ok(json!({"settings": store::load_settings()}))
}

async fn api_journal() -> Response {
    ok(json!({"changes": editlog::list_changes(100)}))
}

// --------------------------------------------------------------------------
// POST routes
// --------------------------------------------------------------------------

async fn api_note_create(State(_): State<AppState>, body: axum::body::Bytes) -> Response {
    let b = body_json(body).await;
    let who = b.get("who").and_then(|v| v.as_str()).unwrap_or("user");
    let tags_opt: Option<Vec<String>> = b.get("tags").and_then(|v| v.as_array()).map(|a| {
        a.iter().filter_map(|x| x.as_str().map(|s| s.to_string())).collect::<Vec<String>>()
    });
    match store::create_note(
        b.get("folder").and_then(|v| v.as_str()).unwrap_or(""),
        b.get("name").and_then(|v| v.as_str()).unwrap_or(""),
        tags_opt.as_deref(),
        b.get("text").and_then(|v| v.as_str()),
        b.get("quick_info").and_then(|v| v.as_str()),
        who,
        b.get("reason").and_then(|v| v.as_str()).unwrap_or(""),
    ) {
        Ok(v) => ok(v),
        Err(e) => err_response(&e),
    }
}

async fn api_note_save(State(_): State<AppState>, body: axum::body::Bytes) -> Response {
    let b = body_json(body).await;
    let who = b.get("who").and_then(|v| v.as_str()).unwrap_or("user");
    match store::save_note_text(
        b.get("path").and_then(|v| v.as_str()).unwrap_or(""),
        b.get("text").and_then(|v| v.as_str()).unwrap_or(""),
        b.get("base_hash").and_then(|v| v.as_str()),
        who,
        b.get("force").and_then(|v| v.as_bool()).unwrap_or(false),
        b.get("reason").and_then(|v| v.as_str()).unwrap_or(""),
    ) {
        Ok(v) => ok(v),
        Err(e) => err_response(&e),
    }
}

async fn api_note_move(State(_): State<AppState>, body: axum::body::Bytes) -> Response {
    let b = body_json(body).await;
    let who = b.get("who").and_then(|v| v.as_str()).unwrap_or("user");
    match store::move_note(
        b.get("path").and_then(|v| v.as_str()).unwrap_or(""),
        b.get("folder").and_then(|v| v.as_str()).unwrap_or(""),
        b.get("name").and_then(|v| v.as_str()),
        who,
    ) {
        Ok(v) => ok(v),
        Err(e) => err_response(&e),
    }
}

async fn api_append_my_notes(State(_): State<AppState>, body: axum::body::Bytes) -> Response {
    let b = body_json(body).await;
    let who = b.get("who").and_then(|v| v.as_str()).unwrap_or("user");
    match store::append_to_my_notes(
        b.get("path").and_then(|v| v.as_str()).unwrap_or(""),
        b.get("text").and_then(|v| v.as_str()).unwrap_or(""),
        who,
        b.get("reason").and_then(|v| v.as_str()).unwrap_or(""),
    ) {
        Ok(v) => ok(v),
        Err(e) => err_response(&e),
    }
}

async fn api_toggle_task(State(_): State<AppState>, body: axum::body::Bytes) -> Response {
    let b = body_json(body).await;
    let who = b.get("who").and_then(|v| v.as_str()).unwrap_or("user");
    match store::toggle_task(
        b.get("path").and_then(|v| v.as_str()).unwrap_or(""),
        b.get("index").and_then(|v| v.as_i64()).unwrap_or(0).max(0) as usize,
        who,
        b.get("text").and_then(|v| v.as_str()),
    ) {
        Ok(v) => ok(v),
        Err(e) => err_response(&e),
    }
}

async fn api_note_tasks(State(_): State<AppState>, body: axum::body::Bytes) -> Response {
    let b = body_json(body).await;
    ok(json!({"tasks": store::note_tasks(
        b.get("path").and_then(|v| v.as_str()).unwrap_or(""),
        b.get("text").and_then(|v| v.as_str()),
    )}))
}

async fn api_folder_create(State(_): State<AppState>, body: axum::body::Bytes) -> Response {
    let b = body_json(body).await;
    let who = b.get("who").and_then(|v| v.as_str()).unwrap_or("user");
    match store::create_folder(
        b.get("parent").and_then(|v| v.as_str()).unwrap_or(""),
        b.get("name").and_then(|v| v.as_str()).unwrap_or(""),
        who,
        b.get("subject_md").and_then(|v| v.as_str()),
    ) {
        Ok(v) => ok(v),
        Err(e) => err_response(&e),
    }
}

async fn api_folder_rename(State(_): State<AppState>, body: axum::body::Bytes) -> Response {
    let b = body_json(body).await;
    let who = b.get("who").and_then(|v| v.as_str()).unwrap_or("user");
    match store::rename_folder(
        b.get("path").and_then(|v| v.as_str()).unwrap_or(""),
        b.get("name").and_then(|v| v.as_str()).unwrap_or(""),
        who,
    ) {
        Ok(v) => ok(v),
        Err(e) => err_response(&e),
    }
}

async fn api_folder_move(State(_): State<AppState>, body: axum::body::Bytes) -> Response {
    let b = body_json(body).await;
    let who = b.get("who").and_then(|v| v.as_str()).unwrap_or("user");
    match store::move_folder(
        b.get("path").and_then(|v| v.as_str()).unwrap_or(""),
        b.get("parent").and_then(|v| v.as_str()).unwrap_or(""),
        who,
    ) {
        Ok(v) => ok(v),
        Err(e) => err_response(&e),
    }
}

async fn api_note_delete(State(_): State<AppState>, body: axum::body::Bytes) -> Response {
    let b = body_json(body).await;
    let who = b.get("who").and_then(|v| v.as_str()).unwrap_or("user");
    match store::delete_note(
        b.get("path").and_then(|v| v.as_str()).unwrap_or(""),
        who,
    ) {
        Ok(v) => ok(v),
        Err(e) => err_response(&e),
    }
}

async fn api_folder_delete(State(_): State<AppState>, body: axum::body::Bytes) -> Response {
    let b = body_json(body).await;
    let who = b.get("who").and_then(|v| v.as_str()).unwrap_or("user");
    match store::delete_folder(b.get("path").and_then(|v| v.as_str()).unwrap_or(""), who) {
        Ok(v) => ok(v),
        Err(e) => err_response(&e),
    }
}

async fn api_tags_edit(State(_): State<AppState>, body: axum::body::Bytes) -> Response {
    let b = body_json(body).await;
    let who = b.get("who").and_then(|v| v.as_str()).unwrap_or("user");
    let arr = |k: &str| -> Option<Vec<String>> {
        b.get(k)
            .and_then(|v| v.as_array())
            .map(|a| a.iter().filter_map(|x| x.as_str().map(String::from)).collect())
    };
    match store::edit_tags(
        b.get("path").and_then(|v| v.as_str()).unwrap_or(""),
        arr("add"),
        arr("remove"),
        who,
    ) {
        Ok(v) => ok(v),
        Err(e) => err_response(&e),
    }
}

async fn api_tags_rename(State(_): State<AppState>, body: axum::body::Bytes) -> Response {
    let b = body_json(body).await;
    let who = b.get("who").and_then(|v| v.as_str()).unwrap_or("user");
    match store::rename_tag(
        b.get("from").and_then(|v| v.as_str()).unwrap_or(""),
        b.get("to").and_then(|v| v.as_str()).unwrap_or(""),
        who,
        b.get("run").and_then(|v| v.as_bool()).unwrap_or(false),
    ) {
        Ok(v) => ok(v),
        Err(e) => err_response(&e),
    }
}

async fn api_tags_merge(State(_): State<AppState>, body: axum::body::Bytes) -> Response {
    let b = body_json(body).await;
    let who = b.get("who").and_then(|v| v.as_str()).unwrap_or("user");
    match store::merge_tags(
        b.get("from").and_then(|v| v.as_str()).unwrap_or(""),
        b.get("into").and_then(|v| v.as_str()).unwrap_or(""),
        who,
        b.get("run").and_then(|v| v.as_bool()).unwrap_or(false),
    ) {
        Ok(v) => ok(v),
        Err(e) => err_response(&e),
    }
}

async fn api_tags_remove(State(_): State<AppState>, body: axum::body::Bytes) -> Response {
    let b = body_json(body).await;
    let who = b.get("who").and_then(|v| v.as_str()).unwrap_or("user");
    match store::remove_tag_everywhere(
        b.get("tag").and_then(|v| v.as_str()).unwrap_or(""),
        who,
        b.get("run").and_then(|v| v.as_bool()).unwrap_or(false),
    ) {
        Ok(v) => ok(v),
        Err(e) => err_response(&e),
    }
}

async fn api_tags_master(State(_): State<AppState>, body: axum::body::Bytes) -> Response {
    let b = body_json(body).await;
    let who = b.get("who").and_then(|v| v.as_str()).unwrap_or("user");
    match store::edit_master_tags(b.get("text").and_then(|v| v.as_str()).unwrap_or(""), who) {
        Ok(v) => ok(v),
        Err(e) => err_response(&e),
    }
}

async fn api_tags_master_add(State(_): State<AppState>, body: axum::body::Bytes) -> Response {
    let b = body_json(body).await;
    let who = b.get("who").and_then(|v| v.as_str()).unwrap_or("user");
    let tags: Vec<String> = b
        .get("tags")
        .and_then(|v| v.as_array())
        .map(|a| a.iter().filter_map(|x| x.as_str().map(String::from)).collect())
        .unwrap_or_default();
    match tags_mod::add_to_master(&tags, who) {
        Ok(added) => ok(json!({"ok": true, "added": added})),
        Err(e) => err_response(&e),
    }
}

async fn api_quick_info(State(_): State<AppState>, body: axum::body::Bytes) -> Response {
    let b = body_json(body).await;
    let who = b.get("who").and_then(|v| v.as_str()).unwrap_or("user");
    match store::set_quick_info(
        b.get("path").and_then(|v| v.as_str()).unwrap_or(""),
        b.get("text").and_then(|v| v.as_str()),
        who,
    ) {
        Ok(v) => ok(v),
        Err(e) => err_response(&e),
    }
}

async fn api_metadata(State(_): State<AppState>, body: axum::body::Bytes) -> Response {
    let b = body_json(body).await;
    let who = b.get("who").and_then(|v| v.as_str()).unwrap_or("user");
    match store::set_metadata(
        b.get("path").and_then(|v| v.as_str()).unwrap_or(""),
        b.get("meta").unwrap_or(&json!({})),
        who,
    ) {
        Ok(v) => ok(v),
        Err(e) => err_response(&e),
    }
}

async fn api_pin(State(_): State<AppState>, body: axum::body::Bytes) -> Response {
    let b = body_json(body).await;
    let who = b.get("who").and_then(|v| v.as_str()).unwrap_or("user");
    match store::toggle_pin(b.get("path").and_then(|v| v.as_str()).unwrap_or(""), who) {
        Ok(v) => ok(v),
        Err(e) => err_response(&e),
    }
}

async fn api_health_fix(State(_): State<AppState>, body: axum::body::Bytes) -> Response {
    let b = body_json(body).await;
    let who = b.get("who").and_then(|v| v.as_str()).unwrap_or("user");
    match healthcheck::health_fix(
        b.get("action").and_then(|v| v.as_str()).unwrap_or(""),
        b.get("params").unwrap_or(&json!({})),
        who,
    ) {
        Ok(v) => ok(v),
        Err(e) => err_response(&e),
    }
}

async fn api_connections(State(_): State<AppState>, body: axum::body::Bytes) -> Response {
    let b = body_json(body).await;
    let who = b.get("who").and_then(|v| v.as_str()).unwrap_or("user");
    let arr = |k: &str| -> Option<Vec<String>> {
        b.get(k)
            .and_then(|v| v.as_array())
            .map(|a| a.iter().filter_map(|x| x.as_str().map(String::from)).collect())
    };
    match store::edit_connections(
        b.get("path").and_then(|v| v.as_str()).unwrap_or(""),
        arr("add"),
        arr("remove"),
        b.get("edit_link"),
        who,
    ) {
        Ok(v) => ok(v),
        Err(e) => err_response(&e),
    }
}

async fn api_references(State(_): State<AppState>, body: axum::body::Bytes) -> Response {
    let b = body_json(body).await;
    let who = b.get("who").and_then(|v| v.as_str()).unwrap_or("user");
    match store::edit_references(
        b.get("path").and_then(|v| v.as_str()).unwrap_or(""),
        b.get("add"),
        b.get("remove_url").and_then(|v| v.as_str()),
        who,
    ) {
        Ok(v) => ok(v),
        Err(e) => err_response(&e),
    }
}

async fn api_links(State(_): State<AppState>, body: axum::body::Bytes) -> Response {
    let b = body_json(body).await;
    let who = b.get("who").and_then(|v| v.as_str()).unwrap_or("user");
    match store::edit_links(
        b.get("path").and_then(|v| v.as_str()).unwrap_or(""),
        b.get("word").and_then(|v| v.as_str()).unwrap_or(""),
        b.get("target").and_then(|v| v.as_str()),
        b.get("make_note").and_then(|v| v.as_bool()).unwrap_or(true),
        who,
    ) {
        Ok(v) => ok(v),
        Err(e) => err_response(&e),
    }
}

async fn api_image_add(State(_): State<AppState>, body: axum::body::Bytes) -> Response {
    let b = body_json(body).await;
    let who = b.get("who").and_then(|v| v.as_str()).unwrap_or("user");
    let data = b
        .get("data_base64")
        .and_then(|v| v.as_str())
        .and_then(|s| base64::Engine::decode(&base64::engine::general_purpose::STANDARD, s).ok());
    match data {
        Some(data) => match images::add_attachment(
            b.get("path").and_then(|v| v.as_str()).unwrap_or(""),
            b.get("filename").and_then(|v| v.as_str()).unwrap_or(""),
            &data,
            who,
        ) {
            Ok(v) => ok(v),
            Err(e) => err_response(&e),
        },
        None => json_response(json!({"error": "missing or invalid data_base64"}), StatusCode::BAD_REQUEST),
    }
}

async fn api_image_crop(State(_): State<AppState>, body: axum::body::Bytes) -> Response {
    let b = body_json(body).await;
    let who = b.get("who").and_then(|v| v.as_str()).unwrap_or("user");
    match images::crop_image(
        b.get("path").and_then(|v| v.as_str()).unwrap_or(""),
        b.get("filename").and_then(|v| v.as_str()).unwrap_or(""),
        b.get("rect").unwrap_or(&json!({})),
        b.get("mode").and_then(|v| v.as_str()).unwrap_or("keep_both"),
        who,
    ) {
        Ok(v) => ok(v),
        Err(e) => err_response(&e),
    }
}

async fn api_image_delete(State(_): State<AppState>, body: axum::body::Bytes) -> Response {
    let b = body_json(body).await;
    let who = b.get("who").and_then(|v| v.as_str()).unwrap_or("user");
    match images::delete_image(
        b.get("path").and_then(|v| v.as_str()).unwrap_or(""),
        b.get("filename").and_then(|v| v.as_str()).unwrap_or(""),
        who,
    ) {
        Ok(v) => ok(v),
        Err(e) => err_response(&e),
    }
}

async fn api_undo(State(_): State<AppState>, body: axum::body::Bytes) -> Response {
    let b = body_json(body).await;
    let who = b.get("who").and_then(|v| v.as_str()).unwrap_or("user");
    let change = b.get("change").and_then(|v| v.as_str()).unwrap_or("");
    match editlog::apply_undo(change, who) {
        Ok(report) => ok(json!({"log": report})),
        Err(e) => err_response(&e),
    }
}

async fn api_log_create(State(_): State<AppState>, body: axum::body::Bytes) -> Response {
    let b = body_json(body).await;
    let who = b.get("who").and_then(|v| v.as_str()).unwrap_or("user");
    let title = b.get("title").and_then(|v| v.as_str()).unwrap_or("Manual entry");
    let details = b.get("details").and_then(|v| v.as_str()).unwrap_or("");
    let name = logger::new_log(who, title, details);
    ok(json!({"ok": true, "file": name}))
}

async fn api_saved_search_save(State(_): State<AppState>, body: axum::body::Bytes) -> Response {
    let b = body_json(body).await;
    let who = b.get("who").and_then(|v| v.as_str()).unwrap_or("user");
    match store::save_search(
        b.get("name").and_then(|v| v.as_str()).unwrap_or(""),
        b.get("params").unwrap_or(&json!({})),
        who,
    ) {
        Ok(v) => ok(v),
        Err(e) => err_response(&e),
    }
}

async fn api_saved_search_delete(State(_): State<AppState>, body: axum::body::Bytes) -> Response {
    let b = body_json(body).await;
    match store::delete_saved_search(b.get("name").and_then(|v| v.as_str()).unwrap_or("")) {
        Ok(v) => ok(v),
        Err(e) => err_response(&e),
    }
}

fn backup_target_from_body(b: &Value) -> Result<PathBuf, SbError> {
    let to = b
        .get("to")
        .and_then(|v| v.as_str())
        .map(String::from)
        .or_else(|| {
            store::load_settings()
                .get("backup_destination")
                .and_then(|v| v.as_str())
                .map(String::from)
        })
        .ok_or_else(|| {
            SbError::Invalid(
                "No backup folder given. Pass 'to' (a folder OUTSIDE the project).".into(),
            )
        })?;
    bk::resolve_target(&to)
}

async fn api_backup_preview(State(_): State<AppState>, body: axum::body::Bytes) -> Response {
    let b = body_json(body).await;
    let direction = b.get("direction").and_then(|v| v.as_str()).unwrap_or("backup");
    let scope = b.get("scope").and_then(|v| v.as_str()).unwrap_or("whole");
    let target = match backup_target_from_body(&b) {
        Ok(t) => t,
        Err(e) => return err_response(&e),
    };
    let src_m = match bk::manifest(paths::ROOT.as_path(), scope) {
        Ok(m) => m,
        Err(e) => return err_response(&e),
    };
    let other_m = match bk::manifest(&target, scope) {
        Ok(m) => m,
        Err(e) => return err_response(&e),
    };
    let cmp = match direction {
        "restore" => bk::compare(&other_m, &src_m),
        _ => bk::compare(&src_m, &other_m),
    };
    ok(json!({"compare": cmp, "preview": bk::preview(&cmp)}))
}

async fn api_backup_run(State(_): State<AppState>, body: axum::body::Bytes) -> Response {
    let b = body_json(body).await;
    let who = b.get("who").and_then(|v| v.as_str()).unwrap_or("user");
    let target = match backup_target_from_body(&b) {
        Ok(t) => t,
        Err(e) => return err_response(&e),
    };
    let opts = bk::RunOptions {
        direction: b.get("direction").and_then(|v| v.as_str()).unwrap_or("backup"),
        target: &target,
        scope: b.get("scope").and_then(|v| v.as_str()).unwrap_or("whole"),
        keep: b.get("keep").and_then(|v| v.as_u64()).unwrap_or(10) as usize,
        who,
    };
    match bk::run(&opts) {
        Ok(v) => ok(v),
        Err(e) => err_response(&e),
    }
}

async fn api_backup_verify(State(_): State<AppState>, body: axum::body::Bytes) -> Response {
    let b = body_json(body).await;
    let target = match backup_target_from_body(&b) {
        Ok(t) => t,
        Err(e) => return err_response(&e),
    };
    match bk::verify(&target, b.get("scope").and_then(|v| v.as_str()).unwrap_or("whole")) {
        Ok(v) => ok(v),
        Err(e) => err_response(&e),
    }
}

async fn api_index_rebuild() -> Response {
    match indexer::rebuild_index() {
        Ok(idx) => ok(json!({"ok": true, "notes": idx.n})),
        Err(e) => err_response(&e),
    }
}

async fn api_settings_post(State(_): State<AppState>, body: axum::body::Bytes) -> Response {
    let b = body_json(body).await;
    let mut s = store::load_settings();
    if let Some(settings) = b.get("settings").and_then(|v| v.as_object()) {
        for (k, v) in settings {
            if let Some(obj) = s.as_object_mut() {
                obj.insert(k.clone(), v.clone());
            }
        }
    }
    match store::save_settings(&s) {
        Ok(_) => ok(json!({"ok": true, "settings": s})),
        Err(e) => err_response(&e),
    }
}

// --------------------------------------------------------------------------
// Static files + SPA fallback + /files/ + /thumb
// --------------------------------------------------------------------------

async fn fallback_get(State(state): State<AppState>, uri: Uri) -> Response {
    let route = urldecode(uri.path());
    if route == "/" || route == "/index.html" {
        return serve_file(&state.static_dir.join("index.html"), false);
    }
    if route == "/favicon.svg" {
        return serve_file(&state.static_dir.join("favicon.svg"), true);
    }
    if let Some(rest) = route.strip_prefix("/assets/") {
        let p = safe_static(&state.static_dir, &format!("assets/{rest}"));
        return match p {
            Some(p) => serve_file(&p, true),
            None => json_response(json!({"error": "forbidden"}), StatusCode::FORBIDDEN),
        };
    }
    if let Some(rest) = route.strip_prefix("/static/") {
        let p = safe_static(&state.static_dir, rest);
        return match p {
            Some(p) => serve_file(&p, true),
            None => json_response(json!({"error": "forbidden"}), StatusCode::FORBIDDEN),
        };
    }
    if let Some(rest) = route.strip_prefix("/files/") {
        // note attachments, addressed through the database (root-relative)
        return match safe_under_containing(paths::DATABASE.as_path(), rest) {
            Some(p) if p.is_file() => serve_file(&p, true),
            _ => json_response(json!({"error": "forbidden"}), StatusCode::FORBIDDEN),
        };
    }
    if route == "/thumb" {
        return thumb_endpoint(&uri);
    }
    // SPA fallback: any other path answers the app shell
    if !route.starts_with("/api/") {
        return serve_file(&state.static_dir.join("index.html"), false);
    }
    json_response(
        json!({"error": format!("Unknown route {route}")}),
        StatusCode::NOT_FOUND,
    )
}

fn safe_static(static_dir: &Path, rel: &str) -> Option<PathBuf> {
    let base = static_dir.canonicalize().ok()?;
    let p = static_dir.join(rel);
    let canon = p.canonicalize().ok()?;
    if canon.starts_with(&base) {
        Some(canon)
    } else {
        None
    }
}

/// `rel` may be root-relative (with a leading database/ segment) or
/// database-relative; resolve it and require the result to stay inside base.
fn safe_under_containing(base: &Path, rel: &str) -> Option<PathBuf> {
    let base_canon = base.canonicalize().ok()?;
    let candidates = [
        base.join(rel),
        base.join(rel.trim_start_matches("database/")),
        paths::ROOT.join(rel),
    ];
    for p in candidates {
        if let Ok(canon) = p.canonicalize() {
            if canon.starts_with(&base_canon) {
                return Some(canon);
            }
        }
    }
    None
}

fn thumb_endpoint(uri: &Uri) -> Response {
    let q: HashMap<String, String> = uri
        .query()
        .map(|v| {
            v.split('&')
                .filter_map(|kv| {
                    let mut it = kv.splitn(2, '=');
                    let k = urldecode(it.next()?);
                    let v = urldecode(it.next().unwrap_or(""));
                    Some((k, v))
                })
                .collect()
        })
        .unwrap_or_default();
    let rel = q.get("path").cloned().unwrap_or_default();
    let width: u32 = q.get("w").and_then(|v| v.parse().ok()).unwrap_or(480);
    let p = match safe_under_containing(paths::DATABASE.as_path(), &rel) {
        Some(p) if p.is_file() => p,
        _ => return json_response(json!({"error": "not found"}), StatusCode::NOT_FOUND),
    };
    let tp = images::thumbnail(&p, width);
    serve_file(&tp, true)
}

fn urldecode(s: &str) -> String {
    let mut out = Vec::new();
    let bytes = s.as_bytes();
    let mut i = 0;
    while i < bytes.len() {
        match bytes[i] {
            b'%' if i + 2 < bytes.len() => {
                if let Ok(v) = u8::from_str_radix(&s[i + 1..i + 3], 16) {
                    out.push(v);
                    i += 3;
                } else {
                    out.push(b'%');
                    i += 1;
                }
            }
            b'+' => {
                out.push(b' ');
                i += 1;
            }
            c => {
                out.push(c);
                i += 1;
            }
        }
    }
    String::from_utf8_lossy(&out).to_string()
}
