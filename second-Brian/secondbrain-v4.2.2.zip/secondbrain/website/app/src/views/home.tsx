import React, { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { FileText, Plus, Search, Pin, Clock, X, Sparkles } from "lucide-react";
import { toast } from "sonner";
import { api, noteHref } from "@/lib/api";
import type { AppState } from "@/lib/types";
import { Button, Card, CardContent, CardHeader, CardTitle, CardDescription, Input, Skeleton, Badge } from "@/components/ui/primitives";
import { Kbd } from "@/components/shared/kbd";

export default function Home() {
  const [state, setState] = useState<AppState | null>(null);
  const [q, setQ] = useState("");
  const nav = useNavigate();

  useEffect(() => {
    api.state().then(setState).catch((e) => toast.error(e.message));
  }, []);

  const stats = [
    { label: "Notes", value: state?.notes ?? "…" },
    { label: "Pinned", value: state?.pinned.length ?? "…" },
    { label: "Recent", value: state?.recent.length ?? "…" },
    { label: "Saved searches", value: state?.saved_searches.length ?? "…" },
  ];

  return (
    <div className="space-y-6">
      {/* hero — calm flat panel with a thin primary accent (v4.2.2) */}
      <section className="sb-hero animate-fade-up rounded-2xl border p-6 sm:p-10">
        <div className="mb-1 flex items-center gap-2 text-xs font-medium uppercase tracking-widest text-primary">
          <Sparkles className="h-3.5 w-3.5" /> Your second brain
        </div>
        <h1 className="text-2xl font-bold sm:text-3xl">
          What are you looking for <span className="sb-gradient-text">today?</span>
        </h1>
        <p className="mt-2 max-w-xl text-sm text-muted-foreground">
          BM25 ranks every word of every note; grep pins down exact keywords — nothing else in between.
        </p>
        <form
          className="mt-5 flex max-w-xl gap-2"
          onSubmit={(e) => {
            e.preventDefault();
            nav("/search?q=" + encodeURIComponent(q));
          }}
        >
          <Input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Search every word of every note, tag, heading and folder…"
            className="h-11 bg-card/70 text-base"
          />
          <Button type="submit" variant="hero" size="lg" className="shrink-0">
            <Search className="h-4 w-4" /> Search
          </Button>
        </form>
        <div className="mt-3 flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
          <span><Kbd>/</Kbd> search anywhere</span>
          <span>·</span>
          <span><Kbd>Ctrl</Kbd> <Kbd>K</Kbd> command palette</span>
          <span>·</span>
          <span>Press <Kbd>e</Kbd> on a note to edit</span>
        </div>
      </section>

      {/* stat cards */}
      <section className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        {stats.map((s) => (
          <Card key={s.label}>
            <CardContent className="p-4">
              <div className="text-2xl font-bold">{s.value}</div>
              <div className="text-xs text-muted-foreground">{s.label}</div>
            </CardContent>
          </Card>
        ))}
      </section>

      {/* quick actions */}
      <section className="grid gap-3 sm:grid-cols-3">
        <ActionCard to="/search" title="Search" desc="BM25 ranking with optional grep exact-match, scopes, tags and folders — every word of the full note is indexed." icon={Search} />
        <ActionCard to="/files" title="Browse files" desc="Open any folder, create notes and subjects right where you are." icon={FolderIcon} />
        <ActionCard to="/health" title="Health & logs" desc="Fault-isolated checks with one-click repairs, the manual log and the automatic edit history." icon={ShieldIcon} />
      </section>

      {/* saved searches */}
      {state && state.saved_searches.length > 0 && (
        <section>
          <h2 className="mb-2 text-sm font-semibold text-muted-foreground">Saved searches</h2>
          <div className="flex flex-wrap gap-2">
            {state.saved_searches.map((s) => (
              <Badge key={s.name} variant="outline" className="gap-1.5 py-1">
                <Link className="hover:underline" to={"/search?" + new URLSearchParams({ q: String((s.params as any)?.q ?? ""), ...(Array.isArray((s.params as any)?.grep) && (s.params as any).grep.length ? { grep: (s.params as any).grep.join(",") } : {}) }).toString()}>{s.name}</Link>
                <button
                  className="opacity-50 hover:opacity-100"
                  onClick={() =>
                    api.savedSearchDelete(s.name).then(() => api.state().then(setState))
                  }
                >
                  <X className="h-3 w-3" />
                </button>
              </Badge>
            ))}
          </div>
        </section>
      )}

      <div className="grid gap-5 lg:grid-cols-2">
        <section>
          <h2 className="mb-2 flex items-center gap-1.5 text-sm font-semibold text-muted-foreground">
            <Pin className="h-3.5 w-3.5" /> Pinned
          </h2>
          <div className="space-y-2">
            {state === null ? <Skeleton className="h-16" /> : state.pinned.length === 0 ? (
              <Empty text="Nothing pinned yet. Open a note and press the pin button." />
            ) : (
              state.pinned.map((n) => <NoteRow key={n.path} n={n} />)
            )}
          </div>
        </section>
        <section>
          <h2 className="mb-2 flex items-center gap-1.5 text-sm font-semibold text-muted-foreground">
            <Clock className="h-3.5 w-3.5" /> Recently updated
          </h2>
          <div className="space-y-2">
            {state === null ? <Skeleton className="h-16" /> : state.recent.length === 0 ? (
              <Empty text="No notes yet. Create your first note from the Files page." />
            ) : (
              state.recent.map((n) => <NoteRow key={n.path} n={n} />)
            )}
          </div>
        </section>
      </div>
    </div>
  );
}

function ActionCard({ to, title, desc, icon: Icon }: { to: string; title: string; desc: string; icon: React.ComponentType<any> }) {
  return (
    <Link to={to} className="group rounded-xl border bg-card p-5 shadow-sm transition-all hover:-translate-y-0.5 hover:shadow-md">
      <Icon className="mb-2 h-5 w-5 text-primary" />
      <div className="font-semibold group-hover:text-primary">{title}</div>
      <div className="mt-1 text-sm text-muted-foreground">{desc}</div>
    </Link>
  );
}

function NoteRow({ n }: { n: { path: string; title: string; folder: string; updated?: string } }) {
  return (
    <Link
      to={noteHref(n.path)}
      className="flex items-center gap-3 rounded-lg border bg-card px-3.5 py-2.5 shadow-sm transition-colors hover:border-primary/50"
    >
      <FileText className="h-4 w-4 shrink-0 text-primary" />
      <span className="min-w-0 flex-1 truncate text-sm font-medium">{n.title}</span>
      <span className="shrink-0 text-xs text-muted-foreground">{n.folder || "database"}</span>
    </Link>
  );
}

function Empty({ text }: { text: string }) {
  return <div className="rounded-lg border border-dashed p-4 text-sm text-muted-foreground">{text}</div>;
}

function FolderIcon(props: any) {
  return <FileText {...props} />;
}
function ShieldIcon(props: any) {
  return <Pin {...props} />;
}
