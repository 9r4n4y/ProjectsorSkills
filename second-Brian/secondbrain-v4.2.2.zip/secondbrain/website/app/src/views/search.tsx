import React, { useCallback, useEffect, useRef, useState } from "react";
import { Link, useSearchParams } from "react-router-dom";
import {
  Search, Save, X, Info, BookOpen, Terminal, Check, AlertTriangle, XCircle,
} from "lucide-react";
import { toast } from "sonner";
import { api, noteHref } from "@/lib/api";
import type { SearchResponse, SearchResult, KeywordStatus } from "@/lib/types";
import { Button, Card, CardContent, Input, Label, Badge, Skeleton, Separator } from "@/components/ui/primitives";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, Switch } from "@/components/ui/overlays";
import { SuggestInput } from "@/components/shared/suggest-input";
import { TagChip } from "@/components/shared/tag-badge";
import { cn } from "@/lib/utils";

const SCOPES = [
  { id: "everything", label: "Everything" },
  { id: "file name", label: "File name" },
  { id: "tags", label: "Tags" },
  { id: "headings", label: "Headings" },
  { id: "body", label: "Body" },
  { id: "folder path", label: "Folder path" },
];

export default function SearchView() {
  const [sp, setSp] = useSearchParams();
  const [q, setQ] = useState(sp.get("q") ?? "");
  const [grepOn, setGrepOn] = useState(sp.get("grep") !== null);
  const [grepWords, setGrepWords] = useState<string[]>((sp.get("grep") ?? "").split(",").map(s => s.trim()).filter(Boolean));
  const [grepInput, setGrepInput] = useState("");
  const [tags, setTags] = useState<string[]>((sp.get("tags") ?? "").split(",").filter(Boolean));
  const [folders, setFolders] = useState<string[]>((sp.get("folders") ?? "").split(",").filter(Boolean));
  const [folderOnly, setFolderOnly] = useState(sp.get("folder_only") === "1");
  const [scopes, setScopes] = useState<string[]>(["everything"]);
  const [dateFrom, setDateFrom] = useState(sp.get("date_from") ?? "");
  const [dateTo, setDateTo] = useState(sp.get("date_to") ?? "");
  const [res, setRes] = useState<SearchResponse | null>(null);
  const [busy, setBusy] = useState(false);
  const [showMore, setShowMore] = useState(false);
  const [helpOpen, setHelpOpen] = useState(false);
  const [saveOpen, setSaveOpen] = useState(false);
  const [saveName, setSaveName] = useState("");
  const offsetRef = useRef(0);

  const activeGrep = grepOn && grepWords.length > 0;
  const modeLabel = activeGrep && q.trim() ? "BM25 + grep" : activeGrep ? "grep only" : "BM25";

  const run = useCallback(
    (offset: number, append: boolean) => {
      setBusy(true);
      api
        .search({
          q,
          grep: activeGrep ? grepWords.join(",") : "",
          tags: tags.join(","),
          folders: folders.join(","),
          folder_only: folderOnly,
          scope: scopes.join(","),
          date_from: dateFrom,
          date_to: dateTo,
          offset,
        })
        .then((r) => {
          offsetRef.current = offset;
          setRes((prev) =>
            append && prev ? { ...r, results: [...prev.results, ...r.results] } : r
          );
          setShowMore(offset + 20 < r.total);
        })
        .catch((e) => toast.error(e.message))
        .finally(() => setBusy(false));
    },
    [q, activeGrep, grepWords, tags, folders, folderOnly, scopes, dateFrom, dateTo]
  );

  // search on mount (when a ?q= arrives) and when the query params change
  useEffect(() => {
    if (sp.get("q") !== null || sp.get("grep") !== null) {
      setQ(sp.get("q") ?? "");
      run(0, false);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [sp]);

  const submit = () => {
    const p: Record<string, string> = { q };
    if (activeGrep) p.grep = grepWords.join(",");
    setSp(p);
    run(0, false);
  };

  const toggleScope = (id: string) => {
    if (id === "everything") return setScopes(["everything"]);
    let next = scopes.filter((s) => s !== "everything");
    next = next.includes(id) ? next.filter((s) => s !== id) : [...next, id];
    setScopes(next.length ? next : ["everything"]);
  };

  const addGrepWord = () => {
    const v = grepInput.trim();
    if (v && !grepWords.some((w) => w.toLowerCase() === v.toLowerCase())) {
      setGrepWords([...grepWords, v]);
    }
    setGrepInput("");
  };

  return (
    <div className="space-y-5">
      <div className="flex items-center gap-2">
        <h1 className="text-xl font-bold">Search</h1>
        <Badge variant="outline" className="gap-1">
          <Terminal className="h-3 w-3" /> {modeLabel}
        </Badge>
        <Button variant="outline" size="sm" className="ml-auto" onClick={() => setHelpOpen(true)}>
          <BookOpen className="h-3.5 w-3.5" /> How to use
        </Button>
      </div>

      {/* query bar */}
      <form className="flex gap-2" onSubmit={(e) => { e.preventDefault(); submit(); }}>
        <div className="relative flex-1">
          <Search className="absolute left-3 top-2.5 h-4.5 w-4.5 text-muted-foreground" />
          <Input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder='BM25 ranks every word of every note — try "one pot" or pasta'
            className="h-11 pl-9 text-base"
          />
        </div>
        <Button type="submit" variant="hero" size="lg" disabled={busy}>Search</Button>
      </form>

      {/* 1 · grep — exact keywords */}
      <Card>
        <CardContent className="space-y-3 p-5">
          <div className="flex items-center justify-between gap-3">
            <div className="text-sm font-semibold">
              <span className="mr-2 rounded bg-primary/15 px-1.5 py-0.5 text-primary">1</span>
              Grep — keywords that must match 100%
            </div>
            <div className="flex items-center gap-2">
              <span className="text-xs text-muted-foreground">Use grep</span>
              <Switch checked={grepOn} onCheckedChange={setGrepOn} />
            </div>
          </div>
          {grepOn ? (
            <div className="space-y-2">
              <div className="flex gap-2">
                <Input
                  value={grepInput}
                  onChange={(e) => setGrepInput(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter") { e.preventDefault(); addGrepWord(); }
                  }}
                  placeholder="A keyword that MUST appear (Enter to add) — e.g. lentil, one pot"
                />
                <Button variant="outline" onClick={addGrepWord} disabled={!grepInput.trim()}>Add</Button>
              </div>
              {grepWords.length > 0 && (
                <div className="flex flex-wrap gap-1.5">
                  {grepWords.map((w) => (
                    <Badge key={w} variant="secondary" className="gap-1 py-1 font-mono">
                      {w}
                      <button onClick={() => setGrepWords(grepWords.filter((x) => x !== w))}><X className="h-3 w-3" /></button>
                    </Badge>
                  ))}
                </div>
              )}
              <p className="text-xs text-muted-foreground">
                Every keyword above must appear in the note <b>exactly as typed</b> (capitals ignored) —
                the note is out otherwise. Leave the query empty for grep-only results, or combine:
                grep narrows, <b>BM25 still decides the order</b>.
              </p>
            </div>
          ) : (
            <p className="text-xs text-muted-foreground">
              Optional. Grep is exact literal matching: a keyword either appears in the note (100% match)
              or the note is excluded. Turn it on only when you want words pinned down; otherwise pure BM25 ranking
              orders everything and excludes nothing.
            </p>
          )}
        </CardContent>
      </Card>

      {/* 2 · search in + narrow */}
      <Card>
        <CardContent className="space-y-4 p-5">
          <div className="text-sm font-semibold"><span className="mr-2 rounded bg-primary/15 px-1.5 py-0.5 text-primary">2</span> Search in & narrow</div>
          <div>
            <div className="mb-1.5 text-xs font-semibold uppercase tracking-wide text-muted-foreground">Search in</div>
            <div className="flex flex-wrap gap-1.5">
              {SCOPES.map((s) => (
                <button
                  key={s.id}
                  onClick={() => toggleScope(s.id)}
                  className={cn(
                    "rounded-full border px-3 py-1 text-xs transition-colors hover:bg-accent",
                    scopes.includes(s.id) ? "border-primary bg-primary/10 text-primary" : "text-muted-foreground"
                  )}
                >
                  {s.label}
                </button>
              ))}
            </div>
          </div>
          <Separator />
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-1.5">
              <Label>Tags (must be real tags — type to see them all)</Label>
              <SuggestInput
                value=""
                kind="tag"
                placeholder="Add a tag…"
                onSubmit={(v) => { if (v && !tags.includes(v)) setTags([...tags, v]); }}
              />
              <div className="flex flex-wrap gap-1.5">
                {tags.map((t) => (
                  <TagChip key={t} tag={t} onRemove={() => setTags(tags.filter((x) => x !== t))} />
                ))}
              </div>
            </div>
            <div className="space-y-1.5">
              <Label>Folders (hard boundary — sub-folders included)</Label>
              <SuggestInput
                value=""
                kind="folder"
                placeholder="Add a folder…"
                onSubmit={(v) => { if (v && !folders.includes(v)) setFolders([...folders, v]); }}
              />
              <div className="flex flex-wrap gap-1.5">
                {folders.map((f) => (
                  <Badge key={f} variant="secondary" className="gap-1 py-1">
                    {f}
                    <button onClick={() => setFolders(folders.filter((x) => x !== f))}><X className="h-3 w-3" /></button>
                  </Badge>
                ))}
                {folders.length > 0 && (
                  <label className="flex items-center gap-1.5 text-xs text-muted-foreground">
                    <input type="checkbox" checked={folderOnly} onChange={(e) => setFolderOnly(e.target.checked)} />
                    this folder only
                  </label>
                )}
              </div>
            </div>
          </div>
          <div className="grid gap-3 sm:grid-cols-2">
            <div className="space-y-1.5">
              <Label>Updated from</Label>
              <Input type="date" value={dateFrom} onChange={(e) => setDateFrom(e.target.value)} />
            </div>
            <div className="space-y-1.5">
              <Label>Updated to</Label>
              <Input type="date" value={dateTo} onChange={(e) => setDateTo(e.target.value)} />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* results */}
      {res === null && busy && <Skeleton className="h-40" />}
      {res && (
        <div className="space-y-3">
          <div className="flex flex-wrap items-center gap-2 text-sm text-muted-foreground">
            <span><b className="text-foreground">{res.total}</b> note{res.total === 1 ? "" : "s"} · {res.elapsed_ms} ms · {res.mode}</span>
            {res.query.query_tags.length > 0 && <span>tags detected: {res.query.query_tags.join(", ")}</span>}
            {res.query.grep.length > 0 && <span className="font-mono">grep: {res.query.grep.join(" · ")}</span>}
            <Button variant="outline" size="sm" className="ml-auto" onClick={() => setSaveOpen(true)}>
              <Save className="h-3.5 w-3.5" /> Save this search
            </Button>
          </div>

          {/* keyword rows: which engine matched which word */}
          {(res.query.keywords ?? []).length > 0 && <KeywordChips keywords={res.query.keywords} />}

          {/* BM25 missed a word but grep found it → amber warning */}
          {(res.warnings ?? []).map((w) => (
            <div key={w.word} className="flex items-start gap-2 rounded-lg border border-amber-500/40 bg-amber-500/10 p-3 text-sm">
              <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-amber-500" />
              <span>{w.message}</span>
            </div>
          ))}

          {/* words with no match anywhere → red cross notice */}
          {(res.no_word_match ?? []).length > 0 && (
            <div className="flex items-start gap-2 rounded-lg border border-destructive/40 bg-destructive/10 p-3 text-sm">
              <XCircle className="mt-0.5 h-4 w-4 shrink-0 text-destructive" />
              <span>
                No word match for{" "}
                {res.no_word_match.map((w) => (
                  <code key={w} className="mx-0.5 rounded bg-muted px-1.5 py-0.5 font-mono text-xs">{w}</code>
                ))}
                — neither BM25 nor grep found these words in any note (red ✗).
              </span>
            </div>
          )}

          {res.notice && (
            <div className="rounded-lg border border-amber-500/40 bg-amber-500/10 p-3 text-sm">{res.notice}</div>
          )}
          {res.results.length === 0 && !res.notice && (
            <div className="rounded-lg border border-dashed p-8 text-center text-sm text-muted-foreground">
              Nothing matched. Remove a grep keyword, a tag, or widen the folder boundary.
            </div>
          )}
          {res.results.map((r) =>
            "score" in r && r.score !== null ? (
              <ResultCard key={r.path} r={r as SearchResult} q={q} grepWords={res.query.grep} />
            ) : (
              <ConnectedExtra key={r.path} r={r as any} />
            )
          )}
          {showMore && (
            <Button variant="outline" className="w-full" onClick={() => run(offsetRef.current + 20, true)}>
              Show 20 more
            </Button>
          )}
        </div>
      )}

      {/* how to use */}
      <Dialog open={helpOpen} onOpenChange={setHelpOpen}>
        <DialogContent wide>
          <DialogHeader><DialogTitle>How to use search</DialogTitle></DialogHeader>
          <div className="space-y-2 text-sm text-muted-foreground">
            <p><b className="text-foreground">BM25 is the ranking algorithm.</b> Every note is scored over six fields — title, aliases, headings (incl. quick-info labels), body (incl. quick-info values), tags and folder path. Rarer words count more, longer notes are normalized, and a note matching more of your words outranks one matching a single word many times. The full text of every note is indexed — nothing hidden, nothing filtered by ranking.</p>
            <p><b className="text-foreground">Grep is the exact stage — your choice.</b> Turn it on and add keywords that must appear in the note <b>literally</b> (capitals ignored): every keyword must match (AND), or the note is out. Use BM25 alone, grep alone, or both — grep narrows the results, BM25 still ranks them.</p>
            <p><b className="text-foreground">Words</b> are lowercased, accents stripped, endings stemmed (recipe ≈ recipes), one wrong letter tolerated for words of 5+ letters, fragments catch their words (garl → garlic), and filler words (the, a, of…) are dropped — negations (no, not, without) are kept. Synonyms count 0.7: quick ≈ fast, dish ≈ meal.</p>
            <p><b className="text-foreground">"Quoted words"</b> are an exact phrase and get a relevance boost.</p>
            <p><b className="text-foreground">Search in</b> narrows the fields: file name, tags, headings, body, folder path — or everything (default).</p>
            <p><b className="text-foreground">Folders are a hard boundary</b>: with a folder selected the search never looks outside it (sub-folders included). Selected tags are filters — every note must carry all of them. Dates filter by last update.</p>
            <p><b className="text-foreground">Every result explains itself</b> — a plain-language reason plus the exact per-field BM25 bars below the score. Tunable in Settings: BM25 k1/b and the six field weights.</p>
          </div>
        </DialogContent>
      </Dialog>

      {/* save search */}
      <Dialog open={saveOpen} onOpenChange={setSaveOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle>Save this search</DialogTitle></DialogHeader>
          <Input value={saveName} onChange={(e) => setSaveName(e.target.value)} placeholder="Name, e.g. weeknight recipes" autoFocus />
          <DialogFooter>
            <Button variant="outline" onClick={() => setSaveOpen(false)}>Cancel</Button>
            <Button
              disabled={!saveName.trim()}
              onClick={() =>
                api.savedSearchSave(saveName.trim(), { q, grep: activeGrep ? grepWords : [], tags, folders, folder_only: folderOnly, scope: scopes, date_from: dateFrom, date_to: dateTo })
                  .then(() => { setSaveOpen(false); setSaveName(""); toast.success("Search saved — it appears on Home"); })
                  .catch((e) => toast.error(e.message))
              }
            >
              Save
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function ResultCard({ r, q, grepWords }: { r: SearchResult; q: string; grepWords: string[] }) {
  const [openWhy, setOpenWhy] = useState(false);
  const applied = Object.entries(r.breakdown ?? {}).filter(([, v]) => v.applied);
  const jump = [q, ...(grepWords ?? [])].filter(Boolean).join(" ");
  const grepOnly = (r.grep_only_words ?? []).length > 0;
  return (
    <Card className="transition-colors hover:border-primary/40">
      <CardContent className="p-4">
        <div className="flex items-start gap-3">
          <div className="min-w-0 flex-1">
            <div className="flex flex-wrap items-center gap-2">
              <Link to={noteHref(r.path, jump)} className="text-base font-semibold hover:text-primary">{r.title}</Link>
              {r.bm25_zero && (
                <Badge variant="outline" className="gap-1 border-amber-500/50 bg-amber-500/10 text-amber-600 dark:text-amber-400">
                  <AlertTriangle className="h-3 w-3" /> BM25 no word match — grep hit
                </Badge>
              )}
              {grepOnly && !r.bm25_zero && (
                <Badge variant="outline" className="gap-1 border-amber-500/50 bg-amber-500/10 text-amber-600 dark:text-amber-400">
                  <AlertTriangle className="h-3 w-3" /> grep-only: {r.grep_only_words.join(", ")}
                </Badge>
              )}
            </div>
            <div className="mt-0.5 flex flex-wrap items-center gap-1.5 text-xs text-muted-foreground">
              <span>{r.folder || "database"}</span>
              {r.updated && <span>· updated {r.updated}</span>}
              {r.pinned && <Badge variant="secondary">pinned</Badge>}
              {r.tags.slice(0, 4).map((t) => <Badge key={t} variant="outline">{t}</Badge>)}
            </div>
            <p className="mt-2 line-clamp-2 text-sm text-muted-foreground">{r.snippet}</p>
            {(r.grep_matches ?? []).length > 0 && (
              <div className="mt-1.5 flex flex-wrap gap-1.5">
                {r.grep_matches.map((m: { keyword: string; count: number }) => (
                  <Badge key={m.keyword} variant="outline" className="gap-1 font-mono text-[11px]">
                    <Terminal className="h-3 w-3" /> {m.keyword} ×{m.count}
                  </Badge>
                ))}
              </div>
            )}
          </div>
          <div className="shrink-0 text-right">
            <div className="text-2xl font-bold text-primary">{r.score}</div>
            <div className="text-[10px] uppercase tracking-wide text-muted-foreground">score</div>
          </div>
        </div>
        <div className="mt-2 flex items-center gap-2 text-xs text-muted-foreground">
          <Info className="h-3.5 w-3.5 shrink-0" />
          <span className="min-w-0 flex-1">{r.rank_reason}</span>
          <button className="shrink-0 underline hover:text-primary" onClick={() => setOpenWhy(!openWhy)}>
            Why this ranking
          </button>
        </div>
        {openWhy && (
          <div className="mt-3 space-y-1.5 rounded-lg border bg-muted/30 p-3">
            {(r.keyword_matches ?? []).length > 0 && (
              <div className="mb-2 flex flex-wrap gap-1.5 border-b border-border pb-2">
                {r.keyword_matches.map((k) => (
                  <span
                    key={k.word}
                    title={`${k.word}: ${k.bm25 ? "BM25 matched" : "BM25 no match"}${k.grep ? " · grep matched" : ""}`}
                    className={cn(
                      "inline-flex items-center gap-1 rounded-full border px-2 py-0.5 font-mono text-[11px]",
                      k.bm25 && k.grep && "border-emerald-500/40 bg-emerald-500/10 text-emerald-600 dark:text-emerald-400",
                      k.bm25 && !k.grep && "border-border bg-muted/50 text-foreground",
                      !k.bm25 && k.grep && "border-amber-500/50 bg-amber-500/10 text-amber-600 dark:text-amber-400",
                      !k.bm25 && !k.grep && "border-destructive/40 bg-destructive/10 text-destructive"
                    )}
                  >
                    {k.word}
                    {k.bm25 ? <Check className="h-3 w-3" /> : <XCircle className="h-3 w-3" />}
                    {k.grep && <span className="opacity-70">grep×{k.grep_count}</span>}
                  </span>
                ))}
              </div>
            )}
            {applied.map(([k, v]) => (
              <div key={k} className="flex items-center gap-2 text-xs">
                <span className="w-20 capitalize text-muted-foreground">{k}</span>
                <div className="h-2 flex-1 overflow-hidden rounded-full bg-muted">
                  <div className="h-full rounded-full bg-primary" style={{ width: `${Math.min(100, v.points * 100)}%` }} />
                </div>
                <span className="w-10 text-right tabular-nums">{v.points.toFixed(2)}</span>
                <span className="w-24 text-muted-foreground">weight {Math.round(v.weight * 100)}%</span>
              </div>
            ))}
            <div className="text-[11px] text-muted-foreground">
              coverage {r.coverage} · BM25 scores are normalized against the best match; fields that did not match show 0.
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

/* One chip per keyword (query words ∪ grep keywords).
   green ✓ both engines · plain ✓ BM25 · amber ⚠ grep-only · red ✗ no match */
function KeywordChips({ keywords }: { keywords: KeywordStatus[] }) {
  const mark = (k: KeywordStatus) => {
    switch (k.status) {
      case "both":
        return { cls: "border-emerald-500/40 bg-emerald-500/10 text-emerald-600 dark:text-emerald-400", icon: <Check className="h-3 w-3" />, title: `“${k.word}” matched by BM25 (df ${k.bm25_df}) and grep (${k.grep_notes} notes)` };
      case "bm25":
        return { cls: "border-border bg-muted/50 text-foreground", icon: <Check className="h-3 w-3" />, title: `“${k.word}” matched by BM25 (df ${k.bm25_df}) — word-level relevance` };
      case "grep":
        return { cls: "border-amber-500/50 bg-amber-500/10 text-amber-600 dark:text-amber-400", icon: <AlertTriangle className="h-3 w-3" />, title: `“${k.word}” has NO BM25 word match, but grep found it literally in ${k.grep_notes} note${k.grep_notes === 1 ? "" : "s"} — included in the ranking` };
      default:
        return { cls: "border-destructive/40 bg-destructive/10 text-destructive", icon: <XCircle className="h-3 w-3" />, title: `“${k.word}” — no word match in BM25 or grep (red cross)` };
    }
  };
  return (
    <div className="flex flex-wrap items-center gap-1.5">
      <span className="mr-1 text-xs font-semibold uppercase tracking-wide text-muted-foreground">keywords</span>
      {keywords.map((k) => {
        const m = mark(k);
        return (
          <span key={k.word + k.source} title={m.title}
            className={cn("inline-flex items-center gap-1 rounded-full border px-2.5 py-1 font-mono text-xs", m.cls)}>
            {k.word}
            {m.icon}
            {k.source === "grep" && <span className="opacity-70">grep</span>}
          </span>
        );
      })}
    </div>
  );
}

function ConnectedExtra({ r }: { r: SearchResult }) {
  return (
    <Card>
      <CardContent className="p-4">
        <div className="flex items-center gap-3">
          <Link to={noteHref(r.path)} className="font-medium hover:text-primary">{r.title}</Link>
          <Badge variant="outline">connected to a top result</Badge>
          <span className="ml-auto text-xs text-muted-foreground">{r.folder}</span>
        </div>
      </CardContent>
    </Card>
  );
}
