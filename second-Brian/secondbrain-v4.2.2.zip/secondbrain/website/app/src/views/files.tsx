import React, { useEffect, useState } from "react";
import { useNavigate, useSearchParams, Link } from "react-router-dom";
import { Folder, FileText, Plus, Lock, Pencil, MoveHorizontal, Trash2, ChevronRight } from "lucide-react";
import { toast } from "sonner";
import { api, noteHref } from "@/lib/api";
import type { FolderNode } from "@/lib/types";
import { Button, Card, Input, Label, Skeleton, Badge, Separator } from "@/components/ui/primitives";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription, AlertDialog, AlertDialogContent, AlertDialogTitle, AlertDialogDescription, AlertDialogCancel, AlertDialogAction, Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from "@/components/ui/overlays";
import { SuggestInput } from "@/components/shared/suggest-input";

export default function Files() {
  const [sp, setSp] = useSearchParams();
  const folder = sp.get("folder") ?? "";
  const [tree, setTree] = useState<FolderNode | null>(null);
  const nav = useNavigate();

  const reload = () => api.folders().then((d) => setTree(d.tree)).catch((e) => toast.error(e.message));
  useEffect(() => { reload(); }, [folder]);

  if (!tree) return <Skeleton className="h-64" />;

  const node = findFolder(tree, folder);

  const crumbs = folder ? folder.split("/") : [];

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center gap-2">
        <h1 className="text-xl font-bold">Files</h1>
        <div className="ml-auto flex gap-2">
          <NewNoteDialog folder={folder} onDone={() => reload()} />
          <NewFolderDialog parent={folder} onDone={() => reload()} />
        </div>
      </div>

      {/* breadcrumbs */}
      <div className="flex flex-wrap items-center gap-1 text-sm text-muted-foreground">
        <button className="hover:text-primary" onClick={() => setSp({})}>database</button>
        {crumbs.map((c, i) => (
          <React.Fragment key={i}>
            <ChevronRight className="h-3.5 w-3.5" />
            <button className="hover:text-primary" onClick={() => setSp({ folder: crumbs.slice(0, i + 1).join("/") })}>{c}</button>
          </React.Fragment>
        ))}
        {node && node.private && <Badge className="ml-1"><Lock className="mr-1 h-3 w-3" />private</Badge>}
      </div>

      {node && node.children.length === 0 && node.notes === 0 && (
        <div className="rounded-lg border border-dashed p-8 text-center text-sm text-muted-foreground">
          This folder is empty. Create a note or a sub-folder right here.
        </div>
      )}

      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
        {node?.children.map((c) => (
          <button
            key={c.path}
            className="flex items-center gap-3 rounded-xl border bg-card p-4 text-left shadow-sm transition-all hover:-translate-y-0.5 hover:border-primary/50"
            onClick={() => setSp({ folder: c.path })}
          >
            <Folder className="h-5 w-5 shrink-0 text-primary" />
            <span className="min-w-0 flex-1">
              <span className="block truncate font-medium">{c.name}</span>
              <span className="text-xs text-muted-foreground">{c.notes} note{c.notes === 1 ? "" : "s"}</span>
            </span>
            {c.private && <Lock className="h-3.5 w-3.5 text-muted-foreground" />}
          </button>
        ))}
      </div>

      {node && <FolderActions node={node} onChanged={reload} />}
    </div>
  );
}

function findFolder(root: FolderNode, path: string): FolderNode | null {
  if (!path) return root;
  for (const c of root.children) {
    if (c.path === path) return c;
    const hit = findFolder(c, path);
    if (hit) return hit;
  }
  return null;
}

function FolderActions({ node, onChanged }: { node: FolderNode; onChanged: () => void }) {
  const [renameOpen, setRenameOpen] = useState(false);
  const [moveOpen, setMoveOpen] = useState(false);
  const [delOpen, setDelOpen] = useState(false);
  const [name, setName] = useState(node.name);
  const [parent, setParent] = useState("");
  if (node.path === "") return null;

  return (
    <div className="flex flex-wrap gap-2 border-t pt-4">
      <Button variant="outline" size="sm" onClick={() => setRenameOpen(true)}><Pencil className="h-3.5 w-3.5" /> Rename folder</Button>
      <Button variant="outline" size="sm" onClick={() => setMoveOpen(true)}><MoveHorizontal className="h-3.5 w-3.5" /> Move folder</Button>
      <Button variant="outline" size="sm" className="text-destructive" onClick={() => setDelOpen(true)}><Trash2 className="h-3.5 w-3.5" /> Delete empty folder</Button>

      <Dialog open={renameOpen} onOpenChange={setRenameOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle>Rename “{node.name}”</DialogTitle></DialogHeader>
          <div className="space-y-2"><Label>New name</Label><Input value={name} onChange={(e) => setName(e.target.value)} /></div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setRenameOpen(false)}>Cancel</Button>
            <Button onClick={() =>
              api.folderRename(node.path, name).then(() => { setRenameOpen(false); onChanged(); toast.success("Folder renamed"); })
                .catch((e) => toast.error(e.message))
            }>Rename</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={moveOpen} onOpenChange={setMoveOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle>Move “{node.name}”</DialogTitle></DialogHeader>
          <div className="space-y-2">
            <Label>New parent folder (empty = database root)</Label>
            <SuggestInput value={parent} onChange={setParent} kind="folder" placeholder="e.g. Recipes" />
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setMoveOpen(false)}>Cancel</Button>
            <Button onClick={() =>
              api.folderMove(node.path, parent).then(() => { setMoveOpen(false); onChanged(); toast.success("Folder moved"); })
                .catch((e) => toast.error(e.message))
            }>Move</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <AlertDialog open={delOpen} onOpenChange={setDelOpen}>
        <AlertDialogContent>
          <AlertDialogTitle>Delete “{node.name}”?</AlertDialogTitle>
          <AlertDialogDescription>
            Only empty folders can be deleted. The folder must be empty; move its notes first.
          </AlertDialogDescription>
          <div className="flex justify-end gap-2">
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={() =>
              api.folderDelete(node.path).then(() => { setDelOpen(false); onChanged(); toast.success("Folder deleted"); })
                .catch((e) => toast.error(e.message))
            }>Delete</AlertDialogAction>
          </div>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

export function NewNoteDialog({ folder, onDone }: { folder: string; onDone?: () => void }) {
  const [open, setOpen] = useState(false);
  const [name, setName] = useState("");
  const nav = useNavigate();

  return (
    <>
      <Button size="sm" onClick={() => setOpen(true)}><Plus className="h-3.5 w-3.5" /> New note</Button>
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>New note</DialogTitle>
            <DialogDescription>
              Names are unique across the whole wiki and are the wiki links.
              {folder ? ` It is created in ${folder}.` : " It is created at the top of the database."}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-3">
            <div className="space-y-1.5">
              <Label>Note name</Label>
              <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g. Spanish Kitchen Words" autoFocus
                onKeyDown={(e) => {
                  if (e.key === "Enter" && name.trim()) {
                    submit();
                  }
                }} />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
            <Button onClick={submit} disabled={!name.trim()}>Create</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );

  function submit() {
    api
      .createNote(folder, name.trim(), [])
      .then((r) => {
        setOpen(false);
        setName("");
        toast.success("Note created");
        onDone?.();
        if (r.path) nav(noteHref(r.path));
      })
      .catch((e) => toast.error(e.message));
  }
}

function NewFolderDialog({ parent, onDone }: { parent: string; onDone?: () => void }) {
  const [open, setOpen] = useState(false);
  const [name, setName] = useState("");
  const [purpose, setPurpose] = useState("");
  return (
    <>
      <Button variant="outline" size="sm" onClick={() => setOpen(true)}><Plus className="h-3.5 w-3.5" /> New sub-folder</Button>
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>New sub-folder in “{parent || "database"}”</DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <div className="space-y-1.5">
              <Label>Folder name</Label>
              <Input value={name} onChange={(e) => setName(e.target.value)} autoFocus />
            </div>
            <div className="space-y-1.5">
              <Label>_subject.md purpose (optional)</Label>
              <Input value={purpose} onChange={(e) => setPurpose(e.target.value)} placeholder="Purpose: coffee and tea" />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
            <Button disabled={!name.trim()} onClick={() =>
              api.folderCreate(parent, name.trim(), purpose.trim() ? `Purpose: ${purpose.trim()}` : undefined)
                .then(() => { setOpen(false); setName(""); setPurpose(""); toast.success("Folder created"); onDone?.(); })
                .catch((e) => toast.error(e.message))
            }>Create</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
