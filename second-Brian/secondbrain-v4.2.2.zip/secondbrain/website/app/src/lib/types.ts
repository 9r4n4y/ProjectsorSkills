/* Shared API types (subset the UI relies on). */

export interface AppState {
  notes: number;
  recent: NoteRef[];
  pinned: NoteRef[];
  saved_searches: { name: string; params: Record<string, unknown> }[];
  themes: string[];
  port: number;
  bind: string;
}
export interface NoteRef {
  path: string;
  title: string;
  folder: string;
  updated?: string;
}
export interface Suggestion {
  type: "tag" | "folder" | "note";
  name: string;
  path?: string;
  folder?: string;
  count: number;
  starts: boolean;
}
export interface SearchSignal {
  weight: number;
  raw: number;
  scaled: number;
  points: number;
  applied: boolean;
}
export interface SearchResult {
  path: string;
  title: string;
  folder: string;
  tags: string[];
  status: string;
  updated: string;
  pinned: boolean;
  score: number;
  coverage: number;
  direct: boolean;
  connected_to: string | null;
  matched_groups: number;
  /** BM25 had zero word matches — this result is here only because grep
   *  found the keyword literally (amber warning sign in the UI). */
  bm25_zero: boolean;
  /** words that matched through grep but NOT through BM25 in this note */
  grep_only_words: string[];
  grep_matches: { keyword: string; count: number }[];
  /** per keyword (query words ∪ grep keywords): which engine matched here */
  keyword_matches: { word: string; source: string; bm25: boolean; grep: boolean; grep_count: number }[];
  rank_reason: string;
  breakdown: Record<string, SearchSignal>;
  snippet: string;
}
/** One row per query word / grep keyword: does BM25 know the word (df),
 *  does grep find it literally. status drives the UI mark:
 *  both → green check · bm25 → check · grep → amber warning · none → red ✗ */
export interface KeywordStatus {
  word: string;
  source: "query" | "phrase" | "grep";
  bm25_found: boolean;
  bm25_df: number;
  grep_found: boolean;
  grep_notes: number;
  status: "both" | "bm25" | "grep" | "none";
}
export interface SearchWarning {
  kind: string;
  word: string;
  grep_notes: number;
  message: string;
}
export interface SearchResponse {
  total: number;
  offset: number;
  results: SearchResult[];
  notice: string | null;
  removed_by: Record<string, number>;
  mode: string;
  query: {
    groups: string[];
    query_tags: string[];
    phrases: string[];
    grep: string[];
    keywords: KeywordStatus[];
  };
  /** BM25 missed a word that grep still found (amber sign) */
  warnings: SearchWarning[];
  /** words with NO match in either engine (red cross) */
  no_word_match: string[];
  elapsed_ms: number;
}
export interface Reference {
  title: string;
  url: string;
  accessed: string;
}
export interface QuickInfoRow {
  label: string;
  value: string;
  group: string | null;
}
export interface Task {
  index: number;
  done: boolean;
  text: string;
  line: number;
}
export interface NoteView {
  path: string;
  folder: string;
  title: string;
  raw: string;
  hash: string;
  quick_info_raw: string | null;
  quick_info_rows: QuickInfoRow[];
  headings: [number, string][];
  body: string;
  connected: string[];
  linked_in_text: { target: string; word: string }[];
  references: Reference[];
  meta: Record<string, string>;
  my_notes: string;
  incoming: string[];
  tags: string[];
  tasks: Task[];
  attachments: string[];
  pinned: boolean;
}
export interface FoldersData {
  tree: FolderNode;
  subjects: { path: string; name: string; private: boolean }[];
}
export interface FolderNode {
  name: string;
  path: string;
  notes: number;
  private: boolean;
  children: FolderNode[];
}
export interface TagsData {
  tags: string[];
  rows: { tag: string; count: number; depth: number }[];
  counts: Record<string, number>;
  per_note: Record<string, string[]>;
  unapproved: string[];
  proposed: string[];
  near_duplicates: { tags: string[] }[];
  approved_unused: string[];
  majors: string[];
  approved: string[];
  tag_synonyms: Record<string, string[]>;
  general_synonyms: Record<string, string[]>;
}
export interface HealthCheck {
  items: unknown[];
  error: string | null;
  fixable: boolean;
}
export interface HealthData {
  ok: boolean;
  summary: Record<string, number>;
  checks: Record<string, HealthCheck>;
  fix_hints: Record<string, string>;
}
export interface LogRow {
  file: string;
  date: string;
  who: string;
  title: string;
}
export interface EditHistoryRow {
  when: string;
  note: string;
  who: string;
  note_path?: string;
  lines_added?: string;
  lines_removed?: string;
}
export interface JournalRow {
  id: string;
  when: string;
  who: string;
  title: string;
  steps: number;
}
