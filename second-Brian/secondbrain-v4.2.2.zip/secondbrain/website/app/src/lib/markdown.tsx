/* The Markdown renderer (v4). Renders exactly the forms documented in
   StructureOFnotes.md and keeps the door open for interactive features:
   tappable checklists, wiki links, auto-https links, KaTeX math (bundled
   offline), footnotes, tables, and the multi-image grid with per-image
   position + size controls. */

import React, { useState } from "react";
import katex from "katex";
import "katex/dist/katex.min.css";
import {
  ArrowDown, ArrowLeft, ArrowRight, ArrowUp, Maximize2, Crop,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { thumbUrl } from "@/lib/api";

export interface RenderOpts {
  /** note rel path — used to resolve wiki links and image thumbs */
  notePath?: string;
  /** known wiki note titles (lowercase) for link resolution */
  wikiTitles?: Set<string>;
  /** toggle the Nth task checkbox (document order) */
  onToggleTask?: (index: number) => void;
  /** image grid operations: (groupIdx, imgIdx, action) */
  onImageOp?: (groupIdx: number, imgIdx: number, op: "left" | "right" | "up" | "down" | "size" | "crop") => void;
  /** open image full screen */
  onOpenImage?: (src: string, alt: string) => void;
  findQuery?: string;
  /** jump target: make the Nth find hit active */
  findActive?: number;
  onFindCount?: (n: number) => void;
}

let findCounter = 0;
export function resetFindCounter() {
  findCounter = 0;
}

/* ------------------------------ inline ------------------------------ */

function renderInline(text: string, opts: RenderOpts, keyBase: string): React.ReactNode[] {
  const out: React.ReactNode[] = [];
  let rest = text;
  let k = 0;
  const push = (node: React.ReactNode) => out.push(<React.Fragment key={`${keyBase}-${k++}`}>{node}</React.Fragment>);

  const patterns: [RegExp, (m: RegExpExecArray) => void][] = [
    // display math first, then inline math
    [/^\$\$([\s\S]+?)\$\$/, (m) => {
      push(<MathBlock tex={m[1]} display />);
    }],
    [/^\$([^$\n]+?)\$/, (m) => {
      push(<MathBlock tex={m[1]} display={false} />);
    }],
    [/^`([^`]+)`/, (m) => {
      push(<code>{m[1]}</code>);
    }],
    [/^\*\*\*([^*]+)\*\*\*/, (m) => {
      push(<strong><em>{renderInline(m[1], opts, keyBase + "b")}</em></strong>);
    }],
    [/^\*\*([^*]+)\*\*/, (m) => {
      push(<strong>{renderInline(m[1], opts, keyBase + "b")}</strong>);
    }],
    [/^__([^_]+)__/, (m) => {
      push(<strong>{renderInline(m[1], opts, keyBase + "b")}</strong>);
    }],
    [/^\*([^*\n]+)\*/, (m) => {
      push(<em>{renderInline(m[1], opts, keyBase + "i")}</em>);
    }],
    [/^_([^_\n]+)_/, (m) => {
      push(<em>{renderInline(m[1], opts, keyBase + "i")}</em>);
    }],
    [/^~~([^~]+)~~/, (m) => {
      push(<s>{renderInline(m[1], opts, keyBase + "s")}</s>);
    }],
    // wiki link with optional word: [[Name]] or [[Name|word]]
    [/^\[\[([^\]|]+)(?:\|([^\]]+))?\]\]/, (m) => {
      const target = m[1].trim();
      const word = (m[2] || target).trim();
      const exists = opts.wikiTitles?.has(target.toLowerCase()) ?? true;
      push(
        <a
          href={`/note?path=${encodeURIComponent(target)}`}
          className={cn("wiki-link", !exists && "wiki-missing")}
          title={exists ? `Open “${target}”` : `“${target}” does not exist yet`}
          onClick={(e) => {
            e.preventDefault();
            window.location.href = `/note?path=${encodeURIComponent(target)}`;
          }}
        >
          {word}
        </a>
      );
    }],
    // web link (auto-https for bare domains is handled at render here too)
    // paths may contain spaces ("Garlic Bread") — match up to the closing paren
    [/^\[([^\]]+)\]\(([^)]+)\)/, (m) => {
      let url = m[2].trim();
      if (url.startsWith("attachments/") || url.startsWith("database/")) {
        // link to a file in the database — resolve it the same way images are
        const resolved = resolveSrc(url, opts.notePath);
        push(<a href={`/files/${encodeFsPath(resolved)}`} target="_blank" rel="noreferrer">{m[1]}</a>);
        return;
      }
      if (!/^[a-zA-Z][a-zA-Z0-9+.-]*:\/\//.test(url) && !url.startsWith("#") && !url.startsWith("/")) {
        url = "https://" + url;
      }
      push(<a href={url} target="_blank" rel="noreferrer">{m[1]}</a>);
    }],
    [/^!\[([^\]]*)\]\(([^)]+)\)/, (m) => {
      // an image written inside a sentence renders inline (click to enlarge)
      const resolved = resolveSrc(m[2].trim(), opts.notePath);
      push(
        <img
          src={thumbUrl(resolved, 640)}
          alt={m[1]}
          loading="lazy"
          className="sb-img-inline"
          onClick={() => opts.onOpenImage?.(resolved, m[1])}
        />
      );
    }],
    // footnote reference
    [/^\[\^([^\]]+)\]/, (m) => {
      push(<sup id={`fnref-${m[1]}`} className="text-primary"><a href={`#fn-${m[1]}`}>[{m[1]}]</a></sup>);
    }],
  ];

  while (rest.length > 0) {
    let matched = false;
    for (const [re, fn] of patterns) {
      const m = re.exec(rest);
      if (m) {
        fn(m);
        rest = rest.slice(m[0].length);
        matched = true;
        break;
      }
    }
    if (!matched) {
      // consume plain text up to the next special char
      const next = rest.slice(1).search(/[$`*_[~\[\]]!/);
      const take = next === -1 ? rest.length : next + 1;
      let plain = rest.slice(0, take);
      rest = rest.slice(take);
      if (opts.findQuery) {
        push(<FindHighlight text={plain} query={opts.findQuery} active={opts.findActive} />);
      } else {
        push(plain);
      }
    }
  }
  return out;
}

function FindHighlight({ text, query, active }: { text: string; query: string; active?: number }) {
  if (!query) return <>{text}</>;
  const lower = text.toLowerCase();
  const q = query.toLowerCase().trim();
  // The full phrase is tried first; when it is not in this chunk, the longest
  // word of a multi-word query still gets marked, so landing from a search
  // result works even when the words sit in different paragraphs.
  let target = "";
  if (q && lower.includes(q)) {
    target = q;
  } else {
    const words = q.split(/\s+/).filter((w) => w.length >= 3);
    words.sort((a, b) => b.length - a.length);
    target = words.find((w) => lower.includes(w)) ?? "";
  }
  if (!target) return <>{text}</>;
  const parts: React.ReactNode[] = [];
  let i = 0;
  let idx: number;
  let kk = 0;
  while ((idx = lower.indexOf(target, i)) !== -1) {
    const isActive = active !== undefined && active === findCounter;
    if (idx > i) parts.push(<span key={kk++}>{text.slice(i, idx)}</span>);
    parts.push(
      <mark key={kk++} className={isActive ? "sb-find active" : "sb-find"} data-find-hit={findCounter}>
        {text.slice(idx, idx + target.length)}
      </mark>
    );
    findCounter++;
    i = idx + target.length;
  }
  if (i < text.length) parts.push(<span key={kk++}>{text.slice(i)}</span>);
  return <>{parts}</>;
}

function MathBlock({ tex, display }: { tex: string; display: boolean }) {
  let html = "";
  try {
    html = katex.renderToString(tex.trim(), { displayMode: display, throwOnError: false, output: "html" });
  } catch {
    html = `<code>${tex}</code>`;
  }
  return display
    ? <span className="katex-display block my-4 overflow-x-auto" dangerouslySetInnerHTML={{ __html: html }} />
    : <span className="katex" dangerouslySetInnerHTML={{ __html: html }} />;
}

/* ------------------------------ images ------------------------------ */

export interface ImageInfo {
  alt: string;
  src: string;
  width: string | null; // e.g. "60"
  rawLine: string;
}

/** Resolve an image path written in a note to the LOGICAL database path
 *  (spaces kept as real spaces — encode with `encodeFsPath` only when the
 *  path becomes part of a URL). Accepts every way a person might write it —
 *  INCLUDING paths with spaces ("database/Recipes/Garlic Bread/…"), which
 *  the v4.2.2 parser now matches (the old `[^)\s]+` regex rejected every
 *  spaced path and the image silently did not render):
 *   - attachments/photo.png        (relative to the note's own folder)
 *   - Recipes/Note/attachments/photo.png (database-relative)
 *   - database/Recipes/.../attachments/photo.png (root-relative)
 *   - https://… external URLs pass through untouched. */
export function resolveSrc(src: string, notePath?: string): string {
  let s = src.trim();
  // accept pre-encoded paths too: decode %20 so the logical path is canonical
  s = s.replace(/%20/gi, " ");
  if (/^[a-zA-Z][a-zA-Z0-9+.-]*:\/\//.test(s) || s.startsWith("/")) return s;
  if (s.startsWith("database/")) s = s.slice("database/".length);
  else if (s.startsWith("attachments/")) {
    const folder = (notePath ?? "").replace(/\/[^/]+$/, "");
    s = folder ? `${folder}/${s}` : s;
  }
  return s;
}

/** Percent-encode a logical path per segment for direct URL use (/files/…). */
export function encodeFsPath(rel: string): string {
  return rel.split("/").map(encodeURIComponent).join("/");
}

function parseImageLine(line: string): ImageInfo | null {
  // spaces are legal in the path ("Garlic Bread") — match up to the `)`
  const m = /^!\[([^\]]*)\]\(([^)]+)\)\s*$/.exec(line.trim());
  if (!m) return null;
  let alt = m[1];
  let src = m[2].trim();
  let width: string | null = null;
  const wm = /^(.*)\|(\d{1,3})%?$/.exec(alt);
  if (wm) {
    alt = wm[1];
    width = wm[2];
  }
  return { alt, src, width, rawLine: line.trim() };
}

function ImageGrid({
  images,
  groupIdx,
  opts,
}: {
  images: ImageInfo[];
  groupIdx: number;
  opts: RenderOpts;
}) {
  const many = images.length > 1;
  // one image keeps its natural size (constrained by the size % / page width)
  if (!many) {
    const img = images[0];
    const resolved = resolveSrc(img.src, opts.notePath);
    return (
      <div className="sb-img-grid sb-img-single" data-img-group={groupIdx}>
        <div className="sb-img-cell" style={img.width ? { width: `${img.width}%` } : undefined}>
          <img
            src={thumbUrl(resolved, 960)}
            alt={img.alt}
            loading="lazy"
            onClick={() => opts.onOpenImage?.(resolved, img.alt)}
          />
          {opts.onImageOp && (
            <div className="sb-img-controls">
              <button title="Change size" onClick={(e) => { e.stopPropagation(); opts.onImageOp!(groupIdx, 0, "size"); }}><Maximize2 /></button>
              <button title="Crop freely" onClick={(e) => { e.stopPropagation(); opts.onImageOp!(groupIdx, 0, "crop"); }}><Crop /></button>
            </div>
          )}
          {img.alt && <div className="mt-1 text-center text-xs text-muted-foreground">{img.alt}</div>}
        </div>
      </div>
    );
  }
  // several images: an auto-adjusting, gap-free tile grid. Columns adapt to
  // the container width and the image count; every tile has the same aspect
  // ratio so all rows line up perfectly — no up/down drift, no holes (`dense`
  // fills gaps). The size control becomes a k×k tile span (2 tiles wide AND
  // 2 rows tall, so a big tile never stretches a row it shares with small
  // tiles — that was the "up and down" misalignment); 100% spans the full row.
  const spanOf = (w: string | null): number => {
    const n = parseInt(w ?? "", 10);
    if (!n || Number.isNaN(n)) return 1;
    if (n <= 25) return 1;
    if (n <= 50) return 2;
    if (n <= 75) return 3;
    return -1; // full row
  };
  return (
    <div className="sb-img-grid sb-img-tiles" data-img-group={groupIdx}>
      {images.map((img, i) => {
        const span = spanOf(img.width);
        const resolved = resolveSrc(img.src, opts.notePath);
        const spanStyle: React.CSSProperties | undefined =
          span === -1
            ? { gridColumn: "1 / -1" }
            : span > 1
              ? { gridColumn: `span ${span} / span ${span}`, gridRow: `span ${span} / span ${span}` }
              : undefined;
        return (
          <div className="sb-img-cell" key={i} style={spanStyle}>
            <img
              src={thumbUrl(resolved, 640)}
              alt={img.alt}
              loading="lazy"
              onClick={() => opts.onOpenImage?.(resolved, img.alt)}
            />
            {opts.onImageOp && (
              <div className="sb-img-controls">
                <button title="Move left" onClick={(e) => { e.stopPropagation(); opts.onImageOp!(groupIdx, i, "left"); }}><ArrowLeft /></button>
                <button title="Move right" onClick={(e) => { e.stopPropagation(); opts.onImageOp!(groupIdx, i, "right"); }}><ArrowRight /></button>
                <button title="Move up" onClick={(e) => { e.stopPropagation(); opts.onImageOp!(groupIdx, i, "up"); }}><ArrowUp /></button>
                <button title="Move down" onClick={(e) => { e.stopPropagation(); opts.onImageOp!(groupIdx, i, "down"); }}><ArrowDown /></button>
                <button title="Change size (tile span)" onClick={(e) => { e.stopPropagation(); opts.onImageOp!(groupIdx, i, "size"); }}><Maximize2 /></button>
                <button title="Crop freely" onClick={(e) => { e.stopPropagation(); opts.onImageOp!(groupIdx, i, "crop"); }}><Crop /></button>
              </div>
            )}
            {img.alt && <div className="sb-tile-caption">{img.alt}</div>}
          </div>
        );
      })}
    </div>
  );
}

/* ------------------------------ blocks ------------------------------ */

type Block =
  | { kind: "heading"; level: number; text: string; id: string }
  | { kind: "paragraph"; text: string }
  | { kind: "code"; lang: string; text: string }
  | { kind: "quote"; lines: string[] }
  | { kind: "list"; ordered: boolean; items: ListItem[] }
  | { kind: "table"; header: string[]; rows: string[][] }
  | { kind: "hr" }
  | { kind: "images"; images: ImageInfo[] }
  | { kind: "footnoteDefs"; defs: { id: string; text: string }[] };

interface ListItem {
  text: string;
  task: boolean;
  done: boolean;
  taskIndex: number | null;
  depth: number;
}

function slug(t: string): string {
  return t.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "");
}

export function parseBlocks(text: string): Block[] {
  const lines = text.split("\n");
  const blocks: Block[] = [];
  let i = 0;
  let taskCounter = 0;
  const footnoteDefs: { id: string; text: string }[] = [];

  const flushImages = (buf: ImageInfo[]) => {
    if (buf.length > 0) blocks.push({ kind: "images", images: buf });
  };
  let imgBuf: ImageInfo[] = [];

  while (i < lines.length) {
    const line = lines[i];
    const trimmed = line.trim();

    // image lines collect into a buffer (consecutive image lines, blank
    // lines between them allowed) — the v4 image grid
    const img = parseImageLine(line);
    if (img) {
      imgBuf.push(img);
      i++;
      continue;
    }
    if (trimmed === "" && imgBuf.length > 0) {
      // peek: if the next non-empty line is also an image, keep the group open
      let j = i + 1;
      while (j < lines.length && lines[j].trim() === "") j++;
      if (j < lines.length && parseImageLine(lines[j])) {
        i++;
        continue;
      }
      flushImages(imgBuf);
      imgBuf = [];
      i++;
      continue;
    }
    flushImages(imgBuf);
    imgBuf = [];

    if (trimmed === "") {
      i++;
      continue;
    }

    // fenced code
    if (trimmed.startsWith("```")) {
      const lang = trimmed.slice(3).trim();
      const body: string[] = [];
      i++;
      while (i < lines.length && !lines[i].trim().startsWith("```")) {
        body.push(lines[i]);
        i++;
      }
      i++; // closing fence
      blocks.push({ kind: "code", lang, text: body.join("\n") });
      continue;
    }

    // hr
    if (/^(-{3,}|\*{3,}|_{3,})$/.test(trimmed)) {
      blocks.push({ kind: "hr" });
      i++;
      continue;
    }

    // heading
    const hm = /^(#{1,6})\s+(.*?)\s*#*\s*$/.exec(line);
    if (hm) {
      const level = hm[1].length;
      blocks.push({ kind: "heading", level, text: hm[2], id: slug(hm[2]) });
      i++;
      continue;
    }

    // blockquote
    if (trimmed.startsWith(">")) {
      const body: string[] = [];
      while (i < lines.length && lines[i].trim().startsWith(">")) {
        body.push(lines[i].trim().replace(/^>\s?/, ""));
        i++;
      }
      blocks.push({ kind: "quote", lines: body });
      continue;
    }

    // table
    if (trimmed.startsWith("|") && i + 1 < lines.length && /^\s*\|?[\s:|-]+\|[\s:|-]*$/.test(lines[i + 1])) {
      const splitRow = (l: string): string[] =>
        l.trim().replace(/^\||\|$/g, "").split("|").map((c) => c.trim());
      const header = splitRow(lines[i]);
      i += 2;
      const rows: string[][] = [];
      while (i < lines.length && lines[i].trim().startsWith("|")) {
        rows.push(splitRow(lines[i]));
        i++;
      }
      blocks.push({ kind: "table", header, rows });
      continue;
    }

    // lists (ordered / bullet / task)
    const isUl = /^(\s*)[-*]\s+(.*)$/.exec(line);
    const isOl = /^(\s*)\d+[.)]\s+(.*)$/.exec(line);
    if (isUl || isOl) {
      const ordered = isOl !== null;
      const items: ListItem[] = [];
      while (i < lines.length) {
        const m = /^(\s*)([-*]|\d+[.)])\s+(.*)$/.exec(lines[i]);
        if (!m) break;
        const depth = Math.floor(m[1].replace(/\t/g, "  ").length / 2);
        let text = m[3];
        let task = false;
        let done = false;
        let taskIndex: number | null = null;
        const tm = /^\[([ xX])\]\s+(.*)$/.exec(text);
        if (tm) {
          task = true;
          done = tm[1].toLowerCase() === "x";
          text = tm[2];
          taskIndex = taskCounter++;
        }
        items.push({ text, task, done, taskIndex, depth });
        i++;
      }
      blocks.push({ kind: "list", ordered, items });
      continue;
    }

    // footnote definition
    const fn = /^\[\^([^\]]+)\]:\s*(.*)$/.exec(trimmed);
    if (fn) {
      footnoteDefs.push({ id: fn[1], text: fn[2] });
      i++;
      continue;
    }

    // paragraph: gather until blank line or a new block start
    const para: string[] = [line];
    i++;
    while (
      i < lines.length &&
      lines[i].trim() !== "" &&
      !/^(#{1,6})\s/.test(lines[i]) &&
      !lines[i].trim().startsWith("```") &&
      !lines[i].trim().startsWith(">") &&
      !lines[i].trim().startsWith("|") &&
      !/^(\s*[-*]\s|\s*\d+[.)]\s)/.test(lines[i]) &&
      !parseImageLine(lines[i]) &&
      !/^(-{3,}|\*{3,}|_{3,})$/.test(lines[i].trim())
    ) {
      para.push(lines[i]);
      i++;
    }
    blocks.push({ kind: "paragraph", text: para.join("\n") });
  }
  flushImages(imgBuf);
  if (footnoteDefs.length > 0) blocks.push({ kind: "footnoteDefs", defs: footnoteDefs });
  return blocks;
}

export function MarkdownBody({
  text,
  opts,
  className,
}: {
  text: string;
  opts: RenderOpts;
  className?: string;
}) {
  const blocks = parseBlocks(text);
  return (
    <div className={cn("sb-prose", className)}>
      {blocks.map((b, bi) => {
        switch (b.kind) {
          case "heading": {
            const Tag = (`h${Math.min(6, Math.max(2, b.level))}`) as keyof React.JSX.IntrinsicElements;
            return (
              <Tag key={bi} id={b.id}>
                {renderInline(b.text, opts, `h${bi}`)}
              </Tag>
            );
          }
          case "paragraph":
            return <p key={bi}>{renderInline(b.text, opts, `p${bi}`)}</p>;
          case "code":
            return (
              <pre key={bi}>
                <code>{b.text}</code>
              </pre>
            );
          case "quote":
            return (
              <blockquote key={bi}>
                {b.lines.map((l, li) => (
                  <p key={li} className="my-1 first:mt-0 last:mb-0">
                    {renderInline(l, opts, `q${bi}-${li}`)}
                  </p>
                ))}
              </blockquote>
            );
          case "list": {
            const Tag = b.ordered ? "ol" : "ul";
            return (
              <Tag key={bi}>
                {b.items.map((it, li) => (
                  <li key={li} style={{ marginLeft: it.depth * 20 }} className={it.task ? "list-none" : undefined}>
                    {it.task ? (
                      <label className="sb-task">
                        <input
                          type="checkbox"
                          checked={it.done}
                          onChange={() => opts.onToggleTask?.(it.taskIndex!)}
                        />
                        <span className={it.done ? "line-through text-muted-foreground" : undefined}>
                          {renderInline(it.text, opts, `t${bi}-${li}`)}
                        </span>
                      </label>
                    ) : (
                      renderInline(it.text, opts, `l${bi}-${li}`)
                    )}
                  </li>
                ))}
              </Tag>
            );
          }
          case "table":
            return (
              <div key={bi} className="overflow-x-auto">
                <table>
                  <thead>
                    <tr>
                      {b.header.map((h, hi) => (
                        <th key={hi}>{renderInline(h, opts, `th${bi}-${hi}`)}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {b.rows.map((r, ri) => (
                      <tr key={ri}>
                        {r.map((c, ci) => (
                          <td key={ci}>{renderInline(c, opts, `td${bi}-${ri}-${ci}`)}</td>
                        ))}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            );
          case "hr":
            return <hr key={bi} />;
          case "images":
            return <ImageGrid key={bi} images={b.images} groupIdx={bi} opts={opts} />;
          case "footnoteDefs":
            return (
              <div key={bi} className="footnotes">
                {b.defs.map((d) => (
                  <p key={d.id} id={`fn-${d.id}`}>
                    <a href={`#fnref-${d.id}`} className="mr-1">[{d.id}]</a>
                    {renderInline(d.text, opts, `fn${bi}-${d.id}`)}
                  </p>
                ))}
              </div>
            );
          default:
            return null;
        }
      })}
    </div>
  );
}

/** Total number of find hits in the last render (for the find bar counter). */
export function lastFindCount(): number {
  return findCounter;
}
