# unslothDeepSeek-V4-Flash-0731-GGUF  Hugging Face

:::quick-info
Source: https://huggingface.co/unsloth/DeepSeek-V4-Flash-0731-GGUF
Scraped: 2026-11-03
Topic: DeepSeek KV Cache
:::

unsloth/DeepSeek-V4-Flash-0731-GGUF · Hugging Face

##

Read our How to Run DeepSeek-V4-0731 Guide![Run DeepSeek-V4-0731 Guide!](https://unsloth.ai/docs/models/deepseek-v4)

Unsloth Dynamic 2.0[Unsloth Dynamic 2.0](https://unsloth.ai/docs/basics/unsloth-dynamic-v2.0-gguf) achieves superior accuracy & outperforms other leading quants.

![https://github.com/unslothai/unsloth/raw/main/images/unsloth%20new%20logo.png](https://github.com/unslothai/unsloth/raw/main/images/unsloth%20new%20logo.png)

![https://github.com/unslothai/unsloth/raw/main/images/Discord%20button.png](https://github.com/unslothai/unsloth/raw/main/images/Discord%20button.png)

![https://raw.githubusercontent.com/unslothai/unsloth/refs/heads/main/images/documentation%20green%20button.png](https://raw.githubusercontent.com/unslothai/unsloth/refs/heads/main/images/documentation%20green%20button.png)

- To run DeepSeek-V4-Flash-0731 in full precision lossless, run Q8 (UD-Q8_K_XL), which is 162GB and only 7GB bigger than Q4 (UD-Q4_K_XL).

- See our DeepSeek-V4 guide[DeepSeek-V4 guide](https://unsloth.ai/docs/models/deepseek-v4) for quantization analysis and instructions.

- You can now run DeepSeek-V4-Flash-0731 in Unsloth Studio[Unsloth Studio](https://github.com/unslothai/unsloth/) with toggles for High and Max thinking.

- New DSpark support allowing up to 2x faster decoding! Docs for DSpark[Docs for DSpark](https://unsloth.ai/docs/models/deepseek-v4#dspark-speculative-decoding)

![deepseek-v4-flash-0731 in unsloth studio](https://3215535692-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2FxhOjnexMCB3dmuQFQ2Zq%2Fuploads%2FlvJqDRKlWdAVkn3HXJZA%2F1000024247.png?alt=media&token=e84fd31d-7720-40d5-aba1-ba65ac34ce97)

---

#

DeepSeek-V4-Flash-0731

![DeepSeek-V4](https://github.com/deepseek-ai/DeepSeek-V2/blob/main/figures/logo.svg?raw=true)

---

![Homepage](https://github.com/deepseek-ai/DeepSeek-V2/blob/main/figures/badge.svg?raw=true)

![Chat](https://img.shields.io/badge/🤖%20Chat-DeepSeek%20V4-536af5?color=536af5&logoColor=white)

![Hugging Face](https://img.shields.io/badge/%F0%9F%A4%97%20Hugging%20Face-DeepSeek%20AI-ffc107?color=ffc107&logoColor=white)

![Twitter Follow](https://img.shields.io/badge/Twitter-deepseek_ai-white?logo=x&logoColor=white)

![License](https://img.shields.io/badge/License-MIT-f5de53?&color=f5de53)

Technical Report👁️[Technical Report👁️](https://arxiv.org/abs/2606.19348)

##

Introduction

DeepSeek-V4-Flash-0731 is the official release of DeepSeek-V4-Flash, superseding the preview version, with substantially enhanced agentic capabilities. It has the same model structure as DeepSeek-V4-Flash-DSpark[DeepSeek-V4-Flash-DSpark](https://huggingface.co/deepseek-ai/DeepSeek-V4-Flash-DSpark), i.e. it comes with a speculative decoding module attached.

DeepSeek-V4-Flash-0731 outperforms DeepSeek-V4-Pro (Preview) on benchmarks listed below despite its far smaller activated parameter count, and is broadly competitive with the strongest proprietary models available.

| Benchmark
| DeepSeek-V4-Flash-0731
| DeepSeek-V4-Flash (Preview)
| DeepSeek-V4-Pro (Preview)
| GLM-5.2
| Opus-4.8

| Terminal Bench 2.1
| 82.7
| 61.8
| 72.1
| 81.0
| 85.0

| NL2Repo
| 54.2
| 39.4
| 38.5
| 48.9
| 69.7

| Cybergym
| 76.7
| 38.7
| 52.7
| -
| 83.1

| DeepSWE
| 54.4
| 7.3
| 12.8
| 46.2
| 58.0

| Toolathlon-Verified
| 70.3
| 49.7
| 55.9
| 59.9
| 76.2

| Agents' Last Exam
| 25.2
| 15.8
| 16.5
| 23.8
| 25.7

| AutomationBench Public
| 25.1
| 10.8
| 12.8
| 12.9
| 27.2

| DSBench-FullStack †
| 68.7
| 37.0
| 41.8
| 61.8
| 71.6

| DSBench-Hard †
| 59.6
| 25.8
| 31.1
| 54.5
| 71.7

Notes:

- For the Code Agent tasks among the public benchmarks above, DeepSeek-V4-Flash-0731 is evaluated with the minimal mode of DeepSeek Harness (to be released) as the agent framework, using the max reasoning effort level with temperature = 1.0, top_p = 0.95.

- † DSBench-FullStack is an internal full-stack development test set; DSBench-Hard is an internal test set of difficult coding-agent problems.

##

License

This repository and the model weights are licensed under the MIT License[MIT License](/unsloth/DeepSeek-V4-Flash-0731-GGUF/tree/main/LICENSE).

##

Citation

```
@misc{deepseekai2026deepseekv4,
title={DeepSeek-V4: Towards Highly Efficient Million-Token Context Intelligence},
author={DeepSeek-AI},
year={2026},
}

```

Downloads last month 150,255

GGUF

Model size
284B params

Architecture
deepseek4

Chat template

Hardware compatibility
Log In to add your hardware

1-bit

UD-IQ1_S
82.5 GB UD-IQ1_M
86.9 GB

2-bit

UD-IQ2_XXS
90.9 GB UD-IQ2_M
90.9 GB UD-Q2_K_XL
96.8 GB

3-bit

UD-IQ3_XXS
104 GB UD-IQ3_S
116 GB UD-Q3_K_M
128 GB UD-Q3_K_XL
128 GB

4-bit

UD-IQ4_XS
137 GB UD-IQ4_NL
137 GB UD-Q4_K_XL
155 GB

8-bit

DSPARK Q8_0
10.9 GB UD-Q8_K_XL
162 GB

16-bit

DSPARK BF16
11.3 GB

Inference Providers NEW[NEW](https://huggingface.co/docs/inference-providers)
This model isn't deployed by any Inference Provider. 🙋 2 Ask for provider support[🙋 2 Ask for provider support](/spaces/huggingface/InferenceSupport/discussions/11631)

## Model tree for unsloth/DeepSeek-V4-Flash-0731-GGUF

Base model

deepseek-ai/DeepSeek-V4-Flash-0731[deepseek-ai/DeepSeek-V4-Flash-0731](/deepseek-ai/DeepSeek-V4-Flash-0731)

Quantized (203[203](/models?other=base_model:quantized:deepseek-ai/DeepSeek-V4-Flash-0731))

this model

Finetunes
1 model[1 model](/models?other=base_model:finetune:unsloth/DeepSeek-V4-Flash-0731-GGUF)

Quantizations
4 models[4 models](/models?other=base_model:quantized:unsloth/DeepSeek-V4-Flash-0731-GGUF)

## Spaces using unsloth/DeepSeek-V4-Flash-0731-GGUF 2

## Collection including unsloth/DeepSeek-V4-Flash-0731-GGUF

New 2.0 version of our Dynamic GGUF + Quants. Dynamic 2.0 achieves superior accuracy & SOTA quantization performance. • 123 items • Updated 5 days ago • 848 [New 2.0 version of our Dynamic GGUF + Quants. Dynamic 2.0 achieves superior accuracy & SOTA quantization performance. • 123 items • Updated 5 days ago • 848](/collections/unsloth/unsloth-dynamic-20-quants)

## Paper for unsloth/DeepSeek-V4-Flash-0731-GGUF

Paper • 2606.19348 • Published Apr 26 • 49 [Paper • 2606.19348 • Published Apr 26 • 49](/papers/2606.19348)

## Reference sources

- [unslothDeepSeek-V4-Flash-0731-GGUF  Hugging Face](https://huggingface.co/unsloth/DeepSeek-V4-Flash-0731-GGUF) — accessed 2026-11-03
