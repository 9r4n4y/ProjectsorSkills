# deepseek-ai DeepSeek

:::quick-info
Source: https://huggingface.co/deepseek-ai
Scraped: 2026-11-03
Topic: DeepSeek KV Cache
:::

deepseek-ai (DeepSeek)

### AI & ML interests

None defined yet.

### Recent Activity

![/api/users/msr2000/avatar](/api/users/msr2000/avatar)

msr2000[msr2000](/msr2000)  published a model 16 days ago deepseek-ai/DeepSeek-V4.1-Flash-1017 [deepseek-ai/DeepSeek-V4.1-Flash-1017](/deepseek-ai/DeepSeek-V4.1-Flash-1017)

![/api/users/msr2000/avatar](/api/users/msr2000/avatar)

msr2000[msr2000](/msr2000)  updated a collection 17 days ago DeepSeek-V4[DeepSeek-V4](https://hf.co/collections/deepseek-ai/deepseek-v4)

![/api/users/msr2000/avatar](/api/users/msr2000/avatar)

msr2000[msr2000](/msr2000)  updated a model 17 days ago deepseek-ai/DeepSeek-V4.1-Flash-1017 [deepseek-ai/DeepSeek-V4.1-Flash-1017](/deepseek-ai/DeepSeek-V4.1-Flash-1017) View all activity[View all activity](/organizations/deepseek-ai/activity/all)

###
Papers

![https://cdn-thumbnails.huggingface.co/social-thumbnails/papers/2609.19969.png](https://cdn-thumbnails.huggingface.co/social-thumbnails/papers/2609.19969.png)

DeepSeek-V4.1-Flash: Pushing the Limits of KV Cache Compression

[DeepSeek-V4.1-Flash: Pushing the Limits of KV Cache Compression](/papers/2609.19969)

![https://cdn-thumbnails.huggingface.co/social-thumbnails/papers/2608.25512.png](https://cdn-thumbnails.huggingface.co/social-thumbnails/papers/2608.25512.png)

A Programming Paradigm for Spatiotemporal Composability

[A Programming Paradigm for Spatiotemporal Composability](/papers/2608.25512) View all Papers[View all Papers](/deepseek-ai/papers)
### Team members 37

Organization Card
Community[Community](/spaces/deepseek-ai/README/discussions) About org cards[About org cards](/docs/hub/organizations-cards)

DeepSeek (深度求索), founded in 2023, is a Chinese company dedicated to making AGI a reality.

Unravel the mystery of AGI with curiosity. Answer the essential question with long-termism.

###
Collections 19[Collections 19](/deepseek-ai/collections)

DeepSpec
[DeepSpec](/collections/deepseek-ai/deepspec)

-

1B • Updated Jun 28 • 2.83k • 66 [1B • Updated Jun 28 • 2.83k • 66](/deepseek-ai/dspark_qwen3_4b_block7)

-

2B • Updated Jun 28 • 21.2k • 20 [2B • Updated Jun 28 • 21.2k • 20](/deepseek-ai/dspark_qwen3_8b_block7)

-

3B • Updated Jun 28 • 4.78k • 17 [3B • Updated Jun 28 • 4.78k • 17](/deepseek-ai/dspark_qwen3_14b_block7)

-

3B • Updated Jun 28 • 1.26k • 48 [3B • Updated Jun 28 • 1.26k • 48](/deepseek-ai/dspark_gemma4_12b_block7)

DeepSeek-V4
[DeepSeek-V4](/collections/deepseek-ai/deepseek-v4)

-

292B • Updated Apr 27 • 41.7k • 352 [292B • Updated Apr 27 • 41.7k • 352](/deepseek-ai/DeepSeek-V4-Flash-Base)

-

Text Generation • 291B • Updated Jun 22 • 1.06M • • 2.36k [Text Generation • 291B • Updated Jun 22 • 1.06M • • 2.36k](/deepseek-ai/DeepSeek-V4-Flash)

-

1.6T • Updated Apr 27 • 17.5k • 355 [1.6T • Updated Apr 27 • 17.5k • 355](/deepseek-ai/DeepSeek-V4-Pro-Base)

-

Text Generation • 1.6T • Updated Jun 22 • 357k • • 5.69k [Text Generation • 1.6T • Updated Jun 22 • 357k • • 5.69k](/deepseek-ai/DeepSeek-V4-Pro)

DeepSpec
[DeepSpec](/collections/deepseek-ai/deepspec)

-

1B • Updated Jun 28 • 2.83k • 66 [1B • Updated Jun 28 • 2.83k • 66](/deepseek-ai/dspark_qwen3_4b_block7)

-

2B • Updated Jun 28 • 21.2k • 20 [2B • Updated Jun 28 • 21.2k • 20](/deepseek-ai/dspark_qwen3_8b_block7)

-

3B • Updated Jun 28 • 4.78k • 17 [3B • Updated Jun 28 • 4.78k • 17](/deepseek-ai/dspark_qwen3_14b_block7)

-

3B • Updated Jun 28 • 1.26k • 48 [3B • Updated Jun 28 • 1.26k • 48](/deepseek-ai/dspark_gemma4_12b_block7)

DeepSeek-V4
[DeepSeek-V4](/collections/deepseek-ai/deepseek-v4)

-

292B • Updated Apr 27 • 41.7k • 352 [292B • Updated Apr 27 • 41.7k • 352](/deepseek-ai/DeepSeek-V4-Flash-Base)

-

Text Generation • 291B • Updated Jun 22 • 1.06M • • 2.36k [Text Generation • 291B • Updated Jun 22 • 1.06M • • 2.36k](/deepseek-ai/DeepSeek-V4-Flash)

-

1.6T • Updated Apr 27 • 17.5k • 355 [1.6T • Updated Apr 27 • 17.5k • 355](/deepseek-ai/DeepSeek-V4-Pro-Base)

-

Text Generation • 1.6T • Updated Jun 22 • 357k • • 5.69k [Text Generation • 1.6T • Updated Jun 22 • 357k • • 5.69k](/deepseek-ai/DeepSeek-V4-Pro)

View 19 collections[View 19 collections](/deepseek-ai/collections)

### spaces 6[spaces 6](/deepseek-ai/spaces)

Sort:
Recently updated

#### Chat With Janus-Pro-7B

🌍
A unified multimodal understanding and generation model.

[Chat With Janus-Pro-7B 🌍 A unified multimodal understanding and generation model.](/spaces/deepseek-ai/Janus-Pro-7B)

#### Chat With Janus 1.3B

🌍
A unified multimodal understanding and generation model.

[Chat With Janus 1.3B 🌍 A unified multimodal understanding and generation model.](/spaces/deepseek-ai/Janus-1.3B)

#### Chat with DeepSeek-VL2-small

🌍
Chat with images using AI for answers and visual tasks

[Chat with DeepSeek-VL2-small 🌍 Chat with images using AI for answers and visual tasks](/spaces/deepseek-ai/deepseek-vl2-small)

#### JanusFlow 1.3B

🏃
Huggingface space for JanusFlow-1.3B

[JanusFlow 1.3B 🏃 Huggingface space for JanusFlow-1.3B](/spaces/deepseek-ai/JanusFlow-1.3B)

#### Chat with DeepSeek Coder 33B

🐬
Generate code snippets and programming help via chat

[Chat with DeepSeek Coder 33B 🐬 Generate code snippets and programming help via chat](/spaces/deepseek-ai/deepseek-coder-33b-instruct)

### models 106[models 106](/deepseek-ai/models)

Sort:
Recently updated

Image-Text-to-Text • 763B • Updated 17 days ago • 177k • • 4.67k [Image-Text-to-Text • 763B • Updated 17 days ago • 177k • • 4.67k](/deepseek-ai/DeepSeek-V4.1-Flash-1017)

Image-Text-to-Text • 763B • Updated 17 days ago • 2.14M • • 4.84k [Image-Text-to-Text • 763B • Updated 17 days ago • 2.14M • • 4.84k](/deepseek-ai/DeepSeek-V4.1-Flash)

Image-Text-to-Text • 305B • Updated Sep 1 • 202k • • 962 [Image-Text-to-Text • 305B • Updated Sep 1 • 202k • • 962](/deepseek-ai/DeepSeek-V4-Flash-Vision-Exp)

Text Generation • 1.7T • Updated Aug 13 • 152k • • 909 [Text Generation • 1.7T • Updated Aug 13 • 152k • • 909](/deepseek-ai/DeepSeek-V4-Pro-0813)

Text Generation • 304B • Updated Aug 1 • 3.03M • • 4.09k [Text Generation • 304B • Updated Aug 1 • 3.03M • • 4.09k](/deepseek-ai/DeepSeek-V4-Flash-0731)

Text Generation • 304B • Updated Jul 4 • 145k • 309 [Text Generation • 304B • Updated Jul 4 • 145k • 309](/deepseek-ai/DeepSeek-V4-Flash-DSpark)

Text Generation • 1.7T • Updated Jul 4 • 2k • 561 [Text Generation • 1.7T • Updated Jul 4 • 2k • 561](/deepseek-ai/DeepSeek-V4-Pro-DSpark)

2B • Updated Jun 28 • 644 • 14 [2B • Updated Jun 28 • 644 • 14](/deepseek-ai/eagle3_gemma4_12b_ttt7)

2B • Updated Jun 28 • 460 • 4 [2B • Updated Jun 28 • 460 • 4](/deepseek-ai/eagle3_qwen3_14b_ttt7)

2B • Updated Jun 28 • 806 • 3 [2B • Updated Jun 28 • 806 • 3](/deepseek-ai/eagle3_qwen3_8b_ttt7)

View 106
models[View 106
models](/deepseek-ai/models)

### datasets 2[datasets 2](/deepseek-ai/datasets)

Sort:
Recently updated

Viewer • Updated Apr 30, 2025 • 325 • 6.13k • 48 [Viewer • Updated Apr 30, 2025 • 325 • 6.13k • 48](/datasets/deepseek-ai/DeepSeek-ProverBench)

Viewer • Updated Sep 12, 2024 • 27.5k • 1.41k • 74 [Viewer • Updated Sep 12, 2024 • 27.5k • 1.41k • 74](/datasets/deepseek-ai/DeepSeek-Prover-V1)

## Reference sources

- [deepseek-ai DeepSeek](https://huggingface.co/deepseek-ai) — accessed 2026-11-03
