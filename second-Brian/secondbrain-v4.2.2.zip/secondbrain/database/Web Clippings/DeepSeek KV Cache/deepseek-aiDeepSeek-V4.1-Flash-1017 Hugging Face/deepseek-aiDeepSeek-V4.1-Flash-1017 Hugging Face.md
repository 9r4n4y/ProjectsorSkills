# deepseek-aiDeepSeek-V4.1-Flash-1017  Hugging Face

:::quick-info
Source: https://huggingface.co/deepseek-ai/DeepSeek-V4.1-Flash-1017
Scraped: 2026-11-03
Topic: DeepSeek KV Cache
:::

deepseek-ai/DeepSeek-V4.1-Flash-1017 · Hugging Face

#

DeepSeek-V4.1-Flash-1017

![DeepSeek-V4.1](https://github.com/deepseek-ai/DeepSeek-V2/blob/main/figures/logo.svg?raw=true)

---

![Homepage](https://github.com/deepseek-ai/DeepSeek-V2/blob/main/figures/badge.svg?raw=true)

![Chat](https://img.shields.io/badge/🤖%20Chat-DeepSeek%20V4.1-536af5?color=536af5&logoColor=white)

![Hugging Face](https://img.shields.io/badge/%F0%9F%A4%97%20Hugging%20Face-DeepSeek%20AI-ffc107?color=ffc107&logoColor=white)

![Twitter Follow](https://img.shields.io/badge/Twitter-deepseek_ai-white?logo=x&logoColor=white)

![License](https://img.shields.io/badge/License-MIT-f5de53?&color=f5de53)

Technical Report 👁️[Technical Report 👁️](https://huggingface.co/deepseek-ai/DeepSeek-V4.1-Flash/blob/main/DeepSeek_V41_Tech_Report.pdf)

##

Introduction

DeepSeek-V4.1-Flash-1017 is a minor update to DeepSeek-V4.1-Flash[DeepSeek-V4.1-Flash](https://huggingface.co/deepseek-ai/DeepSeek-V4.1-Flash), delivering substantial improvements across reasoning, coding, agentic tasks, and visual benchmarks. Alongside these gains, the model reduces task execution time and output length, enabling users to complete tasks faster and at lower cost and advancing the performance–cost Pareto frontier across multiple agent harnesses.

| Benchmark
| DS-V4.1-Flash-1017
| DS-V4.1-Flash
| K3
| GLM-5.3
| GPT-5.6 Sol
| Opus 5

| HLE w/o tools
| 42.6 (44.0†)
| 36.8 (39.1†)
| 43.5
| 42.0†
| 44.5
| 56.3

| Terminal-Bench 4.0
| 42.3
| 31.2
| 12.6
| 37.9
| 39.9
| 51.8

| DeepSWE v1.1
| 77.0
| 74.2
| 67.5
| 66.9
| 73.0
| 74.0

| ProgramBench
| 29.1
| 20.3
| 17.5
| 19.0
| 23.0
| 37.0

| NL2Repo-Bench
| 68.2
| 65.4
| 58.0
| 58.0
| 56.8
| 75.3

| Automation-Bench v1.0.6
| 60.5
| 54.8
| 46.7
| 48.8
| 45.8
| 50.3

| Agents’ Last Exam
| 35.4
| 31.8
| 27.6
| 28.5
| 26.7
| 28.6

| Apex Bench v1.1
| 72.1
| 64.6
| 47.8
| 56.6
| 54.3
| 65.8

| Chartography (w/tools)
| 83.0
| 78.9
| 68.1
| —
| 79.9
| 84.0

| BabyVision (w/tools)
| 92.5
| 89.6
| 85.7
| —
| 88.9
| 94.1

| ZeroBench-main (w/tools)
| 51.0
| 49.0
| 41.0
| —
| 53.0
| 52.0

† denotes the text-only subset of HLE. We use the Claude Code harness for Terminal-Bench 4.0 and the Mini-SWE-V2 harness for DeepSWE v1.1.

##

Prompt Encoding

This release does not include a Jinja-format chat template. The encoding[encoding](/deepseek-ai/DeepSeek-V4.1-Flash-1017/blob/main/encoding/README.md) folder contains a self-contained Python reference implementation (encoding.py) with test cases for multi-turn conversations, tool calling, thinking mode, numeric reasoning effort, mid-conversation system messages, and interleaved image content.

For production use, we additionally release deepseek-recipe[deepseek-recipe](https://github.com/deepseek-ai/deepseek-recipe), a set of Rust libraries with Python bindings that provides the same prompt format as a maintained, protocol-aware toolkit. It converts Messages, Chat Completions, and Responses API requests into the Conversation format, encodes them into DeepSeek V4 and V4.1 prompts or token IDs, and parses model output back into complete or streamed responses — covering thinking, tool calls, images, and generation settings. Model inference, tool execution, and HTTP transport are left to the caller.

##

Minimal Inference

Please refer to the inference[inference](/deepseek-ai/DeepSeek-V4.1-Flash-1017/blob/main/inference/README.md) folder for instructions on weight conversion and running inference locally.

Recommended sampling parameters:

| Parameter
| Value

| temperature
| 1.0

| top_p
| 1.0

| context_window
| 1M tokens

| max_tokens
| ≥ 256K

##

License

This repository and the model weights are licensed under the MIT License[MIT License](/deepseek-ai/DeepSeek-V4.1-Flash-1017/tree/main/LICENSE).

##

Citation

```
@misc{deepseekai2026deepseekv41flash,
title={DeepSeek-V4.1-Flash: Pushing the Limits of KV Cache Compression},
author={DeepSeek-AI},
year={2026},
}

```

##

Contact

If you have any questions, please raise an issue or contact us at service@deepseek.com.

Downloads last month 177,009

Safetensors

Model size
763B params

Tensor type
BF16
· F32
· F8_E4M3
· I8
·

Files info

## Model tree for deepseek-ai/DeepSeek-V4.1-Flash-1017

Adapters
8 models[8 models](/models?other=base_model:adapter:deepseek-ai/DeepSeek-V4.1-Flash-1017)

Finetunes
63 models[63 models](/models?other=base_model:finetune:deepseek-ai/DeepSeek-V4.1-Flash-1017)

Merges
3 models[3 models](/models?other=base_model:merge:deepseek-ai/DeepSeek-V4.1-Flash-1017)

Quantizations

172 models[172 models](/models?other=base_model:quantized:deepseek-ai/DeepSeek-V4.1-Flash-1017)

## Spaces using deepseek-ai/DeepSeek-V4.1-Flash-1017 41

## Collection including deepseek-ai/DeepSeek-V4.1-Flash-1017

11 items • Updated 17 days ago • 953 [11 items • Updated 17 days ago • 953](/collections/deepseek-ai/deepseek-v4)

## Evaluation results

- harborframework/terminal-bench[harborframework/terminal-bench](/datasets/harborframework/terminal-bench) · Terminalbench 4 View evaluation results [View evaluation results](/deepseek-ai/DeepSeek-V4.1-Flash-1017/discussions/30) leaderboard [leaderboard](/datasets/harborframework/terminal-bench?eval_result=deepseek-ai/DeepSeek-V4.1-Flash-1017&leaderboard_task_id=terminalbench_4)

42.3 *

- datacurve/deep-swe[datacurve/deep-swe](/datasets/datacurve/deep-swe) · Deep Swe View evaluation results [View evaluation results](/deepseek-ai/DeepSeek-V4.1-Flash-1017/discussions/30) leaderboard [leaderboard](/datasets/datacurve/deep-swe?eval_result=deepseek-ai/DeepSeek-V4.1-Flash-1017&leaderboard_task_id=deep_swe)

77 *

- harborframework/terminal-bench-science[harborframework/terminal-bench-science](/datasets/harborframework/terminal-bench-science) · Terminalbenchscience 0 1 View evaluation results [View evaluation results](/deepseek-ai/DeepSeek-V4.1-Flash-1017/discussions/40)

![https://cdn-avatars.huggingface.co/v1/production/uploads/68db3b57f9ef4848b1dfa1f1/A9I8kjivZP9DVuDHm7KI_.png](https://cdn-avatars.huggingface.co/v1/production/uploads/68db3b57f9ef4848b1dfa1f1/A9I8kjivZP9DVuDHm7KI_.png)
source [source](https://artificialanalysis.ai/evaluations/terminal-bench-science) leaderboard [leaderboard](/datasets/harborframework/terminal-bench-science?eval_result=deepseek-ai/DeepSeek-V4.1-Flash-1017&leaderboard_task_id=terminalbenchscience_0_1)

12.9 *

- agents-last-exam/agents-last-exam[agents-last-exam/agents-last-exam](/datasets/agents-last-exam/agents-last-exam) · Overall Pass Rate View evaluation results [View evaluation results](/deepseek-ai/DeepSeek-V4.1-Flash-1017/discussions/30) leaderboard [leaderboard](/datasets/agents-last-exam/agents-last-exam?eval_result=deepseek-ai/DeepSeek-V4.1-Flash-1017&leaderboard_task_id=overall-pass-rate)

35.4 *

- cais/hle[cais/hle](/datasets/cais/hle) · Hle

-

Without tools. View evaluation results [View evaluation results](/deepseek-ai/DeepSeek-V4.1-Flash-1017/discussions/30)

42.6 *

-
Text-only subset, without tools. View evaluation results [View evaluation results](/deepseek-ai/DeepSeek-V4.1-Flash-1017/discussions/30)

44 *

## Reference sources

- [deepseek-aiDeepSeek-V4.1-Flash-1017  Hugging Face](https://huggingface.co/deepseek-ai/DeepSeek-V4.1-Flash-1017) — accessed 2026-11-03
