# Your First API Call  DeepSeek API Docs

:::quick-info
Source: https://api-docs.deepseek.com/news/news250910
Scraped: 2026-11-03
Topic: DeepSeek KV Cache
:::

Your First API Call | DeepSeek API Docs

Skip to main content

Search / Fetch API is now available, powered by our in-house search engine and supporting web search and fetch. Click here to view the guide[Click here to view the guide](/guides/search)

On this page

Copy MarkdownCopy Markdown
Open Markdown[Open Markdown](/quick_start/your_first_api_call.md)

# Your First API Call

The DeepSeek API uses an API format compatible with OpenAI/Anthropic. By modifying the configuration, you can use the OpenAI/Anthropic SDK or softwares compatible with the OpenAI/Anthropic API to access the DeepSeek API.

| PARAM | VALUE
| base_url (OpenAI) | https://api.deepseek.com
| base_url (Anthropic) | https://api.deepseek.com/anthropic
| api_key | apply for an API key[API key](https://platform.deepseek.com/api_keys)
| model | deepseek-flash(1)
deepseek-v4-pro

(1) Use deepseek-flash as the model name. It is now served by DeepSeek-V4.1-Flash-1017, and the calling method remains unchanged. The legacy names deepseek-v4-flash and deepseek-v4-flash-vision-exp are still accepted, but the corresponding models have been retired; their requests are served by DeepSeek-V4.1-Flash-1017 and billed at the Flash price.

## Integrate with Agent Tools​

DeepSeek Harness is now in developer preview for agent harness developers worldwide. See the DeepSeek Harness Guide[DeepSeek Harness Guide](https://deepseek-harness.github.io/deepseek-harness/en/guide/quickstart) for details.

The DeepSeek API is supported by many popular AI agent and coding assistant tools. If you use tools like Claude Code, GitHub Copilot, or OpenCode, you can use DeepSeek as the backend model directly — no code required.

See the Agent Integrations Guide[Agent Integrations Guide](/quick_start/agent_integrations/claude_code) for details.

## Invoke The Chat API​

Once you have obtained an API key, you can access the DeepSeek model using the following example scripts in the OpenAI API format. This is a non-stream example, you can set the stream parameter to true to get stream response.

For examples using the Anthropic API format, please refer to Anthropic API[Anthropic API](/guides/anthropic_api).

Before running these examples, set the DEEPSEEK_API_KEY environment variable in your terminal to your API key.

- curl

- python

- nodejs

```
curl https://api.deepseek.com/chat/completions \
-H "Content-Type: application/json" \
-H "Authorization: Bearer ${DEEPSEEK_API_KEY}" \
-d '{
"model": "deepseek-flash",
"messages": [
{"role": "system", "content": "You are a helpful assistant."},
{"role": "user", "content": "Hello!"}
],
"thinking": {"type": "enabled"},
"reasoning_effort": "high",
"stream": false
}'

```

```
# Please install OpenAI SDK first: `pip3 install openai`
import os
from openai import OpenAI

client = OpenAI(
api_key=os.environ.get('DEEPSEEK_API_KEY'),
base_url="https://api.deepseek.com",
)

response = client.chat.completions.create(
model="deepseek-flash",
messages=[
{"role": "system", "content": "You are a helpful assistant"},
{"role": "user", "content": "Hello"},
],
stream=False,
reasoning_effort="high",
extra_body={"thinking": {"type": "enabled"}},
)

print(response.choices[0].message.content)

```

```
// Please install OpenAI SDK first: `npm install openai`

import OpenAI from "openai";

const openai = new OpenAI({
baseURL: 'https://api.deepseek.com',
apiKey: process.env.DEEPSEEK_API_KEY,
});

async function main() {
const completion = await openai.chat.completions.create({
messages: [{ role: "system", content: "You are a helpful assistant." }],
model: "deepseek-flash",
thinking: {"type": "enabled"},
reasoning_effort: "high",
stream: false,
});

console.log(completion.choices[0].message.content);
}

main();

```

- Integrate with Agent Tools

- Invoke The Chat API

## Reference sources

- [Your First API Call  DeepSeek API Docs](https://api-docs.deepseek.com/news/news250910) — accessed 2026-11-03
