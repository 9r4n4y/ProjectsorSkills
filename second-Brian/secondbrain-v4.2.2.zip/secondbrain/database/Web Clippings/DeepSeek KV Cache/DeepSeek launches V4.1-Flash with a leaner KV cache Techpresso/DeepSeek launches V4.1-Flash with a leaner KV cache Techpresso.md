# DeepSeek launches V4.1-Flash with a leaner KV cache  Techpresso

:::quick-info
Source: https://techpresso.co/blog/deepseek-v4-1-flash
Scraped: 2026-11-03
Topic: DeepSeek KV Cache
:::

DeepSeek launches V4.1-Flash with a leaner KV cache | Techpresso

![DeepSeek launches V4.1-Flash with a leaner KV cache](/images/opt/9fcee0ec42fb5ad97e9113de.269c67af607e.avif)

DeepSeek just shipped V4.1-Flash, a 552 billion parameter mixture-of-experts model that it says slashes the memory its KV cache needs to a quarter of the last generation's HBM.

The 10 September 2026 API docs news post[10 September 2026 API docs news post](https://api-docs.deepseek.com/news/news260910) presents DeepSeek-V4.1-Flash as the smallest model in its new architecture family, with native visual understanding. The same-day changelog[changelog](https://api-docs.deepseek.com/updates) lists vendor scores including GPQA Diamond 90.9, Terminal-Bench 2.1 90.6, and a Codeforces rating of 3471. Those figures are DeepSeek's own table, not a third-party audit.

DeepSeek describes a new Causal Encoder-Decoder architecture that activates 8 billion parameters on input and 16 billion on output. Against the prior generation, it says the V4.1-Flash KV cache needs one quarter the HBM and one eighth the SSD storage.

The model is live on the DeepSeek API as deepseek-flash, with native multimodal support. V4-Flash and V4-Flash-Vision-Exp are retired. For compatibility, deepseek-v4-flash and deepseek-v4-flash-vision-exp temporarily route to V4.1-Flash.

The cutoff most one-line takes skip is already on the changelog. After 12:00 Beijing Time on 14 September 2026 (04:00 UTC on the news post), and until V4.1-Pro ships, every deepseek-v4-pro request routes to V4.1-Flash and is billed at V4.1-Flash prices.

DeepSeek says its testing puts V4.1-Flash ahead of V4-Pro on performance, cost, speed, and total time. That is a vendor claim.

TechTimes[TechTimes](https://www.techtimes.com/articles/327163/20260910/deepseek-v41-flash-cuts-agent-memory-costs-fourfold-new-architecture.htm) adds color the docs do not headline: a global KV cache of 890 bytes per token, and DeepSWE scores that swing from 65.5% to 74.2% depending on the harness. Benchmark wins stay DeepSeek-reported. Scores on agent tasks can move with the harness wrapped around the same checkpoint.

DeepSeek posted weights on Hugging Face. TechTimes says they ship under the MIT license. Hosted API traffic still sits under Chinese intelligence and cybersecurity statutes, the same legal backdrop as when CISA flagged China-linked distillation around DeepSeek and Alibaba[CISA flagged China-linked distillation around DeepSeek and Alibaba](https://techpresso.co/blog/cisa-china-ai-distillation-deepseek-alibaba). Open weights change the data-transit story for self-hosters. They do not rewrite that legal backdrop.

Until V4.1-Pro arrives, the Pro endpoint is Flash, at Flash prices, as of Beijing noon on 14 September.

Some offers on this page may be paid placements or contain affiliate links.

Subscribe to Techpresso

Free daily newsletter, read in 5 minutes.

Subscribe free [Subscribe free](https://techpresso.co)

## Reference sources

- [DeepSeek launches V4.1-Flash with a leaner KV cache  Techpresso](https://techpresso.co/blog/deepseek-v4-1-flash) — accessed 2026-11-03
