# Serving DeepSeek-V4 why million-token context is an inference systems

:::quick-info
Source: https://www.together.ai/blog/serving-deepseek-v4-why-million-token-context-is-an-inference-systems-problem
Scraped: 2026-11-03
Topic: DeepSeek KV Cache
:::

Serving DeepSeek-V4: why million-token context is an inference systems problem

![https://cdn.prod.website-files.com/plugins/Basic/assets/placeholder.60f9b1840c.svg](https://cdn.prod.website-files.com/plugins/Basic/assets/placeholder.60f9b1840c.svg)

Introducing Together Post-Training: Better models, faster runs, lower costs →

[Introducing Together Post-Training: Better models, faster runs, lower costs →](https://www.together.ai/blog/together-post-training)

![https://cdn.prod.website-files.com/plugins/Basic/assets/placeholder.60f9b1840c.svg](https://cdn.prod.website-files.com/plugins/Basic/assets/placeholder.60f9b1840c.svg)

Introducing Together Link: Run open models inside the harness you already use →

[Introducing Together Link: Run open models inside the harness you already use →](https://www.together.ai/blog/together-link-frontier-quality-open-models-in-the-harness-you-already-use)

![https://cdn.prod.website-files.com/plugins/Basic/assets/placeholder.60f9b1840c.svg](https://cdn.prod.website-files.com/plugins/Basic/assets/placeholder.60f9b1840c.svg)

The Open Source AI Stack: models, inference, routers, harnesses & tools →

[The Open Source AI Stack: models, inference, routers, harnesses & tools →](https://www.together.ai/blog/the-open-source-ai-stack)

![https://cdn.prod.website-files.com/plugins/Basic/assets/placeholder.60f9b1840c.svg](https://cdn.prod.website-files.com/plugins/Basic/assets/placeholder.60f9b1840c.svg)

GLM-5.3 vs. GLM 5.3 Flash on DeepSWE →

[GLM-5.3 vs. GLM 5.3 Flash on DeepSWE →](/blog/glm-5-3-vs-glm-5-3-flash-on-deepswe-cost-coding-and-routing)

![https://cdn.prod.website-files.com/plugins/Basic/assets/placeholder.60f9b1840c.svg](https://cdn.prod.website-files.com/plugins/Basic/assets/placeholder.60f9b1840c.svg)

⚡ On-demand B200s now available on Together GPU Clusters →

[⚡ On-demand B200s now available on Together GPU Clusters →](https://api.together.ai/clusters/create)

All blog posts[All blog posts](/blog)

Inference
Published 5/11/2026

# Serving DeepSeek-V4: why million-token context is an inference systems problem

-

Authors

Jue Wang, Dan Fu, Alex Angus, Yineng Zhang, Michael Granado, Sonny Khan

-

Table of contents

-
40+ Models Chosen for Production...40+ Models Chosen for Production...40+ Models Chosen for Production...

-

Links in this article

Webinar[Webinar](https://www.youtube.com/live/D_K_xVePFdU?si=gHEFD5vf5T3PobnI)

DeepSeek-V4-Pro[DeepSeek-V4-Pro](https://www.together.ai/models/deepseek-v4-pro)

Benchmark tables miss the main point of DeepSeek-V4: the important change is architectural. V4 turns million-token context into a serving-systems problem.

The model supports a 1M-token context window through a hybrid attention design that compresses context before key-value (KV) storage, mixes compressed and local attention paths, and changes how prefix reuse works. Those choices reduce KV pressure, but the savings only matter if the inference[inference](https://www.together.ai/serverless-inference) engine can manage the resulting cache layouts, recover local state, batch requests effectively, and choose endpoint profiles that match the workload.

This post focuses on the serving implications of V4's Compressed Sparse Attention (CSA) / Heavily Compressed Attention (HCA) / Sliding Window Attention (SWA) attention design, based on Together's early bring-up work on NVIDIA HGX B200. V4 also includes other architecture and training changes, including Manifold-Constrained Hyper-Connections (mHC) residual connections and Muon optimizer choices, but those are outside the main scope here.

## V4 compresses the token axis of KV cache

Autoregressive inference stores prior context in KV cache. During decode, each new token generated reads from and attends to that stored state. The cache grows with sequence length:

KV cache  ∝  layers × tokens × kv_heads × head_dim × bytes

At long context, KV cache hits serving twice. It caps concurrency because each active request occupies memory, and it lowers throughput because decode has to read stored context every step. V4 matters because it attacks both sides of that problem: fewer cache entries to store and fewer cache entries to move through attention.

On NVIDIA Blackwell, that cache pressure maps directly to serving economics. Long-context inference depends on keeping enough KV resident for concurrency while preserving memory bandwidth for decode. V4’s token-axis compression makes that tradeoff more favorable: the engine has more room to batch requests, reuse prefixes, and keep long-context workloads inside an efficient serving regime.

Recent model architectures have reduced different terms in the  product above. Group Query Attention (GQA) reduces KV heads. Multi-Head Latent Attention (MLA) compresses KV into a latent representation. FP8, MXFP4, and NVFP4[NVFP4](https://developer.nvidia.com/blog/introducing-nvfp4-for-efficient-and-accurate-low-precision-inference/) reduce bytes per element. DeepSeek-V3.2 sparse attention reduced how much KV had to be read during decode, while the full cache still had to stay resident.

DeepSeek-V4 targets the token axis. It compresses context before KV storage.

That is the important shift.

Under a vanilla BF16 multi-head attention calculation, a 70B-class model can require megabytes of KV cache per token. The exact coefficient depends on layer count, KV heads, head dimension, and precision. At 1M tokens, the cache becomes impractical for a single request. V4's token-axis compression, combined with MLA-style head compression and low-precision KV, reduces the per-request cache footprint enough to make very long context materially more practical.

In early bring-up, V4’s serving capacity was governed less by the compressed CSA / HCA cache and more by how the engine handled SWA state. A full-SWA implementation actually had a higher per-token KV footprint than our V3 path — roughly 3.8 KB per token versus 3.4 KB — because the engine was storing the full sliding-window state.

The practical gain came from cache policy. By keeping only the SWA states most likely to be reused, we increased total KV-cache capacity on a single NVIDIA HGX B200 node from roughly 1.2M tokens to 3.7M tokens with minimal changes. That is the main serving lesson: V4’s architecture creates the opportunity for long-context efficiency, but the realized capacity depends on how the inference engine stores, recomputes, and evicts the different cache types.

The practical win extends beyond full 1M-token requests. It makes 200K–500K-token workloads more concurrent and less fragile, because the engine has more KV budget to work with before memory pressure forces eviction or limits batching. Earlier million-token-context models still left major serving challenges around memory, concurrency, and cost. V4 moves that range closer to an actual workload when the serving policy matches the cache layout.

![https://cdn.prod.website-files.com/69654e88dce9154b5f12070c/69fe1d7726c393aaadb6ba84_d89c4362.png](https://cdn.prod.website-files.com/69654e88dce9154b5f12070c/69fe1d7726c393aaadb6ba84_d89c4362.png)

## V4 requires multiple KV-cache layouts

Many existing serving paths assume something close to a single KV cache layout: one cache object per layer per token, the same shape across the stack. V4 requires three different cache types, mixed across layers.

Compressed Sparse Attention (CSA) compresses context with stride 4, but each compressed entry is built from a slightly wider receptive field. In V4's configuration, each entry summarizes an 8-token neighborhood, so adjacent compressed entries overlap at the boundaries. When a query selects 128 compressed entries, it is selecting summaries of local neighborhoods rather than isolated token positions. That gives CSA a finer-grained path into selected regions of the million-token prefix while still reducing the stored cache footprint.

![https://cdn.prod.website-files.com/69654e88dce9154b5f12070c/69fe1d7726c393aaadb6ba7b_33d2d4fc.png](https://cdn.prod.website-files.com/69654e88dce9154b5f12070c/69fe1d7726c393aaadb6ba7b_33d2d4fc.png)

Heavily Compressed Attention (HCA) uses the same compression idea but with stride 128. At a 1M-token context length, that reduces the cache from 1M token positions to roughly 8K compressed entries. That is the key difference from CSA: the compressed cache is small enough that the model can attend over it densely instead of selecting a top-k subset. HCA gives the model a coarse global read over the whole context, while CSA gives it a finer sparse read over selected regions.

![https://cdn.prod.website-files.com/69654e88dce9154b5f12070c/69fe1d7726c393aaadb6ba81_b1dc1af1.png](https://cdn.prod.website-files.com/69654e88dce9154b5f12070c/69fe1d7726c393aaadb6ba81_b1dc1af1.png)

Sliding Window Attention (SWA) preserves the local path. The window is short, around 128 tokens, and keeps recent context exact.

Across the stack, the engine has to manage CSA compressed state, HCA compressed state, SWA local state, and short uncompressed tail states used by the CSA and HCA compressors. These objects have different sizes, lifetimes, and read patterns.

New attention kernels are only part of the work. The harder serving problem is memory management: batching requests, evicting cache pages, reusing prefixes, and keeping decode throughput stable while different parts of the model depend on different kinds of stored state.

![Three diagrams comparing CSA, HCA, and SWA methods with different compression and KV token reads.](https://cdn.prod.website-files.com/69654e88dce9154b5f12070c/69fe1d7726c393aaadb6ba7e_5e54d7db.png)

## Prefix caching becomes a storage policy

Prefix caching usually starts with a simple rule: shared prefix, shared KV. With V4, the question becomes: which cache?

A shared prefix contains CSA state, HCA state, SWA state, and the uncompressed tail states used by the CSA and HCA compressors. CSA and HCA are compact enough to store efficiently. SWA is exact local state, which makes it more expensive to store for long prefixes, especially once the cache tier moves beyond GPU memory.

The DeepSeek[DeepSeek](https://www.together.ai/models-providers/deepseek) paper describes three SWA strategies.

The first stores the full SWA cache. Reuse is simple because the engine can restore the complete prefix state directly, but storage and write bandwidth grow quickly.

The second stores periodic SWA checkpoints. The engine saves state every K tokens and recomputes the gap on a cache hit.

The third recomputes SWA on hit. The engine stores compressed CSA / HCA state and rebuilds the SWA path when a prefix is reused. The cost is bounded by window size times layer count. With a 128-token window and 61 layers, that is roughly 8K tokens of recompute. Against a 1M-token prefix, that trade can make sense.

In our current V4 bring-up, we use the first strategy: storing the full SWA cache. This keeps prefix reuse straightforward and avoids adding recompute complexity while the rest of the serving path is still maturing. The tradeoff is higher cache footprint, which makes cache policy and eviction behavior more important as context length and concurrency increase.

V4 turns prefix caching into a policy decision across cache objects: store CSA and HCA, decide how to handle SWA, and evict each type according to its own cost.

## V4 performance is regime-dependent

V4's gains show up first where KV cache dominates.

Long-context, decode-heavy workloads spend much of their time reading cache. V4's compressed cache layout reduces that pressure.

Short-context, prefill-heavy workloads hit a different path. CSA top-k selection, HCA compressed reads, and SWA introduce operations outside mature dense-attention kernel paths. Kernel maturity matters. Precision format matters too: V4 uses MXFP4 for MoE weights, which has different performance characteristics than NVFP4 on NVIDIA Blackwell GPUs. That makes short-context prefill especially sensitive to kernel maturity, while long-context decode benefits more directly from KV-cache reduction.

That creates a regime split. Long-context workloads benefit from V4's cache savings early. Short-context workloads depend more on kernel bring-up and prefill optimization. This is typical for a new architecture: the first implementation establishes correctness; the next iterations close the gap to hardware efficiency.

Together is continuing V4 kernel work across the prefill and decode paths.

Developers should benchmark V4 in their actual regime. A 1M-context coding agent and a short-context chat assistant exercise different parts of the serving stack.

## The same weights need different serving profiles

V4 widens the gap between workload shapes.

Long-context agents benefit most directly from the architecture. They read large amounts of cache during decode, so V4's compressed KV layout, larger tensor-parallel configurations, batching, and prefix reuse all matter. This is the regime where the model's long-context design should show up first.

Coding agents over shared repositories are related, but the serving problem is more prefix-heavy. The same project files, repository state, or task scaffolds may repeat across requests, so cache tiering and SWA recompute policy become first-order choices. The bottleneck includes both long context and repeated-context reuse.

Short chat sits at the other end of the spectrum. These workloads do not benefit much from million-token cache compression, and they expose prefill latency, small-batch overhead, and kernel maturity instead. Serving them well may require smaller tensor-parallel groups, minimal batching delay, and kernels tuned for the short-context path.

RL rollouts care about a different unit of economics: cost per long trajectory. They may share serving machinery with long-context agents, but the optimization target is experiment throughput, how many long-horizon rollouts can be generated per training budget, rather than single-request latency alone.

The same weights can serve all of these workloads. Each performs best under a different endpoint configuration. Together is evaluating endpoint profiles with different batching, parallelism, and cache policies.

## What to benchmark before moving to V4

Million-token serving matters most for systems that accumulate state over long tasks: coding agents, research agents, and other longer horizon tasks. For these workloads, the cost model often shifts from price per token toward cost per completed trajectory.

Before moving traffic to V4, benchmark four things: context-length regime, prefix reuse, cache policy, and endpoint profile.

For long-context agents, measure cache hit rate, decode throughput, and cost per completed task. Time-to-first-token captures only part of the picture.

For short chat, compare latency at your real context lengths and batch sizes. V4's long-context gains may not appear in short-chat latency first.

For shared-prefix workloads, test SWA full-store against recompute-on-hit. Prefix length, cache-tier latency, and reuse frequency determine the answer.

For RL rollouts, calculate cost by trajectory length and number of rollouts per experiment, not by token price alone.

For mixed traffic, expect tradeoffs. One endpoint can serve mixed workloads, but a profile-specific endpoint will usually perform better once the workload shape is clear.

Quality still has to be measured. Longer context creates more room for useful state, retrieval noise, compression artifacts, and latency. It also changes compaction strategy: builders get more control over when to preserve raw state, summarize, or reset.

## Conclusion

DeepSeek-V4's efficiency is a system property. The architecture reduces KV pressure by compressing along the token axis, but the serving engine has to manage the cache types, prefix policies, kernel paths, and endpoint profiles that follow from that choice.

This is also where full-stack co-design matters. The model changes the cache layout. The inference engine changes memory management and prefix policy. The kernels adapt to new attention and precision paths. NVIDIA provides day 0 support for v4 with MXFP4 on Blackwell, and also enables developers to optimize performance with NVFP4. Through extensive co-design, Together AI and NVIDIA both continue to improve hardware efficiency through software optimizations, such as NVIDIA Dynamo. Extreme co-design unlocks the lowest cost-per-token on leading open models like DeepSeek V4, unlocking higher[NVIDIA Dynamo. Extreme co-design unlocks the lowest cost-per-token on leading open models like DeepSeek V4, unlocking higher](https://www.together.ai/blog/together-ai-at-nvidia-gtc-2026) performance on NVIDIA Blackwell.

Running V4 is the starting point. Turning its architectural savings into lower latency, higher concurrency, and cheaper long-context workloads requires cache-policy work, kernel work, and workload-specific serving profiles. The next step is measurement: per-token KV footprint, context-length throughput curves, prefix-cache policy impact, and endpoint profiles for different traffic shapes. We'll publish those numbers as the V4 kernels and cache policies mature.

## FAQ

What is DeepSeek-V4's context window? DeepSeek-V4 supports a 1M-token context window. It achieves this through a hybrid attention design that compresses context before key-value (KV) storage, mixes compressed and local attention paths, and changes how prefix reuse works. The architectural change is what makes million-token context viable as a serving workload.

What is Compressed Sparse Attention (CSA) in DeepSeek-V4? CSA compresses context with stride 4, where each compressed entry summarizes an 8-token neighborhood, so adjacent entries overlap at the boundaries. Queries select roughly 128 of these compressed entries, giving the model a fine-grained sparse path into selected regions of the prefix while reducing the stored cache footprint.

What is Heavily Compressed Attention (HCA)? HCA uses the same compression mechanism as CSA but with stride 128. At a 1M-token context, this reduces the cache from 1M positions to about 8K compressed entries, which is small enough that the model attends densely over all of it. HCA provides a coarse global read, while CSA provides a fine sparse read over selected regions.

How does DeepSeek-V4 reduce KV cache size compared to earlier models? DeepSeek-V4 compresses along the token axis of KV cache. Earlier techniques reduced different terms in the cache product: Group Query Attention reduces KV heads, Multi-Head Latent Attention compresses the head dimension, and FP8/MXFP4/NVFP4 reduce bytes per element. DeepSeek-V3.2 reduced how much cache had to be read at decode while keeping the full cache resident. V4 reduces the number of stored token entries themselves.

Why does serving DeepSeek-V4 require multiple KV cache layouts? The model uses three attention paths (CSA, HCA, and Sliding Window Attention) mixed across layers. Each produces cache objects with different sizes, lifetimes, and read patterns. The inference engine has to manage all three concurrently per request, which makes memory management, eviction, and prefix reuse harder than under a single-cache design.

How does prefix caching work with DeepSeek-V4? Prefix caching becomes a per-cache-type policy decision. CSA and HCA state are compact enough to store. SWA state is exact local state and grows expensive at long prefixes. The DeepSeek paper describes three options: store full SWA, store periodic checkpoints, or recompute SWA on cache hit. Recompute-on-hit is bounded by window size times layer count, roughly 8K tokens of recompute against a 1M-token prefix.

What workloads benefit most from DeepSeek-V4? Long-context, decode-heavy workloads benefit first, including coding agents, research agents, and RL rollouts that accumulate state over long tasks. For these, the cost model shifts from price-per-token toward cost-per-completed-trajectory. Short-context chat workloads see smaller gains because they expose prefill latency and kernel maturity more than KV cache pressure.

Should I move short-chat traffic to DeepSeek-V4? Benchmark first. V4's gains show up where KV cache dominates. Short-context, prefill-heavy workloads exercise newer kernel paths (CSA top-k selection, HCA dense reads, MXFP4 MoE weights) that are still maturing. Compare latency at your real context lengths and batch sizes before switching. Long-context agents and short chats may need different endpoint profiles even on the same weights.

Why did Together pick the NVIDIA HGX B200 to serve DeepSeek V4?

NVIDIA HGX B200 lines up with the parts of DeepSeek V4 that dominate serving cost: KV-cache pressure during long-context decode and MoE weight bandwidth during prefill. NVIDIA Blackwell inference performance[inference performance](https://inferencex.semianalysis.com/inference?g_rundate=2026-05-07&g_runid=25472714189&i_active=b200_sglang%2Cb200_trt%2Cb200_vllm%2Cb300_sglang%2Cb300_trt%2Cb300_vllm%2Cgb200_dynamo-vllm%2Cgb300_dynamo-sglang%2Cgb300_dynamo-vllm%2Cmi355x_atom%2Cmi355x_sglang&g_model=DeepSeek-V4-Pro) lets a single HGX B200 node to hold V4's compressed CSA / HCA / SWA cache layouts resident across many concurrent long-context requests, and its native MXFP4 support matches the format DeepSeek ships for V4's MoE weights, so we run the model's quantization end-to-end without a re-cast step. Together's HGX B200 instances inherit the same MXFP4 path and KV-compression headroom, which is why we picked it as the launch platform for V4.

## Related articles

View All[View All](/blog)

View All[View All](/blog)

Inference
Together Link: frontier-quality open models in the harness you already use
[Together Link: frontier-quality open models in the harness you already use](/blog/together-link-frontier-quality-open-models-in-the-harness-you-already-use)

![https://cdn.prod.website-files.com/69654e88dce9154b5f12070c/6ac396a5f8a841cbd899141c_Together_Link_Blog_Thumbnail_OG_1200x630.jpg](https://cdn.prod.website-files.com/69654e88dce9154b5f12070c/6ac396a5f8a841cbd899141c_Together_Link_Blog_Thumbnail_OG_1200x630.jpg)

Inference
Canary rollouts: upgrade models in production without downtime
[Canary rollouts: upgrade models in production without downtime](/blog/canary-rollouts-upgrade-models-in-production-without-downtime)

![https://cdn.prod.website-files.com/69654e88dce9154b5f12070c/6ab2084d400cf06357fcb03e_OG-image_202600921_canary-rollouts.png](https://cdn.prod.website-files.com/69654e88dce9154b5f12070c/6ab2084d400cf06357fcb03e_OG-image_202600921_canary-rollouts.png)

Inference
How a global fintech scaled coding agent traffic with Dedicated Model Inference
[How a global fintech scaled coding agent traffic with Dedicated Model Inference](/blog/global-fintech-scales-coding-agent-traffic-with-dedicated-model-inference)

![https://cdn.prod.website-files.com/69654e88dce9154b5f12070c/6aad615d591d02ae926847c5_OG-image_202600918_DMI%20blog_global%20fintech.png](https://cdn.prod.website-files.com/69654e88dce9154b5f12070c/6aad615d591d02ae926847c5_OG-image_202600918_DMI%20blog_global%20fintech.png)

Inference
Migrating from closed to open source models, Together
[Migrating from closed to open source models, Together](/blog/migrating-from-closed-to-open-source-models)

![https://cdn.prod.website-files.com/69654e88dce9154b5f12070c/6aaa2194c7f1b60b86e8fde5_OG-image_202600828_GLM53vsGLM53Flash.png](https://cdn.prod.website-files.com/69654e88dce9154b5f12070c/6aaa2194c7f1b60b86e8fde5_OG-image_202600828_GLM53vsGLM53Flash.png)

Inference
The Open Source AI Stack
[The Open Source AI Stack](/blog/the-open-source-ai-stack)

![https://cdn.prod.website-files.com/69654e88dce9154b5f12070c/6aa1767399ac482b5318410e_OG%2017%20%E2%80%94%20MIGHT%20stack.png](https://cdn.prod.website-files.com/69654e88dce9154b5f12070c/6aa1767399ac482b5318410e_OG%2017%20%E2%80%94%20MIGHT%20stack.png)

Inference
A/B test models in production
[A/B test models in production](/blog/a-b-test-models-in-production)

![https://cdn.prod.website-files.com/69654e88dce9154b5f12070c/6a83d4464bad620dc1d00390_OG-image_20260817_a-b-testing.png](https://cdn.prod.website-files.com/69654e88dce9154b5f12070c/6a83d4464bad620dc1d00390_OG-image_20260817_a-b-testing.png)

Inference
Autoscaling endpoints for LLM inference
[Autoscaling endpoints for LLM inference](/blog/autoscaling-endpoints-for-llm-inference)

![https://cdn.prod.website-files.com/69654e88dce9154b5f12070c/6a6ce02b839f62c969091e9b_OG-image_20260731_Autoscaling.png](https://cdn.prod.website-files.com/69654e88dce9154b5f12070c/6a6ce02b839f62c969091e9b_OG-image_20260731_Autoscaling.png)

Inference
Configuring Dedicated Model Inference
[Configuring Dedicated Model Inference](/blog/configuring-dedicated-model-inference)

![https://cdn.prod.website-files.com/69654e88dce9154b5f12070c/6a63a546410d4c650ed5bbf7_OG-image_20260724_configuring-dmi.png](https://cdn.prod.website-files.com/69654e88dce9154b5f12070c/6a63a546410d4c650ed5bbf7_OG-image_20260724_configuring-dmi.png)

Inference
The production platform for open-weight AI inference
[The production platform for open-weight AI inference](/blog/the-production-platform-for-open-weight-ai-inference)

![https://cdn.prod.website-files.com/69654e88dce9154b5f12070c/6a66e68a291fcc22a18d5281_OG-image_20260723_dmi-2%20(3).png](https://cdn.prod.website-files.com/69654e88dce9154b5f12070c/6a66e68a291fcc22a18d5281_OG-image_20260723_dmi-2%20(3).png)

Inference
What does 99.9% uptime mean for inference?
[What does 99.9% uptime mean for inference?](/blog/99-9-uptime-for-inference)

![https://cdn.prod.website-files.com/69654e88dce9154b5f12070c/6a5513c7b8b734d8e29421ba_OG-image_20260713_99-9-uptime.png](https://cdn.prod.website-files.com/69654e88dce9154b5f12070c/6a5513c7b8b734d8e29421ba_OG-image_20260713_99-9-uptime.png)

Inference
Together AI brings Thinking Machines Lab’s new model Inkling on day 0
[Together AI brings Thinking Machines Lab’s new model Inkling on day 0](/blog/together-ai-brings-thinking-machines-labs-new-model-inkling-on-day-0)

![https://cdn.prod.website-files.com/69654e88dce9154b5f12070c/6a57bccc9608080a86fcf005_OG-image_20260715_TML.png](https://cdn.prod.website-files.com/69654e88dce9154b5f12070c/6a57bccc9608080a86fcf005_OG-image_20260715_TML.png)

Inference
Open, convenient and predictable: Introducing Provisioned Throughput
[Open, convenient and predictable: Introducing Provisioned Throughput](/blog/provisioned-throughput)

![https://cdn.prod.website-files.com/69654e88dce9154b5f12070c/6a4d81d7e3dd350edb18c3d1_OG-provisioned-throughput.png](https://cdn.prod.website-files.com/69654e88dce9154b5f12070c/6a4d81d7e3dd350edb18c3d1_OG-provisioned-throughput.png)

Inference
Kimi K2.7 Code vs Claude Fable 5: Landing pages that cost 94% less
[Kimi K2.7 Code vs Claude Fable 5: Landing pages that cost 94% less](/blog/kimi-k2-7-code-vs-claude-fable-5)

![https://cdn.prod.website-files.com/69654e88dce9154b5f12070c/6a31bb3eae99f5eba56ab3ee_OG-image_20260616_Kimi%20vs.%20Claude.png](https://cdn.prod.website-files.com/69654e88dce9154b5f12070c/6a31bb3eae99f5eba56ab3ee_OG-image_20260616_Kimi%20vs.%20Claude.png)

Inference
Serving MiniMax-M3 for efficient inference: Unlocking 1M-Token Context and Multimodality Without Regrets
[Serving MiniMax-M3 for efficient inference: Unlocking 1M-Token Context and Multimodality Without Regrets](/blog/serving-minimax-m3-for-efficient-inference-unlocking-1m-token-context-and-multimodality-without-regrets)

![https://cdn.prod.website-files.com/69654e88dce9154b5f12070c/6a66eeca0a58a12ba183ca41_OG-image_20260602_M3%20(1).png](https://cdn.prod.website-files.com/69654e88dce9154b5f12070c/6a66eeca0a58a12ba183ca41_OG-image_20260602_M3%20(1).png)

Inference
How Together AI built the world’s fastest speech-to-text stack
[How Together AI built the world’s fastest speech-to-text stack](/blog/how-together-ai-built-the-worlds-fastest-speech-to-text-stack)

![https://cdn.prod.website-files.com/69654e88dce9154b5f12070c/6a19c7173dd9ce6d2660f358_OG-image_20260508_Pearl%20(1).png](https://cdn.prod.website-files.com/69654e88dce9154b5f12070c/6a19c7173dd9ce6d2660f358_OG-image_20260508_Pearl%20(1).png)

Inference
Benchmarking inference at scale: coding agents
[Benchmarking inference at scale: coding agents](/blog/coding-agent-benchmarks)

![Text reads: Inference in production: coding agent benchmarks with together.ai logo on pastel gradient background.](https://cdn.prod.website-files.com/69654e88dce9154b5f12070c/69f1a3b5587202cb099d02b4_OG-image_20260429_BLOG_Coding%20agent%20benchmark.png)

Inference
Together AI and Pearl Research Labs Team Up to Reduce the Cost of AI Inference
[Together AI and Pearl Research Labs Team Up to Reduce the Cost of AI Inference](/blog/together-ai-partners-with-pearl-research-labs)

![Together AI and Pearl Research Labs team up to reduce the cost of AI inference on a soft gradient background.](https://cdn.prod.website-files.com/69654e88dce9154b5f12070c/6a0742f027fc6f04110f6194_OG-image_20260508_Pearl.png)

Inference
Serving DeepSeek-V4: why million-token context is an inference systems problem
[Serving DeepSeek-V4: why million-token context is an inference systems problem](/blog/serving-deepseek-v4-why-million-token-context-is-an-inference-systems-problem)

![Together.ai banner with title: Serving DeepSeek-V4, why million-token context is an inference problem.](https://cdn.prod.website-files.com/69654e88dce9154b5f12070c/6a020ec791608508b7712c76_OG-image_20260508_Inference%20model%20from%20HuggingFace.png)

Inference
Deploy and inference any model from HuggingFace
[Deploy and inference any model from HuggingFace](/blog/deploy-and-inference-any-model-from-huggingface)

![Together.ai logo with text: Deploy and inference any model from HuggingFace on a pastel gradient background.](https://cdn.prod.website-files.com/69654e88dce9154b5f12070c/69fe1fddae13f7cd5cdc1a62_OG-image_20260508_Inference%20model%20from%20HuggingFace.png)

Inference
Foundational research powering efficient inference at scale
[Foundational research powering efficient inference at scale](/blog/foundational-research-powering-efficient-inference-at-scale)

![Text stating foundational research powering efficient inference at scale with together.ai logo on gradient background.](https://cdn.prod.website-files.com/69654e88dce9154b5f12070c/69f8d7922768e13db4223e31_OG-image_20260421_BLOG_Multi-tenantGPUclusters.png)

Inference
Introducing Dedicated Container Inference: Delivering 2.6x faster inference for custom AI models
[Introducing Dedicated Container Inference: Delivering 2.6x faster inference for custom AI models](/blog/dedicated-container-inference)

![Table listing Avatar versions 2.4, 2.3, 2.2 with statuses Ready, Running, and Ready.](https://cdn.prod.website-files.com/69654e88dce9154b5f12070c/699efbced035887c7fa5a827_Dedicater%20Container%20Inference.png)

Inference
Optimizing inference speed and costs: Lessons learned from large-scale deployments
[Optimizing inference speed and costs: Lessons learned from large-scale deployments](/blog/optimizing-inference-speed-and-costs)

![Graph showing trade-off between cost efficiency and inference speed with Pareto frontier and labeled providers.](https://cdn.prod.website-files.com/69654e88dce9154b5f12070c/69a5aba73d83955c3a6a4184_Optimizing%20inference%20speed%20and%20costs_%20Lessons%20learned%20from%20large-scale%20deployments.png)

Inference
Learn how Cursor partnered with Together AI to deliver real-time, low-latency inference at scale
[Learn how Cursor partnered with Together AI to deliver real-time, low-latency inference at scale](/blog/learn-how-cursor-partnered-with-together-ai-to-deliver-real-time-low-latency-inference-at-scale)

![https://cdn.prod.website-files.com/69654e88dce9154b5f12070c/6a2b36f0d8075daf9a06d0eb_OG-customer%20story-%20image-cursor.png](https://cdn.prod.website-files.com/69654e88dce9154b5f12070c/6a2b36f0d8075daf9a06d0eb_OG-customer%20story-%20image-cursor.png)

Inference
Together AI delivers fastest inference for the top open-source models
[Together AI delivers fastest inference for the top open-source models](/blog/fastest-inference-for-the-top-open-source-models)

![Bar chart comparing output speed of Together AI, Amazon, and Google Vertex with Together AI fastest.](https://cdn.prod.website-files.com/69654e88dce9154b5f12070c/699eef4879b9c4f903b194f9_Fastest_Inference.png)

Inference
Dynamic AI agent testing for the real world with Collinear Simulations and Together Evals
[Dynamic AI agent testing for the real world with Collinear Simulations and Together Evals](/blog/collinear-simulations-together-evals)

![Text about dynamic AI agent testing using Together AI Evals and Collinear Simulations with their logos.](https://cdn.prod.website-files.com/69654e88dce9154b5f12070c/699e0afe48d36bf43aab5a34_68ffc936ae8c1c434963686e_og-collinear-together-evals-2.png)

Inference
Improved Batch Inference API: Enhanced UI, Expanded Model Support, and 3000× Rate Limit Increase
[Improved Batch Inference API: Enhanced UI, Expanded Model Support, and 3000× Rate Limit Increase](/blog/batch-inference-api-updates-2025)

![Text saying together Batch Inference API and a description of running massive inference jobs with 30B tokens.](https://cdn.prod.website-files.com/69654e88dce9154b5f12070c/699e0afbe4dd430165404eef_68c83a2eef3a04dc23b16371_og-batch-inference-api.png)

Inference
Together Evaluations: Benchmark Models for Your Tasks
[Together Evaluations: Benchmark Models for Your Tasks](/blog/introducing-together-evaluations)

![Together.ai homepage heading with text: Benchmark models for your tasks and a blue Learn More button.](https://cdn.prod.website-files.com/69654e88dce9154b5f12070c/699e0b0b12498640ee9022da_6887b5accddbd065196279bd_Together%2520Evals.jpeg)

Inference
Together AI Delivers Top Speeds for DeepSeek-R1-0528 Inference on NVIDIA Blackwell
[Together AI Delivers Top Speeds for DeepSeek-R1-0528 Inference on NVIDIA Blackwell](/blog/fastest-inference-for-deepseek-r1-0528-with-nvidia-hgx-b200)

![Bar chart showing output speed in tokens/second of AI providers, ranging from Together.ai 355 to DeepSeek 23.](https://cdn.prod.website-files.com/69654e88dce9154b5f12070c/699e0b249316bdc90ac3ce79_687e47e6c42cdbfa75189725_og-deepseek-r1-output-speed-artificial-analysis.png)

Inference
Introducing the Together AI Batch API: Process Thousands of LLM Requests at 50% Lower Cost
[Introducing the Together AI Batch API: Process Thousands of LLM Requests at 50% Lower Cost](/blog/batch-api)

![https://cdn.prod.website-files.com/69654e88dce9154b5f1206dd/6aaaccf4dbfc99eb8d9e1f51_fallback-img-og.svg](https://cdn.prod.website-files.com/69654e88dce9154b5f1206dd/6aaaccf4dbfc99eb8d9e1f51_fallback-img-og.svg)

Inference
Introducing Together Code Sandbox & Together Code Interpreter: SOTA code execution for AI
[Introducing Together Code Sandbox & Together Code Interpreter: SOTA code execution for AI](/blog/code-sandbox-code-interpreter)

![Text on dark background: Introducing Together Code Sandbox Together Code Interpreter.](https://cdn.prod.website-files.com/69654e88dce9154b5f12070c/699e0afe06ef4ee4260b2e7e_682c4dd822e61e1323c49560_og-tcsb-tci.png)

Inference
Together Code Sandbox: the most robust infrastructure for building AI coding products at scale
[Together Code Sandbox: the most robust infrastructure for building AI coding products at scale](/blog/code-sandbox)

![Text 'Together Code Sandbox' with a diagram showing Agent and LLM connecting to Code Sandbox.](https://cdn.prod.website-files.com/69654e88dce9154b5f12070c/699e0afbfddf5b9301e34afc_682c4d7e14d4da2279334477_og-code-sandbox.png)

Inference
Together Code Interpreter: execute LLM-generated code seamlessly with a simple API call
[Together Code Interpreter: execute LLM-generated code seamlessly with a simple API call](/blog/code-interpreter)

![Text 'Together Code Interpreter' and diagram showing LLM generates code, TCI executes code, agent uses output.](https://cdn.prod.website-files.com/69654e88dce9154b5f12070c/699e0af8fc4cf8519cf2d9a4_681344a59fc26fceecb4bfad_og-code-interpreter.png)

Inference
Introducing Together Chat: use DeepSeek R1 for free, hosted in North America
[Introducing Together Chat: use DeepSeek R1 for free, hosted in North America](/blog/together-chat)

![Together.ai interface showing DeepSeek R1 chat answering a quantum physics question simply about particles.](https://cdn.prod.website-files.com/69654e88dce9154b5f12070c/699e0b225fc1f2fee15089ff_67e171e73b0c93ae0a0a6b7c_og-image-together-chat.png)

Inference
Deploy Leading AI Models Accelerated by NVIDIA NIM on Together AI
[Deploy Leading AI Models Accelerated by NVIDIA NIM on Together AI](/blog/nvidia-nim)

![Text says Deploy NVIDIA NIM Microservices to Together AI with a hexagonal icon of connected green nodes.](https://cdn.prod.website-files.com/69654e88dce9154b5f12070c/699e0b15bdaa0285edbe8350_67d962edae2f9137dfc7c250_20250305_NVIDIA_NIM_Microservices_OG_1200x630.jpeg)

Inference
On-demand dedicated endpoints: run inference with unmatched price-performance & control at scale
[On-demand dedicated endpoints: run inference with unmatched price-performance & control at scale](/blog/on-demand-dedicated-endpoints)

![Text about dedicated endpoints with an illustration of increasing blue cube stacks connected to a dial.](https://cdn.prod.website-files.com/69654e88dce9154b5f12070c/699e0b1567fc16b67c4f963e_67d33843f92f9f215f8c4f67_og-dedicated-endpoints.png)

Inference
Deploy DeepSeek-R1 at scale: Fast, secure serverless APIs and large-scale Together Reasoning Clusters
[Deploy DeepSeek-R1 at scale: Fast, secure serverless APIs and large-scale Together Reasoning Clusters](/blog/deploy-deepseek-r1-at-scale-fast-secure-serverless-apis-and-large-scale-together-reasoning-clusters)

![Text promoting DeepSeek-R1 deployment with fast, secure serverless APIs and large-scale Together Reasoning Clusters.](https://cdn.prod.website-files.com/69654e88dce9154b5f12070c/699e0b01c6ac41958d703442_67ace5d08267645540eee5e3_Together%2520Reasoning%2520Clusters%2520Blog%2520Image.png)

Inference
Generate images with specific styles using Flux LoRAs on Together AI
[Generate images with specific styles using Flux LoRAs on Together AI](/blog/generate-images-with-specific-styles-using-flux-loras-on-together-ai)

![Text about generating images with Flux LoRAs with pixel art, 3D, and line art llama styles and together.ai logo.](https://cdn.prod.website-files.com/69654e88dce9154b5f12070c/699e0b09b5c04b8ed13f76dd_6797db5f15a0cff2be05c649_FLUX%2520LoRAs%2520thumbnail.png)

Inference
Announcing Together Inference Engine 2.0 with new Turbo and Lite endpoints
[Announcing Together Inference Engine 2.0 with new Turbo and Lite endpoints](/blog/together-inference-engine-2)

![https://cdn.prod.website-files.com/69654e88dce9154b5f1206dd/6aaaccf4dbfc99eb8d9e1f51_fallback-img-og.svg](https://cdn.prod.website-files.com/69654e88dce9154b5f1206dd/6aaaccf4dbfc99eb8d9e1f51_fallback-img-og.svg)

Inference
Using Axiomic to build multi agent chat with Together API
[Using Axiomic to build multi agent chat with Together API](/blog/axiomatic-agents)

![https://cdn.prod.website-files.com/69654e88dce9154b5f1206dd/6aaaccf4dbfc99eb8d9e1f51_fallback-img-og.svg](https://cdn.prod.website-files.com/69654e88dce9154b5f1206dd/6aaaccf4dbfc99eb8d9e1f51_fallback-img-og.svg)

Inference
Announcing v1 of our Python SDK
[Announcing v1 of our Python SDK](/blog/python-sdk-v1)

![https://cdn.prod.website-files.com/69654e88dce9154b5f1206dd/6aaaccf4dbfc99eb8d9e1f51_fallback-img-og.svg](https://cdn.prod.website-files.com/69654e88dce9154b5f1206dd/6aaaccf4dbfc99eb8d9e1f51_fallback-img-og.svg)

Inference
Announcing function calling and JSON mode
[Announcing function calling and JSON mode](/blog/function-calling-json-mode)

![https://cdn.prod.website-files.com/69654e88dce9154b5f1206dd/6aaaccf4dbfc99eb8d9e1f51_fallback-img-og.svg](https://cdn.prod.website-files.com/69654e88dce9154b5f1206dd/6aaaccf4dbfc99eb8d9e1f51_fallback-img-og.svg)

Inference
Building your own RAG application using Together AI and MongoDB Atlas
[Building your own RAG application using Together AI and MongoDB Atlas](/blog/rag-tutorial-mongodb)

![https://cdn.prod.website-files.com/69654e88dce9154b5f1206dd/6aaaccf4dbfc99eb8d9e1f51_fallback-img-og.svg](https://cdn.prod.website-files.com/69654e88dce9154b5f1206dd/6aaaccf4dbfc99eb8d9e1f51_fallback-img-og.svg)

Inference
Building your own RAG application using Together AI and Langchain
[Building your own RAG application using Together AI and Langchain](/blog/rag-tutorial-langchain)

![https://cdn.prod.website-files.com/69654e88dce9154b5f1206dd/6aaaccf4dbfc99eb8d9e1f51_fallback-img-og.svg](https://cdn.prod.website-files.com/69654e88dce9154b5f1206dd/6aaaccf4dbfc99eb8d9e1f51_fallback-img-og.svg)

Inference
Building your own RAG application using Together AI and LlamaIndex
[Building your own RAG application using Together AI and LlamaIndex](/blog/rag-tutorial-llamaindex)

![https://cdn.prod.website-files.com/69654e88dce9154b5f1206dd/6aaaccf4dbfc99eb8d9e1f51_fallback-img-og.svg](https://cdn.prod.website-files.com/69654e88dce9154b5f1206dd/6aaaccf4dbfc99eb8d9e1f51_fallback-img-og.svg)

Inference
Introducing the Together Embeddings endpoint — Higher accuracy, longer context, and lower cost
[Introducing the Together Embeddings endpoint — Higher accuracy, longer context, and lower cost](/blog/embeddings-endpoint-release)

![https://cdn.prod.website-files.com/69654e88dce9154b5f1206dd/6aaaccf4dbfc99eb8d9e1f51_fallback-img-og.svg](https://cdn.prod.website-files.com/69654e88dce9154b5f1206dd/6aaaccf4dbfc99eb8d9e1f51_fallback-img-og.svg)

Inference
Filter responses of any model with Llama Guard or your own safety model
[Filter responses of any model with Llama Guard or your own safety model](/blog/safety-models)

![https://cdn.prod.website-files.com/69654e88dce9154b5f1206dd/6aaaccf4dbfc99eb8d9e1f51_fallback-img-og.svg](https://cdn.prod.website-files.com/69654e88dce9154b5f1206dd/6aaaccf4dbfc99eb8d9e1f51_fallback-img-og.svg)

Inference
Announcing Together Inference Engine – the fastest inference available
[Announcing Together Inference Engine – the fastest inference available](/blog/together-inference-engine-v1)

![https://cdn.prod.website-files.com/69654e88dce9154b5f1206dd/6aaaccf4dbfc99eb8d9e1f51_fallback-img-og.svg](https://cdn.prod.website-files.com/69654e88dce9154b5f1206dd/6aaaccf4dbfc99eb8d9e1f51_fallback-img-og.svg)

Inference
Announcing Together Custom Models. Build a state-of-the-art LLM with Together AI — and own the model.
[Announcing Together Custom Models. Build a state-of-the-art LLM with Together AI — and own the model.](/blog/announcing-together-custom-models)

![https://cdn.prod.website-files.com/69654e88dce9154b5f1206dd/6aaaccf4dbfc99eb8d9e1f51_fallback-img-og.svg](https://cdn.prod.website-files.com/69654e88dce9154b5f1206dd/6aaaccf4dbfc99eb8d9e1f51_fallback-img-og.svg)

Inference
Together AI launches full stack for developers to build with open-source AI
[Together AI launches full stack for developers to build with open-source AI](/blog/api-announcement)

![https://cdn.prod.website-files.com/69654e88dce9154b5f1206dd/6aaaccf4dbfc99eb8d9e1f51_fallback-img-og.svg](https://cdn.prod.website-files.com/69654e88dce9154b5f1206dd/6aaaccf4dbfc99eb8d9e1f51_fallback-img-og.svg)

Inference
RedPajama 7B now available, instruct model outperforms all open 7B models on HELM benchmarks
[RedPajama 7B now available, instruct model outperforms all open 7B models on HELM benchmarks](/blog/redpajama-7b)

![https://cdn.prod.website-files.com/69654e88dce9154b5f1206dd/6aaaccf4dbfc99eb8d9e1f51_fallback-img-og.svg](https://cdn.prod.website-files.com/69654e88dce9154b5f1206dd/6aaaccf4dbfc99eb8d9e1f51_fallback-img-og.svg)

Inference
RedPajama-INCITE-3B, an LLM for everyone
[RedPajama-INCITE-3B, an LLM for everyone](/blog/redpajama-3b-updates)

![https://cdn.prod.website-files.com/69654e88dce9154b5f1206dd/6aaaccf4dbfc99eb8d9e1f51_fallback-img-og.svg](https://cdn.prod.website-files.com/69654e88dce9154b5f1206dd/6aaaccf4dbfc99eb8d9e1f51_fallback-img-og.svg)

Inference
Releasing 3B and 7B RedPajama-INCITE family of models including base, instruction-tuned & chat models
[Releasing 3B and 7B RedPajama-INCITE family of models including base, instruction-tuned & chat models](/blog/redpajama-models-v1)

![https://cdn.prod.website-files.com/69654e88dce9154b5f1206dd/6aaaccf4dbfc99eb8d9e1f51_fallback-img-og.svg](https://cdn.prod.website-files.com/69654e88dce9154b5f1206dd/6aaaccf4dbfc99eb8d9e1f51_fallback-img-og.svg)

Inference
RedPajama, a project to create leading open-source models, starts by reproducing LLaMA training dataset of over 1.2 trillion tokens
[RedPajama, a project to create leading open-source models, starts by reproducing LLaMA training dataset of over 1.2 trillion tokens](/blog/redpajama)

![https://cdn.prod.website-files.com/69654e88dce9154b5f1206dd/6aaaccf4dbfc99eb8d9e1f51_fallback-img-og.svg](https://cdn.prod.website-files.com/69654e88dce9154b5f1206dd/6aaaccf4dbfc99eb8d9e1f51_fallback-img-og.svg)

Inference
OpenChatKit now runs on consumer GPUs with a new 7B parameter model
[OpenChatKit now runs on consumer GPUs with a new 7B parameter model](/blog/openchatkit-016)

![https://cdn.prod.website-files.com/69654e88dce9154b5f1206dd/6aaaccf4dbfc99eb8d9e1f51_fallback-img-og.svg](https://cdn.prod.website-files.com/69654e88dce9154b5f1206dd/6aaaccf4dbfc99eb8d9e1f51_fallback-img-og.svg)

Inference
Announcing OpenChatKit
[Announcing OpenChatKit](/blog/openchatkit)

![https://cdn.prod.website-files.com/69654e88dce9154b5f1206dd/6aaaccf4dbfc99eb8d9e1f51_fallback-img-og.svg](https://cdn.prod.website-files.com/69654e88dce9154b5f1206dd/6aaaccf4dbfc99eb8d9e1f51_fallback-img-og.svg)

Inference
LLM inference: how it works
[LLM inference: how it works](/blog/llm-inference)

![https://cdn.prod.website-files.com/69654e88dce9154b5f12070c/6acf702bab4cbd59bf10ebdf_OG-image_20261014-llm-inference.png](https://cdn.prod.website-files.com/69654e88dce9154b5f12070c/6acf702bab4cbd59bf10ebdf_OG-image_20261014-llm-inference.png)

Inference
KV cache explained: how it works and what it costs
[KV cache explained: how it works and what it costs](/blog/kv-cache)

![https://cdn.prod.website-files.com/69654e88dce9154b5f12070c/6acf7032ab4cbd59bf10ef6d_OG-image_20261014-kv-cache.png](https://cdn.prod.website-files.com/69654e88dce9154b5f12070c/6acf7032ab4cbd59bf10ef6d_OG-image_20261014-kv-cache.png)

Inference
What are LLMs? How large language models actually work
[What are LLMs? How large language models actually work](/blog/what-are-llms)

![https://cdn.prod.website-files.com/69654e88dce9154b5f12070c/6acf703a0a2983e19235be78_OG-image_20261014-what-are-llms.png](https://cdn.prod.website-files.com/69654e88dce9154b5f12070c/6acf703a0a2983e19235be78_OG-image_20261014-what-are-llms.png)

Inference
How to Build a State-of-the-Art Search Stack for LLMs: RAG, Reranking, and Reinforcement Learning
[How to Build a State-of-the-Art Search Stack for LLMs: RAG, Reranking, and Reinforcement Learning](/blog/sota-search-stack-for-llms)

![Text on dark background: How to Build a SOTA Search Stack for LLMs: RAG, Reranking, and RL](https://cdn.prod.website-files.com/69654e88dce9154b5f12070c/699e0b1b860aee83a8ab646d_6878ff8732a8b6b38ab34a87_og-sota-serach-stack.png)

Inference
Best practices to accelerate inference for large-scale production workloads
[Best practices to accelerate inference for large-scale production workloads](/blog/accelerate-inference-large-scale-workloads)

![https://cdn.prod.website-files.com/69654e88dce9154b5f12070c/6a39b54506a775b0dbbf2acd_OG-best-practices.jpg](https://cdn.prod.website-files.com/69654e88dce9154b5f12070c/6a39b54506a775b0dbbf2acd_OG-best-practices.jpg)

GPU Clusters
Auto repair for Together GPU Clusters: from GPU fault to healthy node
[Auto repair for Together GPU Clusters: from GPU fault to healthy node](/blog/auto-repair-for-together-gpu-clusters)

![Auto repair for Together GPU Clusters: from GPU fault to healthy node](https://cdn.prod.website-files.com/69654e88dce9154b5f12070c/6adfc9c7d8cc8003d466bf41_6adfc97703664d05b18f8202_og-auto-repair-together-gpu-clusters.png)

Model Shaping
Together Post-Training: frontier-grade model shaping, the way that fits you
[Together Post-Training: frontier-grade model shaping, the way that fits you](/blog/together-post-training)

![https://cdn.prod.website-files.com/69654e88dce9154b5f12070c/6ad63420bade9a234b1c0595_6ad6340405d0cf88b81a11a2_og-image-introducing-together-post-training.png](https://cdn.prod.website-files.com/69654e88dce9154b5f12070c/6ad63420bade9a234b1c0595_6ad6340405d0cf88b81a11a2_og-image-introducing-together-post-training.png)

Model Library
Meta Muse Spark Open is live on Together AI
[Meta Muse Spark Open is live on Together AI](/blog/meta-muse-spark-open)

![https://cdn.prod.website-files.com/69654e88dce9154b5f12070c/6ad05aa9a57ccc564b6563a1_TAI_Meta.png](https://cdn.prod.website-files.com/69654e88dce9154b5f12070c/6ad05aa9a57ccc564b6563a1_TAI_Meta.png)

Company
Expanding our enterprise inference capacity with IBM Cloud and NVIDIA
[Expanding our enterprise inference capacity with IBM Cloud and NVIDIA](/blog/expanding-our-enterprise-inference-capacity-with-ibm-cloud-and-nvidia)

![https://cdn.prod.website-files.com/69654e88dce9154b5f12070c/6ac5547dea69498dca307193_20261060_TAI_IBM_Cloud_and_NVIDIA.png](https://cdn.prod.website-files.com/69654e88dce9154b5f12070c/6ac5547dea69498dca307193_20261060_TAI_IBM_Cloud_and_NVIDIA.png)

Inference
Together Link: frontier-quality open models in the harness you already use
[Together Link: frontier-quality open models in the harness you already use](/blog/together-link-frontier-quality-open-models-in-the-harness-you-already-use)

![https://cdn.prod.website-files.com/69654e88dce9154b5f12070c/6ac396a5f8a841cbd899141c_Together_Link_Blog_Thumbnail_OG_1200x630.jpg](https://cdn.prod.website-files.com/69654e88dce9154b5f12070c/6ac396a5f8a841cbd899141c_Together_Link_Blog_Thumbnail_OG_1200x630.jpg)

Model Shaping
How to train your own Jev for $17
[How to train your own Jev for $17](/blog/how-to-train-your-own-jev)

![https://cdn.prod.website-files.com/69654e88dce9154b5f12070c/6ab471b0e7193297cc940874_20260923_How_to_train_your_own_Jev_for_%2417_BLOG.png](https://cdn.prod.website-files.com/69654e88dce9154b5f12070c/6ab471b0e7193297cc940874_20260923_How_to_train_your_own_Jev_for_%2417_BLOG.png)

Inference
Canary rollouts: upgrade models in production without downtime
[Canary rollouts: upgrade models in production without downtime](/blog/canary-rollouts-upgrade-models-in-production-without-downtime)

![https://cdn.prod.website-files.com/69654e88dce9154b5f12070c/6ab2084d400cf06357fcb03e_OG-image_202600921_canary-rollouts.png](https://cdn.prod.website-files.com/69654e88dce9154b5f12070c/6ab2084d400cf06357fcb03e_OG-image_202600921_canary-rollouts.png)

Inference
How a global fintech scaled coding agent traffic with Dedicated Model Inference
[How a global fintech scaled coding agent traffic with Dedicated Model Inference](/blog/global-fintech-scales-coding-agent-traffic-with-dedicated-model-inference)

![https://cdn.prod.website-files.com/69654e88dce9154b5f12070c/6aad615d591d02ae926847c5_OG-image_202600918_DMI%20blog_global%20fintech.png](https://cdn.prod.website-files.com/69654e88dce9154b5f12070c/6aad615d591d02ae926847c5_OG-image_202600918_DMI%20blog_global%20fintech.png)

Inference
Migrating from closed to open source models, Together
[Migrating from closed to open source models, Together](/blog/migrating-from-closed-to-open-source-models)

![https://cdn.prod.website-files.com/69654e88dce9154b5f12070c/6aaa2194c7f1b60b86e8fde5_OG-image_202600828_GLM53vsGLM53Flash.png](https://cdn.prod.website-files.com/69654e88dce9154b5f12070c/6aaa2194c7f1b60b86e8fde5_OG-image_202600828_GLM53vsGLM53Flash.png)

Model Shaping
Together AI expands fine-tuning service with more models, live metrics, and finer controls
[Together AI expands fine-tuning service with more models, live metrics, and finer controls](/blog/together-ai-expands-fine-tuning-service-with-more-models-live-metrics-and-finer-controls)

![https://cdn.prod.website-files.com/69654e88dce9154b5f12070c/6aa42433d784f308e607f1ae_OG-image_202600828_GLM53vsGLM53Flash%20(2).png](https://cdn.prod.website-files.com/69654e88dce9154b5f12070c/6aa42433d784f308e607f1ae_OG-image_202600828_GLM53vsGLM53Flash%20(2).png)

GPU Clusters
Introducing preemptible compute: the same compute, half the price
[Introducing preemptible compute: the same compute, half the price](/blog/introducing-preemptible-compute-the-same-compute-half-the-price)

![https://cdn.prod.website-files.com/69654e88dce9154b5f12070c/6aa2b2d5f51bb47d0473296d_6aa2b1b106394e7398efaee0_og-preemptible.png](https://cdn.prod.website-files.com/69654e88dce9154b5f12070c/6aa2b2d5f51bb47d0473296d_6aa2b1b106394e7398efaee0_og-preemptible.png)

Research
To Infinity and Beyond: ThunderKittens Now on NVIDIA Vera Rubin NVL72!
[To Infinity and Beyond: ThunderKittens Now on NVIDIA Vera Rubin NVL72!](/blog/to-infinity-and-beyond-thunderkittens-now-on-nvidia-vera-rubin-nvl72)

![https://cdn.prod.website-files.com/69654e88dce9154b5f12070c/6aa2b2cb17414168eba6644f_6aa2b1af1a441a9198313764_og-thunderkittens.png](https://cdn.prod.website-files.com/69654e88dce9154b5f12070c/6aa2b2cb17414168eba6644f_6aa2b1af1a441a9198313764_og-thunderkittens.png)

## Reference sources

- [Serving DeepSeek-V4 why million-token context is an inference systems](https://www.together.ai/blog/serving-deepseek-v4-why-million-token-context-is-an-inference-systems-problem) — accessed 2026-11-03
