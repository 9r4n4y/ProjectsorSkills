# DeepSeek-V4.1-Flash Pushing the Limits of KV Cache Compression  alphaX

:::quick-info
Source: https://www.alphaxiv.org/abs/2609.19969
Scraped: 2026-11-03
Topic: DeepSeek KV Cache
:::

DeepSeek-V4.1-Flash: Pushing the Limits of KV Cache Compression | alphaXiv

Abstract[Abstract](/abs/2609.19969)Paper[Paper](/pdf/2609.19969)

## Abstract

The widespread adoption of long-horizon agents has made model workloads increasingly input-heavy. Although prior work has substantially reduced the cost of long-context computation, prefill remains computationally expensive, and large KV caches continue to strain HBM and SSD capacity and data-transfer bandwidth. Together, these compute, storage, and bandwidth demands constitute the primary bottleneck to further lowering deployment costs. To address this challenge, we introduce DeepSeek-V4.1-Flash, a multimodal Mixture-of-Experts (MoE) model with 552B backbone parameters and support for contexts of up to one million tokens. With its Causal Encoder-Decoder (CED) architecture, the model activates 16B parameters per token during decode but only 8B parameters during prefill, substantially improving cost efficiency for agentic workloads. To push the limits of KV cache compression, DeepSeek-V4.1-Flash combines cross-layer KV cache reuse in Compressed Sparse Attention 2 (CSA2) with FP4 KV caching. These designs reduce its global KV cache footprint (always in HBM) to 890 bytes per token, roughly 1/4 of the corresponding footprint of DeepSeek-V4-Flash.[p 37 ] Further, through a dedicated deployment optimization known as SWA Bounded Replay, DeepSeek-V4.1-Flash reduces its persistent KV cache footprint (always on SSD or in host memory) to roughly 1/8 of that of DeepSeek-V4-Flash.[p 37 ] Despite its much smaller KV cache footprint, the model delivers substantially better performance than the baseline. In addition, we streamline the DeepSeek-V4 architecture and introduce several efficient architectural extensions. We pretrain DeepSeek-V4.1-Flash on a multimodal corpus comprising 45T tokens[p 22 ] and conduct comprehensive post-training, yielding strong performance across diverse text-based and multimodal agentic scenarios. Model checkpoints are available at this https URL.

Show more

View Paper[View Paper](/pdf/2609.19969)
722

Save

2
Cite

## AI Overview

Copy
Edit

DeepSeek-V4.1-Flash is a 552B-backbone multimodal model for long-horizon agents. A long-running agent repeatedly brings a large history back into service. Processing that history is not just a compute problem. The model must also keep, move, and reuse large key-value (KV) caches, the stored attention keys and values, under HBM, SSD, and bandwidth limits. Those constraints can limit serving throughput and make longer-running agents more expensive to deploy.[p 4 ]

V4.1 changes what is stored and what is rebuilt. At equal sequence lengths, the authors report 890 bytes per token for global KV held in HBM, roughly one-quarter of DeepSeek-V4-Flash's footprint. They also report persistent KV storage roughly one-eighth as large as V4-Flash's.[p 37 ] On DeepSWE v1.1, the model scores 74.2, versus 54.4 for DeepSeek-V4-Flash. This is evidence about the model's overall performance. It does not show that cache compression itself caused the gain, because V4.1 also changes architecture and post-training data.

![Two-panel figure: agent benchmark bars and global KV cache size per token across DeepSeek generations](https://paper-assets.alphaxiv.org/paper-figures/01a0b25d-cb2e-711d-bb5e-07c114912cee/01a0f995-7ee1-78dd-9504-0401939e4328.png)
(a) Agentic-benchmark performance. (b) Global KV-cache bytes per token, with roughly fourfold and 437-fold reductions versus V4-Flash and V1, respectively.[p 1 ]

## A cache problem, not just a compute problem

Prefill processes the prompt, and decode generates subsequent tokens. Long agent histories and repeated tool calls create input-heavy requests. The cache supports attention to prior tokens, but its size runs into two limits:

- Runtime HBM capacity constrains how much history can be served.

- Persistent SSD and host storage constrains how much history can be reused.

There are two kinds of cache. Global KV spans the context. Sliding-window attention (SWA) KV holds a bounded local window. These capacity and data-movement constraints can restrict throughput and cost even after sparse attention reduces long-context computation.[p 4 ]

## Share the global cache; rebuild the short-lived state

Splitting the backbone. V4.1's Causal Encoder–Decoder (CED) divides the 40-layer backbone into a 20-layer causal encoder and a 20-layer decoder. The decoder's global KV is projected from the final encoder hidden states. This lets the model use 8B active parameters per token during prefill and 16B during decode.[p 7 ] These are active-parameter counts, not measured elapsed time.

Sharing cache across layers. Compressed Sparse Attention 2 (CSA2) cuts duplicated global cache across layers. Two terms matter here. "Main KV" is the compressed global keys and values. "Top-K indices" are the selected context positions each query attends to. Each CSA2 layer works in one of three modes:

- Full: the layer makes main KV and fresh selections.

- Reindex: the layer reuses main KV and indexer keys but scores them with its own query to select new positions.

- Reuse: the layer inherits both main KV and the latest selections, while still computing its own query and SWA KV.[p 11 ]

Lower precision. Pairing CSA2 with FP4 quantization of the main KV gives the reported global-cache reduction. SWA KV remains FP8.[p 14 ]

![Three-panel diagram comparing CSA2 Full, Reindex, and Reuse modes](https://paper-assets.alphaxiv.org/paper-figures/01a0b25d-cb2e-711d-bb5e-07c114912cee/01a0f995-7ece-7de2-ab52-1dcfe92b21cd.png)
Three operating modes of CSA2: Full, Reindex, and Reuse. Green marks quantities computed in the current layer. Yellow marks main KV and indexer K reused from the most recent Full layer. Red marks Top-K indices reused from the latest index-producing layer. All three modes compute main Q and SWA KV in the current layer.[p 10 ]

## The storage saving has a reconstruction cost

Where SWA KV goes. In V4, SWA KV takes nearly half the persistent cache. Its short-lived reuse pattern differs from global KV's long-tail prefix reuse. V4.1 removes SWA KV from the persistent cache and keeps it instead in a distributed host-memory pool with a minutes-long time-to-live. Global KV remains in persistent storage.

Rebuilding missing state. Sometimes global KV hits but SWA KV is missing. In that case, Encoder SWA Bounded Replay recomputes only the most recent nwinn_{\text{win}}nwin​ tokens. Exact reconstruction would need the full L×nwinL \times n_{\text{win}}L×nwin​ tokens.[p 19 ] This bounds replay work, but it produces approximate state. By design, the replayed prefix state is not mathematically identical, and the authors report that it barely compromises response quality.[p 20 ] This is a storage–computation trade-off: bounded replay adds some prefill recomputation.

Benchmark result. On DeepSWE v1.1, under the paper's "Resolved" metric at maximum reasoning effort, V4.1-Flash scores 74.2. V4-Flash scores 54.4 and Opus-5 scores 74.0.[p 33 ] DeepSWE v1.1 uses the mini-SWE harness.[p 32 ] This result covers the full model and evaluation setup. The paper provides no clean ablation isolating each component's contribution to the scores.

## Smaller cache, open boundary

V4.1 treats long-context deployment as a joint storage-and-recomputation problem. It reports a substantially smaller cache footprint alongside strong evaluated agent performance. The authors caution that no finite test suite covers every case. Selection errors in CSA2 or approximate replay could still degrade capability at untested cache-resumption boundaries.[p 37 ]

## Audio

Audio summary

Re-generate the summary with our new system for an improved script, citations within the audio, and more.

Sign up to generate

0:00--:--

Show full transcript

## Similar papers

![https://thumbnails.assets.alphaxiv.org/512/019fe979-6c76-7174-8593-ab07ecb76841.png](https://thumbnails.assets.alphaxiv.org/512/019fe979-6c76-7174-8593-ab07ecb76841.png)
Kimi K3: Open Frontier Intelligence07 Aug 2026[Kimi K3: Open Frontier Intelligence07 Aug 2026](/abs/2607.24653)
![https://thumbnails.assets.alphaxiv.org/512/019a6bae-7393-7389-9798-354aa1ffb711.png](https://thumbnails.assets.alphaxiv.org/512/019a6bae-7393-7389-9798-354aa1ffb711.png)
Mixture-of-Recursions: Learning Dynamic Recursive Depths for Adaptive Token-Level Computation25 Oct 2025[Mixture-of-Recursions: Learning Dynamic Recursive Depths for Adaptive Token-Level Computation25 Oct 2025](/abs/2507.10524)
![https://thumbnails.assets.alphaxiv.org/512/019edddf-8373-78ea-8cf7-f5132b5e3fa6.png](https://thumbnails.assets.alphaxiv.org/512/019edddf-8373-78ea-8cf7-f5132b5e3fa6.png)
DeepSeek-V4: Towards Highly Efficient Million-Token Context Intelligence26 Apr 2026[DeepSeek-V4: Towards Highly Efficient Million-Token Context Intelligence26 Apr 2026](/abs/2606.19348)
![https://thumbnails.assets.alphaxiv.org/512/019ec8de-cdab-78d9-b7e9-dfe1f4a34bc5.png](https://thumbnails.assets.alphaxiv.org/512/019ec8de-cdab-78d9-b7e9-dfe1f4a34bc5.png)
MiniMax Sparse Attention12 Jun 2026[MiniMax Sparse Attention12 Jun 2026](/abs/2606.13392)
![https://thumbnails.assets.alphaxiv.org/512/01902f18-8ee8-72e3-99d2-5cfa54b3c4b3.png](https://thumbnails.assets.alphaxiv.org/512/01902f18-8ee8-72e3-99d2-5cfa54b3c4b3.png)
DeepSeek-V2: A Strong, Economical, and Efficient Mixture-of-Experts Language Model19 Jun 2024[DeepSeek-V2: A Strong, Economical, and Efficient Mixture-of-Experts Language Model19 Jun 2024](/abs/2405.04434)Show moreShow less

![https://thumbnails.assets.alphaxiv.org/512/019f82a1-4e49-763a-b39f-9027b2282600.png](https://thumbnails.assets.alphaxiv.org/512/019f82a1-4e49-763a-b39f-9027b2282600.png)
FlashMemory-DeepSeek-V4: Lightning Index Ultra-Long Context via Lookahead Sparse Attention20 Jul 2026[FlashMemory-DeepSeek-V4: Lightning Index Ultra-Long Context via Lookahead Sparse Attention20 Jul 2026](/abs/2606.09079)
![https://thumbnails.assets.alphaxiv.org/512/01951961-58c8-7f63-8acc-b9d85fda04be.png](https://thumbnails.assets.alphaxiv.org/512/01951961-58c8-7f63-8acc-b9d85fda04be.png)
MoBA: Mixture of Block Attention for Long-Context LLMs18 Feb 2025[MoBA: Mixture of Block Attention for Long-Context LLMs18 Feb 2025](/abs/2502.13189)
![https://thumbnails.assets.alphaxiv.org/512/018cf994-6830-7efa-80a3-aa041c9d9747.png](https://thumbnails.assets.alphaxiv.org/512/018cf994-6830-7efa-80a3-aa041c9d9747.png)
DeepSeekMoE: Towards Ultimate Expert Specialization in
Mixture-of-Experts Language Models11 Jan 2024[DeepSeekMoE: Towards Ultimate Expert Specialization in
Mixture-of-Experts Language Models11 Jan 2024](/abs/2401.06066)
![https://thumbnails.assets.alphaxiv.org/512/019bb0ad-f823-77f1-a148-7dfb534a5394.png](https://thumbnails.assets.alphaxiv.org/512/019bb0ad-f823-77f1-a148-7dfb534a5394.png)
MiMo-V2-Flash Technical Report08 Jan 2026[MiMo-V2-Flash Technical Report08 Jan 2026](/abs/2601.02780)
![https://thumbnails.assets.alphaxiv.org/512/01996f2a-0d7b-7a51-ab61-33331d321059.png](https://thumbnails.assets.alphaxiv.org/512/01996f2a-0d7b-7a51-ab61-33331d321059.png)
LongCat-Flash Technical Report19 Sep 2025[LongCat-Flash Technical Report19 Sep 2025](/abs/2509.01322)

## Discussion

2

Comment

Qh

Quốc Anh Nguyễn hoàngabout 1 month ago

Peak model

0
Reply

xs

xw sabout 1 month ago

excellment model

0
Reply

Sign in to save

## Reference sources

- [DeepSeek-V4.1-Flash Pushing the Limits of KV Cache Compression  alphaX](https://www.alphaxiv.org/abs/2609.19969) — accessed 2026-11-03
