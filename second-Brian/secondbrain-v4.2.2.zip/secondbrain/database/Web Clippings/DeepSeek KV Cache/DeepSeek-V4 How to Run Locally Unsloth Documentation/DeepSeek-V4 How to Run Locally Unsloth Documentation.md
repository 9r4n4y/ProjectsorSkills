# DeepSeek-V4 How to Run Locally  Unsloth Documentation

:::quick-info
Source: https://unsloth.ai/docs/models/deepseek-v4
Scraped: 2026-11-03
Topic: DeepSeek KV Cache
:::

DeepSeek-V4: How to Run Locally | Unsloth Documentation

Introducing Unsloth Desktop: the first local app to run & train models
✨Read more[Introducing Unsloth Desktop: the first local app to run & train models✨Read more](/docs/desktop)

For the complete documentation index, see llms.txt[llms.txt](https://unsloth.ai/docs/llms.txt). This page is also available as Markdown[Markdown](https://unsloth.ai/docs/models/deepseek-v4.md).

DeepSeek-V4, DeepSeek-V4-Flash-Vision-Exp, V4-Pro-0813, and V4-Flash-0731 are new open-weight models - the Flash variant has 284B parameters (13B active), while V4-Pro has 1.6T (49B active). V4-Pro-0813, released on Aug 13, matches Claude-4.8-Opus performance, while V4-Flash-0731, released on July 31, delivers the best performance in its size class and outperforms V4-Pro (Preview). Built for coding, agentic, and chat workflows with a 1M context window, this guide shows how to run DeepSeek-V4-Flash-0731 locally using Unsloth Dynamic GGUFs and Unsloth Desktop[Unsloth Desktop](/docs/desktop).

For lossless DeepSeek, use Q8 (UD-Q8_K_XL), which is only 7GB larger than Q4 (UD-Q4_K_XL). The lossless 8-bit GGUF is 162 GB and 3-bit is 103GB which can run on a 110GB RAM device . DeepSeek-V4-Flash-0731 scores 82.7% on Terminal Bench 2.1, 54.4% on DeepSWE, and 54.2% on NL2Repo. DSpark[DSpark](/docs/models/deepseek-v4#dspark-speculative-decoding) is also enabled for GGUFs, enabling up to 2x faster decoding speed!

Aug 31: DeepSeek-Flash-Vision-Exp is now available!

Aug 13: DeepSeek-V4-Pro-0813 was released and quants are now[quants are now](https://huggingface.co/unsloth/DeepSeek-V4-Pro-0813-GGUF) available to run.

Aug 6: DSpark is enabled for DeepSeek-V4-Flash-0731 - enabling 1.5x to 1.9x faster inference! DSpark is automatically enabled in Unsloth[Unsloth](/docs/models/deepseek-v4#unsloth-studio-guide).

We also improved the DeepSeek-V4 chat jinja template[DeepSeek-V4 chat jinja template](/docs/models/deepseek-v4#deepseek-v4-chat-template-improvements), and tested over 4000 conversations to be equivalent with the official baseline.

DeepSeek-V4-Pro-0813-GGUF[DeepSeek-V4-Pro-0813-GGUF](https://huggingface.co/unsloth/DeepSeek-V4-Pro-0813-GGUF)

DeepSeek-V4-Flash-0731-GGUF[DeepSeek-V4-Flash-0731-GGUF](https://huggingface.co/unsloth/DeepSeek-V4-Flash-0731-GGUF)

DeepSeek-V4-Flash-GGUF[DeepSeek-V4-Flash-GGUF](https://huggingface.co/unsloth/DeepSeek-V4-Flash-GGUF)

Usage Guide[Usage Guide](/docs/models/deepseek-v4#usage-guide)Running Tutorials[Running Tutorials](/docs/models/deepseek-v4#run-deepseek-v4-flash-tutorials)

### 📊 Quantization Analysis

Our UD-Q8_K_XL quant is fully lossless. DeepSeek-V4-Flash is quantization-aware-trained[quantization-aware-trained](/docs/blog/quantization-aware-training-qat): the official checkpoint stores its routed experts (96% of the model) natively in MXFP4 and everything else in FP8 or BF16. GGUF's MXFP4 is exactly that format, so we repack the experts bit-for-bit, and FP8 dequantizes into BF16 with no rounding. We checked every tensor against the official DeepSeek weights: all 1,328 are bit-identical, and it stays lossless at inference (KL-divergence ~0, 100% top-token agreement).

Non-Unsloth DeepSeek-V4-Flash GGUFs were converted without these paths thus deviating from the official weights. UD-Q4_K_XL keeps the same bit-exact experts and only quantizes the non-expert tensors (4% of the model) to Q8_0, so it sits right next to Q8 in size and quality.

![https://unsloth.ai/docs/~gitbook/image?url=https%3A%2F%2F3215535692-files.gitbook.io%2F%7E%2Ffiles%2Fv0%2Fb%2Fgitbook-x-prod.appspot.com%2Fo%2Fspaces%252FxhOjnexMCB3dmuQFQ2Zq%252Fuploads%252FXjXSVsiH2ZIKlJ7iZPDx%252Fkldddd.webp%3Falt%3Dmedia%26token%3De1db5fca-b2b4-411e-8956-29127ef6bfe0&width=768&dpr=3&quality=100&sign=d344a442323eadd94646c9d4b6ef17a1&sv=3](https://unsloth.ai/docs/~gitbook/image?url=https%3A%2F%2F3215535692-files.gitbook.io%2F%7E%2Ffiles%2Fv0%2Fb%2Fgitbook-x-prod.appspot.com%2Fo%2Fspaces%252FxhOjnexMCB3dmuQFQ2Zq%252Fuploads%252FXjXSVsiH2ZIKlJ7iZPDx%252Fkldddd.webp%3Falt%3Dmedia%26token%3De1db5fca-b2b4-411e-8956-29127ef6bfe0&width=768&dpr=3&quality=100&sign=d344a442323eadd94646c9d4b6ef17a1&sv=3)

![https://unsloth.ai/docs/~gitbook/image?url=https%3A%2F%2F3215535692-files.gitbook.io%2F%7E%2Ffiles%2Fv0%2Fb%2Fgitbook-x-prod.appspot.com%2Fo%2Fspaces%252FxhOjnexMCB3dmuQFQ2Zq%252Fuploads%252FHoYuIu6dNNuLrM4nmdbi%252Fpareto.png%3Falt%3Dmedia%26token%3D1c7a44bb-13c3-4fc4-8d57-fb350ffe3c14&width=768&dpr=3&quality=100&sign=341ac15ac8d65916efaf8bd5e0db03b2&sv=3](https://unsloth.ai/docs/~gitbook/image?url=https%3A%2F%2F3215535692-files.gitbook.io%2F%7E%2Ffiles%2Fv0%2Fb%2Fgitbook-x-prod.appspot.com%2Fo%2Fspaces%252FxhOjnexMCB3dmuQFQ2Zq%252Fuploads%252FHoYuIu6dNNuLrM4nmdbi%252Fpareto.png%3Falt%3Dmedia%26token%3D1c7a44bb-13c3-4fc4-8d57-fb350ffe3c14&width=768&dpr=3&quality=100&sign=341ac15ac8d65916efaf8bd5e0db03b2&sv=3)

Measured against the official weights, both Unsloth quants are on the quality/size frontier. UD-Q8_K_XL is the only lossless point. UD-Q4_K_XL matches other community MXFP4 formats and is more accurate than the Q4_K-experts conversions, which are larger yet land at 0.029 KLD.

![https://unsloth.ai/docs/~gitbook/image?url=https%3A%2F%2F3215535692-files.gitbook.io%2F%7E%2Ffiles%2Fv0%2Fb%2Fgitbook-x-prod.appspot.com%2Fo%2Fspaces%252FxhOjnexMCB3dmuQFQ2Zq%252Fuploads%252FxW5lIQID1dIRlVajHSWm%252Fper_layer.png%3Falt%3Dmedia%26token%3D94dd4abc-e7ef-4aa8-8d2f-de8c98a69166&width=768&dpr=3&quality=100&sign=e401d8cba751bc3898bc4fe29c1fba88&sv=3](https://unsloth.ai/docs/~gitbook/image?url=https%3A%2F%2F3215535692-files.gitbook.io%2F%7E%2Ffiles%2Fv0%2Fb%2Fgitbook-x-prod.appspot.com%2Fo%2Fspaces%252FxhOjnexMCB3dmuQFQ2Zq%252Fuploads%252FxW5lIQID1dIRlVajHSWm%252Fper_layer.png%3Falt%3Dmedia%26token%3D94dd4abc-e7ef-4aa8-8d2f-de8c98a69166&width=768&dpr=3&quality=100&sign=e401d8cba751bc3898bc4fe29c1fba88&sv=3)

The error split by layer shows why. Keeping the native MXFP4 experts means 0% weight error at every layer. Conversions that re-quantize the experts to Q4_K or IQ2_XXS round almost every weight: 5% for Q4_K, over 30% for IQ2_XXS.

![https://unsloth.ai/docs/~gitbook/image?url=https%3A%2F%2F3215535692-files.gitbook.io%2F%7E%2Ffiles%2Fv0%2Fb%2Fgitbook-x-prod.appspot.com%2Fo%2Fspaces%252FxhOjnexMCB3dmuQFQ2Zq%252Fuploads%252FINDS7DqyP9TUAs4Bj9rS%252Fwhy_lossless.png%3Falt%3Dmedia%26token%3Defdb261b-f969-42b8-89ec-bc25e8bbdaf3&width=768&dpr=3&quality=100&sign=75f2372d7d827811b1a33c1ecf1afd2c&sv=3](https://unsloth.ai/docs/~gitbook/image?url=https%3A%2F%2F3215535692-files.gitbook.io%2F%7E%2Ffiles%2Fv0%2Fb%2Fgitbook-x-prod.appspot.com%2Fo%2Fspaces%252FxhOjnexMCB3dmuQFQ2Zq%252Fuploads%252FINDS7DqyP9TUAs4Bj9rS%252Fwhy_lossless.png%3Falt%3Dmedia%26token%3Defdb261b-f969-42b8-89ec-bc25e8bbdaf3&width=768&dpr=3&quality=100&sign=75f2372d7d827811b1a33c1ecf1afd2c&sv=3)
Our MXFP4 has exactly zero error on all 8.4M weights, while Q4_K, a different 4-bit grid, must round each one (5.2% RMSE).

We also found using Q8_0 and F16 for some tensors is not lossless, and it gets worse since QAT was applied by DeepSeek to make MXFP4 / FP8 work well, so we had to leave them in BF16 directly. So use UD-Q8_K_XL for a true lossless quant, and UD-Q4_K_XL downcasts some of the BF16 items to Q8_0.

For full benchmark tables of GGUF Benchmarks, see here[GGUF Benchmarks, see here](/docs/models/deepseek-v4#gguf-benchmarks).

### 💬 DeepSeek V4 Chat template improvements

We also improved the DeepSeek-V4 chat jinja template, and tested over 4000 conversations to be equivalent with the golden baseline (official DS4)

We added reasoning_effort and you can select max, high just like official DeepSeek-V4. We prepend the correct system prompt as per DS4, and followed gpt-oss's style.

And for tool calls, reasoning_content was retained for DS4, but the jinja chat template would exclude them. We added it back.

#### Disabling Thinking, changing reasoning effort

DeepSeek-V4 uses reasoning by default. It also supports reasoning efforts where reasoning_effort can be "high", "max" or disabled.

To disable thinking, use --chat-template-kwargs '{"enable_thinking":false}'. If you're on Windows Powershell, use: --chat-template-kwargs "{\"enable_thinking\":false}"

You can also use --reasoning on or --reasoning off in llama.cpp as well now!

For reasoning effort customization and or to disable reasoning, use the below examples:

### ⚙️ Usage Guide

DeepSeek-V4-Flash is smaller and faster than DeepSeek-V4-Pro, with 284B parameters (13B active), and a 1M context window. The model has 3 modes, Non-think, Think High and Think Max.

It's recommended to use UD-IQ3_XXS which is 103GB for best results. Because the file size does not include KV cache, context allocation, try to have at least 110GB RAM to run the model.

The UD-Q8_K_XL quant is DeepSeek-V4-Flash in full original precision. It is 162GB size and it's best to have at least 169GB of available RAM/VRAM available.

Table: Inference hardware requirements (units = total memory: RAM + VRAM, or unified memory)

Format
1-bit
2-bit
3-bit
4-bit (near Lossless)
Q8_K_XL (Lossless)

Standard

92 GB

102 GB

110-135 GB

162 GB

169 GB

DSpark

102 GB

112 GB

120-145 GB

172 GB

179 GB

DSpark uses more VRAM than standard, so plan for ~10 GB additional RAM/VRAM headroom.

For best performance, make sure your total available memory, including VRAM and system RAM, exceeds the quantized model file size by a comfortable margin.

### Recommended Settings

DeepSeek recommends these parameters for best performance: temperature = 1.0, top-p = 1.0. For DeepSeek-V4-Flash-0731 and agentic scenarios, top-p = 0.95 is suggested instead and top-p = 1.0 for other tasks.

Think High is on by default. If disabled, you can enable it via: --chat-template-kwargs '{"enable_thinking":true}' or toggle it via the UI dropdown in Unsloth[Unsloth](/docs/models/deepseek-v4#unsloth-studio-guide). Also see DeepSeek V4 Chat template improvements[DeepSeek V4 Chat template improvements](/docs/models/deepseek-v4#deepseek-v4-chat-template-improvements)

DeepSeek-V4-Flash-0731

temperature = 1.0

top-p = 1.0

top-p = 0.95 (agentic only)

Old DeepSeek-V4-Flash and V4-Pro

temperature = 1.0

top-p = 1.0

-

Maximum context window: 1,048,576

-

For Think Max, set context to at least 384K tokens.

## Run DeepSeek-V4-Flash Tutorials:

For this tutorial, we will use the 3-bit quant UD-IQ3_XXS, as it fits on a 128GB RAM device. Replace UD-IQ3_XXS with UD-Q8_K_XL (original quality) or another quant if your machine has enough memory. You can now run DeepSeek-V4-Flash-0731 in Unsloth Desktop[Unsloth Desktop](/docs/models/deepseek-v4#run-in-unsloth-studio) . DSpark is automatically enabled in Unsloth[Unsloth](/docs/models/deepseek-v4#unsloth-studio-guide).

🦥 Unsloth Guide[🦥 Unsloth Guide](/docs/models/deepseek-v4#unsloth-studio-guide)🦙 Llama.cpp Guide[🦙 Llama.cpp Guide](/docs/models/deepseek-v4#llama.cpp-guide)⚡DSpark Guide[⚡DSpark Guide](/docs/models/deepseek-v4#dspark-speculative-decoding)

### 🦥 Unsloth Guide

DeepSeek-V4-Flash-0731 can now be run and trained in Unsloth[Unsloth](/docs/new/studio), our new open-source UI for local AI. Unsloth Desktop lets you run models locally on MacOS, Windows, Linux and:

-

Search, download, run GGUFs[run GGUFs](/docs/new/studio#run-models-locally) and safetensor models

-

Self-healing tool calling[Self-healing tool calling](/docs/new/studio#execute-code--heal-tool-calling) + web search

-

Code execution[Code execution](/docs/new/studio#run-models-locally) (Python, Bash)

-

Automatic inference[Automatic inference](https://unsloth.ai/docs/desktop#feature-deep-dive) parameter tuning (temp, top-p, etc.)

-

Fast CPU + GPU inference via llama.cpp

-

Train LLMs[Train LLMs](/docs/new/studio#no-code-training) 2x faster with 70% less VRAM

![https://unsloth.ai/docs/~gitbook/image?url=https%3A%2F%2F3215535692-files.gitbook.io%2F%7E%2Ffiles%2Fv0%2Fb%2Fgitbook-x-prod.appspot.com%2Fo%2Fspaces%252FxhOjnexMCB3dmuQFQ2Zq%252Fuploads%252FCwcXvmLERJSUNF6iNTiY%252Fdeepseek-v4-flash-0731-unsloth-studio.png%3Falt%3Dmedia%26token%3D6fdc0216-d21e-42e7-bb57-8e1abf6e7f4f&width=768&dpr=3&quality=100&sign=c59c9a2a962440a07f94f108c678cd52&sv=3](https://unsloth.ai/docs/~gitbook/image?url=https%3A%2F%2F3215535692-files.gitbook.io%2F%7E%2Ffiles%2Fv0%2Fb%2Fgitbook-x-prod.appspot.com%2Fo%2Fspaces%252FxhOjnexMCB3dmuQFQ2Zq%252Fuploads%252FCwcXvmLERJSUNF6iNTiY%252Fdeepseek-v4-flash-0731-unsloth-studio.png%3Falt%3Dmedia%26token%3D6fdc0216-d21e-42e7-bb57-8e1abf6e7f4f&width=768&dpr=3&quality=100&sign=c59c9a2a962440a07f94f108c678cd52&sv=3)

1

#### Install Unsloth

The easiest way to get started is by downloading the Unsloth Desktop app[Unsloth Desktop app](/docs/desktop). Works on macOS[macOS](/docs/get-started/install/mac), Windows[Windows](/docs/get-started/install/windows-installation), and Linux[Linux](/docs/get-started/install/linux).

Download Unsloth[Download Unsloth](https://unsloth.ai/download)

-

Download for macOS[Download for macOS](https://unsloth.ai/download/mac)

-

Download for Windows[Download for Windows](https://unsloth.ai/download/windows)

-

Download for Linux[Download for Linux](https://unsloth.ai/download/linux)

Or, if you prefer to install manually:

MacOS, Linux, WSL:

Windows PowerShell:

2

#### Search and download DeepSeek-V4-Flash

Go to Unsloth Chat[Unsloth Chat](/docs/new/studio/chat) or Model hub and search for DeepSeek-V4-Flash in the search bar and download your desired model and quant.

![https://unsloth.ai/docs/~gitbook/image?url=https%3A%2F%2F3215535692-files.gitbook.io%2F%7E%2Ffiles%2Fv0%2Fb%2Fgitbook-x-prod.appspot.com%2Fo%2Fspaces%252FxhOjnexMCB3dmuQFQ2Zq%252Fuploads%252FGEc90VxPAgTHulQe9zB0%252FScreenshot%25202026-07-31%2520at%25208.01.35%25E2%2580%25AFAM.png%3Falt%3Dmedia%26token%3D2931411d-8f75-4bfe-918a-73fcafe918f9&width=768&dpr=3&quality=100&sign=8366775af78e015ed2d84aeb16824740&sv=3](https://unsloth.ai/docs/~gitbook/image?url=https%3A%2F%2F3215535692-files.gitbook.io%2F%7E%2Ffiles%2Fv0%2Fb%2Fgitbook-x-prod.appspot.com%2Fo%2Fspaces%252FxhOjnexMCB3dmuQFQ2Zq%252Fuploads%252FGEc90VxPAgTHulQe9zB0%252FScreenshot%25202026-07-31%2520at%25208.01.35%25E2%2580%25AFAM.png%3Falt%3Dmedia%26token%3D2931411d-8f75-4bfe-918a-73fcafe918f9&width=768&dpr=3&quality=100&sign=8366775af78e015ed2d84aeb16824740&sv=3)

3

#### Run DeepSeek-V4-Flash-0731

Inference parameters should be auto-set when using Unsloth, however you can still change it manually. Because Think High is on by default, you can go to the right dropdown to toggle it to Non-think or Think Max. You can also edit the context length, chat template and other settings. DSpark is automatically enabled in Unsloth[Unsloth](/docs/models/deepseek-v4#unsloth-studio-guide).

For more information, you can view our Unsloth inference guide[Unsloth inference guide](/docs/new/studio/chat).

![https://unsloth.ai/docs/~gitbook/image?url=https%3A%2F%2F3215535692-files.gitbook.io%2F%7E%2Ffiles%2Fv0%2Fb%2Fgitbook-x-prod.appspot.com%2Fo%2Fspaces%252FxhOjnexMCB3dmuQFQ2Zq%252Fuploads%252FlvJqDRKlWdAVkn3HXJZA%252F1000024247.png%3Falt%3Dmedia%26token%3De84fd31d-7720-40d5-aba1-ba65ac34ce97&width=768&dpr=3&quality=100&sign=43e44601915bec062bad672ae5b916a4&sv=3](https://unsloth.ai/docs/~gitbook/image?url=https%3A%2F%2F3215535692-files.gitbook.io%2F%7E%2Ffiles%2Fv0%2Fb%2Fgitbook-x-prod.appspot.com%2Fo%2Fspaces%252FxhOjnexMCB3dmuQFQ2Zq%252Fuploads%252FlvJqDRKlWdAVkn3HXJZA%252F1000024247.png%3Falt%3Dmedia%26token%3De84fd31d-7720-40d5-aba1-ba65ac34ce97&width=768&dpr=3&quality=100&sign=43e44601915bec062bad672ae5b916a4&sv=3)

4

#### Serve DeepSeek-V4 with Unsloth API

You can use unsloth run command and serve DeepSeek via an API using llama-server runtime flags, including context sizing, GPU layers, threading, sampling, networking, and tool configuration. For more info see our API docs[API docs](/docs/basics/api) or unsloth start[unsloth start](/docs/integrations/unsloth-start).

5

#### Unsloth is now ready

You can also do many other things with DeepSeek via Unsloth Desktop like:

-

Connect tools: Claude Code[Claude Code](/docs/basics/claude-code), Codex[Codex](/docs/basics/codex), web search[web search](/docs/new/studio/chat#advanced-web-search), MCP[MCP](/docs/basics/mcp) and more

-

Train models: Fine-tune text, diffusion, embedding[embedding](/docs/basics/embedding-finetuning), and more

-

Generate media: Create and train images[images](/docs/basics/diffusion-image), video, TTS[TTS](/docs/basics/text-to-speech-tts-fine-tuning) locally

### 🦙 Llama.cpp Guide

1

Obtain the latest llama.cpp on GitHub here[GitHub here](https://github.com/ggml-org/llama.cpp). You can follow the build instructions below as well. Change -DGGML_CUDA=ON to -DGGML_CUDA=OFF if you don't have a GPU or just want CPU inference. For Apple Mac / Metal devices, set -DGGML_CUDA=OFF then continue as usual - Metal support is on by default.

2

You can now use llama.cpp directly to load and download models, just like ollama run. First, select the quantization type you want like IQ3_XXS. Also use export LLAMA_CACHE="folder" to force llama.cpp to save to a specific location. Note this download process might be very slow, so it's probably best to use the manual download process in the next section.

3

If you want to download the model manually, we can download the model via the code below (after installing pip install huggingface_hub). If downloads get stuck, see: Hugging Face Hub, XET debugging[Hugging Face Hub, XET debugging](/docs/basics/troubleshooting-and-faqs/hugging-face-hub-xet-debugging)

4

You can edit --threads 32 for the number of CPU threads, --ctx-size 32768 for context length, --n-gpu-layers 2 for GPU offloading on how many layers. Try adjusting it if your GPU goes out of memory. Also remove it if you have CPU only inference.

## ⚡DSpark - Speculative Decoding

DeepSeek-V4-Flash-0731 has native DSpark, which allows for up to 2x faster decoding speed! DSpark is a new algorithm by DeepSeek that is superior to naive MTP, and was introduced in this paper[paper](https://arxiv.org/abs/2607.05147). DSpark enables DeepSeek-V4-Flash to reach 120 tokens/s on a B200 GPU compared to the original 60 tokens/s baseline. DSpark is automatically enabled in the Unsloth[Unsloth](/docs/models/deepseek-v4#unsloth-studio-guide) local UI.

Llama.cpp integrated DSpark as part of PR 25784[PR 25784](https://github.com/ggml-org/llama.cpp/pull/25784) with further improvements to multi GPU and more. We show using --spec-draft-n-max 3 as a good default, allowing 1.9x faster inference speed. Larger values seem to be slower.

![https://unsloth.ai/docs/~gitbook/image?url=https%3A%2F%2F3215535692-files.gitbook.io%2F%7E%2Ffiles%2Fv0%2Fb%2Fgitbook-x-prod.appspot.com%2Fo%2Fspaces%252FxhOjnexMCB3dmuQFQ2Zq%252Fuploads%252FRV0T1cVPpCnacNnywAsL%252Fimage.png%3Falt%3Dmedia%26token%3Db570026f-4577-4a45-936f-98a650d644ac&width=768&dpr=3&quality=100&sign=0216127a72a638fd979d1ceb5ecf3bc7&sv=3](https://unsloth.ai/docs/~gitbook/image?url=https%3A%2F%2F3215535692-files.gitbook.io%2F%7E%2Ffiles%2Fv0%2Fb%2Fgitbook-x-prod.appspot.com%2Fo%2Fspaces%252FxhOjnexMCB3dmuQFQ2Zq%252Fuploads%252FRV0T1cVPpCnacNnywAsL%252Fimage.png%3Falt%3Dmedia%26token%3Db570026f-4577-4a45-936f-98a650d644ac&width=768&dpr=3&quality=100&sign=0216127a72a638fd979d1ceb5ecf3bc7&sv=3)

Download both the drafter and the GGUF - we made 2 Q8_0 and the lossless BF16 one. Note DSpark will need ~10GB more memory usage, so 128GB machines will need IQ3_XXS and Q8_0

Then load it via llama-cli or llama-server:

Benchmarks from the original DSpark paper as well showing how it fares against MTP:

![https://unsloth.ai/docs/~gitbook/image?url=https%3A%2F%2F3215535692-files.gitbook.io%2F%7E%2Ffiles%2Fv0%2Fb%2Fgitbook-x-prod.appspot.com%2Fo%2Fspaces%252FxhOjnexMCB3dmuQFQ2Zq%252Fuploads%252FNXmTkimQGD9JzAq4OtK9%252Fimage.png%3Falt%3Dmedia%26token%3Dbab3816c-e3cd-4bd8-a234-6226520f45f6&width=768&dpr=3&quality=100&sign=9d5b61619acdababaab0e2726fbbeac9&sv=3](https://unsloth.ai/docs/~gitbook/image?url=https%3A%2F%2F3215535692-files.gitbook.io%2F%7E%2Ffiles%2Fv0%2Fb%2Fgitbook-x-prod.appspot.com%2Fo%2Fspaces%252FxhOjnexMCB3dmuQFQ2Zq%252Fuploads%252FNXmTkimQGD9JzAq4OtK9%252Fimage.png%3Falt%3Dmedia%26token%3Dbab3816c-e3cd-4bd8-a234-6226520f45f6&width=768&dpr=3&quality=100&sign=9d5b61619acdababaab0e2726fbbeac9&sv=3)

## 📊 Benchmarks

### GGUF Benchmarks

See below for a table comparing benchmarks for quants from Unsloth and other providers. Reference = official weights. Perplexity and KL-divergence over wikitext-2 at ctx 512 on 4x B200.

![https://unsloth.ai/docs/~gitbook/image?url=https%3A%2F%2F3215535692-files.gitbook.io%2F%7E%2Ffiles%2Fv0%2Fb%2Fgitbook-x-prod.appspot.com%2Fo%2Fspaces%252FxhOjnexMCB3dmuQFQ2Zq%252Fuploads%252FXjXSVsiH2ZIKlJ7iZPDx%252Fkldddd.webp%3Falt%3Dmedia%26token%3De1db5fca-b2b4-411e-8956-29127ef6bfe0&width=768&dpr=3&quality=100&sign=d344a442323eadd94646c9d4b6ef17a1&sv=3](https://unsloth.ai/docs/~gitbook/image?url=https%3A%2F%2F3215535692-files.gitbook.io%2F%7E%2Ffiles%2Fv0%2Fb%2Fgitbook-x-prod.appspot.com%2Fo%2Fspaces%252FxhOjnexMCB3dmuQFQ2Zq%252Fuploads%252FXjXSVsiH2ZIKlJ7iZPDx%252Fkldddd.webp%3Falt%3Dmedia%26token%3De1db5fca-b2b4-411e-8956-29127ef6bfe0&width=768&dpr=3&quality=100&sign=d344a442323eadd94646c9d4b6ef17a1&sv=3)

Quant
Size (GB)
PPL
Mean KLD
RMS delta-p
Same top token
Bit-exact weights

Official (reference)

156.4

4.5319

0

0%

100%

100%

Unsloth UD-Q8_K_XL

161.9

4.5319

~0 (lossless)

0.000%

100.000%

100.000%

Unsloth UD-Q4_K_XL

155.1

4.5335

0.0102

3.40%

96.28%

97.46%

bartowski MXFP4

156.0

4.5351

0.0105

3.42%

96.18%

97.57%

antirez Q4KExperts-F16 (imatrix)

164.6

4.5743

0.0291

5.87%

93.95%

0.51%

antirez Q4KExperts-F16

164.6

4.5726

0.0290

5.89%

93.94%

0.93%

antirez mixed L37-42-Q4K (imatrix)

97.6

5.8169

0.3605

21.15%

79.74%

0.41%

antirez IQ2XXS (imatrix)

86.7

6.0808

0.4079

22.23%

78.15%

0.39%

antirez IQ2XXS

86.7

6.1518

0.4207

22.74%

77.92%

0.47%

### Official Benchmarks

DeepSeek-V4-Flash-0731 outperforms DeepSeek-V4-Pro (Preview) on the benchmarks below despite using far fewer activated parameters, and remains competitive with leading proprietary models.

Benchmark
DeepSeek-V4-Flash-0731
DeepSeek-V4-Flash (Preview)
DeepSeek-V4-Pro (Preview)
GLM-5.2
Opus-4.8

Terminal Bench 2.1

82.7

61.8

72.1

81.0

85.0

NL2Repo

54.2

39.4

38.5

48.9

69.7

Cybergym

76.7

38.7

52.7

-

83.1

DeepSWE

54.4

7.3

12.8

46.2

58.0

Toolathlon-Verified

70.3

49.7

55.9

59.9

76.2

Agents' Last Exam

25.2

15.8

16.5

23.8

25.7

AutomationBench Public

25.1

10.8

12.8

12.9

27.2

DSBench-FullStack †

68.7

37.0

41.8

61.8

71.6

DSBench-Hard †

59.6

25.8

31.1

54.5

71.7

PreviousDecision Models (Jev + Laya)[PreviousDecision Models (Jev + Laya)](/docs/models/decision-laya)
NextComplete LLM Directory[NextComplete LLM Directory](/docs/models/tutorials)

Last updated 2 months ago

Was this helpful?

- 📊 Quantization Analysis

- 💬 DeepSeek V4 Chat template improvements

- ⚙️ Usage Guide

- Recommended Settings

- Run DeepSeek-V4-Flash Tutorials:

- 🦥 Unsloth Guide

- 🦙 Llama.cpp Guide

- ⚡DSpark - Speculative Decoding

- 📊 Benchmarks

- GGUF Benchmarks

- Official Benchmarks

Was this helpful?

AskCopy
```
--chat-template-kwargs '{"reasoning_effort":"max"}'
--chat-template-kwargs '{"reasoning_effort":"high"}'
--chat-template-kwargs '{"enable_thinking":false}'
```

AskCopy
```
curl -fsSL https://unsloth.ai/install.sh | sh
```

AskCopy
```
irm https://unsloth.ai/install.ps1 | iex
```

AskCopy
```
unsloth run --model unsloth/DeepSeek-V4-Flash-0731-GGUF:UD-IQ3_S
```

AskCopy
```
apt-get update
apt-get install pciutils build-essential cmake curl libcurl4-openssl-dev -y
git clone https://github.com/ggml-org/llama.cpp
cmake llama.cpp -B llama.cpp/build \
-DBUILD_SHARED_LIBS=OFF -DGGML_CUDA=ON
cmake --build llama.cpp/build --config Release -j --clean-first --target llama-cli llama-mtmd-cli llama-server llama-gguf-split
cp llama.cpp/build/bin/llama-* llama.cpp
```

AskCopy
```
export LLAMA_CACHE="unsloth/DeepSeek-V4-Flash-0731-GGUF"
./llama.cpp/llama-cli \
-hf unsloth/DeepSeek-V4-Flash-0731-GGUF:UD-IQ3_S \
--temp 1.0 \
--top-p 1.0 \
--min-p 0.01
```

AskCopy
```
hf download unsloth/DeepSeek-V4-Flash-0731-GGUF \
--local-dir unsloth/DeepSeek-V4-Flash-0731-GGUF \
--include "*UD-IQ3_S*" # Use "*UD-IQ4_XS*" for 4-bit
```

AskCopy
```
./llama.cpp/llama-cli \
--model unsloth/DeepSeek-V4-Flash-0731-GGUF/UD-IQ3_S/DeepSeek-V4-Flash-0731-UD-IQ3_S-00001-of-00004.gguf \
--temp 1.0 \
--top-p 1.0 \
--min-p 0.01
```

AskCopy
```
hf download unsloth/DeepSeek-V4-Flash-0731-GGUF \
--local-dir unsloth/DeepSeek-V4-Flash-0731-GGUF \
--include "*dspark-DeepSeek-V4-Flash-0731-Q8_0*" \
--include "*UD-IQ3_XXS*" # Use "*UD-IQ4_XS*" for 4-bit
```

AskCopy
```
./llama.cpp/llama-cli \
--model unsloth/DeepSeek-V4-Flash-0731-GGUF/UD-IQ3_XXS/DeepSeek-V4-Flash-0731-UD-IQ3_XXS-00001-of-00004.gguf \
-md unsloth/DeepSeek-V4-Flash-0731-GGUF/dspark-DeepSeek-V4-Flash-0731-Q8_0.gguf \
--temp 1.0 \
--top-p 1.0 \
--min-p 0.01 \
--spec-type draft-dspark \
--spec-draft-n-max 3 \
-ngl 99 -ngld 99
```

## Reference sources

- [DeepSeek-V4 How to Run Locally  Unsloth Documentation](https://unsloth.ai/docs/models/deepseek-v4) — accessed 2026-11-03
