# CPU KV offload vLLM issue

:::quick-info
Source: https://github.com/vllm-project/vllm/issues/53607
Scraped: 2026-11-03
Topic: DeepSeek KV Cache
:::

[Bug]: CPU KV offload (OffloadingConnector) crashes on DeepSeek-V4 MLA — flat int8 layout assumption vs padded multi-group uint8 cache · Issue #53607 · vllm-project/vllm · GitHub

Skip to content

You signed in with another tab or window. Reload to refresh your session.
You signed out in another tab or window. Reload to refresh your session.
You switched accounts on another tab or window. Reload to refresh your session.

Dismiss alert

{{ message }}

# [Bug]: CPU KV offload (OffloadingConnector) crashes on DeepSeek-V4 MLA — flat int8 layout assumption vs padded multi-group uint8 cache  #53607

New issue Copy link

New issue Copy link

Open

Open

[Bug]: CPU KV offload (OffloadingConnector) crashes on DeepSeek-V4 MLA — flat int8 layout assumption vs padded multi-group uint8 cache[[Bug]: CPU KV offload (OffloadingConnector) crashes on DeepSeek-V4 MLA — flat int8 layout assumption vs padded multi-group uint8 cache](/vllm-project/vllm/issues/53607#top)#53607

Copy link

Labels

DSv4[DSv4](https://github.com/vllm-project/vllm/issues?q=state%3Aopen%20label%3A%22DSv4%22)deepseekRelated to DeepSeek models[deepseekRelated to DeepSeek models](https://github.com/vllm-project/vllm/issues?q=state%3Aopen%20label%3A%22deepseek%22)Related to DeepSeek models

## Description

![@maci0](https://avatars.githubusercontent.com/u/4222082?u=7a1fadf60d8f1f422a914c9edd2a72a3303007ab&v=4&size=48)

maci0[maci0](https://github.com/maci0)
opened on Aug 24, 2026[on Aug 24, 2026](https://github.com/vllm-project/vllm/issues/53607#issue-5237425881)

Issue body actions

## Summary

OffloadingConnector (stock vLLM, no patches) with an fs_python secondary tier kills the worker during startup on DeepSeek-V4-Flash: CUDA error: an illegal memory access was encountered. Reproduced on v0.27.1 with and without the b12x attention backend; an older stack (0.21.1rc1) deadlocks in CUDA-graph capture instead. Full test: https://github.com/maci0/vllm-spark-nvfp4/blob/main/KV_OFFLOAD_MLA.md[https://github.com/maci0/vllm-spark-nvfp4/blob/main/KV_OFFLOAD_MLA.md](https://github.com/maci0/vllm-spark-nvfp4/blob/main/KV_OFFLOAD_MLA.md)

## Root cause: the transfer path assumes a flat, uniform int8 cache

vllm/v1/kv_offload/cpu/gpu_worker.py asserts exactly:

```
assert gpu_tensor.dtype == torch.int8
assert gpu_tensor.ndim == 2
```

then computes transfer destinations with raw pointer arithmetic:

```
block_page_size = tensor.shape[1] // blocks_per_chunk
all_ptrs = (base_ptr + block_ids * row_stride) + sub_offsets
```

Those addresses feed a Triton kernel (swap_blocks_triton.py) that reinterprets them as int64* words. Nothing validates the addresses against the allocation bounds.

DeepSeek-V4's MLA cache violates every part of that assumption:

| Assumption
| DSV4 MLA reality

| dtype == torch.int8
| uint8 packed pages

| one uniform block_page_size
| per-group padded pages — MLAAttentionSpec.page_size_bytes (576/584 B alignment), and a second group (lightning indexer) with different geometry

| flat 2-D rows
| paged layout whose row stride includes alignment padding

vllm/v1/kv_offload/cpu/spec.py compounds it: a single worker_kv_bytes_per_block is derived for the whole cache, so the hybrid multi-group geometry cannot be represented at all. Once block_page_size diverges from the true padded page size, every pointer drifts by an accumulating offset → out-of-bounds access (or silent corruption).

## Related: LMCache + DSV4

LMCacheConnectorV1 does not implement SupportsHMA, so --kv-transfer-config disables the hybrid KV manager and DSV4 sparse-MLA decode then fails (sparse_mla_sm120_decode_dsv4: num_tokens>64 (36 vs 64)). LMCache/LMCache#3261[LMCache/LMCache#3261](https://github.com/LMCache/LMCache/pull/3261) tracks HMA support and was closed without an implementation. Marking the connector SupportsHMA alone would just move the failure to the same transfer-layout crash above — the transfer path itself needs to understand padded multi-group pages first.

## Suggested direction

- Thread per-group page_size_bytes (and dtype) from MLAAttentionSpec through spec.py → gpu_worker.py instead of the single worker_kv_bytes_per_block.

- Allow uint8 (byte-wise identical to int8 for the swap kernel).

- Validate computed transfer addresses against allocation bounds (the Triton kernel's mask bounds against the declared size only).

## Environment

2x DGX Spark (GB10, SM121a, 128 GiB unified memory), DeepSeek-V4-Flash-0731 + DSpark k=5, fp8_ds_mla and nvfp4_ds_mla cache dtypes, vLLM main e25c586b9 era and v0.27.1.

## Activity

-

![https://avatars.githubusercontent.com/in/15368?s=64&v=4](https://avatars.githubusercontent.com/in/15368?s=64&v=4)
github-actions[github-actions](/apps/github-actions)added
DSv4[DSv4](/vllm-project/vllm/issues?q=state%3Aopen%20label%3A%22DSv4%22)
deepseekRelated to DeepSeek models[deepseekRelated to DeepSeek models](/vllm-project/vllm/issues?q=state%3Aopen%20label%3A%22deepseek%22)Related to DeepSeek models on Aug 24, 2026[on Aug 24, 2026](https://github.com/vllm-project/vllm/issues/53607#event-29928467566)

Sign up for free to join this conversation on GitHub. Already have an account? Sign in to comment

## Metadata

## Metadata

### Assignees

No one assigned

### Labels

DSv4[DSv4](https://github.com/vllm-project/vllm/issues?q=state%3Aopen%20label%3A%22DSv4%22)deepseekRelated to DeepSeek models[deepseekRelated to DeepSeek models](https://github.com/vllm-project/vllm/issues?q=state%3Aopen%20label%3A%22deepseek%22)Related to DeepSeek models

### Type

No type

### Projects

No projects

### Milestone

No milestone

### Relationships

None yet

### Development

No branches or pull requests

## Issue actions

-
![https://github.githubassets.com/assets/github-copilot-app-light-15ad5534265eeacd.svg](https://github.githubassets.com/assets/github-copilot-app-light-15ad5534265eeacd.svg)
Open in GitHub Copilot app

You can’t perform that action at this time.

## Reference sources

- [CPU KV offload vLLM issue](https://github.com/vllm-project/vllm/issues/53607) — accessed 2026-11-03
