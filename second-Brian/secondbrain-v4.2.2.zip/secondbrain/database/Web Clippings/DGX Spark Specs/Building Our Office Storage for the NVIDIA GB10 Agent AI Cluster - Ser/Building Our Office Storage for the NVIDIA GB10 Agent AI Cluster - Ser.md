# Building Our Office Storage for the NVIDIA GB10 Agent AI Cluster - Ser

:::quick-info
Source: https://www.servethehome.com/building-our-office-storage-for-the-nvidia-gb10-agent-ai-cluster-apple-amd-solidigm-qnap/
Scraped: 2026-11-03
Topic: DGX Spark Specs
:::

Building Our Office Storage for the NVIDIA GB10 Agent AI Cluster - ServeTheHome

Facebook
[Facebook](https://www.facebook.com/ServeTheHome/)

Linkedin
[Linkedin](https://www.linkedin.com/company/servethehome-com/)

RSS
[RSS](http://feeds.feedburner.com/servethehome)

TikTok
[TikTok](https://www.tiktok.com/@servethehome)

X
[X](https://twitter.com/servethehome)

Youtube
[Youtube](https://www.youtube.com/ServeTheHomeVideo?sub_confirmation=1)

- Forums[Forums](https://forums.servethehome.com)

- AI[AI](https://www.servethehome.com/category/ai-deep-learning/)

- Server[Server](https://www.servethehome.com/category/server-parts/)

- Server Systems[Server Systems](https://www.servethehome.com/category/server-parts/server-systems/)

- Server CPUs[Server CPUs](https://www.servethehome.com/category/server-parts/cpus/)

- Accelerators[Accelerators](https://www.servethehome.com/category/server-parts/accelerators/)

- Server Motherboards[Server Motherboards](https://www.servethehome.com/category/server-parts/motherboards/)

- Server Chassis[Server Chassis](https://www.servethehome.com/category/server-parts/server-chassis/)

- Other Components[Other Components](https://www.servethehome.com/category/server-parts/other-components/)

- 5G Edge[5G Edge](https://www.servethehome.com/category/edge/)

- Storage[Storage](https://www.servethehome.com/category/storage/)

- Networking[Networking](https://www.servethehome.com/category/networking/)

- Workstation[Workstation](https://www.servethehome.com/category/workstations/)

- Workstation Processors[Workstation Processors](https://www.servethehome.com/category/workstations/workstation-processors/)

- Workstation Motherboards[Workstation Motherboards](https://www.servethehome.com/category/workstations/workstation-motherboards/)

- Software[Software](https://www.servethehome.com/category/server-software/)

- Operating Systems[Operating Systems](https://www.servethehome.com/category/server-software/operating-systems/)

- Server Applications[Server Applications](https://www.servethehome.com/category/server-software/server-applications/)

- Virtualization[Virtualization](https://www.servethehome.com/category/server-software/virtualization-other/)

- Guides[Guides](https://www.servethehome.com/buyers-guides/)

- Buyer’s Guides[Buyer’s Guides](https://www.servethehome.com/category/client-tips-and-tricks/buyers-guides/)

- Tips[Tips](https://www.servethehome.com/category/client-tips-and-tricks/)

- Top Hardware Components for TrueNAS / FreeNAS NAS Servers[Top Hardware Components for TrueNAS / FreeNAS NAS Servers](https://www.servethehome.com/buyers-guides/top-hardware-components-for-truenas-freenas-nas-servers/)

- Top Hardware Components for pfSense Appliances[Top Hardware Components for pfSense Appliances](https://www.servethehome.com/buyers-guides/top-hardware-components-pfsense-appliances/)

- Top Hardware Components for napp-it and Solarish NAS Servers[Top Hardware Components for napp-it and Solarish NAS Servers](https://www.servethehome.com/buyers-guides/top-hardware-components-napp-omnios-nas-servers/)

- Top Picks for Windows Server 2016 Essentials Hardware[Top Picks for Windows Server 2016 Essentials Hardware](https://www.servethehome.com/buyers-guides/top-picks-windows-server-2016-essentials-hardware/)

- The DIY WordPress Hosting Server Hardware Guide[The DIY WordPress Hosting Server Hardware Guide](https://www.servethehome.com/buyers-guides/the-diy-wordpress-hosting-server-hardware-guide/)

Facebook
[Facebook](https://www.facebook.com/ServeTheHome/)

Linkedin
[Linkedin](https://www.linkedin.com/company/servethehome-com/)

RSS
[RSS](http://feeds.feedburner.com/servethehome)

TikTok
[TikTok](https://www.tiktok.com/@servethehome)

X
[X](https://twitter.com/servethehome)

Youtube
[Youtube](https://www.youtube.com/ServeTheHomeVideo?sub_confirmation=1)

Monday, November 2, 2026

- ServeTheHome News[ServeTheHome News](https://www.servethehome.com/category/news/)

- Storage Reliability[Storage Reliability](https://www.servethehome.com/raid-calculator/)

- Raid Calculator[Raid Calculator](https://www.servethehome.com/raid-calculator/)

- RAID Reliability Calculator | Simple MTTDL Model[RAID Reliability Calculator | Simple MTTDL Model](https://www.servethehome.com/raid-calculator/raid-reliability-calculator-simple-mttdl-model/)

- About[About](https://www.servethehome.com/about/)

- Contact[Contact](https://www.servethehome.com/contact/)

- Editorial and Copyright Policies[Editorial and Copyright Policies](https://www.servethehome.com/about/editorial-copyright-policies/)

- AG Substack[AG Substack](https://axautikgroupllc.substack.com/)

- AG Reports[AG Reports](https://reports.axautikgroup.com/)

- Subscribe[Subscribe](https://eepurl.com/dryM09)

- ServeTheHome Forums[ServeTheHome Forums](https://forums.servethehome.com)

Sign in

Welcome! Log into your account

Forgot your password? Get help

Privacy Policy[Privacy Policy](https://www.servethehome.com/about/data-processing-and-privacy-policy/)

Password recovery

Recover your password

A password will be e-mailed to you.

![ServeTheHome Logo](https://www.servethehome.com/wp-content/uploads/2025/06/STH-Logo-2-90px-copy.jpg)

ServeTheHome
[ServeTheHome](https://www.servethehome.com/)

Advertisement

![ServeTheHome Logo](https://www.servethehome.com/wp-content/uploads/2019/10/STH-Logo-48px.png)

![ServeTheHome Logo](https://www.servethehome.com/wp-content/uploads/2025/06/STH-Logo-2-90px-copy.jpg)

- Forums[Forums](https://forums.servethehome.com)

- AI[AI](https://www.servethehome.com/category/ai-deep-learning/)

- Server[Server](https://www.servethehome.com/category/server-parts/)

- Server Systems[Server Systems](https://www.servethehome.com/category/server-parts/server-systems/)

- Server CPUs[Server CPUs](https://www.servethehome.com/category/server-parts/cpus/)

- Accelerators[Accelerators](https://www.servethehome.com/category/server-parts/accelerators/)

- Server Motherboards[Server Motherboards](https://www.servethehome.com/category/server-parts/motherboards/)

- Server Chassis[Server Chassis](https://www.servethehome.com/category/server-parts/server-chassis/)

- Other Components[Other Components](https://www.servethehome.com/category/server-parts/other-components/)

- 5G Edge[5G Edge](https://www.servethehome.com/category/edge/)

- Storage[Storage](https://www.servethehome.com/category/storage/)

- Networking[Networking](https://www.servethehome.com/category/networking/)

- Workstation[Workstation](https://www.servethehome.com/category/workstations/)

- Workstation Processors[Workstation Processors](https://www.servethehome.com/category/workstations/workstation-processors/)

- Workstation Motherboards[Workstation Motherboards](https://www.servethehome.com/category/workstations/workstation-motherboards/)

- Software[Software](https://www.servethehome.com/category/server-software/)

- Operating Systems[Operating Systems](https://www.servethehome.com/category/server-software/operating-systems/)

- Server Applications[Server Applications](https://www.servethehome.com/category/server-software/server-applications/)

- Virtualization[Virtualization](https://www.servethehome.com/category/server-software/virtualization-other/)

- Guides[Guides](https://www.servethehome.com/buyers-guides/)

- Buyer’s Guides[Buyer’s Guides](https://www.servethehome.com/category/client-tips-and-tricks/buyers-guides/)

- Tips[Tips](https://www.servethehome.com/category/client-tips-and-tricks/)

- Top Hardware Components for TrueNAS / FreeNAS NAS Servers[Top Hardware Components for TrueNAS / FreeNAS NAS Servers](https://www.servethehome.com/buyers-guides/top-hardware-components-for-truenas-freenas-nas-servers/)

- Top Hardware Components for pfSense Appliances[Top Hardware Components for pfSense Appliances](https://www.servethehome.com/buyers-guides/top-hardware-components-pfsense-appliances/)

- Top Hardware Components for napp-it and Solarish NAS Servers[Top Hardware Components for napp-it and Solarish NAS Servers](https://www.servethehome.com/buyers-guides/top-hardware-components-napp-omnios-nas-servers/)

- Top Picks for Windows Server 2016 Essentials Hardware[Top Picks for Windows Server 2016 Essentials Hardware](https://www.servethehome.com/buyers-guides/top-picks-windows-server-2016-essentials-hardware/)

- The DIY WordPress Hosting Server Hardware Guide[The DIY WordPress Hosting Server Hardware Guide](https://www.servethehome.com/buyers-guides/the-diy-wordpress-hosting-server-hardware-guide/)

Home[Home](https://www.servethehome.com/) AI[AI](https://www.servethehome.com/category/ai-deep-learning/) Building Our Office Storage for the NVIDIA GB10 Agent AI Cluster

- AI[AI](https://www.servethehome.com/category/ai-deep-learning/)

- Storage[Storage](https://www.servethehome.com/category/storage/)

Facebook[Facebook](https://www.facebook.com/sharer.php?u=https%3A%2F%2Fwww.servethehome.com%2Fbuilding-our-office-storage-for-the-nvidia-gb10-agent-ai-cluster-apple-amd-solidigm-qnap%2F)

X[X](https://x.com/intent/post?text=Building+Our+Office+Storage+for+the+NVIDIA+GB10+Agent+AI+Cluster&url=https%3A%2F%2Fwww.servethehome.com%2Fbuilding-our-office-storage-for-the-nvidia-gb10-agent-ai-cluster-apple-amd-solidigm-qnap%2F&via=ServeTheHome)

Pinterest[Pinterest](https://pinterest.com/pin/create/button/?url=https://www.servethehome.com/building-our-office-storage-for-the-nvidia-gb10-agent-ai-cluster-apple-amd-solidigm-qnap/&media=https://www.servethehome.com/wp-content/uploads/2025/09/QNAP-TS-h1290FX-Front-with-Solidigm-Drive-1.jpg&description=We built an office storage solution for our growing cluster of small AI systems and wanted to share some key experiences)

Linkedin[Linkedin](https://www.linkedin.com/shareArticle?mini=true&url=https://www.servethehome.com/building-our-office-storage-for-the-nvidia-gb10-agent-ai-cluster-apple-amd-solidigm-qnap/&title=Building+Our+Office+Storage+for+the+NVIDIA+GB10+Agent+AI+Cluster)

ReddIt[ReddIt](https://reddit.com/submit?url=https://www.servethehome.com/building-our-office-storage-for-the-nvidia-gb10-agent-ai-cluster-apple-amd-solidigm-qnap/&title=Building+Our+Office+Storage+for+the+NVIDIA+GB10+Agent+AI+Cluster)

Email

Print

Copy URL[Copy URL](https://www.servethehome.com/building-our-office-storage-for-the-nvidia-gb10-agent-ai-cluster-apple-amd-solidigm-qnap/)

![QNAP TS H1290FX Front With Solidigm Drive 1](https://www.servethehome.com/wp-content/uploads/2025/09/QNAP-TS-h1290FX-Front-with-Solidigm-Drive-1-696x392.jpg)
QNAP TS H1290FX Front With Solidigm Drive 1

In the STH studio, we have been working on building a neat cluster. While we have big GPUs that can run small models with great speed, we have instead been focusing on building a cluster of different types of edge AI systems, all with a common thread: they have high memory capacity and can run larger models. The cluster has had 4-5 NVIDIA GB10 machines, plus four AMD Ryzen AI Max+ 395 128GB systems, and an Apple Mac Studio M3 Ultra 512GB. We started a storage solution for the NVIDIA GB10 cluster, and then we hooked other machines up to it. As such, it was time for a little write-up.

As a quick note, we are using SSDs from Solidigm, a NAS from QNAP, NVIDIA GB10’s from NVIDIA and Dell, a MikroTik switch from MikroTik, and likely other hardware provided by other vendors. We have to say this is sponsored. This involved some ideas, plus quite a bit of trial and error to get to the point that we had a solution that worked how we wanted.

## Building Our Office Agent AI Cluster Storage for NVIDIA GB10

First off, why are we doing this project? One of the big reasons is that we have had 4-5 NVIDIA GB10 boxes with high-speed networking. An advantage of hosting models and also fine tuning model data over the network, instead of locally, is that the $1000 delta between 4TB and 1TB nodes starts to get less exciting as the number of machines scales. A 60GB model at these storage prices costs roughly $20 to store locally. When you have five machines that becomes $100 just to store a single model. There are also larger models, and you may have many of these downloaded onto a machine.

![Dell Pro Max With GB 10 Two Node ConnectX7 2](https://www.servethehome.com/wp-content/uploads/2025/12/Dell-Pro-Max-with-GB-10-Two-Node-ConnectX7-2-1-800x450.jpg)
Dell Pro Max With GB 10 Two Node ConnectX7 2

Also, the Apple Mac Studio with the M3 Ultra, which we use for high memory capacity in a single node, costs the same $1000 to move from 1TB to 4TB of storage.

![Apple Mac Studio M3 Ultra 512GB 9499 Base Price](https://www.servethehome.com/wp-content/uploads/2025/03/Apple-Mac-Studio-M3-Ultra-512GB-9499-Base-Price-800x583.jpg)
Apple Mac Studio M3 Ultra 512GB 9499 Base Price

That only has 10Gbase-T networking built in, but we have 25GbE Thunderbolt adapters[25GbE Thunderbolt adapters](https://www.servethehome.com/raidendigit-lightone-25gbe-thunderbolt-adapter-nvidia/) which make storage reasonably fast.

We also have 10GbE or faster networking on five AMD Ryzen AI Max+ 395 servers that we have in the studio.

![Framework Desktop AMD Ryzen AI Max + 395 128GB Front With Tile Pack 3](https://www.servethehome.com/wp-content/uploads/2025/11/Framework-Desktop-AMD-Ryzen-AI-Max-395-128GB-Front-with-Tile-Pack-3-800x450.jpg)
Framework Desktop AMD Ryzen AI Max + 395 128GB Front With Tile Pack 3

That does not include the GPU workstations and servers that we have for higher performance, but lower memory capacity.

![ASUS Pro WS TRX50 SAGE WIFI With AMD Ryzen Threadripper 7980X 1](https://www.servethehome.com/wp-content/uploads/2023/11/ASUS-Pro-WS-TRX50-SAGE-WIFI-with-AMD-Ryzen-Threadripper-7980X-1-800x527.jpg)
ASUS Pro WS TRX50 SAGE WIFI With AMD Ryzen Threadripper 7980X 1

A few weeks ago, we did a piece on Building New STH Studio Storage NAS[Building New STH Studio Storage NAS](https://www.servethehome.com/building-new-sth-studio-nas-storage-qnap-solidigm-amd-nvidia/). In that, we mentioned that we were building not just a storage repository for footage, but we were also using this for AI.

Key to this effort has been the Solidigm D5-P5336[Solidigm D5-P5336](https://www.servethehome.com/solidigm-d5-p5336-122-88tb-nvme-ssd-review/) SSDs. While these are far from the fastest SSDs on the market, they allowed us to scale the storage capacity to a decent figure while also not being wildly expensive for capacity.

![QNAP TS H1290FX Front With Solidigm Drive 2](https://www.servethehome.com/wp-content/uploads/2025/10/QNAP-TS-h1290FX-Front-with-Solidigm-Drive-2-800x450.jpg)
QNAP TS H1290FX Front With Solidigm Drive 2

Although these use QLC NAND, our workloads tend to be much heavier on the read side. Just to give you some sense of the impact versus the hard drives, loading a model like gpt-oss-120b from this Solidigm D5-P5336 versus an older hard drive-based QNAP TS-1655 12-Bay Plus 4-Bay NAS[QNAP TS-1655 12-Bay Plus 4-Bay NAS](https://www.servethehome.com/qnap-ts-1655-12-bay-plus-4-bay-nas-revew-with-an-intel-atom-c5125/) can often see 30-60% reductions in model load times. When you need to load an use a model, that can be a very notable difference.

Still, to get this working takes a bit of work, so let us get to that next.

#### RELATED ARTICLESMORE FROM AUTHOR

![Qualcomm HBC Render](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAANoAAACWAQMAAACCSQSPAAAAA1BMVEWurq51dlI4AAAAAXRSTlMmkutdmwAAABpJREFUWMPtwQENAAAAwiD7p7bHBwwAAAAg7RD+AAGXD7BoAAAAAElFTkSuQmCC)

### Qualcomm Validates HBC Stacked Memory Ahead of 2027 Dragonfly AI250 Sampling[Qualcomm Validates HBC Stacked Memory Ahead of 2027 Dragonfly AI250 Sampling](https://www.servethehome.com/qualcomm-validates-hbc-stacked-memory-ahead-of-2027-dragonfly-ai250-sampling/)

![ASRock Rack OCP Summit-6UXGM-GNR2 CX8_DLC 4](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAANoAAACWAQMAAACCSQSPAAAAA1BMVEWurq51dlI4AAAAAXRSTlMmkutdmwAAABpJREFUWMPtwQENAAAAwiD7p7bHBwwAAAAg7RD+AAGXD7BoAAAAAElFTkSuQmCC)

### Liquid-Cooled NVIDIA Servers at the ASRock Rack OCP 2026 Booth[Liquid-Cooled NVIDIA Servers at the ASRock Rack OCP 2026 Booth](https://www.servethehome.com/liquid-cooled-nvidia-servers-at-the-asrock-rack-ocp-2026-booth/)

![NVIDIA Rubin GPU](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAANoAAACWAQMAAACCSQSPAAAAA1BMVEWurq51dlI4AAAAAXRSTlMmkutdmwAAABpJREFUWMPtwQENAAAAwiD7p7bHBwwAAAAg7RD+AAGXD7BoAAAAAElFTkSuQmCC)

### NVIDIA Updates Rubin GPU Specs as First Production Hardware Arrives[NVIDIA Updates Rubin GPU Specs as First Production Hardware Arrives](https://www.servethehome.com/nvidia-updates-rubin-gpu-specs-as-first-production-hardware-arrives/)

### LEAVE A REPLY

This site uses Akismet to reduce spam. Learn how your comment data is processed.[Learn how your comment data is processed.](https://akismet.com/privacy/)

© 2009-2026 Axautik Group LLC[Axautik Group LLC](https://www.axautikgroup.com/)

## Reference sources

- [Building Our Office Storage for the NVIDIA GB10 Agent AI Cluster - Ser](https://www.servethehome.com/building-our-office-storage-for-the-nvidia-gb10-agent-ai-cluster-apple-amd-solidigm-qnap/) — accessed 2026-11-03
