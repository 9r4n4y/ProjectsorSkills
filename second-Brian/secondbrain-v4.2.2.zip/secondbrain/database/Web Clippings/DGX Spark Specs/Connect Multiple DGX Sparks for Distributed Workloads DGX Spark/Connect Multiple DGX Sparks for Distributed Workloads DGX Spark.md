# Connect Multiple DGX Sparks for Distributed Workloads  DGX Spark

:::quick-info
Source: https://build.nvidia.com/spark/connect-multiple-sparks
Scraped: 2026-11-03
Topic: DGX Spark Specs
:::

Skip to main content

?
Login

View All Playbooks[View All Playbooks](/spark)

View All Playbooks[View All Playbooks](/spark)

Connect Multiple DGX Sparks for Distributed Workloads | DGX Spark

# Connect Multiple DGX Sparks for Distributed Workloads

Beginner10 MIN
Use NVIDIA Sync clustering so larger models and training can span nodes.

- Multi-Node[Multi-Node](/search?label=Multi-Node)

View on GitHub[View on GitHub](https://github.com/NVIDIA/dgx-spark-playbooks/blob/main/nvidia/playbook-connect-multiple-sparks/)

OverviewOverview[OverviewOverview](/spark/connect-multiple-sparks/overview)Cable the DevicesCable the Devices[Cable the DevicesCable the Devices](/spark/connect-multiple-sparks/cable-devices)Configure with NVIDIA SyncConfigure with NVIDIA Sync[Configure with NVIDIA SyncConfigure with NVIDIA Sync](/spark/connect-multiple-sparks/beginner)Configure ManuallyConfigure Manually[Configure ManuallyConfigure Manually](/spark/connect-multiple-sparks/advance)TroubleshootingTroubleshooting[TroubleshootingTroubleshooting](/spark/connect-multiple-sparks/troubleshooting)

## Basic idea

Some workloads need more compute and memory than a single DGX Spark can provide, but you can still run those workloads if you "cluster" two or more Sparks.
Clustering devices is the process of physically connecting them with high-speed cables (and potentially a switch) and then configuring a particular network across those cables.
You can't really do it over a wireless connection because the data will not move between devices quickly enough.

The primary component enabling a high-speed cluster across Sparks is the ConnectX-7[ConnectX-7](https://resources.nvidia.com/en-us-accelerated-networking-resource-library/connectx-7-datasheet) network adapter that each Spark comes with.
The ConnectX-7 adapter, often called a "NIC", is a software and hardware layer that enables data transfer directly between memory across devices through RDMA[RDMA](https://blogs.nvidia.com/blog/what-is-rdma/).

If you physically cable two or more Sparks with QSFP[QSFP](https://en.wikipedia.org/wiki/Small_Form-factor_Pluggable) cables and properly configure the ConnectX-7 network, you can have high-speed super computing cluster on your desktop.

This playbook shows you two paths to configure the ConnectX-7 network across two to four DGX Spark devices.

- Beginner: Follow the Configure with NVIDIA Sync tab to set up and test the ConnectX-7 network (see demo video[see demo video](https://www.youtube.com/watch?v=MehBUQtb9qM)).

- Advanced: Experienced users can do things manually with the NVIDIA provided scripts in the Configure Manually tab.

Both paths start with following the Cable the Devices tab to make sure the devices are appropriately connected.

## What you'll accomplish

- You will physically connect the devices directly with QSFP cables, or a switch if needed. Beginner - Advanced

- You will use NVIDIA Sync[NVIDIA Sync](https://docs.nvidia.com/sync/latest/cluster-assistant.html) to configure the ConnectX-7 network across the devices. Beginner

- Or, you will use commands and scripts to manually set up the ConnectX-7 network across the devices. Advanced

## What to know before starting

- How to plug a QSFP cable into a DGX Spark[plug a QSFP cable into a DGX Spark](https://docs.nvidia.com/dgx/dgx-spark/spark-clustering.html#plugging-in-a-qsfp-cable) and configure switch settings if required. Beginner - Advanced

- How to set up a DGX Spark[set up a DGX Spark](https://docs.nvidia.com/dgx/dgx-spark/first-boot.html) on a LAN. Beginner - Advanced

- How to create and edit json files. Advanced

- How to interpret and run bash scripts. Advanced

- A basic grasp of network configuration and Netplan files[Netplan files](https://netplan.readthedocs.io/en/stable/) and IP . Advanced

- A basic grasp of ConnectX-7 networking[ConnectX-7 networking](https://docs.nvidia.com/dgx/dgx-spark/spark-clustering.html). Advanced

## Supported hardware platforms

Check the table below to see if this playbook is for your hardware.

| Hardware platform | OS | Memory | Recommended default local settings | Multi-node capable hardware
| DGX Spark | DGX OS (Linux) | 64GB or 128GB Unified Memory | Direct or switch QSFP links | ✅ (200GbE QSFP)

## Prerequisites

Hardware requirements

- Two to four DGX Sparks.

- The number of QSFP cables for your layout in Cable the Devices.

- (if using a switch) A switch with one 200 Gbit/s Ethernet link for each device.

Software requirements

- Each Spark must be on the same LAN, and you must know its management IP address or mDNS name.

- You must have a user name and password with sudo privileges on each device.

- Each Spark is updated to the April 2026 DGX OS release[April 2026 DGX OS release](https://docs.nvidia.com/dgx/dgx-spark/release-notes.html#april-2026-release) or later.

## Ancillary files

These files are only needed for the manual path.
You can find them in this playbook's assets folder[this playbook's assets folder](https://github.com/NVIDIA/dgx-spark-playbooks/blob/main/nvidia/playbook-connect-multiple-sparks/assets).

- spark_cluster_setup[spark_cluster_setup](https://github.com/NVIDIA/dgx-spark-playbooks/blob/main/nvidia/playbook-connect-multiple-sparks/assets/spark_cluster_setup) — network and SSH setup for the manual path

## Time & risk

- Estimated time: 10 minutes with NVIDIA Sync; 1 hour for manual setup

- Risk level: Low with NVIDIA Sync; medium with manual setup

- Rollback: Delete the cluster in NVIDIA Sync. For manual setup, follow the rollback steps in Configure Manually.

- Last Updated: 09/24/2026

- Changes file paths and tightened focus on NVIDIA Sync.

### Resources

- NVIDIA Sync Cluster Assistant  [NVIDIA Sync Cluster Assistant](https://docs.nvidia.com/sync/latest/cluster-assistant.html)

- DGX Spark Documentation  [DGX Spark Documentation](https://docs.nvidia.com/dgx/dgx-spark)

- DGX Spark OS and Component Update  [DGX Spark OS and Component Update](https://docs.nvidia.com/dgx/dgx-spark/os-and-component-update.html)

- DGX Spark Forum  [DGX Spark Forum](https://forums.developer.nvidia.com/c/accelerated-computing/dgx-spark-gb10)

- QSFP Cable (marketplace)  [QSFP Cable (marketplace)](https://marketplace.nvidia.com/en-us/enterprise/personal-ai-supercomputers/qsfp-cable-0-4m-for-dgx-spark/)

- NVIDIA Developer Forums  [NVIDIA Developer Forums](https://forums.developer.nvidia.com/)

## Reference sources

- [Connect Multiple DGX Sparks for Distributed Workloads  DGX Spark](https://build.nvidia.com/spark/connect-multiple-sparks) — accessed 2026-11-03
