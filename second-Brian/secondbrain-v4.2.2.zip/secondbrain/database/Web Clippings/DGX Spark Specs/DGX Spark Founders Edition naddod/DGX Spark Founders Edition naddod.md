# DGX Spark Founders Edition naddod

:::quick-info
Source: https://www.naddod.com/products/103029.html
Scraped: 2026-11-03
Topic: DGX Spark Specs
:::

NVIDIA DGX Spark Founders Edition (940-54242-0006-000) - 4TB : A Desktop AI Supercomputer Powered by the GB10 Grace Blackwell Superchip | NADDOD

Free Worldwide Shipping on Orders over US$ 99[Free Worldwide Shipping on Orders over US$ 99](/support/shipping-and-delivery)

![logo](https://resource.naddod.com/images/wb-content/2023-01-30/logo-footer-005749.webp)

![logo](/svg/logo-w.svg)

![/svg/icon-nav-search-normal.svg](/svg/icon-nav-search-normal.svg)

![/svg/search-fff.svg](/svg/search-fff.svg)

![Cart](/svg/cart-ndd.svg)

![Cart](/svg/cart-fff.svg)

![Cart](/svg/mobile/icon-mobile-cart.svg)

You have no items in your cart

---

Subtotal:

US$ 0.00

CheckoutView cart[View cart](/cart)

Are you sure you want to remove this item from your basket?

Are you sure you want to remove this item from your basket?
CancelDelete

CancelDelete

![My Account](/svg/user-circle.svg)

![My Account](/svg/user-circle-fff.svg)

My Account[My Account](/account) Orders[Orders](/account/order) Quotes[Quotes](/account/quote) Manage Profile[Manage Profile](/account/setting)
---

Sign InCreate Account[Create Account](/auth/register?from=/products/103029.html)
Contact

Support
FAQ[FAQ](/support/faq)Decision Guide[Decision Guide](/decision-guide)Shipping & Delivery[Shipping & Delivery](/support/shipping-and-delivery)Payment Methods[Payment Methods](/support/payment-methods)
Services
AI Infrastructure Services[AI Infrastructure Services](/support/ai-infrastructure-deployment-services)Warranty[Warranty](/support/warranty)Returns & Refund Policy[Returns & Refund Policy](/support/rma-policy)Bulk Quotation Request[Bulk Quotation Request](/support/bulk-quotation-request)
Technical Support
Documentation[Documentation](/support/documentation)Compatibility Matrix Tool[Compatibility Matrix Tool](/support/optics-to-device-compatibility-matrix)

Support→
We address all your concerns that span from procurement decision-making to after-sales.

[Support→We address all your concerns that span from procurement decision-making to after-sales.](/support)

About Us
NADDOD Overview[NADDOD Overview](/about-us/naddod-overview)NADDOD Certified[NADDOD Certified](/about-us/naddod-certified)Events[Events](/about-us/events)AIDC Test Center[AIDC Test Center](/about-us/naddod-certified/testing)
Contact Us
sales@naddod.com+(65) 6018 4212
Follow Us

Contact Us→
Our team provides you with professional technical consulting services.

[Contact Us→Our team provides you with professional technical consulting services.](/about-us/contact-us)

By Infrastructure
By Industry

NVIDIA Blackwell

DGX B300 SuperPOD Solution
![/svg/blue-arrow-right.svg](/svg/blue-arrow-right.svg)

Large foundation model training with more memory.

[DGX B300 SuperPOD SolutionLarge foundation model training with more memory.](/solution/ai-networking/dgx-b300-superpod-solution)

Industry Solution

Cybersecurity
![/svg/blue-arrow-right.svg](/svg/blue-arrow-right.svg)

AI-driven cybersecurity solutions for threat detection and prevention.

[CybersecurityAI-driven cybersecurity solutions for threat detection and prevention.](/solution/ai/cybersecurity)

NDDIS→
Full-stack AI cluster maintenance, 24/7 SLAs, and turnkey deployment support.

[NDDIS→Full-stack AI cluster maintenance, 24/7 SLAs, and turnkey deployment support.](/support/ai-infrastructure-deployment-services)

InfiniBand Networking[InfiniBand Networking](/special/naddod-infiniband-products-family)
RoCE Networking[RoCE Networking](/special/naddod-roce-products-family)
Liquid Cooling Networking[Liquid Cooling Networking](/collection/liquid-cooling-networking)
AI Data Center Cabling[AI Data Center Cabling](/special/naddod-ai-data-center-network-cabling)
Optical Transceivers[Optical Transceivers](/collection/optical-transceivers)
AOC, DAC, ACC & AEC[AOC, DAC, ACC & AEC](/collection/dac-and-aoc-cables)
Switches & NICs[Switches & NICs](/collection/networking)
Fiber & Copper Cables[Fiber & Copper Cables](/collection/fiber-optic-cables)
Personal AI Supercomputers[Personal AI Supercomputers](/collection/personal-ai-supercomputers)

![1.6T/800G XDR](https://resource.naddod.com/cdn-cgi/image/width=120,quality=70,format=auto,onerror=redirect/https://resource.naddod.com/images/2026-01-07/osfp-1-6t-2xdr4h-main-1-013973.webp)

1.6T/800G XDR[1.6T/800G XDR](/collections/1600g-800g-infiniband-xdr)Hot
1.6T OSFP224 XDR Transceivers[1.6T OSFP224 XDR Transceivers](/collections/1600g-transceivers-infiniband-xdr)Hot
1.6T OSFP224 to OSFP224 XDR DAC[1.6T OSFP224 to OSFP224 XDR DAC](/collections/1600g-infiniband-xdr-osfp-dac)
1.6T OSFP224 to 2x800G OSFP224 XDR DAC Splitters[1.6T OSFP224 to 2x800G OSFP224 XDR DAC Splitters](/collections/1600g-osfp-to-2x800g-osfp-dac-splitters)
1.6T OSFP224 to 4x400G OSFP224 XDR DAC Splitters[1.6T OSFP224 to 4x400G OSFP224 XDR DAC Splitters](/collections/1600g-osfp-to-4x400g-osfp-dac-splitters)
800G OSFP224 XDR Transceivers[800G OSFP224 XDR Transceivers](/collections/800g-infiniband-xdr-transceivers)Hot

![800G/400G NDR](https://resource.naddod.com/cdn-cgi/image/width=120,quality=70,format=auto,onerror=redirect/https://resource.naddod.com/images/2026-02-05/osfp-800g-2xsr4h-014530.webp)

800G/400G NDR[800G/400G NDR](/collections/infiniband-ndr)Hot
800G IB OSFP Transceivers[800G IB OSFP Transceivers](/collections/800g-infiniband-ndr-osfp-transceivers)In Stock
800G OSFP to OSFP DAC[800G OSFP to OSFP DAC](/collections/800g-infiniband-ndr-osfp-dac)
800G OSFP to 2x400G OSFP/QSFP112 DAC Splitters[800G OSFP to 2x400G OSFP/QSFP112 DAC Splitters](/collections/800g-osfp-to-2x400g-osfp-dac-splitters)
800G OSFP to 4x200G OSFP/QSFP112 DAC Splitters[800G OSFP to 4x200G OSFP/QSFP112 DAC Splitters](/collections/800g-osfp-to-4x200g-osfp-dac-splitters)
400G IB OSFP/QSFP112 Transceivers[400G IB OSFP/QSFP112 Transceivers](/collections/400g-infiniband-ndr-osfp-transceivers)In Stock
400G OSFP to OSFP DAC[400G OSFP to OSFP DAC](/collections/400g-infiniband-ndr-osfp-dac)
400G OSFP to 2x200G QSFP56 DAC Splitters[400G OSFP to 2x200G QSFP56 DAC Splitters](/collections/400g-osfp-to-2x200g-qsfp56-dac-splitters)
400G OSFP to 4x100G QSFP56 DAC Splitters[400G OSFP to 4x100G QSFP56 DAC Splitters](/collections/400g-osfp-to-4x100g-qsfp56-dac-splitters)
400G OSFP to 2x200G QSFP56 AOC Splitters[400G OSFP to 2x200G QSFP56 AOC Splitters](/collections/400g-osfp-to-2x200g-qsfp56-aoc-splitters)In Stock

![NVIDIA InfiniBand Switches](https://resource.naddod.com/cdn-cgi/image/width=120,quality=70,format=auto,onerror=redirect/https://resource.naddod.com/images/products/2025-03-27/1-011073.webp)

NVIDIA InfiniBand Switches[NVIDIA InfiniBand Switches](/collections/nvidia-networking/infiniband-switching)
Quantum-X800 Switches[Quantum-X800 Switches](/collections/nvidia-networking/quantum-x800-switches)
Quantum-2 QM9700 Switches[Quantum-2 QM9700 Switches](/collections/nvidia-networking/quantum-2-qm9700-switches)
Quantum QM8700 Switches[Quantum QM8700 Switches](/collections/nvidia-networking/quantum-qm8700-switches)

![NVIDIA InfiniBand HCAs](https://resource.naddod.com/cdn-cgi/image/width=120,quality=70,format=auto,onerror=redirect/https://resource.naddod.com/images/250410/2025-06-03/1-011573.webp)

NVIDIA InfiniBand HCAs[NVIDIA InfiniBand HCAs](/collections/nvidia-networking/infiniband-adapters)
ConnectX-9 Adapters[ConnectX-9 Adapters](/collections/connectx-9-adapters)New
ConnectX-8[ConnectX-8](/collections/nvidia-networking/connectx-8)Hot
ConnectX-7[ConnectX-7](/collections/nvidia-networking/connectx-7)
ConnectX-6[ConnectX-6](/collections/nvidia-networking/connectx-6)

![InfiniBand Fiber Cable](https://resource.naddod.com/cdn-cgi/image/width=120,quality=70,format=auto,onerror=redirect/https://resource.naddod.com/images/products/2024-11-11/m4mpoa12fb-2-010392.webp)

InfiniBand Fiber Cable[InfiniBand Fiber Cable](/collections/multimode-splitter-fiber-cable)
MPO Jumpers[MPO Jumpers](/collections/mpo-jumpers)
MPO Harnesses / Breakout[MPO Harnesses / Breakout](/collections/mpo-harnesses-breakout)
LC Patch Cords[LC Patch Cords](/collections/lc-patch-cords)

![200G HDR](https://resource.naddod.com/cdn-cgi/image/width=120,quality=70,format=auto,onerror=redirect/https://resource.naddod.com/images/products/2022-12-26/200g-qsfp56-hpc-aoc-2-004425.png)

200G HDR[200G HDR](/collections/infiniband-hdr)
200G QSFP56 to QSFP56 AOC[200G QSFP56 to QSFP56 AOC](/collections/200g-infiniband-hdr-qsfp56-aoc)In Stock
200G OSFP to QSFP56 AOC[200G OSFP to QSFP56 AOC](/collections/200g-infiniband-hdr-osfp-to-qsfp56-aoc)
200G QSFP56 to QSFP56 DAC[200G QSFP56 to QSFP56 DAC](/collections/200g-infiniband-hdr-qsfp56-dac)
200G QSFP56 to 2xQSFP56 AOC Splitters[200G QSFP56 to 2xQSFP56 AOC Splitters](/collections/200g-infiniband-hdr-qsfp56-breakout-aoc)In Stock
200G 2xQSFP56 to 2xQSFP56 AOC Splitters[200G 2xQSFP56 to 2xQSFP56 AOC Splitters](/collections/200g-infiniband-hdr-qsfp56-aoc-splitters-hcable)
200G QSFP56 to 2xQSFP56 DAC Splitters[200G QSFP56 to 2xQSFP56 DAC Splitters](/collections/200g-infiniband-hdr-qsfp56-breakout-dac)
200G IB QSFP56 Transceivers[200G IB QSFP56 Transceivers](/collections/200g-infiniband-hdr-qsfp56-transceivers)

![100G EDR](https://resource.naddod.com/cdn-cgi/image/width=120,quality=70,format=auto,onerror=redirect/https://resource.naddod.com/images/products/2022-12-26/100g-qsfp28-aoc-2-004451.webp)

100G EDR[100G EDR](/collections/infiniband-edr)
100G QSFP28 to QSFP28 AOC[100G QSFP28 to QSFP28 AOC](/collections/100g-infiniband-edr-qsfp28-aoc)On Sale
100G QSFP28 to QSFP28 DAC[100G QSFP28 to QSFP28 DAC](/collections/100g-infiniband-edr-qsfp28-dac)On Sale
100G IB QSFP28 Transceivers[100G IB QSFP28 Transceivers](/collections/100g-infiniband-edr-qsfp28-transceivers)

![InfiniBand LinkX®](https://resource.naddod.com/cdn-cgi/image/width=120,quality=70,format=auto,onerror=redirect/https://resource.naddod.com/images/2026-02-14/1-014827.webp)

InfiniBand LinkX®[InfiniBand LinkX®](/collections/nvidia-networking/infiniband-linkx)
NVIDlA InfiniBand Transceivers[NVIDlA InfiniBand Transceivers](/collections/nvidia-networking/nvidia-infiniband-transceiver)
NVIDIA InfiniBand AOC/DAC[NVIDIA InfiniBand AOC/DAC](/collections/nvidia-infiniband-aoc-or-dac)New

![NVIDIA DPUs and SuperNICs](https://resource.naddod.com/cdn-cgi/image/width=120,quality=70,format=auto,onerror=redirect/https://resource.naddod.com/images/2025-06-11/b3220-900-9d3b6-00sv-aa0-011598.webp)

NVIDIA DPUs and SuperNICs[NVIDIA DPUs and SuperNICs](/collections/nvidia-networking/nvidia-bluefield-3-dpus-and-supernics)New
BlueField-3 DPUs[BlueField-3 DPUs](/collections/nvidia-networking/nvidia-bluefield-3-dpus)
BlueField-3 SuperNICs[BlueField-3 SuperNICs](/collections/nvidia-networking/nvidia-bluefield-3-supernics)

![AI Data Center Switches](https://resource.naddod.com/cdn-cgi/image/width=120,quality=70,format=auto,onerror=redirect/https://resource.naddod.com/images/2025-11-18/5-013306.webp)

AI Data Center Switches[AI Data Center Switches](/collections/data-center-switches)Hot
1.6T AI Data Center Switches[1.6T AI Data Center Switches](/collections/1600g-ai-data-center-switches)New
800G AI Data Center Switches[800G AI Data Center Switches](/collections/800g-ai-data-center-switches)Hot
400G AI Data Center Switches[400G AI Data Center Switches](/collections/400g-ai-data-center-switches)
200G AI Data Center Switches[200G AI Data Center Switches](/collections/200g-ai-data-center-switches)New
NADDOD Enterprise SONiC[NADDOD Enterprise SONiC](/special/naddod-enterprise-sonic)

![NVIDIA Ethernet Switches](https://resource.naddod.com/cdn-cgi/image/width=120,quality=70,format=auto,onerror=redirect/https://resource.naddod.com/images/2025-09-17/a-012311.webp)

NVIDIA Ethernet Switches[NVIDIA Ethernet Switches](/collections/nvidia-networking/nvidia-ethernet-switches)
Spectrum-3 SN4000 Switches[Spectrum-3 SN4000 Switches](/collections/nvidia-networking/spectrum-3-sn4000-ethernet-switches)
Spectrum-4 SN5000 Switches[Spectrum-4 SN5000 Switches](/collections/nvidia-networking/spectrum-4-sn5000-ethernet-switches)Hot

![Networking Adapters](https://resource.naddod.com/cdn-cgi/image/width=120,quality=70,format=auto,onerror=redirect/https://resource.naddod.com/images/250410/2025-06-03/1-011573.webp)

Networking Adapters[Networking Adapters](/collections/nvidia-networking/ethernet-adapters-or-nics)
ConnectX-9 Adapters[ConnectX-9 Adapters](/collections/connectx-9-adapters)New
ConnectX-8 Adapters[ConnectX-8 Adapters](/collections/connectx-8-adapters)Hot
ConnectX-7 Adapters[ConnectX-7 Adapters](/collections/nvidia-networking/connectx-7-adapters)
ConnectX-6 Adapters[ConnectX-6 Adapters](/collections/nvidia-networking/connectx-6-adapters)
ConnectX-5 Adapters[ConnectX-5 Adapters](/collections/nvidia-networking/connectx-5-adapters)

![NVIDIA DPUs and SuperNICs](https://resource.naddod.com/cdn-cgi/image/width=120,quality=70,format=auto,onerror=redirect/https://resource.naddod.com/images/2025-06-11/b3220-900-9d3b6-00sv-aa0-011598.webp)

NVIDIA DPUs and SuperNICs[NVIDIA DPUs and SuperNICs](/collections/nvidia-networking/nvidia-bluefield-3-dpus-and-supernics)New
BlueField-3 DPUs[BlueField-3 DPUs](/collections/nvidia-networking/nvidia-bluefield-3-dpus)
BlueField-3 SuperNICs[BlueField-3 SuperNICs](/collections/nvidia-networking/nvidia-bluefield-3-supernics)

![Ethernet Transceivers](https://resource.naddod.com/cdn-cgi/image/width=120,quality=70,format=auto,onerror=redirect/https://resource.naddod.com/images/2026-02-06/6-014560.webp)

Ethernet Transceivers[Ethernet Transceivers](/collections/ethernet-transceiver-modules)
1.6T OSFP224[1.6T OSFP224](/collections/1600g-osfp-ethernet-modules)New
800G OSFP/QSFP-DD[800G OSFP/QSFP-DD](/collections/800g-osfp-ethernet-modules)Hot
400G OSFP/QSFP-DD/QSFP112[400G OSFP/QSFP-DD/QSFP112](/collections/400g-osfp-qsfp-dd-or-qsfp112-ethernet-modules)Hot
200G QSFP56/QSFP112/QSFP-DD[200G QSFP56/QSFP112/QSFP-DD](/collections/200g-qsfp56-ethernet-modules)
100G QSFP28/QSFP56[100G QSFP28/QSFP56](/collections/100g-qsfp28-ethernet-modules)

![Fiber Patch Cables](https://resource.naddod.com/cdn-cgi/image/width=120,quality=70,format=auto,onerror=redirect/https://resource.naddod.com/images/Products/2022-10-20/m4mtpu12fb-1-removebg-preview-001948.webp)

Fiber Patch Cables[Fiber Patch Cables](/collections/fiber-patch-cables)Hot
MPO Patch Cables[MPO Patch Cables](/collections/mpo-patch-cables)
LC Patch Cables[LC Patch Cables](/collections/lc-patch-cables)
MPO Shuffle Cables[MPO Shuffle Cables](/collections/mpo-shuffle-cable)Hot

![AOC Cables](https://resource.naddod.com/cdn-cgi/image/width=120,quality=70,format=auto,onerror=redirect/https://resource.naddod.com/images/products/2023-09-04/1-007794.webp)

AOC Cables[AOC Cables](/collections/ethernet-active-optical-cables-aoc)
400G QSFP-DD AOC[400G QSFP-DD AOC](/collections/400g-qsfp-dd-ethernet-aoc-cables)Hot
400G Breakout AOC[400G Breakout AOC](/collections/400g-ethernet-breakout-aoc-cables)
200G QSFP56 AOC[200G QSFP56 AOC](/collections/200g-qsfp56-ethernet-aoc-cables)Hot
200G Breakout AOC[200G Breakout AOC](/collections/200g-ethernet-breakout-aoc-cables)

![DAC Cables](https://resource.naddod.com/cdn-cgi/image/width=120,quality=70,format=auto,onerror=redirect/https://resource.naddod.com/images/products/2022-12-26/400g-qsfp-dd-dac-main-004337.webp)

DAC Cables[DAC Cables](/collections/ethernet-direct-attach-copper-dac-cables)
1.6T OSFP224 DAC[1.6T OSFP224 DAC](/collections/1600g-osfp-ethernet-dac-cables)New
1.6T Breakout DAC[1.6T Breakout DAC](/collections/1600g-ethernet-breakout-dac-cables)New
800G OSFP DAC[800G OSFP DAC](/collections/800g-osfp-ethernet-dac-cables)Hot
800G Breakout DAC[800G Breakout DAC](/collections/800g-ethernet-breakout-dac-cables)New
400G QSFP-DD/QSFP112/OSFP DAC[400G QSFP-DD/QSFP112/OSFP DAC](/collections/400g-qsfp-dd-or-qsfp112-ethernet-dac-cables)Hot
400G Breakout DAC[400G Breakout DAC](/collections/400g-ethernet-breakout-dac-cables)Hot
200G QSFP56 DAC[200G QSFP56 DAC](/collections/200g-ethernet-qsfp56-dac-cables)Hot
200G Breakout DAC[200G Breakout DAC](/collections/200g-ethernet-breakout-dac-cables)

![Liquid/Immersion Cooling Transceivers](https://resource.naddod.com/cdn-cgi/image/width=120,quality=70,format=auto,onerror=redirect/https://resource.naddod.com/images/2025-03-04/1-010977.webp)

Liquid/Immersion Cooling Transceivers[Liquid/Immersion Cooling Transceivers](/collections/immersion-cooling-transceivers)Hot
800G OSFP Liquid/Immersion Transceivers[800G OSFP Liquid/Immersion Transceivers](/collections/800g-immersion-transceivers)
400G OSFP Liquid/Immersion Transceivers[400G OSFP Liquid/Immersion Transceivers](/collections/400g-immersion-transceivers)Hot
200G QSFP56 Liquid/Immersion Transceivers[200G QSFP56 Liquid/Immersion Transceivers](/collections/200g-immersion-transceivers)

![Optical Fiber Patch Cables](https://resource.naddod.com/cdn-cgi/image/width=120,quality=70,format=auto,onerror=redirect/https://resource.naddod.com/cdn-cgi/image/width=640,quality=80,format=auto,onerror=redirect/https://resource.naddod.com/images/2025-11-18/s2mpoa12fb-1-013299.webp)

Optical Fiber Patch Cables[Optical Fiber Patch Cables](/collections/optical-fiber-patch-cables)
MPO Jumpers[MPO Jumpers](/collections/mpo-jumpers)
MPO Harnesses / Breakout[MPO Harnesses / Breakout](/collections/mpo-harnesses-breakout)
LC Patch Cords[LC Patch Cords](/collections/lc-patch-cords)

![Structured Cabling](https://resource.naddod.com/cdn-cgi/image/width=120,quality=70,format=auto,onerror=redirect/https://resource.naddod.com/cdn-cgi/image/width=640,quality=80,format=auto,onerror=redirect/https://resource.naddod.com/images/2026-03-05/s2192-1-015053.webp)

Structured Cabling[Structured Cabling](/collections/structured-cabling)Hot
High-Fiber Count Trunk Cables[High-Fiber Count Trunk Cables](/collections/high-fiber-count-trunk-cables)Hot
Fiber Distribution & Management Assemblies[Fiber Distribution & Management Assemblies](/collections/fiber-distribution-management-assemblies)

![Shuffle Assemblies](https://resource.naddod.com/cdn-cgi/image/width=120,quality=70,format=auto,onerror=redirect/https://resource.naddod.com/cdn-cgi/image/width=640,quality=80,format=auto,onerror=redirect/https://resource.naddod.com/images/2026-07-31/1-017360.webp)

Shuffle Assemblies[Shuffle Assemblies](/collections/shuffle-assemblies)Hot
2-Plane & 4-Plane Fabric Fiber Assemblies[2-Plane & 4-Plane Fabric Fiber Assemblies](/collections/2-plane-4-plane-fabric-fiber-assemblies)
8-Plane Fabric Fiber Assemblies[8-Plane Fabric Fiber Assemblies](/collections/8-plane-fabric-fiber-assemblies)Hot

![OOB Management Cables](https://resource.naddod.com/cdn-cgi/image/width=120,quality=70,format=auto,onerror=redirect/https://resource.naddod.com/cdn-cgi/image/width=120,quality=70,format=auto,onerror=redirect/https://resource.naddod.com/images/products/2022-12-09/sg-c5eutppvc24-blue-003686.png)

OOB Management Cables[OOB Management Cables](/collections/oob-management-cables)
Slim Patch Cables[Slim Patch Cables](/collections/slim-patch-cables)Hot
Cat6 Patch Cables[Cat6 Patch Cables](/collections/cat6-patch-cables)
Cat6a Patch Cables[Cat6a Patch Cables](/collections/cat6a-patch-cables)Hot

![1.6T/800G/400G Transceivers](https://resource.naddod.com/cdn-cgi/image/width=120,quality=70,format=auto,onerror=redirect/https://resource.naddod.com/images/2026-01-07/osfp-1-6t-2xdr4h-main-1-013973.webp)

1.6T/800G/400G Transceivers[1.6T/800G/400G Transceivers](/collections/200g-400g-or-800g-modules)
1.6T OSFP224[1.6T OSFP224](/collections/1600g-osfp-transceivers)Hot
800G OSFP/QSFP-DD[800G OSFP/QSFP-DD](/collections/800g-qsfp-dd-or-osfp)Hot
800G OSFP/QSFP-DD LPO[800G OSFP/QSFP-DD LPO](/collections/800g-qsfp-dd-or-osfp-lpo)New
800G OSFP/QSFP-DD Coherent[800G OSFP/QSFP-DD Coherent](/collections/800g-osfp-qsfp-dd-coherent)New
400G OSFP/QSFP-DD/QSFP112[400G OSFP/QSFP-DD/QSFP112](/collections/400g-osfp-qsfp112-qsfp-dd-module)
400G QSFP112 LPO[400G QSFP112 LPO](/collections/400g-osfp-or-qsfp112-lpo)New
400G QSFP-DD Coherent[400G QSFP-DD Coherent](/collections/400g-qsfp-dd-coherent)

![200G Transceivers](https://resource.naddod.com/cdn-cgi/image/width=120,quality=70,format=auto,onerror=redirect/https://resource.naddod.com/images/products/2023-09-04/1-007789.webp)

200G Transceivers[200G Transceivers](/collections/200g-modules)
200G QSFP56/QSFP112/QSFP-DD[200G QSFP56/QSFP112/QSFP-DD](/collections/200g-qsfp56-or-qsfp-dd)

![100G/25G Transceivers](https://resource.naddod.com/cdn-cgi/image/width=120,quality=70,format=auto,onerror=redirect/https://resource.naddod.com/images/products/2022-10-14/qsfp-100g-fr-2km-main-001497.png)

100G/25G Transceivers[100G/25G Transceivers](/collections/100g-modules)
100G QSFP28/QSFP56[100G QSFP28/QSFP56](/collections/100g-qsfp28)Hot
25G SFP28[25G SFP28](/collections/25g-sfp28)On Sale
25G WDM SFP28[25G WDM SFP28](/collections/25g-wdm-sfp28)

![40G/10G Transceivers](https://resource.naddod.com/cdn-cgi/image/width=120,quality=70,format=auto,onerror=redirect/https://resource.naddod.com/images/products/2022-10-14/sfp-10g-u100-45-100km-main-001261.png)

40G/10G Transceivers[40G/10G Transceivers](/collections/10g-modules)
40G QSFP+[40G QSFP+](/collections/40g-qsfp-plus)
10G SFP+[10G SFP+](/collections/10g-sfp-plus)
10G CWDM SFP+[10G CWDM SFP+](/collections/10g-cwdm-sfp-plus)
10G DWDM SFP+[10G DWDM SFP+](/collections/10g-dwdm-sfp-plus)On Sale

![1G/Other Transceivers](https://resource.naddod.com/cdn-cgi/image/width=120,quality=70,format=auto,onerror=redirect/https://resource.naddod.com/images/products/2022-10-14/sfp-fe-lx-10km-main-001501.png)

1G/Other Transceivers[1G/Other Transceivers](/collections/1g-transceivers)
1G SFP[1G SFP](/collections/1g-sfp)
1G BIDI SFP[1G BIDI SFP](/collections/1g-bidi-sfp)
40G/100G Converter[40G/100G Converter](/collections/10g-40g-or-100g-converter)

![Data Center Interconnect (DCI) Transceivers](https://resource.naddod.com/cdn-cgi/image/width=120,quality=70,format=auto,onerror=redirect/https://resource.naddod.com/images/products/2024-12-16/1-010668.webp)

Data Center Interconnect (DCI) Transceivers[Data Center Interconnect (DCI) Transceivers](/collections/data-center-interconnect-transceivers)
800G OSFP/QSFP-DD DCI[800G OSFP/QSFP-DD DCI](/collections/800g-data-center-interconnect-transceivers)New
400G QSFP-DD DCI[400G QSFP-DD DCI](/collections/400g-data-center-interconnect-transceivers)
100G QSFP28 DCI[100G QSFP28 DCI](/collections/100g-data-center-interconnect-transceivers)

![Near-Packaged Optics](https://resource.naddod.com/cdn-cgi/image/width=120,quality=70,format=auto,onerror=redirect/https://resource.naddod.com/images/2026-09-03/7-018008.webp)

Near-Packaged Optics[Near-Packaged Optics](/collections/npo-near-packaged-optics)New
3.2T NPO[3.2T NPO](/collections/3200g-npo-near-packaged-optics)

![Loopback Transceivers](https://resource.naddod.com/cdn-cgi/image/width=120,quality=70,format=auto,onerror=redirect/https://resource.naddod.com/images/2026-07-22/1-017253.webp)

Loopback Transceivers[Loopback Transceivers](/collections/loopback-modules)New
800G OSFP LBA/LBP[800G OSFP LBA/LBP](/collections/800g-osfp-loopback-modules)

![Silicon Photonics Transceivers](https://resource.naddod.com/cdn-cgi/image/width=120,quality=70,format=auto,onerror=redirect/https://resource.naddod.com/images/products/2024-12-03/1-010590.webp)

Silicon Photonics Transceivers[Silicon Photonics Transceivers](/collections/silicon-photonics-transceivers)New
400G OSFP SiPh[400G OSFP SiPh](/collections/400g-ethernet-silicon-photonics-transceivers)

![Active Optical Cables](https://resource.naddod.com/cdn-cgi/image/width=120,quality=70,format=auto,onerror=redirect/https://resource.naddod.com/images/products/2022-10-11/100g-qsfp28-aoc-main-000996.png)

Active Optical Cables[Active Optical Cables](/collections/active-optical-cables)
400G QSFP-DD AOC[400G QSFP-DD AOC](/collections/400g-qsfp-dd-aoc)
200G QSFP56 AOC[200G QSFP56 AOC](/collections/200g-qsfp56-aoc)Hot
100G/56G/40G QSFP AOC[100G/56G/40G QSFP AOC](/collections/56g-qsfp-plus-aoc)On Sale
25G/10G SFP AOC[25G/10G SFP AOC](/collections/40g-qsfp-plus-aoc)On Sale

![Breakout AOC](https://resource.naddod.com/cdn-cgi/image/width=120,quality=70,format=auto,onerror=redirect/https://resource.naddod.com/images/products/2022-10-11/100g-qsfp28-to-4x25g-sfp28-breakout-aoc-main-001003.png)

Breakout AOC[Breakout AOC](/collections/breakout-aoc)
400G Breakout AOC[400G Breakout AOC](/collections/400g-breakout-aoc)
200G Breakout AOC[200G Breakout AOC](/collections/200g-breakout-aoc)Hot
100G Breakout AOC[100G Breakout AOC](/collections/100g-breakout-aoc)Hot
40G Breakout AOC[40G Breakout AOC](/collections/40g-breakout-aoc)On Sale

![Direct Attach Cables](https://resource.naddod.com/cdn-cgi/image/width=120,quality=70,format=auto,onerror=redirect/https://resource.naddod.com/images/IB%E5%B9%BF%E5%91%8A%E7%B4%A0%E6%9D%90%E5%9B%BE/2025-08-19/a-012031.webp)

Direct Attach Cables[Direct Attach Cables](/collections/direct-attach-cables)
1.6T OSFP224 DAC[1.6T OSFP224 DAC](/collections/1600g-dac)New
800G OSFP DAC[800G OSFP DAC](/collections/800g-osfp-or-qsfp112-dd-dac)
400G OSFP DAC[400G OSFP DAC](/collections/400g-osfp-dac-cables)New
400G QSFP-DD DAC[400G QSFP-DD DAC](/collections/400g-qsfp-dd-dac)
400G QSFP112 DAC[400G QSFP112 DAC](/collections/400g-qsfp112-dac-cables)
200G QSFP56 DAC[200G QSFP56 DAC](/collections/200g-qsfp56-dac)Hot
100G SFP-DD DAC[100G SFP-DD DAC](/collections/100g-qsfp28-dac)
100G/56G/40G QSFP DAC[100G/56G/40G QSFP DAC](/collections/56g-qsfp-plus-dac)On Sale
25G/10G SFP DAC[25G/10G SFP DAC](/collections/50g-sfp56-dac)On Sale

![Breakout DAC](https://resource.naddod.com/cdn-cgi/image/width=120,quality=70,format=auto,onerror=redirect/https://resource.naddod.com/images/2026-04-08/1-015595.webp)

Breakout DAC[Breakout DAC](/collections/breakout-dac)
1.6T Breakout DAC[1.6T Breakout DAC](/collections/1600g-breakout-dac)New
800G Breakout DAC[800G Breakout DAC](/collections/800g-breakout-dac)
400G Breakout DAC[400G Breakout DAC](/collections/400g-breakout-dac)Hot
200G Breakout DAC[200G Breakout DAC](/collections/200g-breakout-dac)Hot
100G Breakout DAC[100G Breakout DAC](/collections/100g-breakout-dac)On Sale
40G Breakout DAC[40G Breakout DAC](/collections/40g-breakout-dac)

![Active Copper Cables](https://resource.naddod.com/cdn-cgi/image/width=120,quality=70,format=auto,onerror=redirect/https://resource.naddod.com/images/2026-01-12/osfp-1-6t-ac2h-main-a-014040.webp)

Active Copper Cables[Active Copper Cables](/collections/dac-acc-active-copper-cables)
1.6T OSFP224 ACC[1.6T OSFP224 ACC](/collections/1600g-acc)New
1.6T Breakout ACC[1.6T Breakout ACC](/collections/1600g-breakout-acc-cables)New
800G OSFP ACC[800G OSFP ACC](/collections/800g-osfp-acc-cables)
800G Breakout ACC[800G Breakout ACC](/collections/800g-breakout-acc-cables)
200G QSFP56 ACC[200G QSFP56 ACC](/collections/200g-qsfp56-acc-cables)
100G QSFP28 ACC[100G QSFP28 ACC](/collections/100g-qsfp28-acc-cables)

![Active Electrical Cables](https://resource.naddod.com/cdn-cgi/image/width=120,quality=70,format=auto,onerror=redirect/https://resource.naddod.com/images/2026-03-23/1-015260.webp)

Active Electrical Cables[Active Electrical Cables](/collections/dac-aec-active-electrical-cables)New
1.6T OSFP224 AEC[1.6T OSFP224 AEC](/collections/1600g-aec)
800G OSFP AEC[800G OSFP AEC](/collections/800g-osfp-aec-cables)
800G Breakout AEC[800G Breakout AEC](/collections/800g-breakout-aec-cables)
400G QSFP112 AEC[400G QSFP112 AEC](/collections/400g-qsfp112-aec)

![NVIDIA DPUs and SuperNICs](https://resource.naddod.com/cdn-cgi/image/width=120,quality=70,format=auto,onerror=redirect/https://resource.naddod.com/images/2025-06-11/b3220-900-9d3b6-00sv-aa0-011598.webp)

NVIDIA DPUs and SuperNICs[NVIDIA DPUs and SuperNICs](/collections/nvidia-networking/nvidia-bluefield-3-dpus-and-supernics)New
BlueField-3 DPUs[BlueField-3 DPUs](/collections/nvidia-networking/nvidia-bluefield-3-dpus)
BlueField-3 SuperNICs[BlueField-3 SuperNICs](/collections/nvidia-networking/nvidia-bluefield-3-supernics)

![NVIDIA InfiniBand Switches](https://resource.naddod.com/cdn-cgi/image/width=120,quality=70,format=auto,onerror=redirect/https://resource.naddod.com/images/products/2025-03-27/1-011073.webp)

NVIDIA InfiniBand Switches[NVIDIA InfiniBand Switches](/collections/nvidia-networking/infiniband-switching)
Quantum-X800 Switches[Quantum-X800 Switches](/collections/nvidia-networking/quantum-x800-switches)
Quantum-2 QM9700 Switches[Quantum-2 QM9700 Switches](/collections/nvidia-networking/quantum-2-qm9700-switches)
Quantum QM8700 Switches[Quantum QM8700 Switches](/collections/nvidia-networking/quantum-qm8700-switches)

![Networking Adapters](https://resource.naddod.com/cdn-cgi/image/width=120,quality=70,format=auto,onerror=redirect/https://resource.naddod.com/images/250410/2025-06-03/1-011573.webp)

Networking Adapters[Networking Adapters](/collections/nvidia-networking/ethernet-adapters-or-nics)
ConnectX-9 Adapters[ConnectX-9 Adapters](/collections/connectx-9-adapters)New
ConnectX-8 Adapters[ConnectX-8 Adapters](/collections/connectx-8-adapters)Hot
ConnectX-7 Adapters[ConnectX-7 Adapters](/collections/nvidia-networking/connectx-7-adapters)
ConnectX-6 Adapters[ConnectX-6 Adapters](/collections/nvidia-networking/connectx-6-adapters)
ConnectX-5 Adapters[ConnectX-5 Adapters](/collections/nvidia-networking/connectx-5-adapters)

![AI Data Center Switches](https://resource.naddod.com/cdn-cgi/image/width=120,quality=70,format=auto,onerror=redirect/https://resource.naddod.com/images/2025-11-18/5-013306.webp)

AI Data Center Switches[AI Data Center Switches](/collections/data-center-switches)Hot
1.6T AI Data Center Switches[1.6T AI Data Center Switches](/collections/1600g-ai-data-center-switches)New
800G AI Data Center Switches[800G AI Data Center Switches](/collections/800g-ai-data-center-switches)Hot
400G AI Data Center Switches[400G AI Data Center Switches](/collections/400g-ai-data-center-switches)
200G AI Data Center Switches[200G AI Data Center Switches](/collections/200g-ai-data-center-switches)New

![NVIDIA Ethernet Switches](https://resource.naddod.com/cdn-cgi/image/width=120,quality=70,format=auto,onerror=redirect/https://resource.naddod.com/images/2025-09-17/a-012311.webp)

NVIDIA Ethernet Switches[NVIDIA Ethernet Switches](/collections/nvidia-networking/nvidia-ethernet-switches)
Spectrum-3 SN4000 Switches[Spectrum-3 SN4000 Switches](/collections/nvidia-networking/spectrum-3-sn4000-ethernet-switches)
Spectrum-4 SN5000 Switches[Spectrum-4 SN5000 Switches](/collections/nvidia-networking/spectrum-4-sn5000-ethernet-switches)Hot

![DCN / Enterprise Switches](https://resource.naddod.com/cdn-cgi/image/width=120,quality=70,format=auto,onerror=redirect/https://resource.naddod.com/images/2025-11-18/6-013323.webp)

DCN / Enterprise Switches[DCN / Enterprise Switches](/collections/enterprise-switches)
100G Data Center Switches[100G Data Center Switches](/collections/100g-data-center-switches)
1G/10G/25G/40G Enterprise Switches[1G/10G/25G/40G Enterprise Switches](/collections/1g-or-10g-enterprise-switches)
PoE Switches[PoE Switches](/collections/poe-switches)

![MTP®/MPO Fiber Cables](https://resource.naddod.com/cdn-cgi/image/width=120,quality=70,format=auto,onerror=redirect/https://resource.naddod.com/images/Products/2022-10-20/s2mtpa12mbp-removebg-preview-001970.png)

MTP®/MPO Fiber Cables[MTP®/MPO Fiber Cables](/collections/mtp-or-mpo-cable-assemblies)Hot
MTP®/MPO Jumpers[MTP®/MPO Jumpers](/collections/mtp-or-mpo-trunks)Hot
MTP®/MPO Harnesses[MTP®/MPO Harnesses](/collections/mtp-or-mpo-harnesses)
MPO Trunk Cables[MPO Trunk Cables](/collections/mtp-mpo-trunk-cables)Hot
MMC Cable Assemblies[MMC Cable Assemblies](/collections/mmc-cable-assemblies)New

![Fiber Shuffles](https://resource.naddod.com/cdn-cgi/image/width=120,quality=70,format=auto,onerror=redirect/https://resource.naddod.com/images/2026-02-05/m4mpoa4x8f4-014546.webp)

Fiber Shuffles[Fiber Shuffles](/collections/fiber-shuffles)Hot
MPO Shuffle Cables[MPO Shuffle Cables](/collections/mpo-shuffle-cable)Hot
Shuffle Box[Shuffle Box](/collections/shuffle-box)New

![Fiber Patch Cords](https://resource.naddod.com/cdn-cgi/image/width=120,quality=70,format=auto,onerror=redirect/https://resource.naddod.com/images/Products/2022-10-20/m2lcustud-removebg-preview-001932.png)

Fiber Patch Cords[Fiber Patch Cords](/collections/fiber-patch-cords)
OS2 9/125 Single Mode[OS2 9/125 Single Mode](/collections/os2-9-or-125-single-mode)
OM5 50/125 Multimode[OM5 50/125 Multimode](/collections/om5-50-or-125-multimode)
OM4 50/125 Multimode[OM4 50/125 Multimode](/collections/om4-50-or-125-multimode)
OM3 50/125 Multimode[OM3 50/125 Multimode](/collections/om3-50-or-125-multimode)
OM2 50/125 Multimode[OM2 50/125 Multimode](/collections/om2-50-or-125-multimode)

![Copper Patch Cables](https://resource.naddod.com/cdn-cgi/image/width=120,quality=70,format=auto,onerror=redirect/https://resource.naddod.com/images/products/2022-12-09/sg-c5eutppvc24-blue-003686.png)

Copper Patch Cables[Copper Patch Cables](/collections/patch-cables)
Slim Patch Cables[Slim Patch Cables](/collections/slim-patch-cables)Hot
Cat5e Patch Cables[Cat5e Patch Cables](/collections/cat5e-patch-cables)
Cat6 Patch Cables[Cat6 Patch Cables](/collections/cat6-patch-cables)
Cat6a Patch Cables[Cat6a Patch Cables](/collections/cat6a-patch-cables)Hot
Cat7 Patch Cables[Cat7 Patch Cables](/collections/cat7-patch-cables)
Cat8 Patch Cables[Cat8 Patch Cables](/collections/cat8-patch-cables)

![Fiber Enclosures](https://resource.naddod.com/cdn-cgi/image/width=120,quality=70,format=auto,onerror=redirect/https://resource.naddod.com/images/2026-04-29/0-015880.webp)

Fiber Enclosures[Fiber Enclosures](/collections/fiber-enclosures)New
Rack Mount[Rack Mount](/collections/rack-mount)

![Fiber Optic Panels](https://resource.naddod.com/cdn-cgi/image/width=120,quality=70,format=auto,onerror=redirect/https://resource.naddod.com/images/2026-04-28/4-015873.webp)

Fiber Optic Panels[Fiber Optic Panels](/collections/fiber-optic-panels)New
MTP®/MPO Fiber Optic Panels[MTP®/MPO Fiber Optic Panels](/collections/mtp-mpo-fiber-optic-panels)

![Server Accessories](https://resource.naddod.com/cdn-cgi/image/width=120,quality=70,format=auto,onerror=redirect/https://resource.naddod.com/images/2025-09-28/cq-c14c15-13a-125v-012438.webp)

Server Accessories[Server Accessories](/collections/server-accessories)
Power Cords[Power Cords](/collections/power-cords)

![Copper Bulk Cables](https://resource.naddod.com/cdn-cgi/image/width=120,quality=70,format=auto,onerror=redirect/https://resource.naddod.com/images/2026-07-24/1-017287.webp)

Copper Bulk Cables[Copper Bulk Cables](/collections/copper-bulk-cables)
Cat6 Copper Cables[Cat6 Copper Cables](/collections/cat6-copper-cables)
Cat6a Copper Cables[Cat6a Copper Cables](/collections/cat6a-copper-cables)

![NVIDIA DGX Spark](https://resource.naddod.com/cdn-cgi/image/width=120,quality=70,format=auto,onerror=redirect/https://resource.naddod.com/images/2025-10-22/dgx-spark-main-a-012681.webp)

NVIDIA DGX Spark[NVIDIA DGX Spark](/collections/nvidia-dgx-spark)
DGX Spark - 4TB[DGX Spark - 4TB](/collections/nvidia-dgx-spark-4tb)
DGX Spark Interconnect Cable[DGX Spark Interconnect Cable](/collections/dgx-spark-interconnect-cable)In Stock

Search

Quick Links

1.6T OSFP224 XDR Transceivers[1.6T OSFP224 XDR Transceivers](/collections/1600g-transceivers-infiniband-xdr)

1.6T OSFP224 XDR SiPh[1.6T OSFP224 XDR SiPh](/collections/1600g-silicon-photonics-transceivers-infiniband-xdr)

800G IB OSFP Transceivers[800G IB OSFP Transceivers](/collections/800g-infiniband-ndr-osfp-transceivers)

800G AI Data Center Switches[800G AI Data Center Switches](/collections/800g-ai-data-center-switches)

800G OSFP/QSFP-DD[800G OSFP/QSFP-DD](/collections/800g-osfp-ethernet-modules)

![NVIDIA DGX Spark - 4TB A GB10 Grace Blackwell AI Supercomputer on your desk](https://resource.naddod.com/cdn-cgi/image/width=800,quality=80,format=auto,onerror=redirect/https://resource.naddod.com/images/2025-10-27/dgx-spark-main-a-012798.webp)

Click to open expanded view

![NVIDIA DGX Spark - 4TB A GB10 Grace Blackwell AI Supercomputer on your desk](https://resource.naddod.com/cdn-cgi/image/width=80,quality=75,format=auto,onerror=redirect/https://resource.naddod.com/images/2025-10-27/dgx-spark-main-a-012798.webp)

![NVIDIA DGX Spark - 4TB A GB10 Grace Blackwell AI Supercomputer on your desk](https://resource.naddod.com/cdn-cgi/image/width=80,quality=75,format=auto,onerror=redirect/https://resource.naddod.com/images/2025-10-27/dgx-spark-main-b-012797.webp)

![NVIDIA DGX Spark - 4TB A GB10 Grace Blackwell AI Supercomputer on your desk](https://resource.naddod.com/cdn-cgi/image/width=80,quality=75,format=auto,onerror=redirect/https://resource.naddod.com/images/2025-10-27/dgx-spark-main-c-012794.webp)

![NVIDIA DGX Spark - 4TB A GB10 Grace Blackwell AI Supercomputer on your desk](https://resource.naddod.com/cdn-cgi/image/width=80,quality=75,format=auto,onerror=redirect/https://resource.naddod.com/images/2025-10-27/dgx-spark-main-d-012795.webp)

![NVIDIA DGX Spark - 4TB A GB10 Grace Blackwell AI Supercomputer on your desk](https://resource.naddod.com/cdn-cgi/image/width=80,quality=75,format=auto,onerror=redirect/https://resource.naddod.com/images/2025-10-27/dgx-spark-main-e-012793.webp)

![NVIDIA DGX Spark - 4TB A GB10 Grace Blackwell AI Supercomputer on your desk](https://resource.naddod.com/cdn-cgi/image/width=80,quality=75,format=auto,onerror=redirect/https://resource.naddod.com/images/2025-10-27/dgx-spark-main-f-012792.webp)

![NVIDIA DGX Spark - 4TB A GB10 Grace Blackwell AI Supercomputer on your desk](https://resource.naddod.com/cdn-cgi/image/width=80,quality=75,format=auto,onerror=redirect/https://resource.naddod.com/images/2025-10-27/dgx-spark-main-g-012791.webp)

![NVIDIA DGX Spark - 4TB A GB10 Grace Blackwell AI Supercomputer on your desk](https://resource.naddod.com/cdn-cgi/image/width=80,quality=75,format=auto,onerror=redirect/https://resource.naddod.com/images/2025-10-28/dgx-spark-main-h-012820.webp)

Global Local Service[Global Local Service](/support/global-local-service)
Lifetime Technical Support[Lifetime Technical Support](/support/request-tech-support)

# NVIDIA DGX Spark Founders Edition (940-54242-0006-000) AI Server 4TB NVMe 128GB DDR5X | Personal AI Computer for Deep Learning, LLM & GPU Computing

#103029

Model:DGX Spark (940-54242-0006-000)

Sold:2.4k+
In Stock:30

US$ 7,999.00

DGX Spark Types

DGX Spark
DGX Spark Bundle[DGX Spark Bundle](/products/103030.html)

DGX Spark
DGX Spark Bundle[DGX Spark Bundle](/products/103030.html)

Item Spotlights

- DGX Spark Interconnect Cables — Q56-200G-CU0-5[Q56-200G-CU0-5](https://www.naddod.com/products/13888.html) and Q112-400G-CU0-5[Q112-400G-CU0-5](https://www.naddod.com/products/102069.html)

- DGX Spark to 800G and 400G Switch Interconnect Cables — O4Q112-800G-DAC[O4Q112-800G-DAC](https://www.naddod.com/products/101961.html) and Q2Q56-400G-DAC[Q2Q56-400G-DAC](https://www.naddod.com/products/13864.html)

- NVIDIA GB10 Grace Blackwell superchip

- 1 PFLOPS of FP4 AI performance

- 128GB of coherent, unified system memory

- ConnectX-7 Smart NIC

- 4TB NVME.M2 with self-encryption

- 150mm L x 150mm W x 50.5mm H

![NVIDIA DGX Spark - 4TB A GB10 Grace Blackwell AI Supercomputer on your desk](https://resource.naddod.com/images/2025-10-27/dgx-spark-main-a-012798.webp)

NVIDIA DGX Spark Founders Edition (940-54242-0006-000) AI Server 4TB NVMe 128GB DDR5X | Personal AI Computer for Deep Learning, LLM & GPU Computing

![NADDOD](https://resource.naddod.com/images/wb-content/2023-02-14/need-help-006110.webp)
Need Help?[Need Help?](/about-us/contact-us)

![NADDOD](https://resource.naddod.com/images/wb-content/2023-02-15/freight-006127.webp)

Free Worldwide Shipping on Orders over US$ 99[Free Worldwide Shipping on Orders over US$ 99](/support/shipping-and-delivery)

US$ 7,999.00

Add to Cart

Specifications
Applications
Product Highlights
Videos
Questions & Answers
Customer Reviews
Resources

Specifications
Applications
Product Highlights
Videos
Questions & Answers
Customer Reviews
Resources

## Description

NVIDIA DGX Spark AI Desktop Platform – Grace-Blackwell GB10, 128 GB LPDDR5x, 4 TB NVMe, 1 PFLOP Tensor FP4

Powered by the NVIDIA GB10 Grace Blackwell Superchip, NVIDIA DGX™ Spark delivers one petaFLOP of AI performance in a power-efficient, compact form factor. With the NVIDIA AI software stack preinstalled and 128 GB of memory, developers can prototype, fine-tune, and inference the latest generation of reasoning AI models from DeepSeek, Meta, NVIDIA, Google, Qwen and others with up to 200 billion parameters locally.

Powered by the NVIDIA GB10 Grace Blackwell Superchip, NVIDIA DGX™ Spark delivers one petaFLOP of AI performance in a power-efficient, compact form factor. With the NVIDIA AI software stack preinstalled and 128 GB of memory, developers can prototype, fine-tune, and inference the latest generation of reasoning AI models from DeepSeek, Meta, NVIDIA, Google, Qwen and others with up to 200 billion parameters locally.

## Specifications

Architecture
NVIDIA Grace Blackwell

GPU
NVIDIA Blackwell Architecture

CPU
20 core Arm, 10 Cortex-X925 + 10 Cortex A725 Arm

CUDA Cores
NVIDIA Blackwell Generation

Tensor Cores
5th Generation

RT Cores
4th Generation

Tensor Performance
1000 AI TOPS

System Memory
128GB LPDDR5x, coherent unified system memory

Memory Interface
256-bit

Memory Bandwidth
273GB/s

Storage
4TB NVME.M2 with self-encryption

USB
4x USB Type C

Ethernet
10GbE, 1x RJ-45 connector

NIC
ConnectX-7 Smart NIC

Wi-Fi
Wi-Fi 7

Bluetooth
BT 5.4 w/LE

Audio output
HDMI multichannel audio output

Power Consumption
240W

Display Connectors
1x HDMI 2.1a

NVENC | NVDEC
1x | 1x

OS
NVIDIA DGX™ Base OS, Ubuntu Linux

System Dimensions
150 mm L x 150 mm W x 50.5 mm H

System Weight
1.2kg

## Applications

![/svg/chevron-down-black.svg](/svg/chevron-down-black.svg)

![上一页](/svg/tab-left.svg)

### DGX Spark to DGX Spark

### 800G Switch to DGX Spark

### 400G Switch to DGX Spark

### 200G Switch to DGX Spark

![下一页](/svg/tab-right.svg)

## Product Highlights

Meeting DGX Spark's Interconnect Needs

When DGX Spark systems require system-to-system interconnection, their built-in ConnectX-7 200GbE ports are fully compatible with NADDOD's 0.5m 200G QSFP56 Ethernet DAC — a fully validated option that ensures reliable, seamless interconnection.

When DGX Spark systems require system-to-system interconnection, their built-in ConnectX-7 200GbE ports are fully compatible with NADDOD's 0.5m 200G QSFP56 Ethernet DAC — a fully validated option that ensures reliable, seamless interconnection.

![Meeting DGX Spark's Interconnect Needs](https://resource.naddod.com/images/2025-12-12/1-013695.webp)

## Why NADDOD

-

Module Availability
Worry-Free - Rigorous authentic testing!

-

Multi-version Device Compatibility
Multi-Version - Easy adaptation for each module!

-

High-Performance
Actual Test Data-Better results intuitively!

## Our Approach

Test scene

![Test scene](https://resource.naddod.com/images/2025-10-31/dgx-spark-test-scene-012886.webp)

NADDOD stringently selects a series of items in a professional testing environment to ensure the perfect blend of product performance and reliability. Including hardware compatibility (plugging, unplugging, rebooting), software compatibility (connectivity, parameters) and performance testing (DDM, BER, stability).

Test result

NVIDIA DGX Spark
Linux version: 6.11.0-1014
Contact us for more version testing
![/svg/chevron-down-black.svg](/svg/chevron-down-black.svg)
[Contact us for more version testing](/about-us/contact-us)

-
Connectivity

DGX Spark Side Testing
Connectivity Testing
The DAC cable can connect to two DGX Spark units normally, and their port states are up.

-
BER

DGX Spark Side Testing
BER Testing
Tests REAL-TIME BER to ensure the accuracy of data transmission under high load conditions.

-
Bandwidth

DGX Spark Side Testing
Bandwidth Testing
NADDOD's 0.5m 200G QSFP56 DAC cable enables DGX Spark to achieve stable, high-speed dual-unit communication, ideal for demanding computing scenarios.

![Test result](https://resource.naddod.com/images/2025-10-28/connectivity-012805.webp)

![Test result](https://resource.naddod.com/images/2025-10-28/ber-012806.webp)

![Test result](https://resource.naddod.com/images/2025-11-03/bandwidth-012919.webp)

Connectivity

BER

Bandwidth

DGX Spark Side Testing

![Test result](https://resource.naddod.com/images/2025-10-28/connectivity-012805.webp)

![/svg/mobile/icon-base-expand-white.svg](/svg/mobile/icon-base-expand-white.svg)

Connectivity Testing
The DAC cable can connect to two DGX Spark units normally, and their port states are up.

DGX Spark Side Testing

![Test result](https://resource.naddod.com/images/2025-10-28/ber-012806.webp)

![/svg/mobile/icon-base-expand-white.svg](/svg/mobile/icon-base-expand-white.svg)

BER Testing
Tests REAL-TIME BER to ensure the accuracy of data transmission under high load conditions.

DGX Spark Side Testing

![Test result](https://resource.naddod.com/images/2025-11-03/bandwidth-012919.webp)

![/svg/mobile/icon-base-expand-white.svg](/svg/mobile/icon-base-expand-white.svg)

Bandwidth Testing
NADDOD's 0.5m 200G QSFP56 DAC cable enables DGX Spark to achieve stable, high-speed dual-unit communication, ideal for demanding computing scenarios.

## Videos

![https://resource.naddod.com/images/blog/2025-11-13/dgx-spark-testing-013254.webp](https://resource.naddod.com/images/blog/2025-11-13/dgx-spark-testing-013254.webp)

![/png/play.png](/png/play.png)

![/svg/mobile/icon-video-play.svg](/svg/mobile/icon-video-play.svg)

DGX Spark and Cable Connection & Testing | NADDOD

[DGX Spark and Cable Connection & Testing | NADDOD](https://www.youtube.com/watch?v=EVTNX39kpms)

## Questions & Answers
![/svg/chevron-down-black.svg](/svg/chevron-down-black.svg)

Ask a Question

ALL (10)
Application (1)

Q :
When connecting two DGX Spark units with one or two 0.5m 200G QSFP56 DAC cables, is an Ethernet cable still required?
A :
Yes, you'll need an Ethernet cable or a Wi-Fi connection. DAC cables are dedicated to data transmission between devices, while the two DGX Spark units rely on an out-of-band management network for administrative communication. This network offers two options: a wired connection (Ethernet via RJ45 port, for better stability) or Wi-Fi (for easier use), so you can choose based on your needs.
Show more
![/svg/chevron-down-black.svg](/svg/chevron-down-black.svg)

Q :
What operating system (OS) does DGX Spark run?
A :
DGX Spark runs DGX OS based on Ubuntu, which is the same operating system distribution as that running on the DGX platform.
Show more
![/svg/chevron-down-black.svg](/svg/chevron-down-black.svg)

Q :
What memory and storage do two DGX Spark systems configured as a cluster provide?
A :
Two DGX Spark systems can be configured as a cluster, offering 256GB of combined memory and up to 8TB of total storage.

Q :
What is the GB10 Grace Blackwell Super Chip?
A :
The GB10 Super Chip is a system-on-chip (SoC) based on the Grace Blackwell architecture, featuring 128GB of unified system memory with unified addressing. It delivers up to 1 petaFLOP of AI performance at FP4 precision, integrating an NVIDIA Blackwell GPU equipped with the latest 5th-Generation Tensor Cores and RT Cores, as well as a high-performance Grace CPU with 20 Arm cores.
Show more
![/svg/chevron-down-black.svg](/svg/chevron-down-black.svg)

Q :
What cable is recommended for stacking/clustering two systems?
A :
The approved QSFP cables—such as Q56-200G-CU0-5[Q56-200G-CU0-5](https://www.naddod.com/products/13888.html) and Q112-400G-CU0-5[Q112-400G-CU0-5](https://www.naddod.com/products/102069.html) —are used for connecting two DGX Spark systems.
Show more
![/svg/chevron-down-black.svg](/svg/chevron-down-black.svg)

12

/
2
View More
![arrow](/png/arrow-up-blue.png)

## Customer Reviews

![/svg/chevron-down-black.svg](/svg/chevron-down-black.svg)

-

-

-

-

-

5.05 Reviews

- 5 Star
100%

- 4 Star
0%

- 3 Star
0%

- 2 Star
0%

- 1 Star
0%

-

k***8
Verified Purchase

k***8Sweden

-

-

-

-

-

5.05.0

-

-

-

-

-

5.0
I bought four DGX Sparks and four 0.5m 200G Q56 DACs. For daily use, I connect each pair of units with either one or two DACs—both work great. The remaining DACs serve as spares for redundancy. Whether using a single DAC or two, the setup runs perfectly stable with smooth, consistent performance. If a DAC ever fails, I can swap in a replacement right away. I'm really satisfied with how reliable and hassle-free the whole setup is.

![NADDOD](https://resource.naddod.com/images/2025-11-06/four-dgx-spark-and-200g-q56-dacs-013047.webp)

Verified Purchase
Helpful (7)Comments

-

m***l
Verified Purchase

m***lSwitzerland

-

-

-

-

-

5.05.0

-

-

-

-

-

5.0
I bought four DGX Sparks and wanted to connect them to my existing NVIDIA SN3700 switch. I also bought the four 200G Q56 DACs recommended for this connection later. Connecting the four DGX Sparks to the switch with these cables works well. Everything runs stably, and the performance is good. I'm happy with how it's working.

![NADDOD](https://resource.naddod.com/images/2025-11-05/four-unopend-dgx-spark-013011.webp)

Verified Purchase
Helpful (1)Comments

-

h***6
Verified Purchase

h***6China

-

-

-

-

-

5.05.0

-

-

-

-

-

5.0
Grabbed my DGX Spark and the DAC cable for linking two units, and wow, shipping was pretty speedy! The DGX Spark is surprisingly tiny—sits on my desk without hogging space, and it's easy to carry around too. The DAC cable plugs into the ports perfectly. Both are a good choice!

![NADDOD](https://resource.naddod.com/images/2025-10-30/dgx-spark-and-one-connecting-cable-012862.webp)

Verified Purchase
Helpful (8)Comments

-

r***n
Verified Purchase

r***nPhilippines

-

-

-

-

-

5.05.0

-

-

-

-

-

5.0
Got my NVIDIA DGX Spark—great! Runs smooth for AI and data tasks. Super worth it!

![NADDOD](https://resource.naddod.com/images/2025-10-30/a-dgx-spark-and-connecting-dac-cable-012864.webp)

Verified Purchase
Helpful (7)Comments

-

q***t
Verified Purchase

q***tUkraine

-

-

-

-

-

5.05.0

-

-

-

-

-

5.0
I got two DGX Spark units and a DAC cable for connecting them, and man, the shipping was super fast! Ordered it and got everything in no time. Both the DGX Spark and the DAC work like a dream—super reliable and exactly what I want.

![NADDOD](https://resource.naddod.com/images/2025-10-30/dgx-spark-012860.webp)

Verified Purchase
Helpful (2)Comments

## Resources

![/svg/chevron-down-black.svg](/svg/chevron-down-black.svg)

NVIDIA DGX Spark Datasheet[NVIDIA DGX Spark Datasheet](https://resource.naddod.com/files/2025-10-20/nvidia-dgx-spark-datasheet-web-012638.pdf)

## Quality Certification

![ISO140012015](https://resource.naddod.com/images/products/2022-10-08/iso140012015-000463.webp)

![ISO 90012015](https://resource.naddod.com/images/products/2022-10-08/iso-90012015-000462.webp)

![ISO450012018](https://resource.naddod.com/images/products/2022-10-08/iso450012018-000461.webp)

![FDA](https://resource.naddod.com/images/products/2022-10-08/fda-000460.webp)

![FCC](https://resource.naddod.com/images/products/2022-10-08/fcc-000459.webp)

![CE](https://resource.naddod.com/images/products/2022-10-08/ce-000458.webp)

![RoHS](https://resource.naddod.com/images/products/2022-10-08/rohs-000464.webp)

![TUV-Mark](https://resource.naddod.com/images/products/2022-10-08/tuv-mark-000465.webp)

![UL](https://resource.naddod.com/images/products/2022-10-08/ul-000466.webp)

![WEEE](https://resource.naddod.com/images/wb-content/2023-09-15/weee-007967.webp)

## What We Supply

![https://resource.naddod.com/images/2026-04-22/r-d-center-015784.webp](https://resource.naddod.com/images/2026-04-22/r-d-center-015784.webp)
Cutting-Edge R&D CenterLearn More[Cutting-Edge R&D CenterLearn More](/about-us/naddod-certified/research-and-development)

![https://resource.naddod.com/images/2026-04-22/performance-test-center-015782.webp](https://resource.naddod.com/images/2026-04-22/performance-test-center-015782.webp)
Performance Test CenterLearn More[Performance Test CenterLearn More](/about-us/naddod-certified/testing)

![https://resource.naddod.com/images/2026-04-22/quality-gurantee-system-015783.webp](https://resource.naddod.com/images/2026-04-22/quality-gurantee-system-015783.webp)
Quality Guarantee SystemLearn More[Quality Guarantee SystemLearn More](/about-us/naddod-certified/quality)

![https://resource.naddod.com/images/2026-04-22/manufacturing-capacity-015785.webp](https://resource.naddod.com/images/2026-04-22/manufacturing-capacity-015785.webp)
Manufacturing CapacityLearn More[Manufacturing CapacityLearn More](/about-us/naddod-certified/production)

## Reference sources

- [DGX Spark Founders Edition naddod](https://www.naddod.com/products/103029.html) — accessed 2026-11-03
