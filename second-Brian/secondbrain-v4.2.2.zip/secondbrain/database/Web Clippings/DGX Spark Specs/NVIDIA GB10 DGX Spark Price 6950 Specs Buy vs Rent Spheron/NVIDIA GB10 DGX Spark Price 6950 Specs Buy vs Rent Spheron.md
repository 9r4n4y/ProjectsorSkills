# NVIDIA GB10 DGX Spark Price 6950 Specs  Buy vs Rent  Spheron

:::quick-info
Source: https://www.spheron.network/gpu-price/gb10
Scraped: 2026-11-03
Topic: DGX Spark Specs
:::

NVIDIA GB10 (DGX Spark) Price: $6,950, Specs & Buy vs Rent | Spheron

Updated Oct 21, 2026
Desktop AI system

# NVIDIA GB10 (DGX Spark) Price: $6,950 List Price, Specs and Buy vs Rent

GB10 is the Grace Blackwell chip inside NVIDIA's DGX Spark, a small desktop box with 128GB of memory shared between a 20-core Arm CPU and a Blackwell GPU. People search for it to find out what the Spark costs and whether it beats renting a data center GPU for local model work. The answer depends mostly on memory bandwidth: 273 GB/s is enough to load very large models, but it caps how fast they generate tokens.

Compare rental

## TL;DR: GB10 price

- Price : The NVIDIA GB10 Grace Blackwell (DGX Spark) launched at $3,999 on Oct 15, 2025 and lists at $6,950 as of Oct 3, 2026.

- Specs : GB10: 128GB LPDDR5x unified memory, 273 GB/s, up to 1 PFLOP FP4 (sparse).

- Rent : Spheron does not rent the GB10; the closest card it rents is the RTX PRO 6000 (96GB) from $1.11/hr spot, live as of Nov 2, 2026.

- Break-even : $6,950 buys about 6,260 hours of RTX PRO 6000 rental at that rate, before power and the host machine.

## GB10 price history

- Oct 15, 2025
$3,999Launch price
DGX Spark went on sale at $3,999[went on sale at $3,999](https://www.theregister.com/2025/10/13/nvidia_gb10_spark/). Founders Edition with 128GB of memory and 4TB of storage.

- Feb 23, 2026
$4,699List price+$700 (+18%)
NVIDIA raised the MSRP to $4,699[raised the MSRP to $4,699](https://forums.developer.nvidia.com/t/2-23-2026-price-change-announcement/361713). NVIDIA cited worldwide memory supply constraints.

- Oct 3, 2026
$6,950List price+$2,251 (+48%)
The 128GB model now lists at about $6,950[now lists at about $6,950](https://www.servethehome.com/nvidia-dgx-spark-64gb-launched-and-big-128gb-gb10-price-increases). A 64GB model arrived alongside it at $4,999 through OEM partners from Oct 23, 2026. OEM prices vary.

## Buy the GB10 or rent a cloud GPU

Buy a DGX Spark if you want a quiet desktop machine that can hold a 70B-class model in memory, you work with sensitive data that cannot leave your desk, or you are building against NVIDIA's Arm and CUDA stack before deploying to Grace Blackwell servers.

Rent instead if token throughput matters. The Spark's 273 GB/s is a fraction of what an HBM data center GPU moves, so a rented H200 or RTX PRO 6000 serves the same model much faster, and you stop paying the moment the job ends.

RTX PRO 600096 GB[RTX PRO 600096 GB](/gpu-rental/rtx-pro-6000/)
96GB of GDDR7 on one card, the closest single-GPU match for models sized to the Spark's 128GB pool.

$1.11/hr spotlive as of Nov 2, 2026$6,950 = about 6,260 hours
H200141 GB[H200141 GB](/gpu-rental/h200/)
141GB of HBM3e at 4.8 TB/s, for the same model sizes at roughly 17x the memory bandwidth.

$3.35/hr spotlive as of Nov 2, 2026$6,950 = about 2,070 hours
A10080 GB[A10080 GB](/gpu-rental/a100/)
80GB of HBM2e for fine-tuning and serving models that fit in 80GB.

$1.20/hr spotlive as of Nov 2, 2026$6,950 = about 5,790 hours
Spheron rates are live from the marketplace when this page was built; a rate marked last offered is the most recent one on record, with its date. Hours are the GB10 's $6,950 list price divided by the hourly rate, before electricity, the host machine and resale value. See current GPU pricing[current GPU pricing](/pricing/) for every GPU Spheron rents.

## GB10 specs

ArchitectureNVIDIA Grace Blackwell (GB10)
Memory128GB LPDDR5x unified (CPU + GPU)
Memory bandwidth273 GB/s
AI computeUp to 1 PFLOP FP4 with sparsity
CUDA cores6,144
CPU20-core Arm (10 Cortex-X925 + 10 Cortex-A725)
Power140W GB10 TDP, 240W external supply
LaunchedOct 15, 2025

FAQ / 04
## GB10 price FAQ

What the GB10 costs, what it runs, and when renting beats buying.

01How much does the NVIDIA DGX Spark cost?

The DGX Spark Founders Edition with GB10 and 128GB of memory launched at $3,999 on Oct 15, 2025. NVIDIA raised its MSRP to $4,699 in February 2026, citing memory supply constraints, and the 128GB model lists at about $6,950 as of October 2026, alongside a new 64GB model at $4,999. Partner systems from Dell, ASUS, HP and others are priced separately, so check the seller for the current figure.

02Is GB10 the same as DGX Spark?

GB10 is the chip and DGX Spark is NVIDIA's system built around it. GB10 pairs a Blackwell GPU with a 20-core Arm CPU over a shared pool of 128GB LPDDR5x. Partner desktops from Dell, ASUS, HP, Lenovo and others use the same GB10 chip under their own names.

03Can the DGX Spark run a 70B model?

Yes. A 70B model quantized to 4-bit needs roughly 35-40GB for weights, which fits comfortably in 128GB of unified memory with room for KV cache. Generation speed is limited by the 273 GB/s memory bandwidth, so a dense 70B model at 4-bit generates in the single digits of tokens per second.

04Is it cheaper to buy the GB10 or rent a GPU?

At $6,950, buying the GB10 costs the same as about 6,260 hours of renting the RTX PRO 6000 on Spheron, the closest card it rents at $1.11/hr spot (live as of Nov 2, 2026). At eight hours a day that is about 2.1 years of use, before electricity, the host machine and resale value. If the card would be busy for less than that, renting costs less; if it would run longer, buying usually wins.

// Guides

## GB10 guides

More GPU Deep Dives guides →[More GPU Deep Dives guides →](/blog/topics/gpu-deep-dives/)

### DGX Spark vs Cloud Rental: Break-Even Hours

01
How many H100, H200 and B200 hours the Spark's price buys, at 20, 80 and 160 hours a month.Read[DGX Spark vs Cloud Rental: Break-Even Hours01How many H100, H200 and B200 hours the Spark's price buys, at 20, 80 and 160 hours a month.Read](/blog/dgx-spark-vs-renting-a-cloud-gpu-the-real-break-even-hours-2/)

### DGX Spark vs RTX 5090 for Local LLMs

02
Measured tokens per second when 128GB of unified memory meets a 32GB GDDR7 card.Read[DGX Spark vs RTX 5090 for Local LLMs02Measured tokens per second when 128GB of unified memory meets a 32GB GDDR7 card.Read](/blog/dgx-spark-vs-rtx-5090-for-local-llms-tokens-per-second-2026/)

### DGX Spark Fine-Tuning: What Fits in 128GB

03
LoRA, QLoRA and full fine-tune limits on GB10, model by model.Read[DGX Spark Fine-Tuning: What Fits in 128GB03LoRA, QLoRA and full fine-tune limits on GB10, model by model.Read](/blog/dgx-spark-fine-tuning-what-fits-in-128gb-unified-memory-2026/)

## Other GPU prices

RTX 3090 price
24GB GDDR6X, 936 GB/s, 10,496 CUDA cores, 350W

$1,499[RTX 3090 price24GB GDDR6X, 936 GB/s, 10,496 CUDA cores, 350W$1,499](/gpu-price/rtx-3090/)RTX 4080 Super price
16GB GDDR6X, 736 GB/s, 10,240 CUDA cores, 320W

$999[RTX 4080 Super price16GB GDDR6X, 736 GB/s, 10,240 CUDA cores, 320W$999](/gpu-price/rtx-4080-super/)RTX A6000 price
48GB GDDR6 ECC, 768 GB/s, 10,752 CUDA cores, 300W

$4,650[RTX A6000 price48GB GDDR6 ECC, 768 GB/s, 10,752 CUDA cores, 300W$4,650](/gpu-price/rtx-a6000/)
All GPU prices[All GPU prices](/gpu-price/)GPUs you can rent[GPUs you can rent](/gpu-rental/)GPU guides[GPU guides](/blog/)

## Reference sources

- [NVIDIA GB10 DGX Spark Price 6950 Specs  Buy vs Rent  Spheron](https://www.spheron.network/gpu-price/gb10) — accessed 2026-11-03
