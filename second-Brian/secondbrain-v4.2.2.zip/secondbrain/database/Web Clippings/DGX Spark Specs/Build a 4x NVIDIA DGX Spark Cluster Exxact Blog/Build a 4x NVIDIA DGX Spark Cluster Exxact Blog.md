# Build a 4x NVIDIA DGX Spark Cluster  Exxact Blog

:::quick-info
Source: https://www.exxactcorp.com/blog/deep-learning/what-you-need-to-build-a-4x-nvidia-dgx-spark-cluster-switch-cabling-power
Scraped: 2026-11-03
Topic: DGX Spark Specs
:::

Build a 4x NVIDIA DGX Spark Cluster | Exxact Blog

Skip to main content

![Exxact](https://images.exxactcorp.com/img/exx/misc/X-Exxact.svg)

Categories

- Blog

- Case Studies

- Documents

- eBooks

- News and Events

- Reference Architecture

- Supported Software

- Whitepapers

-
Return to Homepage[Return to Homepage](/)

Artificial Intelligence
# What You Need to Build a 4x NVIDIA DGX Spark Cluster: Switch, Cabling, & Power

August 7, 2026
9 min read

![EXX-Blog-What-You-Need-to-Build-a-4x-NVIDIA-DGX-Spark-Cluster-Switch-Cabling-Power.jpg](https://images.contentstack.io/v3/assets/blt71da4c740e00faaa/blt30e885fbf44a2081/6a75283f0da673797c57a7f3/EXX-Blog-What-You-Need-to-Build-a-4x-NVIDIA-DGX-Spark-Cluster-Switch-Cabling-Power.jpg?format=webp)

A single NVIDIA DGX® Spark tops out around a 200 billion parameter model on its own (with heavy quantization), like what we did with DeepSeek V4 Flash (284B). Link two units directly, and that ceiling jumps to models as large as 405 billion parameters. Four units is where the setup changes character: NVIDIA's own clustering guidance supports up to three DGX Spark systems connected with direct cables.

But four or more requires a managed network switch. We wanted to cover the build sheet actually looks like, with considerations when scaling your NVIDIA DGX Spark systems.

## Why Build a 4-Node DGX Spark Cluster?

For most NVIDIA DGX Spark deployments, their workload can be accomplished with one or two. So who is a 4x NVIDIA DGX Spark for? A 4-node NVIDIA DGX Spark cluster is for teams that want to push beyond a single desk-side AI system without jumping straight into a full data center deployment.

- Running Larger Open-Weight Models Locally: Models in the 300-billion-parameter-plus range that don't fit in one or two units' unified memory, without incurring cloud inference costs or sending data off-premises.

- Prototyping distributed AI patterns at desk scale: testing multi-node inference or fine-tuning workflows before committing to a full NVIDIA DGX system deployment.

- Data privacy and compliance requirements: workloads where the model and its data need to stay on local hardware.

It's also a real hardware investment. Four unit DGX Spark becomes a compact multi-node AI cluster: still small enough to fit into an office or lab, but powerful enough to explore workloads that a single unit simply cannot handle.

![https://images.contentstack.io/v3/assets/blt71da4c740e00faaa/bltd24129e76f3ad084/6a065ea5ea7e922a0b86ba75/dgx_spark.png](https://images.contentstack.io/v3/assets/blt71da4c740e00faaa/bltd24129e76f3ad084/6a065ea5ea7e922a0b86ba75/dgx_spark.png)

#### Your Personal AI Inference: The NVIDIA DGX Spark

Take enterprise AI anywhere. NVIDIA DGX Spark can power your LLM, Agentic AI, and model prototyping on the go! Harness datacenter power today, available now through Exxact Corporation.

Get a Quote Today [Get a Quote Today](/category/NVIDIA-DGX-Spark)

## Possible Model Sizes with Multiple DGX Spark Systems

Each DGX Spark unit is built around NVIDIA's GB10 Grace Blackwell superchip, with 128GB of unified LPDDR5x memory shared between CPU and GPU, 4TB of NVMe storage, and two ConnectX-7 network ports for interconnect alongside a 10GbE RJ-45 port.

Here's how that scales from one unit to four:

| NVIDIA DGX Spark | Combined Unified Memory | NVMe storage | Combined FP4 Tensor Throughput | Connection Method | Approx. Model Size Support (NVFP4) | Networking Switch Required?
| 1x | 128GB | 4TB | 1 petaflop | N/A | Up to 200B | No
| 2x | 256GB | 8TB | 2 petaflops | Direct QSFP Connection | Up to 400B | No
| 3x | 384GB | 12TB | 3 petaflops | Direct QSFP Connection via Mesh | Up to 600B | No
| 4x | 512GB | 16TB | 4 petaflops | Managed Switch with 4x QSFP Ports | Up to 700B to 800B | Yes
NVIDIA's own clustering guidance supports up to three DGX Spark systems connected with direct cable while four (or more) require a managed network switch.

### Setup for 2x and 3x NVIDIA DGX Spark Systems Without a Switch

Before four units make a switch necessary, it's worth seeing how NVIDIA gets two and three units talking to each other with nothing but cable.

- 2x: one cable, one port each. Two DGX Spark units connect with a single 200Gbps QSFP direct-attach cable running from port 0 on one unit to port 0 on the other. Each unit's second port sits unused in this configuration.

- 3x: a three-cable ring using both ports on every unit. We can wire three DGX Spark systems into a ring. We will need 3 200Gbps QSFP direct-attach cables to get maximum speed. Each unit's two ports will be connected to two different neighbors

- Spark A, port 0 → Spark B, port 1

- Spark B, port 0 → Spark C, port 1

- Spark C, port 0 → Spark A, port 1

##

![Setup for 3x NVIDIA DGX Spark Systems Without a Switch](https://images.contentstack.io/v3/assets/blt71da4c740e00faaa/blt2e7ac188f5d761da/6a75283f8bcd8037a4261350/EXX-Blog-What-You-Need-to-Build-a-4x-NVIDIA-DGX-Spark-Cluster-Switch-Cabling-Power-2.jpg?format=webp)

![Setup for 3x NVIDIA DGX Spark Systems Without a Switch](https://images.contentstack.io/v3/assets/blt71da4c740e00faaa/blt2e7ac188f5d761da/6a75283f8bcd8037a4261350/EXX-Blog-What-You-Need-to-Build-a-4x-NVIDIA-DGX-Spark-Cluster-Switch-Cabling-Power-2.jpg?format=webp)

### Setup for 4x NVIDIA DGX Spark Systems with MikroTik Switch

Here’s the list of things we will need to network our 4x NVIDIA DGX Spark systems together:

- 4x NVIDIA DGX Spark systems (Founders Edition[Founders Edition](/NVIDIA-940-54242-0000-000-E177346726))

- 1x MikroTik CRS804-4DDQ-HRM managed switch (available through Exxact[available through Exxact](/MikroTik-CRS804-4DDQ-HRM-E164272210)), with four 400G QSFP56-DD ports and two 10GbE management ports. It is a compact 1U unit (half-rack width) that works equally well rack-mounted or sitting on a desk. It is relatively quiet with less than 150W TDP.

- QSFP-DD to QSFP Cables: Either Configuration: The CRS804's ports are the physically deeper QSFP56-DD, not the standard QSFP112 connectors. There are two options to go with here:

- 4x QSFP-DD to QSFP56: This is the standard cable to connect our network switch to each of our four DGX Spark. Unlike our three DGX Spark configuration, it doesn’t matter which port they are connected (though it is best practice to standardize this).

- 2x QSFP-DD to 2x QSFP56 breakout: A breakout cable splits one 400G switch port into two 200G legs, so two breakout cables give four total transceivers, one per DGX Spark. This leaves two ports on our switch unpopulated while still serving our 4 DGX Sparks, so you have the potential to link 8 DGX Sparks.

- Power: each DGX Spark ships with a 240W external supply; the CRS804 draws roughly 92W typical and about 123W under load. You may need a PDU, but max power draw shouldn’t exceed 1200W, well below the standard outlet circuit 1800W peak.

### Switch Configuration: Setting Port Speed

After cabling is in place, log into the CRS804's admin console and manually set each connected port speed to 200Gbps rather than leaving it on auto-negotiate. NVIDIA's own Cluster Assistant documentation calls this out directly, instructing switch users to verify the switch is negotiating the correct port speed and adjust it manually if it isn't.

Don't be surprised when measured throughput lands closer to 100Gbps per link once the cluster is running. That's expected, not a misconfiguration. It's the PCIe Gen5 x4 ceiling inside each ConnectX-7 port showing up in practice, not a sign the switch is set wrong.

### Software Setup

NVIDIA Sync's Cluster Assistant handles most of the networking configuration automatically: node discovery, ConnectX-7 setup, IP planning, link validation, and password-less SSH between nodes. Distributed workloads also need MPI for inter-process communication and NCCL for GPU-accelerated collective operations across nodes.

Rather than repeat NVIDIA's own setup steps here, these are the official references worth working from directly:

- DGX Spark Clustering guide[DGX Spark Clustering guide](https://docs.nvidia.com/dgx/dgx-spark/spark-clustering.html) — official cabling and topology reference

- NVIDIA Sync Cluster Assistant documentation[NVIDIA Sync Cluster Assistant documentation](https://docs.nvidia.com/sync/latest/cluster-assistant.html) — the tool that configures ConnectX-7 networking and validates switch port speed

- NVIDIA Technical Blog: multi-node clustering on DGX Spark[NVIDIA Technical Blog: multi-node clustering on DGX Spark](https://developer.nvidia.com/blog/run-local-ai-agents-with-faster-models-and-multi-node-clustering-on-nvidia-dgx-spark/) — walkthrough of the clustering workflow and supported model sizes

## Frequently Asked Questions

#### Do all 4 DGX Spark units need to be identical?

Yes, firmware and software side. NVIDIA's clustering tools assume matched hardware and firmware across nodes. An easy way to do this is to clone the SSDs, OS and everything, but make sure to change the device name. Hardware side, you can use any NVIDIA DGX Spark alternative: Asus Ascent GX10, MSI EdgeXpert, Founders Edition, etc.

#### Can I use the CRS804 with fewer than 4 units?

Yes, though 2 or 3 units are simpler and cheaper to connect with direct cables instead. You can also expand your cluster up to 8 DGX Sparks with breakout cables.

#### Does this replace a full DGX server?

No. It's a desk-scale or homelab way to prototype multi-node workflows and run larger models and multiple concurrent AI locally, not an enterprise cluster replacement. Think of it as a NVIDIA DGX prototype.

#### Why set the switch port speed manually instead of letting it auto-negotiate?

The auto-negotiation often sets the switch port speeds to 50Gbps, which is not the maximum or ideal networking speed the DGX Spark can push. NVIDIA's own Cluster Assistant guidance flags this as a common point of misconfiguration and instructs users to check and correct it directly in the switch's admin console.

#### What models can I realistically run on 4 nodes?

On a 4× DGX Spark cluster (~512GB unified memory total), you can realistically target:

- One large “fits only with 4 nodes” model (inference): DeepSeek-R1 671B (quantized, e.g., 4-bit class) — this is the kind of “700B-ish” model scale that typically won’t be practical on 1–2 nodes, but becomes feasible once you have ~512GB total memory (with careful quantization and multi-node tensor/pipeline parallelism).

- Several mid-large models concurrently (great real-world use case): Example: run 4 separate services like Llama 3 70B (one per node) for multiple users/agents, or 2× Llama 3 70B + 2× Qwen2.5 32B for mixed workloads (chat + code + RAG).

Rule of thumb: 4 nodes is mainly about either (a) pushing into ~hundreds-of-billions parameter inference with quantization, or (b) running multiple 30B–70B-class models at the same time with good latency.

## Conclusion

A 4-node DGX Spark cluster sits in a specific niche: bigger than what a single desk-side unit can handle, smaller and cheaper than a dedicated DGX server deployment. It's a reasonable way to test multi-node inference and agent workflows against genuinely large models before deciding whether a full server or cluster purchase is justified.

Exxact carries the DGX Spark units and the MikroTik CRS804-4DDQ-HRM switch, and all the cables you may need. We also supply the broader lineup of HPC and AI hardware for teams scaling past a single workstation. If a 4-node cluster is the right fit for your workload, configuring the switch and matching compute together is the natural next step.

![https://images.contentstack.io/v3/assets/blt71da4c740e00faaa/bltd24129e76f3ad084/6a065ea5ea7e922a0b86ba75/dgx_spark.png](https://images.contentstack.io/v3/assets/blt71da4c740e00faaa/bltd24129e76f3ad084/6a065ea5ea7e922a0b86ba75/dgx_spark.png)

#### Your Personal AI Inference: The NVIDIA DGX Spark

Take enterprise AI anywhere. NVIDIA DGX Spark can power your LLM, Agentic AI, and model prototyping on the go! Harness datacenter power today, available now through Exxact Corporation.

Get a Quote Today [Get a Quote Today](/category/NVIDIA-DGX-Spark)

### Sign up for our newsletter.

Sign up

#### Related Posts

![EXX-Blog-how-to-run-code.jpg](https://images.contentstack.io/v3/assets/blt71da4c740e00faaa/blt9b22a9c54b157238/6a5974c845678e19cf6e4634/EXX-Blog-how-to-run-code.jpg?format=webp)

##### Artificial Intelligence

#### How to Run Claude Code Locally and Save Thousands of Dollars

November 2, 2026
14 min read [Artificial Intelligence How to Run Claude Code Locally and Save Thousands of Dollars November 2, 2026 14 min read](/blog/deep-learning/how-to-run-claude-code-locally-and-save-money)

![2x Workstations built on NVIDIA DGX Station B300 Do in Agentic AI_.jpg](https://images.contentstack.io/v3/assets/blt71da4c740e00faaa/blt3afc97b4a4dec0b9/6abc4a1d280cccdc81663d31/2x_Workstations_built_on_NVIDIA_DGX_Station_B300_Do_in_Agentic_AI_.jpg?format=webp)

##### Artificial Intelligence

#### What Can 2x Workstations built on NVIDIA DGX Station B300 Do for Agentic AI?

September 28, 2026
10 min read [Artificial Intelligence What Can 2x Workstations built on NVIDIA DGX Station B300 Do for Agentic AI? September 28, 2026 10 min read](/blog/deep-learning/what-can-2x-workstations-built-on-nvidia-dgx-station-b300-do-for-agentic-ai)

![Exxact Valence with GB300 vs Exxact Valence 4x Max-Q.jpg](https://images.contentstack.io/v3/assets/blt71da4c740e00faaa/bltbf7828d69f98fac1/6aa85eb5a4ecdf64eaca813c/Exxact_Valence_with_GB300_vs_Exxact_Valence_4x_Max-Q.jpg?format=webp)

##### Artificial Intelligence

#### Exxact Valence with GB300 vs. 4x RTX PRO 6000 for Agentic AI: One Big Model or Many at Once

September 14, 2026
10 min read [Artificial Intelligence Exxact Valence with GB300 vs. 4x RTX PRO 6000 for Agentic AI: One Big Model or Many at Once September 14, 2026 10 min read](/blog/deep-learning/exxact-valence-gb300-vs-4x-rtx-pro-6000-for-agentic-ai)

#### Topics

dgx spark [dgx spark](/blog/result/tag/dgx%20spark)
cluster [cluster](/blog/result/tag/cluster)
agentic ai [agentic ai](/blog/result/tag/agentic%20ai)

#### Have any questions?

Contact us today chevron_right[Contact us today chevron_right](/Contact-Us)

Related Posts

![EXX-Blog-how-to-run-code.jpg](https://images.contentstack.io/v3/assets/blt71da4c740e00faaa/blt9b22a9c54b157238/6a5974c845678e19cf6e4634/EXX-Blog-how-to-run-code.jpg?format=webp)

##### Artificial Intelligence

#### How to Run Claude Code Locally and Save Thousands of Dollars

November 2, 2026
14 min read [Artificial Intelligence How to Run Claude Code Locally and Save Thousands of Dollars November 2, 2026 14 min read](/blog/deep-learning/how-to-run-claude-code-locally-and-save-money)

![2x Workstations built on NVIDIA DGX Station B300 Do in Agentic AI_.jpg](https://images.contentstack.io/v3/assets/blt71da4c740e00faaa/blt3afc97b4a4dec0b9/6abc4a1d280cccdc81663d31/2x_Workstations_built_on_NVIDIA_DGX_Station_B300_Do_in_Agentic_AI_.jpg?format=webp)

##### Artificial Intelligence

#### What Can 2x Workstations built on NVIDIA DGX Station B300 Do for Agentic AI?

September 28, 2026
10 min read [Artificial Intelligence What Can 2x Workstations built on NVIDIA DGX Station B300 Do for Agentic AI? September 28, 2026 10 min read](/blog/deep-learning/what-can-2x-workstations-built-on-nvidia-dgx-station-b300-do-for-agentic-ai)

![Exxact Valence with GB300 vs Exxact Valence 4x Max-Q.jpg](https://images.contentstack.io/v3/assets/blt71da4c740e00faaa/bltbf7828d69f98fac1/6aa85eb5a4ecdf64eaca813c/Exxact_Valence_with_GB300_vs_Exxact_Valence_4x_Max-Q.jpg?format=webp)

##### Artificial Intelligence

#### Exxact Valence with GB300 vs. 4x RTX PRO 6000 for Agentic AI: One Big Model or Many at Once

September 14, 2026
10 min read [Artificial Intelligence Exxact Valence with GB300 vs. 4x RTX PRO 6000 for Agentic AI: One Big Model or Many at Once September 14, 2026 10 min read](/blog/deep-learning/exxact-valence-gb300-vs-4x-rtx-pro-6000-for-agentic-ai)

### Our Goal

We're developing this blog to help engineers, developers, researchers, and hobbyists on the cutting edge cultivate knowledge, uncover compelling new ideas, and find helpful instruction all in one place.

![EXX-Blog-What-You-Need-to-Build-a-4x-NVIDIA-DGX-Spark-Cluster-Switch-Cabling-Power.jpg](https://images.contentstack.io/v3/assets/blt71da4c740e00faaa/blt30e885fbf44a2081/6a75283f0da673797c57a7f3/EXX-Blog-What-You-Need-to-Build-a-4x-NVIDIA-DGX-Spark-Cluster-Switch-Cabling-Power.jpg?format=webp)

Artificial Intelligence
## What You Need to Build a 4x NVIDIA DGX Spark Cluster: Switch, Cabling, & Power

August 7, 20269 min read

A single NVIDIA DGX® Spark tops out around a 200 billion parameter model on its own (with heavy quantization), like what we did with DeepSeek V4 Flash (284B). Link two units directly, and that ceiling jumps to models as large as 405 billion parameters. Four units is where the setup changes character: NVIDIA's own clustering guidance supports up to three DGX Spark systems connected with direct cables.

But four or more requires a managed network switch. We wanted to cover the build sheet actually looks like, with considerations when scaling your NVIDIA DGX Spark systems.

## Why Build a 4-Node DGX Spark Cluster?

For most NVIDIA DGX Spark deployments, their workload can be accomplished with one or two. So who is a 4x NVIDIA DGX Spark for? A 4-node NVIDIA DGX Spark cluster is for teams that want to push beyond a single desk-side AI system without jumping straight into a full data center deployment.

- Running Larger Open-Weight Models Locally: Models in the 300-billion-parameter-plus range that don't fit in one or two units' unified memory, without incurring cloud inference costs or sending data off-premises.

- Prototyping distributed AI patterns at desk scale: testing multi-node inference or fine-tuning workflows before committing to a full NVIDIA DGX system deployment.

- Data privacy and compliance requirements: workloads where the model and its data need to stay on local hardware.

It's also a real hardware investment. Four unit DGX Spark becomes a compact multi-node AI cluster: still small enough to fit into an office or lab, but powerful enough to explore workloads that a single unit simply cannot handle.

![https://images.contentstack.io/v3/assets/blt71da4c740e00faaa/bltd24129e76f3ad084/6a065ea5ea7e922a0b86ba75/dgx_spark.png](https://images.contentstack.io/v3/assets/blt71da4c740e00faaa/bltd24129e76f3ad084/6a065ea5ea7e922a0b86ba75/dgx_spark.png)

#### Your Personal AI Inference: The NVIDIA DGX Spark

Take enterprise AI anywhere. NVIDIA DGX Spark can power your LLM, Agentic AI, and model prototyping on the go! Harness datacenter power today, available now through Exxact Corporation.

Get a Quote Today [Get a Quote Today](/category/NVIDIA-DGX-Spark)

## Possible Model Sizes with Multiple DGX Spark Systems

Each DGX Spark unit is built around NVIDIA's GB10 Grace Blackwell superchip, with 128GB of unified LPDDR5x memory shared between CPU and GPU, 4TB of NVMe storage, and two ConnectX-7 network ports for interconnect alongside a 10GbE RJ-45 port.

Here's how that scales from one unit to four:

| NVIDIA DGX Spark | Combined Unified Memory | NVMe storage | Combined FP4 Tensor Throughput | Connection Method | Approx. Model Size Support (NVFP4) | Networking Switch Required?
| 1x | 128GB | 4TB | 1 petaflop | N/A | Up to 200B | No
| 2x | 256GB | 8TB | 2 petaflops | Direct QSFP Connection | Up to 400B | No
| 3x | 384GB | 12TB | 3 petaflops | Direct QSFP Connection via Mesh | Up to 600B | No
| 4x | 512GB | 16TB | 4 petaflops | Managed Switch with 4x QSFP Ports | Up to 700B to 800B | Yes
NVIDIA's own clustering guidance supports up to three DGX Spark systems connected with direct cable while four (or more) require a managed network switch.

### Setup for 2x and 3x NVIDIA DGX Spark Systems Without a Switch

Before four units make a switch necessary, it's worth seeing how NVIDIA gets two and three units talking to each other with nothing but cable.

- 2x: one cable, one port each. Two DGX Spark units connect with a single 200Gbps QSFP direct-attach cable running from port 0 on one unit to port 0 on the other. Each unit's second port sits unused in this configuration.

- 3x: a three-cable ring using both ports on every unit. We can wire three DGX Spark systems into a ring. We will need 3 200Gbps QSFP direct-attach cables to get maximum speed. Each unit's two ports will be connected to two different neighbors

- Spark A, port 0 → Spark B, port 1

- Spark B, port 0 → Spark C, port 1

- Spark C, port 0 → Spark A, port 1

##

![https://images.contentstack.io/v3/assets/blt71da4c740e00faaa/blt2e7ac188f5d761da/6a75283f8bcd8037a4261350/EXX-Blog-What-You-Need-to-Build-a-4x-NVIDIA-DGX-Spark-Cluster-Switch-Cabling-Power-2.jpg?format=webp](https://images.contentstack.io/v3/assets/blt71da4c740e00faaa/blt2e7ac188f5d761da/6a75283f8bcd8037a4261350/EXX-Blog-What-You-Need-to-Build-a-4x-NVIDIA-DGX-Spark-Cluster-Switch-Cabling-Power-2.jpg?format=webp)

### Setup for 4x NVIDIA DGX Spark Systems with MikroTik Switch

Here’s the list of things we will need to network our 4x NVIDIA DGX Spark systems together:

- 4x NVIDIA DGX Spark systems (Founders Edition[Founders Edition](/NVIDIA-940-54242-0000-000-E177346726))

- 1x MikroTik CRS804-4DDQ-HRM managed switch (available through Exxact[available through Exxact](/MikroTik-CRS804-4DDQ-HRM-E164272210)), with four 400G QSFP56-DD ports and two 10GbE management ports. It is a compact 1U unit (half-rack width) that works equally well rack-mounted or sitting on a desk. It is relatively quiet with less than 150W TDP.

- QSFP-DD to QSFP Cables: Either Configuration: The CRS804's ports are the physically deeper QSFP56-DD, not the standard QSFP112 connectors. There are two options to go with here:

- 4x QSFP-DD to QSFP56: This is the standard cable to connect our network switch to each of our four DGX Spark. Unlike our three DGX Spark configuration, it doesn’t matter which port they are connected (though it is best practice to standardize this).

- 2x QSFP-DD to 2x QSFP56 breakout: A breakout cable splits one 400G switch port into two 200G legs, so two breakout cables give four total transceivers, one per DGX Spark. This leaves two ports on our switch unpopulated while still serving our 4 DGX Sparks, so you have the potential to link 8 DGX Sparks.

- Power: each DGX Spark ships with a 240W external supply; the CRS804 draws roughly 92W typical and about 123W under load. You may need a PDU, but max power draw shouldn’t exceed 1200W, well below the standard outlet circuit 1800W peak.

### Switch Configuration: Setting Port Speed

After cabling is in place, log into the CRS804's admin console and manually set each connected port speed to 200Gbps rather than leaving it on auto-negotiate. NVIDIA's own Cluster Assistant documentation calls this out directly, instructing switch users to verify the switch is negotiating the correct port speed and adjust it manually if it isn't.

Don't be surprised when measured throughput lands closer to 100Gbps per link once the cluster is running. That's expected, not a misconfiguration. It's the PCIe Gen5 x4 ceiling inside each ConnectX-7 port showing up in practice, not a sign the switch is set wrong.

### Software Setup

NVIDIA Sync's Cluster Assistant handles most of the networking configuration automatically: node discovery, ConnectX-7 setup, IP planning, link validation, and password-less SSH between nodes. Distributed workloads also need MPI for inter-process communication and NCCL for GPU-accelerated collective operations across nodes.

Rather than repeat NVIDIA's own setup steps here, these are the official references worth working from directly:

- DGX Spark Clustering guide[DGX Spark Clustering guide](https://docs.nvidia.com/dgx/dgx-spark/spark-clustering.html) — official cabling and topology reference

- NVIDIA Sync Cluster Assistant documentation[NVIDIA Sync Cluster Assistant documentation](https://docs.nvidia.com/sync/latest/cluster-assistant.html) — the tool that configures ConnectX-7 networking and validates switch port speed

- NVIDIA Technical Blog: multi-node clustering on DGX Spark[NVIDIA Technical Blog: multi-node clustering on DGX Spark](https://developer.nvidia.com/blog/run-local-ai-agents-with-faster-models-and-multi-node-clustering-on-nvidia-dgx-spark/) — walkthrough of the clustering workflow and supported model sizes

## Frequently Asked Questions

#### Do all 4 DGX Spark units need to be identical?

Yes, firmware and software side. NVIDIA's clustering tools assume matched hardware and firmware across nodes. An easy way to do this is to clone the SSDs, OS and everything, but make sure to change the device name. Hardware side, you can use any NVIDIA DGX Spark alternative: Asus Ascent GX10, MSI EdgeXpert, Founders Edition, etc.

#### Can I use the CRS804 with fewer than 4 units?

Yes, though 2 or 3 units are simpler and cheaper to connect with direct cables instead. You can also expand your cluster up to 8 DGX Sparks with breakout cables.

#### Does this replace a full DGX server?

No. It's a desk-scale or homelab way to prototype multi-node workflows and run larger models and multiple concurrent AI locally, not an enterprise cluster replacement. Think of it as a NVIDIA DGX prototype.

#### Why set the switch port speed manually instead of letting it auto-negotiate?

The auto-negotiation often sets the switch port speeds to 50Gbps, which is not the maximum or ideal networking speed the DGX Spark can push. NVIDIA's own Cluster Assistant guidance flags this as a common point of misconfiguration and instructs users to check and correct it directly in the switch's admin console.

#### What models can I realistically run on 4 nodes?

On a 4× DGX Spark cluster (~512GB unified memory total), you can realistically target:

- One large “fits only with 4 nodes” model (inference): DeepSeek-R1 671B (quantized, e.g., 4-bit class) — this is the kind of “700B-ish” model scale that typically won’t be practical on 1–2 nodes, but becomes feasible once you have ~512GB total memory (with careful quantization and multi-node tensor/pipeline parallelism).

- Several mid-large models concurrently (great real-world use case): Example: run 4 separate services like Llama 3 70B (one per node) for multiple users/agents, or 2× Llama 3 70B + 2× Qwen2.5 32B for mixed workloads (chat + code + RAG).

Rule of thumb: 4 nodes is mainly about either (a) pushing into ~hundreds-of-billions parameter inference with quantization, or (b) running multiple 30B–70B-class models at the same time with good latency.

## Conclusion

A 4-node DGX Spark cluster sits in a specific niche: bigger than what a single desk-side unit can handle, smaller and cheaper than a dedicated DGX server deployment. It's a reasonable way to test multi-node inference and agent workflows against genuinely large models before deciding whether a full server or cluster purchase is justified.

Exxact carries the DGX Spark units and the MikroTik CRS804-4DDQ-HRM switch, and all the cables you may need. We also supply the broader lineup of HPC and AI hardware for teams scaling past a single workstation. If a 4-node cluster is the right fit for your workload, configuring the switch and matching compute together is the natural next step.

![https://images.contentstack.io/v3/assets/blt71da4c740e00faaa/bltd24129e76f3ad084/6a065ea5ea7e922a0b86ba75/dgx_spark.png](https://images.contentstack.io/v3/assets/blt71da4c740e00faaa/bltd24129e76f3ad084/6a065ea5ea7e922a0b86ba75/dgx_spark.png)

#### Your Personal AI Inference: The NVIDIA DGX Spark

Take enterprise AI anywhere. NVIDIA DGX Spark can power your LLM, Agentic AI, and model prototyping on the go! Harness datacenter power today, available now through Exxact Corporation.

Get a Quote Today [Get a Quote Today](/category/NVIDIA-DGX-Spark)

#### Related Posts

![EXX-Blog-how-to-run-code.jpg](https://images.contentstack.io/v3/assets/blt71da4c740e00faaa/blt9b22a9c54b157238/6a5974c845678e19cf6e4634/EXX-Blog-how-to-run-code.jpg?format=webp)

##### Artificial Intelligence

#### How to Run Claude Code Locally and Save Thousands of Dollars

November 2, 2026
14 min read [Artificial Intelligence How to Run Claude Code Locally and Save Thousands of Dollars November 2, 2026 14 min read](/blog/deep-learning/how-to-run-claude-code-locally-and-save-money)

![2x Workstations built on NVIDIA DGX Station B300 Do in Agentic AI_.jpg](https://images.contentstack.io/v3/assets/blt71da4c740e00faaa/blt3afc97b4a4dec0b9/6abc4a1d280cccdc81663d31/2x_Workstations_built_on_NVIDIA_DGX_Station_B300_Do_in_Agentic_AI_.jpg?format=webp)

##### Artificial Intelligence

#### What Can 2x Workstations built on NVIDIA DGX Station B300 Do for Agentic AI?

September 28, 2026
10 min read [Artificial Intelligence What Can 2x Workstations built on NVIDIA DGX Station B300 Do for Agentic AI? September 28, 2026 10 min read](/blog/deep-learning/what-can-2x-workstations-built-on-nvidia-dgx-station-b300-do-for-agentic-ai)

![Exxact Valence with GB300 vs Exxact Valence 4x Max-Q.jpg](https://images.contentstack.io/v3/assets/blt71da4c740e00faaa/bltbf7828d69f98fac1/6aa85eb5a4ecdf64eaca813c/Exxact_Valence_with_GB300_vs_Exxact_Valence_4x_Max-Q.jpg?format=webp)

##### Artificial Intelligence

#### Exxact Valence with GB300 vs. 4x RTX PRO 6000 for Agentic AI: One Big Model or Many at Once

September 14, 2026
10 min read [Artificial Intelligence Exxact Valence with GB300 vs. 4x RTX PRO 6000 for Agentic AI: One Big Model or Many at Once September 14, 2026 10 min read](/blog/deep-learning/exxact-valence-gb300-vs-4x-rtx-pro-6000-for-agentic-ai)

![EXX-Blog-How-We-Ran-Ten-Parallel-Million-Token-Agents-on-a-Single-Exxact-Valence-Workstation-on-GB300.jpg](https://images.contentstack.io/v3/assets/blt71da4c740e00faaa/bltb61935eda99d4b74/6a961ef2ecdaa77bf30520fd/EXX-Blog-How-We-Ran-Ten-Parallel-Million-Token-Agents-on-a-Single-Exxact-Valence-Workstation-on-GB300.jpg?format=webp)

##### Artificial Intelligence

#### How We Ran Ten AI Agents each with 1M Tokens of Context Each on an Exxact Valence Workstation with GB300

August 31, 2026
11 min read [Artificial Intelligence How We Ran Ten AI Agents each with 1M Tokens of Context Each on an Exxact Valence Workstation with GB300 August 31, 2026 11 min read](/blog/deep-learning/10x-million-token-context-ai-agents-in-parallel-on-a-single-workstation)

### Sign up for our newsletter.

Sign upchevron_right

#### Topics

dgx spark [dgx spark](/blog/result/tag/dgx%20spark)
cluster [cluster](/blog/result/tag/cluster)
agentic ai [agentic ai](/blog/result/tag/agentic%20ai)

#### Have any questions?

Contact us today chevron_right[Contact us today chevron_right](/Contact-Us)

![logo](https://images.exxactcorp.com/img/exx/misc/x-emblem.svg)

Sign up for our newsletter.

© 2026 Exxact Corporation |Privacy[Privacy](/Privacy)|Consent Preferences|Cookies

## Reference sources

- [Build a 4x NVIDIA DGX Spark Cluster  Exxact Blog](https://www.exxactcorp.com/blog/deep-learning/what-you-need-to-build-a-4x-nvidia-dgx-spark-cluster-switch-cabling-power) — accessed 2026-11-03
