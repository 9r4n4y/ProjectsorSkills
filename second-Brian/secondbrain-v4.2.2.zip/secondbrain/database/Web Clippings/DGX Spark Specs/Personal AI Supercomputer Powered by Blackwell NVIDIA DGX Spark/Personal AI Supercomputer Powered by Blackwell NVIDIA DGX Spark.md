# Personal AI Supercomputer Powered by Blackwell  NVIDIA DGX Spark

:::quick-info
Source: https://www.nvidia.com/en-us/products/workstations/dgx-spark/
Scraped: 2026-11-03
Topic: DGX Spark Specs
:::

Personal AI Supercomputer Powered by Blackwell | NVIDIA DGX Spark

![data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=)

#

NVIDIA DGX Spark

Designed to build and run autonomous agents.

###

Where to Buy

Find your best purchase option on the NVIDIA Marketplace.

Buy Now

[Buy Now](https://marketplace.nvidia.com/en-us/enterprise/personal-ai-supercomputers/?superchip=GB10&page=1&limit=15)

Support

[Support](https://www.nvidia.com/en-us/support/dgx-spark/)

Datasheet[Datasheet](https://dam-cdn.nvd.orangelogic.com/AssetLink/es6d60li4v5hybk461p65is6os33c48h.pdf) | Specifications | Forum[Forum](https://forums.developer.nvidia.com/c/accelerated-computing/dgx-spark-gb10/719)

-
Overview

-
Features

-
Workloads

-
Software

-
Partners

-
Overview

-
Features

-
Workloads

-
Software

-
Partners

-
Overview

-
Features

-
Workloads

-
Software

-
Partners

Buy Now

[Buy Now](https://marketplace.nvidia.com/en-us/enterprise/personal-ai-supercomputers/?superchip=GB10&page=1&limit=15)

![data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=)

A New Beginning for Windows PCs

Powered by NVIDIA RTX Spark.

Out Now

[Out Now](https://nvidianews.nvidia.com/news/nvidia-rtx-spark-pcs-available-today-a-new-beginning-for-windows-pcs)

###

Overview

##

Your Desktop Agent Computer

Powered by the NVIDIA GB10 Grace Blackwell Superchip, NVIDIA DGX Spark™ is a complete platform for local autonomous agents. Large local memory, powerful AI compute and the NVIDIA AI software stack enable agents and large models to run locally, reducing the need for cloud-based token generation resources. With a compact, power-efficient design, DGX Spark is built to run always-on agent workloads—right from your desktop.

##

NVIDIA GB10 Grace Blackwell Superchip

Up to

###

20-core

Grace CPU

Up to

###

1 petaFLOP

FP4 AI Performance

Up to

###

128 GB

Unified Memory

###

NVIDIA GB10 Superchip

Experience up to 1 petaFLOP of AI performance at FP4 precision with the NVIDIA Grace Blackwell architecture.

###

Coherent Unified System Memory

Run AI development and testing workloads with state-of-the-art AI models at your desktop with a large, unified system memory. Available in 64 GB* or 128 GB memory configuration options.

###

NVIDIA ConnectX Networking

High-performance NVIDIA ConnectX™ networking enables up to four DGX Spark systems to work together on larger AI models, deliver faster inference, and run multi-agent workloads.

###

NVIDIA AI Software Stack

Utilize a full-stack solution for generative AI workloads, encompassing NVIDIA tools, frameworks, libraries, and pre-trained models, including NVIDIA NIM™.

###

NVIDIA Sync

Connect to your DGX Spark from your laptop or desktop and monitor system status, launch Cursor, VS Code, or AI Workbench remotely, and configure up to four devices into a high-speed multi-node cluster. Install the latest software updates to get the most out of your system.

*64 GB memory configuration is available exclusively through participating OEM partners.

---

##

Workloads

##

Accelerate All Your AI Workloads

Delivering the power of Grace Blackwell in a desktop-friendly size, DGX Spark is ideal for AI developer, researcher, and data scientist workloads.

####
Agentic AI

Build, run, and manage always-on AI agents from your desk.

DGX Spark provides a complete local platform to develop, test, and deploy autonomous AI agents. With the NVIDIA AI software stack preinstalled—including tools for agent orchestration, evaluation, and secure local deployment—developers can build agents that run persistently and privately, without cloud dependency. From single-agent prototypes to multi-agent workflows, DGX Spark supports the full agentic development cycle.

![Person prototyping on a laptop.](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=)

####
Prototyping

Develop, test, and validate AI models and applications.

With the NVIDIA AI software stack, DGX Spark provides a platform for developers to create, test, and validate AI models, and build AI agents, AI-augmented applications, and solutions. For final tuning or deployment, conveniently evaluate the work for eventual migration to the NVIDIA DGX™ cloud or other NVIDIA-accelerated data centers or cloud infrastructures.

![Person prototyping on a laptop.](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=)

####
Fine-Tuning

Fine-tune AI models up to 70 billion parameters.

Improve pre-trained model performance by fine-tuning on DGX Spark. With up to 128 GB of unified system memory, fine-tune models up to 70 billion parameters to customize AI models and solutions for specific needs and use cases.

![Image of interconnected AI models.](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=)

####
Inference

Test, validate, and inference with AI models up to 200 billion parameters.

Fifth-generation Tensor Cores with support for FP4 deliver up to 1 petaFLOP of AI computing performance, combined with up to 128 GB of system memory, accelerating inference of state-of-the-art AI models to test, validate, and deploy from your DGX Spark.

![Image of code being validated.](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=)

####
Data Science

High-performance data science at your desk.

DGX Spark’s combination of up to 128 GB of unified memory and 1 petaFLOP of parallel throughput maximizes performance of large, computationally complex data analytics and machine learning workflows at your desk.

![Image of NYC overlaying trip distance and tip data.](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=)

####
Edge Applications

Develop edge applications with NVIDIA AI frameworks, including NVIDIA Isaac™, Metropolis, and many others.

DGX Spark offers an exceptional platform for developing robotics, smart city, and computer vision solutions. NVIDIA frameworks include Isaac[Isaac](https://developer.nvidia.com/isaac), Metropolis[Metropolis](https://www.nvidia.com/en-us/autonomous-machines/intelligent-video-analytics-platform/), and Holoscan[Holoscan](https://developer.nvidia.com/holoscan-sdk), enabling developers to leverage the power of DGX Spark to develop edge applications quickly.

![Image of a robot stacking blocks.](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=)

##

Scale to Larger Models, Faster Inference, and Agentic Workloads

Run frontier-class models on desktop clusters.

###
1x DGX Spark

64 GB*

Up to 100B parameters

###
1x DGX Spark

128 GB

Up to 200B parameters

###
2x 64 GB DGX Spark

128 GB

Up to 200B parameters

###
2x 128 GB DGX Spark

256 GB

Up to 400B parameters

###
4x DGX Spark

512 GB

Up to 700B parameters

*64 GB memory configuration is available exclusively through participating OEM partners.

DGX Spark for Developers

##

Everything You Need to Build, Run, and Deploy AI Locally

###
NVIDIA Open Agent Safety Platform

NVIDIA Open Agent Safety Platform™ is an open software platform and reference system design built with industry, researchers, and public-sector organizations to strengthen AI security from agent testing to deployment so the world can unlock the full potential of agentic AI, safely.

Learn More

[Learn More](https://www.nvidia.com/en-us/solutions/ai/agent-safety/)

###
NVIDIA OpenShell

NVIDIA OpenShell™ is a safe runtime for AI agents. It provides sandboxed execution environments and policy enforcement to govern agent behavior.

Learn More

[Learn More](https://www.nvidia.com/en-us/ai/openshell/)

###
NVIDIA NemoClaw

NVIDIA NemoClaw™ is a collection of open blueprints for building autonomous agents: domain-specialized, always-on AI systems that reason, plan, and act across real-world workflows

Learn More

[Learn More](https://www.nvidia.com/en-us/ai/nemoclaw/)

###
NVIDIA Nemotron

NVIDIA Nemotron™ is a family of highly efficient, multimodal, open AI models built for long-running autonomous agents: high-throughput, openly licensed AI systems that reason, plan, and act across complex, multi-step workflows—deployable anywhere from edge to cloud.

Learn More

[Learn More](https://www.nvidia.com/en-us/ai-data-science/foundation-models/nemotron/)

###
NVIDIA AI Enterprise

A cloud-native suite of software tools, libraries, and frameworks accelerating production-grade AI development. Combines enterprise-grade security, optimized performance, and enterprise-level support to streamline prototype-to-production for next-gen agentic AI.

Learn More

[Learn More](https://enterpriseproductregistration.nvidia.com/?LicType=Eval&ProductFamily=NVAIE_DGX_SPARK)

###
NVIDIA Local AI

NVIDIA Local AI is a full-stack platform for building and running AI privately on DGX Spark and NVIDIA GPUs: optimized models, accelerated inference backends, agentic frameworks, and developer tools—all running locally on your desk, with no data leaving your machine, so you can experiment, build, and deploy AI faster than ever.

Learn More

[Learn More](https://developer.nvidia.com/topics/ai/local-ai)

##

Playbooks for Everyone

From novice to expert, leverage our curated playbooks to get off to a running start on various projects. Playbooks contain step-by-step recipes to demonstrate the art of the possible.

Browse DGX Spark Playbooks

[Browse DGX Spark Playbooks](http://build.nvidia.com/spark)

Resources

##

Explore NVIDIA DGX Spark

-

Blogs

-

Videos

-

Livestreams

October 2, 2026

###
NVIDIA DGX Spark 64 GB Gives Developers More Ways to Build and Scale Local AI

DGX Spark 64 GB runs capable local agents on device and works with our new NVIDIA Sync Cluster Assistant to seamlessly pair systems for larger workloads.

Read Blog

[Read Blog](https://blogs.nvidia.com/blog/local-ai-dgx-spark-64gb-sync/)

March 16, 2026

###
Scaling Autonomous AI Agents and Workloads with NVIDIA DGX Spark

Learn why NVIDIA DGX Spark is an ideal desktop platform for autonomous AI.

Read Blog

[Read Blog](https://developer.nvidia.com/blog/scaling-autonomous-ai-agents-and-workloads-with-nvidia-dgx-spark/)

February 12, 2026

###
NVIDIA DGX Spark Powers Big Projects in Higher Education

The desktop supercomputer is sparking innovation across research fields, from campus labs to the South Pole.

Read Blog

[Read Blog](https://blogs.nvidia.com/blog/dgx-spark-higher-education/)

January 5, 2026

###
NVIDIA DGX Spark Gains 2x Performance and Open AI Model Support

The latest DGX Spark software release delivers performance uplift across models and workflows.

Read Blog

[Read Blog](https://blogs.nvidia.com/blog/dgx-spark-and-station-open-source-frontier-models/)

February 20, 2026

###
Meet the AI Photo Booth: DGX Spark + Reachy Mini at CES

At CES 2026, the NVIDIA DGX Spark powers the Reachy Mini robot in an interactive photo booth with Pollen Robotics (Hugging Face).

Watch Video

[Watch Video](https://www.youtube.com/watch?v=e1UTUZ8lfTs)

January 5, 2026

###
Build Your Own AI Assistant With Hugging Face on NVIDIA DGX Spark

NVIDIA and Hugging Face are bringing AI agents to life.

Watch Video

[Watch Video](https://www.youtube.com/watch?v=dMpLCGvE2A0)

October 15, 2025

###
Sparking Something Big: NVIDIA DGX Spark Has Arrived

It’s here! Go behind the scenes and see the delivery of NVIDIA DGX Sparks to top developers, researchers, creative studios, and roboticists.

Watch Video

[Watch Video](https://www.youtube.com/watch?v=AvgZscNZzYw)

###
DGX Spark Live: Perplexity Portable Computer Goes Local

See how you can run agentic AI fully on-device on NVIDIA DGX Spark — analyzing sensitive documents and diagnosing product funnels locally, with optional cloud escalation only when you choose.

Watch Now

[Watch Now](https://www.youtube.com/live/euQoPqGXVlk?si=42TpiSHgWIPGJB8N)

###
DGX Spark Live: Autonomous AI Agent Migration

Watch a live demo of an NVIDIA NemoClaw agent running Qwen3-Coder on-device, autonomously migrating a legacy x86 application to Arm via the Arm MCP Server.

Watch Now

[Watch Now](https://www.youtube.com/live/wfPZH6Fmlzc?si=bL4hkW_8zuoASl87)

###
DGX Spark Live: Smart Routing for Hybrid AI

Learn how a lightweight judge model evaluates each incoming request and sends it to the right destination, choosing between local models and the cloud based on what the job actually needs.

Watch Now

[Watch Now](https://www.youtube.com/live/XY6ySMd2Lzs?si=x-rC2opItgRnbY72)

See All Livestreams

[See All Livestreams](https://www.youtube.com/watch?v=XY6ySMd2Lzs&list=PL5B692fm6--szoycV51n_dI29J8wGP9_-&index=1)

##

Partners

##

NVIDIA DGX Spark

Get DGX Spark through our authorized channel and retail partners.

##

NVIDIA DGX Spark Powered Systems

Discover NVIDIA GB10 Grace Blackwell Superchip–powered systems from our preferred OEM partners.

See All Buying Options

[See All Buying Options](https://marketplace.nvidia.com/en-us/enterprise/personal-ai-supercomputers/?superchip=GB10&page=1&limit=15)

---

##

FAQ

###

What is the NVIDIA DGX Spark platform?

NVIDIA DGX Spark belongs to a new class of computers designed from the ground up to build and run AI. Powered by the NVIDIA GB10 Grace Blackwell Superchip, it's a complete local AI platform for agents, LLM, image and video, and multimodal inference, fine-tuning, data science, and edge development, bringing the power of Grace Blackwell to every desk. Connect up to four systems via NVIDIA ConnectX-7 to scale to larger models and more complex workflows

###

Who is the target user of DGX Spark?

NVIDIA DGX Spark is designed for AI developers, researchers, data scientists, and students who need powerful, always-on AI compute on the desktop—without relying on cloud or data center access for every workload. Whether working independently or as part of an enterprise fleet, DGX Spark users share a common need: large local memory, the full NVIDIA AI software stack, and a development environment consistent with production infrastructure.

###

What software and hardware support is available for DGX Spark?

DGX Spark ships with DGX OS and additional NVIDIA tools. DGX OS is a Linux distribution based on Ubuntu and matches the Linux distribution running on other DGX platforms. DGX Spark comes pre-installed and/or supports a large catalog of tools, frameworks, models, and software for development use from NVIDIA NGC. For example:

- NVIDIA NeMo framework for model fine-tuning

- NVIDIA RAPIDS libraries for accelerated data science

- NVIDIA Blueprints for building agentic AI applications

- NVIDIA NIM microservices for testing optimized inference results

- NVIDIA NemoClaw, an open-source reference stack that adds privacy and security to OpenClaw, with a single-command install of the OpenShell runtime, NVIDIA Agent Toolkit, and Nemotron models

- Common frameworks such as PyTorch, Python, and Jupyter notebooks

DGX Spark users can register free of charge for the NVIDIA Developer Program to get access to NGC including additional SDKs, toolkits, trained models, and workflows.

Hardware support will be provided by the vendor that sold the system.

###

How many DGX Spark systems can I connect?

Up to 4 DGX Spark systems can be connected using NVIDIA ConnectX-7 networking. You can cluster two or three systems with a single QSFP cable; clustering 4 systems requires an external network switch. For optimal load balance and parallelism, connect DGX Spark in a power-of-2 number

|
Configuration

|
DGX Spark 64 GB*

|
DGX Spark 128 GB

|
Connection

|
1 × DGX Spark

|
64 GB

|
128 GB

|
–

|
2 × DGX Spark

|
128 GB

|
256 GB

|
Direct QSFP cable, no switch required

|
4 × DGX Spark

|
256 GB

|
512 GB

|
200 GbE switch (QSFP56-DD, RoCE v2)

Details on QSFP Cables and Switches

Each DGX Spark has two QSFP ports on the back of the device. Each port provides up to 200 Gigabits per second (Gb/s), but the incoming speed also depends on the cable you use. Approved cables are:

Amphenol: NJAAKK-N911 (QSFP to QSFP112, 32AWG, 400mm, LSZH), NJAAKK0006 is the 0.5m version of this cable

Luxshare: LMTQF022-SD-R (QSFP112 400G DAC Cable, 400mm, 30AWG)

Minimum requirements for switch:

- Minimum 4 ports QSFP56-DD

- Breakout to 25/50/100/200/400 G

- Recommended max port speed of 200G–400G per port

- One 1/10GbE management Ethernet port

- Supports RoCE v2

- Switching capacity/throughput: minimum 0.8–1.6 Tbps

*64 GB memory configuration is available exclusively through participating OEM partners.

###

What enterprise management options are available for DGX Spark?

The enterprise manageability features developed for DGX Spark 128 GB can also be applied to DGX Spark 64 GB. Full details are located at https://docs.nvidia.com/dgx/dgx-spark/enterprise-manageability.html[https://docs.nvidia.com/dgx/dgx-spark/enterprise-manageability.html](https://docs.nvidia.com/dgx/dgx-spark/enterprise-manageability.html)

## NVIDIA DGX Spark Specifications

| Architecture
| NVIDIA Grace Blackwell

| GPU
| Blackwell Architecture

| CPU
| 20-core Arm, 10 Cortex-X925 + 10 Cortex-A725 Arm

| CUDA Cores
| Blackwell Generation

| Tensor Cores
| 5th Generation

| RT Cores
| 4th Generation

| Tensor Performance1
| Up to 1 PFLOP FP4

| System Memory
| 64 GB LPDDR5X* or 128 GB LPDDR5x, coherent unified system memory

| Memory Interface
| 256-bit

| Memory Bandwidth
| 273 GB/s

| Storage
| Up to 4 TB NVME.M2 with self-encryption

| USB
| 4x USB TypeC

| Ethernet
| 1x RJ-45 connector

10 GbE

| NIC
| ConnectX-7 NIC @ 200 Gbps

| Wi-Fi
| WiFi 7

| Bluetooth
| BT 5.4

| Audio-output
| HDMI multichannel audio output

| Power Supply
| 240 Watts

| GB10 TDP2
| 140 W

| Display Connectors
| 1x HDMI 2.1a, Up to 3x DisplayPort over USB-C (DP Alt Mode)

| NVENC | NVDEC
| 1x | 1x

| OS
| NVIDIA DGX™ OS

| System Dimensions
| 150 mm L x 150 mm W x 50.5 mm H

| System Weight
| 1.2 kg

1 Theoretical FP4 TOPS using the sparsity feature.

*64 GB memory configuration is available exclusively through participating OEM partners.

2 TDP: Thermal Design Power of the GB10 chip, including CPU and GPU

Declared noise emission values in accordance with ECMA-109, June 2025

| Product name
| NVIDIA DGX Spark

940-54242-0000

| Product description
| NVIDIA GB10 Grace Blackwell

Superchip

20-core Arm: 10 Cortex-X925 + 10

Cortex-A725 Arm,

128 GB LPDDR5x

Up to 4 TB NVME.M2

| Quantities declared
| Operating Modedd)
| Idle

| Declared mean A-weighted sound power level a), LWA,m (dB)
| 35
| 19

| Declared mean A-weighted emission sound pressure level b), LpA,m (dB)
| 29
| 13

| Statistical adder for verification c), Kv (dB)
| 3
| 3

a) The declared mean A-weighted sound power level, Lwa,m is computed as the arithmetic average of the measured A-weighted sound power levels.

b) The declared mean A-weighted emission sound pressure level, LpA,m is computed as the arithmetic average of the defined Operator position (C.4b)

c) The statistical adder for verification, KV is a factor to be added to the declared mean A-weighted sound power level, LWA,m, such that there will be a 95 % probability of acceptance, when using the verification procedures of ECMA-109, if no more than 6,5 % of the equipment in batch, has A-weighted sound power levels greater than (LWA,m + Kv).

d) Operating mode, max GPU stress in 25°C ambient.

Note 1 The quantity, LWA,c (formerly called LWAd) can be computed from the sum of LWA,m and KV.

Note 2 All measurements made in conformance with ECMA-74 and declared with ECMA-109

Note 3 dB is the abbreviation for decibels

View Datasheet

[View Datasheet](https://dam-cdn.nvd.orangelogic.com/AssetLink/es6d60li4v5hybk461p65is6os33c48h.pdf)

View GB10 White Paper

[View GB10 White Paper](/content/dam/en-zz/Solutions/dgx-spark/nvidia-gb10-superchip-whitepaper.pdf)

## Sign up To Be Notified on Availability

Welcome back.
Not you? Log Out

Welcome
back. Not you? Clear form

Products

-
NVIDIA RTX PRO Platform[NVIDIA RTX PRO Platform](https://www.nvidia.com/en-us/products/workstations/)

-
NVIDIA RTX PRO Desktop GPUs[NVIDIA RTX PRO Desktop GPUs](https://www.nvidia.com/en-us/design-visualization/desktop-graphics/)

-
NVIDIA RTX PRO Laptop GPUs[NVIDIA RTX PRO Laptop GPUs](https://www.nvidia.com/en-us/products/workstations/professional-laptops/#performance)

-
Cloud & Data Center[Cloud & Data Center](https://www.nvidia.com/en-us/data-center/)

-
Virtual Workstation[Virtual Workstation](https://www.nvidia.com/en-us/design-visualization/virtual-workstation/)

-
Embedded[Embedded](https://www.nvidia.com/en-us/products/workstations/resources/rtx-embedded/)

-
NVIDIA RTX Enterprise Software[NVIDIA RTX Enterprise Software](https://www.nvidia.com/en-us/design-visualization/rtx-enterprise-software)

Resources

-
Blogs[Blogs](https://blogs.nvidia.com/blog/category/pro-graphics/)

-
Developer Blogs[Developer Blogs](https://developer.nvidia.com/blog/tag/workstation/)

-
Customer Stories[Customer Stories](https://www.nvidia.com/en-us/case-studies/?page=1)

-
NVIDIA RTX PRO Product Literature[NVIDIA RTX PRO Product Literature](https://www.nvidia.com/en-us/products/workstations/product-literature/)

-
Virtual GPU Product Literature[Virtual GPU Product Literature](https://www.nvidia.com/en-us/data-center/virtualization/resources/?ncid=no-ncid)

-
Documentation[Documentation](https://docs.nvidia.com/)

-
NVIDIA On-Demand Sessions[NVIDIA On-Demand Sessions](https://www.nvidia.com/en-us/on-demand/)

Community

-
Developer Forum[Developer Forum](https://forums.developer.nvidia.com/)

-
RTX PRO Forum[RTX PRO Forum](https://forums.developer.nvidia.com/c/gaming-and-visualization-technologies/rtx-pro/774)

-
Omniverse Community [Omniverse Community](https://developer.nvidia.com/omniverse/community)

Company Info

-
About NVIDIA[About NVIDIA](https://www.nvidia.com/en-us/about-nvidia/#About%20Us)

-
Corporate Overview[Corporate Overview](https://www.nvidia.com/en-us/about-nvidia/#About%20Us)

-
Careers[Careers](https://www.nvidia.com/en-us/about-nvidia/careers/)

-
NVIDIA Foundation[NVIDIA Foundation](https://www.nvidia.com/en-us/foundation/)

-
Investors[Investors](https://investor.nvidia.com/home/default.aspx)

-
NVIDIA Research[NVIDIA Research](https://www.nvidia.com/en-us/research/)

-
Social Responsibility[Social Responsibility](https://www.nvidia.com/en-us/sustainability/)

-
Technologies[Technologies](https://www.nvidia.com/en-us/technologies/)

Follow NVIDIA

## Reference sources

- [Personal AI Supercomputer Powered by Blackwell  NVIDIA DGX Spark](https://www.nvidia.com/en-us/products/workstations/dgx-spark/) — accessed 2026-11-03
