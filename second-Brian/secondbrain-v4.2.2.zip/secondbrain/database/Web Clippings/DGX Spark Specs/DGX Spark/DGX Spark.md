# DGX Spark

:::quick-info
Source: https://build.nvidia.com/spark
Scraped: 2026-11-03
Topic: DGX Spark Specs
:::

Skip to main content

?
Login

DGX Spark

# Start Building AI Agents on DGX Spark

Find instructions and examples to run AI workloads on the NVIDIA GB10 Grace Blackwell Superchip

![/_next/image?url=https%3A%2F%2Fassets.ngc.nvidia.com%2Fproducts%2Fapi-catalog%2Fimages%2Fdgx-spark-support-bg.jpg&w=3840&q=75](/_next/image?url=https%3A%2F%2Fassets.ngc.nvidia.com%2Fproducts%2Fapi-catalog%2Fimages%2Fdgx-spark-support-bg.jpg&w=3840&q=75)

## DGX Spark Support

Access documentation, software, and expert assistance for your DGX Spark.

Get Support[Get Support](https://www.nvidia.com/en-us/support/dgx-spark/)

## Connect from Another Computer

Get started with NVIDIA Sync

![Connect Remotely to Your AI Compute](/_next/image?url=https%3A%2F%2Fassets.ngc.nvidia.com%2Fproducts%2Fapi-catalog%2Fspark%2Fspark-agent-hero.jpg&w=1920&q=75)

### Connect Remotely to Your AI Compute

Reach your machine remotely via NVIDIA Sync

Connect Now[Connect Now](/spark/connect-to-your-spark)

## First Time Here?

Try these developer quickstarts

### Chat with LLMs Using Open WebUI and Ollama15 MIN

A self-hosted browser interface with models running locally on your GPU

[Chat with LLMs Using Open WebUI and Ollama15 MINA self-hosted browser interface with models running locally on your GPU](/spark/open-webui)

### Generate Images and Videos with ComfyUI2 HOURS

Node-based diffusion workflows for images and videos with FLUX, Wan, HunyuanVideo, and Stable Diffusion

[Generate Images and Videos with ComfyUI2 HOURSNode-based diffusion workflows for images and videos with FLUX, Wan, HunyuanVideo, and Stable Diffusion](/spark/comfyui)

### Monitor Your AI Compute with DGX Dashboard30 MIN

Notebook access, GPU status, and update controls in one place

[Monitor Your AI Compute with DGX Dashboard30 MINNotebook access, GPU status, and update controls in one place](/spark/dgx-dashboard)

### Serve LLMs with vLLM on One Device30 MIN

A locally accessible model API from one DGX Spark or Station

[Serve LLMs with vLLM on One Device30 MINA locally accessible model API from one DGX Spark or Station](/spark/vllm)
Explore All Playbooks

See More Playbooks Below

## What's New

New and majorly updated playbooks

-

Use NVIDIA Sync clustering so larger models and training can span nodes.

- DGX Spark[DGX Spark](/search?filters=hardwareType%3Ahardwaretype_dgx_spark)

+ 3

- Beginner[Beginner](/search?filters=difficultyLevel%3Adifficultylevel_beginner)

- Connect Multiple Nodes[Connect Multiple Nodes](/search?filters=playbookCategories%3Aplaybookcategories_connect_multiple_nodes)

- Multi-Node[Multi-Node](/search?label=Multi-Node)

17d

Last updated on October 15, 2026

-

A locally accessible model API from one DGX Spark or Station

- vLLM[vLLM](/search?label=vLLM)

+ 5

- Inference[Inference](/search?label=Inference)

- DGX Spark[DGX Spark](/search?filters=hardwareType%3Ahardwaretype_dgx_spark)

- DGX Station[DGX Station](/search?filters=hardwareType%3Ahardwaretype_dgx_station)

- Run LLM Inference[Run LLM Inference](/search?filters=playbookCategories%3Aplaybookcategories_run_llm_inference)

- Intermediate[Intermediate](/search?filters=difficultyLevel%3Adifficultylevel_intermediate)

2mo

Last updated on August 6, 2026

-

Guided and configurable model serving across DGX Spark clusters

- vLLM[vLLM](/search?label=vLLM)

+ 4

- Inference[Inference](/search?label=Inference)

- DGX Spark[DGX Spark](/search?filters=hardwareType%3Ahardwaretype_dgx_spark)

- Run LLM Inference[Run LLM Inference](/search?filters=playbookCategories%3Aplaybookcategories_run_llm_inference)

- Intermediate[Intermediate](/search?filters=difficultyLevel%3Adifficultylevel_intermediate)

12d

Last updated on October 20, 2026

## Playbooks for DGX Spark 64 GB and 128 GB

Detailed instructions to set up and run popular AI workflows on DGX Spark

-

Your chosen agent connected to a local model in one command

- Build AI Applications[Build AI Applications](/search?filters=playbookCategories%3Aplaybookcategories_build_ai_applications)

+ 7

- DGX Spark[DGX Spark](/search?filters=hardwareType%3Ahardwaretype_dgx_spark)

- Ollama[Ollama](/search?label=Ollama)

- Claude Code[Claude Code](/search?label=Claude+Code)

- OpenCode[OpenCode](/search?label=OpenCode)

- Application[Application](/search?label=Application)

- Codex[Codex](/search?label=Codex)

- Intermediate[Intermediate](/search?filters=difficultyLevel%3Adifficultylevel_intermediate)

## Playbooks for DGX Spark 128 GB only

Detailed instructions to set up and run popular AI workflows on DGX Spark 128 GB

-

Train a concept LoRA on FLUX.2 Klein with AI Toolkit

- Fine-Tune Models[Fine-Tune Models](/search?filters=playbookCategories%3Aplaybookcategories_fine_tune_models)

+ 7

- Content Creation[Content Creation](/search?label=Content+Creation)

- Image Generation[Image Generation](/search?label=Image+Generation)

- ComfyUI[ComfyUI](/search?label=ComfyUI)

- Docker[Docker](/search?label=Docker)

- Fine-tuning[Fine-tuning](/search?label=Fine-tuning)

- DGX Spark[DGX Spark](/search?filters=hardwareType%3Ahardwaretype_dgx_spark)

- Intermediate[Intermediate](/search?filters=difficultyLevel%3Adifficultylevel_intermediate)

-

Extract triples with Ollama or vLLM, store them in a graph database, and explore them in a GPU-accelerated web UI

-

Benchmarked interconnect bandwidth for distributed training across nodes

-

Image and video understanding adapted to your own specialized tasks

-

One interface for supervised, RLHF, and parameter-efficient training

-

Hugging Face model training from single-GPU to multi-node jobs

-

Reduced memory use and minimal boilerplate for open models

-

A shared GPU workspace your team can access from anywhere

-

Chat from the terminal against local vLLM with the self-improving Nous Research agent (Telegram optional)

-

Ready-to-run workflows you can copy and personalize

-

Build a local AI assistant in an OpenShell sandbox with vLLM inference and optional Telegram

-

Install a local-first AI agent and connect it to a private OpenAI-compatible model endpoint

-

Isolate AI coding agents like Pi with kernel-level policies and a locally served vLLM model

-

Node-based diffusion workflows for images and videos with FLUX, Wan, HunyuanVideo, and Stable Diffusion

-

Realistic robot simulation and RL training before real-world deployment

-

A webcam-based testbed for comparing VLMs across backends

-

Route independent local AI requests across paired systems using llama.cpp, Ollama, or LM Studio

-

Efficient inference for any GGUF model with minimal dependencies

-

High-throughput serving with RadixAttention, structured output, and an OpenAI-compatible API

-

Prebuilt, GPU-optimized model containers with a ready-to-use HTTP endpoint

-

Local models reachable from your own machine's tools over an encrypted link

-

Cut memory ~3.5× vs FP16 while keeping accuracy close to FP8, then validate with an OpenAI-compatible endpoint

11d

Last updated on October 22, 2026

- Build AI Applications[Build AI Applications](/search?filters=playbookCategories%3Aplaybookcategories_build_ai_applications)

+ 6

- vLLM[vLLM](/search?label=vLLM)

- Ollama[Ollama](/search?label=Ollama)

- Application[Application](/search?label=Application)

- DGX Spark[DGX Spark](/search?filters=hardwareType%3Ahardwaretype_dgx_spark)

- DGX Station[DGX Station](/search?filters=hardwareType%3Ahardwaretype_dgx_station)

- Intermediate[Intermediate](/search?filters=difficultyLevel%3Adifficultylevel_intermediate)

2mo

Last updated on August 6, 2026

- DGX Spark[DGX Spark](/search?filters=hardwareType%3Ahardwaretype_dgx_spark)

+ 5

- Connect Multiple Nodes[Connect Multiple Nodes](/search?filters=playbookCategories%3Aplaybookcategories_connect_multiple_nodes)

- NCCL[NCCL](/search?label=NCCL)

- Setup[Setup](/search?label=Setup)

- Multi-Node[Multi-Node](/search?label=Multi-Node)

- Intermediate[Intermediate](/search?filters=difficultyLevel%3Adifficultylevel_intermediate)

17d

Last updated on October 15, 2026

- Fine-Tune Models[Fine-Tune Models](/search?filters=playbookCategories%3Aplaybookcategories_fine_tune_models)

+ 6

- vLLM[vLLM](/search?label=vLLM)

- PyTorch[PyTorch](/search?label=PyTorch)

- Docker[Docker](/search?label=Docker)

- Fine-tuning[Fine-tuning](/search?label=Fine-tuning)

- DGX Spark[DGX Spark](/search?filters=hardwareType%3Ahardwaretype_dgx_spark)

- Intermediate[Intermediate](/search?filters=difficultyLevel%3Adifficultylevel_intermediate)

17d

Last updated on October 15, 2026

- Fine-Tune Models[Fine-Tune Models](/search?filters=playbookCategories%3Aplaybookcategories_fine_tune_models)

+ 5

- PyTorch[PyTorch](/search?label=PyTorch)

- LLaMA Factory[LLaMA Factory](/search?label=LLaMA+Factory)

- Fine-tuning[Fine-tuning](/search?label=Fine-tuning)

- DGX Spark[DGX Spark](/search?filters=hardwareType%3Ahardwaretype_dgx_spark)

- Intermediate[Intermediate](/search?filters=difficultyLevel%3Adifficultylevel_intermediate)

1mo

Last updated on September 22, 2026

- Fine-Tune Models[Fine-Tune Models](/search?filters=playbookCategories%3Aplaybookcategories_fine_tune_models)

+ 5

- Docker[Docker](/search?label=Docker)

- Fine-tuning[Fine-tuning](/search?label=Fine-tuning)

- NeMo[NeMo](/search?label=NeMo)

- DGX Spark[DGX Spark](/search?filters=hardwareType%3Ahardwaretype_dgx_spark)

- Intermediate[Intermediate](/search?filters=difficultyLevel%3Adifficultylevel_intermediate)

1mo

Last updated on September 22, 2026

- Fine-Tune Models[Fine-Tune Models](/search?filters=playbookCategories%3Aplaybookcategories_fine_tune_models)

+ 5

- Docker[Docker](/search?label=Docker)

- Fine-tuning[Fine-tuning](/search?label=Fine-tuning)

- Unsloth[Unsloth](/search?label=Unsloth)

- DGX Spark[DGX Spark](/search?filters=hardwareType%3Ahardwaretype_dgx_spark)

- Intermediate[Intermediate](/search?filters=difficultyLevel%3Adifficultylevel_intermediate)

1mo

Last updated on September 22, 2026

- DGX Spark[DGX Spark](/search?filters=hardwareType%3Ahardwaretype_dgx_spark)

+ 5

- DGX Station[DGX Station](/search?filters=hardwareType%3Ahardwaretype_dgx_station)

- Beginner[Beginner](/search?filters=difficultyLevel%3Adifficultylevel_beginner)

- Get Started[Get Started](/search?filters=playbookCategories%3Aplaybookcategories_get_started)

- Remote Access[Remote Access](/search?label=Remote+Access)

- Brev[Brev](/search?label=Brev)

1mo

Last updated on September 29, 2026

- Hermes Agent[Hermes Agent](/search?label=Hermes+Agent)

+ 7

- vLLM[vLLM](/search?label=vLLM)

- Docker[Docker](/search?label=Docker)

- Agentic Workflow[Agentic Workflow](/search?label=Agentic+Workflow)

- DGX Spark[DGX Spark](/search?filters=hardwareType%3Ahardwaretype_dgx_spark)

- DGX Station[DGX Station](/search?filters=hardwareType%3Ahardwaretype_dgx_station)

- Run AI Agents[Run AI Agents](/search?filters=playbookCategories%3Aplaybookcategories_run_ai_agents)

- Intermediate[Intermediate](/search?filters=difficultyLevel%3Adifficultylevel_intermediate)

3mo

Last updated on August 4, 2026

- Telegram[Telegram](/search?label=Telegram)

+ 7

- Agentic Workflow[Agentic Workflow](/search?label=Agentic+Workflow)

- NemoClaw[NemoClaw](/search?label=NemoClaw)

- OpenClaw[OpenClaw](/search?label=OpenClaw)

- OpenShell[OpenShell](/search?label=OpenShell)

- DGX Spark[DGX Spark](/search?filters=hardwareType%3Ahardwaretype_dgx_spark)

- Run AI Agents[Run AI Agents](/search?filters=playbookCategories%3Aplaybookcategories_run_ai_agents)

- Intermediate[Intermediate](/search?filters=difficultyLevel%3Adifficultylevel_intermediate)

17d

Last updated on October 15, 2026

- vLLM[vLLM](/search?label=vLLM)

+ 9

- Telegram[Telegram](/search?label=Telegram)

- Agentic Workflow[Agentic Workflow](/search?label=Agentic+Workflow)

- NemoClaw[NemoClaw](/search?label=NemoClaw)

- OpenClaw[OpenClaw](/search?label=OpenClaw)

- OpenShell[OpenShell](/search?label=OpenShell)

- DGX Spark[DGX Spark](/search?filters=hardwareType%3Ahardwaretype_dgx_spark)

- DGX Station[DGX Station](/search?filters=hardwareType%3Ahardwaretype_dgx_station)

- Run AI Agents[Run AI Agents](/search?filters=playbookCategories%3Aplaybookcategories_run_ai_agents)

- Intermediate[Intermediate](/search?filters=difficultyLevel%3Adifficultylevel_intermediate)

2mo

Last updated on August 6, 2026

- DGX Spark[DGX Spark](/search?filters=hardwareType%3Ahardwaretype_dgx_spark)

+ 5

- RTX[RTX](/search?filters=hardwareType%3Ahardwaretype_rtx)

- Agentic Workflow[Agentic Workflow](/search?label=Agentic+Workflow)

- OpenClaw[OpenClaw](/search?label=OpenClaw)

- Run AI Agents[Run AI Agents](/search?filters=playbookCategories%3Aplaybookcategories_run_ai_agents)

- Intermediate[Intermediate](/search?filters=difficultyLevel%3Adifficultylevel_intermediate)

2mo

Last updated on August 6, 2026

- vLLM[vLLM](/search?label=vLLM)

+ 8

- Docker[Docker](/search?label=Docker)

- Agentic Workflow[Agentic Workflow](/search?label=Agentic+Workflow)

- OpenShell[OpenShell](/search?label=OpenShell)

- Pi[Pi](/search?label=Pi)

- DGX Spark[DGX Spark](/search?filters=hardwareType%3Ahardwaretype_dgx_spark)

- DGX Station[DGX Station](/search?filters=hardwareType%3Ahardwaretype_dgx_station)

- Run AI Agents[Run AI Agents](/search?filters=playbookCategories%3Aplaybookcategories_run_ai_agents)

- Intermediate[Intermediate](/search?filters=difficultyLevel%3Adifficultylevel_intermediate)

2mo

Last updated on August 6, 2026

- Content Creation[Content Creation](/search?label=Content+Creation)

+ 7

- Image Generation[Image Generation](/search?label=Image+Generation)

- ComfyUI[ComfyUI](/search?label=ComfyUI)

- Docker[Docker](/search?label=Docker)

- DGX Spark[DGX Spark](/search?filters=hardwareType%3Ahardwaretype_dgx_spark)

- DGX Station[DGX Station](/search?filters=hardwareType%3Ahardwaretype_dgx_station)

- Run Domain-Specific Workloads[Run Domain-Specific Workloads](/search?filters=playbookCategories%3Aplaybookcategories_run_domain_specific_workloads)

- Intermediate[Intermediate](/search?filters=difficultyLevel%3Adifficultylevel_intermediate)

3mo

Last updated on August 4, 2026

- Isaac Sim[Isaac Sim](/search?label=Isaac+Sim)

+ 7

- Physical AI[Physical AI](/search?label=Physical+AI)

- Isaac Lab[Isaac Lab](/search?label=Isaac+Lab)

- Reinforcement Learning[Reinforcement Learning](/search?label=Reinforcement+Learning)

- Robotics[Robotics](/search?label=Robotics)

- DGX Spark[DGX Spark](/search?filters=hardwareType%3Ahardwaretype_dgx_spark)

- Run Domain-Specific Workloads[Run Domain-Specific Workloads](/search?filters=playbookCategories%3Aplaybookcategories_run_domain_specific_workloads)

- Intermediate[Intermediate](/search?filters=difficultyLevel%3Adifficultylevel_intermediate)

17d

Last updated on October 15, 2026

- DGX Spark[DGX Spark](/search?filters=hardwareType%3Ahardwaretype_dgx_spark)

+ 4

- Ollama[Ollama](/search?label=Ollama)

- Inference[Inference](/search?label=Inference)

- Run Domain-Specific Workloads[Run Domain-Specific Workloads](/search?filters=playbookCategories%3Aplaybookcategories_run_domain_specific_workloads)

- Intermediate[Intermediate](/search?filters=difficultyLevel%3Adifficultylevel_intermediate)

17d

Last updated on October 15, 2026

- DGX Spark[DGX Spark](/search?filters=hardwareType%3Ahardwaretype_dgx_spark)

+ 9

- RTX[RTX](/search?filters=hardwareType%3Ahardwaretype_rtx)

- RTX Spark[RTX Spark](/search?filters=hardwareType%3Ahardwaretype_rtx_spark)

- Ollama[Ollama](/search?label=Ollama)

- Inference[Inference](/search?label=Inference)

- LM Studio[LM Studio](/search?label=LM+Studio)

- Multi-Node[Multi-Node](/search?label=Multi-Node)

- llama.cpp[llama.cpp](/search?label=llama.cpp)

- Run LLM Inference[Run LLM Inference](/search?filters=playbookCategories%3Aplaybookcategories_run_llm_inference)

- Intermediate[Intermediate](/search?filters=difficultyLevel%3Adifficultylevel_intermediate)

1mo

Last updated on September 3, 2026

- DGX Spark[DGX Spark](/search?filters=hardwareType%3Ahardwaretype_dgx_spark)

+ 4

- Run LLM Inference[Run LLM Inference](/search?filters=playbookCategories%3Aplaybookcategories_run_llm_inference)

- Inference[Inference](/search?label=Inference)

- llama.cpp[llama.cpp](/search?label=llama.cpp)

- Intermediate[Intermediate](/search?filters=difficultyLevel%3Adifficultylevel_intermediate)

17d

Last updated on October 15, 2026

- DGX Spark[DGX Spark](/search?filters=hardwareType%3Ahardwaretype_dgx_spark)

+ 5

- DGX Station[DGX Station](/search?filters=hardwareType%3Ahardwaretype_dgx_station)

- Run LLM Inference[Run LLM Inference](/search?filters=playbookCategories%3Aplaybookcategories_run_llm_inference)

- Inference[Inference](/search?label=Inference)

- SGLang[SGLang](/search?label=SGLang)

- Intermediate[Intermediate](/search?filters=difficultyLevel%3Adifficultylevel_intermediate)

3mo

Last updated on August 4, 2026

- NIM[NIM](/search?label=NIM)

+ 5

- Docker[Docker](/search?label=Docker)

- Inference[Inference](/search?label=Inference)

- DGX Spark[DGX Spark](/search?filters=hardwareType%3Ahardwaretype_dgx_spark)

- Run LLM Inference[Run LLM Inference](/search?filters=playbookCategories%3Aplaybookcategories_run_llm_inference)

- Intermediate[Intermediate](/search?filters=difficultyLevel%3Adifficultylevel_intermediate)

1mo

Last updated on September 22, 2026

1mo

Last updated on September 22, 2026

- DGX Spark[DGX Spark](/search?filters=hardwareType%3Ahardwaretype_dgx_spark)

+ 4

- Run LLM Inference[Run LLM Inference](/search?filters=playbookCategories%3Aplaybookcategories_run_llm_inference)

- Inference[Inference](/search?label=Inference)

- LM Studio[LM Studio](/search?label=LM+Studio)

- Intermediate[Intermediate](/search?filters=difficultyLevel%3Adifficultylevel_intermediate)

13d

Last updated on October 19, 2026

- vLLM[vLLM](/search?label=vLLM)

+ 7

- Model Optimizer[Model Optimizer](/search?label=Model+Optimizer)

- TensorRT-LLM[TensorRT-LLM](/search?label=TensorRT-LLM)

- Inference[Inference](/search?label=Inference)

- Serve Models[Serve Models](/search?filters=playbookCategories%3Aplaybookcategories_serve_models)

- DGX Spark[DGX Spark](/search?filters=hardwareType%3Ahardwaretype_dgx_spark)

- DGX Station[DGX Station](/search?filters=hardwareType%3Ahardwaretype_dgx_station)

- Intermediate[Intermediate](/search?filters=difficultyLevel%3Adifficultylevel_intermediate)

3mo

Last updated on August 4, 2026

## Reference sources

- [DGX Spark](https://build.nvidia.com/spark) — accessed 2026-11-03
