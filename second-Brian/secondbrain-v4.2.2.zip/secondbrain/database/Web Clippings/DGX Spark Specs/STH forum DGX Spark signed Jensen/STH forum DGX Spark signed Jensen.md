# STH forum DGX Spark signed Jensen

:::quick-info
Source: https://forums.servethehome.com/index.php?threads/if-you-could-buy-a-dgx-spark-signed-by-jensen-huang-how-much-would-you-pay.55128
Scraped: 2026-11-03
Topic: DGX Spark Specs
:::

If you could buy a DGX Spark signed by Jensen Huang, how much would you pay? | ServeTheHome Forums

-

New posts[New posts](/index.php?whats-new/posts/)

-

Search forums[Search forums](/index.php?search/&type=post)

Menu

Install the app
Install

How to install the app on iOS

Follow along with the video below to see how to install our site as a web app on your home screen.

Note: This feature may not be available in some browsers.

# If you could buy a DGX Spark signed by Jensen Huang, how much would you pay?

-

Thread starter

eunha kim[eunha kim](/index.php?members/eunha-kim.232455/)

-

Start date

Mar 26, 2026[Mar 26, 2026](/index.php?threads/if-you-could-buy-a-dgx-spark-signed-by-jensen-huang-how-much-would-you-pay.55128/)

-

Home

[Home](https://www.servethehome.com)

-

Forums

[Forums](/index.php)

-

Hardware

[Hardware](/index.php#hardware.4)

-

Processors and Motherboards

[Processors and Motherboards](/index.php?forums/processors-and-motherboards.18/)

You are using an out of date browser. It may not display this or other websites correctly.
You should upgrade or use an alternative browser[alternative browser](https://www.google.com/chrome/).

Notice: Page may contain affiliate links for which we may earn a small commission through services like Amazon Affiliates or Skimlinks.

E
[E](/index.php?members/eunha-kim.232455/)

#### eunha kim[eunha kim](/index.php?members/eunha-kim.232455/)

##### New Member

Mar 26, 2026

2

0

1

Korea[Korea](/index.php?misc/location-info&location=Korea)

Hi everyone,

I wanted to get some opinions from people who are into GPUs, AI, and NVIDIA.

I recently attended NVIDIA GTC 2026 in San Francisco, and during an on-site event, I was selected to receive a DGX Spark unit. It was a limited selection among roughly 30,000 attendees.

What makes it more unique is that it’s personally signed by Jensen Huang.

This isn’t something that’s commercially available, and I don’t really see it as just hardware — it feels more like a piece connected to NVIDIA and the current AI era.

I am considering potentially selling it, but before making any decisions, I wanted to understand how people in this space perceive something like this.

How would you personally look at it?

- As a collector item?

- As a display/showcase piece?

- Or just as hardware?

Also, in your opinion, what kind of value range do you think something like this might fall into?

Appreciate any thoughts.

#### Attachments

-

![KakaoTalk_Image_2026-03-23-14-19-22_001.jpeg](/data/attachments/48/48269-f6fb6a137f0d1ccb2f9fa454e03bac61.jpg?hash=9vtqE38NHM)

KakaoTalk_Image_2026-03-23-14-19-22_001.jpeg

825.4 KB

· Views: 28

-

![KakaoTalk_Photo_2026-03-26-16-43-07.jpeg](/data/attachments/48/48270-3b08528569b66397213e4658e6aaa427.jpg?hash=OwhShWm2Y5)

KakaoTalk_Photo_2026-03-26-16-43-07.jpeg

447.8 KB

· Views: 29

Last edited: Mar 26, 2026

I
[I](/index.php?members/i386.7103/)

#### i386[i386](/index.php?members/i386.7103/)

##### Well-Known Member

Mar 18, 2016

4,946

1,951

113

37

Germany[Germany](/index.php?misc/location-info&location=Germany)

I'm getting older and I don't care that much about the new nvidia "ai" stuff anymore (It feels like there is everyday a new ai accelerator/gpu...). If it was something like a riva tnt2 or older "graphic/video accelerator" that started nvidias journey then it would have some nostalgic aspects for me ._.

For me this is "just hardware" and probably "obsolete next year" ._.

-
![Like](https://cdn.jsdelivr.net/joypixels/assets/8.0/png/unicode/64/1f44d.png)

Reactions:
plony and Patriot[plony and Patriot](/index.php?posts/500870/reactions)

![Ralph_IT](/data/avatars/s/34/34614.jpg?1623779579)

#### Ralph_IT[Ralph_IT](/index.php?members/ralph_it.34614/)

##### I'm called Ralph

Apr 12, 2021

241

143

43

/home[/home](/index.php?misc/location-info&location=%2Fhome)

![1774518315686.png](https://forums.servethehome.com/data/attachments/48/48272-777d104b0600fca87210fb33e00729b0.jpg?hash=d30QSwYA_K)

-
![Like](https://cdn.jsdelivr.net/joypixels/assets/8.0/png/unicode/64/1f44d.png)

Reactions:
DavidRa[DavidRa](/index.php?posts/500872/reactions)

R
[R](/index.php?members/rtech.35831/)

#### rtech[rtech](/index.php?members/rtech.35831/)

##### Active Member

Jun 2, 2021

410

150

43

Is it personally signed by Jensen or it is just autopen by his employees? Does every signature look same?

R
[R](/index.php?members/rolloz170.7479/)

#### RolloZ170[RolloZ170](/index.php?members/rolloz170.7479/)

##### Well-Known Member

Apr 24, 2016

10,958

3,532

113

germany[germany](/index.php?misc/location-info&location=germany)

eunha kim said:[eunha kim said:](/index.php?goto/post&id=500865)

It was a limited selection among roughly 30,000 attendees.

Click to expand...

Other normal batches/quantities were smaller. Limited ?

eunha kim said:[eunha kim said:](/index.php?goto/post&id=500865)

It was a limited selection among roughly 30,000 attendees.

What makes it more unique is that it’s personally signed by Jensen Huang.

Click to expand...

personaly 30,000 times ? no way...

.

I
[I](/index.php?members/i386.7103/)

#### i386[i386](/index.php?members/i386.7103/)

##### Well-Known Member

Mar 18, 2016

4,946

1,951

113

37

Germany[Germany](/index.php?misc/location-info&location=Germany)

RolloZ170 said:[RolloZ170 said:](/index.php?goto/post&id=500876)

Other normal batches/quantities were smaller. Limited ?

Click to expand...

I read this like: there were 30k attendees, and only x of these 30k attendees got a kit
![:D](https://cdn.jsdelivr.net/joypixels/assets/8.0/png/unicode/64/1f600.png)

-
![Like](https://cdn.jsdelivr.net/joypixels/assets/8.0/png/unicode/64/1f44d.png)

Reactions:
RolloZ170[RolloZ170](/index.php?posts/500882/reactions)

A
[A](/index.php?members/anakronox.159786/)

#### anakronox[anakronox](/index.php?members/anakronox.159786/)

##### Member

Mar 17, 2025

33

8

8

I'd make him pay me.

![Patriot](/data/avatars/s/0/181.jpg?1424660402)

#### Patriot[Patriot](/index.php?members/patriot.181/)

##### Moderator

Apr 18, 2011

1,531

856

113

Sell it on ebay and buy 2 that don't overheat... The OG sparks are "valued" by fanatics at far more than they are worth computationally...

If you value the GB10, sell your spark and get 2 Dell GB10s that have proper cooling.

![ccie4526](/data/avatars/s/32/32580.jpg?1621537701)

#### ccie4526[ccie4526](/index.php?members/ccie4526.32580/)

##### Active Member

Jan 25, 2021

246

166

43

I'll give ya 50 cents....

E
[E](/index.php?members/eunha-kim.232455/)

#### eunha kim[eunha kim](/index.php?members/eunha-kim.232455/)

##### New Member

Mar 26, 2026

2

0

1

Korea[Korea](/index.php?misc/location-info&location=Korea)

rtech said:[rtech said:](/index.php?goto/post&id=500873)

Is it personally signed by Jensen or it is just autopen by his employees? Does every signature look same?

Click to expand...

It was personally signed by Jensen Huang.

An NVIDIA staff member on-site confirmed the signature directly, and I received it in person during the event.

The green ticket shown in the photo is the actual proof from the GTC event, which was used for the on-site selection and verification.

So this wasn’t something pre-signed or handled by employees — it was part of the live event process.

R
[R](/index.php?members/rolloz170.7479/)

#### RolloZ170[RolloZ170](/index.php?members/rolloz170.7479/)

##### Well-Known Member

Apr 24, 2016

10,958

3,532

113

germany[germany](/index.php?misc/location-info&location=germany)

Jensen Huang is responsible for the high prices, therefore his signature is worthless to me.

damn, i can't find the NVIDIA blank checks.

-
![Like](https://cdn.jsdelivr.net/joypixels/assets/8.0/png/unicode/64/1f44d.png)

Reactions:
nexox and jode[nexox and jode](/index.php?posts/500960/reactions)

A
[A](/index.php?members/amalurk.10119/)

#### amalurk[amalurk](/index.php?members/amalurk.10119/)

##### Active Member

Dec 16, 2016

366

139

43

104

Sorry, nerdy gone too far for me.

-
![Haha](https://cdn.jsdelivr.net/joypixels/assets/8.0/png/unicode/64/1f923.png)

Reactions:
jode and eunha kim[jode and eunha kim](/index.php?posts/500961/reactions)

You must log in or register to reply here.
[You must log in or register to reply here.](/index.php?login/)

Share:

Facebook

X

Bluesky

LinkedIn

Reddit

Pinterest

Tumblr

WhatsApp

Email

Share

Link

-

Home

[Home](https://www.servethehome.com)

-

Forums

[Forums](/index.php)

-

Hardware

[Hardware](/index.php#hardware.4)

-

Processors and Motherboards

[Processors and Motherboards](/index.php?forums/processors-and-motherboards.18/)

Top

Bottom

Back

-

This site uses cookies to help personalise content, tailor your experience and to keep you logged in if you register.

By continuing to use this site, you are consenting to our use of cookies.

Accept[Accept](/index.php?account/dismiss-notice)
Learn more…[Learn more…](/index.php?help/cookies)

## Reference sources

- [STH forum DGX Spark signed Jensen](https://forums.servethehome.com/index.php?threads/if-you-could-buy-a-dgx-spark-signed-by-jensen-huang-how-much-would-you-pay.55128) — accessed 2026-11-03
