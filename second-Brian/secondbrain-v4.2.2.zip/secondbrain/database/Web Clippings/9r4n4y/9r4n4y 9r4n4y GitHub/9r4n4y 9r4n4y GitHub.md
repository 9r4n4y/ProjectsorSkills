# 9r4n4y 9r4n4y  GitHub

:::quick-info
Source: https://github.com/9r4n4y
Scraped: 2026-11-03
Topic: 9r4n4y
:::

9r4n4y (9r4n4y) · GitHub

Skip to content

You signed in with another tab or window. Reload to refresh your session.
You signed out in another tab or window. Reload to refresh your session.
You switched accounts on another tab or window. Reload to refresh your session.

Dismiss alert

{{ message }}

![@9r4n4y](https://avatars.githubusercontent.com/u/256166675?s=64&v=4)

9r4n4y

Follow[Follow](/login?return_to=https%3A%2F%2Fgithub.com%2F9r4n4y)

More

-
Overview[Overview](/9r4n4y)

-
Repositories[Repositories](/9r4n4y?tab=repositories)

-
Projects[Projects](/9r4n4y?tab=projects)

-
Packages[Packages](/9r4n4y?tab=packages)

-
Stars[Stars](/9r4n4y?tab=stars)

![@9r4n4y](https://avatars.githubusercontent.com/u/256166675?s=64&v=4)

9r4n4y

Follow[Follow](/login?return_to=https%3A%2F%2Fgithub.com%2F9r4n4y)

![View 9r4n4y's full-sized avatar](https://avatars.githubusercontent.com/u/256166675?v=4)

#

9r4n4y

9r4n4y

Follow[Follow](/login?return_to=https%3A%2F%2Fgithub.com%2F9r4n4y)

1
follower
[1
follower](https://github.com/9r4n4y?tab=followers) ·
3
following
[3
following](https://github.com/9r4n4y?tab=following)

Block or report user

#
Block or report 9r4n4y

Report abuse

Contact GitHub support about this user’s behavior.
Learn more about reporting abuse[reporting abuse](https://docs.github.com/articles/reporting-abuse-or-spam).

Report abuse[Report abuse](/contact/report-abuse?report=9r4n4y+%28user%29)

More

-
Overview[Overview](/9r4n4y)

-
Repositories[Repositories](/9r4n4y?tab=repositories)

-
Projects[Projects](/9r4n4y?tab=projects)

-
Packages[Packages](/9r4n4y?tab=packages)

-
Stars[Stars](/9r4n4y?tab=stars)

##
Pinned

Loading

-

ScreenTextCopy[ScreenTextCopy](/9r4n4y/ScreenTextCopy) ScreenTextCopy Public

Forked from rkfcode/ScreenTextCopy[rkfcode/ScreenTextCopy](/rkfcode/ScreenTextCopy)

Grab text from anywhere on your Windows screen — offline OCR, AI translation, send to phone.

C#

1
[1](/9r4n4y/ScreenTextCopy/stargazers)

Something went wrong, please refresh the page to try again.

If the problem persists, check the GitHub status page[GitHub status page](https://www.githubstatus.com/)
or contact support[contact support](/contact).

### Uh oh!

There was an error while loading. Please reload this page.

You can’t perform that action at this time.

## Reference sources

- [9r4n4y 9r4n4y  GitHub](https://github.com/9r4n4y) — accessed 2026-11-03
