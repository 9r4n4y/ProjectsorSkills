# 9r4n4y whisper termux releases

:::quick-info
Source: https://github.com/9r4n4y/how-to-use-whisper-AI-in-Android-with-termux-for-subtitles-and-transcriptions./releases
Scraped: 2026-11-03
Topic: 9r4n4y
:::

Releases · 9r4n4y/how-to-use-whisper-AI-in-Android-with-termux-for-subtitles-and-transcriptions. · GitHub

Skip to content

You signed in with another tab or window. Reload to refresh your session.
You signed out in another tab or window. Reload to refresh your session.
You switched accounts on another tab or window. Reload to refresh your session.

Dismiss alert

{{ message }}

# Releases: 9r4n4y/how-to-use-whisper-AI-in-Android-with-termux-for-subtitles-and-transcriptions.

Releases · 9r4n4y/how-to-use-whisper-AI-in-Android-with-termux-for-subtitles-and-transcriptions.

## There aren’t any releases here

You can create a release to package software, along with release notes and links to binary files, for other people to use. Learn more about releases in our docs[our docs](https://docs.github.com/repositories/releasing-projects-on-github/about-releases).

You can’t perform that action at this time.

## Reference sources

- [9r4n4y whisper termux releases](https://github.com/9r4n4y/how-to-use-whisper-AI-in-Android-with-termux-for-subtitles-and-transcriptions./releases) — accessed 2026-11-03
