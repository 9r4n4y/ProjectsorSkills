# 9r4n4yUntwisting-RoPE-Style-tranfer-for-img-models-with-tutorial  Hugg

:::quick-info
Source: https://huggingface.co/9r4n4y/Untwisting-RoPE-Style-tranfer-for-img-models-with-tutorial
Scraped: 2026-11-03
Topic: 9r4n4y
:::

9r4n4y/Untwisting-RoPE-Style-tranfer-for-img-models-with-tutorial · Hugging Face

YAML Metadata
Warning:empty or missing yaml metadata in repo card

Check out the documentation[documentation](https://huggingface.co/docs/hub/model-cards#model-card-metadata) for more information.

#

ComfyUi-Untwisting-RoPE (Training-Free Style Transfer)

Your browser does not support the video tag.

###

Official Repository

This is the official GitHub repository: BigStationW/ComfyUi-Untwisting-RoPE[BigStationW/ComfyUi-Untwisting-RoPE](https://github.com/BigStationW/ComfyUi-Untwisting-RoPE)

###

Repository Clone

The GitHub repository clone is already included inside this Hugging Face repository as a .7z archive.

This is a ComfyUi implementation of Untwisting RoPE: Frequency Control for Shared Attention in DiTs[Untwisting RoPE: Frequency Control for Shared Attention in DiTs](https://arxiv.org/abs/2602.05013)

https://untwisting-rope.github.io/[https://untwisting-rope.github.io/](https://untwisting-rope.github.io/)

![Image 4](https://github.com/user-attachments/assets/ea4b7f49-45b0-4812-845b-0bd58824f27c)

You can see more examples here[here](https://github.com/BigStationW/ComfyUi-Untwisting-RoPE/tree/main/Examples).

##

Supported models

- Z-image and Z-image turbo

- Anima

- The whole Flux.2 family

- The whole Qwen-Image/Edit family

##

Installation

Navigate to the ComfyUI\custom_nodes folder, open cmd[open cmd](https://www.youtube.com/watch?v=bgSSJQolR0E&t=47s) and run:

```
git clone https://github.com/BigStationW/ComfyUi-Untwisting-RoPE

```

Restart ComfyUI after installation.

##

Usage

- Here's some workflows[some workflows](https://github.com/BigStationW/ComfyUi-Untwisting-RoPE/tree/main/workflows) for those interested.

- You also need these custom nodes to make those workflows work.

https://github.com/BigStationW/ComfyUi-Scale-Image-to-Total-Pixels-Advanced[https://github.com/BigStationW/ComfyUi-Scale-Image-to-Total-Pixels-Advanced](https://github.com/BigStationW/ComfyUi-Scale-Image-to-Total-Pixels-Advanced)

https://github.com/BigStationW/ComfyUi-TextEncodeEditAdvanced[https://github.com/BigStationW/ComfyUi-TextEncodeEditAdvanced](https://github.com/BigStationW/ComfyUi-TextEncodeEditAdvanced)

Don't hesitate to consult the documentation[the documentation](https://github.com/BigStationW/ComfyUi-Untwisting-RoPE/tree/main/documentation) to better understand this repository.

Downloads last month

-

Downloads are not tracked for this model. How to track [How to track](https://huggingface.co/docs/hub/models-download-stats)

Inference Providers NEW[NEW](https://huggingface.co/docs/inference-providers)
This model isn't deployed by any Inference Provider. 🙋 Ask for provider support[🙋 Ask for provider support](/spaces/huggingface/InferenceSupport/discussions/new?title=9r4n4y/Untwisting-RoPE-Style-tranfer-for-img-models-with-tutorial&description=React%20to%20this%20comment%20with%20an%20emoji%20to%20vote%20for%20%5B9r4n4y%2FUntwisting-RoPE-Style-tranfer-for-img-models-with-tutorial%5D(%2F9r4n4y%2FUntwisting-RoPE-Style-tranfer-for-img-models-with-tutorial)%20to%20be%20supported%20by%20Inference%20Providers.%0A%0A(optional)%20Which%20providers%20are%20you%20interested%20in%3F%20(Novita%2C%20Hyperbolic%2C%20Together%E2%80%A6)%0A)

## Collection including 9r4n4y/Untwisting-RoPE-Style-tranfer-for-img-models-with-tutorial

2 items • Updated Jun 5 [2 items • Updated Jun 5](/collections/9r4n4y/tutorial-videos)

## Paper for 9r4n4y/Untwisting-RoPE-Style-tranfer-for-img-models-with-tutorial

Paper • 2602.05013 • Published Feb 4 [Paper • 2602.05013 • Published Feb 4](/papers/2602.05013)

## Reference sources

- [9r4n4yUntwisting-RoPE-Style-tranfer-for-img-models-with-tutorial  Hugg](https://huggingface.co/9r4n4y/Untwisting-RoPE-Style-tranfer-for-img-models-with-tutorial) — accessed 2026-11-03
