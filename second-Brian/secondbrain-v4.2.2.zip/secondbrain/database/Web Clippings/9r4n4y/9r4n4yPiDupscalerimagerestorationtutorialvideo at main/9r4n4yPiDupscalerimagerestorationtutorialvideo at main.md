# 9r4n4yPiDupscalerimagerestorationtutorialvideo at main

:::quick-info
Source: https://huggingface.co/9r4n4y/PiD_upscaler_image_restoration_tutorial_video/tree/main
Scraped: 2026-11-03
Topic: 9r4n4y
:::

9r4n4y/PiD_upscaler_image_restoration_tutorial_video at main

![9r4n4y's picture](https://cdn-avatars.huggingface.co/v1/production/uploads/69cdd5e6700f30243d0900b0/-WGSuT-mVxxWVCENsJpt9.png)

9r4n4y[9r4n4y](/9r4n4y)
Update README.md c7b710b[c7b710b](/9r4n4y/PiD_upscaler_image_restoration_tutorial_video/commit/c7b710ba49dafe114da0f3f7456a89a9c5577572) verified 5 months ago

- checkpoints[checkpoints](/9r4n4y/PiD_upscaler_image_restoration_tutorial_video/tree/main/checkpoints)
Duplicate from nvidia/PiD[Duplicate from nvidia/PiD](/9r4n4y/PiD_upscaler_image_restoration_tutorial_video/commit/f0efdd14a98d24983b2df4974d369211cde269ad) 5 months ago[5 months ago](/9r4n4y/PiD_upscaler_image_restoration_tutorial_video/commit/f0efdd14a98d24983b2df4974d369211cde269ad)

- figures[figures](/9r4n4y/PiD_upscaler_image_restoration_tutorial_video/tree/main/figures)
Duplicate from nvidia/PiD[Duplicate from nvidia/PiD](/9r4n4y/PiD_upscaler_image_restoration_tutorial_video/commit/f0efdd14a98d24983b2df4974d369211cde269ad) 5 months ago[5 months ago](/9r4n4y/PiD_upscaler_image_restoration_tutorial_video/commit/f0efdd14a98d24983b2df4974d369211cde269ad)

-
.gitattributes[.gitattributes](/9r4n4y/PiD_upscaler_image_restoration_tutorial_video/blob/main/.gitattributes)
Safe 1.67 kB
[1.67 kB](/9r4n4y/PiD_upscaler_image_restoration_tutorial_video/resolve/main/.gitattributes?download=true) Rename tutorial.webm to tutorial.mp4[Rename tutorial.webm to tutorial.mp4](/9r4n4y/PiD_upscaler_image_restoration_tutorial_video/commit/4bff5324219e1f70f59cb20f5651cc39fe203278) 5 months ago[5 months ago](/9r4n4y/PiD_upscaler_image_restoration_tutorial_video/commit/4bff5324219e1f70f59cb20f5651cc39fe203278)

-
README.md[README.md](/9r4n4y/PiD_upscaler_image_restoration_tutorial_video/blob/main/README.md)
Safe 6.6 kB
[6.6 kB](/9r4n4y/PiD_upscaler_image_restoration_tutorial_video/resolve/main/README.md?download=true) Update README.md[Update README.md](/9r4n4y/PiD_upscaler_image_restoration_tutorial_video/commit/c7b710ba49dafe114da0f3f7456a89a9c5577572) 5 months ago[5 months ago](/9r4n4y/PiD_upscaler_image_restoration_tutorial_video/commit/c7b710ba49dafe114da0f3f7456a89a9c5577572)

-
config.json[config.json](/9r4n4y/PiD_upscaler_image_restoration_tutorial_video/blob/main/config.json)
Safe 71 Bytes
[71 Bytes](/9r4n4y/PiD_upscaler_image_restoration_tutorial_video/resolve/main/config.json?download=true) Duplicate from nvidia/PiD[Duplicate from nvidia/PiD](/9r4n4y/PiD_upscaler_image_restoration_tutorial_video/commit/f0efdd14a98d24983b2df4974d369211cde269ad) 5 months ago[5 months ago](/9r4n4y/PiD_upscaler_image_restoration_tutorial_video/commit/f0efdd14a98d24983b2df4974d369211cde269ad)

-
tutorial.mp4[tutorial.mp4](/9r4n4y/PiD_upscaler_image_restoration_tutorial_video/blob/main/tutorial.mp4)
121 MB
xet
[121 MB xet](/9r4n4y/PiD_upscaler_image_restoration_tutorial_video/resolve/main/tutorial.mp4?download=true) Rename tutorial.webm to tutorial.mp4[Rename tutorial.webm to tutorial.mp4](/9r4n4y/PiD_upscaler_image_restoration_tutorial_video/commit/4bff5324219e1f70f59cb20f5651cc39fe203278) 5 months ago[5 months ago](/9r4n4y/PiD_upscaler_image_restoration_tutorial_video/commit/4bff5324219e1f70f59cb20f5651cc39fe203278)

## Reference sources

- [9r4n4yPiDupscalerimagerestorationtutorialvideo at main](https://huggingface.co/9r4n4y/PiD_upscaler_image_restoration_tutorial_video/tree/main) — accessed 2026-11-03
