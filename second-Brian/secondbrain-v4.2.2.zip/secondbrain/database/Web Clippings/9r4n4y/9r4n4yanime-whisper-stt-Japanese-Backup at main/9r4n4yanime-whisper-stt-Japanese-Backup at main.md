# 9r4n4yanime-whisper-stt-Japanese-Backup at main

:::quick-info
Source: https://huggingface.co/9r4n4y/anime-whisper-stt-Japanese-Backup/tree/main
Scraped: 2026-11-03
Topic: 9r4n4y
:::

9r4n4y/anime-whisper-stt-Japanese-Backup at main

![9r4n4y's picture](https://cdn-avatars.huggingface.co/v1/production/uploads/69cdd5e6700f30243d0900b0/-WGSuT-mVxxWVCENsJpt9.png)

9r4n4y[9r4n4y](/9r4n4y)
![litagin's picture](https://cdn-avatars.huggingface.co/v1/production/uploads/63e6f33bf2e9a8f22c5ce7b8/lXLNq88lxlnY6Mwk6pMsD.png)

litagin[litagin](/litagin)
Duplicate from litagin/anime-whisper 56c71ce[56c71ce](/9r4n4y/anime-whisper-stt-Japanese-Backup/commit/56c71ce53389294039c87edd9fce508f17946b82) 6 months ago

- figs[figs](/9r4n4y/anime-whisper-stt-Japanese-Backup/tree/main/figs)
Duplicate from litagin/anime-whisper[Duplicate from litagin/anime-whisper](/9r4n4y/anime-whisper-stt-Japanese-Backup/commit/56c71ce53389294039c87edd9fce508f17946b82) 6 months ago[6 months ago](/9r4n4y/anime-whisper-stt-Japanese-Backup/commit/56c71ce53389294039c87edd9fce508f17946b82)

-
.gitattributes[.gitattributes](/9r4n4y/anime-whisper-stt-Japanese-Backup/blob/main/.gitattributes)
Safe 1.52 kB
[1.52 kB](/9r4n4y/anime-whisper-stt-Japanese-Backup/resolve/main/.gitattributes?download=true) Duplicate from litagin/anime-whisper[Duplicate from litagin/anime-whisper](/9r4n4y/anime-whisper-stt-Japanese-Backup/commit/56c71ce53389294039c87edd9fce508f17946b82) 6 months ago[6 months ago](/9r4n4y/anime-whisper-stt-Japanese-Backup/commit/56c71ce53389294039c87edd9fce508f17946b82)

-
README.md[README.md](/9r4n4y/anime-whisper-stt-Japanese-Backup/blob/main/README.md)
Safe 21.8 kB
[21.8 kB](/9r4n4y/anime-whisper-stt-Japanese-Backup/resolve/main/README.md?download=true) Duplicate from litagin/anime-whisper[Duplicate from litagin/anime-whisper](/9r4n4y/anime-whisper-stt-Japanese-Backup/commit/56c71ce53389294039c87edd9fce508f17946b82) 6 months ago[6 months ago](/9r4n4y/anime-whisper-stt-Japanese-Backup/commit/56c71ce53389294039c87edd9fce508f17946b82)

-
added_tokens.json[added_tokens.json](/9r4n4y/anime-whisper-stt-Japanese-Backup/blob/main/added_tokens.json)
Safe 34.6 kB
[34.6 kB](/9r4n4y/anime-whisper-stt-Japanese-Backup/resolve/main/added_tokens.json?download=true) Duplicate from litagin/anime-whisper[Duplicate from litagin/anime-whisper](/9r4n4y/anime-whisper-stt-Japanese-Backup/commit/56c71ce53389294039c87edd9fce508f17946b82) 6 months ago[6 months ago](/9r4n4y/anime-whisper-stt-Japanese-Backup/commit/56c71ce53389294039c87edd9fce508f17946b82)

-
config.json[config.json](/9r4n4y/anime-whisper-stt-Japanese-Backup/blob/main/config.json)
Safe 1.27 kB
[1.27 kB](/9r4n4y/anime-whisper-stt-Japanese-Backup/resolve/main/config.json?download=true) Duplicate from litagin/anime-whisper[Duplicate from litagin/anime-whisper](/9r4n4y/anime-whisper-stt-Japanese-Backup/commit/56c71ce53389294039c87edd9fce508f17946b82) 6 months ago[6 months ago](/9r4n4y/anime-whisper-stt-Japanese-Backup/commit/56c71ce53389294039c87edd9fce508f17946b82)

-
generation_config.json[generation_config.json](/9r4n4y/anime-whisper-stt-Japanese-Backup/blob/main/generation_config.json)
Safe 3.9 kB
[3.9 kB](/9r4n4y/anime-whisper-stt-Japanese-Backup/resolve/main/generation_config.json?download=true) Duplicate from litagin/anime-whisper[Duplicate from litagin/anime-whisper](/9r4n4y/anime-whisper-stt-Japanese-Backup/commit/56c71ce53389294039c87edd9fce508f17946b82) 6 months ago[6 months ago](/9r4n4y/anime-whisper-stt-Japanese-Backup/commit/56c71ce53389294039c87edd9fce508f17946b82)

-
merges.txt[merges.txt](/9r4n4y/anime-whisper-stt-Japanese-Backup/blob/main/merges.txt)
Safe 494 kB
[494 kB](/9r4n4y/anime-whisper-stt-Japanese-Backup/resolve/main/merges.txt?download=true) Duplicate from litagin/anime-whisper[Duplicate from litagin/anime-whisper](/9r4n4y/anime-whisper-stt-Japanese-Backup/commit/56c71ce53389294039c87edd9fce508f17946b82) 6 months ago[6 months ago](/9r4n4y/anime-whisper-stt-Japanese-Backup/commit/56c71ce53389294039c87edd9fce508f17946b82)

-
model.safetensors[model.safetensors](/9r4n4y/anime-whisper-stt-Japanese-Backup/blob/main/model.safetensors)
Safe 3.03 GB
xet
[3.03 GB xet](/9r4n4y/anime-whisper-stt-Japanese-Backup/resolve/main/model.safetensors?download=true) Duplicate from litagin/anime-whisper[Duplicate from litagin/anime-whisper](/9r4n4y/anime-whisper-stt-Japanese-Backup/commit/56c71ce53389294039c87edd9fce508f17946b82) 6 months ago[6 months ago](/9r4n4y/anime-whisper-stt-Japanese-Backup/commit/56c71ce53389294039c87edd9fce508f17946b82)

-
normalizer.json[normalizer.json](/9r4n4y/anime-whisper-stt-Japanese-Backup/blob/main/normalizer.json)
Safe 52.7 kB
[52.7 kB](/9r4n4y/anime-whisper-stt-Japanese-Backup/resolve/main/normalizer.json?download=true) Duplicate from litagin/anime-whisper[Duplicate from litagin/anime-whisper](/9r4n4y/anime-whisper-stt-Japanese-Backup/commit/56c71ce53389294039c87edd9fce508f17946b82) 6 months ago[6 months ago](/9r4n4y/anime-whisper-stt-Japanese-Backup/commit/56c71ce53389294039c87edd9fce508f17946b82)

-
preprocessor_config.json[preprocessor_config.json](/9r4n4y/anime-whisper-stt-Japanese-Backup/blob/main/preprocessor_config.json)
Safe 340 Bytes
[340 Bytes](/9r4n4y/anime-whisper-stt-Japanese-Backup/resolve/main/preprocessor_config.json?download=true) Duplicate from litagin/anime-whisper[Duplicate from litagin/anime-whisper](/9r4n4y/anime-whisper-stt-Japanese-Backup/commit/56c71ce53389294039c87edd9fce508f17946b82) 6 months ago[6 months ago](/9r4n4y/anime-whisper-stt-Japanese-Backup/commit/56c71ce53389294039c87edd9fce508f17946b82)

-
special_tokens_map.json[special_tokens_map.json](/9r4n4y/anime-whisper-stt-Japanese-Backup/blob/main/special_tokens_map.json)
Safe 2.19 kB
[2.19 kB](/9r4n4y/anime-whisper-stt-Japanese-Backup/resolve/main/special_tokens_map.json?download=true) Duplicate from litagin/anime-whisper[Duplicate from litagin/anime-whisper](/9r4n4y/anime-whisper-stt-Japanese-Backup/commit/56c71ce53389294039c87edd9fce508f17946b82) 6 months ago[6 months ago](/9r4n4y/anime-whisper-stt-Japanese-Backup/commit/56c71ce53389294039c87edd9fce508f17946b82)

-
tokenizer_config.json[tokenizer_config.json](/9r4n4y/anime-whisper-stt-Japanese-Backup/blob/main/tokenizer_config.json)
Safe 283 kB
[283 kB](/9r4n4y/anime-whisper-stt-Japanese-Backup/resolve/main/tokenizer_config.json?download=true) Duplicate from litagin/anime-whisper[Duplicate from litagin/anime-whisper](/9r4n4y/anime-whisper-stt-Japanese-Backup/commit/56c71ce53389294039c87edd9fce508f17946b82) 6 months ago[6 months ago](/9r4n4y/anime-whisper-stt-Japanese-Backup/commit/56c71ce53389294039c87edd9fce508f17946b82)

-
vocab.json[vocab.json](/9r4n4y/anime-whisper-stt-Japanese-Backup/blob/main/vocab.json)
Safe 1.04 MB
[1.04 MB](/9r4n4y/anime-whisper-stt-Japanese-Backup/resolve/main/vocab.json?download=true) Duplicate from litagin/anime-whisper[Duplicate from litagin/anime-whisper](/9r4n4y/anime-whisper-stt-Japanese-Backup/commit/56c71ce53389294039c87edd9fce508f17946b82) 6 months ago[6 months ago](/9r4n4y/anime-whisper-stt-Japanese-Backup/commit/56c71ce53389294039c87edd9fce508f17946b82)

## Reference sources

- [9r4n4yanime-whisper-stt-Japanese-Backup at main](https://huggingface.co/9r4n4y/anime-whisper-stt-Japanese-Backup/tree/main) — accessed 2026-11-03
