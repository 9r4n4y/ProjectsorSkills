# 9r4n4y whisper termux android

:::quick-info
Source: https://github.com/9r4n4y/how-to-use-whisper-AI-in-Android-with-termux-for-subtitles-and-transcriptions.
Scraped: 2026-11-03
Topic: 9r4n4y
:::

GitHub - 9r4n4y/how-to-use-whisper-AI-in-Android-with-termux-for-subtitles-and-transcriptions.: Run OpenAI Whisper completely offline on Android using Termux. Put your audio/video file and a Whisper model in one folder, run a single command, and get automatic transcription or English-translated SRT/TXT subtitles — no internet, no API, no limits. · GitHub

Skip to content

You signed in with another tab or window. Reload to refresh your session.
You signed out in another tab or window. Reload to refresh your session.
You switched accounts on another tab or window. Reload to refresh your session.

Dismiss alert

{{ message }}

main

Branches[Branches](/9r4n4y/how-to-use-whisper-AI-in-Android-with-termux-for-subtitles-and-transcriptions./branches)Tags[Tags](/9r4n4y/how-to-use-whisper-AI-in-Android-with-termux-for-subtitles-and-transcriptions./tags)

Go to fileCode
Open more actions menu

## Latest commit

## History

2 Commits[2 Commits](/9r4n4y/how-to-use-whisper-AI-in-Android-with-termux-for-subtitles-and-transcriptions./commits/main/)

2 Commits
## Folders and files

| Name | Name |
Last commit message |
Last commit date
|

README.md[README.md](/9r4n4y/how-to-use-whisper-AI-in-Android-with-termux-for-subtitles-and-transcriptions./blob/main/README.md) |

README.md[README.md](/9r4n4y/how-to-use-whisper-AI-in-Android-with-termux-for-subtitles-and-transcriptions./blob/main/README.md) |
|

|
View all files

## Repository files navigation

# Whisper AI on Android (Offline)

Run OpenAI Whisper completely offline on Android using Termux.

This guide is clean, minimal, beginner-safe, and copy-paste friendly.

No cloud

No API

No internet after setup

Runs 100% locally on your phone

---

## What this does

- Generate SRT subtitles

- Generate TXT transcription

- Auto-detect spoken language

- Translate any language to English

- Works with audio or video files

---

## Requirements

- Android phone (4 GB RAM or more recommended)

- Termux from F-Droid only

https://f-droid.org/packages/com.termux/[https://f-droid.org/packages/com.termux/](https://f-droid.org/packages/com.termux/)

Open Termux after installing it.

---

## Step 1: Create working folder (phone storage)

Create one folder:

/storage/emulated/0/Download/transl/

Put everything here later.

Rename your audio file to:

input.mp3

This keeps commands simple.

---

## Step 2: Initial Termux setup

Run the following commands exactly.

pkg update && pkg upgrade -y

pkg install -y git cmake clang make ffmpeg wget

termux-setup-storage

Allow storage permission when asked.

---

## Step 3: Clone Whisper (one time only)

cd ~ git clone https://github.com/ggerganov/whisper.cpp.git[https://github.com/ggerganov/whisper.cpp.git](https://github.com/ggerganov/whisper.cpp.git) cd whisper.cpp

---

## Step 4: Build Whisper (one time only)

mkdir -p build cd build cmake .. make -j2

After this finishes, Whisper is ready.

---

## Step 5: Download Whisper model

Download the file:

ggml-small-q8_0.bin

Place it inside:

/storage/emulated/0/Download/transl/

---

## Step 6: Always go to Whisper directory before running commands

cd ~/whisper.cpp

You must be here every time you run Whisper.

---

## Step 7: Convert MP3 to WAV (recommended)

This avoids audio read errors.

ffmpeg -y -i /storage/emulated/0/Download/transl/input.mp3 -ar 16000 -ac 1 -c:a pcm_s16le /storage/emulated/0/Download/transl/input.wav

After this, use input.wav in all commands.

---

## Auto-detect language and translate to English (SRT)

This is the main command most people need.

./build/bin/whisper-cli
-m /storage/emulated/0/Download/transl/ggml-small-q8_0.bin
-f /storage/emulated/0/Download/transl/input.wav
-of /storage/emulated/0/Download/transl/output
-osrt
-tr
-l auto
-t 2
-ng

Output file:

/storage/emulated/0/Download/transl/output.srt

---

## Same-language transcription only (no translation)

./build/bin/whisper-cli
-m /storage/emulated/0/Download/transl/ggml-small-q8_0.bin
-f /storage/emulated/0/Download/transl/input.wav
-of /storage/emulated/0/Download/transl/output
-osrt
-l auto
-t 2
-ng

---

## TXT output only

./build/bin/whisper-cli
-m /storage/emulated/0/Download/transl/ggml-small-q8_0.bin
-f /storage/emulated/0/Download/transl/input.wav
-of /storage/emulated/0/Download/transl/output
-otxt
-tr
-l auto

Output file:

/storage/emulated/0/Download/transl/output.txt

---

## TXT and SRT together

./build/bin/whisper-cli
-m /storage/emulated/0/Download/transl/ggml-small-q8_0.bin
-f /storage/emulated/0/Download/transl/input.wav
-of /storage/emulated/0/Download/transl/output
-otxt
-osrt
-tr
-l auto
-t 2
-ng

---

## One-line quick command (always works)

Use this if you want a single paste that never fails.

cd ~/whisper.cpp && ./build/bin/whisper-cli -m /storage/emulated/0/Download/transl/ggml-small-q8_0.bin -f /storage/emulated/0/Download/transl/input.wav -of /storage/emulated/0/Download/transl/output -osrt -tr -l auto -t 2 -ng

---

## Flags reference

- -m model path

- -f input audio

- -of output name

- -osrt generate SRT

- -otxt generate TXT

- -tr translate to English

- -l auto auto language detection

- -t 2 CPU threads

- -ng disable GPU (Android safe)

---

## Final summary

- Install Termux

- Install packages

- Build Whisper once

- Put model and audio in transl

- Run one command

- Get subtitles or text

---

## Search keywords

Whisper AI Android

Whisper offline Android

Whisper Termux guide

Whisper cpp Android

Offline speech to text Android

Generate SRT Android offline

Whisper AI no internet

Whisper AI no API

Whisper translation Android

Whisper subtitles Android

## About

Run OpenAI Whisper completely offline on Android using Termux. Put your audio/video file and a Whisper model in one folder, run a single command, and get automatic transcription or English-translated SRT/TXT subtitles — no internet, no API, no limits.

### Resources

Readme

Activity[Activity](/9r4n4y/how-to-use-whisper-AI-in-Android-with-termux-for-subtitles-and-transcriptions./activity)

### Stars

4 stars
### Watchers

0 watching
### Forks

1 fork[1 fork](/9r4n4y/how-to-use-whisper-AI-in-Android-with-termux-for-subtitles-and-transcriptions./forks)
Report repository[Report repository](/contact/report-content?content_url=https%3A%2F%2Fgithub.com%2F9r4n4y%2Fhow-to-use-whisper-AI-in-Android-with-termux-for-subtitles-and-transcriptions.&report=9r4n4y+%28user%29)

## Releases

## Packages

## Contributors

You can’t perform that action at this time.

## Reference sources

- [9r4n4y whisper termux android](https://github.com/9r4n4y/how-to-use-whisper-AI-in-Android-with-termux-for-subtitles-and-transcriptions.) — accessed 2026-11-03
