# 9r4n4yadonisflux2kleinbackup  Hugging Face

:::quick-info
Source: https://huggingface.co/9r4n4y/adonis_flux2klein_backup
Scraped: 2026-11-03
Topic: 9r4n4y
:::

9r4n4y/adonis_flux2klein_backup · Hugging Face

#

05/20/26 - Added New Model: Adonis Post for Flux 2 Klein 9B

An additional model to be used with the Adonis Base or Refine model. The new model was trained on the outputs of Adonis (as the control images) and the original reference high resolution images (as the target images).

This new model removes the artifacts that show up from the Base or Refine model upscale process, reducing the harsh details so the images look more natural and clean. Images of women are much softer and feminine, and the Post model seems to help with images upscaled via other means as well (SeedVR2, Upscale using Model, etc.)

The example images used Adonis_Base as the first generation step, Adonis_Refine can be used as well but will shift the image slightly (anatomy is better with Refine so what works best will vary by your image.)

#

Adonis for Flux 2 Klein 9B

Adonis is an "upscale model" LoKr trained using a high-resolution "target" dataset of men, paired with synthetic low-resolution edited copies as the "control." It refines skin, hair, and anatomy details that base model often gets wrong.

##

How it Works

- Edit-Only: Improves only what is already visible in the input image. Suitable for any image involving people.

- Two-Model Generation: The model splits into two models (adonis_base or adonis_refine + adonis_post) that work best together:

- Adonis Base (or Refine): Sets the image structure and color first, while grabbing rough details from the low resolution images. (first generation, 6-9 steps)

- Adonis Post: Corrects and removes artifact issues from the first step, smooths skin and refines details like hair texture. (final generation, 6-9 steps)

##

Recommended Prompt

This prompt enhances most images effectively:

uhdmanscale, fully reconstruct this entire image from cellphone quality to professional high resolution color raw quality. Remove halftone dot pattern. Apply descreen filter. Eliminate periodic grid noise. Eliminate repeating noise patterns and artifacts, remove uniform diagonal line texture patterns. Reconstruct low resolution high ISO noise areas with high resolution low ISO noise textures.

Apply full detail reconstruction to all areas: background, environment, surfaces, objects, clothing, and foreground elements — render everything sharp, textured, and high fidelity.

Subject identity is locked: preserve exact facial geometry and body geometry, eye shape and color, nose and mouth shape, and expression. On skin areas, remove color blotch artifacts, normalize tone uniformity, preserve natural pore and texture detail. On hair and body hair areas, separate smeared color artifacts, restore strand separation and texture. Outside the subject's face, freely reconstruct all texture and sharpness with no restrictions.

Deblur and focus correction pass. Infer and reconstruct underlying detail from soft source: sharpen edge definition, recover eye detail, lip definition, and skin texture from motion blur. Output as professional high resolution color camera RAW image.

Note: For non-color inputs, specify object colors in the background. Replace "color" with "black and white" if you do not want to colorize the image.

##

ComfyUI Setup

The Adonis_Workflow.json is included. Install these custom nodes:

- ComfyUI-KJNodes[ComfyUI-KJNodes](https://github.com/kijai/ComfyUI-KJNodes)

- ComfyUi-Scale-Image-to-Total-Pixels-Advanced[ComfyUi-Scale-Image-to-Total-Pixels-Advanced](https://github.com/BigStationW/ComfyUi-Scale-Image-to-Total-Pixels-Advanced)

- gguf[gguf](https://github.com/calcuis/gguf)

- RES4LYF[RES4LYF](https://github.com/ClownsharkBatwing/RES4LYF)

- rgthree-comfy[rgthree-comfy](https://github.com/rgthree/rgthree-comfy)

- comfyui-vrgamedevgirl[comfyui-vrgamedevgirl](https://github.com/vrgamegirl19/comfyui-vrgamedevgirl)

##

Model Files & Requirements

Base Models:

- FLUX.2-klein-9B.safetensors[FLUX.2-klein-9B.safetensors](https://huggingface.co/black-forest-labs/FLUX.2-klein-9B/blob/main/flux-2-klein-9b.safetensors) (HuggingFace: black-forest-labs/FLUX.2-klein-9B)

- Flux 2 VAE[Flux 2 VAE](https://huggingface.co/Comfy-Org/flux2-dev/resolve/main/split_files/vae/flux2-vae.safetensors) (HuggingFace: Comfy-Org/flux2-dev)

Clip:

- Qwen3-8B-GGUF[Qwen3-8B-GGUF](https://github.com/Qwen/Qwen3-8B-GGUF/tree/main)

- Use a higher quantization GGUF if VRAM is limited. FP8 tends to degrade details in eyes and fingers based on testing.

##

Training Details

- Config: adonis_ai_toolkit_config.yaml training config included.

- Method: Factor 4 LoKr trained with 100 images at target resolutions of 1024px, 1280px, and 1536px.

- Hardware: Requires >24GB VRAM

##

Examples

-
SFW Examples[SFW Examples](https://slow.pics/s/tlV469yQ) (Slow.Pics)

-
(Male) NSFW Examples[(Male) NSFW Examples](https://slow.pics/s/fgOHfi7H) (Slow.Pics)

Downloads last month

-

Downloads are not tracked for this model. How to track [How to track](https://huggingface.co/docs/hub/models-download-stats)

Inference Providers NEW[NEW](https://huggingface.co/docs/inference-providers)
This model isn't deployed by any Inference Provider. 🙋 Ask for provider support[🙋 Ask for provider support](/spaces/huggingface/InferenceSupport/discussions/new?title=9r4n4y/adonis_flux2klein_backup&description=React%20to%20this%20comment%20with%20an%20emoji%20to%20vote%20for%20%5B9r4n4y%2Fadonis_flux2klein_backup%5D(%2F9r4n4y%2Fadonis_flux2klein_backup)%20to%20be%20supported%20by%20Inference%20Providers.%0A%0A(optional)%20Which%20providers%20are%20you%20interested%20in%3F%20(Novita%2C%20Hyperbolic%2C%20Together%E2%80%A6)%0A)

## Model tree for 9r4n4y/adonis_flux2klein_backup

Base model

black-forest-labs/FLUX.2-klein-9B[black-forest-labs/FLUX.2-klein-9B](/black-forest-labs/FLUX.2-klein-9B)

Finetuned (58[58](/models?other=base_model:finetune:black-forest-labs/FLUX.2-klein-9B))

this model

## Reference sources

- [9r4n4yadonisflux2kleinbackup  Hugging Face](https://huggingface.co/9r4n4y/adonis_flux2klein_backup) — accessed 2026-11-03
