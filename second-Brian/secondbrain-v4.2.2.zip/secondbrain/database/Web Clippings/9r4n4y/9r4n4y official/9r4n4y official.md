# 9r4n4y official

:::quick-info
Source: https://huggingface.co/9r4n4y
Scraped: 2026-11-03
Topic: 9r4n4y
:::

9r4n4y (official)

![official's picture](https://cdn-avatars.huggingface.co/v1/production/uploads/69cdd5e6700f30243d0900b0/-WGSuT-mVxxWVCENsJpt9.png)

# official[official](/9r4n4y)

9r4n4y
3[3](/9r4n4y/activity/community) 20[20](/9r4n4y/activity/likes)

Follow

![https://cdn-avatars.huggingface.co/v1/production/uploads/noauth/lcGMzIDdMeOJvl8dF53vQ.png](https://cdn-avatars.huggingface.co/v1/production/uploads/noauth/lcGMzIDdMeOJvl8dF53vQ.png)
Nexylll's profile picture[Nexylll's profile picture](/Nexylll)
![https://cdn-avatars.huggingface.co/v1/production/uploads/noauth/sE8Rzooy67a7h10ei-qix.jpeg](https://cdn-avatars.huggingface.co/v1/production/uploads/noauth/sE8Rzooy67a7h10ei-qix.jpeg)
LUCYsstillhere's profile picture[LUCYsstillhere's profile picture](/LUCYsstillhere)
![/avatars/974462b1590ecf126b08b176062932de.svg](/avatars/974462b1590ecf126b08b176062932de.svg)
Naseer1200's profile picture[Naseer1200's profile picture](/Naseer1200) 5
followers
· 4 following
### AI & ML interests

None yet
### Recent Activity

liked a Space 3 days ago BharathK333/VoxMorph [BharathK333/VoxMorph](/spaces/BharathK333/VoxMorph)

updated a dataset 11 days ago 9r4n4y/DataMine [9r4n4y/DataMine](/datasets/9r4n4y/DataMine)

published a dataset 11 days ago 9r4n4y/DataMine [9r4n4y/DataMine](/datasets/9r4n4y/DataMine) View all activity[View all activity](/9r4n4y/activity/all)
### Organizations

None yet

###
Collections 4[Collections 4](/9r4n4y/collections)

img-datasets
[img-datasets](/collections/9r4n4y/img-datasets)

-

Viewer • Updated Jul 21, 2024 • 456k • 53 • 36 [Viewer • Updated Jul 21, 2024 • 456k • 53 • 36](/datasets/SilentAntagonist/vintage-photography-450k-high-quality-captions)

-

Viewer • Updated Apr 20 • 810 • 9 • 1 [Viewer • Updated Apr 20 • 810 • 9 • 1](/datasets/9r4n4y/ghibli_images_with_captions)

-

Viewer • Updated Apr 20 • 368 • 101 [Viewer • Updated Apr 20 • 368 • 101](/datasets/9r4n4y/Gpt_Style_Ghibli_Images)

tutorial videos
[tutorial videos](/collections/9r4n4y/tutorial-videos)

-

Image-to-Image • Updated Jun 2 • 79 • 2 [Image-to-Image • Updated Jun 2 • 79 • 2](/9r4n4y/PiD_upscaler_image_restoration_tutorial_video)

-

Updated Jun 5 • 1 [Updated Jun 5 • 1](/9r4n4y/Untwisting-RoPE-Style-tranfer-for-img-models-with-tutorial)

img-datasets
[img-datasets](/collections/9r4n4y/img-datasets)

-

Viewer • Updated Jul 21, 2024 • 456k • 53 • 36 [Viewer • Updated Jul 21, 2024 • 456k • 53 • 36](/datasets/SilentAntagonist/vintage-photography-450k-high-quality-captions)

-

Viewer • Updated Apr 20 • 810 • 9 • 1 [Viewer • Updated Apr 20 • 810 • 9 • 1](/datasets/9r4n4y/ghibli_images_with_captions)

-

Viewer • Updated Apr 20 • 368 • 101 [Viewer • Updated Apr 20 • 368 • 101](/datasets/9r4n4y/Gpt_Style_Ghibli_Images)

tutorial videos
[tutorial videos](/collections/9r4n4y/tutorial-videos)

-

Image-to-Image • Updated Jun 2 • 79 • 2 [Image-to-Image • Updated Jun 2 • 79 • 2](/9r4n4y/PiD_upscaler_image_restoration_tutorial_video)

-

Updated Jun 5 • 1 [Updated Jun 5 • 1](/9r4n4y/Untwisting-RoPE-Style-tranfer-for-img-models-with-tutorial)

View 4 collections[View 4 collections](/9r4n4y/collections)

### models 12[models 12](/9r4n4y/models)

Sort:
Recently updated

Automatic Speech Recognition • 0.3B • Updated 29 days ago • 21 [Automatic Speech Recognition • 0.3B • Updated 29 days ago • 21](/9r4n4y/Wav2Vec2-large-xlsr-hindi)

Updated Jun 10 [Updated Jun 10](/9r4n4y/adonis_flux2klein_backup)

Updated Jun 5 • 1 [Updated Jun 5 • 1](/9r4n4y/Untwisting-RoPE-Style-tranfer-for-img-models-with-tutorial)

Image-to-Image • Updated Jun 2 • 79 • 2 [Image-to-Image • Updated Jun 2 • 79 • 2](/9r4n4y/PiD_upscaler_image_restoration_tutorial_video)

Text-to-Speech • 4B • Updated May 19 • 102 • 23 [Text-to-Speech • 4B • Updated May 19 • 102 • 23](/9r4n4y/LongCat-AudioDiT-3.5B-tts-text-to-speech-SOTA)

Automatic Speech Recognition • 0.8B • Updated Apr 27 • 41 [Automatic Speech Recognition • 0.8B • Updated Apr 27 • 41](/9r4n4y/anime-whisper-stt-Japanese-Backup)

Text-to-Speech • 4B • Updated Apr 26 • 5 [Text-to-Speech • 4B • Updated Apr 26 • 5](/9r4n4y/LongCat-AudioDiT-3.5B-fp8-backup)

4B • Updated Apr 26 • 5 [4B • Updated Apr 26 • 5](/9r4n4y/LongCat-AudioDiT-3.5B-backup)

Text-to-Image • Updated Apr 25 • 28 • [Text-to-Image • Updated Apr 25 • 28 •](/9r4n4y/Z-Image-Turbo-Ghibli-Style-backup-2)

8B • Updated Apr 23 • 7 [8B • Updated Apr 23 • 7](/9r4n4y/llama-joycaption-alpha-two-hf-llava-backup)

View 12
models[View 12
models](/9r4n4y/models)

### datasets 9[datasets 9](/9r4n4y/datasets)

Sort:
Recently updated

Updated 11 days ago • 23 [Updated 11 days ago • 23](/datasets/9r4n4y/DataMine)

Updated Sep 3 • 13 • 1 [Updated Sep 3 • 13 • 1](/datasets/9r4n4y/9r4n4y)

Updated Jul 9 • 10 [Updated Jul 9 • 10](/datasets/9r4n4y/Courage-The-Cowardly-Dog-hindi-english-tamil)

Viewer • Updated Jul 9 • 63 • 86 • 1 [Viewer • Updated Jul 9 • 63 • 86 • 1](/datasets/9r4n4y/srmthfg)

Viewer • Updated Jun 7 • 456k • 17 • 1 [Viewer • Updated Jun 7 • 456k • 17 • 1](/datasets/9r4n4y/vintage-photography-450k-high-quality-captions)

Viewer • Updated May 25 • 26 • 67 • 1 [Viewer • Updated May 25 • 26 • 67 • 1](/datasets/9r4n4y/Ultimate-Spiderman-english-hindi-tamil)

Viewer • Updated Apr 20 • 810 • 9 • 1 [Viewer • Updated Apr 20 • 810 • 9 • 1](/datasets/9r4n4y/ghibli_images_with_captions)

Viewer • Updated Apr 20 • 368 • 101 [Viewer • Updated Apr 20 • 368 • 101](/datasets/9r4n4y/Gpt_Style_Ghibli_Images)

Viewer • Updated Apr 12 • 4 • 96 [Viewer • Updated Apr 12 • 4 • 96](/datasets/9r4n4y/vintagescifi-19k-nocaptions-png-format)

## Reference sources

- [9r4n4y official](https://huggingface.co/9r4n4y) — accessed 2026-11-03
