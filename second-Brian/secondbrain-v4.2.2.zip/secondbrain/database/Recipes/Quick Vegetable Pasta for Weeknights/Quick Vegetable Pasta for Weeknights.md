
![pasta-2](database/Recipes/Quick Vegetable Pasta for Weeknights/attachments/pasta-2.png)
# Quick Vegetable Pasta for Weeknights

:::quick-info
Common name: Vegetable Pasta
Serves: 4
Time: 25 minutes
Often paired with: [[Garlic Bread]]
Image: attachments/pasta-1.png

## Dietary notes
Vegetarian: Yes
Vegan: No (parmesan)
:::

A one-pot pasta that gets dinner on the table in 25 minutes on any weeknight.
Everything cooks in the same pan, so washing up stays light. This recipe is
the quickest vegetable pasta in the box and the one I cook most often.

## Ingredients

| Ingredient | Amount |
| --- | --- |
| Pasta (penne or fusilli) | 350 g |
| Cherry tomatoes | 250 g |
| Courgette | 1 medium |
| Garlic | 3 cloves |
| Vegetable stock | 500 ml |
| Parmesan | 40 g |
| Basil | a handful |
| Olive oil | 2 tbsp |

## Method

1. Sizzle the sliced garlic in the olive oil over a medium heat for one
   minute. Do not let it brown.
2. Add the chopped courgette and the tomatoes and cook for 5 minutes.
3. Stir in the dry pasta and the stock. Cover and simmer for 12 minutes,
   stirring twice, until the pasta is done and the liquid is mostly gone.
4. Take off the heat, stir in the parmesan and the basil, and rest for two
   minutes before serving.

## Tips

- Grate the parmesan finely so it melts into a sauce instead of clumping.
- The whole recipe is one pot; if the pan dries out before the pasta is
  soft, add a splash of hot water.
- Turn it vegan with a spoon of nutritional yeast instead of parmesan.

## Gallery

![The pan, mid-cook](attachments/pasta-2.png)

![First attempt](attachments/pasta-1.png)

![Plated, ready|75](attachments/pasta-3.png)

![pasta pan](attachments/pasta-1.png)

![pasta plate](attachments/pasta-2.png)

A paragraph with ![inline shot](attachments/pasta-3.png) inside the sentence.

## My notes

- 2026-10-20: made it with frozen peas added in step 3 — works well, kids
  ate it without picking anything out.
- The stock cube makes it salty enough; no extra salt needed.

## Connected notes

[[Garlic Bread]]
[[Lentil Soup for Cold Evenings]]
[[Spanish Kitchen Words]]

## Reference sources

- [BBC Good Food: one-pot pasta technique](https://www.bbcgoodfood.com/recipes/collection/one-pot-pasta-recipes) — accessed 2026-10-15

:::meta











Status: verified
Created: 2026-10-15
Updated: 2026-11-02
Pinned: yes
:::
