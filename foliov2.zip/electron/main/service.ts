// The desktop implementation of NativeApi: library, jobs, extraction, verification, trash, health, import.

import * as fsp from "node:fs/promises";
import * as os from "node:os";
import * as path from "node:path";
import { randomUUID } from "node:crypto";
import {
  type ArchiveJob,
  type ArchiveRecord,
  type ComicRecord,
  type ComicStatePatch,
  type Counts,
  DEFAULT_SETTINGS,
  type DeletePreview,
  type DecodeResult,
  type EnginePort,
  type ExtractResult,
  type FileFacts,
  type FolderCheck,
  type FolderRecord,
  type HealthCheck,
  type HealthReport,
  type ImportApply,
  type ImportReport,
  type InitInfo,
  type JobAction,
  JobQueue,
  type JobsState,
  type LayerResult,
  type LibrarySnapshot,
  MANIFEST_NAME,
  type Manifest,
  type MoveResult,
  type PageInfo,
  type PasswordEntry,
  type PermissionStatus,
  type ScanSummary,
  type Settings,
  type SizeReport,
  type StatePatch,
  type TagDef,
  type TrashItem,
  type VerificationReport,
  compareToManifest,
  decodeLayer,
  extractArchive,
  isImageFile,
  isJunkPath,
  layer,
  makeFingerprint,
  mapLimit,
  normalizeText,
  pageSequenceLayer,
  planExtraction,
  reconcileScan,
  sanitizeSegment,
  sha256Hex,
  skipped,
  smallFilesLayer,
  summarizeLayers,
  uniqueName,
} from "@comiclib/shared";
import { Db } from "./db";
import { NodeFs, SevenZipEngine } from "./ports";
import { describeComic, naturalPages, scanRoot } from "./scanner";

export interface Host {
  dataDir: string;
  appVersion: string;
  engines: { id: string; bin: string }[];
  imaging: {
    check(abs: string): Promise<{ ok: boolean; width: number; height: number; error?: string }>;
    thumbs(src: string, small: string, medium: string): Promise<boolean>;
  };
  encrypt(s: string): string;
  decrypt(s: string): string;
  pickFolder(): Promise<string | null>;
  saveText(name: string, text: string): Promise<string | null>;
  pickText(): Promise<string | null>;
  openPath(p: string): void;
  emit(event: string, payload: unknown): void;
  copy(text: string): void;
  notify(title: string, body: string): void;
}

const isGreen = (r?: VerificationReport) => !!r && (r.status === "green" || (r.manual && r.status === "amber"));
const worst = (a: LayerResult, b: LayerResult): LayerResult => {
  const rank = { fail: 3, warn: 2, pass: 1, skip: 0 } as const;
  return rank[b.status] > rank[a.status] ? b : a;
};

export class Service {
  readonly db: Db;
  readonly queue: JobQueue;
  root: string | null;
  private fs = new NodeFs();
  private engines: EnginePort[];
  private lastScan: ScanSummary = { comics: 0, folders: 0, archives: 0, added: 0, removed: 0, moved: 0, updated: 0, ms: 0 };
  private thumbInflight = new Map<string, Promise<boolean>>();
  private libTimer: ReturnType<typeof setTimeout> | null = null;
  private baseWorkers = 2;
  private healthLog: string[] = [];

  constructor(private host: Host) {
    this.db = new Db(path.join(host.dataDir, "library.db"), () => this.root);
    this.root = this.db.getSetting<string | null>("root", null);
    this.engines = host.engines.map((e) => new SevenZipEngine(e.id, e.bin));
    this.queue = new JobQueue({ concurrency: this.workers(), store: this.db, log: (m) => this.healthLog.push(m) });
    this.queue.subscribe((s) => host.emit("jobs", s));
    this.queue.register("scan", async (ctx) => {
      await this.doScan(ctx.progress, ctx.signal);
    });
    this.queue.register("extract", (ctx) => this.runExtract(ctx.payload as ExtractPayload, ctx));
    this.queue.register("verify", (ctx) => this.runVerify(ctx.payload as { id: string }, ctx));
    this.queue.register("thumbs", async (ctx) => {
      await this.doThumbs(ctx.progress, ctx.signal);
    });
    this.queue.register("fingerprint", async (ctx) => {
      await this.doFingerprints(ctx.progress, ctx.signal);
    });
  }

  async start(): Promise<void> {
    await this.queue.restore();
  }

  // ---- settings and init ---------------------------------------------------------------------
  settings(): Settings {
    return { ...DEFAULT_SETTINGS, ...this.db.getSetting<Partial<Settings>>("settings", {}) };
  }
  private workers(): number {
    const s = (this.db?.getSetting<Partial<Settings>>("settings", {}) ?? {}).workers ?? 0;
    return s > 0 ? s : Math.max(1, Math.min(4, Math.floor(os.cpus().length / 2)));
  }
  private async freeBytes(): Promise<number> {
    try {
      const s = await fsp.statfs(this.root ?? this.host.dataDir);
      return Number(s.bavail) * Number(s.bsize);
    } catch {
      return 0;
    }
  }
  private permissions(): PermissionStatus {
    return { allFiles: "granted", safFolder: "unsupported", notifications: "granted", foregroundService: "unsupported", wakeLock: "unsupported", batteryOptimization: "unsupported" };
  }
  async init(): Promise<InitInfo> {
    this.baseWorkers = this.workers();
    this.queue.setConcurrency(this.baseWorkers);
    return {
      platform: "electron",
      appVersion: this.host.appVersion,
      root: this.root,
      settings: this.settings(),
      permissions: this.permissions(),
      env: { os: `${os.platform()} ${os.release()}`, cpus: os.cpus().length, freeBytes: await this.freeBytes() },
      savedPasswordCount: this.db.listPasswords().length,
      needsOnboarding: false,
      demo: false,
    };
  }
  async pickFolder() {
    return this.host.pickFolder();
  }
  async setRoot(p: string) {
    this.root = p;
    this.db.setSetting("root", p);
    this.db.h.exec("DELETE FROM comics; DELETE FROM comic_fts; DELETE FROM archives; DELETE FROM folders;");
    await this.scan();
  }

  // ---- library -------------------------------------------------------------------------------
  async getLibrary(): Promise<LibrarySnapshot> {
    return {
      root: this.root,
      comics: this.db.allComics(),
      folders: this.db.allFolders(),
      archives: this.db.allArchives().filter((a) => a.status !== "deleted"),
      tags: this.db.allTags(),
      reports: this.db.allReports(),
      trash: this.db.trash().map(({ trashPath: _t, ...t }) => t),
    };
  }
  private emitLibrary() {
    if (this.libTimer) return;
    this.libTimer = setTimeout(() => {
      this.libTimer = null;
      this.host.emit("library", {});
    }, 250);
  }

  private runJob(kind: string, title: string, payload: unknown, group?: string): Promise<void> {
    const j = this.queue.add(kind, title, payload, { group });
    return new Promise((resolve, reject) => {
      const off = this.queue.subscribe(() => {
        const cur = this.queue.get(j.id);
        if (!cur || ["done", "failed", "cancelled"].includes(cur.state)) {
          off();
          if (cur?.state === "failed") reject(new Error(cur.error));
          else resolve();
        }
      });
    });
  }

  async scan(): Promise<ScanSummary> {
    if (!this.root) throw new Error("No mother folder selected");
    await this.runJob("scan", "Scanning library", {}, "scan");
    return this.lastScan;
  }

  private async doScan(progress: (p: { message?: string; fraction?: number }) => void, signal: AbortSignal): Promise<void> {
    const root = this.root;
    if (!root) throw new Error("No mother folder selected");
    if (!(await this.fs.exists(root))) throw new Error(`Mother folder is not available: ${root}`);
    const t0 = Date.now();
    const prev = this.db.h.prepare("SELECT id, rel_path AS relPath, size, mtime, pages FROM comics").all() as { id: string; relPath: string; size: number; mtime: number; pages: number }[];
    const found = await scanRoot(root, new Map(prev.map((p) => [p.relPath, p])), (d, c) => progress({ message: `${c} comics in ${d} folders` }), signal);
    if (signal.aborted) return;
    const rec = reconcileScan(prev, found.comics);
    this.db.h.transaction(() => {
      for (const m of rec.moved) {
        this.db.upsertComic({ id: m.prev.id, ...m.next }, m.prev.id);
        this.db.bumpThumb(m.prev.id);
      }
      for (const u of rec.updated) {
        this.db.upsertComic({ id: u.prev.id, ...u.next }, u.prev.id);
        if (u.prev.pages !== u.next.pages) this.db.bumpThumb(u.prev.id);
      }
      for (const a of rec.added) this.db.upsertComic({ id: "c_" + randomUUID().replace(/-/g, "").slice(0, 12), ...a });
      this.db.deleteComics(rec.removed.map((r) => r.id));
      const keep = new Set<string>();
      for (const a of found.archives) {
        keep.add(a.relPath);
        this.db.upsertArchive({
          id: "a_" + sha256Hex(a.relPath).slice(0, 12),
          relPath: a.relPath,
          name: a.name,
          folder: a.folder,
          author: a.author,
          size: a.size,
          parts: a.group.parts,
          missingParts: a.group.missing,
          encrypted: false,
          status: "pending",
          targetName: sanitizeSegment(a.name),
        });
      }
      this.db.deleteArchivesNotIn(keep);
    })();
    this.db.replaceFolders(buildFolders(found.dirs, found.comics, found.archives));
    this.lastScan = {
      comics: found.comics.length,
      folders: found.dirs.length,
      archives: found.archives.length,
      added: rec.added.length,
      removed: rec.removed.length,
      moved: rec.moved.length,
      updated: rec.updated.length,
      ms: Date.now() - t0,
    };
    this.emitLibrary();
    if (!this.queue.list().some((j) => ["thumbs", "fingerprint"].includes(j.kind) && j.state === "queued")) {
      this.queue.add("thumbs", "Generating thumbnails", {}, { group: "background" });
      this.queue.add("fingerprint", "Fingerprinting comics", {}, { group: "background" });
    }
    if (this.settings().autoExtractNew) await this.extractAll();
  }

  // ---- state -----------------------------------------------------------------------------------
  async saveState(patch: StatePatch) {
    if (patch.comics?.length || patch.tagDefs?.length || patch.deleteTags?.length) this.db.applyState(patch.comics ?? [], patch.tagDefs ?? [], patch.deleteTags ?? []);
    if (patch.settings) {
      this.db.setSetting("settings", { ...this.settings(), ...patch.settings });
      if (patch.settings.workers !== undefined) {
        this.baseWorkers = this.workers();
        this.queue.setConcurrency(this.baseWorkers);
      }
    }
  }

  // ---- pages and thumbnails ---------------------------------------------------------------------
  private comicDir(id: string): string | null {
    const r = this.db.comicRow(id);
    return r && this.root ? path.join(this.root, ...r.rel_path.split("/")) : null;
  }
  async pages(comicId: string): Promise<PageInfo[]> {
    const dir = this.comicDir(comicId);
    if (!dir) return [];
    const names = await naturalPages(dir);
    return Promise.all(
      names.map(async (n) => ({ name: n, url: `comic://page/${comicId}/${encodeURIComponent(n)}`, size: (await fsp.stat(path.join(dir, n)).catch(() => ({ size: 0 }))).size })),
    );
  }
  pageFile(comicId: string, name: string): string | null {
    const dir = this.comicDir(comicId);
    if (!dir || name.includes("/") || name.includes("\\") || !isImageFile(name)) return null;
    return path.join(dir, name);
  }
  thumbPath(id: string, size: "s" | "m") {
    return path.join(this.host.dataDir, "thumbs", `${id}_${size}.jpg`);
  }
  async ensureThumbFile(id: string, size: "s" | "m"): Promise<string | null> {
    const p = this.thumbPath(id, size);
    if (await this.fs.exists(p)) return p;
    await this.ensureThumb(id);
    return (await this.fs.exists(p)) ? p : null;
  }
  async ensureThumb(id: string): Promise<void> {
    let pr = this.thumbInflight.get(id);
    if (!pr) {
      pr = (async () => {
        const dir = this.comicDir(id);
        if (!dir) return false;
        const pages = await naturalPages(dir).catch(() => []);
        if (!pages.length) return false;
        return this.host.imaging.thumbs(path.join(dir, pages[0]), this.thumbPath(id, "s"), this.thumbPath(id, "m"));
      })().finally(() => this.thumbInflight.delete(id));
      this.thumbInflight.set(id, pr);
    }
    await pr;
  }
  private async thumbOk(id: string): Promise<boolean> {
    const st = await fsp.stat(this.thumbPath(id, "m")).catch(() => null);
    return !!st && st.size > 100;
  }
  private async doThumbs(progress: (p: { done?: number; total?: number; message?: string }) => void, signal: AbortSignal) {
    const all = this.db.allComics();
    const missing: ComicRecord[] = [];
    for (const c of all) if (!(await this.thumbOk(c.id))) missing.push(c);
    let done = 0;
    await mapLimit(missing, 3, async (c) => {
      if (signal.aborted) return;
      await this.ensureThumb(c.id);
      progress({ done: ++done, total: missing.length, message: `${done} of ${missing.length}` });
      if (done % 20 === 0) this.host.emit("thumbs", {});
    });
    this.host.emit("thumbs", {});
  }
  private async doFingerprints(progress: (p: { done?: number; total?: number }) => void, signal: AbortSignal) {
    const todo = this.db.allComics().filter((c) => !c.fp);
    let done = 0;
    await mapLimit(todo, 2, async (c) => {
      if (signal.aborted) return;
      try {
        const names = await naturalPages(c.path);
        if (!names.length) return;
        const sizes = await Promise.all(names.map((n) => fsp.stat(path.join(c.path, n)).then((s) => ({ size: s.size }))));
        const first = await this.fs.hashFile(path.join(c.path, names[0]));
        const last = await this.fs.hashFile(path.join(c.path, names[names.length - 1]));
        this.db.setFingerprint(c.id, makeFingerprint(sizes, first.sha256, last.sha256));
      } catch {
        /* comic vanished; the next scan reconciles it */
      }
      progress({ done: ++done, total: todo.length });
    });
  }

  thumbUrl(): string {
    return "";
  }
  async resolveImage(url: string) {
    return url;
  }

  // ---- jobs --------------------------------------------------------------------------------------
  async getJobs(): Promise<JobsState> {
    return this.queue.state();
  }
  async jobControl(action: JobAction, id?: string) {
    if (action === "pause") this.queue.pauseAll();
    else if (action === "resume") this.queue.resumeAll();
    else if (action === "cancel") id ? this.queue.cancel(id) : this.queue.cancelAll();
    else if (action === "retry" && id) this.queue.retry(id);
    else if (action === "clear") this.queue.clearFinished();
  }

  async extractAll() {
    const ids = this.db.allArchives().filter((a) => a.status === "pending").map((a) => a.id);
    await this.enqueueExtract(ids);
  }
  async extractArchives(ids: string[], opts: { password?: string; applyToSimilar?: boolean } = {}) {
    if (opts.password && opts.applyToSimilar) {
      this.db.addPassword("p_" + randomUUID().slice(0, 8), "Added from extraction prompt", this.host.encrypt(opts.password));
      const similar = this.db.allArchives().filter((a) => a.status === "needs_password").map((a) => a.id);
      ids = [...new Set([...ids, ...similar])];
    }
    await this.enqueueExtract(ids, opts.password);
  }
  private async enqueueExtract(ids: string[], password?: string) {
    for (const id of ids) {
      const a = this.db.archive(id);
      if (!a || a.status === "deleted" || a.status === "extracting") continue;
      this.db.setArchive(id, { status: "queued" });
      this.queue.add("extract", `Extract ${a.name}`, { archiveId: id, password } satisfies ExtractPayload, { group: "extract", totalBytes: a.size, id: `x-${id}-${Date.now().toString(36)}` });
    }
    this.emitLibrary();
  }

  private archiveJob(a: ArchiveRecord): ArchiveJob {
    const dir = path.dirname(a.path);
    return { id: a.id, path: a.path, name: a.name, parentDir: dir, parts: a.parts.map((p) => path.join(dir, p)), missingParts: a.missingParts, size: a.size };
  }

  private savedPasswords(): string[] {
    return this.db.listPasswords().flatMap((p) => {
      try {
        return [this.host.decrypt(p.blob)];
      } catch {
        return [];
      }
    });
  }

  private async runExtract(p: ExtractPayload, ctx: { progress: (x: any) => void; signal: AbortSignal }) {
    const a = this.db.archive(p.archiveId);
    if (!a || !this.root) return;
    const root = this.root;
    this.db.setArchive(a.id, { status: "extracting" });
    this.emitLibrary();
    const res = await extractArchive(this.archiveJob(a), {
      engines: this.engines,
      fs: this.fs,
      image: this.host.imaging,
      index: {
        register: async (dir) => {
          const c = await describeComic(root, dir);
          if (!c) return null;
          const id = this.db.upsertComic({ id: "c_" + randomUUID().replace(/-/g, "").slice(0, 12), ...c });
          await this.ensureThumb(id);
          this.db.bumpThumb(id);
          return { pageCount: c.pages, thumbOk: await this.thumbOk(id) };
        },
      },
      savedPasswords: this.savedPasswords(),
      password: p.password,
      collision: this.settings().collision,
      quarantineDir: path.join(root, ".comiclib", "quarantine"),
      parallelism: Math.max(1, Math.min(4, this.queue.workers)),
      signal: ctx.signal,
      onProgress: (x) => ctx.progress({ fraction: x.fraction, message: x.message, bytes: x.fraction * a.size, totalBytes: a.size }),
      onReduceParallelism: () => this.queue.setConcurrency(Math.max(1, Math.floor(this.queue.workers / 2))),
    });
    if (this.queue.workers < this.baseWorkers) this.queue.setConcurrency(this.baseWorkers);
    if (res.status === "cancelled") {
      this.db.setArchive(a.id, { status: ctx.signal.aborted ? "queued" : "pending" });
      this.emitLibrary();
      return;
    }
    const rels = res.comics.map((c) => path.relative(root, c.dir).split(path.sep).join("/"));
    const report = this.makeReport(a, res, rels);
    this.db.saveReport(report);
    const state = report.state;
    const target = res.finalDir ? path.basename(res.finalDir) : a.targetName;
    this.db.h.prepare("UPDATE archives SET target_name = ? WHERE id = ?").run(target, a.id);
    this.db.setArchive(a.id, { status: state, uncompressed: res.uncompressed, encrypted: !!res.passwordUsed || state === "needs_password", detail: res.reason ?? null });
    for (const r of rels) {
      const id = this.db.comicIdByRel(r);
      if (id) this.db.setVerification(id, report.status);
    }
    this.emitLibrary();
    if (res.nestedArchives.length) {
      await this.doScan(() => undefined, ctx.signal);
      const nested = this.db.allArchives().filter((x) => x.status === "pending" && rels.some((r) => x.relPath.startsWith(r + "/") || x.relPath.startsWith(path.basename(res.finalDir ?? "") + "/")));
      await this.enqueueExtract(nested.map((n) => n.id));
    }
    if (res.status === "failed" || res.status === "quarantined") throw new Error(res.reason ?? "Extraction failed");
  }

  private makeReport(a: ArchiveRecord, res: ExtractResult, rels: string[]): VerificationReport {
    const ok = res.status === "done" || res.status === "already_extracted";
    const state = (ok ? "done" : res.status === "cancelled" ? "queued" : res.status) as VerificationReport["state"];
    const status = ok ? summarizeLayers(res.layers) : ["needs_password", "needs_input", "no_images"].includes(res.status) ? "amber" : "red";
    return {
      id: a.id,
      subject: a.name,
      archiveRelPath: a.relPath,
      archiveSize: a.size,
      comicIds: rels.map((r) => this.db.comicIdByRel(r)).filter((x): x is string => !!x),
      outputRelPaths: rels,
      layers: res.layers,
      status,
      state,
      error: ok && status !== "red" ? undefined : res.reason,
      engineOutput: res.engineOutput?.slice(-4000),
      attempts: res.attempts,
      warnings: res.warnings,
      manual: false,
      uncompressed: res.uncompressed,
      extractedBytes: res.uncompressed,
      updatedAt: Date.now(),
    };
  }

  // ---- re-verification -----------------------------------------------------------------------------
  async reverify(ids: string[]) {
    for (const id of ids) this.queue.add("verify", `Verify ${id}`, { id }, { group: "verify" });
  }

  private async verifyFolder(dir: string): Promise<LayerResult[]> {
    const raw = await this.fs.readText(path.join(dir, MANIFEST_NAME)).catch(() => null);
    const manifest = raw ? (JSON.parse(raw) as Manifest) : null;
    const direct = (await this.fs.listFiles(dir)).filter((f) => !isJunkPath(f.rel) && path.posix.basename(f.rel) !== MANIFEST_NAME);
    const imgs = direct.filter((f) => isImageFile(f.rel));
    const L: LayerResult[] = Array.from({ length: 10 }, (_, i) => skipped(i + 1, "Not applicable"));
    L[0] = skipped(1, "Archive not re-tested");
    if (manifest) {
      L[1] = compareToManifest(manifest, direct.map((d) => ({ path: d.rel, size: d.size })), 2);
      const bad: string[] = [];
      await mapLimit(manifest.files, 4, async (f) => {
        const h: FileFacts | null = await this.fs.hashFile(path.join(dir, f.path)).catch(() => null);
        if (h && h.sha256 !== f.sha256) bad.push(`changed: ${f.path}`);
      });
      L[2] = bad.length ? layer(3, "fail", `${bad.length} file(s) changed since extraction`, bad) : layer(3, "pass", `${manifest.files.length} SHA-256 hashes match the manifest`);
      const count = direct.length;
      const bytes = direct.reduce((s, f) => s + f.size, 0);
      L[3] = count !== manifest.files.length || bytes !== manifest.totalBytes ? layer(4, "fail", "Totals differ from the manifest", [`${count} files, ${bytes} bytes; expected ${manifest.files.length}, ${manifest.totalBytes}`]) : layer(4, "pass", `${count} files, ${bytes} bytes match`);
      L[7] = layer(8, "pass", "Manifest present");
    } else {
      L[7] = layer(8, "warn", "No manifest found for this folder");
    }
    const decodes: DecodeResult[] = await mapLimit(imgs, 3, async (f) => {
      const r = await this.host.imaging.check(path.join(dir, f.rel));
      return { path: f.rel, ...r };
    });
    L[4] = decodeLayer(decodes);
    L[5] = pageSequenceLayer(imgs.map((i) => i.rel));
    L[6] = smallFilesLayer(direct.map((d) => ({ path: d.rel, size: d.size })));
    const row = this.db.h.prepare("SELECT id, pages FROM comics WHERE rel_path = ?").get(path.relative(this.root!, dir).split(path.sep).join("/")) as { id: string; pages: number } | undefined;
    L[9] = !row ? layer(10, "fail", "Folder is not in the library index") : row.pages !== imgs.length || !(await this.thumbOk(row.id)) ? layer(10, "fail", "Index or thumbnail out of date", [`indexed ${row.pages}, on disk ${imgs.length}`]) : layer(10, "pass", "Index and thumbnail are valid");
    return L;
  }

  private async runVerify(p: { id: string }, ctx: { progress: (x: any) => void }) {
    const root = this.root;
    if (!root) return;
    let report = this.db.report(p.id) ?? this.db.allReports().find((r) => r.comicIds.includes(p.id));
    let dirs: string[] = [];
    let subject = p.id;
    if (report) {
      dirs = report.outputRelPaths.map((r) => path.join(root, ...r.split("/")));
      subject = report.subject;
    } else {
      const c = this.db.comicById(p.id);
      if (!c) return;
      dirs = [c.path];
      subject = c.name;
    }
    const merged: LayerResult[][] = [];
    for (let i = 0; i < dirs.length; i++) {
      ctx.progress({ fraction: i / dirs.length, message: `Verifying ${subject}` });
      merged.push(await this.verifyFolder(dirs[i]));
    }
    const layers = merged.length ? merged[0].map((l, i) => merged.reduce((acc, m) => worst(acc, m[i]), l)) : [];
    if (report) layers[0] = report.layers[0] ?? layers[0];
    const base: VerificationReport = report ?? {
      id: p.id, subject, archiveRelPath: "", archiveSize: 0, comicIds: [p.id], outputRelPaths: dirs.map((d) => path.relative(root, d).split(path.sep).join("/")),
      layers: [], status: "green", state: "done", attempts: [], warnings: [], manual: false, uncompressed: 0, extractedBytes: 0, updatedAt: 0,
    };
    report = { ...base, layers, status: summarizeLayers(layers), state: "done", error: layers.filter((l) => l.status === "fail").map((l) => `${l.name}: ${l.summary}`).join("; ") || undefined, updatedAt: Date.now() };
    this.db.saveReport(report);
    for (const c of report.comicIds) this.db.setVerification(c, report.status);
    this.emitLibrary();
  }

  async skipArchive(id: string) {
    for (const j of this.queue.list()) if ((j.payload as ExtractPayload | undefined)?.archiveId === id) this.queue.cancel(j.id);
    this.db.setArchive(id, { status: "skipped" });
    this.emitLibrary();
  }
  async markManual(id: string, value: boolean) {
    const r = this.db.report(id);
    if (r) this.db.saveReport({ ...r, manual: value });
    this.emitLibrary();
  }
  async openFolder(t: { comicId?: string; archiveId?: string; path?: string }) {
    let p = t.path;
    if (t.comicId) p = this.comicDir(t.comicId) ?? undefined;
    if (t.archiveId) p = this.db.archive(t.archiveId)?.path;
    if (p) this.host.openPath(p);
  }

  // ---- move / create folder --------------------------------------------------------------------------
  async createFolder(parent: string, name: string): Promise<string> {
    if (!this.root) throw new Error("No mother folder selected");
    const safe = sanitizeSegment(name.trim());
    const rel = parent ? `${parent}/${safe}` : safe;
    await fsp.mkdir(path.join(this.root, ...rel.split("/")), { recursive: true });
    await this.doScanDirect();
    return rel;
  }
  private async doScanDirect() {
    await this.scan();
  }
  async moveComics(ids: string[], destFolder: string): Promise<MoveResult[]> {
    const root = this.root;
    if (!root) throw new Error("No mother folder selected");
    const destDir = path.join(root, ...destFolder.split("/").filter(Boolean));
    await fsp.mkdir(destDir, { recursive: true });
    const out: MoveResult[] = [];
    for (const id of ids) {
      try {
        const c = this.db.comicById(id);
        if (!c) throw new Error("Comic not found");
        if (path.resolve(path.dirname(c.path)) === path.resolve(destDir)) throw new Error("Already in this folder");
        if (path.resolve(destDir).startsWith(path.resolve(c.path) + path.sep)) throw new Error("Cannot move a folder into itself");
        const before = await this.fs.listFiles(c.path);
        const name = uniqueName(c.name, await fsp.readdir(destDir));
        const target = path.join(destDir, name);
        try {
          await fsp.rename(c.path, target);
        } catch {
          await fsp.cp(c.path, target, { recursive: true, errorOnExist: true });
          const copied = await this.fs.listFiles(target);
          if (copied.length !== before.length || copied.reduce((s, f) => s + f.size, 0) !== before.reduce((s, f) => s + f.size, 0)) throw new Error("Copy verification failed; original left in place");
          await fsp.rm(c.path, { recursive: true, force: true });
        }
        const after = await this.fs.listFiles(target);
        if (after.length !== before.length) throw new Error("Post-move file count differs");
        const d = await describeComic(root, target);
        if (d) this.db.upsertComic({ id, ...d }, id);
        out.push({ id, ok: true });
      } catch (e) {
        out.push({ id, ok: false, error: (e as Error).message });
      }
    }
    await this.scan();
    return out;
  }

  // ---- safe delete ---------------------------------------------------------------------------------------
  private async freshVerify(a: ArchiveRecord): Promise<string[]> {
    const errs: string[] = [];
    const r = this.db.report(a.id);
    if (!isGreen(r)) return ["Archive is not fully verified (green)"];
    for (const p of a.parts) if (!(await this.fs.exists(path.join(path.dirname(a.path), p)))) errs.push(`Archive part is missing: ${p}`);
    if (errs.length) return errs;
    const job = this.archiveJob(a);
    let list = await this.engines[0].list(job);
    if (!list.ok || list.entries.some((e) => e.encrypted)) {
      for (const pw of this.savedPasswords()) {
        const l = await this.engines[0].list(job, pw);
        if (l.ok) {
          list = l;
          break;
        }
      }
    }
    if (!list.ok) return [`Cannot read the archive: ${list.error ?? "unknown error"}`];
    const plan = planExtraction(a.name, list.entries);
    const out = path.join(path.dirname(a.path), a.targetName);
    if (!(await this.fs.exists(out))) return [`Extracted folder is missing: ${a.targetName}`];
    const actual = (await this.fs.listFiles(out)).filter((f) => !isJunkPath(f.rel));
    const have = new Map(actual.map((f) => [f.rel, f.size]));
    for (const f of plan.files) {
      const s = have.get(f.dest);
      if (s === undefined) errs.push(`missing: ${f.dest}`);
      else if (s !== f.size) errs.push(`size differs: ${f.dest}`);
    }
    const planned = new Set(plan.files.map((f) => f.dest));
    for (const f of actual) if (!planned.has(f.rel) && path.posix.basename(f.rel) !== MANIFEST_NAME) {
      /* files added later by the user or nested extraction are allowed */
    }
    if (errs.length) return errs.slice(0, 20);
    await mapLimit(plan.files, 4, async (f) => {
      if (f.crc === undefined) return;
      const h = await this.fs.hashFile(path.join(out, f.dest));
      if ((h.crc32 >>> 0) !== (f.crc >>> 0)) errs.push(`checksum differs: ${f.dest}`);
    });
    for (const rel of r!.outputRelPaths) {
      const dir = path.join(this.root!, ...rel.split("/"));
      const raw = await this.fs.readText(path.join(dir, MANIFEST_NAME)).catch(() => null);
      if (!raw) {
        errs.push(`manifest missing: ${rel}`);
        continue;
      }
      const m = JSON.parse(raw) as Manifest;
      const files = (await this.fs.listFiles(dir)).filter((f) => !isJunkPath(f.rel) && path.posix.basename(f.rel) !== MANIFEST_NAME);
      const cmp = compareToManifest(m, files.filter((f) => m.files.some((x) => x.path === f.rel)).map((f) => ({ path: f.rel, size: f.size })));
      if (cmp.status === "fail") errs.push(...cmp.details.filter((d) => !d.startsWith("unexpected")).map((d) => `${rel}: ${d}`));
    }
    return errs.slice(0, 20);
  }

  async previewDelete(ids: string[]): Promise<DeletePreview> {
    const out: DeletePreview = { ok: true, archives: [], totalBytes: 0, failures: [] };
    for (const id of ids) {
      const a = this.db.archive(id);
      if (!a) continue;
      const errs = await this.freshVerify(a);
      if (errs.length) out.failures.push({ id, name: a.name, reason: errs.join("; ") });
      else {
        const rep = this.db.report(id)!;
        out.archives.push({ id, name: a.name, size: a.size, folders: rep.outputRelPaths });
        out.totalBytes += a.size;
      }
    }
    out.ok = out.failures.length === 0 && out.archives.length > 0;
    return out;
  }

  async confirmDelete(ids: string[]) {
    const failures: { id: string; reason: string }[] = [];
    let moved = 0;
    for (const id of ids) {
      const a = this.db.archive(id);
      if (!a || !this.root) continue;
      const errs = await this.freshVerify(a);
      if (errs.length) {
        failures.push({ id, reason: errs.join("; ") });
        continue;
      }
      const tdir = path.join(this.root, ".comiclib", "trash", `${id}-${Date.now()}`);
      await fsp.mkdir(tdir, { recursive: true });
      const dir = path.dirname(a.path);
      for (const p of a.parts) await fsp.rename(path.join(dir, p), path.join(tdir, p));
      this.db.addTrash({ id, name: a.name, originalPath: a.path, trashPath: tdir, size: a.size, deletedAt: Date.now() });
      this.db.log("trash", a.path, `moved to ${tdir}`);
      this.db.setArchive(id, { status: "deleted" });
      moved++;
    }
    this.emitLibrary();
    return { ok: failures.length === 0, moved, failures };
  }
  async trashList(): Promise<TrashItem[]> {
    return this.db.trash().map(({ trashPath: _t, ...t }) => t);
  }
  async trashRestore(id: string) {
    const t = this.db.trash().find((x) => x.id === id);
    if (!t) return;
    const a = this.db.archive(id);
    const dir = path.dirname(t.originalPath);
    for (const p of (await fsp.readdir(t.trashPath))) {
      const dest = path.join(dir, p);
      if (await this.fs.exists(dest)) throw new Error(`Cannot restore: ${p} already exists`);
      await fsp.rename(path.join(t.trashPath, p), dest);
    }
    await fsp.rm(t.trashPath, { recursive: true, force: true });
    this.db.removeTrash(id);
    this.db.log("restore", t.originalPath);
    if (a) this.db.setArchive(id, { status: "done" });
    await this.scan();
  }
  async trashEmpty(): Promise<number> {
    let n = 0;
    for (const t of this.db.trash()) {
      await fsp.rm(t.trashPath, { recursive: true, force: true });
      this.db.removeTrash(t.id);
      this.db.h.prepare("DELETE FROM archives WHERE id = ? AND status = 'deleted'").run(t.id);
      this.db.log("empty-trash", t.originalPath, `${t.size} bytes`);
      n++;
    }
    this.emitLibrary();
    return n;
  }

  // ---- passwords ----------------------------------------------------------------------------------------------
  async listPasswords(): Promise<PasswordEntry[]> {
    return this.db.listPasswords().map((p) => ({ id: p.id, label: p.label }));
  }
  async addPassword(label: string, password: string) {
    this.db.addPassword("p_" + randomUUID().slice(0, 8), label || "Saved password", this.host.encrypt(password));
  }
  async removePassword(id: string) {
    this.db.removePassword(id);
  }
  async exportPasswords(): Promise<string[]> {
    return this.savedPasswords();
  }

  // ---- sizes and folder check -----------------------------------------------------------------------------------------
  async sizeReport(): Promise<SizeReport> {
    const root = this.root;
    if (!root) throw new Error("No mother folder selected");
    const files = await this.fs.listFiles(root);
    const rootBytes = files.filter((f) => !f.rel.startsWith(".")).reduce((s, f) => s + f.size, 0);
    const archives = this.db.allArchives().filter((a) => a.status !== "deleted");
    const comics = this.db.allComics();
    const per = new Map<string, { folder: string; bytes: number; archives: number; archiveBytes: number }>();
    const slot = (f: string) => per.get(f) ?? per.set(f, { folder: f, bytes: 0, archives: 0, archiveBytes: 0 }).get(f)!;
    for (const c of comics) slot(c.author || "(root)").bytes += c.size;
    for (const a of archives) {
      const s = slot(a.author || "(root)");
      s.archives++;
      s.archiveBytes += a.size;
    }
    const reports = this.db.allReports();
    const comparisons = archives.flatMap((a) => {
      const r = reports.find((x) => x.id === a.id);
      if (!r || !a.uncompressed) return [];
      const extracted = r.outputRelPaths.reduce((s, rel) => s + (comics.find((c) => c.relPath === rel)?.size ?? 0), 0);
      return [{ archive: a.name, uncompressed: a.uncompressed, extracted, ok: extracted <= a.uncompressed && extracted >= a.uncompressed * 0.98 }];
    });
    return {
      rootBytes,
      archiveBytes: archives.reduce((s, a) => s + a.size, 0),
      extractedBytes: comics.reduce((s, c) => s + c.size, 0),
      archiveUncompressed: archives.reduce((s, a) => s + (a.uncompressed ?? 0), 0),
      perFolder: [...per.values()].sort((a, b) => b.bytes + b.archiveBytes - (a.bytes + a.archiveBytes)),
      comparisons,
    };
  }

  async folderCheck(): Promise<FolderCheck> {
    const root = this.root;
    if (!root) throw new Error("No mother folder selected");
    const disk = await scanRoot(root, new Map());
    const lib = this.db.allComics();
    const libFolders = this.db.allFolders();
    const onDisk = new Set(disk.comics.map((c) => c.relPath));
    const inLib = new Set(lib.map((c) => c.relPath));
    const mismatches: FolderCheck["mismatches"] = [];
    for (const p of onDisk) if (!inLib.has(p)) mismatches.push({ path: p, reason: "On disk but not in the library" });
    for (const p of inLib) if (!onDisk.has(p)) mismatches.push({ path: p, reason: "In the library but missing on disk" });
    const dd = new Set(disk.dirs);
    for (const f of libFolders) if (!dd.has(f.path)) mismatches.push({ path: f.path, reason: "Folder in the library no longer exists on disk" });
    for (const p of dd) if (!libFolders.some((f) => f.path === p)) mismatches.push({ path: p, reason: "Folder on disk is not in the library" });
    return { diskFolders: disk.dirs.length, diskComics: disk.comics.length, libraryFolders: libFolders.length, libraryComics: lib.length, mismatches };
  }
  async fixFolders() {
    return this.scan();
  }

  // ---- metadata import ----------------------------------------------------------------------------------------------------
  async saveTextFile(name: string, text: string) {
    return this.host.saveText(name, text);
  }
  async pickTextFile() {
    return this.host.pickText();
  }
  async backupDb(): Promise<string> {
    const id = `backup-${new Date().toISOString().replace(/[:.]/g, "-")}.db`;
    this.db.backupTo(path.join(this.host.dataDir, "backups", id));
    return id;
  }
  async restoreBackup(id: string) {
    if (id.includes("/") || id.includes("\\")) throw new Error("Invalid backup id");
    this.db.restoreFrom(path.join(this.host.dataDir, "backups", id));
    this.emitLibrary();
  }
  async applyImport(apply: ImportApply): Promise<ImportReport> {
    const before = this.db.counts();
    const backupId = await this.backupDb();
    try {
      this.db.applyState(apply.comics, apply.tagDefs);
      if (apply.settings) await this.saveState({ settings: apply.settings });
      for (const pw of apply.passwords ?? []) await this.addPassword("Imported", pw);
    } catch (e) {
      await this.restoreBackup(backupId);
      throw new Error(`Import failed and was rolled back: ${(e as Error).message}`);
    }
    this.emitLibrary();
    const after = this.db.counts();
    return { before, after, backupId, applied: apply.comics.length };
  }

  // ---- health -------------------------------------------------------------------------------------------------------------------
  async runHealth(repair: boolean): Promise<HealthReport> {
    const log: string[] = [];
    const checks: HealthCheck[] = [];
    const add = (c: HealthCheck) => checks.push(c);
    const act = (m: string) => log.push(`${new Date().toISOString()}  ${m}`);

    const integ = this.db.integrity();
    let fts = this.db.ftsConsistency();
    if (repair && !fts.ok) {
      const n = this.db.ftsRebuild();
      act(`Rebuilt full-text index (${n} rows)`);
      fts = this.db.ftsConsistency();
    }
    add({ id: "db", title: "Database integrity", status: !integ.ok ? "red" : fts.ok ? "green" : "amber", summary: !integ.ok ? "Integrity check failed" : fts.ok ? `Healthy, schema v${this.db.version}` : `Search index out of sync (${fts.indexed} of ${fts.comics})`, details: [...integ.messages.slice(0, 5), `FTS rows ${fts.indexed}, comics ${fts.comics}`], repairable: !fts.ok });

    let fc: FolderCheck | null = null;
    if (this.root) {
      fc = await this.folderCheck();
      if (repair && fc.mismatches.length) {
        const s = await this.scan();
        act(`Rescanned library: ${s.added} added, ${s.removed} removed, ${s.moved} moved`);
        fc = await this.folderCheck();
      }
    }
    add({ id: "disk", title: "Library versus disk", status: !fc ? "amber" : fc.mismatches.length ? "amber" : "green", summary: !fc ? "No mother folder selected" : fc.mismatches.length ? `${fc.mismatches.length} mismatch(es)` : `${fc.diskComics} comics and ${fc.diskFolders} folders match`, details: fc?.mismatches.slice(0, 30).map((m) => `${m.path}: ${m.reason}`) ?? [], repairable: !!fc?.mismatches.length });

    const comics = this.db.allComics();
    const missing: ComicRecord[] = [];
    for (const c of comics) if (!(await this.thumbOk(c.id))) missing.push(c);
    if (repair && missing.length) {
      await mapLimit(missing, 3, (c) => this.ensureThumb(c.id));
      act(`Regenerated ${missing.length} thumbnail(s)`);
      this.host.emit("thumbs", {});
    }
    const still = repair ? (await mapLimit(missing, 4, (c) => this.thumbOk(c.id))).filter((x) => !x).length : missing.length;
    add({ id: "thumbs", title: "Thumbnails", status: still ? "amber" : "green", summary: still ? `${still} missing or corrupt` : "All thumbnails present", details: missing.slice(0, 20).map((c) => c.name), repairable: still > 0 });

    const sample = comics.filter((c) => c.verification).sort(() => Math.random() - 0.5).slice(0, repair ? 200 : 20);
    const bad: string[] = [];
    for (const c of sample) {
      const raw = await this.fs.readText(path.join(c.path, MANIFEST_NAME)).catch(() => null);
      if (!raw) continue;
      const files = (await this.fs.listFiles(c.path).catch(() => [])).filter((f) => path.posix.basename(f.rel) !== MANIFEST_NAME);
      const r = compareToManifest(JSON.parse(raw) as Manifest, files.map((f) => ({ path: f.rel, size: f.size })));
      if (r.status === "fail") bad.push(`${c.name}: ${r.details[0]}`);
    }
    add({ id: "manifests", title: "Extracted comics versus manifests", status: bad.length ? "red" : "green", summary: bad.length ? `${bad.length} comic(s) changed` : `${sample.length} sampled comics match their manifests`, details: bad, repairable: false });

    const tagRows = this.db.h.prepare("SELECT tag, COUNT(*) n FROM comic_tags GROUP BY tag").all() as { tag: string; n: number }[];
    const groups = new Map<string, string[]>();
    for (const t of this.db.allTags()) (groups.get(normalizeText(t.name)) ?? groups.set(normalizeText(t.name), []).get(normalizeText(t.name))!).push(t.name);
    const dupTags = [...groups.values()].filter((g) => g.length > 1);
    const orphanRows = (this.db.h.prepare("SELECT COUNT(*) n FROM comic_tags WHERE comic_id NOT IN (SELECT id FROM comics)").get() as { n: number }).n;
    if (repair) {
      if (orphanRows) (this.db.h.prepare("DELETE FROM comic_tags WHERE comic_id NOT IN (SELECT id FROM comics)").run(), act(`Removed ${orphanRows} orphaned tag link(s)`));
      for (const g of dupTags) {
        const [keep, ...rest] = g;
        for (const r of rest) {
          this.db.h.prepare("UPDATE OR IGNORE comic_tags SET tag = ? WHERE tag = ?").run(keep, r);
          this.db.h.prepare("DELETE FROM comic_tags WHERE tag = ?").run(r);
          this.db.h.prepare("DELETE FROM tags WHERE name = ?").run(r);
        }
        act(`Merged duplicate tags: ${g.join(", ")}`);
      }
    }
    const metaBad = repair ? 0 : orphanRows + dupTags.length;
    add({ id: "meta", title: "Metadata consistency", status: metaBad ? "amber" : "green", summary: metaBad ? `${orphanRows} orphaned link(s), ${dupTags.length} duplicate tag group(s)` : `${tagRows.length} tags consistent`, details: dupTags.map((g) => `Duplicate tags: ${g.join(", ")}`), repairable: metaBad > 0 });

    const fps = new Map<string, string[]>();
    for (const c of comics) if (c.fp) (fps.get(`${c.fp.pages}|${c.fp.sizes}|${c.fp.first}|${c.fp.last}`) ?? fps.set(`${c.fp.pages}|${c.fp.sizes}|${c.fp.first}|${c.fp.last}`, []).get(`${c.fp.pages}|${c.fp.sizes}|${c.fp.first}|${c.fp.last}`)!).push(c.relPath);
    const dups = [...fps.values()].filter((g) => g.length > 1);
    add({ id: "dups", title: "Duplicate comics", status: dups.length ? "amber" : "green", summary: dups.length ? `${dups.length} duplicate group(s)` : "No duplicates found", details: dups.slice(0, 20).map((g) => g.join("  =  ")), repairable: false });

    const free = await this.freeBytes();
    add({ id: "env", title: "Storage, permissions and service", status: free > 0 && free < 1 << 30 ? "amber" : "green", summary: `${(free / 1024 ** 3).toFixed(1)} GB free, file access granted, ${this.queue.isPaused ? "queue paused" : "queue running"}`, details: [`Workers: ${this.queue.workers}`], repairable: false });

    const report = { ranAt: Date.now(), checks, log: [...log, ...this.healthLog.slice(-20)] };
    if (repair) this.emitLibrary();
    return report;
  }

  async getPermissions() {
    return this.permissions();
  }
  async requestPermission() {
    return this.permissions();
  }
  async openSystemSettings() {
    /* nothing to configure on desktop */
  }
  async copyText(t: string) {
    this.host.copy(t);
  }
  async diagnostics(): Promise<string> {
    const c = this.db.counts();
    const free = await this.freeBytes();
    return [
      `Comic Library ${this.host.appVersion}`,
      `Platform: electron on ${os.platform()} ${os.release()} (${os.arch()}), ${os.cpus().length} CPUs`,
      `Node ${process.versions.node}, Electron ${process.versions.electron}`,
      `Mother folder: ${this.root ?? "(none)"}`,
      `Database: schema v${this.db.version}, ${c.comics} comics, ${c.tags} tags, ${c.favorites} favorites`,
      `Engines: ${this.host.engines.map((e) => `${e.id}=${e.bin}`).join(", ")}`,
      `Free space: ${(free / 1024 ** 3).toFixed(2)} GB`,
      `Jobs: ${this.queue.list().map((j) => `${j.kind}:${j.state}`).join(", ") || "none"}`,
    ].join("\n");
  }
  on(): () => void {
    return () => undefined;
  }
  async shutdown() {
    this.queue.pauseAll();
    await this.queue.flush().catch(() => undefined);
  }
}

interface ExtractPayload {
  archiveId: string;
  password?: string;
}

function buildFolders(dirs: string[], comics: { folder: string; size: number }[], archives: { folder: string }[]): FolderRecord[] {
  const map = new Map<string, FolderRecord>();
  const get = (p: string) => {
    let f = map.get(p);
    if (!f) {
      const i = p.lastIndexOf("/");
      f = { path: p, name: p.slice(i + 1), parent: i < 0 ? "" : p.slice(0, i), kind: i < 0 ? "author" : "folder", comics: 0, size: 0 };
      map.set(p, f);
    }
    return f;
  };
  for (const d of dirs) get(d);
  for (const a of archives) if (a.folder) get(a.folder);
  for (const c of comics) {
    let p = c.folder;
    while (p) {
      const f = get(p);
      f.comics++;
      f.size += c.size;
      const i = p.lastIndexOf("/");
      p = i < 0 ? "" : p.slice(0, i);
    }
  }
  return [...map.values()].sort((a, b) => a.path.localeCompare(b.path));
}

export type { ComicStatePatch, Counts, TagDef };
