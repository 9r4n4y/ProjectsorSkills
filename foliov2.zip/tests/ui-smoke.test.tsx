// @vitest-environment jsdom
// Mounts the real app against the demo backend and drives the main flows to catch runtime errors.
import { act } from "react";
import { createRoot } from "react-dom/client";
import { describe, expect, it, beforeAll } from "vitest";

(globalThis as any).IS_REACT_ACT_ENVIRONMENT = true;

beforeAll(() => {
  class RO { cb: any; constructor(cb: any) { this.cb = cb; } observe() { this.cb([]); } unobserve() {} disconnect() {} }
  (globalThis as any).ResizeObserver = RO;
  (globalThis as any).IntersectionObserver = class { observe() {} unobserve() {} disconnect() {} takeRecords() { return []; } };
  window.matchMedia = ((q: string) => ({ matches: q.includes("min-width") ? true : false, media: q, addEventListener() {}, removeEventListener() {}, addListener() {}, removeListener() {}, dispatchEvent: () => false, onchange: null })) as any;
  Object.defineProperty(HTMLElement.prototype, "clientWidth", { configurable: true, get: () => 1100 });
  Object.defineProperty(HTMLElement.prototype, "clientHeight", { configurable: true, get: () => 800 });
  Object.defineProperty(HTMLElement.prototype, "offsetHeight", { configurable: true, get: () => 800 });
  Element.prototype.scrollIntoView = () => {};
  Element.prototype.scrollBy = (() => {}) as any;
  (window as any).scrollTo = () => {};
});

const tick = (ms = 50) => act(async () => { await new Promise((r) => setTimeout(r, ms)); });
const click = (el: Element | null) => act(async () => { (el as HTMLElement)?.dispatchEvent(new MouseEvent("click", { bubbles: true })); });
const byText = (t: string, sel = "button") => [...document.querySelectorAll(sel)].find((e) => e.textContent?.includes(t)) ?? null;

describe("app smoke test (demo backend)", () => {
  it("boots, shows the grid, opens quick look, filters, navigates every screen, reads", async () => {
    const errors: string[] = [];
    const origErr = console.error;
    console.error = (...a: unknown[]) => { errors.push(a.map(String).join(" ").slice(0, 300)); };
    const App = (await import("../src/App")).default;
    const host = document.createElement("div");
    host.id = "root";
    document.body.appendChild(host);
    await act(async () => { createRoot(host).render(<App />); });
    await tick(600);

    expect(document.body.textContent).toContain("Comic Library");
    const cards = document.querySelectorAll("[data-comic-id]");
    expect(cards.length).toBeGreaterThan(4);
    // every card has the same two-line title box
    expect(new Set([...cards].map((c) => (c.querySelector(".clamp-2") as HTMLElement).style.height)).size).toBe(1);

    // text search
    const search = document.querySelector('input[aria-label="Search comics"]') as HTMLInputElement;
    await act(async () => {
      const set = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value")!.set!;
      set.call(search, "sister");
      search.dispatchEvent(new Event("input", { bubbles: true }));
    });
    await tick(100);
    expect(document.body.textContent).toMatch(/\d+ of 6\d\d comics/);
    await act(async () => {
      Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value")!.set!.call(search, "");
      search.dispatchEvent(new Event("input", { bubbles: true }));
    });

    // quick look opens in place and closes
    await click(document.querySelector("[data-comic-id]"));
    await tick(300);
    expect(document.querySelector('[role="dialog"]')).toBeTruthy();
    expect(document.body.textContent).toContain("Read");
    await act(async () => { document.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", bubbles: true })); });
    await tick(200);

    // tag panel include / exclude
    await click(document.querySelector('button[aria-label="Filter by tag"]'));
    await tick(200);
    await click(document.querySelector('button[aria-label="Include color"]'));
    await click(document.querySelector('button[aria-label="Exclude action"]'));
    await tick(100);
    expect(document.querySelector('button[aria-label="Remove color"]')).toBeTruthy();
    expect(document.querySelector('button[aria-label="Remove action"]')).toBeTruthy();
    await act(async () => { document.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", bubbles: true })); });
    await tick(200);
    await click(byText("Clear all"));

    // every screen renders
    const screens: [string, string][] = [["Extraction", "Extract all"], ["Verification", "Total archives"], ["Health", "Run checks"], ["Settings", "Mother folder"], ["Tags", "tags across"]];
    for (const [nav, expected] of screens) {
      await click(byText(nav, "aside button"));
      await tick(700);
      expect(document.body.textContent, nav).toContain(expected);
    }

    // simulated extraction runs through the real job queue
    await click(byText("Extraction", "aside button"));
    await tick(100);
    await click(byText("Extract all"));
    await tick(400);
    expect(document.body.textContent).toMatch(/Queue|Extracting|Waiting/);
    await tick(2500);

    // reader opens and closes
    await click(byText("All comics", "aside button"));
    await tick(100);
    await click(document.querySelector("[data-comic-id]"));
    await tick(200);
    await click(byText("Read"));
    await tick(400);
    expect(document.querySelector('[aria-label^="Reading"]')).toBeTruthy();
    expect(document.querySelector('input[aria-label="Page scrubber"]')).toBeTruthy();
    await act(async () => { window.dispatchEvent(new KeyboardEvent("keydown", { key: "ArrowRight" })); });
    await act(async () => { window.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape" })); });
    await tick(100);

    console.error = origErr;
    const real = errors.filter((e) => !/not wrapped in act|Missing `Description`|aria-describedby/.test(e));
    expect(real).toEqual([]);
  }, 30000);
});
