// Metadata export / import: versioned schema, checksum, dry-run matching, merge rules, passphrase encryption.

import type { ComicRecord, Fingerprint, Settings, TagDef } from "./types";
import { sha256Hex } from "./hash";
import { SearchIndex } from "./search";
import { normalizeText, similarity } from "./text";

export const METADATA_SCHEMA = "comiclib.metadata";
export const METADATA_VERSION = 1;

export interface MetaComic {
  relPath: string;
  name: string;
  folder: string;
  pages: number;
  favorite: boolean;
  read: boolean;
  lastPage: number;
  lastReadAt: number;
  tags: string[];
  fp?: Fingerprint;
}

export interface EncryptedBlob {
  alg: "AES-GCM/PBKDF2-SHA256";
  iter: number;
  salt: string;
  iv: string;
  data: string;
}

export interface MetadataData {
  comics: MetaComic[];
  tags: TagDef[];
  settings: Partial<Settings>;
  passwords?: EncryptedBlob;
}

export interface MetadataFile {
  schema: typeof METADATA_SCHEMA;
  version: number;
  createdAt: number;
  app: string;
  checksum: string;
  data: MetadataData;
}

/** Stable JSON with sorted keys, so the checksum does not depend on key order. */
export function canonicalJson(v: unknown): string {
  if (Array.isArray(v)) return `[${v.map(canonicalJson).join(",")}]`;
  if (v && typeof v === "object") {
    const o = v as Record<string, unknown>;
    return `{${Object.keys(o)
      .filter((k) => o[k] !== undefined)
      .sort()
      .map((k) => `${JSON.stringify(k)}:${canonicalJson(o[k])}`)
      .join(",")}}`;
  }
  return JSON.stringify(v) ?? "null";
}

export function toMetaComic(c: ComicRecord): MetaComic {
  return {
    relPath: c.relPath,
    name: c.name,
    folder: c.folder,
    pages: c.pages,
    favorite: c.favorite,
    read: c.read,
    lastPage: c.lastPage,
    lastReadAt: c.lastReadAt,
    tags: [...c.tags],
    fp: c.fp,
  };
}

export function buildMetadata(
  comics: readonly ComicRecord[],
  tags: readonly TagDef[],
  settings: Partial<Settings>,
  passwords?: EncryptedBlob,
  now = Date.now(),
): MetadataFile {
  const data: MetadataData = { comics: comics.map(toMetaComic), tags: [...tags], settings, ...(passwords ? { passwords } : {}) };
  return {
    schema: METADATA_SCHEMA,
    version: METADATA_VERSION,
    createdAt: now,
    app: "Comic Library",
    checksum: sha256Hex(canonicalJson(data)),
    data,
  };
}

export type ValidateResult =
  | { ok: true; file: MetadataFile }
  | { ok: false; stage: "parse" | "schema" | "version" | "checksum"; error: string };

/** Safety layers 1 and 2: schema and version validation, then content checksum. */
export function validateMetadata(text: string): ValidateResult {
  let j: any;
  try {
    j = JSON.parse(text);
  } catch (e) {
    return { ok: false, stage: "parse", error: `Not valid JSON: ${(e as Error).message}` };
  }
  if (!j || j.schema !== METADATA_SCHEMA) return { ok: false, stage: "schema", error: "This file is not a Comic Library metadata export" };
  if (typeof j.version !== "number" || j.version < 1) return { ok: false, stage: "version", error: "Missing schema version" };
  if (j.version > METADATA_VERSION) return { ok: false, stage: "version", error: `File version ${j.version} is newer than this app supports (${METADATA_VERSION})` };
  const d = j.data;
  if (!d || !Array.isArray(d.comics) || !Array.isArray(d.tags)) return { ok: false, stage: "schema", error: "Data section is missing comics or tags" };
  for (const c of d.comics) {
    if (typeof c.relPath !== "string" || typeof c.name !== "string" || !Array.isArray(c.tags)) {
      return { ok: false, stage: "schema", error: "A comic record has the wrong shape" };
    }
  }
  if (sha256Hex(canonicalJson(d)) !== j.checksum) {
    return { ok: false, stage: "checksum", error: "Checksum mismatch: the file was modified or damaged" };
  }
  return { ok: true, file: j as MetadataFile };
}

// ---- matching ---------------------------------------------------------------------------

export type MatchMethod = "path" | "fingerprint" | "name+pages" | "fuzzy";
export type MatchStatus = "matched" | "ambiguous" | "unmatched" | "conflict";

export interface MatchItem {
  index: number;
  record: MetaComic;
  status: MatchStatus;
  method?: MatchMethod;
  comicId?: string;
  candidates: string[];
  conflicts: string[];
}

const fpKey = (f: Fingerprint) => `${f.pages}|${f.sizes}|${f.first}|${f.last}`;
const lc = (s: string) => s.normalize("NFC").toLowerCase();

function push<K, V>(m: Map<K, V[]>, k: K, v: V) {
  const a = m.get(k);
  if (a) a.push(v);
  else m.set(k, [v]);
}

export function describeConflicts(c: ComicRecord, r: MetaComic): string[] {
  const out: string[] = [];
  const a = new Set(c.tags.map(normalizeText));
  const b = new Set(r.tags.map(normalizeText));
  if (a.size && b.size && (a.size !== b.size || [...a].some((x) => !b.has(x)))) out.push("tags differ");
  if (c.lastPage > 0 && r.lastPage > 0 && c.lastPage !== r.lastPage) out.push("reading position differs");
  if (c.favorite && !r.favorite) out.push("favorite differs");
  return out;
}

/**
 * Match exported records to comics on disk. Order: exact relative path, fingerprint,
 * normalized name plus page count, fuzzy name. A comic is claimed by at most one record.
 */
export function matchRecords(records: readonly MetaComic[], comics: readonly ComicRecord[]): MatchItem[] {
  const byPath = new Map(comics.map((c) => [lc(c.relPath), c]));
  const byFp = new Map<string, ComicRecord[]>();
  const byName = new Map<string, ComicRecord[]>();
  for (const c of comics) {
    if (c.fp) push(byFp, fpKey(c.fp), c);
    push(byName, `${normalizeText(c.name)}|${c.pages}`, c);
  }
  const claimed = new Set<string>();
  const items: MatchItem[] = records.map((record, index) => ({ index, record, status: "unmatched", candidates: [], conflicts: [] }));
  const accept = (it: MatchItem, c: ComicRecord, method: MatchMethod) => {
    claimed.add(c.id);
    it.comicId = c.id;
    it.method = method;
    it.candidates = [c.id];
    it.conflicts = describeConflicts(c, it.record);
    it.status = it.conflicts.length ? "conflict" : "matched";
  };

  for (const it of items) {
    const c = byPath.get(lc(it.record.relPath));
    if (c && !claimed.has(c.id)) accept(it, c, "path");
  }

  const resolveGroup = (it: MatchItem, group: ComicRecord[] | undefined, method: MatchMethod): boolean => {
    if (!group) return false;
    let cands = group.filter((c) => !claimed.has(c.id));
    if (!cands.length) return false;
    if (cands.length > 1) {
      const sameName = cands.filter((c) => normalizeText(c.name) === normalizeText(it.record.name));
      if (sameName.length) cands = sameName;
    }
    if (cands.length > 1) {
      const sameFolder = cands.filter((c) => lc(c.folder) === lc(it.record.folder));
      if (sameFolder.length) cands = sameFolder;
    }
    if (cands.length === 1) {
      accept(it, cands[0], method);
    } else {
      it.status = "ambiguous";
      it.method = method;
      it.candidates = cands.map((c) => c.id);
    }
    return true;
  };

  for (const it of items) if (it.status === "unmatched" && it.record.fp) resolveGroup(it, byFp.get(fpKey(it.record.fp)), "fingerprint");
  for (const it of items) if (it.status === "unmatched") resolveGroup(it, byName.get(`${normalizeText(it.record.name)}|${it.record.pages}`), "name+pages");

  const pending = items.filter((i) => i.status === "unmatched");
  if (pending.length) {
    const free = comics.filter((c) => !claimed.has(c.id));
    const idx = new SearchIndex();
    idx.build(free.map((c) => ({ id: c.id, name: c.name, folder: "", author: "", tags: [] })));
    const byId = new Map(free.map((c) => [c.id, c]));
    for (const it of pending) {
      const ranked = (idx.search(it.record.name) ?? []).slice(0, 8);
      const scored = ranked
        .map((id) => ({ c: byId.get(id)!, s: similarity(byId.get(id)!.name, it.record.name) }))
        .filter((x) => !claimed.has(x.c.id) && x.s >= 0.8)
        .sort((a, b) => b.s - a.s);
      if (!scored.length) continue;
      if (scored.length > 1 && scored[0].s - scored[1].s < 0.05) {
        it.status = "ambiguous";
        it.method = "fuzzy";
        it.candidates = scored.map((x) => x.c.id);
      } else accept(it, scored[0].c, "fuzzy");
    }
  }
  return items;
}

export function summarizeMatches(items: readonly MatchItem[]) {
  const s = { matched: 0, ambiguous: 0, unmatched: 0, conflict: 0, total: items.length };
  for (const i of items) s[i.status]++;
  return s;
}

/** Merge rule used when applying: union of tags, favorite or read if either side has it, newest progress wins. */
export function mergeUserState(c: ComicRecord, r: MetaComic) {
  const seen = new Set<string>();
  const tags: string[] = [];
  for (const t of [...c.tags, ...r.tags]) {
    const k = normalizeText(t);
    if (k && !seen.has(k)) {
      seen.add(k);
      tags.push(t);
    }
  }
  const useRecord = r.lastReadAt > c.lastReadAt;
  return {
    id: c.id,
    favorite: c.favorite || r.favorite,
    read: c.read || r.read,
    lastPage: useRecord ? r.lastPage : c.lastPage,
    lastReadAt: Math.max(c.lastReadAt, r.lastReadAt),
    tags,
  };
}

// ---- passphrase encryption (Web Crypto, available in Node 20, browsers and WebViews) -----

const b64 = (b: ArrayBuffer | Uint8Array) => {
  const u = b instanceof Uint8Array ? b : new Uint8Array(b);
  let s = "";
  for (let i = 0; i < u.length; i++) s += String.fromCharCode(u[i]);
  return btoa(s);
};
const unb64 = (s: string) => Uint8Array.from(atob(s), (c) => c.charCodeAt(0));

async function deriveKey(pass: string, salt: Uint8Array, iter: number): Promise<CryptoKey> {
  const base = await crypto.subtle.importKey("raw", new TextEncoder().encode(pass), "PBKDF2", false, ["deriveKey"]);
  return crypto.subtle.deriveKey({ name: "PBKDF2", salt: salt as BufferSource, iterations: iter, hash: "SHA-256" }, base, { name: "AES-GCM", length: 256 }, false, ["encrypt", "decrypt"]);
}

export async function encryptSecret(plain: string, pass: string, iter = 150_000): Promise<EncryptedBlob> {
  const salt = crypto.getRandomValues(new Uint8Array(16));
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const key = await deriveKey(pass, salt, iter);
  const data = await crypto.subtle.encrypt({ name: "AES-GCM", iv: iv as BufferSource }, key, new TextEncoder().encode(plain));
  return { alg: "AES-GCM/PBKDF2-SHA256", iter, salt: b64(salt), iv: b64(iv), data: b64(data) };
}

export async function decryptSecret(blob: EncryptedBlob, pass: string): Promise<string> {
  const key = await deriveKey(pass, unb64(blob.salt), blob.iter);
  const out = await crypto.subtle.decrypt({ name: "AES-GCM", iv: unb64(blob.iv) as BufferSource }, key, unb64(blob.data) as BufferSource);
  return new TextDecoder().decode(out);
}
