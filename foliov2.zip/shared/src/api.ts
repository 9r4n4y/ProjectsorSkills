// The contract between the shared UI and each platform (Electron main, Android plugin, browser demo).

import type {
  ComicRecord,
  DeletePreview,
  FolderCheck,
  HealthReport,
  LibrarySnapshot,
  PermissionStatus,
  Platform,
  ScanSummary,
  Settings,
  SizeReport,
  TagDef,
  TrashItem,
} from "./types";
import type { JobsState } from "./jobs";

export interface InitInfo {
  platform: Platform;
  appVersion: string;
  root: string | null;
  settings: Settings;
  permissions: PermissionStatus;
  env: { os: string; cpus: number; freeBytes: number };
  savedPasswordCount: number;
  /** Android: permissions screens still to show */
  needsOnboarding: boolean;
  demo: boolean;
}

export interface ComicStatePatch {
  id: string;
  favorite?: boolean;
  read?: boolean;
  lastPage?: number;
  lastReadAt?: number;
  tags?: string[];
}

export interface StatePatch {
  comics?: ComicStatePatch[];
  tagDefs?: TagDef[];
  deleteTags?: string[];
  settings?: Partial<Settings>;
}

export interface PageInfo {
  name: string;
  url: string;
  size: number;
}

export interface MoveResult {
  id: string;
  ok: boolean;
  error?: string;
}

export interface Counts {
  comics: number;
  tags: number;
  favorites: number;
  read: number;
}

export interface ImportApply {
  comics: ComicStatePatch[];
  tagDefs: TagDef[];
  settings?: Partial<Settings>;
  /** decrypted passwords to add to the saved list */
  passwords?: string[];
}

export interface ImportReport {
  before: Counts;
  after: Counts;
  backupId: string;
  applied: number;
}

export interface PasswordEntry {
  id: string;
  label: string;
}

export type PermissionKind = keyof PermissionStatus;
export type JobAction = "pause" | "resume" | "cancel" | "retry" | "clear";

export type ApiEvent = "jobs" | "library" | "thumbs";

export interface NativeApi {
  readonly platform: Platform;
  init(): Promise<InitInfo>;
  pickFolder(): Promise<string | null>;
  setRoot(path: string): Promise<void>;
  getLibrary(): Promise<LibrarySnapshot>;
  scan(): Promise<ScanSummary>;
  saveState(patch: StatePatch): Promise<void>;

  pages(comicId: string): Promise<PageInfo[]>;
  thumbUrl(comic: Pick<ComicRecord, "id" | "thumbRev">, size: "s" | "m"): string;
  ensureThumb(comicId: string): Promise<void>;
  /** Turn a page url into something an img element can show (identity except for SAF mode). */
  resolveImage(url: string): Promise<string>;

  getJobs(): Promise<JobsState>;
  extractAll(): Promise<void>;
  extractArchives(ids: string[], opts?: { password?: string; applyToSimilar?: boolean }): Promise<void>;
  reverify(ids: string[]): Promise<void>;
  jobControl(action: JobAction, id?: string): Promise<void>;
  skipArchive(id: string): Promise<void>;
  markManual(id: string, value: boolean): Promise<void>;
  openFolder(target: { comicId?: string; archiveId?: string; path?: string }): Promise<void>;

  moveComics(ids: string[], destFolder: string): Promise<MoveResult[]>;
  createFolder(parent: string, name: string): Promise<string>;

  previewDelete(archiveIds: string[]): Promise<DeletePreview>;
  confirmDelete(archiveIds: string[]): Promise<{ ok: boolean; moved: number; failures: { id: string; reason: string }[] }>;
  trashList(): Promise<TrashItem[]>;
  trashRestore(id: string): Promise<void>;
  trashEmpty(): Promise<number>;

  listPasswords(): Promise<PasswordEntry[]>;
  addPassword(label: string, password: string): Promise<void>;
  removePassword(id: string): Promise<void>;
  exportPasswords(): Promise<string[]>;

  sizeReport(): Promise<SizeReport>;
  folderCheck(): Promise<FolderCheck>;
  fixFolders(): Promise<ScanSummary>;

  saveTextFile(suggestedName: string, text: string): Promise<string | null>;
  pickTextFile(): Promise<string | null>;
  backupDb(): Promise<string>;
  restoreBackup(id: string): Promise<void>;
  applyImport(apply: ImportApply): Promise<ImportReport>;

  runHealth(repair: boolean): Promise<HealthReport>;
  getPermissions(): Promise<PermissionStatus>;
  /** Android only: match status/navigation bar colour and icon contrast to the app theme. No-op elsewhere. */
  setSystemBars(dark: boolean): Promise<void>;
  requestPermission(kind: keyof PermissionStatus): Promise<PermissionStatus>;
  openSystemSettings(kind: keyof PermissionStatus): Promise<void>;
  diagnostics(): Promise<string>;
  copyText(text: string): Promise<void>;

  on(event: ApiEvent, cb: (payload: any) => void): () => void;
}
