import { Menu } from "lucide-react";
import { useStore } from "@/lib/store";
import { useIsMobile } from "@/lib/hooks";
import { Button } from "@/components/ui/button";

export function PageShell({ title, description, actions, children }: { title: string; description?: string; actions?: React.ReactNode; children: React.ReactNode }) {
  const set = useStore((s) => s.set);
  const mobile = useIsMobile();
  return (
    <div className="flex h-full min-h-0 min-w-0 flex-col">
      {/* The header wraps instead of squeezing: the title keeps a readable minimum width and the actions drop to their own row on a phone. */}
      <header className="flex shrink-0 flex-wrap items-center gap-x-3 gap-y-2 border-b-[2.5px] border-ink bg-surface px-4 py-3 sm:px-6">
        <div className="flex min-w-0 flex-1 basis-44 items-center gap-2">
          {mobile && (
            <Button variant="ghost" size="icon" aria-label="Open folders and sections" onClick={() => set({ drawer: true })}>
              <Menu />
            </Button>
          )}
          <div className="min-w-0 flex-1">
            <h1 className="truncate font-display text-xl font-extrabold leading-7">{title}</h1>
            {description && <p className="truncate text-[13px] text-sub">{description}</p>}
          </div>
        </div>
        {actions && <div className="flex min-w-0 max-w-full flex-wrap items-center gap-x-2 gap-y-1 max-sm:w-full">{actions}</div>}
      </header>
      <div className="min-h-0 flex-1 overflow-y-auto overflow-x-hidden overscroll-contain">
        <div className="mx-auto flex min-w-0 max-w-5xl flex-col gap-6 px-4 py-6 sm:px-6">{children}</div>
      </div>
    </div>
  );
}

const TAGS = ["bg-butter", "bg-mint", "bg-lilac", "bg-peach"] as const;
const tagFor = (t: string) => TAGS[[...t].reduce((h, c) => (h * 31 + c.charCodeAt(0)) >>> 0, 7) % TAGS.length];

export function Card({ title, children, actions, className }: { title?: string; children: React.ReactNode; actions?: React.ReactNode; className?: string }) {
  return (
    <section className={`min-w-0 overflow-hidden rounded-[24px] border-[2.5px] border-ink bg-surface shadow-[0_5px_0_var(--ink)] ${className ?? ""}`}>
      {(title || actions) && (
        <div className="flex flex-wrap items-center justify-between gap-x-3 gap-y-2 px-4 pb-1 pt-4">
          {title && <h2 className={`max-w-full -rotate-1 rounded-[22px] border-[2.5px] border-ink px-3.5 pb-0.5 pt-px font-display text-[17px] font-extrabold leading-6 text-on ${tagFor(title)}`}>{title}</h2>}
          {actions}
        </div>
      )}
      <div className="min-w-0 p-4">{children}</div>
    </section>
  );
}

export function Stat({ label, value, tone }: { label: string; value: React.ReactNode; tone?: "ok" | "warn" | "bad" }) {
  const cls = tone === "ok" ? "text-ok" : tone === "warn" ? "text-warn" : tone === "bad" ? "text-bad" : "text-fg";
  return (
    <div className="flex flex-col gap-1 rounded-[20px] border-[2.5px] border-ink bg-surface px-4 py-3 shadow-[0_4px_0_var(--ink)]">
      <span className="text-xs text-sub">{label}</span>
      <span className={`font-display text-2xl font-extrabold tabular-nums ${cls}`}>{value}</span>
    </div>
  );
}
