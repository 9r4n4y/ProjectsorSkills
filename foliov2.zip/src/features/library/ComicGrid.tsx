import { useCallback, useEffect, useLayoutEffect, useRef, useState } from "react";
import { useVirtualizer } from "@tanstack/react-virtual";
import type { ComicRecord } from "@comiclib/shared";
import { useStore } from "@/lib/store";
import { ComicCard, TITLE_H } from "./ComicCard";
import { columnsFor } from "./gridColumns";

let scrollMemo = 0;

/**
 * Virtualized comic grid. Every row has the same height (2:3 cover + two title lines + gutter),
 * so 10,000+ comics scroll smoothly and columns stay perfectly aligned.
 */
export function ComicGrid({ items }: { items: ComicRecord[] }) {
  const ref = useRef<HTMLDivElement>(null);
  const [width, setWidth] = useState(0);
  const density = useStore((s) => s.settings.density);
  const selectMode = useStore((s) => s.selectMode);
  const selected = useStore((s) => s.selected);
  const highlightId = useStore((s) => s.highlightId);
  const { openQuick, toggleSelect, setSelectMode, setSelected } = useStore.getState();

  useLayoutEffect(() => {
    const el = ref.current!;
    const ro = new ResizeObserver(() => setWidth(el.clientWidth));
    ro.observe(el);
    setWidth(el.clientWidth);
    return () => ro.disconnect();
  }, []);

  const pad = width < 640 ? 16 : 24;
  const gap = width < 640 ? 12 : 16;
  const inner = Math.max(0, width - pad * 2);
  const cols = columnsFor(inner, gap, density);
  const cardW = (inner - gap * (cols - 1)) / cols;
  const rowH = Math.round(cardW * 1.5) + 8 + TITLE_H + gap;
  const rows = Math.ceil(items.length / cols);

  const v = useVirtualizer({
    count: rows,
    getScrollElement: () => ref.current,
    estimateSize: () => rowH,
    overscan: 3,
    paddingStart: pad,
    paddingEnd: pad,
  });
  useEffect(() => v.measure(), [rowH, v]);

  // restore the exact scroll position on mount and whenever the grid becomes visible again
  const visible = width > 0;
  useLayoutEffect(() => {
    if (visible && ref.current && scrollMemo) ref.current.scrollTop = scrollMemo;
  }, [visible]);

  const onOpen = useCallback((c: ComicRecord) => openQuick(c.id), [openQuick]);
  const onSelect = useCallback((c: ComicRecord) => toggleSelect(c.id), [toggleSelect]);
  const onLong = useCallback(
    (c: ComicRecord) => {
      setSelectMode(true);
      setSelected([c.id]);
      navigator.vibrate?.(10);
    },
    [setSelectMode, setSelected],
  );

  return (
    <div
      ref={ref}
      onScroll={(e) => (scrollMemo = e.currentTarget.scrollTop)}
      className="h-full overflow-y-auto overflow-x-hidden"
      style={{ contain: "strict" }}
      role="list"
      aria-label="Comics"
    >
      <div style={{ height: v.getTotalSize(), position: "relative", width: "100%" }}>
        {width > 0 &&
          v.getVirtualItems().map((vr) => {
            const start = vr.index * cols;
            const slice = items.slice(start, start + cols);
            return (
              <div
                key={vr.key}
                role="presentation"
                className="absolute left-0 top-0 grid w-full"
                style={{ transform: `translateY(${vr.start}px)`, height: vr.size, paddingInline: pad, columnGap: gap, gridTemplateColumns: `repeat(${cols}, minmax(0, 1fr))`, alignContent: "start" }}
              >
                {slice.map((c) => (
                  <div role="listitem" key={c.id} style={{ minWidth: 0 }}>
                    <ComicCard comic={c} selectMode={selectMode} selected={selected.has(c.id)} highlight={highlightId === c.id} onOpen={onOpen} onSelect={onSelect} onLongPress={onLong} />
                  </div>
                ))}
              </div>
            );
          })}
      </div>
    </div>
  );
}

export function GridSkeleton() {
  return (
    <div className="grid gap-4 p-6" style={{ gridTemplateColumns: "repeat(auto-fill, minmax(148px, 1fr))" }} aria-busy="true" aria-label="Loading comics">
      {Array.from({ length: 18 }, (_, i) => (
        <div key={i} className="flex flex-col gap-2">
          <div className="skeleton aspect-[2/3] rounded-md" />
          <div className="skeleton h-9 rounded-sm" />
        </div>
      ))}
    </div>
  );
}
