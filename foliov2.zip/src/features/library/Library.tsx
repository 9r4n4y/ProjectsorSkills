import { useState } from "react";
import { ArrowDownAZ, ArrowUpAZ, BookOpen, CheckSquare, FolderTree, FolderX, Heart, LayoutGrid, Menu, Minus, Plus, Search, SearchX, SlidersHorizontal, Tag, X, Folder as FolderIcon } from "lucide-react";
import { activeFilterCount, type SortKey } from "@comiclib/shared";
import { useStore } from "@/lib/store";
import { useIsMobile, useLibraryView } from "@/lib/hooks";
import { Button } from "@/components/ui/button";
import { Badge, EmptyState, Input, Popover, PopoverContent, PopoverTrigger } from "@/components/ui/controls";
import { cn } from "@/utils/cn";
import { ComicGrid, GridSkeleton } from "./ComicGrid";
import { BulkBar } from "./Dialogs";

const SORTS: { value: SortKey; label: string }[] = [
  { value: "name", label: "Name" },
  { value: "added", label: "Date added" },
  { value: "modified", label: "Date modified" },
  { value: "pages", label: "Page count" },
  { value: "lastRead", label: "Last read" },
];

function Chip({ children, onRemove, label, tone }: { children: React.ReactNode; onRemove: () => void; label: string; tone?: "in" | "ex" }) {
  return (
    <span className={cn("inline-flex h-8 max-w-[240px] items-center gap-1.5 rounded-full border-2 border-ink pl-3 pr-1 text-[13px] font-bold", tone === "ex" ? "bg-muted text-fg" : "bg-lilac text-on")}>
      {children}
      <button aria-label={`Remove ${label}`} onClick={onRemove} className="flex size-7 touch-manipulation items-center justify-center rounded-full hover:bg-black/10 active:bg-black/20">
        <X className="size-3.5" />
      </button>
    </span>
  );
}

export function Library() {
  const { results, relevance, ms } = useLibraryView();
  const f = useStore((s) => s.filters);
  const total = useStore((s) => s.comics.length);
  const set = useStore((s) => s.set);
  const setFilters = useStore((s) => s.setFilters);
  const clearFilters = useStore((s) => s.clearFilters);
  const settings = useStore((s) => s.settings);
  const setSettings = useStore((s) => s.setSettings);
  const selectMode = useStore((s) => s.selectMode);
  const setSelectMode = useStore((s) => s.setSelectMode);
  const scanning = useStore((s) => s.scanning);
  const rescan = useStore((s) => s.rescan);
  const setScreen = useStore((s) => s.setScreen);
  const archives = useStore((s) => s.archives);
  const mobile = useIsMobile();
  const [sortOpen, setSortOpen] = useState(false);
  const [denseOpen, setDenseOpen] = useState(false);
  const active = activeFilterCount(f);
  const pending = archives.filter((a) => a.status === "pending").length;

  const title = f.favoritesOnly ? "Favorites" : f.recentOnly ? "Recently read" : f.foldersIn.length === 1 ? f.foldersIn[0].split("/").join("  /  ") : "All comics";

  return (
    <div className="flex h-full min-h-0 flex-col">
      <div className="flex shrink-0 flex-col gap-3 border-b-[2.5px] border-ink bg-surface px-4 py-3 sm:px-6">
        <div className="flex flex-wrap items-center gap-x-2 gap-y-2">
          {mobile && (
            <Button variant="ghost" size="icon" aria-label="Open folders and sections" onClick={() => set({ drawer: true })}>
              <Menu />
            </Button>
          )}
          <h1 className="hidden min-w-0 shrink truncate font-display text-xl font-extrabold leading-7 sm:block sm:max-w-[240px]" title={title}>{title}</h1>
          <div className="relative min-w-0 flex-1 basis-40 sm:max-w-xl">
            <Search className="pointer-events-none absolute left-3.5 top-1/2 size-4 -translate-y-1/2 text-sub" />
            <Input value={f.query} onChange={(e) => setFilters({ query: e.target.value })} placeholder="Search name, folder, author or tag" aria-label="Search comics" className="pl-10 pr-10" />
            {f.query && (
              <button aria-label="Clear search" onClick={() => setFilters({ query: "" })} className="absolute right-1 top-1/2 flex size-8 -translate-y-1/2 items-center justify-center rounded-sm text-sub hover:text-fg">
                <X className="size-4" />
              </button>
            )}
          </div>
          <div className="flex items-center gap-1.5 max-sm:w-full max-sm:justify-between sm:ml-auto">
            <Button variant="outline" size="icon" aria-label="Filter by tag" title="Filter by tag" onClick={() => set({ panel: "tags" })} className="relative">
              <Tag />
              {f.tagsIn.length + f.tagsEx.length > 0 && <span className="absolute -right-1 -top-1 flex size-5 items-center justify-center rounded-full border-2 border-ink bg-peach text-[10px] font-bold text-on">{f.tagsIn.length + f.tagsEx.length}</span>}
            </Button>
            <Button variant="outline" size="icon" aria-label="Filter by folder" title="Filter by folder" onClick={() => set({ panel: "folders" })} className="relative">
              <FolderTree />
              {f.foldersIn.length + f.foldersEx.length > 0 && <span className="absolute -right-1 -top-1 flex size-5 items-center justify-center rounded-full border-2 border-ink bg-peach text-[10px] font-bold text-on">{f.foldersIn.length + f.foldersEx.length}</span>}
            </Button>
            <Popover open={sortOpen} onOpenChange={setSortOpen}>
              <PopoverTrigger asChild>
                <Button variant="outline" size="icon" aria-label="Sort" title="Sort">
                  <SlidersHorizontal />
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-56">
                {SORTS.map((s) => (
                  <button key={s.value} onClick={() => { setSettings({ sort: s.value }); setSortOpen(false); }} className={cn("flex h-9 w-full touch-manipulation items-center justify-between rounded-full px-3 text-sm font-bold hover:bg-muted active:bg-line pointer-coarse:h-11", settings.sort === s.value && "bg-lilac text-on")}>
                    {s.label}
                    {settings.sort === s.value && <span className="size-2 rounded-full border-2 border-ink bg-butter" />}
                  </button>
                ))}
                <div className="my-1 h-px bg-line" />
                <button onClick={() => setSettings({ sortDir: settings.sortDir === "asc" ? "desc" : "asc" })} className="flex h-9 w-full touch-manipulation items-center gap-2 rounded-full px-3 text-sm font-bold hover:bg-muted active:bg-line pointer-coarse:h-11">
                  {settings.sortDir === "asc" ? <ArrowDownAZ className="size-4" /> : <ArrowUpAZ className="size-4" />}
                  {settings.sortDir === "asc" ? "Ascending" : "Descending"}
                </button>
              </PopoverContent>
            </Popover>
            <Popover open={denseOpen} onOpenChange={setDenseOpen}>
              <PopoverTrigger asChild>
                <Button variant="outline" size="icon" aria-label="Grid density" title="Grid density">
                  <LayoutGrid />
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-64 p-4">
                <div className="mb-2 flex items-center justify-between text-[13px] font-bold">
                  <label htmlFor="density">Grid size</label>
                  <span className="rounded-full border-2 border-ink bg-butter px-2.5 text-on">{["Largest", "Large", "Medium", "Small", "Smallest"][settings.density - 1]}</span>
                </div>
                <input id="density" type="range" min={1} max={5} step={1} value={settings.density} onChange={(e) => setSettings({ density: +e.target.value })} aria-valuetext={["Largest", "Large", "Medium", "Small", "Smallest"][settings.density - 1]} className="mochi-range w-full" style={{ ["--p" as string]: (settings.density - 1) / 4 }} />
                <div className="mt-1 flex justify-between text-xs text-sub"><span>Big covers</span><span>Many per row</span></div>
              </PopoverContent>
            </Popover>
            <Button variant={selectMode ? "default" : "outline"} size="icon" aria-label="Select mode" aria-pressed={selectMode} title="Select" onClick={() => setSelectMode(!selectMode)}>
              <CheckSquare />
            </Button>
          </div>
        </div>

        {active > 0 && (
          <div className="flex flex-wrap items-center gap-2" aria-label="Active filters">
            {f.favoritesOnly && <Chip label="favorites" onRemove={() => setFilters({ favoritesOnly: false })}><Heart className="size-3.5" />Favorites</Chip>}
            {f.recentOnly && <Chip label="recently read" onRemove={() => setFilters({ recentOnly: false })}>Recently read</Chip>}
            {f.tagsIn.map((t) => <Chip key={"i" + t} label={t} onRemove={() => setFilters({ tagsIn: f.tagsIn.filter((x) => x !== t) })}><Plus className="size-3.5" /><span className="truncate">{t}</span></Chip>)}
            {f.tagsEx.map((t) => <Chip key={"e" + t} tone="ex" label={t} onRemove={() => setFilters({ tagsEx: f.tagsEx.filter((x) => x !== t) })}><Minus className="size-3.5" /><span className="truncate">{t}</span></Chip>)}
            {f.foldersIn.map((t) => <Chip key={"fi" + t} label={t} onRemove={() => setFilters({ foldersIn: f.foldersIn.filter((x) => x !== t) })}><FolderIcon className="size-3.5" /><span className="truncate">{t}</span></Chip>)}
            {f.foldersEx.map((t) => <Chip key={"fe" + t} tone="ex" label={t} onRemove={() => setFilters({ foldersEx: f.foldersEx.filter((x) => x !== t) })}><FolderX className="size-3.5" /><span className="truncate">{t}</span></Chip>)}
            {f.tagsIn.length > 1 && <Badge tone="accent">{f.tagMode === "and" ? "All tags" : "Any tag"}</Badge>}
          </div>
        )}
        <div className="flex items-center justify-between gap-3 text-[13px] text-sub" aria-live="polite">
          <span>
            <span className="font-medium tabular-nums text-fg">{results.length.toLocaleString()}</span> {results.length === total ? "comics" : `of ${total.toLocaleString()} comics`}
            {relevance ? " · sorted by relevance" : ""}
            <span className="sr-only"> found in {Math.round(ms)} milliseconds</span>
          </span>
          {active > 0 && <Button variant="ghost" size="sm" onClick={clearFilters}><X />Clear all</Button>}
        </div>
      </div>

      <div className="relative min-h-0 flex-1">
        {scanning && total === 0 ? (
          <GridSkeleton />
        ) : total === 0 ? (
          <EmptyState icon={BookOpen} title="No comics found yet" text="Folders that directly contain page images appear here. If your library holds archives, extract them first.">
            <div className="flex gap-2">
              <Button onClick={() => void rescan()} disabled={scanning}>Scan folder</Button>
              {pending > 0 && <Button variant="outline" onClick={() => setScreen("extract")}>Extract {pending} archives</Button>}
            </div>
          </EmptyState>
        ) : results.length === 0 ? (
          <EmptyState icon={SearchX} title="No comics match" text="Try fewer words, check the spelling, or remove a tag or folder filter.">
            <Button variant="outline" onClick={clearFilters}>Clear all filters</Button>
          </EmptyState>
        ) : (
          <ComicGrid items={results} />
        )}
      </div>
      {selectMode && <BulkBar items={results} />}
    </div>
  );
}
