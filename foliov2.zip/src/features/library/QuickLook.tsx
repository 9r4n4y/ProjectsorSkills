import { useEffect, useState } from "react";
import { BookOpen, FolderInput, FolderOpen, Heart, Tag } from "lucide-react";
import { type PageInfo, formatBytes } from "@comiclib/shared";
import { api } from "@/lib/backend";
import { useStore } from "@/lib/store";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge, TriIcon } from "@/components/ui/controls";
import { PageImage } from "@/features/reader/PageImage";
import { MoveDialog, TagEditor } from "./Dialogs";

/** In-place modal over the grid: no navigation, so scroll position, filters and selection are untouched. */
export function QuickLook() {
  const id = useStore((s) => s.quickId);
  const comic = useStore((s) => s.comics.find((c) => c.id === id));
  const close = useStore((s) => s.closeQuick);
  const openReader = useStore((s) => s.openReader);
  const toggleFavorite = useStore((s) => s.toggleFavorite);
  const openInfo = useStore((s) => s.info);
  const [pages, setPages] = useState<PageInfo[] | null>(null);
  const [tags, setTags] = useState(false);
  const [move, setMove] = useState(false);
  const open = !!id && !!comic;

  useEffect(() => {
    setPages(null);
    if (!id) return;
    let live = true;
    void api.pages(id).then((p) => live && setPages(p));
    return () => {
      live = false;
    };
  }, [id]);

  if (!comic) return null;
  const read = () => {
    const rid = comic.id;
    close();
    setTimeout(() => openReader(rid), 0);
  };
  const resume = comic.lastPage > 0 && comic.lastPage < comic.pages - 1;
  return (
    <>
      <Dialog open={open} onOpenChange={(o) => !o && close()}>
        <DialogContent title={comic.name} size="lg" onCloseAutoFocus={(e) => e.preventDefault()} className="sm:h-[min(760px,88dvh)]">
          <div className="flex min-h-0 flex-1 flex-col overflow-y-auto sm:flex-row sm:overflow-hidden">
            <aside className="flex shrink-0 flex-col gap-4 border-b border-line p-5 sm:w-72 sm:overflow-y-auto sm:border-b-0 sm:border-r">
              <dl className="grid grid-cols-[84px_1fr] gap-x-3 gap-y-2 text-[13px]">
                <dt className="text-sub">Name</dt><dd className="break-words" title={comic.name}>{comic.name}</dd>
                <dt className="text-sub">Folder</dt><dd className="break-words">{comic.folder || "Mother folder"}</dd>
                {comic.author && <><dt className="text-sub">Author</dt><dd>{comic.author}</dd></>}
                <dt className="text-sub">Pages</dt><dd className="tabular-nums">{comic.pages}</dd>
                <dt className="text-sub">Size</dt><dd className="tabular-nums">{formatBytes(comic.size)}</dd>
                <dt className="text-sub">Progress</dt><dd>{comic.read ? "Read" : comic.lastPage > 0 ? `Page ${comic.lastPage + 1} of ${comic.pages}` : "Not started"}</dd>
                {comic.verification && <><dt className="text-sub">Verified</dt><dd className="flex items-center gap-1.5"><TriIcon tri={comic.verification} />{comic.verification === "green" ? "All checks passed" : comic.verification === "amber" ? "Warnings" : "Failed"}</dd></>}
              </dl>
              <div>
                <div className="mb-2 text-[13px] text-sub">Tags</div>
                <div className="flex flex-wrap gap-1.5">
                  {comic.tags.length ? comic.tags.map((t) => <Badge key={t}>{t}</Badge>) : <span className="text-[13px] text-sub">No tags</span>}
                </div>
              </div>
              <div className="flex flex-col gap-2">
                <Button size="lg" onClick={read}><BookOpen />{resume ? `Resume at page ${comic.lastPage + 1}` : "Read"}</Button>
                <div className="grid grid-cols-3 gap-2">
                  <Button variant={comic.favorite ? "default" : "outline"} aria-pressed={comic.favorite} aria-label="Toggle favorite" onClick={() => toggleFavorite([comic.id])}><Heart className={comic.favorite ? "fill-current" : ""} /></Button>
                  <Button variant="outline" aria-label="Edit tags" onClick={() => setTags(true)}><Tag /></Button>
                  <Button variant="outline" aria-label="Move comic" onClick={() => setMove(true)}><FolderInput /></Button>
                </div>
                {openInfo?.platform === "electron" && <Button variant="ghost" onClick={() => void api.openFolder({ comicId: comic.id })}><FolderOpen />Open folder</Button>}
              </div>
            </aside>
            <section className="min-h-[320px] flex-1 p-4 sm:overflow-y-auto" aria-label="Pages">
              <div className="grid grid-cols-3 gap-3 sm:grid-cols-4">
                {pages === null
                  ? Array.from({ length: 12 }, (_, i) => <div key={i} className="skeleton aspect-[2/3] rounded-md" />)
                  : pages.map((p, i) => (
                      <button key={p.name} title={p.name} onClick={() => { const rid = comic.id; close(); setTimeout(() => openReader(rid, i), 0); }} className="group relative aspect-[2/3] overflow-hidden rounded-md border border-line bg-muted">
                        <PageImage url={p.url} className="size-full object-cover" lazy />
                        <span className="absolute bottom-1 right-1 rounded-sm bg-black/60 px-1.5 text-[11px] tabular-nums text-white">{i + 1}</span>
                      </button>
                    ))}
              </div>
            </section>
          </div>
        </DialogContent>
      </Dialog>
      {tags && <TagEditor ids={[comic.id]} onClose={() => setTags(false)} />}
      {move && <MoveDialog ids={[comic.id]} onClose={() => setMove(false)} />}
    </>
  );
}
