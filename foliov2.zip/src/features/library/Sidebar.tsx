import { useMemo, useState } from "react";
import { Activity, BookOpen, ChevronRight, Clock, Download, FolderOpen, Heart, Library, Settings, ShieldCheck, Tag } from "lucide-react";
import { countFolders } from "@comiclib/shared";
import { type Screen, useStore } from "@/lib/store";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { cn } from "@/utils/cn";

export function NavButton({ icon: Icon, label, active, onClick, badge }: { icon: React.ElementType; label: string; active?: boolean; onClick: () => void; badge?: number }) {
  return (
    <button
      onClick={onClick}
      aria-current={active ? "page" : undefined}
      className={cn("flex h-9 w-full items-center gap-3 rounded-full border-2 px-3.5 text-sm font-bold transition-[background-color,transform] duration-300 ease-spring active:brightness-90 touch-manipulation pointer-coarse:h-11", active ? "border-ink bg-lilac text-on shadow-[0_3px_0_var(--ink)]" : "border-transparent text-fg hover:bg-muted")}
    >
      <Icon className="size-4 shrink-0" />
      <span className="min-w-0 flex-1 truncate text-left">{label}</span>
      {badge ? <span className={cn("rounded-full px-2 text-xs font-bold tabular-nums", active ? "bg-surface/70 text-on" : "bg-muted text-sub")}>{badge}</span> : null}
    </button>
  );
}

export function SidebarContent() {
  const screen = useStore((s) => s.screen);
  const setScreen = useStore((s) => s.setScreen);
  const filters = useStore((s) => s.filters);
  const setFilters = useStore((s) => s.setFilters);
  const clearFilters = useStore((s) => s.clearFilters);
  const comics = useStore((s) => s.comics);
  const folders = useStore((s) => s.folders);
  const archives = useStore((s) => s.archives);
  const reports = useStore((s) => s.reports);
  const [open, setOpen] = useState<Set<string>>(new Set());
  const counts = useMemo(() => countFolders(comics), [comics]);
  const pending = archives.filter((a) => a.status === "pending" || a.status === "queued" || a.status === "extracting").length;
  const issues = reports.filter((r) => r.status !== "green" && !r.manual).length;
  const go = (s: Screen) => setScreen(s);
  const nav = (patch: Parameters<typeof setFilters>[0]) => {
    clearFilters();
    setFilters(patch);
    setScreen("library");
  };
  const noFilter = !filters.favoritesOnly && !filters.recentOnly && !filters.foldersIn.length;
  const children = (p: string) => folders.filter((f) => f.parent === p);

  const renderFolder = (path: string, depth: number): React.ReactNode =>
    children(path).map((f) => {
      const kids = children(f.path).length > 0;
      const isOpen = open.has(f.path);
      const sel = screen === "library" && filters.foldersIn.length === 1 && filters.foldersIn[0] === f.path;
      return (
        <li key={f.path}>
          <div className="flex items-center" style={{ paddingLeft: depth * 12 }}>
            <button aria-label={isOpen ? "Collapse" : "Expand"} disabled={!kids} onClick={() => setOpen((o) => { const n = new Set(o); n.has(f.path) ? n.delete(f.path) : n.add(f.path); return n; })} className="flex size-8 shrink-0 items-center justify-center text-sub disabled:opacity-0 pointer-coarse:size-10">
              <ChevronRight className={cn("size-4 transition-transform duration-150", isOpen && "rotate-90")} />
            </button>
            <button onClick={() => nav({ foldersIn: [f.path] })} aria-current={sel ? "page" : undefined} title={f.path} className={cn("flex h-8 min-w-0 flex-1 items-center gap-2 rounded-full pr-3 text-left text-[13px] pointer-coarse:h-10", sel ? "bg-lilac pl-2 font-bold text-on" : "pl-2 hover:bg-muted")}>
              <span className="min-w-0 flex-1 truncate">{f.name}</span>
              <span className="text-xs tabular-nums text-sub">{counts.get(f.path) ?? 0}</span>
            </button>
          </div>
          {kids && isOpen && <ul>{renderFolder(f.path, depth + 1)}</ul>}
        </li>
      );
    });

  return (
    <div className="flex h-full min-h-0 flex-col">
      <div className="flex items-center gap-2.5 px-4 py-4">
        <div className="flex size-9 -rotate-6 items-center justify-center rounded-[12px] border-[2.5px] border-ink bg-butter text-on shadow-[0_3px_0_var(--ink)]"><BookOpen className="size-[18px]" /></div>
        <span className="font-display text-xl font-extrabold leading-6">Comic Library</span>
      </div>
      <nav className="flex min-h-0 flex-1 flex-col gap-4 overflow-y-auto px-2 pb-2" aria-label="Main">
        <div className="flex flex-col gap-0.5">
          <NavButton icon={Library} label="All comics" active={screen === "library" && noFilter} onClick={() => nav({})} badge={comics.length} />
          <NavButton icon={Heart} label="Favorites" active={screen === "library" && filters.favoritesOnly} onClick={() => nav({ favoritesOnly: true })} badge={comics.filter((c) => c.favorite).length} />
          <NavButton icon={Clock} label="Recently read" active={screen === "library" && filters.recentOnly} onClick={() => nav({ recentOnly: true })} />
          <NavButton icon={Tag} label="Tags" active={screen === "tags"} onClick={() => go("tags")} />
        </div>
        <div>
          <div className="mb-1 flex items-center gap-2 px-3 font-display text-sm font-extrabold text-sub"><FolderOpen className="size-3.5" />Folders</div>
          <ul>{renderFolder("", 0)}</ul>
          {folders.length === 0 && <p className="px-3 py-2 text-[13px] text-sub">No folders yet.</p>}
        </div>
      </nav>
      <div className="flex flex-col gap-0.5 border-t border-line p-2">
        <NavButton icon={Download} label="Extraction" active={screen === "extract"} onClick={() => go("extract")} badge={pending} />
        <NavButton icon={ShieldCheck} label="Verification" active={screen === "verify"} onClick={() => go("verify")} badge={issues} />
        <NavButton icon={Activity} label="Health" active={screen === "health"} onClick={() => go("health")} />
        <NavButton icon={Settings} label="Settings" active={screen === "settings"} onClick={() => go("settings")} />
      </div>
    </div>
  );
}

export function SidebarDrawer() {
  const drawer = useStore((s) => s.drawer);
  const set = useStore((s) => s.set);
  return (
    <Dialog open={drawer} onOpenChange={(o) => set({ drawer: o })}>
      <DialogContent title="Library" hideTitle panel className="sm:left-0 sm:right-auto sm:border-l-0 sm:border-r">
        <SidebarContent />
      </DialogContent>
    </Dialog>
  );
}
