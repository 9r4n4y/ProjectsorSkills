import { useCallback, useEffect, useRef, useState } from "react";
import { ArrowLeftRight, ChevronLeft, ChevronRight, Expand, MoveVertical, Rows3, Shrink, Timer, X, MousePointerClick } from "lucide-react";
import type { FitMode, PageInfo, ReaderMode } from "@comiclib/shared";
import { api } from "@/lib/backend";
import { useStore } from "@/lib/store";
import { useBackClose } from "@/lib/hooks";
import { Button } from "@/components/ui/button";
import { cn } from "@/utils/cn";
import { PageImage } from "./PageImage";

const MODES: { value: ReaderMode; label: string; icon: React.ElementType }[] = [
  { value: "scroll", label: "Scroll", icon: Rows3 },
  { value: "paged", label: "Tap pages", icon: MousePointerClick },
  { value: "auto", label: "Auto", icon: Timer },
];
const MODE_HINT: Record<ReaderMode, string> = {
  scroll: "Continuous vertical scroll",
  paged: "Tap the left or right edge to turn the page",
  auto: "Turns the page by itself; touch to pause",
};
const SECONDS = [3, 5, 8, 12, 20, 30, 60];

export function Reader() {
  const reader = useStore((s) => s.reader);
  if (!reader) return null;
  return <ReaderInner key={reader.id} />;
}

function ReaderInner() {
  const reader = useStore((s) => s.reader)!;
  const comic = useStore((s) => s.comics.find((c) => c.id === reader.id));
  const settings = useStore((s) => s.settings);
  const setSettings = useStore((s) => s.setSettings);
  const close = useStore((s) => s.closeReader);
  const recordProgress = useStore((s) => s.recordProgress);
  const [pages, setPages] = useState<PageInfo[] | null>(null);
  const [index, setIndex] = useState(reader.page);
  const [controls, setControls] = useState(true);
  const [zoom, setZoom] = useState({ s: 1, x: 0, y: 0 });
  const [held, setHeld] = useState(false);
  const [remain, setRemain] = useState(1);
  const [full, setFull] = useState(false);
  const hideTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const mode = settings.readerMode;
  const fit = settings.fit;
  const n = pages?.length ?? comic?.pages ?? 0;
  useBackClose(true, close);
  // scrubber: while dragging, `scrub` is shown instead of `index`; the page is committed on release (paged/auto) and the
  // scroll position follows live (scroll). `scrubbing` stops the scroll tracker from fighting the finger.
  const [scrub, setScrub] = useState<number | null>(null);
  const dragging = useRef(false);
  const scrubbing = useRef(false);

  useEffect(() => {
    let live = true;
    void api.pages(reader.id).then((p) => live && setPages(p));
    return () => {
      live = false;
    };
  }, [reader.id]);

  const go = useCallback(
    (i: number) => {
      setIndex((cur) => {
        const t = Math.max(0, Math.min(n - 1, i));
        if (t !== cur) setZoom({ s: 1, x: 0, y: 0 });
        return t;
      });
    },
    [n],
  );

  // remember the page (debounced) and mark the comic as read at the end
  useEffect(() => {
    if (!pages) return;
    const t = setTimeout(() => recordProgress(reader.id, index, pages.length), 500);
    return () => clearTimeout(t);
  }, [index, pages, reader.id, recordProgress]);

  // preload upcoming pages
  useEffect(() => {
    if (!pages || mode === "scroll") return;
    for (let i = index + 1; i <= index + 3 && i < pages.length; i++) {
      void api.resolveImage(pages[i].url).then((u) => (new Image().src = u));
    }
  }, [index, pages, mode]);

  // controls auto-hide
  const poke = useCallback(() => {
    setControls(true);
    if (hideTimer.current) clearTimeout(hideTimer.current);
    hideTimer.current = setTimeout(() => setControls(false), 2800);
  }, []);
  useEffect(() => {
    poke();
    return () => {
      if (hideTimer.current) clearTimeout(hideTimer.current);
    };
  }, [poke]);

  // auto-next timer with visible countdown, paused while touching
  useEffect(() => {
    if (mode !== "auto" || !pages) return;
    setRemain(1);
    const total = settings.autoNextSec * 1000;
    let left = total;
    const id = setInterval(() => {
      if (held) return;
      left -= 100;
      setRemain(Math.max(0, left / total));
      if (left <= 0) {
        left = total;
        setIndex((i) => (i < pages.length - 1 ? i + 1 : i));
        setZoom({ s: 1, x: 0, y: 0 });
      }
    }, 100);
    return () => clearInterval(id);
  }, [mode, pages, index, settings.autoNextSec, held]);

  const scrollRef = useRef<HTMLDivElement>(null);
  const scrollBy = (dir: 1 | -1) => scrollRef.current?.scrollBy({ top: dir * scrollRef.current.clientHeight * 0.85, behavior: "smooth" });

  const toggleFull = useCallback(() => {
    if (document.fullscreenElement) void document.exitFullscreen();
    else void document.documentElement.requestFullscreen?.().catch(() => undefined);
  }, []);
  useEffect(() => {
    const h = () => setFull(!!document.fullscreenElement);
    document.addEventListener("fullscreenchange", h);
    return () => {
      document.removeEventListener("fullscreenchange", h);
      if (document.fullscreenElement) void document.exitFullscreen();
    };
  }, []);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.target as HTMLElement)?.tagName === "INPUT" || (e.target as HTMLElement)?.tagName === "SELECT") return;
      const scroll = mode === "scroll";
      const next = () => (scroll ? scrollBy(1) : go(index + 1));
      const prev = () => (scroll ? scrollBy(-1) : go(index - 1));
      switch (e.key) {
        case "ArrowRight": case "ArrowDown": case "PageDown": e.preventDefault(); next(); break;
        case " ": e.preventDefault(); e.shiftKey ? prev() : next(); break;
        case "ArrowLeft": case "ArrowUp": case "PageUp": e.preventDefault(); prev(); break;
        case "Home": go(0); break;
        case "End": go(n - 1); break;
        case "f": case "F": toggleFull(); break;
        case "+": case "=": setZoom((z) => ({ ...z, s: Math.min(5, z.s + 0.5) })); break;
        case "-": setZoom((z) => ({ s: Math.max(1, z.s - 0.5), x: z.s <= 1.5 ? 0 : z.x, y: z.s <= 1.5 ? 0 : z.y })); break;
        case "Escape": if (!document.fullscreenElement) close(); break;
        default: return;
      }
      poke();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  });

  // ---- pointer handling for paged and auto mode: tap zones, double-tap zoom, pinch, pan --------------
  const ptrs = useRef(new Map<number, { x: number; y: number }>());
  const pinch = useRef<{ d: number; s: number } | null>(null);
  const drag = useRef<{ x: number; y: number; zx: number; zy: number; moved: boolean } | null>(null);
  const lastTap = useRef({ t: 0, x: 0 });
  const tapTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const dist = () => {
    const [a, b] = [...ptrs.current.values()];
    return Math.hypot(a.x - b.x, a.y - b.y);
  };
  const onDown = (e: React.PointerEvent) => {
    setHeld(true);
    ptrs.current.set(e.pointerId, { x: e.clientX, y: e.clientY });
    (e.currentTarget as HTMLElement).setPointerCapture?.(e.pointerId);
    if (ptrs.current.size === 2) pinch.current = { d: dist(), s: zoom.s };
    else drag.current = { x: e.clientX, y: e.clientY, zx: zoom.x, zy: zoom.y, moved: false };
  };
  const onMove = (e: React.PointerEvent) => {
    if (!ptrs.current.has(e.pointerId)) return;
    ptrs.current.set(e.pointerId, { x: e.clientX, y: e.clientY });
    if (pinch.current && ptrs.current.size === 2) {
      const s = Math.max(1, Math.min(5, (pinch.current.s * dist()) / pinch.current.d));
      setZoom((z) => ({ s, x: s === 1 ? 0 : z.x, y: s === 1 ? 0 : z.y }));
    } else if (drag.current) {
      const dx = e.clientX - drag.current.x;
      const dy = e.clientY - drag.current.y;
      if (Math.abs(dx) + Math.abs(dy) > 8) drag.current.moved = true;
      if (zoom.s > 1) setZoom((z) => ({ ...z, x: drag.current!.zx + dx, y: drag.current!.zy + dy }));
    }
  };
  const onCancel = (e: React.PointerEvent) => {
    // the browser took the gesture (native scroll, system gesture): forget it, never treat it as a tap
    ptrs.current.delete(e.pointerId);
    if (ptrs.current.size < 2) pinch.current = null;
    if (ptrs.current.size === 0) {
      drag.current = null;
      setHeld(false);
    }
  };
  const onUp = (e: React.PointerEvent) => {
    ptrs.current.delete(e.pointerId);
    if (ptrs.current.size < 2) pinch.current = null;
    if (ptrs.current.size === 0) {
      setHeld(false);
      const d = drag.current;
      drag.current = null;
      if (d && !d.moved) tap(e.clientX, (e.currentTarget as HTMLElement).clientWidth);
      else if (d && d.moved && zoom.s === 1) {
        const dx = e.clientX - d.x;
        const dy = e.clientY - d.y;
        if (Math.abs(dx) > 60 && Math.abs(dx) > Math.abs(dy) * 1.5) go(index + (dx < 0 ? 1 : -1));
      }
    }
  };
  const tap = (x: number, w: number) => {
    const now = Date.now();
    if (now - lastTap.current.t < 300) {
      if (tapTimer.current) clearTimeout(tapTimer.current);
      lastTap.current.t = 0;
      setZoom((z) => (z.s > 1 ? { s: 1, x: 0, y: 0 } : { s: 2.4, x: (w / 2 - x) * 1.4, y: 0 }));
      return;
    }
    lastTap.current = { t: now, x };
    tapTimer.current = setTimeout(() => {
      if (zoom.s > 1) return poke();
      if (x < w * 0.33) go(index - 1);
      else if (x > w * 0.67) go(index + 1);
      else setControls((c) => !c);
      poke();
    }, 230);
  };

  // ---- scroll mode: pages are stacked with no gaps; the current page is the one under the viewport centre ----------
  const initial = useRef(reader.page);
  const restoring = useRef(false);
  const pageEls = () => [...(scrollRef.current?.querySelectorAll<HTMLElement>("[data-page]") ?? [])];
  const scrollToPage = (i: number) => {
    const el = scrollRef.current?.querySelector<HTMLElement>(`[data-page="${i}"]`);
    if (el && scrollRef.current) scrollRef.current.scrollTop = el.offsetTop;
  };
  useEffect(() => {
    if (mode !== "scroll" || !pages || !scrollRef.current) return;
    const root = scrollRef.current;
    let raf = 0;
    const track = () => {
      raf = 0;
      if (scrubbing.current || restoring.current) return;
      const els = pageEls();
      const mid = root.scrollTop + root.clientHeight / 2;
      let lo = 0, hi = els.length - 1;
      while (lo < hi) {
        const m = (lo + hi + 1) >> 1;
        if (els[m].offsetTop <= mid) lo = m; else hi = m - 1;
      }
      setIndex((cur) => (cur === lo ? cur : lo));
    };
    const onScroll = () => { if (!raf) raf = requestAnimationFrame(track); };
    // restore the last read page; images above it load later and move it, so re-pin until the user touches the list
    if (initial.current > 0) {
      restoring.current = true;
      scrollToPage(initial.current);
      const stop = () => { restoring.current = false; };
      root.addEventListener("touchstart", stop, { once: true, passive: true });
      root.addEventListener("wheel", stop, { once: true, passive: true });
      const t = setTimeout(stop, 4000);
      root.addEventListener("scroll", onScroll, { passive: true });
      return () => { clearTimeout(t); root.removeEventListener("scroll", onScroll); root.removeEventListener("touchstart", stop); root.removeEventListener("wheel", stop); if (raf) cancelAnimationFrame(raf); };
    }
    root.addEventListener("scroll", onScroll, { passive: true });
    return () => { root.removeEventListener("scroll", onScroll); if (raf) cancelAnimationFrame(raf); };
  }, [mode, pages]);
  // the placeholder height only exists for pages that have not loaded yet; loaded pages sit flush against each other
  const [loadedPages, setLoadedPages] = useState<Set<number>>(() => new Set());
  const markLoaded = (i: number) => setLoadedPages((s) => (s.has(i) ? s : new Set(s).add(i)));
  const onStripImageLoad = (i: number) => () => {
    markLoaded(i);
    if (restoring.current && i <= initial.current) requestAnimationFrame(() => scrollToPage(initial.current));
  };

  // ---- scrubber ---------------------------------------------------------------------------------------------------
  const commitScrub = (v: number) => {
    dragging.current = false;
    setScrub(null);
    if (mode === "scroll") {
      scrollToPage(v);
      setIndex(Math.max(0, Math.min(n - 1, v)));
      setTimeout(() => { scrubbing.current = false; }, 150);
    } else {
      scrubbing.current = false;
      go(v);
    }
    poke();
  };
  const onScrubChange = (v: number) => {
    poke();
    if (!dragging.current) return commitScrub(v); // keyboard / assistive tech: apply immediately
    scrubbing.current = true;
    setScrub(v);
    if (mode === "scroll") scrollToPage(v);
  };
  const shown = Math.min(scrub ?? index, Math.max(0, n - 1));

  const page = pages?.[index];
  const title = comic?.name ?? "";
  const barCls = cn("absolute inset-x-0 z-10 flex bg-[#1d1b3b]/90 px-3 text-white backdrop-blur-sm transition-opacity duration-200", controls ? "opacity-100" : "pointer-events-none opacity-0");
  // paged/auto: the page is centred horizontally and vertically in the reader viewport (already inside the system bars).
  // fit=height shows the whole page; fit=width fills the width and centres vertically while the page is shorter than the
  // viewport, and scrolls from its top edge when taller (min-h-full + my-auto never clips the top like plain items-center).
  const imgFit = fit === "width" ? "w-full h-auto" : "max-h-full max-w-full object-contain";

  return (
    <div className="fixed inset-0 z-[60] bg-black text-white" role="dialog" aria-label={`Reading ${title}`} onPointerMove={(e) => e.pointerType === "mouse" && poke()}>
      <div className={cn(barCls, "top-0 safe-t min-h-14 items-center gap-2 border-b-[2.5px] border-[#0e0d22]")}>
        <Button variant="ghost" size="icon" aria-label="Close reader" onClick={close} faceClassName="text-white group-hover:bg-white/15"><X /></Button>
        <div className="min-w-0 flex-1">
          <div className="truncate text-[15px] font-medium" title={title}>{title}</div>
          <div className="text-xs text-white/70">Page {shown + 1} of {n}</div>
        </div>
        {mode !== "scroll" && (
          <Button variant="ghost" size="icon" aria-label={fit === "width" ? "Fit whole page" : "Fit page width"} title={fit === "width" ? "Fit whole page" : "Fit page width"} onClick={() => { setSettings({ fit: (fit === "width" ? "height" : "width") as FitMode }); setZoom({ s: 1, x: 0, y: 0 }); }} faceClassName="text-white group-hover:bg-white/15">
            {fit === "width" ? <MoveVertical /> : <ArrowLeftRight />}
          </Button>
        )}
        <Button variant="ghost" size="icon" aria-label="Toggle fullscreen" title="Fullscreen (F)" onClick={toggleFull} className="hidden md:inline-flex" faceClassName="text-white group-hover:bg-white/15">{full ? <Shrink /> : <Expand />}</Button>
      </div>

      {!pages ? (
        <div className="flex size-full items-center justify-center text-sm text-white/70">Loading pages</div>
      ) : mode === "scroll" ? (
        <div ref={scrollRef} className="reader-strip size-full overflow-y-auto overscroll-contain" onClick={() => poke()}>
          <div className="mx-auto max-w-3xl">
            {pages.map((p, i) => (
              <div key={p.name} data-page={i} className="block w-full leading-[0]" style={loadedPages.has(i) ? undefined : { minHeight: "60dvh", background: "#17152f" }}>
                <PageImage url={p.url} lazy onLoad={onStripImageLoad(i)} onFail={() => markLoaded(i)} className="block h-auto w-full" />
              </div>
            ))}
            <div className="py-10 text-center text-sm text-white/60">End of comic</div>
          </div>
        </div>
      ) : (
        <div className="relative size-full select-none overflow-hidden" style={{ touchAction: zoom.s === 1 && fit === "width" ? "pan-y" : "none" }} onPointerDown={onDown} onPointerMove={onMove} onPointerUp={onUp} onPointerCancel={onCancel}>
          <div className={cn("size-full", fit === "width" && zoom.s === 1 ? "overflow-y-auto overscroll-contain" : "overflow-hidden")} style={{ transform: `translate(${zoom.x}px, ${zoom.y}px) scale(${zoom.s})`, transformOrigin: "center", transition: pinch.current || drag.current ? "none" : "transform 180ms ease-out" }}>
            <div className="flex min-h-full w-full items-center justify-center" style={{ height: fit === "height" ? "100%" : undefined }}>
              {page && <PageImage key={page.url} url={page.url} className={cn("block", imgFit)} />}
            </div>
          </div>
          {mode === "auto" && (
            <div className="pointer-events-none absolute bottom-24 right-4 flex items-center gap-2 rounded-full bg-black/60 py-1 pl-2 pr-3 text-xs text-white/80" aria-label={`Next page in ${Math.ceil(remain * settings.autoNextSec)} seconds`}>
              <svg width="18" height="18" viewBox="0 0 18 18" aria-hidden><circle cx="9" cy="9" r="7" fill="none" stroke="currentColor" strokeOpacity=".25" strokeWidth="2" /><circle cx="9" cy="9" r="7" fill="none" stroke="currentColor" strokeWidth="2" strokeDasharray={44} strokeDashoffset={44 * (1 - remain)} transform="rotate(-90 9 9)" /></svg>
              {held ? "Paused" : `${Math.ceil(remain * settings.autoNextSec)}s`}
            </div>
          )}
          <button aria-label="Previous page" onClick={(e) => { e.stopPropagation(); go(index - 1); }} onPointerDown={(e) => e.stopPropagation()} className={cn("absolute left-2 top-1/2 hidden size-11 -translate-y-1/2 items-center justify-center rounded-full bg-black/50 text-white transition-opacity md:flex", controls ? "opacity-100" : "opacity-0")}><ChevronLeft /></button>
          <button aria-label="Next page" onClick={(e) => { e.stopPropagation(); go(index + 1); }} onPointerDown={(e) => e.stopPropagation()} className={cn("absolute right-2 top-1/2 hidden size-11 -translate-y-1/2 items-center justify-center rounded-full bg-black/50 text-white transition-opacity md:flex", controls ? "opacity-100" : "opacity-0")}><ChevronRight /></button>
        </div>
      )}

      <div className={cn(barCls, "bottom-0 safe-b flex-col gap-1.5 border-t-[2.5px] border-[#0e0d22] py-2")} onPointerDown={(e) => e.stopPropagation()}>
        <div className="flex w-full items-center gap-3">
          <span className="w-10 text-right text-xs tabular-nums text-white/80">{shown + 1}</span>
          <input
            type="range"
            min={0}
            max={Math.max(0, n - 1)}
            step={1}
            value={shown}
            onChange={(e) => onScrubChange(+e.target.value)}
            onPointerDown={(e) => { e.stopPropagation(); dragging.current = true; scrubbing.current = true; poke(); }}
            onPointerUp={(e) => { e.stopPropagation(); if (dragging.current) commitScrub(scrub ?? index); }}
            onPointerCancel={() => { if (dragging.current) commitScrub(scrub ?? index); }}
            onKeyDown={(e) => e.stopPropagation()}
            aria-label="Page scrubber"
            aria-valuetext={`Page ${shown + 1} of ${n}`}
            style={{ "--p": n > 1 ? shown / (n - 1) : 0 } as React.CSSProperties}
            className="scrubber min-w-0 flex-1"
          />
          <span className="w-10 text-xs tabular-nums text-white/80">{n}</span>
          {mode === "auto" && (
            <select value={settings.autoNextSec} onChange={(e) => setSettings({ autoNextSec: +e.target.value })} aria-label="Seconds per page" className="h-10 rounded-full border-2 border-[#0e0d22] bg-[#252250] px-3 text-xs font-bold text-white">
              {SECONDS.map((v) => <option key={v} value={v}>{v} s</option>)}
            </select>
          )}
        </div>
        <div role="radiogroup" aria-label="Reading mode" className="grid w-full grid-cols-3 gap-1 rounded-full border-[2.5px] border-[#0e0d22] bg-[#252250] p-1">
          {MODES.map((m) => (
            <button key={m.value} role="radio" aria-checked={mode === m.value} title={MODE_HINT[m.value]} onClick={() => { setSettings({ readerMode: m.value }); initial.current = index; setZoom({ s: 1, x: 0, y: 0 }); poke(); }} className={cn("flex h-11 min-w-0 touch-manipulation items-center justify-center gap-1.5 rounded-full border-2 px-1 text-[13px] font-bold transition-colors", mode === m.value ? "border-[#0e0d22] bg-butter text-on" : "border-transparent text-white/80 active:bg-white/15")}>
              <m.icon className="size-4 shrink-0" /><span className="truncate">{m.label}</span>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
