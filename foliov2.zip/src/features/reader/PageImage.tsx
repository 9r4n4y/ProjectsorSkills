import { useEffect, useState } from "react";
import { api } from "@/lib/backend";

/** Page image that also resolves SAF-mode urls (Android folder-picker fallback). */
export function PageImage({ url, className, lazy, onLoad, onFail, draggable = false }: { url: string; className?: string; lazy?: boolean; onLoad?: (e: React.SyntheticEvent<HTMLImageElement>) => void; onFail?: () => void; draggable?: boolean }) {
  const [src, setSrc] = useState(url.startsWith("saf:") ? "" : url);
  const [failed, setFailed] = useState(false);
  useEffect(() => {
    setFailed(false);
    if (!url.startsWith("saf:")) return setSrc(url);
    let live = true;
    void api.resolveImage(url).then((s) => live && setSrc(s));
    return () => {
      live = false;
    };
  }, [url]);
  if (failed) return <div className="flex size-full items-center justify-center bg-muted text-xs text-sub">Cannot load page</div>;
  if (!src) return <div className="skeleton size-full" />;
  return <img src={src} alt="" loading={lazy ? "lazy" : undefined} decoding="async" draggable={draggable} onLoad={onLoad} onError={() => { setFailed(true); onFail?.(); }} className={className} />;
}
