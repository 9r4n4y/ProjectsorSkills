import { Capacitor } from "@capacitor/core";
import { create } from "zustand";
import {
  type ComicRecord,
  DEFAULT_SETTINGS,
  EMPTY_FILTERS,
  type FilterState,
  type FolderRecord,
  type InitInfo,
  type JobsState,
  type ArchiveRecord,
  type Settings,
  type TagDef,
  type TrashItem,
  type VerificationReport,
  normalizeText,
} from "@comiclib/shared";
import { api } from "./backend";

export type Screen = "library" | "tags" | "extract" | "verify" | "health" | "settings";
export interface Toast {
  id: number;
  text: string;
  kind: "info" | "error";
}

interface State {
  ready: boolean;
  error: string | null;
  info: InitInfo | null;
  root: string | null;
  comics: ComicRecord[];
  folders: FolderRecord[];
  archives: ArchiveRecord[];
  tags: TagDef[];
  reports: VerificationReport[];
  trash: TrashItem[];
  settings: Settings;
  jobs: JobsState;
  scanning: boolean;

  filters: FilterState;
  screen: Screen;
  drawer: boolean;
  panel: null | "tags" | "folders";
  selectMode: boolean;
  selected: Set<string>;
  quickId: string | null;
  reader: { id: string; page: number } | null;
  highlightId: string | null;
  thumbTick: number;
  toasts: Toast[];

  boot(): Promise<void>;
  refresh(): Promise<void>;
  rescan(): Promise<void>;
  setScreen(s: Screen): void;
  setFilters(p: Partial<FilterState>): void;
  clearFilters(): void;
  setSettings(p: Partial<Settings>): void;
  toggleSelect(id: string): void;
  setSelected(ids: string[]): void;
  setSelectMode(on: boolean): void;
  openQuick(id: string): void;
  closeQuick(): void;
  openReader(id: string, page?: number): void;
  closeReader(): void;
  toggleFavorite(ids: string[]): void;
  editTags(ids: string[], add: string[], remove: string[]): void;
  renameTag(from: string, to: string): void;
  deleteTag(name: string): void;
  recordProgress(id: string, page: number, pages: number): void;
  toast(text: string, kind?: "info" | "error"): void;
  set: (p: Partial<State>) => void;
}

let toastId = 1;
let theme: Settings["theme"] = "system";

export function applyTheme(t: Settings["theme"]) {
  theme = t;
  const dark = t === "dark" || (t === "system" && window.matchMedia("(prefers-color-scheme: dark)").matches);
  document.documentElement.classList.toggle("dark", dark);
  // keep Android status/navigation bar colours and icon contrast in sync with the theme
  if (Capacitor.isNativePlatform()) void api.setSystemBars(dark).catch(() => undefined);
}
if (typeof window !== "undefined" && typeof window.matchMedia === "function") {
  window.matchMedia("(prefers-color-scheme: dark)").addEventListener("change", () => theme === "system" && applyTheme("system"));
}

export const useStore = create<State>((set, get) => ({
  ready: false,
  error: null,
  info: null,
  root: null,
  comics: [],
  folders: [],
  archives: [],
  tags: [],
  reports: [],
  trash: [],
  settings: DEFAULT_SETTINGS,
  jobs: { jobs: [], paused: false },
  scanning: false,
  filters: EMPTY_FILTERS,
  screen: "library",
  drawer: false,
  panel: null,
  selectMode: false,
  selected: new Set(),
  quickId: null,
  reader: null,
  highlightId: null,
  thumbTick: 0,
  toasts: [],
  set: (p) => set(p),

  async boot() {
    try {
      const info = await api.init();
      applyTheme(info.settings.theme);
      set({ info, settings: info.settings, root: info.root, filters: { ...EMPTY_FILTERS, tagMode: info.settings.tagMode } });
      api.on("jobs", (s) => set({ jobs: s }));
      let t: ReturnType<typeof setTimeout> | null = null;
      api.on("library", () => {
        if (t) return;
        t = setTimeout(() => {
          t = null;
          void get().refresh();
        }, 400);
      });
      api.on("thumbs", () => set((s) => ({ thumbTick: s.thumbTick + 1 })));
      set({ jobs: await api.getJobs() });
      if (info.root) await get().refresh();
      set({ ready: true });
      if (info.root && info.settings.healthOnStart) void api.runHealth(false).catch(() => undefined);
    } catch (e) {
      set({ error: (e as Error).message, ready: true });
    }
  },

  async refresh() {
    const lib = await api.getLibrary();
    set({ root: lib.root, comics: lib.comics, folders: lib.folders, archives: lib.archives, tags: lib.tags, reports: lib.reports, trash: lib.trash });
  },

  async rescan() {
    set({ scanning: true });
    try {
      const s = await api.scan();
      await get().refresh();
      get().toast(`Scan complete: ${s.comics} comics, ${s.added} added, ${s.removed} removed, ${s.moved} moved`);
    } catch (e) {
      get().toast((e as Error).message, "error");
    } finally {
      set({ scanning: false });
    }
  },

  setScreen: (screen) => set({ screen, drawer: false }),
  setFilters: (p) => set((s) => ({ filters: { ...s.filters, ...p } })),
  clearFilters: () => set((s) => ({ filters: { ...EMPTY_FILTERS, tagMode: s.filters.tagMode } })),

  setSettings(p) {
    const settings = { ...get().settings, ...p };
    set({ settings });
    if (p.theme) applyTheme(p.theme);
    void api.saveState({ settings: p });
  },

  toggleSelect(id) {
    const s = new Set(get().selected);
    s.has(id) ? s.delete(id) : s.add(id);
    set({ selected: s });
  },
  setSelected: (ids) => set({ selected: new Set(ids) }),
  setSelectMode: (on) => set({ selectMode: on, selected: on ? get().selected : new Set() }),

  openQuick: (id) => set({ quickId: id }),
  closeQuick() {
    const id = get().quickId;
    set({ quickId: null, highlightId: id });
    setTimeout(() => get().highlightId === id && set({ highlightId: null }), 1400);
  },
  openReader: (id, page) => {
    const c = get().comics.find((x) => x.id === id);
    set({ reader: { id, page: page ?? (c && c.lastPage > 0 && c.lastPage < c.pages ? c.lastPage : 0) } });
  },
  closeReader: () => set({ reader: null }),

  toggleFavorite(ids) {
    const comics = get().comics;
    const targets = comics.filter((c) => ids.includes(c.id));
    const value = !targets.every((c) => c.favorite);
    set({ comics: comics.map((c) => (ids.includes(c.id) ? { ...c, favorite: value } : c)) });
    void api.saveState({ comics: ids.map((id) => ({ id, favorite: value })) });
  },

  editTags(ids, add, remove) {
    const rm = new Set(remove.map(normalizeText));
    const patches: { id: string; tags: string[] }[] = [];
    const comics = get().comics.map((c) => {
      if (!ids.includes(c.id)) return c;
      const have = new Set<string>();
      const tags = [...c.tags.filter((t) => !rm.has(normalizeText(t))), ...add].filter((t) => {
        const k = normalizeText(t);
        if (!k || have.has(k)) return false;
        have.add(k);
        return true;
      });
      patches.push({ id: c.id, tags });
      return { ...c, tags };
    });
    const known = new Set(get().tags.map((t) => normalizeText(t.name)));
    const newDefs = add.filter((t) => !known.has(normalizeText(t))).map((name) => ({ name }));
    set({ comics, tags: [...get().tags, ...newDefs] });
    void api.saveState({ comics: patches, tagDefs: newDefs });
  },

  renameTag(from, to) {
    const ids = get().comics.filter((c) => c.tags.some((t) => normalizeText(t) === normalizeText(from))).map((c) => c.id);
    get().editTags(ids, [to], [from]);
    void api.saveState({ deleteTags: [from], tagDefs: [{ name: to }] });
    set({ tags: get().tags.filter((t) => normalizeText(t.name) !== normalizeText(from) || normalizeText(from) === normalizeText(to)) });
  },

  deleteTag(name) {
    const k = normalizeText(name);
    set({
      comics: get().comics.map((c) => ({ ...c, tags: c.tags.filter((t) => normalizeText(t) !== k) })),
      tags: get().tags.filter((t) => normalizeText(t.name) !== k),
    });
    void api.saveState({ deleteTags: [name] });
  },

  recordProgress(id, page, pages) {
    const read = page >= pages - 1;
    const now = Date.now();
    set({ comics: get().comics.map((c) => (c.id === id ? { ...c, lastPage: page, lastReadAt: now, read: c.read || read } : c)) });
    void api.saveState({ comics: [{ id, lastPage: page, lastReadAt: now, ...(read ? { read: true } : {}) }] });
  },

  toast(text, kind = "info") {
    const id = toastId++;
    set({ toasts: [...get().toasts, { id, text, kind }] });
    setTimeout(() => set({ toasts: get().toasts.filter((t) => t.id !== id) }), kind === "error" ? 7000 : 3500);
  },
}));
