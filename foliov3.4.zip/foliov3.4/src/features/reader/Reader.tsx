import { useCallback, useEffect, useRef, useState } from "react";
import { ArrowLeftRight, ChevronLeft, ChevronRight, Download, Expand, FileArchive, ImageDown, Loader2, Minus, MoveVertical, Plus, RefreshCw, Rows3, Shrink, Timer, X, MousePointerClick } from "lucide-react";
import type { FitMode, PageInfo, ReaderMode } from "@comiclib/shared";
import { api } from "@/lib/backend";
import { useStore } from "@/lib/store";
import { useBackClose } from "@/lib/hooks";
import { Button } from "@/components/ui/button";
import { cn } from "@/utils/cn";
import { PageImage } from "./PageImage";

const MODES: { value: ReaderMode; label: string; icon: React.ElementType }[] = [
  { value: "scroll", label: "Scroll", icon: Rows3 },
  { value: "paged", label: "Tap pages", icon: MousePointerClick },
  { value: "auto", label: "Auto", icon: Timer },
];
const MODE_HINT: Record<ReaderMode, string> = {
  scroll: "Continuous vertical scroll (pinch or double-tap to zoom)",
  paged: "Tap the left or right edge to turn the page",
  auto: "Turns the page by itself; touch to pause",
};
const SECONDS = [3, 5, 8, 12, 20, 30, 60];
const MAX_ZOOM = 4;

export function Reader() {
  const reader = useStore((s) => s.reader);
  if (!reader) return null;
  return <ReaderInner key={`${reader.id}:${reader.page}`} readerId={reader.id} initialPage={reader.page} />;
}

function ReaderInner({ readerId, initialPage }: { readerId: string; initialPage: number }) {
  const comic = useStore((s) => s.comics.find((c) => c.id === readerId));
  const settings = useStore((s) => s.settings);
  const setSettings = useStore((s) => s.setSettings);
  const close = useStore((s) => s.closeReader);
  const recordProgress = useStore((s) => s.recordProgress);
  const toast = useStore((s) => s.toast);
  const [pages, setPages] = useState<PageInfo[] | null>(null);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [index, setIndex] = useState(Math.max(0, initialPage));
  const [controls, setControls] = useState(true);
  const [exportOpen, setExportOpen] = useState(false);
  const [exporting, setExporting] = useState<null | "page" | "comic">(null);
  const [zoom, setZoom] = useState({ s: 1, x: 0, y: 0 });
  const [scrollZoom, setScrollZoom] = useState(1);
  const scrollZoomRef = useRef(1);
  scrollZoomRef.current = scrollZoom;
  const [held, setHeld] = useState(false);
  const [remain, setRemain] = useState(1);
  const [full, setFull] = useState(false);
  const hideTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const viewportRef = useRef<HTMLDivElement>(null);
  const mode = settings.readerMode;
  const fit = settings.fit;
  const n = pages?.length ?? comic?.pages ?? 0;
  useBackClose(true, close);

  const [scrub, setScrub] = useState<number | null>(null);
  const dragging = useRef(false);
  const scrubbing = useRef(false);

  const loadPages = useCallback(() => {
    setPages(null);
    setLoadError(null);
    let live = true;
    void api
      .pages(readerId)
      .then((p) => {
        if (!live) return;
        const list = Array.isArray(p) ? p : [];
        setPages(list);
        if (list.length > 0) {
          const clamped = Math.max(0, Math.min(list.length - 1, initialPage));
          initial.current = clamped;
          setIndex(clamped);
        }
      })
      .catch((e) => {
        if (!live) return;
        setLoadError((e as Error)?.message || "Could not open this comic.");
        setPages([]);
      });
    return () => {
      live = false;
    };
  }, [readerId, initialPage]);

  useEffect(() => loadPages(), [loadPages]);

  const go = useCallback(
    (i: number) => {
      if (n <= 0) return;
      setIndex((cur) => {
        const t = Math.max(0, Math.min(n - 1, i));
        if (t !== cur) setZoom({ s: 1, x: 0, y: 0 });
        return t;
      });
    },
    [n],
  );

  // remember the page (debounced) and mark the comic as read at the end
  useEffect(() => {
    if (!pages || pages.length === 0) return;
    const t = setTimeout(() => recordProgress(readerId, index, pages.length), 500);
    return () => clearTimeout(t);
  }, [index, pages, readerId, recordProgress]);

  // preload upcoming pages
  useEffect(() => {
    if (!pages || pages.length === 0 || mode === "scroll") return;
    for (let i = index + 1; i <= index + 3 && i < pages.length; i++) {
      void api.resolveImage(pages[i].url).then((u) => {
        if (u) new Image().src = u;
      }).catch(() => undefined);
    }
  }, [index, pages, mode]);

  // controls auto-hide (stay open while export menu is open)
  const poke = useCallback(() => {
    setControls(true);
    if (hideTimer.current) clearTimeout(hideTimer.current);
    hideTimer.current = setTimeout(() => {
      setExportOpen((open) => {
        if (!open) setControls(false);
        return open;
      });
    }, 2800);
  }, []);
  useEffect(() => {
    poke();
    return () => {
      if (hideTimer.current) clearTimeout(hideTimer.current);
    };
  }, [poke]);

  // auto-next timer with visible countdown, paused while touching
  useEffect(() => {
    if (mode !== "auto" || !pages || pages.length === 0) return;
    setRemain(1);
    const total = settings.autoNextSec * 1000;
    let left = total;
    const id = setInterval(() => {
      if (held || exportOpen) return;
      left -= 100;
      setRemain(Math.max(0, left / total));
      if (left <= 0) {
        left = total;
        setIndex((i) => (i < pages.length - 1 ? i + 1 : i));
        setZoom({ s: 1, x: 0, y: 0 });
      }
    }, 100);
    return () => clearInterval(id);
  }, [mode, pages, index, settings.autoNextSec, held, exportOpen]);

  const scrollRef = useRef<HTMLDivElement>(null);
  const stripInnerRef = useRef<HTMLDivElement>(null);
  const scrollBy = (dir: 1 | -1) => scrollRef.current?.scrollBy({ top: dir * scrollRef.current.clientHeight * 0.85, behavior: "smooth" });

  const toggleFull = useCallback(() => {
    if (document.fullscreenElement) void document.exitFullscreen();
    else void document.documentElement.requestFullscreen?.().catch(() => undefined);
  }, []);
  useEffect(() => {
    const h = () => setFull(!!document.fullscreenElement);
    document.addEventListener("fullscreenchange", h);
    return () => {
      document.removeEventListener("fullscreenchange", h);
      if (document.fullscreenElement) void document.exitFullscreen();
    };
  }, []);

  /**
   * Zoom in scroll mode by scaling the strip's layout width (100%..400%) inside an overflow-auto container
   * and keeping the focal point anchored. Avoids giant CSS transform GPU textures so images never vanish on Android.
   */
  const applyScrollZoom = useCallback((nextRaw: number, focalX?: number, focalY?: number) => {
    const prev = scrollZoomRef.current;
    const next = Math.max(1, Math.min(MAX_ZOOM, Number.isFinite(nextRaw) ? Math.round(nextRaw * 100) / 100 : 1));
    if (Math.abs(next - prev) < 0.01) return;
    const root = scrollRef.current;
    if (!root) {
      setScrollZoom(next);
      return;
    }
    const rect = root.getBoundingClientRect();
    const fx = focalX !== undefined ? focalX - rect.left : root.clientWidth / 2;
    const fy = focalY !== undefined ? focalY - rect.top : root.clientHeight / 2;
    const ratio = next / prev;
    const targetLeft = next <= 1.01 ? 0 : Math.max(0, (root.scrollLeft + fx) * ratio - fx);
    const targetTop = Math.max(0, (root.scrollTop + fy) * ratio - fy);
    setScrollZoom(next <= 1.01 ? 1 : next);
    requestAnimationFrame(() => {
      if (!scrollRef.current) return;
      scrollRef.current.scrollLeft = targetLeft;
      scrollRef.current.scrollTop = targetTop;
    });
  }, []);

  // Scroll-mode touch pinch-zoom & double-tap zoom
  const scrollPinchRef = useRef<{ d: number; s: number; cx: number; cy: number } | null>(null);
  const scrollLastTapRef = useRef<{ t: number; x: number; y: number }>({ t: 0, x: 0, y: 0 });
  const scrollTapTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const onScrollTouchStart = (e: React.TouchEvent) => {
    if (e.touches.length === 2) {
      const a = e.touches[0], b = e.touches[1];
      const d = Math.hypot(a.clientX - b.clientX, a.clientY - b.clientY);
      scrollPinchRef.current = {
        d: Math.max(10, d),
        s: scrollZoomRef.current,
        cx: (a.clientX + b.clientX) / 2,
        cy: (a.clientY + b.clientY) / 2,
      };
    }
  };
  const onScrollTouchMove = (e: React.TouchEvent) => {
    if (e.touches.length === 2 && scrollPinchRef.current) {
      const a = e.touches[0], b = e.touches[1];
      const d = Math.hypot(a.clientX - b.clientX, a.clientY - b.clientY);
      if (d < 1) return;
      const nextScale = scrollPinchRef.current.s * (d / scrollPinchRef.current.d);
      applyScrollZoom(nextScale, (a.clientX + b.clientX) / 2, (a.clientY + b.clientY) / 2);
    }
  };
  const onScrollTouchEnd = (e: React.TouchEvent) => {
    if (e.touches.length < 2) scrollPinchRef.current = null;
  };
  const onScrollClick = (e: React.MouseEvent) => {
    setExportOpen(false);
    const now = Date.now();
    const dx = Math.abs(e.clientX - scrollLastTapRef.current.x);
    const dy = Math.abs(e.clientY - scrollLastTapRef.current.y);
    if (now - scrollLastTapRef.current.t < 300 && dx < 36 && dy < 36) {
      if (scrollTapTimer.current) clearTimeout(scrollTapTimer.current);
      scrollLastTapRef.current.t = 0;
      applyScrollZoom(scrollZoomRef.current > 1.05 ? 1 : 2.2, e.clientX, e.clientY);
      return;
    }
    scrollLastTapRef.current = { t: now, x: e.clientX, y: e.clientY };
    scrollTapTimer.current = setTimeout(() => {
      poke();
    }, 220);
  };

  /** Clamp zoom scale and pan offsets so the page image can never fly off-screen or trigger NaN transforms in Android WebView. */
  const clampZoom = useCallback((sRaw: number, xRaw: number, yRaw: number) => {
    const s = Number.isFinite(sRaw) ? Math.max(1, Math.min(MAX_ZOOM, sRaw)) : 1;
    if (s <= 1.01) return { s: 1, x: 0, y: 0 };
    const w = viewportRef.current?.clientWidth || window.innerWidth || 360;
    const h = viewportRef.current?.clientHeight || window.innerHeight || 640;
    const maxX = ((s - 1) * w) / 2;
    const maxY = ((s - 1) * h) / 2;
    const x = Number.isFinite(xRaw) ? Math.max(-maxX, Math.min(maxX, xRaw)) : 0;
    const y = Number.isFinite(yRaw) ? Math.max(-maxY, Math.min(maxY, yRaw)) : 0;
    return { s, x, y };
  }, []);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.target as HTMLElement)?.tagName === "INPUT" || (e.target as HTMLElement)?.tagName === "SELECT") return;
      const scroll = mode === "scroll";
      const next = () => (scroll ? scrollBy(1) : go(index + 1));
      const prev = () => (scroll ? scrollBy(-1) : go(index - 1));
      switch (e.key) {
        case "ArrowRight": case "ArrowDown": case "PageDown": e.preventDefault(); next(); break;
        case " ": e.preventDefault(); e.shiftKey ? prev() : next(); break;
        case "ArrowLeft": case "ArrowUp": case "PageUp": e.preventDefault(); prev(); break;
        case "Home": go(0); break;
        case "End": go(n - 1); break;
        case "f": case "F": toggleFull(); break;
        case "+": case "=":
          if (scroll) applyScrollZoom(scrollZoomRef.current + 0.5);
          else setZoom((z) => clampZoom(z.s + 0.5, z.x, z.y));
          break;
        case "-":
          if (scroll) applyScrollZoom(scrollZoomRef.current - 0.5);
          else setZoom((z) => clampZoom(z.s - 0.5, z.s <= 1.5 ? 0 : z.x, z.s <= 1.5 ? 0 : z.y));
          break;
        case "Escape": if (exportOpen) setExportOpen(false); else if (!document.fullscreenElement) close(); break;
        default: return;
      }
      poke();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [mode, go, index, n, toggleFull, clampZoom, applyScrollZoom, close, poke, exportOpen]);

  // ---- pointer handling for paged and auto mode: tap zones, double-tap zoom, pinch, pan --------------
  const ptrs = useRef(new Map<number, { x: number; y: number }>());
  const pinch = useRef<{ d: number; s: number; zx: number; zy: number } | null>(null);
  const drag = useRef<{ x: number; y: number; zx: number; zy: number; moved: boolean } | null>(null);
  const zoomRef = useRef(zoom);
  zoomRef.current = zoom;
  const lastTap = useRef({ t: 0, x: 0 });
  const tapTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const dist = () => {
    const vals = [...ptrs.current.values()];
    if (vals.length < 2) return 0;
    return Math.hypot(vals[0].x - vals[1].x, vals[0].y - vals[1].y);
  };

  const onDown = (e: React.PointerEvent) => {
    setExportOpen(false);
    setHeld(true);
    ptrs.current.set(e.pointerId, { x: e.clientX, y: e.clientY });
    (e.currentTarget as HTMLElement).setPointerCapture?.(e.pointerId);
    if (ptrs.current.size === 2) {
      drag.current = null;
      pinch.current = { d: Math.max(10, dist()), s: zoomRef.current.s, zx: zoomRef.current.x, zy: zoomRef.current.y };
    } else if (ptrs.current.size === 1) {
      pinch.current = null;
      drag.current = { x: e.clientX, y: e.clientY, zx: zoomRef.current.x, zy: zoomRef.current.y, moved: false };
    }
  };

  const onMove = (e: React.PointerEvent) => {
    if (!ptrs.current.has(e.pointerId)) return;
    ptrs.current.set(e.pointerId, { x: e.clientX, y: e.clientY });
    if (pinch.current && ptrs.current.size === 2) {
      const curD = dist();
      if (curD < 1) return;
      const ratio = curD / pinch.current.d;
      const nextScale = pinch.current.s * ratio;
      setZoom(clampZoom(nextScale, pinch.current.zx * (nextScale / pinch.current.s), pinch.current.zy * (nextScale / pinch.current.s)));
    } else if (drag.current && ptrs.current.size === 1) {
      const dx = e.clientX - drag.current.x;
      const dy = e.clientY - drag.current.y;
      if (Math.abs(dx) + Math.abs(dy) > 8) drag.current.moved = true;
      if (zoomRef.current.s > 1) {
        setZoom(clampZoom(zoomRef.current.s, drag.current.zx + dx, drag.current.zy + dy));
      }
    }
  };

  const onCancel = (e: React.PointerEvent) => {
    ptrs.current.delete(e.pointerId);
    if (ptrs.current.size < 2) pinch.current = null;
    if (ptrs.current.size === 0) {
      drag.current = null;
      setHeld(false);
    }
  };

  const onUp = (e: React.PointerEvent) => {
    ptrs.current.delete(e.pointerId);
    if (ptrs.current.size === 1 && pinch.current) {
      pinch.current = null;
      const [rem] = [...ptrs.current.values()];
      drag.current = { x: rem.x, y: rem.y, zx: zoomRef.current.x, zy: zoomRef.current.y, moved: true };
      return;
    }
    if (ptrs.current.size < 2) pinch.current = null;
    if (ptrs.current.size === 0) {
      setHeld(false);
      const d = drag.current;
      drag.current = null;
      if (d && !d.moved) tap(e.clientX, (e.currentTarget as HTMLElement).clientWidth);
      else if (d && d.moved && zoomRef.current.s === 1) {
        const dx = e.clientX - d.x;
        const dy = e.clientY - d.y;
        if (Math.abs(dx) > 60 && Math.abs(dx) > Math.abs(dy) * 1.5) go(index + (dx < 0 ? 1 : -1));
      }
    }
  };

  const tap = (x: number, w: number) => {
    const now = Date.now();
    if (now - lastTap.current.t < 300) {
      if (tapTimer.current) clearTimeout(tapTimer.current);
      lastTap.current.t = 0;
      setZoom((z) => (z.s > 1 ? { s: 1, x: 0, y: 0 } : clampZoom(2.2, (w / 2 - x) * 1.1, 0)));
      return;
    }
    lastTap.current = { t: now, x };
    tapTimer.current = setTimeout(() => {
      if (zoomRef.current.s > 1) return poke();
      if (x < w * 0.33) go(index - 1);
      else if (x > w * 0.67) go(index + 1);
      else setControls((c) => !c);
      poke();
    }, 230);
  };

  // ---- scroll mode: exact target page jump + layout-shift pinning + thick black dividers ------------
  const initial = useRef(Math.max(0, initialPage));
  const restoring = useRef(false);
  const restoreGraceUntil = useRef(0);

  const pageEls = () => [...(scrollRef.current?.querySelectorAll<HTMLElement>("[data-page]") ?? [])];

  const scrollToPage = useCallback((i: number) => {
    const root = scrollRef.current;
    if (!root) return;
    const el = root.querySelector<HTMLElement>(`[data-page="${i}"]`);
    if (!el) return;
    const delta = el.getBoundingClientRect().top - root.getBoundingClientRect().top;
    root.scrollTop = Math.max(0, root.scrollTop + delta);
  }, []);

  useEffect(() => {
    if (mode !== "scroll" || !pages || pages.length === 0 || !scrollRef.current) return;
    const root = scrollRef.current;
    let raf = 0;
    const track = () => {
      raf = 0;
      if (scrubbing.current || restoring.current) return;
      const els = pageEls();
      if (els.length === 0) return;
      const rootTop = root.getBoundingClientRect().top;
      const mid = rootTop + root.clientHeight * 0.35;
      let lo = 0, hi = els.length - 1;
      while (lo < hi) {
        const m = (lo + hi + 1) >> 1;
        if (els[m].getBoundingClientRect().top <= mid) lo = m;
        else hi = m - 1;
      }
      setIndex((cur) => (cur === lo ? cur : lo));
    };
    const onScroll = () => {
      if (!raf) raf = requestAnimationFrame(track);
    };

    const target = Math.max(0, Math.min(pages.length - 1, initial.current));
    if (target > 0) {
      restoring.current = true;
      restoreGraceUntil.current = Date.now() + 300;
      setIndex(target);
      const pin = () => {
        if (!restoring.current) return;
        scrollToPage(target);
      };
      pin();
      const raf1 = requestAnimationFrame(() => {
        pin();
        requestAnimationFrame(pin);
      });
      const ro = typeof ResizeObserver !== "undefined" && stripInnerRef.current
        ? new ResizeObserver(() => {
            if (restoring.current) pin();
          })
        : null;
      if (ro && stripInnerRef.current) ro.observe(stripInnerRef.current);

      const stop = () => {
        if (Date.now() < restoreGraceUntil.current) return;
        restoring.current = false;
        ro?.disconnect();
      };
      root.addEventListener("touchmove", stop, { passive: true });
      root.addEventListener("wheel", stop, { passive: true });
      root.addEventListener("pointerdown", stop, { passive: true });
      const t = setTimeout(() => {
        restoring.current = false;
        ro?.disconnect();
      }, 6000);
      root.addEventListener("scroll", onScroll, { passive: true });
      return () => {
        cancelAnimationFrame(raf1);
        clearTimeout(t);
        ro?.disconnect();
        root.removeEventListener("scroll", onScroll);
        root.removeEventListener("touchmove", stop);
        root.removeEventListener("wheel", stop);
        root.removeEventListener("pointerdown", stop);
        if (raf) cancelAnimationFrame(raf);
      };
    }

    root.addEventListener("scroll", onScroll, { passive: true });
    return () => {
      root.removeEventListener("scroll", onScroll);
      if (raf) cancelAnimationFrame(raf);
    };
  }, [mode, pages, scrollToPage]);

  const [loadedPages, setLoadedPages] = useState<Set<number>>(() => new Set());
  const markLoaded = (i: number) => setLoadedPages((s) => (s.has(i) ? s : new Set(s).add(i)));
  const onStripImageLoad = (i: number) => () => {
    markLoaded(i);
    if (restoring.current && i <= initial.current) {
      requestAnimationFrame(() => scrollToPage(initial.current));
    }
  };

  // ---- scrubber ---------------------------------------------------------------------------------------------------
  const commitScrub = (v: number) => {
    dragging.current = false;
    setScrub(null);
    const target = Math.max(0, Math.min(Math.max(0, n - 1), v));
    if (mode === "scroll") {
      restoring.current = false;
      initial.current = target;
      scrollToPage(target);
      setIndex(target);
      setTimeout(() => {
        scrollToPage(target);
        scrubbing.current = false;
      }, 150);
    } else {
      scrubbing.current = false;
      go(target);
    }
    poke();
  };
  const onScrubChange = (v: number) => {
    poke();
    if (!dragging.current) return commitScrub(v);
    scrubbing.current = true;
    setScrub(v);
    if (mode === "scroll") scrollToPage(v);
  };
  const shown = Math.min(scrub ?? index, Math.max(0, n - 1));

  // ---- direct export (current page or full comic) -----------------------------------------------------------------
  const handleExportPage = async () => {
    setExportOpen(false);
    setExporting("page");
    try {
      const res = await api.exportPage(readerId, shown);
      if (res.cancelled) return;
      if (res.ok) toast(`Exported page ${shown + 1}${res.filename ? ` (${res.filename})` : ""}`);
      else toast("Could not export page", "error");
    } catch (e) {
      toast((e as Error)?.message || "Could not export page", "error");
    } finally {
      setExporting(null);
    }
  };

  const handleExportComic = async () => {
    setExportOpen(false);
    setExporting("comic");
    try {
      const res = await api.exportComic(readerId);
      if (res.cancelled) return;
      if (res.ok) toast(`Exported comic (${res.pages ?? n} pages)`);
      else toast("Could not export comic", "error");
    } catch (e) {
      toast((e as Error)?.message || "Could not export comic", "error");
    } finally {
      setExporting(null);
    }
  };

  const page = pages?.[Math.min(index, Math.max(0, (pages?.length ?? 1) - 1))];
  const title = comic?.name ?? "";
  const barCls = cn("absolute inset-x-0 z-10 flex bg-[#1d1b3b]/92 px-3 text-white backdrop-blur-sm transition-opacity duration-200", controls ? "opacity-100" : "pointer-events-none opacity-0");
  const imgFit = fit === "width" ? "w-full h-auto" : "max-h-full max-w-full object-contain";
  const isZoomed = zoom.s > 1;
  const activeZoom = mode === "scroll" ? scrollZoom : zoom.s;

  return (
    <div className="fixed inset-0 z-[60] bg-black text-white" role="dialog" aria-label={`Reading ${title}`} onPointerMove={(e) => e.pointerType === "mouse" && poke()}>
      <div className={cn(barCls, "top-0 safe-t min-h-14 items-center gap-1 border-b-[2.5px] border-[#0e0d22]")} onPointerDown={(e) => e.stopPropagation()}>
        <Button variant="ghost" size="icon" aria-label="Close reader" onClick={close} faceClassName="text-white [@media(hover:hover)]:group-hover:bg-white/15"><X /></Button>
        <div className="min-w-0 flex-1">
          <div className="truncate text-[15px] font-medium" title={title}>{title}</div>
          <div className="text-xs text-white/70">{n > 0 ? `Page ${shown + 1} of ${n}` : "No pages"}</div>
        </div>
        {pages && pages.length > 0 && (
          <div className="flex items-center gap-0.5">
            <Button
              variant="ghost"
              size="icon"
              aria-label="Zoom out"
              title="Zoom out"
              disabled={activeZoom <= 1.01}
              onClick={() => {
                if (mode === "scroll") applyScrollZoom(scrollZoomRef.current - 0.5);
                else setZoom((z) => clampZoom(z.s - 0.5, z.s <= 1.5 ? 0 : z.x, z.s <= 1.5 ? 0 : z.y));
                poke();
              }}
              faceClassName="text-white [@media(hover:hover)]:group-hover:bg-white/15"
            >
              <Minus />
            </Button>
            {activeZoom > 1.01 && (
              <Button
                variant="ghost"
                size="sm"
                aria-label="Reset zoom"
                title="Reset zoom to 100%"
                onClick={() => {
                  if (mode === "scroll") applyScrollZoom(1);
                  else setZoom({ s: 1, x: 0, y: 0 });
                  poke();
                }}
                faceClassName="text-white px-2 [@media(hover:hover)]:group-hover:bg-white/15"
              >
                {Math.round(activeZoom * 100)}%
              </Button>
            )}
            <Button
              variant="ghost"
              size="icon"
              aria-label="Zoom in"
              title="Zoom in"
              disabled={activeZoom >= MAX_ZOOM}
              onClick={() => {
                if (mode === "scroll") applyScrollZoom(scrollZoomRef.current + 0.5);
                else setZoom((z) => clampZoom(z.s + 0.5, z.x, z.y));
                poke();
              }}
              faceClassName="text-white [@media(hover:hover)]:group-hover:bg-white/15"
            >
              <Plus />
            </Button>
          </div>
        )}
        {pages && pages.length > 0 && (
          <div className="relative">
            <Button
              variant="ghost"
              size="icon"
              aria-label="Export page or comic"
              aria-expanded={exportOpen}
              title="Export page or comic"
              disabled={exporting !== null}
              onClick={() => {
                setExportOpen((v) => !v);
                poke();
              }}
              faceClassName="text-white [@media(hover:hover)]:group-hover:bg-white/15"
            >
              {exporting ? <Loader2 className="animate-spin" /> : <Download />}
            </Button>
            {exportOpen && (
              <div
                role="menu"
                aria-label="Export options"
                className="absolute right-0 top-12 z-30 flex w-56 flex-col gap-1 rounded-[20px] border-[2.5px] border-[#0e0d22] bg-[#252250] p-2 text-white shadow-[0_6px_0_#0e0d22]"
              >
                <button
                  type="button"
                  role="menuitem"
                  onClick={() => void handleExportPage()}
                  className="flex h-10 w-full items-center gap-2.5 rounded-full px-3 text-left text-[13px] font-bold hover:bg-white/10 active:bg-white/20"
                >
                  <ImageDown className="size-4 shrink-0 text-butter" />
                  <span className="truncate">Export page {shown + 1}</span>
                </button>
                <button
                  type="button"
                  role="menuitem"
                  onClick={() => void handleExportComic()}
                  className="flex h-10 w-full items-center gap-2.5 rounded-full px-3 text-left text-[13px] font-bold hover:bg-white/10 active:bg-white/20"
                >
                  <FileArchive className="size-4 shrink-0 text-mint" />
                  <span className="truncate">Export full comic (.cbz)</span>
                </button>
              </div>
            )}
          </div>
        )}
        {mode !== "scroll" && (
          <Button variant="ghost" size="icon" aria-label={fit === "width" ? "Fit whole page" : "Fit page width"} title={fit === "width" ? "Fit whole page" : "Fit page width"} onClick={() => { setSettings({ fit: (fit === "width" ? "height" : "width") as FitMode }); setZoom({ s: 1, x: 0, y: 0 }); }} faceClassName="text-white [@media(hover:hover)]:group-hover:bg-white/15">
            {fit === "width" ? <MoveVertical /> : <ArrowLeftRight />}
          </Button>
        )}
        <Button variant="ghost" size="icon" aria-label="Toggle fullscreen" title="Fullscreen (F)" onClick={toggleFull} className="hidden md:inline-flex" faceClassName="text-white [@media(hover:hover)]:group-hover:bg-white/15">{full ? <Shrink /> : <Expand />}</Button>
      </div>

      {!pages ? (
        <div className="flex size-full items-center justify-center text-sm text-white/70">Loading pages</div>
      ) : loadError ? (
        <div className="flex size-full flex-col items-center justify-center gap-3 px-6 text-center">
          <div className="font-display text-lg text-peach">Could not open comic</div>
          <p className="max-w-xs text-sm text-white/75">{loadError}</p>
          <div className="flex gap-2">
            <Button variant="outline" onClick={close}>Close</Button>
            <Button onClick={loadPages}><RefreshCw />Retry</Button>
          </div>
        </div>
      ) : pages.length === 0 ? (
        <div className="flex size-full flex-col items-center justify-center gap-3 px-6 text-center">
          <div className="font-display text-lg">No pages found</div>
          <p className="max-w-xs text-sm text-white/75">This comic folder has no readable images, or storage permission was revoked.</p>
          <Button variant="outline" onClick={close}>Close</Button>
        </div>
      ) : mode === "scroll" ? (
        <div
          ref={scrollRef}
          className={cn("reader-strip relative size-full overscroll-contain", scrollZoom > 1 ? "overflow-auto" : "overflow-y-auto overflow-x-hidden")}
          style={{ touchAction: scrollZoom > 1 ? "pan-x pan-y" : "pan-y" }}
          onTouchStart={onScrollTouchStart}
          onTouchMove={onScrollTouchMove}
          onTouchEnd={onScrollTouchEnd}
          onTouchCancel={onScrollTouchEnd}
          onClick={onScrollClick}
        >
          <div
            ref={stripInnerRef}
            className={cn(scrollZoom <= 1 && "mx-auto max-w-3xl")}
            style={scrollZoom > 1 ? { width: `${scrollZoom * 100}%`, maxWidth: "none" } : undefined}
          >
            {pages.map((p, i) => (
              <div key={p.name} data-page={i} className="block w-full leading-[0]" style={loadedPages.has(i) ? undefined : { minHeight: "60dvh", background: "#17152f" }}>
                <PageImage
                  url={p.url}
                  fallbackUrl={p.fallbackUrl}
                  lazy={Math.abs(i - initial.current) > 2}
                  onLoad={onStripImageLoad(i)}
                  onFail={() => markLoaded(i)}
                  className="block h-auto w-full"
                />
                {i < pages.length - 1 && (
                  <div className="h-2.5 w-full border-y border-white/15 bg-black" aria-hidden="true" />
                )}
              </div>
            ))}
            <div className="py-10 text-center text-sm text-white/60">End of comic</div>
          </div>
        </div>
      ) : (
        <div
          ref={viewportRef}
          className="relative size-full select-none overflow-hidden"
          style={{ touchAction: !isZoomed && fit === "width" ? "pan-y" : "none" }}
          onPointerDown={onDown}
          onPointerMove={onMove}
          onPointerUp={onUp}
          onPointerCancel={onCancel}
        >
          <div className={cn("size-full", fit === "width" && !isZoomed ? "overflow-y-auto overscroll-contain" : "overflow-hidden")}>
            <div
              className="flex min-h-full w-full items-center justify-center"
              style={{
                height: fit === "height" || isZoomed ? "100%" : undefined,
                transform: isZoomed ? `translate3d(${zoom.x}px, ${zoom.y}px, 0) scale(${zoom.s})` : "translate3d(0, 0, 0) scale(1)",
                transformOrigin: "center center",
                willChange: isZoomed ? "transform" : "auto",
                backfaceVisibility: "hidden",
                WebkitBackfaceVisibility: "hidden",
                transition: pinch.current || drag.current ? "none" : "transform 160ms ease-out",
              }}
            >
              {page && <PageImage key={page.url} url={page.url} fallbackUrl={page.fallbackUrl} className={cn("block", imgFit)} />}
            </div>
          </div>
          {mode === "auto" && (
            <div className="pointer-events-none absolute bottom-24 right-4 flex items-center gap-2 rounded-full bg-black/60 py-1 pl-2 pr-3 text-xs text-white/80" aria-label={`Next page in ${Math.ceil(remain * settings.autoNextSec)} seconds`}>
              <svg width="18" height="18" viewBox="0 0 18 18" aria-hidden><circle cx="9" cy="9" r="7" fill="none" stroke="currentColor" strokeOpacity=".25" strokeWidth="2" /><circle cx="9" cy="9" r="7" fill="none" stroke="currentColor" strokeWidth="2" strokeDasharray={44} strokeDashoffset={44 * (1 - remain)} transform="rotate(-90 9 9)" /></svg>
              {held ? "Paused" : `${Math.ceil(remain * settings.autoNextSec)}s`}
            </div>
          )}
          <button aria-label="Previous page" onClick={(e) => { e.stopPropagation(); go(index - 1); }} onPointerDown={(e) => e.stopPropagation()} className={cn("absolute left-2 top-1/2 hidden size-11 -translate-y-1/2 items-center justify-center rounded-full bg-black/50 text-white transition-opacity md:flex", controls ? "opacity-100" : "opacity-0")}><ChevronLeft /></button>
          <button aria-label="Next page" onClick={(e) => { e.stopPropagation(); go(index + 1); }} onPointerDown={(e) => e.stopPropagation()} className={cn("absolute right-2 top-1/2 hidden size-11 -translate-y-1/2 items-center justify-center rounded-full bg-black/50 text-white transition-opacity md:flex", controls ? "opacity-100" : "opacity-0")}><ChevronRight /></button>
        </div>
      )}

      <div className={cn(barCls, "bottom-0 safe-b flex-col gap-1.5 border-t-[2.5px] border-[#0e0d22] py-2")} onPointerDown={(e) => e.stopPropagation()}>
        <div className="flex w-full items-center gap-2">
          <button
            type="button"
            aria-label="Previous page"
            disabled={shown <= 0}
            onClick={() => {
              const target = Math.max(0, shown - 1);
              if (mode === "scroll") {
                restoring.current = false;
                initial.current = target;
                scrollToPage(target);
                setIndex(target);
              } else {
                go(target);
              }
              poke();
            }}
            className="flex size-9 shrink-0 items-center justify-center rounded-full border-2 border-[#0e0d22] bg-[#252250] text-white disabled:opacity-40 active:scale-90 active:bg-white/20"
          >
            <ChevronLeft className="size-4" />
          </button>
          <span className="w-9 text-right text-xs tabular-nums text-white/80">{n > 0 ? shown + 1 : 0}</span>
          <input
            type="range"
            min={0}
            max={Math.max(0, n - 1)}
            step={1}
            value={shown}
            onChange={(e) => onScrubChange(+e.target.value)}
            onPointerDown={(e) => { e.stopPropagation(); dragging.current = true; scrubbing.current = true; poke(); }}
            onPointerUp={(e) => { e.stopPropagation(); if (dragging.current) commitScrub(scrub ?? index); }}
            onPointerCancel={() => { if (dragging.current) commitScrub(scrub ?? index); }}
            onKeyDown={(e) => e.stopPropagation()}
            aria-label="Page scrubber"
            aria-valuetext={`Page ${shown + 1} of ${n}`}
            style={{ "--p": n > 1 ? shown / (n - 1) : 0 } as React.CSSProperties}
            className="scrubber min-w-0 flex-1"
          />
          <span className="w-9 text-xs tabular-nums text-white/80">{n}</span>
          <button
            type="button"
            aria-label="Next page"
            disabled={shown >= n - 1}
            onClick={() => {
              const target = Math.min(n - 1, shown + 1);
              if (mode === "scroll") {
                restoring.current = false;
                initial.current = target;
                scrollToPage(target);
                setIndex(target);
              } else {
                go(target);
              }
              poke();
            }}
            className="flex size-9 shrink-0 items-center justify-center rounded-full border-2 border-[#0e0d22] bg-[#252250] text-white disabled:opacity-40 active:scale-90 active:bg-white/20"
          >
            <ChevronRight className="size-4" />
          </button>
          {mode === "auto" && (
            <select value={settings.autoNextSec} onChange={(e) => setSettings({ autoNextSec: +e.target.value })} aria-label="Seconds per page" className="h-9 rounded-full border-2 border-[#0e0d22] bg-[#252250] px-2.5 text-xs font-bold text-white">
              {SECONDS.map((v) => <option key={v} value={v}>{v} s</option>)}
            </select>
          )}
        </div>
        <div role="radiogroup" aria-label="Reading mode" className="grid w-full grid-cols-3 gap-1 rounded-full border-[2.5px] border-[#0e0d22] bg-[#252250] p-1">
          {MODES.map((m) => (
            <button key={m.value} role="radio" aria-checked={mode === m.value} title={MODE_HINT[m.value]} onClick={() => { setSettings({ readerMode: m.value }); initial.current = index; setZoom({ s: 1, x: 0, y: 0 }); setScrollZoom(1); poke(); }} className={cn("flex h-11 min-w-0 touch-manipulation items-center justify-center gap-1.5 rounded-full border-2 px-1 text-[13px] font-bold transition-colors", mode === m.value ? "border-[#0e0d22] bg-butter text-on" : "border-transparent text-white/80 active:bg-white/15")}>
              <m.icon className="size-4 shrink-0" /><span className="truncate">{m.label}</span>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
