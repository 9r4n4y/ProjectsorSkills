// npm run build:apk  ->  release/Folio-v3.4-debug.apk (signed with the Android debug key, installable directly)
import { spawnSync } from "node:child_process";
import fs from "node:fs";
import path from "node:path";

const root = path.resolve(path.dirname(new URL(import.meta.url).pathname.replace(/^\/([A-Za-z]:)/, "$1")), "..");
const run = (cmd, args, cwd = root) => {
  const r = spawnSync(cmd, args, { cwd, stdio: "inherit", shell: process.platform === "win32" });
  if (r.status !== 0) {
    console.error(`\nCommand failed: ${cmd} ${args.join(" ")}\nSee the Troubleshooting section of README.md.`);
    process.exit(r.status ?? 1);
  }
};

if (!process.env.ANDROID_HOME && !process.env.ANDROID_SDK_ROOT) {
  console.error("ANDROID_HOME is not set. Install the Android SDK and set ANDROID_HOME (README, section 'Build the Android APK').");
  process.exit(1);
}
run("node", ["scripts/prepare-android.mjs"]);
const gradlew = process.platform === "win32" ? "gradlew.bat" : "./gradlew";
run(gradlew, ["assembleDebug"], path.join(root, "android"));
const apk = path.join(root, "android/app/build/outputs/apk/debug/app-debug.apk");
fs.mkdirSync(path.join(root, "release"), { recursive: true });
fs.copyFileSync(apk, path.join(root, "release/Folio-v3.4-debug.apk"));
console.log("\nDone: release/Folio-v3.4-debug.apk");
