# Garlic Bread

:::quick-info
Common name: Cheesy Garlic Bread
Serves: 4
Time: 15 minutes
Often paired with: [[Quick Vegetable Pasta for Weeknights]]
:::

The standard side dish for any pasta night. A baguette, butter, garlic and
a hot oven — ready faster than the pasta takes to boil.

## Ingredients

- 1 baguette
- 100 g soft butter
- 4 garlic cloves, crushed
- 60 g cheddar, grated (optional)
- Parsley, chopped

## Method

1. Heat the oven to 200 °C.
2. Mix the butter with the crushed garlic and most of the parsley.
3. Slice the baguette almost through, spread the garlic butter between the
   slices, and wrap loosely in foil.
4. Bake for 10 minutes, open the foil, add the cheese if using, and bake
   5 minutes more until golden.

## My notes

- Crushed garlic beats chopped garlic here — it spreads into the butter.

## Connected notes

[[Quick Vegetable Pasta for Weeknights]]

## Reference sources

:::meta
Status: verified
Created: 2026-10-16
Updated: 2026-10-31
:::
e