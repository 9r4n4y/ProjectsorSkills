"""SecondBrain core: the health check (spec 18).

Lists: broken links, notes with no tags, tags used once, near-duplicate
tags, notes with no connections, and any file outside the allowed structure.
"""
from __future__ import annotations

from . import indexer, paths, store, tags as tags_mod
from .textutil import key_of


def health_check(idx: dict | None = None) -> dict:
    if idx is None:
        idx = indexer.load_index()
    extractor = tags_mod.extract_all_notes_tags()
    files = idx["files"]

    broken = [{"note": rp, "link": name}
              for rp, names in idx.get("broken_links", {}).items() for name in names]

    no_tags = [rp for rp, e in files.items() if not e["tags"]]
    no_connections = [rp for rp in files
                      if not idx["graph"].get(rp)
                      and not idx["backlinks"].get(rp)]
    no_meta = [rp for rp, e in files.items()
               if not e["meta"].get("created") or not e["meta"].get("updated")]
    unverified = [rp for rp, e in files.items()
                  if e["status"] != "verified"]

    # Unreferenced images (kept in backup history after crop/delete).
    stray_attachments = []
    for md in store.list_note_files():
        att = md.parent / "attachments"
        if not att.exists():
            continue
        used = set()
        text = md.read_text(encoding="utf-8")
        for m in __import__("re").finditer(r"\((?:attachments/)?([^)]+)\)", text):
            used.add(m.group(1).split("/")[-1])
        doc_m = __import__("re").search(r"Image:\s*(\S+)", text)
        if doc_m:
            used.add(doc_m.group(1).split("/")[-1])
        for img in att.iterdir():
            if img.is_file() and img.name not in used:
                stray_attachments.append({"note": paths.rel(md), "file": img.name,
                                          "reason": "image not referenced in the note"
                                                    " (kept as backup history)"})

    structure = paths.check_structure()

    return {
        "summary": {
            "notes": len(files),
            "broken_links": len(broken),
            "notes_without_tags": len(no_tags),
            "notes_without_connections": len(no_connections),
            "tags_used_once": len(extractor["used_once"]),
            "near_duplicate_tags": len(extractor["near_duplicates"]),
            "unapproved_tags": len(extractor["unapproved"]),
            "structure_problems": len(structure),
            "unverified_notes": len(unverified),
        },
        "broken_links": broken,
        "notes_without_tags": no_tags,
        "notes_without_connections": no_connections,
        "tags_used_once": extractor["used_once"],
        "near_duplicate_tags": extractor["near_duplicates"],
        "unapproved_tags": extractor["unapproved"],
        "tags_missing_from_master": extractor["missing_from_master"],
        "proposed_tags": extractor["proposed"],
        "structure_problems": structure,
        "notes_without_dates": no_meta,
        "unreferenced_attachments": stray_attachments,
    }
