"""SecondBrain core: the index.

Files are the truth; the index is only a cache and can always be rebuilt
(spec 17). Every file is hashed; only notes whose hash changed are
re-parsed. The index holds:

- per-note parsed data (title, aliases, headings, body tokens with
  positions and section spans, tags, quick info rows, connections,
  references, metadata),
- an inverted word index for body, headings, title and tags,
- document frequencies and average lengths for BM25,
- the connection graph (for backlinks, neighbors and the website graph),
- deletion buckets for typo tolerance (one wrong letter for words of
  five or more letters, spec 3.3 B).
"""
from __future__ import annotations

import json
import re
from pathlib import Path

from . import paths, store, tags as tags_mod
from .parser import (parse_note, qi_aliases, qi_label_rows, qi_value_rows)
from .textutil import deletion_variants, key_of, normalize, stem, tokenize


def stem_tokens(tokens: list[str]) -> list[str]:
    """Index tokens are stored as stems so plurals and endings match
    (spec 3.3 step 1: recipe/recipes)."""
    return [stem(t) for t in tokens]


INDEX_VERSION = 5


def _cache_path() -> Path:
    return paths.CACHE / "index.json"


def _walk_notes():
    for md in sorted(paths.DATABASE.rglob("*.md")):
        if md.name == "_subject.md":
            continue
        if md.parent.name != md.stem:
            continue
        if store.is_private(md.parent):
            continue        # restricted private folders are excluded
        yield md


def _empty_note_entry(rel_path: str) -> dict:
    return {
        "hash": "", "title": "", "folder": "", "folder_path": "",
        "headings": [], "heading_text": "", "title_tokens": [],
        "tokens": [], "section_spans": [], "tags": [], "tag_text": "",
        "aliases": [], "qi_labels": [], "connected": [], "linked_in_text": [],
        "references": [], "meta": {}, "status": "unverified",
        "updated": "", "created": "", "pinned": "no", "snippet_text": "",
        "image": None, "words": {}, "heading_words": {},
    }


def build_index(force: bool = False, log=None) -> dict:
    """Load or build the index incrementally, then return it."""
    paths.CACHE.mkdir(parents=True, exist_ok=True)
    idx = None
    if not force and _cache_path().exists():
        try:
            data = json.loads(_cache_path().read_text(encoding="utf-8"))
            if data.get("version") == INDEX_VERSION:
                idx = data
        except (json.JSONDecodeError, OSError):
            idx = None
    if idx is None:
        idx = {"version": INDEX_VERSION, "files": {}, "generated": ""}
        if log:
            log("Index missing or damaged; rebuilt from the files (spec 3.4).")

    files = idx["files"]
    changed = []
    for md in _walk_notes():
        rp = paths.rel(md)
        h = store.sha256_of(md)
        entry = files.get(rp)
        if entry is None or entry.get("hash") != h:
            entry = _index_one(md, rp, h)
            files[rp] = entry
            changed.append(rp)
        # tags.txt can change without the .md changing
        tags_file = md.parent / "tags.txt"
        th = store.sha256_of(tags_file) if tags_file.exists() else ""
        if entry.get("tags_hash") != th:
            entry["tags_hash"] = th
            entry["tags"] = tags_mod.parse_tags_txt(
                tags_file.read_text(encoding="utf-8")) if tags_file.exists() else []
            entry["tag_text"] = " ".join(
                normalize(t.replace("_", " ").replace("-", " ")) for t in entry["tags"])
            changed.append(rp) if rp not in changed else None

    # Drop deleted notes.
    live = {paths.rel(md) for md in _walk_notes()}
    for rp in list(files):
        if rp not in live:
            del files[rp]
            changed.append(rp)

    _derive(idx)
    idx["generated"] = store.now_iso()
    tmp = _cache_path().with_suffix(".tmp")
    tmp.write_text(json.dumps(idx, ensure_ascii=False), encoding="utf-8", newline="\n")
    tmp.replace(_cache_path())
    idx["changed_notes"] = changed
    return idx


def rebuild_index() -> dict:
    """Discard the cache and rebuild everything from the files (guard rail,
    spec 3.4)."""
    if _cache_path().exists():
        _cache_path().unlink()
    return build_index(force=True)


def _index_one(md: Path, rp: str, h: str) -> dict:
    text = md.read_text(encoding="utf-8")
    doc = parse_note(text, rp)
    e = _empty_note_entry(rp)
    e["hash"] = h
    e["title"] = doc.title
    folder = md.parent.parent
    e["folder"] = paths.rel(folder).removeprefix("database/")
    e["folder_path"] = " ".join(stem_tokens(tokenize(
        normalize(e["folder"].replace("/", " ")))))
    e["title_tokens"] = stem_tokens(tokenize(normalize(doc.title)))
    e["headings"] = [t for _, t in doc.headings]
    e["heading_text"] = normalize(" ".join(
        e["headings"] + qi_label_rows(doc.quick_info_rows)))
    e["aliases"] = [normalize(a) for a in qi_aliases(doc.quick_info_rows)]

    # Body tokens + section spans for closeness. Tokens are stems.
    tokens: list[str] = []
    spans: list[tuple[int, int]] = []
    plain: list[str] = []
    for para in re.split(r"\n\s*\n", doc.body):
        start = len(tokens)
        tokens.extend(stem_tokens(tokenize(para)))
        spans.append((start, len(tokens)))
        plain.append(para)
    # quick info values count like body text (spec 13)
    qv = " ".join(qi_value_rows(doc.quick_info_rows))
    if qv:
        start = len(tokens)
        tokens.extend(stem_tokens(tokenize(qv)))
        spans.append((start, len(tokens)))
        plain.append(qv)
    e["tokens"] = tokens
    e["section_spans"] = spans
    e["snippet_text"] = normalize(" ".join(plain))
    e["words"] = _tf(tokens)
    e["heading_words"] = _tf(stem_tokens(tokenize(e["heading_text"])))

    tags_file = md.parent / "tags.txt"
    e["tags_hash"] = store.sha256_of(tags_file) if tags_file.exists() else ""
    e["tags"] = tags_mod.parse_tags_txt(
        tags_file.read_text(encoding="utf-8")) if tags_file.exists() else []
    e["tag_text"] = " ".join(stem_tokens(tokenize(
        " ".join(t.replace("_", " ").replace("-", " ") for t in e["tags"]))))
    e["connected"] = doc.connected
    e["linked_in_text"] = [t for t, _w in doc.linked_in_text]
    e["references"] = doc.references
    e["meta"] = doc.meta
    e["status"] = doc.meta.get("status", "unverified")
    e["updated"] = doc.meta.get("updated", "")
    e["created"] = doc.meta.get("created", "")
    e["pinned"] = doc.meta.get("pinned", "no").lower() == "yes"
    e["image"] = doc.quick_info_rows and next(
        (r.value.strip() for r in doc.quick_info_rows if r.label.lower() == "image"), None)
    return e


def _tf(tokens: list[str]) -> dict[str, int]:
    tf: dict[str, int] = {}
    for t in tokens:
        tf[t] = tf.get(t, 0) + 1
    return tf


def _derive(idx: dict):
    """Build derived structures: df, avgdl, graph, backlinks, typo buckets."""
    files = idx["files"]
    N = len(files)
    idx["N"] = N

    df: dict[str, int] = {}
    h_df: dict[str, int] = {}
    dl_sum = 0
    h_dl_sum = 0
    for e in files.values():
        for w in e["words"]:
            df[w] = df.get(w, 0) + 1
        for w in e["heading_words"]:
            h_df[w] = h_df.get(w, 0) + 1
        dl_sum += len(e["tokens"])
        h_dl_sum += sum(e["heading_words"].values())
    idx["df"] = df
    idx["h_df"] = h_df
    idx["avgdl"] = (dl_sum / N) if N else 0.0
    idx["h_avgdl"] = (h_dl_sum / N) if N else 0.0

    # Connection graph (explicit + linked-in-text), resolved by file name.
    by_title: dict[str, str] = {}
    for rp, e in files.items():
        by_title[key_of(e["title"])] = rp
    graph: dict[str, list[str]] = {}
    broken: dict[str, list[str]] = {}
    for rp, e in files.items():
        targets = []
        for name in list(e["connected"]) + list(e["linked_in_text"]):
            tgt = by_title.get(key_of(name))
            if tgt and tgt != rp:
                targets.append(tgt)
            elif not tgt:
                broken.setdefault(rp, [])
                if name not in broken[rp]:
                    broken[rp].append(name)
        graph[rp] = sorted(set(targets))
    idx["graph"] = graph
    idx["broken_links"] = broken
    backlinks: dict[str, list[str]] = {rp: [] for rp in files}
    for rp, targets in graph.items():
        for t in targets:
            backlinks.setdefault(t, [])
            backlinks[t].append(rp)
    idx["backlinks"] = {k: sorted(set(v)) for k, v in backlinks.items()}

    # Tag -> notes map (for tag hits, neighbors and fallback).
    tag_map: dict[str, list[str]] = {}
    for rp, e in files.items():
        for t in e["tags"]:
            tag_map.setdefault(key_of(t), []).append(rp)
            # parents also index the note (a deep tag counts for its parents)
            for p in tags_mod.parents_of(t):
                tag_map.setdefault(key_of(p), []).append(rp)
    idx["tag_map"] = {k: sorted(set(v)) for k, v in tag_map.items()}

    # Deletion buckets for typo tolerance (words of 5+ letters).
    buckets: dict[str, list[str]] = {}
    vocab = set(df) | set(h_df)
    for w in vocab:
        if len(w) >= 5:
            for d in deletion_variants(w):
                buckets.setdefault(d, []).append(w)
    idx["typo_buckets"] = buckets


def load_index(force_reload: bool = False) -> dict:
    """Public entry used by the website and MCP: fresh enough on every call.
    Checks the manifest quickly - only changed files are re-parsed."""
    return build_index(force=force_reload)
