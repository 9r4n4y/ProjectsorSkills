"""SecondBrain local website (spec 4, 9, 10, 11, 12).

A thin layer over the core engine: one search engine serves the website and
the MCP server, so results are identical. The website scans the Markdown
files through the index and exposes a JSON API for everything the user can
do - search with modes and filters, reading, editing, tags, folders, images,
quick info, connections, references, metadata, logs and undo, health check,
saved searches and the backup tool.

Local only: the server listens on this computer by default (server_bind in
core/settings.json). Opening it to the home network is an explicit setting.

Run:  python3 website/server.py [--port 8765] [--no-browser] [--rebuild]
"""
from __future__ import annotations

import argparse
import base64
import json
import sys
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse, parse_qs, unquote

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from core import healthcheck, images, indexer, logger, paths, search, store  # noqa: E402
from core import tags as tags_mod  # noqa: E402

STATIC = Path(__file__).resolve().parent / "static"
MIME = {".html": "text/html", ".css": "text/css", ".js": "application/javascript",
        ".json": "application/json", ".png": "image/png", ".jpg": "image/jpeg",
        ".jpeg": "image/jpeg", ".gif": "image/gif", ".webp": "image/webp",
        ".svg": "image/svg+xml", ".woff": "font/woff", ".woff2": "font/woff2",
        ".ttf": "font/ttf", ".txt": "text/plain", ".map": "application/json"}


def jdump(obj) -> bytes:
    return json.dumps(obj, ensure_ascii=False).encode("utf-8")


def note_view(md_path: Path) -> dict:
    """Everything the note page needs: parsed blocks, panels, backlinks,
    rendered pieces and the raw text with its hash for safe editing."""
    rp = paths.rel(md_path)
    doc = store.parse_note(md_path.read_text(encoding="utf-8"), rp)
    idx = indexer.load_index()
    backlinks = idx["backlinks"].get(rp, [])
    atts = []
    att_dir = md_path.parent / "attachments"
    if att_dir.exists():
        atts = sorted(p.name for p in att_dir.iterdir() if p.is_file())
    return {
        "path": rp,
        "folder": md_path.parent.parent.relative_to(paths.DATABASE).as_posix()
        if md_path.parent.parent != paths.DATABASE else "",
        "title": doc.title,
        "raw": doc.raw,
        "hash": store.text_sha256(doc.raw),
        "quick_info_raw": doc.quick_info_raw,
        "quick_info_rows": [{"label": r.label, "value": r.value, "group": r.group}
                            for r in doc.quick_info_rows],
        "headings": doc.headings,
        "body": doc.body,
        "connected": doc.connected,
        "linked_in_text": [{"target": t, "word": w} for t, w in doc.linked_in_text],
        "references": doc.references,
        "meta": doc.meta,
        "my_notes": doc.my_notes,
        "backlinks": backlinks,
        "attachments": atts,
        "pinned": doc.meta.get("pinned", "no").lower() == "yes",
        "status": doc.meta.get("status", "unverified"),
    }


class Handler(BaseHTTPRequestHandler):
    server_version = "SecondBrain/1.0"

    # ------------------------------------------------------------ plumbing
    def log_message(self, fmt, *args):        # quiet
        pass

    def _json(self, obj, status=200):
        data = jdump(obj)
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(data)

    def _err(self, e: Exception, status=400):
        self._json({"error": str(e), "type": type(e).__name__}, status)

    def _body(self) -> dict:
        n = int(self.headers.get("Content-Length") or 0)
        if n <= 0:
            return {}
        raw = self.rfile.read(min(n, 64 * 1024 * 1024))
        return json.loads(raw.decode("utf-8"))

    def _file(self, p: Path, cache=False):
        if not p.exists() or not p.is_file():
            self._json({"error": "not found"}, 404)
            return
        data = p.read_bytes()
        self.send_response(200)
        self.send_header("Content-Type",
                         MIME.get(p.suffix.lower(), "application/octet-stream"))
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control",
                         "no-cache" if cache else "no-store")
        self.end_headers()
        self.wfile.write(data)

    # -------------------------------------------------------------- routes
    def do_GET(self):
        try:
            u = urlparse(self.path)
            route = unquote(u.path)
            q = {k: v for k, v in parse_qs(u.query).items()}
            one = lambda k, d="": (q.get(k, [d])[0] if q.get(k) else d)  # noqa: E731
            many = lambda k: q.get(k, [])[0].split(",") if q.get(k) else []  # noqa: E731

            if route == "/" or route == "/index.html":
                return self._file(STATIC / "index.html")
            if route.startswith("/static/"):
                rp = (STATIC / route.removeprefix("/static/")).resolve()
                if not str(rp).startswith(str(STATIC)):
                    return self._json({"error": "forbidden"}, 403)
                return self._file(rp, cache=True)
            if route.startswith("/files/"):
                # note attachments, addressed through the database
                rel = route.removeprefix("/files/")
                p = (paths.ROOT / rel).resolve()
                db = paths.DATABASE.resolve()
                if not str(p).startswith(str(db)):
                    return self._json({"error": "forbidden"}, 403)
                return self._file(p, cache=True)

            if route == "/thumb":
                # the image grid uses thumbnails; the full file loads only
                # in full screen (spec 17)
                rel = one("path")
                p = (paths.ROOT / rel).resolve()
                db = paths.DATABASE.resolve()
                if not str(p).startswith(str(db)) or not p.exists():
                    return self._json({"error": "not found"}, 404)
                try:
                    tp = images.thumbnail(p, int(one("w", "480") or 480))
                except Exception:      # noqa: BLE001 - a broken image is not fatal
                    tp = p
                return self._file(tp, cache=True)

            if route == "/api/state":
                idx = indexer.load_index()
                recent = sorted(idx["files"].items(),
                                key=lambda kv: kv[1]["updated"], reverse=True)[:8]
                settings = store.load_settings()
                return self._json({
                    "notes": idx["N"],
                    "recent": [{"path": rp, "title": e["title"], "folder": e["folder"],
                                "updated": e["updated"]} for rp, e in recent],
                    "pinned": [{"path": rp, "title": e["title"], "folder": e["folder"]}
                               for rp, e in idx["files"].items() if e["pinned"]],
                    "saved_searches": settings.get("saved_searches", []),
                    "themes": ["light", "dark", "coffee", "orange"],
                    "port": settings.get("server_port"),
                    "bind": settings.get("server_bind"),
                })

            if route == "/api/search":
                idx = indexer.load_index()
                res = search.search(
                    idx=idx, q=one("q"),
                    mode=one("mode", "rank"),
                    tags_sel=many("tags"),
                    folders=many("folders"),
                    folder_only=one("folder_only") == "1",
                    scope=many("scope") or ["everything"],
                    tag_mode=one("tag_mode", "rank"),
                    kw_mode=one("kw_mode", "rank"),
                    include_connected=one("include_connected") == "1",
                    status=one("status") or None,
                    date_from=one("date_from") or None,
                    date_to=one("date_to") or None,
                    limit_to=[x for x in many("limit_to") if x],
                    offset=int(one("offset", "0") or 0),
                )
                return self._json(res)

            if route == "/api/suggest":
                idx = indexer.load_index()
                return self._json(suggest(idx, one("q"), one("type", "all")))

            if route == "/api/tags":
                ext = tags_mod.extract_all_notes_tags()
                mt = tags_mod.load_master()
                return self._json({
                    "tree": ext["tree"],
                    "rows": tags_mod.tree_to_list(ext["tree"]),
                    "counts": ext["counts"],
                    "unapproved": ext["unapproved"],
                    "proposed": ext["proposed"],
                    "near_duplicates": ext["near_duplicates"],
                    "majors": sorted({v["major"] for v in mt.approved.values()}),
                    "approved": mt.all_tags(),
                    "tag_synonyms": {v["tag"]: v["synonyms"]
                                     for v in mt.approved.values()},
                    "general_synonyms": mt.general_synonyms,
                })

            if route == "/api/folders":
                return self._json({"tree": store.folder_tree(),
                                   "subjects": store.list_subjects()})

            if route == "/api/graph":
                idx = indexer.load_index()
                nodes = [{"id": rp, "title": e["title"], "folder": e["folder"],
                          "tags": e["tags"][:1]} for rp, e in idx["files"].items()]
                edges = sorted({tuple(sorted((a, b)))
                                for a, ts in idx["graph"].items() for b in ts})
                return self._json({"nodes": nodes, "edges": [list(e) for e in edges]})

            if route == "/api/note":
                p = store.note_md_path(one("path"))
                if not p.exists():
                    # allow lookup by note name
                    found = store.note_exists(one("path"))
                    if not found:
                        return self._json({"error": f"Note {one('path')!r} not found."}, 404)
                    p = found
                return self._json(note_view(p))

            if route == "/api/export":
                p = store.note_md_path(one("path"))
                text = store.export_metadata(paths.rel(p))
                data = text.encode("utf-8")
                self.send_response(200)
                self.send_header("Content-Type", "text/plain; charset=utf-8")
                self.send_header("Content-Disposition",
                                 f'attachment; filename="{p.stem}.metadata.txt"')
                self.send_header("Content-Length", str(len(data)))
                self.end_headers()
                return self.wfile.write(data)

            if route == "/api/health":
                return self._json(healthcheck.health_check())

            if route == "/api/logs":
                return self._json({"logs": logger.list_logs(int(one("limit", "100")))})

            if route == "/api/log":
                return self._json({"name": one("name"),
                                   "text": logger.read_log(one("name"))})

            if route == "/api/master_tags":
                return self._json({
                    "text": (paths.ROOT / "_tags.md").read_text(encoding="utf-8")})

            return self._json({"error": f"Unknown route {route}"}, 404)
        except Exception as e:                     # noqa: BLE001
            return self._err(e, 500)

    do_HEAD = do_GET

    def do_POST(self):
        try:
            u = urlparse(self.path)
            route = unquote(u.path)
            b = self._body()
            who = b.get("who", "user")

            if route == "/api/note/create":
                return self._json(store.create_note(
                    b.get("folder", ""), b["name"], b.get("tags") or [],
                    b.get("text"), b.get("quick_info"), who, b.get("reason", "")))

            if route == "/api/note/save":
                return self._json(store.save_note_text(
                    b["path"], b["text"], b.get("base_hash"), who,
                    b.get("force", False), b.get("reason", "")))

            if route == "/api/note/move":
                return self._json(store.move_note(
                    b["path"], b.get("folder", ""), b.get("name"), who))

            if route == "/api/note/append_my_notes":
                return self._json(store.append_to_my_notes(
                    b["path"], b["text"], who, b.get("reason", "")))

            if route == "/api/folder/create":
                return self._json(store.create_folder(
                    b.get("parent", ""), b["name"], who, b.get("subject_md")))

            if route == "/api/folder/rename":
                return self._json(store.rename_folder(b["path"], b["name"], who))

            if route == "/api/folder/move":
                return self._json(store.move_folder(
                    b["path"], b.get("parent", ""), who))

            if route == "/api/folder/delete":
                return self._json(store.delete_folder(b["path"], who))

            if route == "/api/tags/edit":
                return self._json(store.edit_tags(
                    b["path"], b.get("add"), b.get("remove"), who))

            if route == "/api/tags/rename":
                return self._json(store.rename_tag(
                    b["from"], b["to"], who, run=b.get("run", False)))

            if route == "/api/tags/merge":
                return self._json(store.merge_tags(
                    b["from"], b["into"], who, run=b.get("run", False)))

            if route == "/api/tags/remove":
                return self._json(store.remove_tag_everywhere(
                    b["tag"], who, run=b.get("run", False)))

            if route == "/api/tags/master":
                return self._json(store.edit_master_tags(b["text"], who))

            if route == "/api/quick_info":
                return self._json(store.set_quick_info(b["path"], b.get("text"), who))

            if route == "/api/metadata":
                return self._json(store.set_metadata(b["path"], b.get("meta", {}), who))

            if route == "/api/pin":
                return self._json(store.toggle_pin(b["path"], who))

            if route == "/api/connections":
                return self._json(store.edit_connections(
                    b["path"], b.get("add"), b.get("remove"),
                    b.get("edit_link"), who))

            if route == "/api/references":
                return self._json(store.edit_references(
                    b["path"], b.get("add"), b.get("remove_url"), who))

            if route == "/api/links":
                return self._json(store.edit_links(
                    b["path"], b["word"], b.get("target"),
                    b.get("make_note", True), who))

            if route == "/api/image/add":
                data = base64.b64decode(b["data_base64"])
                return self._json(images.add_attachment(
                    b["path"], b["filename"], data, who))

            if route == "/api/image/crop":
                return self._json(images.crop_image(
                    b["path"], b["filename"], b["rect"], b.get("mode", "keep_both"), who))

            if route == "/api/image/delete":
                return self._json(images.delete_image(b["path"], b["filename"], who))

            if route == "/api/undo":
                return self._json({"log": logger.apply_undo(b["log"], who)})

            if route == "/api/saved_searches/save":
                return self._json(store.save_search(b["name"], b["params"], who))

            if route == "/api/saved_searches/delete":
                return self._json(store.delete_saved_search(b["name"]))

            if route == "/api/backup/preview":
                from backup import backup as bk
                target = Path(b["to"]).expanduser().resolve()
                if b.get("direction", "backup") == "backup":
                    src_m, dst_m = bk.manifest(paths.ROOT, b.get("scope", "whole")), \
                        bk.manifest(target, b.get("scope", "whole"))
                else:
                    src_m, dst_m = bk.manifest(target, b.get("scope", "whole")), \
                        bk.manifest(paths.ROOT, b.get("scope", "whole"))
                return self._json({"compare": bk.compare(src_m, dst_m),
                                   "preview": bk.preview(bk.compare(src_m, dst_m))})

            if route == "/api/backup/run":
                from backup import backup as bk
                rep = bk.run(b.get("direction", "backup"),
                             Path(b["to"]).expanduser().resolve(),
                             b.get("scope", "whole"), approve=True,
                             keep_versions=int(b.get("keep", 10)),
                             log_fn=lambda m: None)
                return self._json(rep)

            if route == "/api/backup/verify":
                from backup import backup as bk
                target = Path(b["to"]).expanduser().resolve()
                ok = bk.verify(target, b.get("scope", "whole"), log_fn=lambda m: None)
                return self._json({"ok": ok})

            if route == "/api/index/rebuild":
                idx = indexer.rebuild_index()
                return self._json({"ok": True, "notes": idx["N"]})

            if route == "/api/settings":
                s = store.load_settings()
                for k, v in (b.get("settings") or {}).items():
                    s[k] = v
                store.save_settings(s)
                return self._json({"ok": True, "settings": s})

            return self._json({"error": f"Unknown route {route}"}, 404)
        except Exception as e:                     # noqa: BLE001
            return self._err(e, 400)


def suggest(idx: dict, q: str, kind: str) -> dict:
    """Type-ahead over existing tags and folders (spec 9.1). Only things
    that really exist can be chosen; the closest names are offered. Tags
    come from the auto tag extractor: every written tag plus every parent
    node of the hierarchy (a deep tag also counts for its parents, spec 8),
    with the note counts the deep-tag rule produces."""
    qn = (q or "").strip().lower().replace(" ", "-")
    out = []
    if kind in ("all", "tag"):
        ext = tags_mod.extract_all_notes_tags()
        rows = tags_mod.tree_to_list(ext["tree"])       # written + parent nodes
        counts = ext["counts"]
        for row in rows:
            t = row["tag"]
            tl = t.lower()
            starts, contains = tl.startswith(qn), (qn in tl) if qn else True
            if not qn or starts or contains:
                out.append({"type": "tag", "name": t,
                            "parent": t.split("-")[0],
                            "count": row.get("count", counts.get(t, 0)),
                            "starts": starts})
    if kind in ("all", "folder"):
        for s in store.list_subjects():
            sl = s["name"].lower()
            starts, contains = sl.startswith(qn), (qn in sl) if qn else True
            if not qn or starts or contains:
                out.append({"type": "folder", "name": s["name"],
                            "parent": s["path"].rsplit("/", 1)[0]
                            if "/" in s["path"] else "database",
                            "count": note_count(s["path"]),
                            "starts": starts})
    out.sort(key=lambda r: (not r["starts"], r["type"], r["name"].lower()))
    return {"suggestions": out[:12]}


def note_count(subject_rel: str) -> int:
    base = paths.DATABASE / subject_rel
    if not base.exists():
        return 0
    return sum(1 for md in base.rglob("*.md")
               if md.name != "_subject.md" and md.parent.name == md.stem)


def main():
    ap = argparse.ArgumentParser(description="SecondBrain local website")
    ap.add_argument("--port", type=int, default=None)
    ap.add_argument("--no-browser", action="store_true")
    ap.add_argument("--rebuild", action="store_true",
                    help="rebuild the index from the files, then start")
    args = ap.parse_args()

    settings = store.load_settings()
    if args.rebuild:
        idx = indexer.rebuild_index()
        print(f"Index rebuilt: {idx['N']} notes.")
    port = args.port or int(settings.get("server_port", 8765))
    bind = settings.get("server_bind", "127.0.0.1")

    server = ThreadingHTTPServer((bind, port), Handler)
    url = f"http://{'localhost' if bind == '127.0.0.1' else bind}:{port}/"
    print(f"SecondBrain website running at {url}  (local only, bind {bind})")
    print("Press Ctrl+C to stop.")
    if not args.no_browser and settings.get("open_browser_on_start", True):
        try:
            webbrowser.open(url)
        except Exception:
            pass
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nStopped.")


if __name__ == "__main__":
    main()
