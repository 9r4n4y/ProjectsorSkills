/* SecondBrain frontend helpers (api.js): fetch wrapper, state, icons,
 * toasts, modals, tag chips, theme and text size. */
(function () {
  "use strict";

  const SB = (window.SB = window.SB || {});

  /* ---------------- API ---------------- */

  async function get(url) {
    const r = await fetch(url);
    const j = await r.json();
    if (!r.ok || j.error) throw new Error(j.error || r.statusText);
    return j;
  }
  async function post(url, body) {
    const r = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body || {}),
    });
    const j = await r.json();
    if (!r.ok || j.error) throw new Error(j.error || r.statusText);
    return j;
  }
  SB.api = { get, post };

  /* ---------------- state ---------------- */

  SB.state = {
    theme: localStorage.getItem("sb-theme") || "light",
    noteSize: parseInt(localStorage.getItem("sb-note-size") || "17", 10),
    route: "",
    lastSearch: null,
  };

  SB.setTheme = function (t) {
    SB.state.theme = t;
    localStorage.setItem("sb-theme", t);
    document.body.className = "theme-" + t;
    document.querySelectorAll(".theme-select").forEach((s) => (s.value = t));
    document.dispatchEvent(new CustomEvent("sb-theme"));
  };
  SB.setNoteSize = function (n) {
    SB.state.noteSize = n;
    localStorage.setItem("sb-note-size", n);
    document.documentElement.style.setProperty("--note-size", n + "px");
  };

  /* ---------------- icons (small, friendly line icons) ---------------- */

  const I = {
    search: '<circle cx="7" cy="7" r="4.5"/><path d="M10.5 10.5 L14 14"/>',
    home: '<path d="M2.5 7.5 L8 2.5 L13.5 7.5"/><path d="M4 7v6h8V7"/>',
    note: '<path d="M4 2.5h6.5L13 5v8.5H4z"/><path d="M10 2.5V5h3M6 8h5M6 10.5h5"/>',
    tag: '<path d="M8.5 2.5H13.5V7.5L7.5 13.5L2.5 8.5z"/><circle cx="10.8" cy="5.2" r="1"/>',
    folder: '<path d="M2.5 4.5v8h11v-6.5H8L6.5 4.5z"/>',
    graph: '<circle cx="4" cy="4" r="1.8"/><circle cx="12" cy="6" r="1.8"/><circle cx="7" cy="12" r="1.8"/><path d="M5.5 5l4.8 .8M11 7.5L8 10.6M5.7 4.8L6.4 10.4"/>',
    health: '<path d="M8 13S2.5 9.5 2.5 5.8C2.5 3.7 4.2 2.5 5.7 2.5c1 0 1.9.5 2.3 1.3C8.4 3 9.3 2.5 10.3 2.5c1.5 0 3.2 1.2 3.2 3.3C13.5 9.5 8 13 8 13z"/>',
    backup: '<rect x="3" y="3" width="10" height="4" rx="1"/><rect x="3" y="9" width="10" height="4" rx="1"/><circle cx="5" cy="5" r=".4"/><circle cx="5" cy="11" r=".4"/>',
    edit: '<path d="M3 13l.8-3L10.5 3.3a1.4 1.4 0 0 1 2 2L5.8 12 3 13z"/>',
    copy: '<rect x="5.5" y="5.5" width="8" height="8" rx="1"/><path d="M10.5 5.5v-2a1 1 0 0 0-1-1h-6a1 1 0 0 0-1 1v6a1 1 0 0 0 1 1h2"/>',
    print: '<path d="M4.5 6V2.5h7V6M4.5 11h-2V6h11v5h-2M4.5 9.5h7V14h-7z"/>',
    download: '<path d="M8 2.5v7M5 7l3 3 3-3M3 13.5h10"/>',
    crop: '<path d="M4 2v10h10M2 4h10v10"/>',
    trash: '<path d="M3.5 4.5h9M6.5 4.5v-2h3v2M5 4.5l.6 9h4.8l.6-9"/>',
    link: '<path d="M6.5 9.5l3-3M5 7L3.6 8.4a2.5 2.5 0 0 0 3.5 3.5L8.5 10.5M7.5 5.5L9 4a2.5 2.5 0 0 1 3.5 3.5L11 9"/>',
    plus: '<path d="M8 3v10M3 8h10"/>',
    pin: '<path d="M8 2.5v6M5 8.5h6l-1.5 3h-3z"/><path d="M8 11.5v2"/>',
    check: '<path d="M3 8.5l3.5 3.5L13 5"/>',
    x: '<path d="M4 4l8 8M12 4l-8 8"/>',
    gear: '<circle cx="8" cy="8" r="2.2"/><path d="M8 2v2M8 12v2M2 8h2M12 8h2M3.8 3.8l1.4 1.4M10.8 10.8l1.4 1.4M12.2 3.8l-1.4 1.4M5.2 10.8l-1.4 1.4"/>',
    eye: '<path d="M1.8 8S4 4 8 4s6.2 4 6.2 4S12 12 8 12 1.8 8 1.8 8z"/><circle cx="8" cy="8" r="1.8"/>',
    undo: '<path d="M3 6h6.5a3.5 3.5 0 1 1 0 7H6"/><path d="M5.5 3.5L3 6l2.5 2.5"/>',
    chev: '<path d="M6 4l4 4-4 4"/>',
    img: '<rect x="2.5" y="3" width="11" height="10" rx="1"/><circle cx="5.8" cy="6.2" r="1.1"/><path d="M3 11l3.5-3 2.5 2 2-1.5 3 2.5"/>',
  };
  SB.icon = function (name, size) {
    return '<svg class="icon" width="' + (size || 16) + '" height="' + (size || 16) +
      '" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">' +
      (I[name] || "") + "</svg>";
  };

  /* ---------------- toasts + modal ---------------- */

  SB.toast = function (msg, kind) {
    let t = document.querySelector(".toast");
    if (!t) {
      t = document.createElement("div");
      t.className = "toast";
      document.body.appendChild(t);
    }
    t.textContent = msg;
    t.className = "toast show " + (kind || "");
    clearTimeout(t._h);
    t._h = setTimeout(() => t.classList.remove("show"), 3200);
  };

  SB.modal = function (title, bodyHTML, buttons) {
    closeModal();
    const wrap = document.createElement("div");
    wrap.className = "modal-wrap";
    wrap.innerHTML =
      '<div class="modal"><div class="modal-head"><span>' + SB.esc(title) +
      '</span><button class="ghost modal-x">' + SB.icon("x") + "</button></div>" +
      '<div class="modal-body">' + bodyHTML + "</div>" +
      '<div class="modal-foot"></div></div>';
    const foot = wrap.querySelector(".modal-foot");
    (buttons || []).forEach((b) => {
      const el = document.createElement("button");
      el.className = b.primary ? "btn primary" : "btn";
      el.textContent = b.label;
      el.onclick = () => {
        const keep = b.onclick && b.onclick(wrap) === false;
        if (!keep) closeModal();
      };
      foot.appendChild(el);
    });
    wrap.querySelector(".modal-x").onclick = closeModal;
    wrap.addEventListener("mousedown", (e) => {
      if (e.target === wrap) closeModal();
    });
    document.body.appendChild(wrap);
    return wrap;
  };
  function closeModal() {
    document.querySelectorAll(".modal-wrap").forEach((m) => m.remove());
  }
  SB.closeModal = closeModal;

  SB.confirm = function (text, onYes) {
    SB.modal("Please confirm", "<p>" + SB.esc(text) + "</p>", [
      { label: "Cancel" },
      { label: "Yes, do it", primary: true, onclick: onYes },
    ]);
  };

  /* ---------------- misc ---------------- */

  SB.esc = function (s) {
    return (s == null ? "" : "" + s).replace(/&/g, "&amp;").replace(/</g, "&lt;")
      .replace(/>/g, "&gt;").replace(/"/g, "&quot;");
  };
  SB.debounce = function (fn, ms) {
    let h;
    return function () {
      clearTimeout(h);
      const a = arguments, self = this;
      h = setTimeout(() => fn.apply(self, a), ms);
    };
  };

  const HUES = {};
  SB.tagHue = function (major) {
    if (!HUES[major]) {
      let h = 0;
      for (const c of major) h = (h * 31 + c.charCodeAt(0)) % 360;
      HUES[major] = h;
    }
    return HUES[major];
  };
  SB.chip = function (tag, extra) {
    const major = tag.split("-")[0];
    const h = SB.tagHue(major);
    const dark = SB.state.theme === "dark";
    const bg = dark ? `hsl(${h} 30% 26%)` : `hsl(${h} 55% 90%)`;
    const fg = dark ? `hsl(${h} 45% 80%)` : `hsl(${h} 45% 30%)`;
    return '<a class="chip ' + (extra || "") + '" style="background:' + bg +
      ";color:" + fg + '" href="#/search?tags=' + encodeURIComponent(tag) + '">' +
      SB.esc(tag) + "</a>";
  };

  SB.fmtDate = function (d) {
    return d ? d : "—";
  };
})();
