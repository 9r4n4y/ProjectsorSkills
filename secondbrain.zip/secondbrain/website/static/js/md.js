/* SecondBrain markdown renderer (md.js)
 * One renderer for view mode, with two special duties:
 *  - every rendered block carries the source lines it came from
 *    (data-sl / data-el) so switching edit <-> preview never moves the view;
 *  - images render exactly where their Markdown was placed, many images
 *    arrange into a tidy grid, and each image can be resized in the viewer.
 * Supported (StructureOFnotes): headings, bold/italic, lists, task lists,
 * tables, code blocks, quotes, footnotes, images, web links, wiki links,
 * horizontal rules, LaTeX math ($ and $$), metadata-free body only.
 */
(function () {
  "use strict";

  function esc(s) {
    return (s || "").replace(/&/g, "&amp;").replace(/</g, "&lt;")
      .replace(/>/g, "&gt;").replace(/"/g, "&quot;");
  }

  /* ---------- inline ---------- */

  function inline(raw, ctx) {
    var s = esc(raw);
    var codes = [];
    s = s.replace(/`([^`]+)`/g, function (_, c) {
      codes.push(c);
      return "\u0000C" + (codes.length - 1) + "\u0000";
    });
    // images ![alt](src) or ![alt|60%](attachments/x.png)
    s = s.replace(/!\[([^\]|]*)\|([^\]]*)\]\(([^)\s]+)\)/g, function (_, alt, w, src) {
      return '<img class="md-img" src="' + ctx.src(src) + '" alt="' + alt +
        '" style="width:' + esc(w) + '" loading="lazy" data-path="' + esc(src) + '">';
    });
    s = s.replace(/!\[([^\]]*)\]\(([^)\s]+)\)/g, function (_, alt, src) {
      return '<img class="md-img" src="' + ctx.src(src) + '" alt="' + alt +
        '" loading="lazy" data-path="' + esc(src) + '">';
    });
    // wiki links [[Target]] and [[Target|word]]
    s = s.replace(/\[\[([^\]|]+)\|([^\]]+)\]\]/g, function (_, t, w) {
      return '<a class="wikilink' + (ctx.missing(t) ? " missing" : "") +
        '" href="#/note/' + encodeURIComponent(t.trim()) + '" data-target="' +
        esc(t.trim()) + '">' + w + "</a>";
    });
    s = s.replace(/\[\[([^\]]+)\]\]/g, function (_, t) {
      return '<a class="wikilink' + (ctx.missing(t) ? " missing" : "") +
        '" href="#/note/' + encodeURIComponent(t.trim()) + '" data-target="' +
        esc(t.trim()) + '">' + t + "</a>";
    });
    // web links, avoiding the ones inside wiki already handled
    s = s.replace(/\[([^\]]+)\]\((https?:[^)\s]+)\)/g, function (_, w, u) {
      return '<a class="weblink" href="' + u + '" target="_blank" rel="noopener">' + w + "</a>";
    });
    // footnotes [^id]
    s = s.replace(/\[\^([a-zA-Z0-9_-]+)\]/g, function (_, id) {
      return '<sup class="fnref" data-fn="' + id + '">[' + id + "]</sup>";
    });
    // bold + italic
    s = s.replace(/\*\*([^*]+)\*\*/g, "<strong>$1</strong>");
    s = s.replace(/(^|[^*])\*([^*\n]+)\*/g, "$1<em>$2</em>");
    s = s.replace(/(^|[^_])_([^_\n]+)_(?![a-zA-Z0-9_])/g, "$1<em>$2</em>");
    // inline math $...$
    s = s.replace(/\$([^$\n]+)\$/g, function (_, m) {
      return ctx.math(m, false);
    });
    s = s.replace(/\u0000C(\d+)\u0000/g, function (_, i) {
      return "<code>" + codes[+i] + "</code>";
    });
    return s;
  }

  /* ---------- blocks ---------- */

  function render(text, ctx) {
    var lines = (text || "").split("\n");
    var out = [];
    var i = 0;
    var footnotes = {};

    function push(html, sl, el, cls) {
      out.push('<div class="blk ' + (cls || "") + '" data-sl="' + sl + '" data-el="' + el + '">' + html + "</div>");
    }

    while (i < lines.length) {
      var line = lines[i];

      if (!line.trim()) { i++; continue; }

      // display math $$...$$
      if (/^\s*\$\$/.test(line)) {
        var mstart = i, buf = [line.replace(/^\s*\$\$/, "")];
        if (/^(.*)\$\$\s*$/.test(line) && line.trim().length > 4) {
          i++;
        } else {
          i++;
          while (i < lines.length && !/\$\$\s*$/.test(lines[i])) { buf.push(lines[i]); i++; }
          if (i < lines.length) { buf.push(lines[i].replace(/\$\$\s*$/, "")); i++; }
        }
        push(ctx.math(buf.join("\n"), true), mstart, i - 1, "blk-math");
        continue;
      }

      // fenced code
      if (/^\s*```/.test(line)) {
        var cstart = i, lang = line.replace(/^\s*```/, "").trim();
        i++;
        var code = [];
        while (i < lines.length && !/^\s*```/.test(lines[i])) { code.push(lines[i]); i++; }
        i++; // closing fence
        push('<pre class="md-code"><div class="code-lang">' + esc(lang) + "</div><code>" +
          esc(code.join("\n")) + "</code></pre>", cstart, i - 1, "blk-code");
        continue;
      }

      // heading
      var h = line.match(/^(#{1,6})\s+(.*?)\s*#*\s*$/);
      if (h) {
        var lvl = Math.min(h[1].length + 1, 6); // note title is h1
        push("<h" + lvl + ">" + inline(h[2], ctx) + "</h" + lvl + ">", i, i, "blk-h");
        i++;
        continue;
      }

      // horizontal rule
      if (/^\s*(-{3,}|\*{3,}|_{3,})\s*$/.test(line)) {
        push("<hr>", i, i, "blk-hr");
        i++;
        continue;
      }

      // quote
      if (/^\s*>\s?/.test(line)) {
        var qstart = i, qbuf = [];
        while (i < lines.length && /^\s*>\s?/.test(lines[i])) {
          qbuf.push(lines[i].replace(/^\s*>\s?/, "")); i++;
        }
        push("<blockquote>" + inline(qbuf.join(" "), ctx) + "</blockquote>", qstart, i - 1, "blk-quote");
        continue;
      }

      // table
      if (/^\s*\|.*\|\s*$/.test(line) && i + 1 < lines.length &&
          /^\s*\|?[\s:|-]+\|?\s*$/.test(lines[i + 1]) && lines[i + 1].includes("-")) {
        var tstart = i;
        var head = splitRow(line);
        i += 2;
        var rows = [];
        while (i < lines.length && /^\s*\|.*\|\s*$/.test(lines[i])) {
          rows.push(splitRow(lines[i])); i++;
        }
        var html = '<div class="tablewrap"><table><thead><tr>';
        head.forEach(function (c) { html += "<th>" + inline(c, ctx) + "</th>"; });
        html += "</tr></thead><tbody>";
        rows.forEach(function (r) {
          html += "<tr>";
          head.forEach(function (_, ci) { html += "<td>" + inline(r[ci] || "", ctx) + "</td>"; });
          html += "</tr>";
        });
        html += "</tbody></table></div>";
        push(html, tstart, i - 1, "blk-table");
        continue;
      }

      // footnote definition [^id]: text
      var fd = line.match(/^\s*\[\^([a-zA-Z0-9_-]+)\]:\s*(.*)$/);
      if (fd) {
        var fstart = i, fbuf = [fd[2]];
        i++;
        while (i < lines.length && lines[i].trim() &&
               !/^(#{1,6}\s|[-*]\s|\d+\.\s|>|\||```|\[\^|!\[)/.test(lines[i].trim())) {
          fbuf.push(lines[i].trim()); i++;
        }
        footnotes[fd[1]] = fbuf.join(" ");
        push('<div class="fn-def" data-fn="' + fd[1] + '"><b>[' + fd[1] + "]</b> " +
          inline(fbuf.join(" "), ctx) + "</div>", fstart, i - 1, "blk-fn");
        continue;
      }

      // lists (incl. task lists)
      var li = line.match(/^(\s*)([-*]|\d+[.)])\s+(.*)$/);
      if (li) {
        var lstart = i, ordered = /\d/.test(li[2]);
        var baseIndent = li[1].length;
        var items = [];
        while (i < lines.length) {
          var m2 = lines[i].match(/^(\s*)([-*]|\d+[.)])\s+(.*)$/);
          if (m2 && m2[1].length <= baseIndent + 1) {
            var task = m2[3].match(/^\[([ xX])\]\s+(.*)$/);
            items.push({
              indent: m2[1].length,
              text: task ? task[2] : m2[3],
              task: task ? (task[1].toLowerCase() === "x" ? "on" : "off") : null,
              ordered: /\d/.test(m2[2])
            });
            i++;
          } else if (m2) {
            // deeper nesting: keep with previous item
            var task2 = m2[3].match(/^\[([ xX])\]\s+(.*)$/);
            items[items.length - 1].sub.push({
              text: task2 ? task2[2] : m2[3],
              task: task2 ? (task2[1].toLowerCase() === "x" ? "on" : "off") : null,
              ordered: /\d/.test(m2[2])
            });
            i++;
          } else if (lines[i].trim() && /^\s{2,}\S/.test(lines[i]) && items.length) {
            items[items.length - 1].text += " " + lines[i].trim();
            i++;
          } else break;
        }
        items.forEach(function (it) { if (!it.sub) it.sub = []; });
        push(renderList(items, ctx, 0, ordered), lstart, i - 1, "blk-list");
        continue;
      }

      // standalone image -> figure (grid handled after)
      var imgOnly = line.match(/^\s*!\[([^\]]*)\]\(([^)\s]+)\)\s*$/);
      if (imgOnly) {
        push('<figure class="md-figure"><img class="md-img" src="' + ctx.src(imgOnly[2]) +
          '" alt="' + esc(imgOnly[1]) + '" loading="lazy" data-path="' + esc(imgOnly[2]) + '">' +
          (imgOnly[1] ? "<figcaption>" + esc(imgOnly[1]) + "</figcaption>" : "") +
          "</figure>", i, i, "blk-img");
        i++;
        continue;
      }

      // paragraph
      var pstart = i, pbuf = [];
      while (i < lines.length && lines[i].trim() &&
             !/^(#{1,6}\s|[-*]\s|\d+[.)]\s|>|\||```|\$\$|\[\^|!\[)/.test(lines[i].trim())) {
        pbuf.push(lines[i]); i++;
      }
      if (!pbuf.length) { pbuf.push(line); i++; }
      push("<p>" + inline(pbuf.join(" "), ctx) + "</p>", pstart, i - 1, "blk-p");
    }

    var html = out.join("");

    // grid: 3+ consecutive image figures become a tidy grid
    // pass 1: turn each standalone image block into a neutral slot
    html = html.replace(
      /<div class="blk blk-img" data-sl="(\d+)" data-el="(\d+)">(<figure[\s\S]*?<\/figure>)<\/div>/g,
      '<span class="grid-slot" data-sl="$1" data-el="$2">$3</span>');
    // pass 2: wrap runs of 3+ slots
    html = html.replace(
      /(<span class="grid-slot"[^>]*><figure[\s\S]*?<\/figure><\/span>\s*){3,}/g,
      function (m) { return '<div class="blk blk-imggrid">' + m + "</div>"; });
    // pass 3: the grid uses thumbnails, the full file loads in full screen
    html = html.replace(/(<div class="blk blk-imggrid">[\s\S]*?<\/div>)/g,
      function (grid) {
        return grid.replace(/(src=")\/files\/([^"]+)(")/g,
          '$1/thumb?path=$2&w=480$3');
      });

    if (Object.keys(footnotes).length) {
      var fl = '<div class="blk blk-fnlist" data-sl="999999" data-el="999999"><h3>Footnotes</h3><ol>';
      Object.keys(footnotes).forEach(function (id) {
        fl += '<li id="fn-' + id + '">' + inline(footnotes[id], ctx) + "</li>";
      });
      html += fl + "</ol></div>";
    }
    return html;
  }

  function renderList(items, ctx, depth, ordered) {
    var tag = ordered && depth === 0 ? "ol" : "ul";
    var html = "<" + tag + ' class="md-list' + (depth ? " sub" : "") + '">';
    items.forEach(function (it) {
      var cls = it.task === "on" ? "task on" : it.task === "off" ? "task" : "";
      html += '<li class="' + cls + '">' +
        (it.task ? '<span class="tick">' + (it.task === "on" ? "\u2713" : "\u25CB") + "</span> " : "") +
        inline(it.text, ctx);
      if (it.sub && it.sub.length) html += renderList(it.sub, ctx, depth + 1, it.ordered);
      html += "</li>";
    });
    return html + "</" + tag + ">";
  }

  function splitRow(line) {
    var s = line.trim().replace(/^\|/, "").replace(/\|$/, "");
    return s.split(/\s*\|\s*(?![^[]*\])/).map(function (c) { return c.trim(); });
  }

  window.SBmd = { render: render, inline: inline, esc: esc };
  // note.js reaches the renderer through the SB namespace as well
  (window.SB = window.SB || {}).md = window.SBmd;
})();
