/* SecondBrain views (views.js): home, search, tag browser, connection
 * graph, health check + logs + backup. The note view lives in note.js. */
(function () {
  "use strict";
  const SB = window.SB;
  const esc = SB.esc;
  SB.views = SB.views || {};

  /* ================= HOME ================= */

  SB.views.home = async function () {
    const st = await SB.api.get("/api/state");
    document.getElementById("main").innerHTML =
      '<div class="home">' +
      '<div class="hero"><h1>Second<span>Brain</span></h1>' +
      "<p>Your notes as plain Markdown — searchable, tagged, connected.</p>" +
      '<div class="bigsearch"><input id="home-q" placeholder="Search…  (press / )" autofocus>' +
      '<button class="btn primary" id="home-go">' + SB.icon("search") + " Search</button></div>" +
      '<div class="savedchips">' +
      st.saved_searches.map((s) =>
        '<a class="chip savedchip" href="#/search?' + new URLSearchParams(s.params).toString() + '">' +
        SB.icon("search") + " " + esc(s.name) + "</a>").join("") +
      "</div></div>" +
      '<div class="cols"><div class="col"><h3>' + SB.icon("pin") + " Pinned</h3>" +
      '<ul class="notelist">' +
      (st.pinned.map(rowNote).join("") || '<li class="dim">Nothing pinned yet — use the pin button on a note.</li>') +
      "</ul></div>" +
      '<div class="col"><h3>' + SB.icon("eye") + " Recently updated</h3>" +
      '<ul class="notelist">' +
      st.recent.map(rowNote).join("") + "</ul></div></div>" +
      '<div class="cols quicklinks">' +
      linkCard("tags", "Tag browser", "Browse the vocabulary by group and hierarchy.") +
      linkCard("graph", "Connection graph", "See how notes link together.") +
      linkCard("health", "Health & logs", "Broken links, stray files, undo, backup.") +
      linkCard("tools", "New note", "Create a note with its folder, tags.txt and attachments.") +
      "</div></div>";
    document.getElementById("home-go").onclick = go;
    document.getElementById("home-q").addEventListener("keydown", (e) => {
      if (e.key === "Enter") go();
    });
    function go() {
      const q = document.getElementById("home-q").value.trim();
      location.hash = "#/search?q=" + encodeURIComponent(q);
    }
    function rowNote(n) {
      return '<li><a href="#/note/' + encodeURIComponent(n.title) + '">' + esc(n.title) +
        "</a><span class='dim'> " + esc(n.folder || "") + "</span></li>";
    }
    function linkCard(route, t, d) {
      return '<a class="qcard" href="#/' + route + '"><b>' + esc(t) + "</b><span>" + esc(d) + "</span></a>";
    }
  };

  /* ================= SEARCH ================= */

  const searchState = {
    q: "", mode: "rank", tags: [], folders: [], folder_only: false,
    scope: ["everything"], tag_mode: "rank", kw_mode: "rank",
    include_connected: false, status: "", date_from: "", date_to: "",
    limit_to: [], offset: 0, total: 0, results: [],
  };

  SB.views.search = async function (params) {
    const p = new URLSearchParams(params || "");
    searchState.q = p.get("q") || "";
    searchState.mode = p.get("mode") || "rank";
    searchState.tags = (p.get("tags") || "").split(",").filter(Boolean);
    searchState.folders = (p.get("folders") || "").split(",").filter(Boolean);
    if (p.get("tag_mode")) searchState.tag_mode = p.get("tag_mode");
    if (p.get("kw_mode")) searchState.kw_mode = p.get("kw_mode");
    if (p.get("scope")) searchState.scope = p.get("scope").split(",").filter(Boolean);
    if (p.get("folder_only")) searchState.folder_only = p.get("folder_only") === "1";
    if (p.get("include_connected")) searchState.include_connected = p.get("include_connected") === "1";
    searchState.limit_to = (p.get("limit_to") || "").split(",").filter(Boolean);
    renderSearch();
    await doSearch(0);          // DOM exists first, then results (run or not)
  };

  function renderSearch() {
    const s = searchState;
    document.getElementById("main").innerHTML =
      '<div class="searchpage">' +
      '<div class="searchbar"><input id="s-q" value="' + esc(s.q) + '" placeholder="Search…  (press /)">' +
      '<button class="btn primary" id="s-go">' + SB.icon("search") + " Search</button></div>" +

      '<div class="modebar">' +
      '<span class="dim">Mode</span>' +
      modeBtn("rank", "Ranking only") + modeBtn("strict_keyword", "Strict keyword") + modeBtn("strict_tag", "Strict tag") +
      '<span class="vr"></span>' +
      '<label class="switch"><input type="checkbox" id="sw-tags-req" ' + (s.tag_mode === "require" ? "checked" : "") + "> Require tags</label>" +
      '<label class="switch"><input type="checkbox" id="sw-kw-req" ' + (s.kw_mode === "require" ? "checked" : "") + "> Require keywords</label>" +
      '<span class="vr"></span>' +
      '<label class="switch"><input type="checkbox" id="sw-conn" ' + (s.include_connected ? "checked" : "") + "> include notes connected to my results</label>" +
      "</div>" +

      '<div class="filterbar" id="filterbar"></div>' +

      '<div class="filters2">' +
      '<div class="fgroup"><span class="dim">Scope</span>' +
      ["everything", "file name", "tags", "headings", "body", "folder path"].map((sc) =>
        '<label class="check"><input type="checkbox" data-scope="' + sc + '" ' +
        (s.scope.includes(sc) ? "checked" : "") + "> " + sc + "</label>").join("") + "</div>" +
      '<div class="fgroup"><span class="dim">Status</span><select id="f-status">' +
      ["", "verified", "unverified"].map((v) =>
        '<option value="' + v + '"' + (s.status === v ? " selected" : "") + ">" + (v || "any") + "</option>").join("") +
      "</select>" +
      '<span class="dim">Updated from</span><input type="date" id="f-from" value="' + esc(s.date_from) + '">' +
      '<span class="dim">to</span><input type="date" id="f-to" value="' + esc(s.date_to) + '"></div>' +
      "</div>" +

      '<div id="s-notice"></div>' +
      '<div id="s-results" class="results"></div>' +
      '<div class="morewrap"><button class="btn" id="s-more" style="display:none">Show 20 more</button> ' +
      '<button class="ghost" id="s-save">Save this search</button></div>' +
      "</div>";
    renderFilterBar();
    wireSearch();
  }

  function modeBtn(m, label) {
    return '<button class="btn mode' + (searchState.mode === m ? " primary" : "") +
      '" data-mode="' + m + '">' + label + "</button>";
  }

  function renderFilterBar() {
    const s = searchState;
    const bar = document.getElementById("filterbar");
    bar.innerHTML =
      s.tags.map((t) => chipX("tag", t)).join("") +
      s.folders.map((f) => chipX("folder", f)).join("") +
      '<input id="filter-input" placeholder="Add a tag or folder… (major tags first)" autocomplete="off">' +
      '<div id="suggest" class="suggest"></div>' +
      (s.folders.length ? '<label class="check"><input type="checkbox" id="folder-only" ' +
        (s.folder_only ? "checked" : "") + "> this folder only (no sub-folders)</label>" : "");
    bar.querySelectorAll(".chipx").forEach((c) => {
      c.querySelector("button").onclick = () => {
        if (c.dataset.type === "tag") s.tags = s.tags.filter((t) => t !== c.dataset.name);
        else s.folders = s.folders.filter((t) => t !== c.dataset.name);
        renderFilterBar();
        doSearch(0);
      };
    });
    const folderOnly = document.getElementById("folder-only");
    if (folderOnly) folderOnly.onchange = () => {
      s.folder_only = folderOnly.checked;
      doSearch(0);
    };

    const inp = document.getElementById("filter-input");
    const sug = document.getElementById("suggest");
    let majorPhase = true;
    inp.addEventListener("input", SB.debounce(async () => {
      const q = inp.value.trim();
      if (!q) { sug.innerHTML = ""; return; }
      const res = await SB.api.get("/api/suggest?q=" + encodeURIComponent(q) + "&type=all");
      sug.innerHTML = res.suggestions.map((r) =>
        '<button class="sug" data-type="' + r.type + '" data-name="' + esc(r.type === "tag" ? r.name : r.name) + '">' +
        SB.icon(r.type === "tag" ? "tag" : "folder") + " " + esc(r.name) +
        '<span class="dim"> ' + esc(r.type) + (r.type === "tag" ? " · under " + esc(r.parent) : "") +
        " · " + r.count + " notes</span></button>").join("");
      sug.querySelectorAll(".sug").forEach((b) => {
        b.onclick = () => {
          if (b.dataset.type === "tag") {
            const name = b.dataset.name;
            // major tags first: picking a major narrows future suggestions
            if (!name.includes("-") && !s.tags.includes(name)) s.tags.push(name);
            else if (!s.tags.includes(name)) s.tags.push(name);
          } else {
            if (!s.folders.includes(b.dataset.name)) s.folders.push(b.dataset.name);
          }
          inp.value = "";
          sug.innerHTML = "";
          renderFilterBar();
          doSearch(0);
        };
      });
    }, 120));
  }

  function chipX(type, name) {
    return '<span class="chip chipx" data-type="' + type + '" data-name="' + esc(name) + '">' +
      SB.icon(type === "tag" ? "tag" : "folder") + " " + esc(name) +
      "<button aria-label='remove'>" + SB.icon("x") + "</button></span>";
  }

  function wireSearch() {
    const s = searchState;
    document.getElementById("s-go").onclick = () => doSearch(0);
    document.getElementById("s-q").addEventListener("keydown", (e) => {
      if (e.key === "Enter") doSearch(0);
    });
    document.querySelectorAll(".mode").forEach((b) => {
      b.onclick = () => {
        s.mode = b.dataset.mode;
        s.tag_mode = s.mode === "strict_tag" ? "require" : "rank";
        s.kw_mode = s.mode === "strict_keyword" ? "require" : "rank";
        renderSearch();
        doSearch(0);
      };
    });
    document.getElementById("sw-tags-req").onchange = (e) => {
      s.tag_mode = e.target.checked ? "require" : "rank";
      s.mode = s.tag_mode === "require" ? "strict_tag" : (s.kw_mode === "require" ? "strict_keyword" : "rank");
      renderSearch();
      doSearch(0);
    };
    document.getElementById("sw-kw-req").onchange = (e) => {
      s.kw_mode = e.target.checked ? "require" : "rank";
      s.mode = s.kw_mode === "require" ? "strict_keyword" : (s.tag_mode === "require" ? "strict_tag" : "rank");
      renderSearch();
      doSearch(0);
    };
    document.getElementById("sw-conn").onchange = (e) => {
      s.include_connected = e.target.checked;
      doSearch(0);
    };
    document.querySelectorAll("[data-scope]").forEach((cb) => {
      cb.onchange = () => {
        const v = cb.dataset.scope;
        if (cb.checked) {
          if (v === "everything") s.scope = ["everything"];
          else s.scope = s.scope.filter((x) => x !== "everything").concat(v);
        } else {
          s.scope = s.scope.filter((x) => x !== v);
          if (!s.scope.length) s.scope = ["everything"];
        }
        doSearch(0);
      };
    });
    document.getElementById("f-status").onchange = (e) => { s.status = e.target.value; doSearch(0); };
    document.getElementById("f-from").onchange = (e) => { s.date_from = e.target.value; doSearch(0); };
    document.getElementById("f-to").onchange = (e) => { s.date_to = e.target.value; doSearch(0); };
    document.getElementById("s-more").onclick = () => doSearch(s.offset + 20);
    document.getElementById("s-save").onclick = () => {
      SB.modal("Save this search", "<label>Name</label><input id='sv-name' placeholder='e.g. quick veggie dinners'>", [
        { label: "Cancel" },
        { label: "Save", primary: true, onclick: async (w) => {
          const name = w.querySelector("#sv-name").value.trim();
          if (!name) return false;
          await SB.api.post("/api/saved_searches/save", { name, params: currentParams() });
          SB.toast("Saved search pinned to the home page.");
        }},
      ]);
    };
  }

  function currentParams() {
    const s = searchState;
    const p = new URLSearchParams();
    p.set("q", s.q);
    p.set("mode", s.mode);
    if (s.tags.length) p.set("tags", s.tags.join(","));
    if (s.folders.length) p.set("folders", s.folders.join(","));
    if (s.folder_only) p.set("folder_only", "1");
    p.set("scope", s.scope.join(","));
    p.set("tag_mode", s.tag_mode);
    p.set("kw_mode", s.kw_mode);
    if (s.include_connected) p.set("include_connected", "1");
    if (s.limit_to && s.limit_to.length) p.set("limit_to", s.limit_to.join(","));
    if (s.status) p.set("status", s.status);
    if (s.date_from) p.set("date_from", s.date_from);
    if (s.date_to) p.set("date_to", s.date_to);
    return p;
  }

  async function doSearch(offset) {
    const s = searchState;
    s.offset = offset;
    const p = currentParams();
    p.set("offset", String(offset));
    const res = await SB.api.get("/api/search?" + p.toString());
    if (offset === 0) s.results = res.results;
    else s.results = s.results.concat(res.results);
    s.total = res.total;
    s.removedBy = res.removed_by;
    s.notice = res.notice;
    s.elapsed = res.elapsed_ms;
    s.queryTags = res.query.query_tags;
    s.groups = res.query.groups;
    renderResults(res);
  }

  function renderResults(res) {
    const s = searchState;
    const box = document.getElementById("s-results");
    const within = (s.limit_to && s.limit_to.length)
      ? ' · within: ' + s.limit_to.map(esc).join(", ") +
        ' <button class="ghost tiny" id="limit-clear">clear</button>'
      : "";
    document.getElementById("s-notice").innerHTML = s.notice
      ? '<div class="notice">' + esc(s.notice) + "</div>" : "";
    document.getElementById("s-more").style.display =
      s.results.length < s.total ? "inline-flex" : "none";
    box.innerHTML =
      '<p class="dim">' + s.total + " result(s) · ranked in " + s.elapsed + " ms" +
      (s.queryTags.length ? " · query tags: " + s.queryTags.map((t) => esc(t)).join(", ") : "") +
      within + "</p>" +
      s.results.map(resultCard).join("");
    const lc = document.getElementById("limit-clear");
    if (lc) lc.onclick = () => { s.limit_to = []; doSearch(0); };
  }

  function resultCard(r) {
    const why = r.score == null
      ? '<span class="badge conn">connected to ' + esc((r.connected_to || "").split("/").slice(-2)[0] || "") + "</span>"
      : '<span class="score">' + r.score + "</span>";
    const parts = [];
    if (r.breakdown) {
      Object.keys(r.breakdown).forEach((k) => {
        const v = r.breakdown[k];
        if (v.points > 0.001) parts.push(k + " " + (v.points * 100).toFixed(0));
      });
    }
    return '<div class="result' + (r.direct === false ? " neighbor" : "") + '">' +
      '<div class="rhead"><a class="rtitle" href="#/note/' + encodeURIComponent(r.title) + '">' +
      esc(r.title) + "</a>" + why +
      (r.status !== "verified" ? '<span class="badge unv">unverified</span>' : "") +
      "</div>" +
      '<div class="rmeta">' + SB.icon("folder") + " " + esc(r.folder || "database") +
      ' <span class="dim">updated ' + esc(SB.fmtDate(r.updated)) + "</span>" +
      (r.neighbor_kind ? '<span class="badge">' + r.neighbor_kind + " only</span>" : "") +
      "</div>" +
      '<div class="rtags">' + (r.tags || []).map((t) => SB.chip(t)).join("") + "</div>" +
      '<p class="rsnippet">…' + esc(r.snippet || "") + "…</p>" +
      (r.score != null
        ? '<details class="why"><summary>Why this result</summary>' +
          '<div class="whybars">' + whyBars(r) +
          "<p class='dim'>coverage factor " + r.coverage +
          " = 0.4 + 0.6 × (" + r.matched_groups + " of the query's groups matched)</p></div></details>"
        : "") +
      "</div>";
  }

  function whyBars(r) {
    const names = { tags: "Tags 34%", title: "Title & aliases 24%", headings: "Headings 14%",
      neighbors: "Neighbors 12%", body: "Body 10%", closeness: "Closeness 6%" };
    return Object.keys(r.breakdown).map((k) => {
      const v = r.breakdown[k];
      return '<div class="whyrow"><span class="whyname">' + (names[k] || k) + "</span>" +
        '<div class="whybar"><div style="width:' + Math.min(100, (v.points || 0) * 294) + '%"></div></div>' +
        '<span class="whyval">' + (v.points ? (v.points * 100).toFixed(1) + " pts" :
          "<i>not applicable — weight shared</i>") + "</span></div>";
    }).join("");
  }

  /* ================= TAGS ================= */

  SB.views.tags = async function () {
    const data = await SB.api.get("/api/tags");
    const rows = data.rows || [];
    document.getElementById("main").innerHTML =
      '<div class="tagspage"><h2>' + SB.icon("tag") + " Tag browser</h2>" +
      "<p class='dim'>Organized by major tag and hierarchy. A deep tag also counts for its parents. " +
      "Tags not in _tags.md are flagged and cannot be picked in search.</p>" +
      '<div class="tagmanage">' +
      '<button class="btn" id="tg-add">' + SB.icon("plus") + " Add tag to _tags.md</button>" +
      '<button class="btn" id="tg-rename">' + SB.icon("edit") + " Rename / merge</button>" +
      '<button class="btn" id="tg-raw">' + SB.icon("edit") + " Edit _tags.md raw</button></div>" +
      '<table class="tagtable"><thead><tr><th>Tag</th><th>Notes</th><th></th></tr></thead><tbody>' +
      rows.map((r) => {
        const major = r.tag.split("-")[0];
        const hue = SB.tagHue(major);
        const dark = SB.state.theme === "dark";
        return "<tr><td><span class='indent" + r.depth + "'></span>" +
          '<a class="chip" style="background:' + (dark ? `hsl(${hue} 30% 26%)` : `hsl(${hue} 55% 90%)`) +
          ";color:" + (dark ? `hsl(${hue} 45% 80%)` : `hsl(${hue} 45% 30%)`) +
          '" href="#/search?tags=' + encodeURIComponent(r.tag) + "&run=1" + '">' + esc(r.tag) + "</a></td>" +
          "<td>" + r.count + "</td><td></td></tr>";
      }).join("") + "</tbody></table>" +
      (data.unapproved.length ? '<div class="notice"><b>Unapproved tags in use:</b> ' +
        data.unapproved.map(esc).join(", ") + " — approve them in _tags.md.</div>" : "") +
      (data.proposed.length ? '<div class="notice"><b>Proposed by the AI (awaiting approval):</b> ' +
        data.proposed.map(esc).join(", ") + "</div>" : "") +
      "</div>";
    document.getElementById("tg-add").onclick = () => masterEditor();
    document.getElementById("tg-rename").onclick = () => renameMerge();
    document.getElementById("tg-raw").onclick = () => masterEditor();
  };

  async function masterEditor() {
    const m = await SB.api.get("/api/master_tags");
    SB.modal("Edit _tags.md (master tag list)",
      "<textarea id='master-text' rows='16'>" + esc(m.text) + "</textarea>", [
      { label: "Cancel" },
      { label: "Save master list", primary: true, onclick: async (w) => {
        await SB.api.post("/api/tags/master", { text: w.querySelector("#master-text").value });
        SB.toast("_tags.md saved; affected notes keep working, new tags are now pickable.");
      }},
    ]);
  }

  function renameMerge() {
    SB.modal("Rename or merge a tag",
      "<p class='dim'>One action renames or merges a tag across all notes. " +
      "You will see a preview of every note that changes before anything is written.</p>" +
      "<label>From</label><input id='rt-from' placeholder='FOOD-pasta'>" +
      "<label>To</label><input id='rt-to' placeholder='FOOD-noodles (rename) or existing tag (merge)'>", [
      { label: "Cancel" },
      { label: "Preview", onclick: async (w) => {
        const from = w.querySelector("#rt-from").value.trim();
        const to = w.querySelector("#rt-to").value.trim();
        const res = await SB.api.post("/api/tags/rename", { from, to });
        showTagPreview(from, to, res, false);
        return false;
      }},
      { label: "Preview merge", onclick: async (w) => {
        const from = w.querySelector("#rt-from").value.trim();
        const to = w.querySelector("#rt-to").value.trim();
        const res = await SB.api.post("/api/tags/merge", { from, into: to });
        showTagPreview(from, to, res, true);
        return false;
      }},
    ]);
  }

  function showTagPreview(from, to, res, merge) {
    const rows = (res.notes || []).map((n) =>
      "<li><b>" + esc(n.file) + "</b><br>" + esc(n.old.join(", ")) +
      " &nbsp;→&nbsp; " + esc(n.new.join(", ")) + "</li>").join("");
    SB.modal("Preview: " + (merge ? "merge " : "rename ") + from + (merge ? " into " : " → ") + to,
      "<p>" + (res.notes || []).length + " notes will change.</p><ul class='previewlist'>" + rows +
      "</ul><p class='dim'>_tags.md is updated in the same change.</p>", [
      { label: "Cancel" },
      { label: "Apply to every note listed", primary: true, onclick: async () => {
        if (merge) await SB.api.post("/api/tags/merge", { from, into: to, run: true });
        else await SB.api.post("/api/tags/rename", { from, to, run: true });
        SB.toast("Done. Every change is logged and can be undone.");
        SB.views.tags();
      }},
    ]);
  }

  /* ================= TOOLS: new note + folders ================= */

  SB.views.tools = async function () {
    const f = await SB.api.get("/api/folders");
    const rows = [];
    const walk = (n, depth) => {
      if (n.path !== "") {
        rows.push("<tr><td><span class='indent" + depth + "'></span>" +
          SB.icon("folder") + " " + esc(n.name) +
          (n.private ? " <span class='badge'>private — hidden & excluded from the index</span>" : "") +
          "</td><td class='dim'>" + esc(n.path) + "</td><td>" +
          "<button class='ghost tiny f-rename' data-p='" + esc(n.path) + "'>rename</button> " +
          "<button class='ghost tiny f-move' data-p='" + esc(n.path) + "'>move</button> " +
          "<button class='ghost tiny f-delete' data-p='" + esc(n.path) + "'>delete</button></td></tr>");
      }
      (n.children || []).forEach((c) => walk(c, depth + 1));
    };
    walk(f.tree, 0);
    document.getElementById("main").innerHTML =
      '<div class="toolspage"><h2>' + SB.icon("folder") + " Notes & folders</h2>" +
      "<div class='btnrow'><button class='btn primary' id='t-newnote'>" + SB.icon("plus") +
      " New note</button><button class='btn' id='t-newfolder'>" + SB.icon("plus") +
      " New folder</button></div>" +
      "<h3>Subject folders</h3>" +
      "<table class='logtable'><thead><tr><th>Folder</th><th>Path</th><th></th></tr></thead>" +
      "<tbody>" + rows.join("") + "</tbody></table>" +
      "<p class='dim'>A folder is a subject; subjects nest to any depth. The AI must ask before " +
      "creating a new folder. Folder chips in search are hard boundaries.</p></div>";
    document.getElementById("t-newnote").onclick = () => document.getElementById("new-note").click();
    document.getElementById("t-newfolder").onclick = () => folderDialog("");
    document.querySelectorAll(".f-rename").forEach((b) => (b.onclick = () => {
      SB.modal("Rename folder", "<label>New name</label><input id='fr-name'>", [
        { label: "Cancel" },
        { label: "Rename", primary: true, onclick: async (w) => {
          try {
            await SB.api.post("/api/folder/rename", { path: b.dataset.p, name: w.querySelector("#fr-name").value });
            SB.toast("Renamed. Wiki links use file names, so nothing else needed rewriting.");
            SB.views.tools();
          } catch (e) { SB.toast(e.message, "err"); return false; }
        }},
      ]);
    }));
    document.querySelectorAll(".f-move").forEach((b) => (b.onclick = () => {
      SB.modal("Move folder", "<label>New parent (empty = database root)</label>" +
        "<input id='fm-parent' placeholder='database/Recipes … or leave empty'>", [
        { label: "Cancel" },
        { label: "Move", primary: true, onclick: async (w) => {
          try {
            await SB.api.post("/api/folder/move", { path: b.dataset.p, parent: w.querySelector("#fm-parent").value });
            SB.toast("Moved.");
            SB.views.tools();
          } catch (e) { SB.toast(e.message, "err"); return false; }
        }},
      ]);
    }));
    document.querySelectorAll(".f-delete").forEach((b) => (b.onclick = () => {
      SB.confirm("Delete this folder? Only empty folders can be deleted.", async () => {
        try {
          await SB.api.post("/api/folder/delete", { path: b.dataset.p });
          SB.toast("Deleted (it was empty).");
          SB.views.tools();
        } catch (e) { SB.toast(e.message, "err"); }
      });
    }));

    function folderDialog(parent) {
      SB.modal("Create a folder (a new subject)",
        "<p class='dim'>Folder trees can be any depth. An optional _subject.md describes " +
        "its purpose and sensitivity.</p>" +
        "<label>Parent</label><input id='nf-parent' value='" + esc(parent) + "' placeholder='empty = database root'>" +
        "<label>Name</label><input id='nf-name' placeholder='e.g. Home Repair'>" +
        "<label>Optional _subject.md content</label><textarea id='nf-subject' rows='4' " +
        "placeholder='Purpose: ...&#10;Sensitivity: normal'></textarea>", [
        { label: "Cancel" },
        { label: "Create", primary: true, onclick: async (w) => {
          try {
            await SB.api.post("/api/folder/create", {
              parent: w.querySelector("#nf-parent").value.trim(),
              name: w.querySelector("#nf-name").value,
              subject_md: w.querySelector("#nf-subject").value || null,
            });
            SB.toast("Folder created.");
            SB.views.tools();
          } catch (e) { SB.toast(e.message, "err"); return false; }
        }},
      ]);
    }
  };

  /* ================= GRAPH ================= */

  SB.views.graph = async function () {
    const g = await SB.api.get("/api/graph");
    document.getElementById("main").innerHTML =
      '<div class="graphpage"><h2>' + SB.icon("graph") + " Connection graph</h2>" +
      "<p class='dim'>Every note and every link. Click a circle to open the note.</p>" +
      "<canvas id='graph-canvas' width='1100' height='620'></canvas></div>";
    drawGraph(g);
  };

  function drawGraph(g) {
    const cv = document.getElementById("graph-canvas");
    const ctx2 = cv.getContext("2d");
    const W = cv.width, H = cv.height;
    const nodes = g.nodes.map((n, i) => ({
      id: n.id, title: n.title, major: (n.tags[0] || "?").split("-")[0],
      x: W / 2 + Math.cos(i * 2.4) * (100 + i * 8),
      y: H / 2 + Math.sin(i * 2.4) * (80 + i * 5),
      vx: 0, vy: 0,
    }));
    const byId = Object.fromEntries(nodes.map((n) => [n.id, n]));
    const edges = g.edges.map((e) => [byId[e[0]], byId[e[1]]]).filter((e) => e[0] && e[1]);

    for (let step = 0; step < 300; step++) {
      nodes.forEach((a) => {
        let fx = 0, fy = 0;
        nodes.forEach((b) => {
          if (a === b) return;
          const dx = a.x - b.x, dy = a.y - b.y;
          const d2 = dx * dx + dy * dy + 40;
          fx += (dx / d2) * 900;
          fy += (dy / d2) * 900;
        });
        edges.forEach((e) => {
          const [p, q] = e;
          if (p === a || q === a) {
            const other = p === a ? q : p;
            fx += (other.x - a.x) * 0.02;
            fy += (other.y - a.y) * 0.02;
          }
        });
        fx += (W / 2 - a.x) * 0.002;
        fy += (H / 2 - a.y) * 0.002;
        a.vx = (a.vx + fx) * 0.85;
        a.vy = (a.vy + fy) * 0.85;
      });
      nodes.forEach((n) => {
        n.x = Math.max(40, Math.min(W - 40, n.x + n.vx));
        n.y = Math.max(40, Math.min(H - 40, n.y + n.vy));
      });
    }

    function paint() {
      ctx2.clearRect(0, 0, W, H);
      ctx2.strokeStyle = getComputedStyle(document.body).getPropertyValue("--border");
      edges.forEach((e) => {
        ctx2.beginPath();
        ctx2.moveTo(e[0].x, e[0].y);
        ctx2.lineTo(e[1].x, e[1].y);
        ctx2.stroke();
      });
      nodes.forEach((n) => {
        const hue = SB.tagHue(n.major);
        ctx2.beginPath();
        ctx2.arc(n.x, n.y, 14, 0, 7);
        ctx2.fillStyle = `hsl(${hue} 55% 72%)`;
        ctx2.fill();
        ctx2.fillStyle = getComputedStyle(document.body).getPropertyValue("--text");
        ctx2.font = "11px system-ui";
        ctx2.textAlign = "center";
        ctx2.fillText(n.title.length > 26 ? n.title.slice(0, 25) + "…" : n.title, n.x, n.y + 26);
      });
    }
    paint();
    document.addEventListener("sb-theme", paint);
    cv.onmousemove = SB.debounce((e) => {
      const r = cv.getBoundingClientRect();
      const mx = e.clientX - r.left, my = e.clientY - r.top;
      const hit = nodes.find((n) => Math.hypot(n.x - mx, n.y - my) < 16);
      cv.style.cursor = hit ? "pointer" : "default";
      cv.onclick = () => { if (hit) location.hash = "#/note/" + encodeURIComponent(hit.title); };
    }, 30);
  }

  /* ================= HEALTH / LOGS / BACKUP ================= */

  SB.views.health = async function () {
    const h = await SB.api.get("/api/health");
    const logs = (await SB.api.get("/api/logs?limit=30")).logs;
    const sec = (title, items, fmt) =>
      "<h3>" + title + " <span class='badge'>" + items.length + "</span></h3>" +
      (items.length ? "<ul class='healthlist'>" + items.map(fmt).join("") + "</ul>"
        : "<p class='dim'>None.</p>");
    document.getElementById("main").innerHTML =
      '<div class="healthpage"><h2>' + SB.icon("health") + " Health check</h2>" +
      '<div class="hgrid">' +
      '<div>' + sec("Broken links", h.broken_links, (b) =>
        "<li><a href='#/note/" + encodeURIComponent(b.note.split("/").slice(-2)[0]) + "'>" +
        esc(b.note.split("/").slice(-2)[0]) + "</a> → missing <b>" + esc(b.link) + "</b></li>") + "</div>" +
      '<div>' + sec("Notes with no tags", h.notes_without_tags, (p) =>
        "<li><a href='#/note/" + encodeURIComponent(p.split("/").slice(-2)[0]) + "'>" +
        esc(p.split("/").slice(-2)[0]) + "</a></li>") + "</div>" +
      '<div>' + sec("Notes with no connections", h.notes_without_connections, (p) =>
        "<li>" + esc(p.split("/").slice(-2)[0]) + "</li>") + "</div>" +
      '<div>' + sec("Tags used once", h.tags_used_once, (t) => "<li>" + esc(t) + "</li>") + "</div>" +
      '<div>' + sec("Near-duplicate tags", h.near_duplicate_tags, (n) =>
        "<li>" + n.tags.map(esc).join(" ↔ ") + "</li>") + "</div>" +
      '<div>' + sec("Unapproved tags", h.unapproved_tags, (t) => "<li>" + esc(t) + "</li>") + "</div>" +
      '<div>' + sec("Files outside the allowed structure", h.structure_problems, (p) =>
        "<li><b>" + esc(p.path) + "</b> — " + esc(p.problem) + "</li>") + "</div>" +
      "</div>" +
      '<h2>' + SB.icon("undo") + " Logs</h2>" +
      "<p class='dim'>One new log file after every edit, never edited or deleted. " +
      "Each records who, what, why and how to undo.</p>" +
      "<table class='logtable'><thead><tr><th>When</th><th>Who</th><th>Title</th><th></th></tr></thead><tbody>" +
      logs.map((l) => "<tr><td>" + esc(l.date) + "</td><td>" + esc(l.who) + "</td><td>" +
        esc(l.title) + "</td><td>" +
        "<button class='ghost tiny log-view' data-f='" + esc(l.file) + "'>view</button> " +
        (l.undoable ? "<button class='ghost tiny log-undo' data-f='" + esc(l.file) + "'>undo</button>" : "") +
        "</td></tr>").join("") + "</tbody></table></div>";
    document.querySelectorAll(".log-view").forEach((b) => {
      b.onclick = async () => {
        const t = await SB.api.get("/api/log?name=" + encodeURIComponent(b.dataset.f));
        SB.modal(b.dataset.f, "<pre class='logpre'>" + esc(t.text) + "</pre>", [{ label: "Close" }]);
      };
    });
    document.querySelectorAll(".log-undo").forEach((b) => {
      b.onclick = () => {
        SB.confirm("Undo the change recorded in this log?", async () => {
          try {
            await SB.api.post("/api/undo", { log: b.dataset.f });
            SB.toast("Change undone (a new log entry records the undo).");
            SB.views.health();
          } catch (e) { SB.toast(e.message, "err"); }
        });
      };
    });
  };

  SB.views.backup = async function () {
    document.getElementById("main").innerHTML =
      '<div class="backuppage"><h2>' + SB.icon("backup") + " Backup & restore</h2>" +
      "<p class='dim'>Keeps a second copy of the project up to date without copying everything again. " +
      "Changed and new files only; every replaced or removed file is kept in a dated .versions/ folder; " +
      "everything is re-hashed and the run only succeeds when every hash matches.</p>" +
      "<div class='bform'><label>Backup folder (outside the project)</label>" +
      "<input id='b-dir' placeholder='/path/to/backup'>" +
      "<label>Scope</label><select id='b-scope'>" +
      ["whole", "database", "inbox", "logs"].map((s) => "<option>" + s + "</option>").join("") +
      "</select><label>Direction</label><select id='b-dirn'>" +
      "<option value='backup'>update backup from the project</option>" +
      "<option value='restore'>restore project from the backup</option></select></div>" +
      "<div class='btnrow'><button class='btn' id='b-preview'>Preview</button>" +
      "<button class='btn primary' id='b-run'>Run</button>" +
      "<button class='btn' id='b-verify'>Verify hashes</button></div>" +
      "<div id='b-out'></div></div>";
    const out = document.getElementById("b-out");
    const getArgs = () => ({
      to: document.getElementById("b-dir").value.trim(),
      scope: document.getElementById("b-scope").value,
      direction: document.getElementById("b-dirn").value,
    });
    document.getElementById("b-preview").onclick = async () => {
      try {
        const a = getArgs();
        const r = await SB.api.post("/api/backup/preview", a);
        out.innerHTML = "<h3>Preview</h3><pre class='logpre'>" + esc(r.preview) + "</pre>";
      } catch (e) { out.innerHTML = ""; SB.toast(e.message, "err"); }
    };
    document.getElementById("b-run").onclick = () => {
      const a = getArgs();
      if (!a.to) return SB.toast("Choose the backup folder first.", "err");
      SB.confirm("Run the " + a.direction + " now? Changed and new files only; replaced files are kept in .versions/.", async () => {
        try {
          const r = await SB.api.post("/api/backup/run", a);
          out.innerHTML = "<h3>Result</h3><pre class='logpre'>" +
            esc(JSON.stringify(r, null, 1)) + "</pre>" +
            (r.ok ? "<p class='ok'>Every hash verified.</p>" : "<p class='err'>Hash mismatch — see above.</p>");
        } catch (e) { SB.toast(e.message, "err"); }
      });
    };
    document.getElementById("b-verify").onclick = async () => {
      try {
        const a = getArgs();
        const r = await SB.api.post("/api/backup/verify", a);
        out.innerHTML = r.ok ? "<p class='ok'>Backup verified: every file matches by SHA-256.</p>"
          : "<p class='err'>Not in sync — run a backup first.</p>";
      } catch (e) { SB.toast(e.message, "err"); }
    };
  };
})();
