/* SecondBrain note view + edit (note.js)
 * - View: breadcrumb, quick info card, rendered body, connected notes,
 *   reference sources, metadata (in that order, spec 11).
 * - Edit: raw Markdown editor with a toolbar; save checks the file hash
 *   first and asks before overwriting.
 * - Switching edit <-> preview keeps the place: every rendered block knows
 *   its source lines, so the anchor block and fraction are restored
 *   (acceptance: the view never moves by more than one line).
 * - Images: render in place, resizable in the viewer, grid when many;
 *   full screen with crop (saved as a new image: replace+backup or keep
 *   both), download, delete (with confirmation and warning).
 */
(function () {
  "use strict";
  const SB = window.SB;
  const esc = SB.esc;
  let current = null;          // note view payload
  let editMode = false;
  let draft = null;            // unsaved editor text while previewing

  /* ---------------- renderer context ---------------- */

  let titleSet = new Set();
  async function refreshTitles() {
    const folders = await SB.api.get("/api/folders");
    titleSet = new Set();
    const walk = (n) => {
      (n.children || []).forEach(walk);
    };
    // titles come from search index; use a cheap full scan of graph
    const g = await SB.api.get("/api/graph");
    g.nodes.forEach((n) => titleSet.add(n.title));
  }

  function ctx(srcBase) {
    return {
      src: (p) => {
        if (/^https?:/.test(p)) return p;
        const np = p.replace(/^\.?\//, "");
        if (np.startsWith("attachments/")) {
          return "/files/" + current.path.split("/").slice(0, -1).join("/") + "/" + np;
        }
        return "/files/database/" + np;
      },
      missing: (t) => !titleSet.has(t.trim()),
      math: (tex, display) => renderMath(tex, display),
    };
  }

  function renderMath(tex, display) {
    if (window.katex) {
      try {
        return katex.renderToString(tex, { displayMode: display, throwOnError: false });
      } catch (e) { /* fall through */ }
    }
    // tiny fallback: keep the raw math visible
    return display ? '<div class="math-fallback">$$' + esc(tex) + "$$</div>"
      : "<em>" + esc(tex) + "</em>";
  }

  /* ---------------- route entry ---------------- */

  SB.views = SB.views || {};

  SB.views.note = async function (name) {
    editMode = false;
    draft = null;
    current = await SB.api.get("/api/note?path=" + encodeURIComponent(name));
    await refreshTitles();
    renderView();
  };

  /* ---------------- view mode ---------------- */

  function renderView(anchor) {
    const el = document.getElementById("main");
    const c = ctx();
    const qi = current.quick_info_rows || [];
    const qiHTML = qi.length ? quickInfoCard(qi, c) : "";
    const folderBits = (current.folder || "").split("/").filter(Boolean);

    el.innerHTML =
      '<div class="note-page">' +
      '<div class="crumbs">' +
      '<a href="#/home">' + SB.icon("home") + "</a>" +
      folderBits.map((f) => " <span class='sep'>›</span> <span>" + esc(f) + "</span>").join("") +
      " <span class='sep'>›</span> <b>" + esc(current.title) + "</b>" +
      '<span class="spacer"></span>' +
      '<button class="ghost" id="btn-pin" title="Pin to home">' +
      SB.icon("pin") + (current.pinned ? " Pinned" : " Pin") + "</button>" +
      "</div>" +
      '<div class="note-head"><h1 class="note-title">' + esc(current.title) + "</h1>" +
      '<div class="note-actions">' +
      '<button class="btn" id="btn-edit">' + SB.icon("edit") + " Edit</button>" +
      '<button class="btn" id="btn-copy">' + SB.icon("copy") + " Copy note</button>" +
      '<button class="btn" id="btn-export">' + SB.icon("download") + " Export metadata</button>" +
      '<button class="btn" id="btn-print">' + SB.icon("print") + " Print / PDF</button>" +
      "</div></div>" +
      '<div class="note-grid"><div class="note-main"><article id="note-body" style="font-size:var(--note-size)">' +
      SB.md.render(current.body, c) +
      "</article>" +
      '<section class="panel" id="panel-connections">' + connectionsPanel(c) + "</section>" +
      '<section class="panel" id="panel-references">' + referencesPanel() + "</section>" +
      '<section class="panel" id="panel-meta">' + metaPanel() + "</section>" +
      "</div>" +
      '<aside class="note-side">' + qiHTML + "</aside>" +
      "</div></div>";

    wireView();
    if (anchor) restoreAnchor(anchor);
  }

  function quickInfoCard(rows, c) {
    let html = '<div class="qicard"><div class="qicard-title">' + SB.icon("note") + " Quick info</div>";
    let group = null;
    rows.forEach((r) => {
      if (r.group && r.group !== group) {
        group = r.group;
        html += '<div class="qi-group">' + esc(group) + "</div>";
      }
      if (r.label.toLowerCase() === "image") {
        html += '<div class="qi-img"><img src="' + c.src(r.value) + '" loading="lazy" data-path="' + esc(r.value) + '"></div>';
      } else {
        html += '<div class="qi-row"><span class="qi-label">' + esc(r.label) +
          '</span><span class="qi-value">' + SB.md.inline(r.value, c) + "</span></div>";
      }
    });
    html += '<button class="ghost qi-edit">' + SB.icon("edit") + " Edit card</button></div>";
    return html;
  }

  function connectionsPanel(c) {
    const rows = (current.connected || []).map((t) => {
      const both = (current.backlinks || []).some((b) => b.endsWith("/" + t + "/" + t + ".md"));
      return '<li class="conn-row"><input type="checkbox" class="conn-sel" value="' + esc(t) + '">' +
        '<span class="conn-kind">' + (both ? "in + out" : "link out") + "</span> " +
        '<a href="#/note/' + encodeURIComponent(t) + '">' + esc(t) + "</a>" +
        '<button class="ghost tiny conn-rm" data-t="' + esc(t) + '">' + SB.icon("x") + "</button></li>";
    });
    const backs = (current.backlinks || []).map((b) => {
      const t = b.split("/").slice(-2)[0];
      const inText = (current.linked_in_text || []).some((l) => l.target === t);
      return '<li class="conn-row"><input type="checkbox" class="conn-sel" value="' + esc(t) + '">' +
        '<span class="conn-kind">' + (inText ? "linked in text" : "backlink") + "</span> " +
        '<a href="#/note/' + encodeURIComponent(t) + '">' + esc(t) + "</a></li>";
    });
    const inText = (current.linked_in_text || []).map((l) =>
      '<li class="conn-row"><span class="conn-kind">linked in text</span> "' +
      esc(l.word) + '" → ' + esc(l.target) +
      '<button class="ghost tiny link-unlink" data-w="' + esc(l.word) + '">unlink</button></li>');
    return '<div class="panel-title">' + SB.icon("graph") + " Connected notes</div>" +
      '<ul class="conn-list">' + rows.join("") + backs.join("") + inText.join("") + "</ul>" +
      (rows.length + backs.length + inText.length ? "" : '<p class="dim">No connections yet.</p>') +
      '<div class="panel-add"><button class="btn" id="conn-search">' + SB.icon("search") +
      " Search within selected</button></div>" +
      '<div class="panel-add"><input id="conn-input" placeholder="Connect to an existing note…" list="all-notes">' +
      '<button class="btn" id="conn-add">' + SB.icon("plus") + " Add</button>" +
      '<datalist id="all-notes">' +
      Array.from(titleSet).map((t) => "<option value='" + esc(t) + "'>").join("") +
      "</datalist></div>";
  }

  function referencesPanel() {
    const rows = (current.references || []).map((r) =>
      '<li><a class="weblink" href="' + esc(r.url) + '" target="_blank" rel="noopener">' +
      esc(r.title) + "</a>" + (r.accessed ? ' <span class="dim">— accessed ' + esc(r.accessed) + "</span>" : "") +
      '<button class="ghost tiny ref-rm" data-u="' + esc(r.url) + '">' + SB.icon("x") + "</button></li>");
    return '<div class="panel-title">' + SB.icon("link") + " Reference sources</div>" +
      '<ul class="ref-list">' + rows.join("") + "</ul>" +
      (rows.length ? "" : '<p class="dim">No reference sources yet.</p>') +
      '<div class="panel-add"><input id="ref-title" placeholder="Title"><input id="ref-url" placeholder="https://…">' +
      '<button class="btn" id="ref-add">' + SB.icon("plus") + " Add</button></div>";
  }

  function metaPanel() {
    const m = current.meta || {};
    const row = (k) => "<div class='qi-row'><span class='qi-label'>" + k +
      "</span><span>" + esc(m[k] || "—") + "</span></div>";
    const verify = current.status !== "verified"
      ? '<button class="btn" id="meta-verify">' + SB.icon("check") +
        " Mark verified (I approve this)</button>"
      : "";
    return '<div class="panel-title">' + SB.icon("gear") + " Metadata</div>" +
      row("status") + row("created") + row("updated") +
      '<div class="panel-add">' + verify +
      '<button class="btn" id="meta-edit">' + SB.icon("edit") + " Edit as form</button>" +
      '<button class="btn" id="meta-raw">' + SB.icon("edit") + " Edit raw block</button></div>" +
      '<p class="dim">Tags live in tags.txt beside the note. ' +
      (current.tagline || "") + "</p>";
  }

  /* ---------------- interactions ---------------- */

  function wireView() {
    document.getElementById("btn-edit").textContent =
      draft !== null ? "Back to editing" : "Edit";
    document.getElementById("btn-edit").onclick = () => {
      if (draft !== null) {
        // return to the editor with the unsaved draft preserved
        const text = draft;
        editMode = true;
        document.getElementById("main").innerHTML = editSkeleton();
        const ed = document.getElementById("editor");
        ed.value = text;
        wireEditor();
        ed.focus();
      } else {
        switchMode(true);
      }
    };
    document.getElementById("btn-copy").onclick = async () => {
      const withoutMeta = current.raw.replace(/:::meta\n[\s\S]*?:::\s*$/, "").trimEnd();
      try {
        await navigator.clipboard.writeText(withoutMeta);
        SB.toast("Note copied as raw Markdown.");
      } catch (e) {
        SB.toast("Clipboard blocked by the browser; copy from Edit mode instead.", "err");
      }
    };
    document.getElementById("btn-export").onclick = () => {
      window.location.href = "/api/export?path=" + encodeURIComponent(current.path);
    };
    document.getElementById("btn-print").onclick = () => window.print();
    const mv = document.getElementById("meta-verify");
    if (mv) mv.onclick = async () => {
      await SB.api.post("/api/metadata", { path: current.path, meta: { status: "verified" } });
      SB.toast("Verified. The note is approved.");
      reload();
    };
    document.getElementById("btn-pin").onclick = async () => {
      await SB.api.post("/api/pin", { path: current.path });
      SB.toast(current.pinned ? "Unpinned." : "Pinned to home.");
      current = await SB.api.get("/api/note?path=" + encodeURIComponent(current.path));
      renderView();
    };

    // connections
    const connSearch = document.getElementById("conn-search");
    if (connSearch) connSearch.onclick = () => {
      const sel = Array.from(document.querySelectorAll(".conn-sel:checked"))
        .map((c) => c.value);
      if (!sel.length) { SB.toast("Tick the connections to search within.", "err"); return; }
      location.hash = "#/search?limit_to=" + encodeURIComponent(sel.join(",")) + "&run=1";
    };
    const connAdd = document.getElementById("conn-add");
    if (connAdd) {
      connAdd.onclick = async () => {
        const t = document.getElementById("conn-input").value.trim();
        if (!t) return;
        try {
          await SB.api.post("/api/connections", { path: current.path, add: [t] });
          SB.toast("Connected to " + t + ".");
          reload();
        } catch (e) { SB.toast(e.message, "err"); }
      };
      document.querySelectorAll(".conn-rm").forEach((b) => (b.onclick = async () => {
        await SB.api.post("/api/connections", { path: current.path, remove: [b.dataset.t] });
        SB.toast("Connection removed; the other side updated its backlinks.");
        reload();
      }));
      document.querySelectorAll(".link-unlink").forEach((b) => (b.onclick = async () => {
        await SB.api.post("/api/links", { path: current.path, word: b.dataset.w, target: null });
        SB.toast("Link removed, the words stay.");
        reload();
      }));
    }

    // references
    const refAdd = document.getElementById("ref-add");
    if (refAdd) {
      refAdd.onclick = async () => {
        const title = document.getElementById("ref-title").value.trim();
        const url = document.getElementById("ref-url").value.trim();
        if (!url.startsWith("http")) return SB.toast("A reference needs an http(s) address.", "err");
        await SB.api.post("/api/references", { path: current.path, add: { title, url } });
        SB.toast("Reference source added.");
        reload();
      };
      document.querySelectorAll(".ref-rm").forEach((b) => (b.onclick = async () => {
        await SB.api.post("/api/references", { path: current.path, remove_url: b.dataset.u });
        reload();
      }));
    }

    // metadata
    document.getElementById("meta-edit").onclick = () => metaForm();
    document.getElementById("meta-raw").onclick = () => metaRaw();

    // quick info edit
    const qiEdit = document.querySelector(".qi-edit");
    if (qiEdit) qiEdit.onclick = () => quickInfoEditor();

    // images: click opens full screen
    document.querySelectorAll("#note-body img.md-img, .qi-img img").forEach((img) => {
      img.onclick = () => fullscreenImage(img);
      applySavedSize(img);
    });
  }

  async function reload() {
    current = await SB.api.get("/api/note?path=" + encodeURIComponent(current.path));
    await refreshTitles();
    renderView();
  }
  SB._reloadNote = reload;

  /* ---------------- edit mode + anchor ---------------- */

  function captureAnchor() {
    // record the block at the top of the screen, fraction into it, and px
    const body = document.getElementById("note-body");
    const editor = document.getElementById("editor");
    const container = body || editor;
    if (!container) return null;
    const top = container.getBoundingClientRect().top;
    if (body && body.style.display !== "none") {
      const blocks = body.querySelectorAll(".blk");
      for (const b of blocks) {
        const r = b.getBoundingClientRect();
        if (r.bottom > top + 1) {
          const frac = Math.min(1, Math.max(0, (top - r.top) / Math.max(1, r.height)));
          return { kind: "view", sl: +b.dataset.sl, frac, off: top };
        }
      }
      return { kind: "view", sl: 0, frac: 0, off: top };
    }
    // editor: top visible line
    const lh = parseFloat(getComputedStyle(editor).lineHeight) || 21;
    const line = Math.floor(editor.scrollTop / lh);
    return { kind: "edit", line, off: top };
  }

  function restoreAnchor(a) {
    const body = document.getElementById("note-body");
    const editor = document.getElementById("editor");
    if (a.kind === "edit" && editor) {
      const lh = parseFloat(getComputedStyle(editor).lineHeight) || 21;
      editor.scrollTop = a.line * lh;
      return;
    }
    if (!body || body.style.display === "none") return;
    const top = body.getBoundingClientRect().top;
    const blocks = body.querySelectorAll(".blk");
    let target = null, best = -1;
    for (const b of blocks) {
      const sl = +b.dataset.sl;
      if (sl <= a.sl || best < 0) { if (sl <= a.sl) { target = b; best = sl; } }
      if (!target) target = b;
    }
    if (!target) return;
    const r = target.getBoundingClientRect();
    window.scrollTo({ top: window.scrollY + (r.top + a.frac * r.height - top) , behavior: "instant" });
  }

  async function switchMode(toEdit, opts) {
    const anchor = opts && opts.noAnchor ? null : captureAnchor();
    if (toEdit) {
      editMode = true;
      const el = document.getElementById("main");
      el.innerHTML = editSkeleton();
      const ed = document.getElementById("editor");
      ed.value = current.raw;
      wireEditor();
      if (anchor && anchor.kind === "edit") { /* staying in edit */ }
      else if (anchor) {
        // map view block line -> editor scroll
        const lh = parseFloat(getComputedStyle(ed).lineHeight) || 21;
        const lines = current.raw.split("\n");
        let line = 0;
        for (let i = 0; i < lines.length; i++) {
          if (i >= anchor.sl) { line = i; break; }
        }
        ed.scrollTop = line * lh;
      }
      ed.focus();
    } else {
      editMode = false;
      // re-read from server unless caller already updated `current`
      renderView(anchor);
    }
  }
  SB.switchNoteMode = switchMode;

  function editSkeleton() {
    return '<div class="note-page"><div class="crumbs">' +
      '<a href="#/home">' + SB.icon("home") + "</a> <span class='sep'>›</span> <b>" +
      esc(current.title) + '</b><span class="spacer"></span>' +
      '<span id="save-state" class="dim"></span></div>' +
      '<div class="note-head"><h1 class="note-title">' + esc(current.title) + "</h1>" +
      '<div class="note-actions">' +
      '<button class="btn primary" id="btn-save">' + SB.icon("check") + " Save</button>" +
      '<button class="btn" id="btn-preview">' + SB.icon("eye") + " Preview</button>" +
      '<button class="btn" id="btn-cancel-edit">Cancel</button>' +
      "</div></div>" +
      '<div class="edit-toolbar" id="toolbar"></div>' +
      '<textarea id="editor" spellcheck="false"></textarea>' +
      '<p class="dim">Edit mode is a raw Markdown editor: what you type is exactly what is saved. ' +
      "Shortcut: <b>e</b> toggles edit/preview, <b>Ctrl/Cmd+S</b> saves.</p></div>";
  }

  const TOOLS = [
    ["Bold", "**", "**"], ["Italic", "*", "*"], ["Code", "`", "`"],
    ["Heading", "## ", ""], ["List", "- ", ""], ["Task", "- [ ] ", ""],
    ["Table", "\n| A | B |\n| --- | --- |\n| 1 | 2 |\n", ""],
    ["Quote", "> ", ""], ["Math", "$$", "$$"],
    ["Footnote", "[^1]", ""], ["HRule", "\n---\n", ""],
  ];

  function wireEditor() {
    const ed = document.getElementById("editor");
    const tb = document.getElementById("toolbar");
    tb.innerHTML = TOOLS.map((t, i) =>
      '<button class="ghost tool" data-i="' + i + '">' + t[0] + "</button>").join("") +
      '<button class="ghost tool" id="tool-wikilink">Wiki link</button>' +
      '<button class="ghost tool" id="tool-weblink">Web link</button>' +
      '<button class="ghost tool" id="tool-image">' + SB.icon("img") + " Image</button>";

    tb.querySelectorAll(".tool[data-i]").forEach((b) => {
      b.onclick = () => {
        const t = TOOLS[+b.dataset.i];
        wrapSelection(t[1], t[2]);
      };
    });
    document.getElementById("tool-wikilink").onclick = async () => {
      const sel = ed.value.slice(ed.selectionStart, ed.selectionEnd) || "word";
      const wrap = SB.modal("Link to a note", 
        "<p>Choose which words are the link and where it points.</p>" +
        '<label>Link text</label><input id="wl-word" value="' + esc(sel) + '">' +
        "<label>Target note (existing notes only)</label>" +
        '<input id="wl-target" list="all-notes">' +
        '<datalist id="all-notes">' +
        Array.from(titleSet).map((t) => "<option value='" + esc(t) + "'>").join("") +
        "</datalist>", [
        { label: "Cancel" },
        { label: "Insert [[Target|word]]", primary: true, onclick: (w) => {
          const word = w.querySelector("#wl-word").value;
          const target = w.querySelector("#wl-target").value.trim();
          if (!titleSet.has(target)) { SB.toast("No such note in this wiki.", "err"); return false; }
          wrapSelection("[[" + target + "|" + word + "]]", "");
        }},
      ]);
    };
    document.getElementById("tool-weblink").onclick = () => {
      SB.modal("Web link", "<label>Word</label><input id='we-word'>" +
        "<label>Address</label><input id='we-url' placeholder='https://…'>", [
        { label: "Cancel" },
        { label: "Insert", primary: true, onclick: (w) => {
          const word = w.querySelector("#we-word").value.trim() || "link";
          const url = w.querySelector("#we-url").value.trim();
          if (!/^https?:/.test(url)) { SB.toast("Needs an http(s) address.", "err"); return false; }
          wrapSelection("[" + word + "](" + url + ")", "");
        }},
      ]);
    };
    document.getElementById("tool-image").onclick = () => {
      const inp = document.createElement("input");
      inp.type = "file";
      inp.accept = "image/*";
      inp.onchange = async () => {
        const f = inp.files[0];
        if (!f) return;
        const b64 = await new Promise((res) => {
          const r = new FileReader();
          r.onload = () => res(r.result.split(",")[1]);
          r.readAsDataURL(f);
        });
        try {
          const out = await SB.api.post("/api/image/add", {
            path: current.path, filename: f.name, data_base64: b64,
          });
          wrapSelection("\n![" + f.name.replace(/\.[a-z]+$/i, "") + "](" + out.file + ")\n", "");
          SB.toast("Image added to attachments/ and placed in the note.");
        } catch (e) { SB.toast(e.message, "err"); }
      };
      inp.click();
    };

    document.getElementById("btn-save").onclick = saveNote;
    document.getElementById("btn-preview").onclick = () => {
      // save-free preview of exactly what is in the textarea
      draft = document.getElementById("editor").value;
      const parsed = stripBlocks(draft);
      current = Object.assign({}, current, {
        raw: draft, body: parsed.body,
        quick_info_rows: parsed.qiRows, quick_info_raw: parsed.qiRows.length ?
          parsed.qiRows.map((r) => r.label + ": " + r.value).join("\n") : null,
        meta: parsed.meta,
      });
      editMode = false;
      renderView(captureAnchor());
    };
    document.getElementById("btn-cancel-edit").onclick = () => {
      draft = null;
      editMode = false;
      reload();
    };
    ed.addEventListener("keydown", (e) => {
      if ((e.ctrlKey || e.metaKey) && e.key === "s") { e.preventDefault(); saveNote(); }
    });

    function wrapSelection(before, after) {
      const s = ed.selectionStart, e2 = ed.selectionEnd;
      const sel = ed.value.slice(s, e2);
      ed.setRangeText(before + sel + after, s, e2, "select");
      ed.focus();
    }
  }

  function stripBlocks(text) {
    // quick client-side strip for preview parity with the server parser
    let body = text.replace(/^# .*\n/, "");
    const qiM = body.match(/:::quick-info\n([\s\S]*?)\n:::/);
    let qiRows = [];
    if (qiM) {
      body = body.replace(qiM[0], "");
      let group = null;
      qiM[1].split("\n").forEach((ln) => {
        ln = ln.trim();
        if (!ln) return;
        if (ln.startsWith("##")) { group = ln.replace(/^#+\s*/, ""); return; }
        const m = ln.match(/^([^:]{1,60}):\s*(.*)$/);
        if (m) qiRows.push({ label: m[1], value: m[2], group });
      });
    }
    const metaM = body.match(/:::meta\n([\s\S]*?)\n:::/);
    const meta = {};
    if (metaM) {
      body = body.replace(metaM[0], "");
      metaM[1].split("\n").forEach((ln) => {
        const m = ln.match(/^([A-Za-z]+):\s*(.*)$/);
        if (m) meta[m[1].toLowerCase()] = m[2];
      });
    }
    return { body: body.trim(), qiRows, meta };
  }

  async function saveNote() {
    const ed = document.getElementById("editor");
    const state = document.getElementById("save-state");
    state.textContent = "Saving…";
    try {
      const out = await SB.api.post("/api/note/save", {
        path: current.path, text: ed.value, base_hash: current.hash,
      });
      if (out.conflict) {
        SB.modal("The file changed while it was open",
          "<p>" + esc(out.message) + "</p>", [
          { label: "Cancel" },
          { label: "Reload my editor with the new file", onclick: () => reload() },
          { label: "Overwrite with my version", primary: true, onclick: async () => {
            await SB.api.post("/api/note/save", {
              path: current.path, text: ed.value, base_hash: out.current_hash,
              force: true,
            });
            SB.toast("Overwritten. The previous text is in the log.");
            reload();
          }},
        ]);
        state.textContent = "";
        return;
      }
      current.hash = out.hash;
      draft = null;
      state.textContent = "Saved " + new Date().toLocaleTimeString();
      SB.toast("Saved. One log file recorded the change.");
    } catch (e) {
      state.textContent = "";
      SB.toast(e.message, "err");
    }
  }

  /* ---------------- metadata editors ---------------- */

  function metaForm() {
    const m = current.meta || {};
    const field = (k) =>
      "<label>" + k + '</label><input id="mf-' + k + '" value="' + esc(m[k] || "") + '">';
    SB.modal("Edit metadata",
      field("Status") + field("Created") + field("Updated"), [
      { label: "Cancel" },
      { label: "Save", primary: true, onclick: async (w) => {
        const g = (k) => w.querySelector("#mf-" + k).value;
        await SB.api.post("/api/metadata", { path: current.path,
          meta: { status: g("Status"), created: g("Created"), updated: g("Updated") } });
        SB.toast("Metadata saved.");
        reload();
      }},
    ]);
  }

  function metaRaw() {
    const m = current.meta || {};
    const text = Object.keys(m).map((k) => k.charAt(0).toUpperCase() + k.slice(1) + ": " + m[k]).join("\n");
    SB.modal("Metadata block (raw)", "<textarea id='meta-raw-text' rows='6'>" + esc(text) + "</textarea>", [
      { label: "Cancel" },
      { label: "Save", primary: true, onclick: async (w) => {
        const meta = {};
        w.querySelector("#meta-raw-text").value.split("\n").forEach((ln) => {
          const mm = ln.match(/^([A-Za-z][A-Za-z0-9 _-]*):\s*(.*)$/);
          if (mm) meta[mm[1].toLowerCase()] = mm[2];
        });
        await SB.api.post("/api/metadata", { path: current.path, meta });
        SB.toast("Metadata saved.");
        reload();
      }},
    ]);
  }

  function quickInfoEditor() {
    const c = ctx();
    SB.modal("Edit quick info card",
      "<p class='dim'>One line per fact, <b>Label: value</b>. A line starting with " +
      "<b>##</b> begins a named group. Raw editing shows the same text the file holds.</p>" +
      "<textarea id='qi-text' rows='10'>" + esc(current.quick_info_raw || "") + "</textarea>", [
      { label: "Cancel" },
      { label: "Save card", primary: true, onclick: async (w) => {
        try {
          await SB.api.post("/api/quick_info", { path: current.path, text: w.querySelector("#qi-text").value });
          SB.toast("Quick info saved.");
          reload();
        } catch (e) { SB.toast(e.message, "err"); return false; }
      }},
    ]);
  }

  /* ---------------- images ---------------- */

  function applySavedSize(img) {
    const key = "imgsize:" + current.path + ":" + img.dataset.path;
    const w = localStorage.getItem(key);
    if (w && !img.closest(".md-imggrid")) img.style.width = w;
  }

  function fullscreenImage(img) {
    const path = img.dataset.path;
    const src = img.src;
    const wrap = document.createElement("div");
    wrap.className = "fullscreen-img";
    wrap.innerHTML =
      '<div class="fs-tools">' +
      '<button class="btn" id="fs-crop">' + SB.icon("crop") + " Crop</button>" +
      '<a class="btn" id="fs-download" download="' + esc(path.split("/").pop()) + '" href="' + src + '">' +
      SB.icon("download") + " Download</a>" +
      '<button class="btn" id="fs-delete">' + SB.icon("trash") + " Delete</button>" +
      '<button class="btn" id="fs-close">' + SB.icon("x") + " Close</button></div>" +
      '<div class="fs-stage"><img id="fs-img" src="' + src + '"></div>';
    document.body.appendChild(wrap);
    wrap.querySelector("#fs-close").onclick = () => wrap.remove();
    wrap.addEventListener("mousedown", (e) => { if (e.target === wrap) wrap.remove(); });

    wrap.querySelector("#fs-delete").onclick = () => {
      SB.confirm("Delete this image? The file is kept in backup history and you will be warned if the note still points to it.", async () => {
        try {
          const out = await SB.api.post("/api/image/delete", { path: current.path, filename: path.split("/").pop() });
          SB.toast(out.warning ? out.message : "Deleted; the file is kept in backup history.", out.warning ? "err" : "");
          wrap.remove();
          reload();
        } catch (e) { SB.toast(e.message, "err"); }
      });
    };

    wrap.querySelector("#fs-crop").onclick = () => startCrop(wrap, path, src);
  }

  function startCrop(wrap, path, src) {
    const stage = wrap.querySelector(".fs-stage");
    const img = wrap.querySelector("#fs-img");
    stage.style.cursor = "crosshair";
    let x0 = 0, y0 = 0, x1 = 0, y1 = 0, drawing = false;
    let box = document.createElement("div");
    box.className = "crop-box";
    stage.appendChild(box);

    const toImgCoords = (e) => {
      const r = img.getBoundingClientRect();
      const sx = img.naturalWidth / r.width, sy = img.naturalHeight / r.height;
      return {
        x: Math.max(0, Math.min(img.naturalWidth, (e.clientX - r.left) * sx)),
        y: Math.max(0, Math.min(img.naturalHeight, (e.clientY - r.top) * sy)),
        r,
      };
    };
    const onDown = (e) => {
      const c = toImgCoords(e);
      x0 = c.x; y0 = c.y; drawing = true;
    };
    const onMove = (e) => {
      if (!drawing) return;
      const c = toImgCoords(e);
      x1 = c.x; y1 = c.y;
      const r = c.r;
      box.style.left = Math.min(e.clientX, e.clientX) - r.left + "px";
      // position box in stage coordinates
      const sr = stage.getBoundingClientRect();
      const ir = img.getBoundingClientRect();
      const scale = ir.width / img.naturalWidth;
      box.style.left = (ir.left - sr.left + Math.min(x0, x1) * scale) + "px";
      box.style.top = (ir.top - sr.top + Math.min(y0, y1) * scale) + "px";
      box.style.width = (Math.abs(x1 - x0) * scale) + "px";
      box.style.height = (Math.abs(y1 - y0) * scale) + "px";
    };
    const onUp = () => {
      if (!drawing) return;
      drawing = false;
      const w = Math.round(Math.abs(x1 - x0)), h = Math.round(Math.abs(y1 - y0));
      if (w < 5 || h < 5) return;
      const rect = { x: Math.round(Math.min(x0, x1)), y: Math.round(Math.min(y0, y1)), w, h };
      SB.modal("Crop is saved as a new image",
        "<p>Rectangle " + rect.w + " × " + rect.h + " px. What should happen to the original?</p>", [
        { label: "Cancel" },
        { label: "Keep both", onclick: async () => finishCrop("keep_both") },
        { label: "Replace the original (old one is backed up first)", primary: true,
          onclick: async () => finishCrop("replace") },
      ]);
      async function finishCrop(mode) {
        try {
          const out = await SB.api.post("/api/image/crop", {
            path: current.path, filename: path.split("/").pop(), rect, mode,
          });
          SB.toast(mode === "replace"
            ? "Replaced; the original is backed up as " + out.original_backed_up_as
            : "New image saved: " + out.new_image);
          wrap.remove();
          reload();
        } catch (e) { SB.toast(e.message, "err"); }
      }
    };
    stage.onmousedown = onDown;
    stage.onmousemove = onMove;
    stage.onmouseup = onUp;
  }

  /* resize handles in the viewer */
  document.addEventListener("click", (e) => {
    const img = e.target.closest("img.md-img");
    if (!img || editMode) return;
    if (e.altKey) {
      // alt+click cycles a comfortable reading width
      const widths = ["40%", "60%", "80%", "100%"];
      const cur = img.style.width || "100%";
      const next = widths[(widths.indexOf(cur) + 1) % widths.length];
      img.style.width = next;
      localStorage.setItem("imgsize:" + current.path + ":" + img.dataset.path, next);
      SB.toast("Image width " + next + " (Alt+click to change; grid images keep the tidy grid).");
    }
  });
})();
