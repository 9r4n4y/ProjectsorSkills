/* SecondBrain app shell (app.js): router, topbar, keyboard shortcuts.
 * One key opens search (/), one toggles edit mode (e). */
(function () {
  "use strict";
  const SB = window.SB;

  const routes = {
    "": () => SB.views.home(),
    home: () => SB.views.home(),
    search: (p) => SB.views.search(p),
    note: (p) => SB.views.note(decodeURIComponent(p || "")),
    tags: () => SB.views.tags(),
    graph: () => SB.views.graph(),
    health: () => SB.views.health(),
    backup: () => SB.views.backup(),
    tools: () => SB.views.tools(),
  };

  async function route() {
    const h = location.hash.replace(/^#\/?/, "");
    // Two link styles are used across the app:
    //   #/search?q=...        (query string)
    //   #/note/<Note Name>    (path segment)
    const qm = h.indexOf("?");
    const path = qm >= 0 ? h.slice(0, qm) : h;
    const query = qm >= 0 ? h.slice(qm + 1) : "";
    const segs = path.split("/").filter(Boolean);
    const name = segs[0] || "";
    const param = segs.slice(1).join("/") + (query ? (segs.length > 1 ? "?" : "") + query : "");
    const fn = routes[name] || routes.home;
    SB.state.route = name;
    document.querySelectorAll(".nav a").forEach((a) => {
      a.classList.toggle("active", a.dataset.route === name);
    });
    try {
      await fn(param);
    } catch (e) {
      document.getElementById("main").innerHTML =
        '<div class="notice">Something went wrong: ' + SB.esc(e.message) + "</div>";
    }
    window.scrollTo(0, 0);
  }

  function topbar() {
    document.getElementById("topbar").innerHTML =
      '<a class="brand" href="#/home">Second<span>Brain</span></a>' +
      '<nav class="nav">' +
      nav("home", "Home", "home") + nav("tags", "Tags", "tag") +
      nav("graph", "Graph", "graph") + nav("health", "Health", "health") +
      nav("backup", "Backup", "backup") +
      "</nav>" +
      '<span class="spacer"></span>' +
      '<button class="btn primary" id="new-note">' + SB.icon("plus") + " New note</button>" +
      '<select class="theme-select" title="Theme">' +
      ["light", "dark", "coffee", "orange"].map((t) =>
        '<option value="' + t + '">' + t + "</option>").join("") +
      "</select>" +
      '<div class="sizectl" title="Text size">' +
      '<button class="ghost" id="size-down">A−</button>' +
      '<button class="ghost" id="size-up">A+</button></div>';
    function nav(r, label, ic) {
      return '<a href="#/' + r + '" data-route="' + r + '">' + SB.icon(ic) + " " + label + "</a>";
    }
    const sel = document.querySelector(".theme-select");
    sel.value = SB.state.theme;
    sel.onchange = () => SB.setTheme(sel.value);
    document.getElementById("size-up").onclick = () =>
      SB.setNoteSize(Math.min(22, SB.state.noteSize + 1));
    document.getElementById("size-down").onclick = () =>
      SB.setNoteSize(Math.max(14, SB.state.noteSize - 1));
    document.getElementById("new-note").onclick = newNoteDialog;
  }

  function newNoteDialog() {
    SB.api.get("/api/folders").then((f) => {
      const opts = [];
      const walk = (n, depth) => {
        if (n.path !== "" && !n.private) opts.push({ p: n.path, n: n.name, d: depth });
        (n.children || []).forEach((c) => walk(c, depth + 1));
      };
      walk(f.tree, 0);
      SB.modal("Create a new note",
        "<p class='dim'>The app creates the note folder with <b>&lt;Note Name&gt;.md</b>, " +
        "tags.txt and attachments/. File names are detailed and descriptive, unique across the wiki.</p>" +
        "<label>Note name</label><input id='nn-name' placeholder='e.g. Cold Brew Coffee Ratios'>" +
        "<label>Folder</label><select id='nn-folder'>" +
        opts.map((o) => "<option value='" + SB.esc(o.p) + "'>" +
          "&nbsp;".repeat(o.d * 2) + SB.esc(o.n) + "</option>").join("") +
        "</select><label>Tags (comma separated, dash notation)</label>" +
        "<input id='nn-tags' placeholder='COOKING-drinks, METHOD-cold_brew'>", [
        { label: "Cancel" },
        { label: "Create and open", primary: true, onclick: async (w) => {
          const name = w.querySelector("#nn-name").value.trim();
          const folder = w.querySelector("#nn-folder").value;
          const tags = w.querySelector("#nn-tags").value.split(",").map((t) => t.trim()).filter(Boolean);
          if (!name) { SB.toast("Give the note a detailed name.", "err"); return false; }
          try {
            const out = await SB.api.post("/api/note/create", { folder, name, tags });
            if (out.proposed_tags && out.proposed_tags.length) {
              SB.toast("Created. Proposed tags need approval in _tags.md: " +
                out.proposed_tags.join(", "));
            } else SB.toast("Created.");
            location.hash = "#/note/" + encodeURIComponent(name);
          } catch (e) { SB.toast(e.message, "err"); return false; }
        }},
      ]);
    });
  }

  /* keyboard shortcuts */
  document.addEventListener("keydown", (e) => {
    const inField = /input|textarea|select/i.test(document.activeElement.tagName);
    if (e.key === "/" && !inField) {
      e.preventDefault();
      if (SB.state.route !== "search") {
        location.hash = "#/search";
        setTimeout(() => document.getElementById("s-q")?.focus(), 300);
      } else document.getElementById("s-q")?.focus();
    }
    if ((e.key === "e" || e.key === "E") && !inField && SB.state.route === "note") {
      const btn = document.getElementById("btn-edit");
      if (btn) btn.click();
    }
  });

  SB.setTheme(SB.state.theme);
  SB.setNoteSize(SB.state.noteSize);
  topbar();
  window.addEventListener("hashchange", route);
  route();
})();
