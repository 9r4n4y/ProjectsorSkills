# StructureOFnotes — the exact rulebook for every note

This is the rulebook for how every note in SecondBrain is written. It is
for you and for the AI. The website checks notes against it, the parser
implements it, and the AI reads it before writing anything. If a file
follows this page, every tool reads it perfectly; anything not described
here is treated as plain text and preserved untouched.

---

## 1. The anatomy of a note

Every note is a **folder** named exactly like the note, containing exactly
three things:

```
database/<Subject>/.../<Note Name>/
├── <Note Name>.md    the note file (this page describes it)
├── tags.txt          the note's tags, comma separated (section 5)
└── attachments/      images only
```

The `.md` file itself has five parts, in this order:

```
1. # The Note Title              (an H1 heading, the same words as the folder)
2. :::quick-info ... :::         (optional quick info card — section 3)
3. The main text                 (any Markdown — section 4)
4. ## My notes                   (optional — section 6)
5. ## Connected notes            (section 7)
   ## Reference sources          (section 8)
   :::meta ... :::               (metadata — section 9)
```

Parts 1, 3 are required in practice (a note with no text is just a
stub); 2, 4 are optional; 5 is always created by the tools. The website
shows the parts in exactly this order: title and breadcrumb on top, then
the quick info card, then the text, then Connected notes, Reference
sources, Metadata — no matter how the sections are arranged in the file,
but the standard order above is what the tools write.

## 2. File and folder naming rules

- A note folder and its `.md` file share the note's exact name; note names
  are unique across the whole wiki, even when capital letters are ignored.
- Names may contain letters, digits, spaces, accents, dashes and
  underscores. They may **not** contain `\ / : * ? " < > |` or control
  characters, and they never end with a space or a dot. Accents are
  normalized the same way on every system (NFC).
- Subject folders follow the same rules; a subject folder never contains
  loose files (only note folders, sub-subjects and an optional
  `_subject.md`).
- Attachments live only in a note's `attachments/` folder, only as image
  files (`.png .jpg .jpeg .gif .webp .svg .bmp`).
- Everything is UTF-8 with LF line endings; all paths inside the project
  are relative.

## 3. The quick info card (`:::quick-info`)

The small fact card at the top of a note, like the box beside the first
paragraph of a wiki page. It lives inside the note file — no separate
file, no extra folder — so it moves, searches and backs up with the note.

```
:::quick-info
Common name: Vegetable Pasta
Serves: 4
Often paired with: [[Garlic Bread]]
Image: attachments/pasta-1.jpg

## Dietary notes
Vegetarian: Yes
Vegan: No (parmesan)
:::
```

Rules:

- One line per fact: `Label: value`. The first colon separates them; the
  label is short (up to ~60 characters), the value is the rest of the line.
- Values may hold **bold**, *italics*, web links `[text](url)` and wiki
  links `[[Note Name]]`.
- A line starting with `## ` begins a named group of rows (like
  `## Dietary notes` above); groups are shown as titled sections of the
  card.
- A line starting with `Image:` adds a photo from `attachments/`
  (several `Image:` lines are allowed; the card shows them in order).
- Empty lines are allowed and ignored.
- The website renders the block as a styled card. **Edit card** gives a
  form (add, remove, reorder rows and groups, pick the image); raw editing
  shows exactly the text above. Both change the same text in the file.
- Quick info is searchable: **labels count like headings and values count
  like body text** (spec 13).
- A note without a quick info block simply has no card.
- Labels `Common name`, `Also known as`, `Aliases`, `AKA` are treated as
  **title aliases** in search: a query matching an alias ranks the note as
  if it matched the title.

## 4. The main text — every Markdown form the website supports

What you type in edit mode is exactly what is saved in the file. The
renderer supports:

| Form | How it is written |
| --- | --- |
| Headings | `## Section`, `### Sub-section` … up to `######` (the note title is the `#` H1) |
| Bold / italic | `**bold**`, `*italic*` or `_italic_` |
| Bullet lists | `- item` or `* item`, nested by two-space indentation |
| Numbered lists | `1. item`, `2. item` |
| Task lists | `- [ ] open task`, `- [x] done task` |
| Tables | `\| Column \| Column \|` then a `\| --- \| --- \|` separator row, then rows |
| Code blocks | ` ```lang ` … ` ``` ` (a language name may follow the fence) |
| Inline code | `` `code` `` |
| Quotes | `> quoted text` (consecutive quote lines form one quote) |
| Footnotes | `[^id]` in the text and `[^id]: the note text` on its own line; the list renders at the end |
| Images | `![alt](attachments/file.png)` — rendered **exactly where placed**; an optional width: `![alt|60%](attachments/file.png)`; three or more consecutive standalone images arrange into a tidy grid |
| Web links | `[text](https://example.com)` — opens in a new tab |
| Wiki links | `[[Note Name]]` or `[[Note Name|word]]` — opens the note; a missing target renders dashed and is flagged by the health check |
| Horizontal rules | `---` or `***` alone on a line |
| LaTeX math | `$e = mc^2$` inline, `$$ ... $$` as a display formula (KaTeX, bundled offline) |

Not rendered (kept as plain text, faithfully preserved): raw HTML, custom
directives other than the `:::quick-info`, `:::meta` and `:::undo` blocks
the system itself writes.

**Links on words.** Selecting a word and choosing *link* offers a note in
the wiki (`[[File Name|word]]`) or a web address (`[word](https://…)`);
clicking the word opens the target. You can change which words carry the
link, change the target, or remove the link and keep the words — from the
note page or with the `edit_links` tool.

## 5. Tags (`tags.txt`)

- One `tags.txt` per note, next to the `.md` file. Entries separated by
  commas, for example:

  ```
  COOKING-weeknight, FOOD-pasta-vegetarian, METHOD-stovetop-one_pot, INGREDIENT-garlic
  ```

- `MAJOR-sub-subsub`: a dash is one level deeper, as deep as needed; a
  space inside a level is an underscore; no commas or dashes inside a
  level; capitals ignored (majors are written in capitals by convention).
- A deep tag also counts for its parents: `FOOD-pasta-vegetarian` is found
  by `FOOD-pasta` and `FOOD`.
- The master list is `_tags.md`. A tag used on a note but missing there is
  flagged by the health check and cannot be picked in search until it is
  approved. Adding a major tag or sub-tag to `_tags.md` makes it available
  everywhere at once.

## 6. `My notes` — append-only

- `## My notes` holds your own observations, dated lines work well:

  ```
  ## My notes

  - 2026-10-20: made it with frozen peas — works well.
  ```

- **Nothing in the system ever overwrites or rewrites this section.** The
  only change anyone (including the AI, through `append_my_notes`) may
  make is adding lines at the end. The engine refuses any edit that
  alters or removes existing lines.

## 7. Connected notes

- Written in `## Connected notes` as one `[[File Name]]` per line — file
  names, not paths, so notes can move between folders without breaking
  links.

  ```
  ## Connected notes

  [[Garlic Bread]]
  [[Lentil Soup for Cold Evenings]]
  ```

- Backlinks are generated automatically; the panel shows every connection
  with a badge: out, in, or both.
- Links written inside the text (`[[File Name|word]]`) appear in the panel
  marked *linked in text* and can be edited there (the linked words, the
  target, or unlink) — no connection is invisible.
- Adding a connection uses type-ahead of existing file names: a connection
  to a note that does not exist cannot be created.
- Renaming or moving a note rewrites every link to it everywhere.
- Connected notes affect search (neighbor and backlink bonuses);
  connected sets can be searched as a group from the panel.

## 8. Reference sources

- Written in `## Reference sources`, one per line:

  ```
  ## Reference sources

  - [BBC Good Food: one-pot pasta technique](https://www.bbcgoodfood.com/one-pot-pasta) — accessed 2026-10-15
  ```

- `[Title](url)` plus the date accessed after a dash (`— accessed
  YYYY-MM-DD` or `- accessed YYYY-MM-DD` — both parse).
- Reference sources are **proof of where a fact came from**. They never
  mix with Connected notes (which point to notes in this wiki) and they do
  not affect search ranking.

## 9. Metadata (`:::meta`)

Metadata lives at the bottom of the note file in a simple block, so the
top of the file stays clean text:

```
:::meta
Status: verified
Created: 2026-10-15
Updated: 2026-10-31
Pinned: no
:::
```

- `Status` is `verified` or `unverified`. Everything the AI writes is
  `unverified` until you approve it (the website shows a *Mark verified*
  control; the AI cannot set verified).
- `Created` and `Updated` are `YYYY-MM-DD`; the engine touches `Updated`
  on every saved change.
- `Pinned: yes` shows the note on the home page.
- Other `Key: value` lines are preserved and editable (form or raw).
- The website shows the block in the same place on the page and can edit
  it as a form or as raw text.

## 10. What the website reads vs. plain text

Parsed and understood by the tools: the H1 title; `:::quick-info` (rows,
groups, images); headings; task list states; wiki links (section and
in-text); web links and reference dates; images under `attachments/`;
`:::meta`; `tags.txt`. Everything else — prose, tables, code, math,
quotes — is rendered faithfully and stored byte-for-byte; the parser never
reformats the parts it does not understand.

## 11. Subject files (`_subject.md`)

Optional, one per subject folder:

```
Purpose: what this subject is for
Template: Tasting Note        (optional: a note name whose body pre-fills new notes here)
Sensitivity: private          (optional: private = hidden, locked, excluded from the index)
Inherits: sensitivity         (optional: fields taken from the parent subject when unset)
```

## 12. The inbox

Raw, unsorted notes (`.md` or `.txt`, flat, no sub-folders) waiting for
the AI librarian. Anything goes in — fragments, clippings, reminders. The
librarian files them into the deepest matching subject, asks before
creating folders, and never deletes the original until you say so.
