import { BookOpen, ChevronRight, HelpCircle } from "lucide-react";
import { useStore } from "@/lib/store";
import { Card } from "@/components/PageShell";
import { Button } from "@/components/ui/button";

const QUICK_TIPS = [
  "Edge Panel: swipe left or tap the slim right-edge tab for navigation, folders, and Page top/bottom.",
  "Tags & Authors: tap Tag in Search to switch between regular Tags and dedicated Author tags.",
  "Connect Parts: open any comic → Connect parts to link Part 1, 2, 3, 4… and read seamlessly across parts.",
  "Reader: tap narrow left/right edges in Tap mode for instant 120Hz turns, or pinch-zoom smoothly in Scroll mode.",
  "Security & Backup: set up to 3 App Lock passwords and export checksum-verified metadata JSON backups.",
];

export function TutorialCard() {
  const setScreen = useStore((s) => s.setScreen);
  return (
    <Card title="Quick guide & tutorial" actions={<HelpCircle className="size-4 text-sub" />}>
      <ul className="mb-4 flex list-disc flex-col gap-1.5 pl-5 text-[13px] leading-5 text-sub">
        {QUICK_TIPS.map((tip, i) => (
          <li key={i}>{tip}</li>
        ))}
      </ul>
      <Button variant="secondary" onClick={() => setScreen("tutorial")}>
        <BookOpen />Open detailed tutorial<ChevronRight className="size-4" />
      </Button>
    </Card>
  );
}
