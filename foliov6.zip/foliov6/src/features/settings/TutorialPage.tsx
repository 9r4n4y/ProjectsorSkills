import { useMemo, useState } from "react";
import {
  ArrowLeft,
  BookOpen,
  Download,
  FolderTree,
  Keyboard,
  Layers,
  Link2,
  Lock,
  Search,
  ShieldCheck,
  Sliders,
  Sparkles,
  Tag,
  X,
} from "lucide-react";
import { useStore } from "@/lib/store";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/controls";
import { Card, PageShell } from "@/components/PageShell";

interface GuideSection {
  id: string;
  icon: React.ElementType;
  title: string;
  summary: string;
  steps: string[];
  settings?: string[];
  example: string;
}

const GUIDE_SECTIONS: GuideSection[] = [
  {
    id: "library",
    icon: FolderTree,
    title: "1. Library, Edge Panel & One-Step Back History",
    summary: "Browse your entire offline comic collection with zero clutter and predictable step-by-step Back navigation.",
    steps: [
      "Pick your Mother folder in Settings (or during first launch). Every subfolder containing images automatically appears as a comic.",
      "Swipe left or tap the slim lilac Edge Panel tab on the right side of the screen to jump between Library, Favorites, Recently Read, Tags, Extraction, Verification, Health, Settings, folders, and Page top / Page bottom.",
      "Back navigation always moves one step back in history: Reader → Comic Preview (Quick Look) → Library, and sub-pages like Keyboard Shortcuts or Detailed Tutorial → Settings → previous screen.",
    ],
    settings: [
      "Settings → Appearance and reading → Comics per page: choose 20, 50, 100, custom count, or Unlimited (continuous scroll with no page breaks).",
      "Settings → Appearance and reading → Show reading progress bar: off by default so covers stay clean; turn on to display a progress bar at the bottom of partially read covers.",
    ],
    example: "Example: Tap a comic cover to open Quick Look preview → tap Page 12 to start reading → press Android Back or X to return straight to Quick Look preview → press Back again to return to your exact scroll spot in the Library.",
  },
  {
    id: "tags-authors",
    icon: Tag,
    title: "2. Search, Tags & Dedicated Author Tags",
    summary: "Filter by name, regular tags, dedicated Author tags (completely separate from folders), or folders.",
    steps: [
      "Tap the Tag button in the library search bar to open the filter panel with two tabs: Tags and Authors.",
      "Authors are dedicated user-assigned Author tags—never folder names. To add an Author tag, open any comic (or select multiple comics), tap the Tag icon, switch to the Authors tab, type one or more comma-separated author names, and tap Apply.",
      "In the Filter panel, tap any tag/author (or press +) to include it, or press - to exclude it. Switch between All (AND) and Any (OR) for multi-tag filtering.",
      "Open the Tags screen from the Edge Panel to switch between Tags and Authors, rename, merge, delete, or bulk-tag any group.",
    ],
    example: "Example: Tag 15 comics with Author 'Aoki Rin' and regular tag 'color'. In Search, tap Tag → Authors → + Aoki Rin, then switch to Tags → + color to instantly see only colored comics by Aoki Rin.",
  },
  {
    id: "mass-select",
    icon: Sliders,
    title: "3. Mass Select & Bulk Tagging Across All Pages",
    summary: "Select dozens or hundreds of comics at once—across all pages, an entire folder, or a whole tag/author group.",
    steps: [
      "Tap the Select icon in the search bar (or long-press any comic card) to enter Select mode.",
      "Tap 'Select all (N)' in the bottom bar to select EVERY matching comic across every page (even across 14+ pages), not just the current page.",
      "Tap Tags in the bottom bar to add or remove regular tags or Author tags on all selected comics at once, or tap Favorite / Move.",
      "For one-tap folder or tag-group tagging, open the Edge Panel or Filter panel and tap the small Tag icon beside any folder, tag, or author.",
    ],
    example: "Example: Filter by Folder 'Downloads', tap Select → Select all (84) → Tags → add 'to-read, monochrome' → Apply. All 84 comics are tagged in one action in standard metadata format.",
  },
  {
    id: "connect-parts",
    icon: Link2,
    title: "4. Connect Comic Parts & Force-Group Together",
    summary: "Link multi-part comics into Part 1, 2, 3, 4… with smart recommendations and seamless part-to-part reading.",
    steps: [
      "Open any comic in Quick Look (or tap the Link icon in the Reader top bar) and tap Connect parts.",
      "Folio automatically analyzes titles, CamelCase/underscores, bracketed circles, part/volume/chapter/Roman numbers, and Author tags to place the strongest matches (like 'Next part (#2)') right at the very top.",
      "Tap any comic's cover or title (or Preview) to inspect its full untruncated name and page photos before connecting it, then assign it directly as Part 1, Part 2, Part 3, Part 4… or reorder parts with the Up/Down buttons.",
      "While reading a connected comic in Scroll mode, scroll to the end for a one-tap Next Part card (or top for Previous Part). In Tap mode, tapping the right edge on the last page glides straight into Part N+1 (Page 1), and tapping the left edge on Page 1 goes back to Part N-1.",
    ],
    settings: [
      "Settings → Appearance and reading → Group connected parts together (Default: ON): keeps connected parts arranged side by side in Part 1, 2, 3… order no matter which sort mode you pick (Name A–Z, Z–A, Date Added, Date Modified, etc.). Turn OFF for normal independent sorting.",
    ],
    example: "Example: Open 'Silent Atlas Vol. 1' → tap Connect parts → Folio suggests 'Silent Atlas Vol. 2' ('Next part (#2)') and 'Vol. 3' at the top → tap + Part 2 and + Part 3. Now all 3 stay grouped together in your Library and flow seamlessly when you finish reading Part 1.",
  },
  {
    id: "reader",
    icon: BookOpen,
    title: "5. Comic Reader: 120Hz Edge Tap, Scroll Zoom & Lock Mode",
    summary: "Zero-flicker reading engineered for high-refresh screens in Tap, Scroll, and Auto modes.",
    steps: [
      "Tap pages mode: tap the narrow, thumb-friendly invisible left edge for the previous page or the right edge for the next page (instant 0ms switch with eager page preloading and zero zoom-bounce flicker—works both unzoomed and zoomed in). Tap the center to show/hide reader bars, or double-tap to zoom.",
      "Scroll mode: continuous vertical strip with thick black dividers between pages. Pinch or double-tap to zoom smoothly; scrolling while zoomed maintains constant speed and smooth inertia.",
      "Lock Mode: tap the Lock icon in the reader top bar to hide all UI and block accidental taps. Tap the thin lilac edge tab on the right side (or press Back) to bring controls back.",
    ],
    settings: [
      "Settings → Appearance and reading → When opening a comic: choose 'Last page' (default, resumes where you left off) or 'From start' (always opens at Page 1).",
      "Settings → Appearance and reading → Zoom pan sensitivity (0.5× to 2.5×): controls how far the zoomed page moves per swipe across all reading modes.",
      "Settings → Appearance and reading → Always keep screen awake: keeps your screen from dimming or turning off while Folio is open.",
    ],
    example: "Example: Turn on Always keep screen awake, set Zoom pan sensitivity to 1.4×, open a comic in Tap mode, zoom in on a detailed panel, pan around smoothly, and tap the right edge with your thumb to jump cleanly to the next page without unzooming.",
  },
  {
    id: "export",
    icon: Download,
    title: "6. Direct Page & Full Comic (.cbz) Export",
    summary: "Save any single page image or bundle an entire comic into a portable .cbz archive.",
    steps: [
      "Inside the Reader top bar, tap the Download icon to export the currently opened page in its original image format or export the entire comic as a .cbz file.",
      "You can also export a full comic directly from Quick Look using the Download button.",
    ],
    example: "Example: Spot a favorite cover or spread on Page 7 → tap Download → Export page 7 to save the full-resolution image straight to your device.",
  },
  {
    id: "extract",
    icon: Layers,
    title: "7. Archive Extraction, Verification & Saved Passwords",
    summary: "Unpack .zip, .cbz, .7z, .rar, and multi-volume archives with 10-layer integrity verification.",
    steps: [
      "Place comic archives inside your Mother folder and tap Rescan in Settings (or Extraction).",
      "Open Extraction to unpack archives automatically with 10-layer verification (archive headers, file counts, checksums, and magic-byte image decoding).",
      "Add recurring archive passwords under Settings → Saved archive passwords so encrypted archives extract without prompting each time.",
    ],
    example: "Example: Drop 12 password-protected .7z archives into your Mother folder, save the password once in Settings, and tap Extract all—Folio unpacks and verifies every page automatically.",
  },
  {
    id: "applock",
    icon: Lock,
    title: "8. App Lock: 3 Passwords, Idle Countdown & Always-Live State",
    summary: "Protect Folio with up to 3 independent PBKDF2-SHA256 passwords without losing your reading spot.",
    steps: [
      "Open Settings → App Lock & Passwords and set up to 3 independent passwords. Any single password unlocks Folio and can verify & reset any of the other slots.",
      "Choose 'On close' to stay unlocked permanently across app switches until you manually close Folio.",
      "Choose 'After idle' (1, 2, 5, 10, or 30 minutes) to run a live countdown timer that auto-locks at 00:00 while keeping your exact open comic, page, and scroll position live underneath.",
    ],
    example: "Example: Set Password 1 as your daily PIN and Password 2 as a backup recovery password, set mode to 'After idle (5 min)'. If you set your phone down mid-chapter, Folio auto-locks after 5 minutes—unlocking drops you right back on the exact panel you were reading.",
  },
  {
    id: "shortcuts",
    icon: Keyboard,
    title: "9. Configurable Keyboard Shortcuts",
    summary: "Customize every navigation, library, and reader keybinding for desktop or external keyboards.",
    steps: [
      "Open Settings → Keyboard shortcuts → Configure to open the dedicated shortcuts page.",
      "Tap any action, press your preferred key or modifier combo (like Ctrl+K or ]), or clear/reset individual bindings anytime.",
      "Includes shortcuts for Search, Edge Panel, Select mode, Lock App, Next/Prev Page, Next/Prev Connected Part ([ and ]), Zoom In/Out/Reset, Fullscreen, Reader Lock Mode, and Export Page.",
    ],
    example: "Example: Rebind 'Next connected part' to Ctrl+ArrowRight and 'Toggle Reader Lock Mode' to Space for one-handed desktop reading.",
  },
  {
    id: "backup",
    icon: ShieldCheck,
    title: "10. Metadata Backup & Full Recovery",
    summary: "Back up all tags, Author tags, connected parts, favorites, progress, and settings into one verified JSON file.",
    steps: [
      "Open Settings → Metadata backup → Export to save a SHA-256 checksum-verified metadata JSON file (App Lock passwords are never exported for security).",
      "If you switch devices or reinstall Folio, open Settings → Metadata backup → Import and match and select your backup JSON.",
      "Folio matches comics automatically by path, content fingerprint, name + page count, and fuzzy matching, and creates a rollback snapshot with one-tap Undo.",
    ],
    example: "Example: Move your comic folders to a new phone, install Folio, pick the Mother folder, and import your metadata JSON—every tag, Author tag, favorite, connected series, and reading page is restored.",
  },
];

export function TutorialPage() {
  const goBack = useStore((s) => s.goBack);
  const [q, setQ] = useState("");

  const filtered = useMemo(() => {
    const nq = q.trim().toLowerCase();
    if (!nq) return GUIDE_SECTIONS;
    return GUIDE_SECTIONS.filter(
      (s) =>
        s.title.toLowerCase().includes(nq) ||
        s.summary.toLowerCase().includes(nq) ||
        s.example.toLowerCase().includes(nq) ||
        s.steps.some((st) => st.toLowerCase().includes(nq)) ||
        (s.settings?.some((st) => st.toLowerCase().includes(nq)) ?? false),
    );
  }, [q]);

  const jumpTo = (id: string) => {
    document.getElementById(`guide-${id}`)?.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  return (
    <PageShell
      title="Detailed Tutorial"
      description="Deep walkthrough of every Folio feature, setting, and real-world workflow."
      actions={
        <Button variant="outline" size="sm" onClick={() => goBack()}>
          <ArrowLeft />Back
        </Button>
      }
    >
      <div className="flex flex-col gap-3">
        <div className="relative max-w-md">
          <Search className="pointer-events-none absolute left-3.5 top-1/2 size-4 -translate-y-1/2 text-sub" />
          <Input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Search features, settings, or examples…"
            aria-label="Search tutorial"
            className="pl-10 pr-10"
          />
          {q && (
            <button
              type="button"
              aria-label="Clear tutorial search"
              onClick={() => setQ("")}
              className="absolute right-1.5 top-1/2 flex size-8 -translate-y-1/2 items-center justify-center rounded-full text-sub hover:bg-muted hover:text-fg"
            >
              <X className="size-4" />
            </button>
          )}
        </div>

        {!q && (
          <div className="flex flex-wrap gap-1.5" aria-label="Jump to section">
            {GUIDE_SECTIONS.map((s) => (
              <button
                key={s.id}
                type="button"
                onClick={() => jumpTo(s.id)}
                className="h-8 rounded-full border-2 border-ink bg-surface px-3 text-xs font-bold text-fg transition-colors hover:bg-butter hover:text-on"
              >
                {s.title.replace(/^\d+\.\s*/, "").split(":")[0]}
              </button>
            ))}
          </div>
        )}
      </div>

      {filtered.length === 0 ? (
        <Card title="No matching guide sections">
          <p className="text-[13px] text-sub">No tutorial topic matched "{q}". Try searching for "author", "parts", "zoom", "lock", or "backup".</p>
        </Card>
      ) : (
        <div className="flex flex-col gap-4">
          {filtered.map((sec) => (
            <div key={sec.id} id={`guide-${sec.id}`} className="scroll-mt-4">
              <Card
                title={sec.title}
                actions={<sec.icon className="size-4 text-accent" />}
              >
                <p className="mb-3 text-[13px] font-semibold text-fg/90">{sec.summary}</p>

                <div className="mb-3">
                  <div className="mb-1.5 text-xs font-extrabold uppercase tracking-wide text-sub">How it works</div>
                  <ul className="flex list-disc flex-col gap-1.5 pl-5 text-[13px] leading-relaxed text-sub">
                    {sec.steps.map((step, i) => (
                      <li key={i}>{step}</li>
                    ))}
                  </ul>
                </div>

                {sec.settings && sec.settings.length > 0 && (
                  <div className="mb-3 rounded-[16px] border-2 border-line bg-muted/60 p-3">
                    <div className="mb-1 text-xs font-extrabold uppercase tracking-wide text-accent">Related Settings</div>
                    <ul className="flex list-disc flex-col gap-1 pl-4 text-[13px] leading-relaxed text-fg/85">
                      {sec.settings.map((st, i) => (
                        <li key={i}>{st}</li>
                      ))}
                    </ul>
                  </div>
                )}

                <div className="flex items-start gap-2 rounded-[16px] border-2 border-ink bg-mint/20 p-3 text-[13px] leading-relaxed text-fg">
                  <Sparkles className="mt-0.5 size-4 shrink-0 text-accent" />
                  <span>{sec.example}</span>
                </div>
              </Card>
            </div>
          ))}
        </div>
      )}
    </PageShell>
  );
}
