import { useMemo, useRef, useState } from "react";
import { AnimatePresence, motion } from "motion/react";
import { Activity, ArrowDownToLine, ArrowUpToLine, BookOpen, ChevronRight, Clock, Download, FolderOpen, Heart, Library, Lock, Settings, ShieldCheck, Tag, X } from "lucide-react";
import { countFolders } from "@comiclib/shared";
import { type Screen, useStore } from "@/lib/store";
import { useBackClose } from "@/lib/hooks";
import { hasActiveAppLock } from "@/lib/appLock";
import { cn } from "@/utils/cn";
import { TagEditor } from "./Dialogs";

export function NavButton({ icon: Icon, label, active, onClick, badge }: { icon: React.ElementType; label: string; active?: boolean; onClick: () => void; badge?: number }) {
  return (
    <button
      onClick={onClick}
      aria-current={active ? "page" : undefined}
      className={cn(
        "flex h-9 w-full items-center gap-3 rounded-full border-2 px-3.5 text-sm font-bold transition-[background-color,transform] duration-300 ease-spring active:brightness-90 touch-manipulation pointer-coarse:h-11",
        active ? "border-ink bg-lilac text-on shadow-[0_3px_0_var(--ink)]" : "border-transparent text-fg hover:bg-muted",
      )}
    >
      <Icon className="size-4 shrink-0" />
      <span className="min-w-0 flex-1 truncate text-left">{label}</span>
      {badge ? <span className={cn("rounded-full px-2 text-xs font-bold tabular-nums", active ? "bg-surface/70 text-on" : "bg-muted text-sub")}>{badge}</span> : null}
    </button>
  );
}

/** Scrolls whichever page is on screen (library grid or a settings style page) to its very top or bottom. */
export function jumpPage(where: "top" | "bottom") {
  const el = [...document.querySelectorAll<HTMLElement>("#library-scroll, #page-scroll")].find((e) => e.offsetParent !== null);
  el?.scrollTo({ top: where === "top" ? 0 : el.scrollHeight, behavior: "smooth" });
}

export function SidebarContent({ onLockNow }: { onLockNow?: () => void }) {
  const set = useStore((s) => s.set);
  const screen = useStore((s) => s.screen);
  const setScreen = useStore((s) => s.setScreen);
  const filters = useStore((s) => s.filters);
  const setFilters = useStore((s) => s.setFilters);
  const clearFilters = useStore((s) => s.clearFilters);
  const comics = useStore((s) => s.comics);
  const folders = useStore((s) => s.folders);
  const archives = useStore((s) => s.archives);
  const reports = useStore((s) => s.reports);
  const appLock = useStore((s) => s.settings.appLock);
  const toast = useStore((s) => s.toast);
  const [open, setOpen] = useState<Set<string>>(new Set());
  const [tagFolder, setTagFolder] = useState<{ path: string; name: string; ids: string[] } | null>(null);
  const counts = useMemo(() => countFolders(comics), [comics]);
  const pending = archives.filter((a) => a.status === "pending" || a.status === "queued" || a.status === "extracting").length;
  const issues = reports.filter((r) => r.status !== "green" && !r.manual).length;
  const go = (s: Screen) => setScreen(s);
  const nav = (patch: Parameters<typeof setFilters>[0]) => {
    clearFilters();
    setFilters(patch);
    setScreen("library");
  };
  const noFilter = !filters.favoritesOnly && !filters.recentOnly && !filters.foldersIn.length;
  const children = (p: string) => folders.filter((f) => f.parent === p);

  const openFolderTagging = (folderPath: string, folderName: string) => {
    const ids = comics
      .filter((c) => c.folder === folderPath || c.folder.startsWith(`${folderPath}/`))
      .map((c) => c.id);
    if (!ids.length) {
      toast("No comics inside this folder");
      return;
    }
    setTagFolder({ path: folderPath, name: folderName, ids });
  };

  const renderFolder = (path: string, depth: number): React.ReactNode =>
    children(path).map((f) => {
      const kids = children(f.path).length > 0;
      const isOpen = open.has(f.path);
      const sel = screen === "library" && filters.foldersIn.length === 1 && filters.foldersIn[0] === f.path;
      const count = counts.get(f.path) ?? 0;
      return (
        <li key={f.path}>
          <div className="flex items-center gap-0.5" style={{ paddingLeft: depth * 12 }}>
            <button
              aria-label={isOpen ? "Collapse" : "Expand"}
              disabled={!kids}
              onClick={() =>
                setOpen((o) => {
                  const n = new Set(o);
                  n.has(f.path) ? n.delete(f.path) : n.add(f.path);
                  return n;
                })
              }
              className="flex size-8 shrink-0 items-center justify-center text-sub disabled:opacity-0 pointer-coarse:size-10"
            >
              <ChevronRight className={cn("size-4 transition-transform duration-150", isOpen && "rotate-90")} />
            </button>
            <button
              onClick={() => nav({ foldersIn: [f.path] })}
              aria-current={sel ? "page" : undefined}
              title={f.path}
              className={cn("flex h-8 min-w-0 flex-1 items-center gap-2 rounded-full pr-2 text-left text-[13px] pointer-coarse:h-10", sel ? "bg-lilac pl-2 font-bold text-on" : "pl-2 hover:bg-muted")}
            >
              <span className="min-w-0 flex-1 truncate">{f.name}</span>
              <span className="text-xs tabular-nums text-sub">{count}</span>
            </button>
            {count > 0 && (
              <button
                type="button"
                aria-label={`Tag all comics in ${f.name}`}
                title={`Add or remove tags for all ${count} comics in ${f.name}`}
                onClick={() => openFolderTagging(f.path, f.name)}
                className="flex size-8 shrink-0 items-center justify-center rounded-full text-sub hover:bg-muted hover:text-fg active:scale-90 pointer-coarse:size-9"
              >
                <Tag className="size-3.5" />
              </button>
            )}
          </div>
          {kids && isOpen && <ul>{renderFolder(f.path, depth + 1)}</ul>}
        </li>
      );
    });

  return (
    <>
      <div className="flex h-full min-h-0 flex-col">
        <div className="flex items-center gap-2.5 border-b border-line px-4 py-3.5">
          <div className="flex size-9 shrink-0 items-center justify-center rounded-[12px] border-[2.5px] border-ink bg-butter text-on shadow-[0_3px_0_var(--ink)]">
            <BookOpen className="size-[18px]" />
          </div>
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-1.5">
              <span className="truncate font-display text-lg font-extrabold leading-6">Folio</span>
            </div>
            <div className="truncate text-[11px] font-bold text-sub">Comic Library</div>
          </div>
          <button aria-label="Close edge panel" title="Close edge panel" onClick={() => set({ drawer: false })} className="flex size-9 shrink-0 items-center justify-center rounded-full border-2 border-ink bg-muted hover:bg-line active:scale-95">
            <X className="size-4" />
          </button>
        </div>
        <div className="grid grid-cols-2 gap-2 px-3 py-3">
          <button onClick={() => { set({ drawer: false }); setTimeout(() => jumpPage("top"), 60); }} className="flex h-9 items-center justify-center gap-1.5 rounded-full border-2 border-ink bg-butter text-[13px] font-bold text-on shadow-[0_2px_0_var(--ink)] active:translate-y-px pointer-coarse:h-10">
            <ArrowUpToLine className="size-4" />Page top
          </button>
          <button onClick={() => { set({ drawer: false }); setTimeout(() => jumpPage("bottom"), 60); }} className="flex h-9 items-center justify-center gap-1.5 rounded-full border-2 border-ink bg-mint text-[13px] font-bold text-on shadow-[0_2px_0_var(--ink)] active:translate-y-px pointer-coarse:h-10">
            <ArrowDownToLine className="size-4" />Page bottom
          </button>
        </div>
        <nav className="flex min-h-0 flex-1 flex-col gap-4 overflow-y-auto px-2.5 pb-2" aria-label="Main">
          <div className="flex flex-col gap-0.5">
            <NavButton icon={Library} label="All comics" active={screen === "library" && noFilter} onClick={() => nav({})} badge={comics.length} />
            <NavButton icon={Heart} label="Favorites" active={screen === "library" && filters.favoritesOnly} onClick={() => nav({ favoritesOnly: true })} badge={comics.filter((c) => c.favorite).length} />
            <NavButton icon={Clock} label="Recently read" active={screen === "library" && filters.recentOnly} onClick={() => nav({ recentOnly: true })} />
            <NavButton icon={Tag} label="Tags" active={screen === "tags"} onClick={() => go("tags")} />
          </div>
          <div>
            <div className="mb-1 flex items-center gap-2 px-3 font-display text-sm font-extrabold text-sub"><FolderOpen className="size-3.5" />Folders</div>
            <ul>{renderFolder("", 0)}</ul>
            {folders.length === 0 && <p className="px-3 py-2 text-[13px] text-sub">No folders yet.</p>}
          </div>
        </nav>
        <div className="flex flex-col gap-0.5 border-t border-line p-2.5">
          <NavButton icon={Download} label="Extraction" active={screen === "extract"} onClick={() => go("extract")} badge={pending} />
          <NavButton icon={ShieldCheck} label="Verification" active={screen === "verify"} onClick={() => go("verify")} badge={issues} />
          <NavButton icon={Activity} label="Health" active={screen === "health"} onClick={() => go("health")} />
          <NavButton icon={Settings} label="Settings" active={screen === "settings"} onClick={() => go("settings")} />
          {hasActiveAppLock(appLock) && onLockNow && (
            <NavButton icon={Lock} label="Lock app" onClick={() => { set({ drawer: false }); onLockNow(); }} />
          )}
        </div>
      </div>
      {tagFolder && (
        <TagEditor
          ids={tagFolder.ids}
          title={`Tag folder: ${tagFolder.name} (${tagFolder.ids.length})`}
          onClose={() => setTagFolder(null)}
        />
      )}
    </>
  );
}

/**
 * Slim Edge Panel handle hugging the right edge of the screen.
 * Tap or swipe left to slide out the Mochi Nook Edge Panel.
 */
export function EdgePanelHandle() {
  const set = useStore((s) => s.set);
  const drawer = useStore((s) => s.drawer);
  const reader = useStore((s) => s.reader);
  const startX = useRef<number | null>(null);
  const swiped = useRef(false);

  if (drawer || reader) return null;

  return (
    <button
      type="button"
      aria-label="Open edge panel"
      aria-expanded={drawer}
      title="Open edge panel"
      onPointerDown={(e) => {
        startX.current = e.clientX;
        swiped.current = false;
        (e.currentTarget as HTMLElement).setPointerCapture?.(e.pointerId);
      }}
      onPointerMove={(e) => {
        if (startX.current === null || swiped.current) return;
        if (startX.current - e.clientX > 16) {
          swiped.current = true;
          startX.current = null;
          set({ drawer: true });
        }
      }}
      onPointerUp={() => {
        startX.current = null;
      }}
      onPointerCancel={() => {
        startX.current = null;
      }}
      onClick={() => {
        if (swiped.current) {
          swiped.current = false;
          return;
        }
        set({ drawer: true });
      }}
      className="group fixed right-0 top-1/2 z-40 flex h-28 w-7 -translate-y-1/2 touch-none items-center justify-end bg-transparent focus-visible:outline-none"
    >
      <span className="flex h-24 w-3 items-center justify-center rounded-l-full border-y-[2.5px] border-l-[2.5px] border-ink bg-lilac/90 shadow-[-2px_3px_0_var(--ink)] transition-[width,background-color,opacity] duration-200 ease-out group-hover:w-4 group-hover:bg-lilac group-active:w-4 group-focus-visible:ring-2 group-focus-visible:ring-accent">
        <span className="h-9 w-1 rounded-full bg-on/45" />
      </span>
    </button>
  );
}

/** Floating right-edge Edge Panel matching the Mochi Nook UI. Supports tap-outside, Back, Escape, and swipe-right to close. */
export function EdgePanel({ onLockNow }: { onLockNow?: () => void }) {
  const drawer = useStore((s) => s.drawer);
  const set = useStore((s) => s.set);
  const dragStart = useRef<{ x: number; y: number } | null>(null);
  useBackClose(drawer, () => set({ drawer: false }));

  return (
    <AnimatePresence>
      {drawer && (
        <>
          <motion.div
            key="bd"
            className="fixed inset-0 z-50 bg-[#140f32]/45 backdrop-blur-[2px]"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.16 }}
            onClick={() => set({ drawer: false })}
            aria-hidden
          />
          <motion.aside
            key="panel"
            role="dialog"
            aria-label="Edge panel"
            className="safe-b fixed bottom-3 right-2.5 top-3 z-[51] flex w-[min(312px,86vw)] flex-col overflow-hidden rounded-[28px] border-[2.5px] border-ink bg-surface text-fg shadow-[0_6px_0_var(--ink)]"
            initial={{ x: "108%", opacity: 0.7 }}
            animate={{ x: 0, opacity: 1 }}
            exit={{ x: "108%", opacity: 0.7 }}
            transition={{ duration: 0.22, ease: [0.22, 1, 0.36, 1] }}
            onKeyDown={(e) => e.key === "Escape" && set({ drawer: false })}
            onPointerDown={(e) => {
              dragStart.current = { x: e.clientX, y: e.clientY };
            }}
            onPointerMove={(e) => {
              if (!dragStart.current) return;
              const dx = e.clientX - dragStart.current.x;
              const dy = Math.abs(e.clientY - dragStart.current.y);
              if (dx > 56 && dx > dy * 1.4) {
                dragStart.current = null;
                set({ drawer: false });
              }
            }}
            onPointerUp={() => {
              dragStart.current = null;
            }}
            onPointerCancel={() => {
              dragStart.current = null;
            }}
          >
            <SidebarContent onLockNow={onLockNow} />
          </motion.aside>
        </>
      )}
    </AnimatePresence>
  );
}
