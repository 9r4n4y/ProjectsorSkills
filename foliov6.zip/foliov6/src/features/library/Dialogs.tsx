import { useMemo, useState } from "react";
import { CheckCheck, Folder, FolderPlus, Heart, Tag, User, X, FolderInput } from "lucide-react";
import { type ComicRecord, authorTagName, authorTagsOf, isAuthorTag, normalTagsOf, normalizeText, tagKey, toAuthorTag } from "@comiclib/shared";
import { api } from "@/lib/backend";
import { useStore } from "@/lib/store";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input, Segmented } from "@/components/ui/controls";
import { cn } from "@/utils/cn";

export function TagEditor({ ids, title, initialTab = "tags", onClose }: { ids: string[]; title?: string; initialTab?: "tags" | "authors"; onClose: () => void }) {
  const comics = useStore((s) => s.comics);
  const defs = useStore((s) => s.tags);
  const editTags = useStore((s) => s.editTags);
  const toast = useStore((s) => s.toast);
  const [tab, setTab] = useState<"tags" | "authors">(initialTab);
  const idSet = useMemo(() => new Set(ids), [ids]);
  const targets = useMemo(() => comics.filter((c) => idSet.has(c.id)), [comics, idSet]);

  const currentTags = useMemo(() => {
    const m = new Map<string, { raw: string; label: string; n: number }>();
    for (const c of targets) {
      for (const t of normalTagsOf(c.tags)) {
        const e = m.get(tagKey(t));
        if (e) e.n++;
        else m.set(tagKey(t), { raw: t, label: t, n: 1 });
      }
    }
    return [...m.values()].sort((a, b) => b.n - a.n || a.label.localeCompare(b.label));
  }, [targets]);

  const currentAuthors = useMemo(() => {
    const m = new Map<string, { raw: string; label: string; n: number }>();
    for (const c of targets) {
      for (const a of authorTagsOf(c.tags)) {
        const raw = toAuthorTag(a);
        const e = m.get(tagKey(a));
        if (e) e.n++;
        else m.set(tagKey(a), { raw, label: a, n: 1 });
      }
    }
    return [...m.values()].sort((a, b) => b.n - a.n || a.label.localeCompare(b.label));
  }, [targets]);

  const [adds, setAdds] = useState<string[]>([]);
  const [removes, setRemoves] = useState<string[]>([]);
  const [q, setQ] = useState("");

  const current = tab === "tags" ? currentTags : currentAuthors;
  const visibleAdds = adds.filter((a) => (tab === "authors" ? isAuthorTag(a) : !isAuthorTag(a)));

  const sugg = useMemo(() => {
    const nq = normalizeText(q.split(",").pop() ?? "");
    const taken = new Set([...adds, ...current.map((c) => c.raw)].map(tagKey));
    const pool = defs
      .filter((d) => (tab === "authors" ? isAuthorTag(d.name) : !isAuthorTag(d.name)))
      .map((d) => ({ raw: d.name, label: tab === "authors" ? authorTagName(d.name) : d.name }));
    return pool.filter((d) => d.label && !taken.has(tagKey(d.raw)) && (!nq || normalizeText(d.label).includes(nq))).slice(0, 12);
  }, [defs, q, adds, current, tab]);

  const formatEntry = (item: string) => (tab === "authors" ? toAuthorTag(item) : item.trim());

  const addMany = (raw: string) => {
    const parts = raw
      .split(",")
      .map((s) => formatEntry(s))
      .filter(Boolean);
    if (!parts.length) return;
    setAdds((prev) => {
      const next = [...prev];
      for (const t of parts) {
        if (!next.some((x) => tagKey(x) === tagKey(t))) next.push(t);
      }
      return next;
    });
    setRemoves((r) => r.filter((x) => !parts.some((p) => tagKey(p) === tagKey(x))));
    setQ("");
  };

  const apply = () => {
    const pending = q
      .split(",")
      .map((s) => formatEntry(s))
      .filter(Boolean);
    const finalAdds = [...adds];
    for (const t of pending) {
      if (!finalAdds.some((x) => tagKey(x) === tagKey(t))) finalAdds.push(t);
    }
    if (!finalAdds.length && !removes.length) return;
    editTags(ids, finalAdds, removes);
    toast(`Updated tags & authors on ${ids.length.toLocaleString()} comic${ids.length === 1 ? "" : "s"}`);
    onClose();
  };

  const heading = title ?? (ids.length === 1 ? "Edit tags & authors" : `Edit tags & authors (${ids.length.toLocaleString()})`);
  const canApply = adds.length > 0 || removes.length > 0 || q.trim().length > 0;

  return (
    <Dialog open onOpenChange={(o) => !o && onClose()}>
      <DialogContent
        title={heading}
        description={ids.length === 1 ? targets[0]?.name : "Changes apply to every selected comic. Switch between Tags and Authors below."}
        size="sm"
        zIndex={80}
      >
        <div className="flex min-h-0 flex-1 flex-col gap-4 overflow-y-auto p-5">
          <div className="flex justify-center">
            <Segmented
              label="Edit tags or authors"
              value={tab}
              onChange={(v) => {
                setTab(v);
                setQ("");
              }}
              options={[
                { value: "tags", label: `Tags (${currentTags.length})` },
                { value: "authors", label: `Authors (${currentAuthors.length})` },
              ]}
            />
          </div>

          <div>
            <div className="mb-2 text-[13px] font-medium">
              {tab === "tags" ? "Current tags (tap to remove)" : "Current authors (tap to remove)"}
            </div>
            <div className="flex flex-wrap gap-2">
              {current.length === 0 && (
                <span className="text-[13px] text-sub">{tab === "tags" ? "No tags yet." : "No authors added yet."}</span>
              )}
              {current.map((t) => {
                const gone = removes.some((r) => tagKey(r) === tagKey(t.raw));
                return (
                  <button
                    key={t.raw}
                    onClick={() => setRemoves((r) => (gone ? r.filter((x) => tagKey(x) !== tagKey(t.raw)) : [...r, t.raw]))}
                    aria-pressed={gone}
                    className={cn(
                      "inline-flex h-8 items-center gap-1.5 rounded-full border-2 px-3 text-[13px] font-bold",
                      gone ? "border-ink bg-peach/40 text-sub line-through" : tab === "authors" ? "border-ink bg-lilac/35 text-fg" : "border-ink bg-muted text-fg",
                    )}
                  >
                    {tab === "authors" && <User className="size-3.5" />}
                    {t.label}
                    {ids.length > 1 && <span className="text-xs text-sub">{t.n}/{ids.length}</span>}
                    <X className="size-3.5" />
                  </button>
                );
              })}
            </div>
          </div>

          <div>
            <div className="mb-2 text-[13px] font-medium">
              {tab === "tags" ? "Add tags (comma-separated for multiple)" : "Add author tag (comma-separated for multiple)"}
            </div>
            <form onSubmit={(e) => (e.preventDefault(), addMany(q))} className="flex gap-2">
              <Input
                value={q}
                onChange={(e) => setQ(e.target.value)}
                placeholder={tab === "tags" ? "e.g. color, favorite, sci-fi" : "e.g. Oda Eiichiro, Aoki Rin"}
                aria-label={tab === "tags" ? "New tag" : "New author tag"}
                autoFocus
              />
              <Button type="submit" variant="secondary" disabled={!q.trim()}>Add</Button>
            </form>
            {sugg.length > 0 && (
              <div className="mt-2 flex flex-wrap gap-1.5" aria-label="Suggestions">
                {sugg.map((s) => (
                  <button key={s.raw} onClick={() => addMany(s.label)} className="h-8 rounded-full border-2 border-line px-2.5 text-[13px] font-bold hover:border-ink hover:bg-muted">
                    + {s.label}
                  </button>
                ))}
              </div>
            )}
            {visibleAdds.length > 0 && (
              <div className="mt-3 flex flex-wrap gap-2">
                {visibleAdds.map((a) => (
                  <button key={a} onClick={() => setAdds(adds.filter((x) => x !== a))} className="inline-flex h-8 items-center gap-1.5 rounded-full border-2 border-ink bg-mint px-3 text-[13px] font-bold text-on">
                    {tab === "authors" && <User className="size-3.5" />}
                    + {tab === "authors" ? authorTagName(a) : a}
                    <X className="size-3.5" />
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>
        <div className="flex justify-end gap-2 border-t border-line p-3">
          <Button variant="ghost" onClick={onClose}>Cancel</Button>
          <Button disabled={!canApply} onClick={apply}>Apply to {ids.length.toLocaleString()}</Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

export function MoveDialog({ ids, onClose }: { ids: string[]; onClose: () => void }) {
  const folders = useStore((s) => s.folders);
  const refresh = useStore((s) => s.refresh);
  const toast = useStore((s) => s.toast);
  const [q, setQ] = useState("");
  const [dest, setDest] = useState<string | null>(null);
  const [name, setName] = useState("");
  const [busy, setBusy] = useState(false);
  const list = useMemo(() => folders.filter((f) => !q || normalizeText(f.path).includes(normalizeText(q))), [folders, q]);
  const run = async (target: string) => {
    setBusy(true);
    try {
      const res = await api.moveComics(ids, target);
      await refresh();
      const bad = res.filter((r) => !r.ok);
      if (bad.length) toast(`${bad.length} could not be moved: ${bad[0].error}`, "error");
      else toast(`Moved ${res.length} comic${res.length > 1 ? "s" : ""} and verified the result`);
      onClose();
    } catch (e) {
      toast((e as Error).message, "error");
    } finally {
      setBusy(false);
    }
  };
  const create = async () => {
    try {
      const p = await api.createFolder(dest ?? "", name.trim());
      await refresh();
      setDest(p);
      setName("");
    } catch (e) {
      toast((e as Error).message, "error");
    }
  };
  return (
    <Dialog open onOpenChange={(o) => !o && onClose()}>
      <DialogContent title={`Move ${ids.length} comic${ids.length > 1 ? "s" : ""}`} description="Files are moved on disk, then checked. Name clashes get a numeric suffix." size="sm" zIndex={80}>
        <div className="flex min-h-0 flex-1 flex-col">
          <div className="border-b border-line p-4"><Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search folders" aria-label="Search folders" /></div>
          <ul className="max-h-[40dvh] min-h-[160px] flex-1 overflow-y-auto">
            <li>
              <button onClick={() => setDest("")} className={cn("flex h-10 w-full items-center gap-2 px-4 text-left text-sm hover:bg-muted pointer-coarse:h-12", dest === "" && "bg-accent-soft text-accent")}><Folder className="size-4" />Mother folder (top level)</button>
            </li>
            {list.map((f) => (
              <li key={f.path}>
                <button onClick={() => setDest(f.path)} className={cn("flex h-10 w-full items-center gap-2 px-4 text-left text-sm hover:bg-muted pointer-coarse:h-12", dest === f.path && "bg-accent-soft text-accent")} style={{ paddingLeft: 16 + (q ? 0 : (f.path.split("/").length - 1) * 16) }}>
                  <Folder className="size-4 shrink-0" /><span className="truncate">{q ? f.path : f.name}</span>
                  {f.kind === "author" && <span className="ml-auto shrink-0 text-xs text-sub">Author</span>}
                </button>
              </li>
            ))}
          </ul>
          <div className="flex gap-2 border-t border-line p-3">
            <Input value={name} onChange={(e) => setName(e.target.value)} placeholder={dest ? `New folder inside ${dest}` : "New top-level folder"} aria-label="New folder name" />
            <Button variant="secondary" disabled={!name.trim()} onClick={() => void create()}><FolderPlus />Create</Button>
          </div>
        </div>
        <div className="flex justify-end gap-2 border-t border-line p-3">
          <Button variant="ghost" onClick={onClose}>Cancel</Button>
          <Button disabled={dest === null || busy} onClick={() => dest !== null && void run(dest)}>{busy ? "Moving" : "Move here"}</Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

export function BulkBar({ items }: { items: ComicRecord[] }) {
  const selected = useStore((s) => s.selected);
  const setSelected = useStore((s) => s.setSelected);
  const setSelectMode = useStore((s) => s.setSelectMode);
  const toggleFavorite = useStore((s) => s.toggleFavorite);
  const [tags, setTags] = useState(false);
  const [move, setMove] = useState(false);
  const ids = [...selected];
  const allSelected = items.length > 0 && items.every((c) => selected.has(c.id));

  return (
    <>
      <div className="safe-b flex flex-wrap items-center gap-1.5 border-t-[2.5px] border-ink bg-surface px-3 py-2 sm:gap-2 sm:px-6" role="toolbar" aria-label="Bulk actions">
        <Button variant="ghost" size="icon" aria-label="Exit select mode" onClick={() => setSelectMode(false)}><X /></Button>
        <span className="mr-auto text-xs font-bold tabular-nums sm:text-sm">
          <b>{ids.length.toLocaleString()}</b> / {items.length.toLocaleString()} selected
        </span>
        <Button
          variant={allSelected ? "secondary" : "outline"}
          size="sm"
          onClick={() => setSelected(allSelected ? [] : items.map((c) => c.id))}
          title={allSelected ? "Clear selection" : `Select all ${items.length} matching comics across all pages`}
        >
          <CheckCheck />
          <span>{allSelected ? "Clear" : `All (${items.length})`}</span>
        </Button>
        <Button variant="outline" size="sm" disabled={!ids.length} onClick={() => toggleFavorite(ids)} title="Toggle favorite">
          <Heart /><span className="hidden sm:inline">Favorite</span>
        </Button>
        <Button variant="default" size="sm" disabled={!ids.length} onClick={() => setTags(true)} title="Add or remove tags">
          <Tag /><span>Tags</span>
        </Button>
        <Button variant="outline" size="sm" disabled={!ids.length} onClick={() => setMove(true)} title="Move selected comics">
          <FolderInput /><span className="hidden sm:inline">Move</span>
        </Button>
      </div>
      {tags && <TagEditor ids={ids} onClose={() => setTags(false)} />}
      {move && <MoveDialog ids={ids} onClose={() => setMove(false)} />}
    </>
  );
}
