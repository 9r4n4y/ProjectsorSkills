import { useEffect, useRef, useState } from "react";
import { ArrowDownAZ, ArrowUpAZ, BookOpen, CheckSquare, Eye, EyeOff, FolderTree, FolderX, Heart, LayoutGrid, Minus, Plus, Search, SearchX, SlidersHorizontal, Tag, User, X, Folder as FolderIcon } from "lucide-react";
import { activeFilterCount, type SortKey } from "@comiclib/shared";
import { useStore } from "@/lib/store";
import { useLibraryView } from "@/lib/hooks";
import { Button } from "@/components/ui/button";
import { Badge, EmptyState, Input, Popover, PopoverContent, PopoverTrigger } from "@/components/ui/controls";
import { cn } from "@/utils/cn";
import { Pager } from "@/components/Pager";
import { ComicGrid, GridSkeleton } from "./ComicGrid";
import { BulkBar } from "./Dialogs";

const SORTS: { value: SortKey; label: string }[] = [
  { value: "name", label: "Name" },
  { value: "added", label: "Date added" },
  { value: "modified", label: "Date modified" },
  { value: "pages", label: "Page count" },
  { value: "lastRead", label: "Last read" },
];

function Chip({ children, onRemove, label, tone }: { children: React.ReactNode; onRemove: () => void; label: string; tone?: "in" | "ex" }) {
  return (
    <span className={cn("inline-flex h-8 max-w-[240px] items-center gap-1.5 rounded-full border-2 border-ink pl-3 pr-1 text-[13px] font-bold", tone === "ex" ? "bg-muted text-fg" : "bg-lilac text-on")}>
      {children}
      <button aria-label={`Remove ${label}`} onClick={onRemove} className="flex size-7 touch-manipulation items-center justify-center rounded-full hover:bg-black/10 active:bg-black/20">
        <X className="size-3.5" />
      </button>
    </span>
  );
}

export function Library() {
  const { results, relevance, ms } = useLibraryView();
  const f = useStore((s) => s.filters);
  const total = useStore((s) => s.comics.length);
  const set = useStore((s) => s.set);
  const setFilters = useStore((s) => s.setFilters);
  const clearFilters = useStore((s) => s.clearFilters);
  const settings = useStore((s) => s.settings);
  const setSettings = useStore((s) => s.setSettings);
  const selectMode = useStore((s) => s.selectMode);
  const setSelectMode = useStore((s) => s.setSelectMode);
  const scanning = useStore((s) => s.scanning);
  const rescan = useStore((s) => s.rescan);
  const setScreen = useStore((s) => s.setScreen);
  const archives = useStore((s) => s.archives);
  const chipsHidden = useStore((s) => s.chipsHidden);
  const page = useStore((s) => s.page);
  const scrollRef = useRef<HTMLDivElement>(null);
  const [sortOpen, setSortOpen] = useState(false);
  const [denseOpen, setDenseOpen] = useState(false);
  const active = activeFilterCount(f);
  const pending = archives.filter((a) => a.status === "pending").length;

  // pageSize === 0 means Unlimited (continuous scroll with no pages)
  const unlimited = settings.pageSize === 0;
  const pageSize = unlimited ? Math.max(1, results.length) : Math.max(1, settings.pageSize || 20);
  const lastPage = unlimited ? 0 : Math.max(0, Math.ceil(results.length / pageSize) - 1);
  const cur = unlimited ? 0 : Math.min(page, lastPage);
  const slice = unlimited ? results : results.slice(cur * pageSize, (cur + 1) * pageSize);
  const goPage = (p: number) => {
    set({ page: p });
    scrollRef.current?.scrollTo({ top: 0, behavior: "smooth" });
  };
  useEffect(() => {
    if (page !== cur) set({ page: cur });
  }, [page, cur, set]);

  const title = f.favoritesOnly ? "Favorites" : f.recentOnly ? "Recently read" : f.foldersIn.length === 1 ? f.foldersIn[0].split("/").join("  /  ") : f.authorsIn.length === 1 ? f.authorsIn[0] : "All comics";

  return (
    <div className="flex h-full min-h-0 flex-col">
      {/* Entire library — including the search card, top pager, grid and bottom pager — scrolls together so nothing sticks while scrolling. */}
      <div ref={scrollRef} id="library-scroll" className="min-h-0 flex-1 overflow-y-auto overflow-x-hidden overscroll-contain">
        <div className="flex flex-col gap-4 px-4 pb-6 pt-4 sm:px-6">
          <section aria-label="Search and library controls" className="flex flex-col gap-3 rounded-[24px] border-[2.5px] border-ink bg-surface p-3.5 shadow-[0_4px_0_var(--ink)] sm:p-4">
            <div className="flex items-center justify-between gap-2">
              <div className="flex min-w-0 items-center gap-2">
                <h1 className="min-w-0 truncate font-display text-xl font-extrabold leading-7" title={title}>{title}</h1>
              </div>
              <span className="shrink-0 text-[12px] font-bold text-sub tabular-nums" aria-live="polite">
                <span className="text-fg">{results.length.toLocaleString()}</span> {results.length === total ? "comics" : `of ${total.toLocaleString()}`}
                {relevance ? " · relevance" : ""}
                <span className="sr-only"> found in {Math.round(ms)} milliseconds</span>
              </span>
            </div>

            <div className="flex flex-col gap-2.5 sm:flex-row sm:items-center">
              <div className="relative min-w-0 flex-1">
                <Search className="pointer-events-none absolute left-3.5 top-1/2 size-4 -translate-y-1/2 text-sub" />
                <Input
                  value={f.query}
                  onChange={(e) => setFilters({ query: e.target.value })}
                  placeholder="Search name, folder, author or tag"
                  aria-label="Search comics"
                  className="pl-10 pr-10"
                />
                {f.query && (
                  <button aria-label="Clear search" onClick={() => setFilters({ query: "" })} className="absolute right-1.5 top-1/2 flex size-8 -translate-y-1/2 items-center justify-center rounded-full text-sub hover:bg-muted hover:text-fg">
                    <X className="size-4" />
                  </button>
                )}
              </div>

              <div className="flex items-center justify-between gap-2 sm:shrink-0 sm:justify-end">
                <Button variant="outline" size="icon" aria-label="Filter by tag or author" title="Filter by tag or author" onClick={() => set({ panel: "tags" })} className="relative">
                  <Tag />
                  {f.tagsIn.length + f.tagsEx.length + f.authorsIn.length + f.authorsEx.length > 0 && (
                    <span className="absolute -right-1 -top-1 flex size-5 items-center justify-center rounded-full border-2 border-ink bg-peach text-[10px] font-bold text-on">
                      {f.tagsIn.length + f.tagsEx.length + f.authorsIn.length + f.authorsEx.length}
                    </span>
                  )}
                </Button>
                <Button variant="outline" size="icon" aria-label="Filter by folder" title="Filter by folder" onClick={() => set({ panel: "folders" })} className="relative">
                  <FolderTree />
                  {f.foldersIn.length + f.foldersEx.length > 0 && <span className="absolute -right-1 -top-1 flex size-5 items-center justify-center rounded-full border-2 border-ink bg-peach text-[10px] font-bold text-on">{f.foldersIn.length + f.foldersEx.length}</span>}
                </Button>
                <Popover open={sortOpen} onOpenChange={setSortOpen}>
                  <PopoverTrigger asChild>
                    <Button variant="outline" size="icon" aria-label="Sort" title="Sort">
                      <SlidersHorizontal />
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-56">
                    {SORTS.map((s) => (
                      <button key={s.value} onClick={() => { setSettings({ sort: s.value }); setSortOpen(false); }} className={cn("flex h-9 w-full touch-manipulation items-center justify-between rounded-full px-3 text-sm font-bold hover:bg-muted active:bg-line pointer-coarse:h-11", settings.sort === s.value && "bg-lilac text-on")}>
                        {s.label}
                        {settings.sort === s.value && <span className="size-2 rounded-full border-2 border-ink bg-butter" />}
                      </button>
                    ))}
                    <div className="my-1 h-px bg-line" />
                    <button onClick={() => setSettings({ sortDir: settings.sortDir === "asc" ? "desc" : "asc" })} className="flex h-9 w-full touch-manipulation items-center gap-2 rounded-full px-3 text-sm font-bold hover:bg-muted active:bg-line pointer-coarse:h-11">
                      {settings.sortDir === "asc" ? <ArrowDownAZ className="size-4" /> : <ArrowUpAZ className="size-4" />}
                      {settings.sortDir === "asc" ? "Ascending" : "Descending"}
                    </button>
                  </PopoverContent>
                </Popover>
                <Popover open={denseOpen} onOpenChange={setDenseOpen}>
                  <PopoverTrigger asChild>
                    <Button variant="outline" size="icon" aria-label="Grid density" title="Grid density">
                      <LayoutGrid />
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-64 p-4">
                    <div className="mb-2 flex items-center justify-between text-[13px] font-bold">
                      <label htmlFor="density">Grid size</label>
                      <span className="rounded-full border-2 border-ink bg-butter px-2.5 text-on">{["Largest", "Large", "Medium", "Small", "Smallest"][settings.density - 1]}</span>
                    </div>
                    <input id="density" type="range" min={1} max={5} step={1} value={settings.density} onChange={(e) => setSettings({ density: +e.target.value })} aria-valuetext={["Largest", "Large", "Medium", "Small", "Smallest"][settings.density - 1]} className="mochi-range w-full" style={{ ["--p" as string]: (settings.density - 1) / 4 }} />
                    <div className="mt-1 flex justify-between text-xs text-sub"><span>Big covers</span><span>Many per row</span></div>
                  </PopoverContent>
                </Popover>
                <Button variant={selectMode ? "default" : "outline"} size="icon" aria-label="Select mode" aria-pressed={selectMode} title="Select" onClick={() => setSelectMode(!selectMode)}>
                  <CheckSquare />
                </Button>
              </div>
            </div>

            {active > 0 && (
              <div className="flex flex-col gap-2 border-t border-line pt-2.5">
                {!chipsHidden && (
                  <div className="flex flex-wrap items-center gap-2" aria-label="Active filters">
                    {f.favoritesOnly && <Chip label="favorites" onRemove={() => setFilters({ favoritesOnly: false })}><Heart className="size-3.5" />Favorites</Chip>}
                    {f.recentOnly && <Chip label="recently read" onRemove={() => setFilters({ recentOnly: false })}>Recently read</Chip>}
                    {f.tagsIn.map((t) => <Chip key={"i" + t} label={t} onRemove={() => setFilters({ tagsIn: f.tagsIn.filter((x) => x !== t) })}><Plus className="size-3.5" /><span className="truncate">{t}</span></Chip>)}
                    {f.tagsEx.map((t) => <Chip key={"e" + t} tone="ex" label={t} onRemove={() => setFilters({ tagsEx: f.tagsEx.filter((x) => x !== t) })}><Minus className="size-3.5" /><span className="truncate">{t}</span></Chip>)}
                    {f.authorsIn.map((a) => <Chip key={"ai" + a} label={`author ${a}`} onRemove={() => setFilters({ authorsIn: f.authorsIn.filter((x) => x !== a) })}><User className="size-3.5" /><span className="truncate">{a}</span></Chip>)}
                    {f.authorsEx.map((a) => <Chip key={"ae" + a} tone="ex" label={`exclude author ${a}`} onRemove={() => setFilters({ authorsEx: f.authorsEx.filter((x) => x !== a) })}><Minus className="size-3.5" /><User className="size-3" /><span className="truncate">{a}</span></Chip>)}
                    {f.foldersIn.map((t) => <Chip key={"fi" + t} label={t} onRemove={() => setFilters({ foldersIn: f.foldersIn.filter((x) => x !== t) })}><FolderIcon className="size-3.5" /><span className="truncate">{t}</span></Chip>)}
                    {f.foldersEx.map((t) => <Chip key={"fe" + t} tone="ex" label={t} onRemove={() => setFilters({ foldersEx: f.foldersEx.filter((x) => x !== t) })}><FolderX className="size-3.5" /><span className="truncate">{t}</span></Chip>)}
                    {f.tagsIn.length > 1 && <Badge tone="accent">{f.tagMode === "and" ? "All tags" : "Any tag"}</Badge>}
                  </div>
                )}
                <div className="flex items-center justify-end gap-1">
                  <Button variant="ghost" size="sm" aria-pressed={chipsHidden} onClick={() => set({ chipsHidden: !chipsHidden })}>{chipsHidden ? <Eye /> : <EyeOff />}{chipsHidden ? `Show ${active} selected` : "Hide selected"}</Button>
                  <Button variant="ghost" size="sm" onClick={clearFilters}><X />Clear all</Button>
                </div>
              </div>
            )}
          </section>

          {scanning && total === 0 ? (
            <GridSkeleton />
          ) : total === 0 ? (
            <EmptyState icon={BookOpen} title="No comics found yet" text="Folders that directly contain page images appear here. If your library holds archives, extract them first.">
              <div className="flex gap-2">
                <Button onClick={() => void rescan()} disabled={scanning}>Scan folder</Button>
                {pending > 0 && <Button variant="outline" onClick={() => setScreen("extract")}>Extract {pending} archives</Button>}
              </div>
            </EmptyState>
          ) : results.length === 0 ? (
            <EmptyState icon={SearchX} title="No comics match" text="Try fewer words, check the spelling, or remove a tag or folder filter.">
              <Button variant="outline" onClick={clearFilters}>Clear all filters</Button>
            </EmptyState>
          ) : (
            <>
              {!unlimited && <Pager page={cur} total={results.length} pageSize={pageSize} onChange={goPage} />}
              <ComicGrid items={slice} />
              {!unlimited && <Pager page={cur} total={results.length} pageSize={pageSize} onChange={goPage} />}
            </>
          )}
        </div>
      </div>
      {selectMode && <BulkBar items={results} />}
    </div>
  );
}
