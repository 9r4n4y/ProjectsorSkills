import { useEffect, useMemo, useRef, useState } from "react";
import { type ComicRecord, SearchIndex, filterComics, naturalCompare } from "@comiclib/shared";
import { Capacitor } from "@capacitor/core";
import { useStore } from "./store";

// ---- Back handling --------------------------------------------------------------------------------------
// One stack of "things Back should dismiss" (dialogs, drawers, the reader). Order of priority for Back:
//   1. top of the overlay stack (last opened first), 2. selection mode, 3. nested screen -> library,
//   4. nothing left: report "not handled" so the caller may leave the app.
// On Android the native MainActivity calls window.__comicBack() for the hardware button and the back gesture and
// minimises the app (never finishes it) when it returns false. In a normal browser the stack is wired to history
// instead. Native builds never touch history, so there is no popstate loop and Back cannot be swallowed.
const stack: { close: () => void }[] = [];
let ignore = 0;
const native = typeof window !== "undefined" && Capacitor.isNativePlatform();

/** Handles one Back press. Returns true if something was dismissed or navigated, false at the library root. */
export function handleBack(): boolean {
  const top = stack[stack.length - 1];
  if (top) {
    top.close();
    return true;
  }
  const s = useStore.getState();
  if (s.selectMode) {
    s.setSelectMode(false);
    return true;
  }
  return s.goBack();
}

if (typeof window !== "undefined") {
  (window as unknown as { __comicBack: () => boolean }).__comicBack = handleBack;
  if (!native) {
    window.addEventListener("popstate", () => {
      if (ignore > 0) {
        ignore--;
        return;
      }
      stack.pop()?.close();
    });
  }
}

/** While `open`, Back closes this overlay (LIFO with other overlays) instead of leaving the screen. */
export function useBackClose(open: boolean, close: () => void) {
  const ref = useRef(close);
  ref.current = close;
  useEffect(() => {
    if (!open) return;
    const entry = { close: () => ref.current() };
    stack.push(entry);
    if (!native) history.pushState({ overlay: true }, "");
    return () => {
      const i = stack.indexOf(entry);
      if (i >= 0) {
        stack.splice(i, 1);
        if (!native) {
          ignore++;
          history.back();
        }
      }
    };
  }, [open]);
}

export function useMedia(query: string): boolean {
  const [m, setM] = useState(() => window.matchMedia(query).matches);
  useEffect(() => {
    const mq = window.matchMedia(query);
    const h = () => setM(mq.matches);
    mq.addEventListener("change", h);
    return () => mq.removeEventListener("change", h);
  }, [query]);
  return m;
}
export const useIsMobile = () => useMedia("(max-width: 767px)");

// ---- search + filters + sort -----------------------------------------------------------------------------
export function useSearchIndex(comics: ComicRecord[]) {
  const prev = useRef<{ comics: ComicRecord[]; index: SearchIndex } | null>(null);
  return useMemo(() => {
    const p = prev.current;
    if (p && p.comics.length === comics.length && comics.every((c, i) => c.id === p.comics[i].id && c.name === p.comics[i].name && c.folder === p.comics[i].folder && c.tags === p.comics[i].tags)) {
      prev.current = { comics, index: p.index };
      return p.index;
    }
    const index = new SearchIndex();
    index.build(comics.map((c) => ({ id: c.id, name: c.name, folder: c.folder, author: c.author, tags: c.tags })));
    prev.current = { comics, index };
    return index;
  }, [comics]);
}

export function useLibraryView() {
  const comics = useStore((s) => s.comics);
  const filters = useStore((s) => s.filters);
  const sort = useStore((s) => s.settings.sort);
  const dir = useStore((s) => s.settings.sortDir);
  const series = useStore((s) => s.settings.series);
  const groupSeriesParts = useStore((s) => s.settings.groupSeriesParts !== false);
  const index = useSearchIndex(comics);

  const sorted = useMemo(() => {
    const k = (c: ComicRecord) => (sort === "added" ? c.addedAt : sort === "modified" ? c.mtime : sort === "pages" ? c.pages : sort === "lastRead" ? c.lastReadAt : 0);
    const arr = [...comics];
    arr.sort(sort === "name" ? (a, b) => naturalCompare(a.name, b.name) : (a, b) => k(a) - k(b) || naturalCompare(a.name, b.name));
    if (dir === "desc") arr.reverse();
    return arr;
  }, [comics, sort, dir]);

  return useMemo(() => {
    const t0 = performance.now();
    const ranked = index.search(filters.query);
    let results: ComicRecord[];
    if (ranked) results = filterComics(comics, filters, ranked);
    else if (filters.recentOnly) results = filterComics(comics, filters, null).sort((a, b) => b.lastReadAt - a.lastReadAt);
    else results = filterComics(sorted, filters, null);

    // When enabled (default ON), force-arrange connected series parts side by side in Part 1, 2, 3… order regardless of sort/direction
    if (groupSeriesParts && series?.length && results.length > 1) {
      const byId = new Map(results.map((c) => [c.id, c]));
      const comicToGroup = new Map<string, ComicRecord[]>();
      for (const s of series) {
        const present = s.comicIds.map((id) => byId.get(id)).filter((c): c is ComicRecord => !!c);
        if (present.length >= 2) {
          for (const c of present) comicToGroup.set(c.id, present);
        }
      }
      if (comicToGroup.size > 0) {
        const grouped: ComicRecord[] = [];
        const emitted = new Set<string>();
        for (const c of results) {
          if (emitted.has(c.id)) continue;
          const group = comicToGroup.get(c.id);
          if (group) {
            for (const part of group) {
              if (!emitted.has(part.id)) {
                emitted.add(part.id);
                grouped.push(part);
              }
            }
          } else {
            emitted.add(c.id);
            grouped.push(c);
          }
        }
        results = grouped;
      }
    }

    return { results, ms: performance.now() - t0, relevance: !!ranked };
  }, [index, comics, sorted, filters, series, groupSeriesParts]);
}
