import {
  type ComicRecord,
  type ComicSeries,
  authorTagsOf,
  naturalCompare,
  normalTagsOf,
  normalizeText,
  similarity,
  tagKey,
  tokenize,
} from "@comiclib/shared";

export interface ResolvedSeries {
  series: ComicSeries;
  /** 0-based index of the current comic in `parts` */
  partIndex: number;
  totalParts: number;
  parts: ComicRecord[];
  prev: ComicRecord | null;
  next: ComicRecord | null;
}

export interface RankedCandidate {
  comic: ComicRecord;
  score: number;
  isStrongMatch: boolean;
  hint?: string;
  detectedPart?: number | null;
}

const ROMAN_MAP: Record<string, number> = {
  i: 1,
  ii: 2,
  iii: 3,
  iv: 4,
  v: 5,
  vi: 6,
  vii: 7,
  viii: 8,
  ix: 9,
  x: 10,
  xi: 11,
  xii: 12,
};

/** Split CamelCase/PascalCase & replace underscores/dots/slashes with spaces so filenames tokenize cleanly. */
function humanizeTitle(raw: string): string {
  return raw
    .replace(/([a-z0-9])([A-Z])/g, "$1 $2")
    .replace(/([A-Z]+)([A-Z][a-z])/g, "$1 $2")
    .replace(/[_\.\+\/\\]+/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

/** Extract bracketed metadata tags like [Author], (C99), [English] separately from the core title. */
function extractBrackets(raw: string): { groups: string[]; stripped: string } {
  const groups: string[] = [];
  const stripped = raw
    .replace(/\[([^\]]{1,48})\]|\(([^)]{1,48})\)|\{([^}]{1,48})\}/g, (match, a, b, c) => {
      const inner = String(a ?? b ?? c ?? "").trim();
      // Keep pure numeric brackets like "(2)" or "[Part 2]" in stripped so part-number extraction sees them
      if (/^(?:(?:vol(?:ume)?|part|pt|ch(?:apter)?|ep(?:isode)?|no\.?|#)\s*\.?\s*)?\d+[a-z]?$/i.test(inner)) {
        return ` ${inner} `;
      }
      const norm = normalizeText(humanizeTitle(inner));
      if (norm && !/^(english|eng|japanese|jpn|chinese|chn|korean|kor|digital|uncensored|decensored|color|full color|raw|translated|dl|web|complete|ongoing)$/.test(norm)) {
        groups.push(norm);
      }
      return " ";
    })
    .replace(/\s+/g, " ")
    .trim();
  return { groups, stripped: stripped || raw };
}

/** Detect an explicit or trailing part/volume/chapter number in a comic title (including Roman numerals). */
export function extractPartNumber(raw: string): number | null {
  const s = humanizeTitle(raw);

  // 1. Explicit markers: Part 2, Pt. 3, Vol 04, Ch. 5, Episode 6, #7, Book 2, Act 3
  const explicit = s.match(/(?:^|[\s\-_:–—(\[])(?:part|pt|vol(?:ume)?|ch(?:apter)?|ep(?:isode)?|issue|book|bk|act|no\.?|#)\s*\.?\s*(\d{1,4})(?:\b|$)/i);
  if (explicit) return parseInt(explicit[1], 10);

  // 2. Ordinals: 2nd, 3rd, 4th
  const ord = s.match(/\b(\d{1,2})(?:st|nd|rd|th)\b/i);
  if (ord) return parseInt(ord[1], 10);

  // 3. Japanese part markers (Zenpen / Chuuhen / Kouhen, Jou / Chuu / Ge)
  if (/\b(?:zenpen|jou)\b/i.test(s) || /前編|上巻/.test(raw)) return 1;
  if (/\b(?:chuuhen)\b/i.test(s) || /中編|中巻/.test(raw)) return 2;
  if (/\b(?:kouhen|ge)\b/i.test(s) || /後編|下巻/.test(raw)) return 2;

  // 4. Trailing Arabic number (ignore years like 1998..2035)
  const trailing = s.match(/(?:^|[\s\-_:–—(\[])(\d{1,4})\s*[\])]?\s*$/);
  if (trailing) {
    const val = parseInt(trailing[1], 10);
    if (val < 1900 || val > 2099) return val;
  }

  // 5. Trailing Roman numeral (II..XII)
  const roman = s.match(/[\s\-_:–—]+(xii|xi|x|ix|viii|vii|vi|v|iv|iii|ii)\s*$/i);
  if (roman) return ROMAN_MAP[roman[1].toLowerCase()] ?? null;

  return null;
}

/**
 * Strip brackets, underscores, and volume/part/chapter/episode/issue numbers so
 * "[Circle] Silent_Atlas_Vol.01" and "[Circle] Silent Atlas Part 2" share the exact same core title.
 */
export function stripPartTokens(name: string): string {
  const { stripped } = extractBrackets(name);
  let s = humanizeTitle(stripped);
  // Remove explicit part/vol/chapter/episode/number clauses anywhere at the end
  s = s.replace(/[\s\-_:–—]*(?:part|pt|vol(?:ume)?|ch(?:apter)?|ep(?:isode)?|issue|book|bk|act|no\.?|#)\s*\.?\s*\d{1,4}[a-z]?\b.*$/i, "");
  // Remove Japanese part words
  s = s.replace(/[\s\-_:–—]*(?:zenpen|chuuhen|kouhen|前編|中編|後編|上巻|中巻|下巻)\s*$/i, "");
  // Remove trailing Roman numeral
  s = s.replace(/[\s\-_:–—]+(?:xii|xi|x|ix|viii|vii|vi|v|iv|iii|ii)\s*$/i, "");
  // Remove trailing plain number (e.g. "My Comic 02", "My Comic - 3")
  s = s.replace(/[\s\-_:–—]+\d{1,4}[a-z]?\s*$/i, "");
  // Clean stray trailing punctuation
  s = s.replace(/[\s\-_:–—]+$/g, "").trim();
  return s || humanizeTitle(name);
}

/** Character trigram Dice coefficient (fast, great for long/squashed titles with slight spelling or suffix changes). */
function trigramSimilarity(a: string, b: string): number {
  const sa = a.replace(/\s+/g, "");
  const sb = b.replace(/\s+/g, "");
  if (sa.length < 3 || sb.length < 3) return sa === sb ? 1 : 0;
  const mapA = new Map<string, number>();
  for (let i = 0; i <= sa.length - 3; i++) {
    const tri = sa.slice(i, i + 3);
    mapA.set(tri, (mapA.get(tri) ?? 0) + 1);
  }
  let inter = 0;
  for (let i = 0; i <= sb.length - 3; i++) {
    const tri = sb.slice(i, i + 3);
    const c = mapA.get(tri);
    if (c && c > 0) {
      inter++;
      mapA.set(tri, c - 1);
    }
  }
  return (2 * inter) / (sa.length - 2 + (sb.length - 2));
}

/** Resolve the series containing `comicId`, automatically ignoring deleted comic IDs. */
export function findSeriesForComic(
  seriesList: readonly ComicSeries[] | undefined,
  comicId: string,
  comics: readonly ComicRecord[],
): ResolvedSeries | null {
  if (!seriesList?.length) return null;
  const byId = new Map(comics.map((c) => [c.id, c]));
  for (const series of seriesList) {
    if (!series.comicIds.includes(comicId)) continue;
    const parts = series.comicIds.map((id) => byId.get(id)).filter((c): c is ComicRecord => !!c);
    if (parts.length < 2) continue;
    const partIndex = parts.findIndex((c) => c.id === comicId);
    if (partIndex < 0) continue;
    return {
      series,
      partIndex,
      totalParts: parts.length,
      parts,
      prev: partIndex > 0 ? parts[partIndex - 1] : null,
      next: partIndex < parts.length - 1 ? parts[partIndex + 1] : null,
    };
  }
  return null;
}

/** Fast lookup map: comicId -> { partNumber (1-based), totalParts, seriesId, seriesName }. */
export function buildSeriesBadgeMap(
  seriesList: readonly ComicSeries[] | undefined,
  comics: readonly ComicRecord[],
): Map<string, { partNumber: number; totalParts: number; seriesId: string; seriesName: string }> {
  const out = new Map<string, { partNumber: number; totalParts: number; seriesId: string; seriesName: string }>();
  if (!seriesList?.length) return out;
  const validIds = new Set(comics.map((c) => c.id));
  for (const s of seriesList) {
    const valid = s.comicIds.filter((id) => validIds.has(id));
    if (valid.length < 2) continue;
    valid.forEach((id, idx) => {
      out.set(id, { partNumber: idx + 1, totalParts: valid.length, seriesId: s.id, seriesName: s.name });
    });
  }
  return out;
}

/**
 * Ultra-smart multi-signal candidate ranker:
 * Combines core-title matching (stripping brackets/underscores/CamelCase/part numbers),
 * sequential part number hints (N+1, N-1, Roman numerals, Vol/Ch/Pt), trigram & token similarity,
 * bracketed [Circle/Author] matches, shared user Author tags, shared regular tags, and folder proximity.
 */
export function rankCandidatesByName(
  anchor: ComicRecord,
  allComics: readonly ComicRecord[],
  query: string,
  excludeIds?: ReadonlySet<string>,
): RankedCandidate[] {
  const anchorMeta = extractBrackets(anchor.name);
  const anchorCore = normalizeText(stripPartTokens(anchor.name));
  const anchorHuman = normalizeText(humanizeTitle(anchor.name));
  const anchorTokens = new Set(tokenize(anchorCore));
  const anchorPartNum = extractPartNumber(anchor.name);
  const anchorGroups = new Set(anchorMeta.groups);
  const anchorAuthors = new Set(authorTagsOf(anchor.tags).map(tagKey));
  const anchorNormalTags = new Set(normalTagsOf(anchor.tags).map(tagKey));

  const nq = normalizeText(humanizeTitle(query));
  const qTokens = tokenize(humanizeTitle(query));

  const scored: RankedCandidate[] = [];

  for (const c of allComics) {
    if (c.id === anchor.id) continue;
    if (excludeIds?.has(c.id)) continue;

    const cHuman = normalizeText(humanizeTitle(c.name));
    const cFolder = normalizeText(c.folder);
    const cAuthorsList = authorTagsOf(c.tags);
    const cAuthorText = normalizeText(cAuthorsList.join(" "));

    if (nq) {
      const hay = `${cHuman} ${cAuthorText} ${cFolder}`;
      const matched = hay.includes(nq) || (qTokens.length > 0 && qTokens.every((t) => hay.includes(t)));
      if (!matched) continue;
    }

    const cMeta = extractBrackets(c.name);
    const cCore = normalizeText(stripPartTokens(c.name));
    const cPartNum = extractPartNumber(c.name);
    let score = 0;
    let sameCore = false;

    // 1. Core-title match (after stripping brackets, underscores, CamelCase & part numbers)
    if (anchorCore.length >= 2 && cCore === anchorCore) {
      score += 1200;
      sameCore = true;
    } else if (anchorCore.length >= 4 && (cCore.startsWith(anchorCore) || anchorCore.startsWith(cCore))) {
      score += 680;
      sameCore = true;
    }

    // 2. Word/token Jaccard overlap on core title
    const cTokens = tokenize(cCore);
    let tokenOverlapRatio = 0;
    if (anchorTokens.size > 0 && cTokens.length > 0) {
      let overlap = 0;
      for (const t of cTokens) if (anchorTokens.has(t)) overlap++;
      if (overlap > 0) {
        const union = new Set([...anchorTokens, ...cTokens]).size;
        tokenOverlapRatio = overlap / union;
        score += Math.round(tokenOverlapRatio * 460);
      }
    }

    // 3. Trigram similarity (catches squashed names, typos, and partial subtitles)
    const triSim = trigramSimilarity(anchorCore, cCore);
    score += Math.round(triSim * 320);

    // 4. Shared prefix & edit similarity
    let prefix = 0;
    const minLen = Math.min(anchorHuman.length, cHuman.length);
    while (prefix < minLen && anchorHuman[prefix] === cHuman[prefix]) prefix++;
    if (prefix >= 4) score += Math.min(240, prefix * 14);
    score += Math.round(similarity(anchorCore, cCore) * 160);

    // 5. Smart sequential part-number boost when titles are related
    const titleRelated = sameCore || triSim >= 0.45 || tokenOverlapRatio >= 0.5;
    let hint: string | undefined;
    if (titleRelated && cPartNum != null) {
      if (anchorPartNum != null) {
        const diff = cPartNum - anchorPartNum;
        if (diff === 1) {
          score += 360;
          hint = `Next part (#${cPartNum})`;
        } else if (diff === -1) {
          score += 310;
          hint = `Prev part (#${cPartNum})`;
        } else if (Math.abs(diff) <= 10 && diff !== 0) {
          score += 240 - Math.min(80, Math.abs(diff) * 8);
          hint = `Series #${cPartNum}`;
        }
      } else if (cPartNum === 2) {
        score += 320;
        hint = "Likely Part 2";
      } else if (cPartNum <= 10) {
        score += 220;
        hint = `Series #${cPartNum}`;
      }
    } else if (sameCore) {
      hint = "Same series";
    }

    // 6. Bracketed [Circle / Author] match
    if (anchorGroups.size > 0 && cMeta.groups.some((g) => anchorGroups.has(g))) {
      score += 180;
    }

    // 7. Shared user-assigned Author tags
    if (anchorAuthors.size > 0 && cAuthorsList.some((a) => anchorAuthors.has(tagKey(a)))) {
      score += 160;
    }

    // 8. Same folder & shared regular tags
    if (anchor.folder && c.folder === anchor.folder) score += 85;
    if (anchorNormalTags.size > 0) {
      let sharedTags = 0;
      for (const t of normalTagsOf(c.tags)) {
        if (anchorNormalTags.has(tagKey(t))) sharedTags++;
      }
      score += Math.min(80, sharedTags * 20);
    }

    // 9. Search query match boost
    if (nq) {
      if (cHuman === nq) score += 320;
      else if (cHuman.startsWith(nq)) score += 190;
      else if (cHuman.includes(nq)) score += 100;
    }

    const isStrongMatch = score >= 560;
    if (isStrongMatch && !hint) hint = "Best match";

    scored.push({
      comic: c,
      score,
      isStrongMatch,
      hint,
      detectedPart: cPartNum,
    });
  }

  scored.sort((a, b) => {
    // Keep same-series strong matches in clean ascending part order if scores are close
    if (a.isStrongMatch && b.isStrongMatch && Math.abs(a.score - b.score) < 110) {
      if (a.detectedPart != null && b.detectedPart != null && a.detectedPart !== b.detectedPart) {
        return a.detectedPart - b.detectedPart;
      }
      return naturalCompare(a.comic.name, b.comic.name);
    }
    return b.score - a.score || naturalCompare(a.comic.name, b.comic.name);
  });

  return scored;
}

function makeSeriesId(): string {
  return `s_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 7)}`;
}

/**
 * Connect `targetComic` into `anchorComic`'s series at exact 1-based `partNumber` (1..N+1).
 * If `anchorComic` is not yet in a series, creates a new series starting with `anchorComic`.
 */
export function setComicPartPosition(
  seriesList: readonly ComicSeries[] | undefined,
  anchorComic: ComicRecord,
  targetComic: ComicRecord,
  partNumber: number,
): ComicSeries[] {
  const list = (seriesList ?? []).map((s) => ({ ...s, comicIds: [...s.comicIds] }));
  let current = list.find((s) => s.comicIds.includes(anchorComic.id));

  for (const s of list) {
    if (s !== current) {
      s.comicIds = s.comicIds.filter((id) => id !== targetComic.id);
    }
  }

  if (!current) {
    current = {
      id: makeSeriesId(),
      name: stripPartTokens(anchorComic.name),
      comicIds: [anchorComic.id],
    };
    list.push(current);
  }

  const withoutTarget = current.comicIds.filter((id) => id !== targetComic.id);
  const insertAt = Math.max(0, Math.min(withoutTarget.length, Math.round(partNumber) - 1));
  withoutTarget.splice(insertAt, 0, targetComic.id);
  current.comicIds = withoutTarget;

  return list.filter((s) => s.comicIds.length >= 2);
}

/** Reorder a part inside a series from `fromIndex` to `toIndex`. */
export function moveSeriesPart(
  seriesList: readonly ComicSeries[] | undefined,
  seriesId: string,
  fromIndex: number,
  toIndex: number,
): ComicSeries[] {
  const list = (seriesList ?? []).map((s) => ({ ...s, comicIds: [...s.comicIds] }));
  const s = list.find((x) => x.id === seriesId);
  if (!s) return list;
  if (fromIndex < 0 || fromIndex >= s.comicIds.length) return list;
  const clampedTo = Math.max(0, Math.min(s.comicIds.length - 1, toIndex));
  const [item] = s.comicIds.splice(fromIndex, 1);
  s.comicIds.splice(clampedTo, 0, item);
  return list;
}

/** Remove one comic from a series; automatically cleans up the series if fewer than 2 parts remain. */
export function removeSeriesPart(
  seriesList: readonly ComicSeries[] | undefined,
  seriesId: string,
  comicId: string,
): ComicSeries[] {
  return (seriesList ?? [])
    .map((s) => (s.id === seriesId ? { ...s, comicIds: s.comicIds.filter((id) => id !== comicId) } : s))
    .filter((s) => s.comicIds.length >= 2);
}

/** Rename a series cleanly. */
export function renameSeries(
  seriesList: readonly ComicSeries[] | undefined,
  seriesId: string,
  name: string,
): ComicSeries[] {
  const trimmed = name.trim();
  if (!trimmed) return [...(seriesList ?? [])];
  return (seriesList ?? []).map((s) => (s.id === seriesId ? { ...s, name: trimmed } : s));
}

/** Disconnect all parts in a series. */
export function dissolveSeries(
  seriesList: readonly ComicSeries[] | undefined,
  seriesId: string,
): ComicSeries[] {
  return (seriesList ?? []).filter((s) => s.id !== seriesId);
}
