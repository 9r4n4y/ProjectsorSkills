import { sha256Hex, type AppLockConfig, type AppLockSlot } from "@comiclib/shared";

const DEFAULT_ITER = 150_000;

function toBase64(bytes: Uint8Array): string {
  let s = "";
  for (let i = 0; i < bytes.length; i++) s += String.fromCharCode(bytes[i]);
  return btoa(s);
}

function fromBase64(b64: string): Uint8Array {
  const bin = atob(b64);
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}

function randomBytes(len: number): Uint8Array {
  const out = new Uint8Array(len);
  if (typeof crypto !== "undefined" && typeof crypto.getRandomValues === "function") {
    crypto.getRandomValues(out);
  } else {
    for (let i = 0; i < len; i++) out[i] = Math.floor(Math.random() * 256);
  }
  return out;
}

/** Constant-time string comparison to avoid timing leaks when verifying hashes. */
function constantTimeEqual(a: string, b: string): boolean {
  if (a.length !== b.length) return false;
  let diff = 0;
  for (let i = 0; i < a.length; i++) diff |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return diff === 0;
}

/**
 * Derive a 256-bit password hash using Web Crypto PBKDF2-SHA256 (150,000 iterations).
 * Falls back to iterated SHA-256 only if SubtleCrypto is unavailable (e.g. non-secure HTTP test context).
 */
async function deriveHash(password: string, saltB64: string, iter: number): Promise<string> {
  if (typeof crypto !== "undefined" && crypto.subtle) {
    const salt = fromBase64(saltB64);
    const keyMaterial = await crypto.subtle.importKey("raw", new TextEncoder().encode(password), "PBKDF2", false, ["deriveBits"]);
    const bits = await crypto.subtle.deriveBits(
      { name: "PBKDF2", salt: salt as BufferSource, iterations: iter, hash: "SHA-256" },
      keyMaterial,
      256,
    );
    return toBase64(new Uint8Array(bits));
  }
  // Fallback for environments without SubtleCrypto
  let h = sha256Hex(`${saltB64}:${password}`);
  const rounds = Math.min(iter, 5000);
  for (let i = 0; i < rounds; i++) h = sha256Hex(`${h}:${saltB64}:${password}`);
  return `fb:${h}`;
}

export async function createPasswordSlot(id: 1 | 2 | 3, password: string, label?: string): Promise<AppLockSlot> {
  const salt = toBase64(randomBytes(16));
  const iter = DEFAULT_ITER;
  const hash = await deriveHash(password, salt, iter);
  return { id, label: label?.trim() || `Password ${id}`, salt, hash, iter };
}

export async function verifyPasswordSlot(password: string, slot: AppLockSlot): Promise<boolean> {
  if (!password || !slot.salt || !slot.hash) return false;
  try {
    const derived = await deriveHash(password, slot.salt, slot.iter || DEFAULT_ITER);
    return constantTimeEqual(derived, slot.hash);
  } catch {
    return false;
  }
}

/** Checks the candidate password against all configured slots (1..3); returns the matched slot or null. */
export async function verifyAnyPassword(password: string, slots: readonly AppLockSlot[]): Promise<AppLockSlot | null> {
  let matched: AppLockSlot | null = null;
  for (const slot of slots) {
    const ok = await verifyPasswordSlot(password, slot);
    if (ok && !matched) matched = slot;
  }
  return matched;
}

export function hasActiveAppLock(lock?: AppLockConfig): boolean {
  return Boolean(lock && lock.enabled && Array.isArray(lock.slots) && lock.slots.length > 0);
}
