package app.comiclib.mobile

import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.WebView
import androidx.activity.OnBackPressedCallback
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.getcapacitor.BridgeActivity

/**
 * System bars: ONE strategy. The window is edge-to-edge (the only mode on Android 15 / targetSdk 35), and this class is the
 * single owner of the insets: it pads the WebView's parent by the status bar, navigation bar, display cutout and keyboard,
 * then consumes them. The WebView therefore sees no insets (env(safe-area-*) is 0), and the web layer must not pad again
 * (CSS .safe-t/.safe-b are disabled by html.native-app). The padded strip shows the theme background, and icon contrast is
 * switched with the theme (see applySystemBars).
 *
 * Back: hardware Back and the gesture both reach the OnBackPressedCallback below. The web layer decides what to dismiss
 * (dialog, reader, nested screen); if nothing is left the task is moved to the background, never finished.
 */
class MainActivity : BridgeActivity() {
    private var dark = false

    override fun onCreate(savedInstanceState: Bundle?) {
        registerPlugin(ComicNativePlugin::class.java)
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        val content = findViewById<ViewGroup>(android.R.id.content)
        ViewCompat.setOnApplyWindowInsetsListener(content) { v, insets ->
            val i = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout() or WindowInsetsCompat.Type.ime())
            v.setPadding(i.left, i.top, i.right, i.bottom)
            WindowInsetsCompat.CONSUMED
        }
        ViewCompat.requestApplyInsets(content)
        // The UI is a fixed-size shell with its own in-app zoom (reader). Browser pinch-zoom of the whole page must be off,
        // otherwise zooming out makes the page wider than the screen and the chrome slides outside it.
        bridge?.webView?.settings?.apply {
            setSupportZoom(false)
            builtInZoomControls = false
            displayZoomControls = false
        }
        applySystemBars(resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_NIGHT_MASK == android.content.res.Configuration.UI_MODE_NIGHT_YES)

        // Registered after super.onCreate so it runs before Capacitor's own handler.
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                val wv: WebView? = bridge?.webView
                if (wv == null) { moveTaskToBack(true); return }
                wv.evaluateJavascript("(function(){try{return window.__comicBack?window.__comicBack():false}catch(e){return false}})()") { r ->
                    if (r != "true") moveTaskToBack(true)
                }
            }
        })
    }

    /** Theme colours for the bar strips and matching status/navigation icon contrast. Safe to call from any thread. */
    fun applySystemBars(isDark: Boolean) {
        dark = isDark
        runOnUiThread {
            val bg = if (isDark) Color.parseColor("#1d1b3b") else Color.parseColor("#dfe6ff")
            window.decorView.setBackgroundColor(bg)
            findViewById<View>(android.R.id.content)?.setBackgroundColor(bg)
            @Suppress("DEPRECATION") run { window.statusBarColor = Color.TRANSPARENT; window.navigationBarColor = Color.TRANSPARENT }
            WindowInsetsControllerCompat(window, window.decorView).apply {
                isAppearanceLightStatusBars = !isDark
                isAppearanceLightNavigationBars = !isDark
            }
        }
    }

    /** Keep display awake while Folio is open when Always Wake is enabled. Safe to call from any thread. */
    fun applyKeepScreenOn(on: Boolean) {
        runOnUiThread {
            if (on) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
    }
}
