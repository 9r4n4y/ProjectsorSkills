# Folio v5.6

## Highlights
- **Connect Parts UI Overhaul (Zero Squished Text):** Rebuilt every connected part and candidate card in `ConnectPartsModal` into a crisp 2-row card layout—Row 1 gives the cover thumbnail and full-width title generous breathing room with single-line `whitespace-nowrap` Part pills (`Part 1`, `Part 2`, `Part 3`…), and Row 2 places neatly aligned controls underneath.
- **Ultra-Smart Part Connection Recommendations:** Upgraded `src/lib/series.ts` to split CamelCase/underscores, strip bracketed metadata (`[Circle]`, `[English]`, `(C99)`), detect part/volume/chapter/Roman-numeral numbers anywhere in the filename, compute trigram + token + bracket/author-tag similarity, and highlight likely `Next part (#N)`, `Prev part (#N)`, and `Same series` matches right at the top.
- **Dedicated Author Tags (Separated from Folders):** Authors are now true user-assigned Author tags (`author:<Name>` stored cleanly in standard metadata v1 tags) completely separated from folders—never showing folder names in the Authors section. Add, edit, bulk-tag, rename, merge, delete, and filter Author tags via the **Tags | Authors** switcher in Search, Tag Editor, Quick Look, and the Tags screen.
- **Show Reading Progress Bar Toggle (Default: OFF):** Added a Settings switch under *Appearance and reading* to show or hide the bottom reading progress bar on library comic covers (off by default).
- **Reader Start Position Setting (Default: Last page):** Added a Settings option (*When opening a comic*) to either **Resume last page** (default) or always open **From start** (Page 1).
