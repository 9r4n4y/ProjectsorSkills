# Folio v5

- **Mass Selection, Folder Tagging & Tag-Group Bulk Tagging**:
  - `BulkBar` now lets you select ALL matching comics across all pages in one tap (`All (N)`), add/remove comma-separated tags, favorite, or move them together—using the exact same standard `comiclib.metadata` format.
  - Added direct one-tap bulk-tag and select-all buttons for every folder (in the Edge Panel and Folder Filter panel) and for every tag (in the Tags screen and Tag Filter panel).
- **Unlimited / No-Pages Library Mode**: Added an `Unlimited` (`pageSize: 0`) option under **Settings → Appearance and reading → Comics per page** so you can scroll continuously through all comics with no pagination.
- **3-Password App Lock Security (Android, PC & Web)**:
  - Hard security gate (`AppLockGate`) that does not mount library or reader UI while locked, with PBKDF2-SHA256 (`150,000` iterations) hashing and a 30-second cooldown after 5 wrong attempts.
  - Supports up to 3 independent passwords—any one unlocks the app and can verify to reset, change, or remove any of the 3 slots.
  - Configurable auto-lock: `On close` (stays unlocked until app restart) or `After idle` (`1`, `2`, `5`, `10`, or `30` minutes of inactivity/backgrounding), plus a manual `Lock app` button.
- **Gallery-Style Swipe & Zoomed Edge-Pull Page Turning**:
  - Replaced teleport/double-swipe in Tap & Auto modes with a smooth horizontal Gallery carousel where adjacent pages slide in right beside the current page.
  - When zoomed in, pan smoothly with your `Zoom pan sensitivity` setting; reaching the left or right edge and pulling deliberately past the dead-zone smoothly slides to the next or previous page without accidental turns.
- **Full Tutorial in Settings**: Added an expandable 8-section **How to use Folio** guide inside Settings.
- **Version Bump**: Updated code/build version to `5.0.0` (Android `versionCode 12`, `versionName 5.0`, `Folio-v5-debug.apk`).
