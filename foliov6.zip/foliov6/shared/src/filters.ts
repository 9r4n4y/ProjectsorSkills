import type { ComicRecord } from "./types";
import { normalizeText } from "./text";

export interface FilterState {
  query: string;
  tagsIn: string[];
  tagsEx: string[];
  /** how included tags combine */
  tagMode: "and" | "or";
  authorsIn: string[];
  authorsEx: string[];
  foldersIn: string[];
  foldersEx: string[];
  favoritesOnly: boolean;
  recentOnly: boolean;
}

export const EMPTY_FILTERS: FilterState = {
  query: "",
  tagsIn: [],
  tagsEx: [],
  tagMode: "and",
  authorsIn: [],
  authorsEx: [],
  foldersIn: [],
  foldersEx: [],
  favoritesOnly: false,
  recentOnly: false,
};

export const AUTHOR_TAG_PREFIX = "author:";

export function isAuthorTag(t: string): boolean {
  return t.trim().toLowerCase().startsWith(AUTHOR_TAG_PREFIX);
}

export function authorTagName(t: string): string {
  const trimmed = t.trim();
  return isAuthorTag(trimmed) ? trimmed.slice(AUTHOR_TAG_PREFIX.length).trim() : trimmed;
}

export function toAuthorTag(name: string): string {
  const clean = authorTagName(name);
  return clean ? `${AUTHOR_TAG_PREFIX}${clean}` : "";
}

export function normalTagsOf(tags: readonly string[]): string[] {
  return tags.filter((t) => !isAuthorTag(t));
}

export function authorTagsOf(tags: readonly string[]): string[] {
  return tags.filter(isAuthorTag).map(authorTagName).filter(Boolean);
}

export function tagKey(t: string): string {
  return normalizeText(t);
}

export function inFolder(comicFolder: string, folder: string): boolean {
  return comicFolder === folder || comicFolder.startsWith(folder + "/");
}

export function activeFilterCount(f: FilterState): number {
  return (
    (f.query.trim() ? 1 : 0) +
    f.tagsIn.length +
    f.tagsEx.length +
    f.authorsIn.length +
    f.authorsEx.length +
    f.foldersIn.length +
    f.foldersEx.length +
    (f.favoritesOnly ? 1 : 0) +
    (f.recentOnly ? 1 : 0)
  );
}

/**
 * Combine tag, folder and section filters with an optional ranked id list from text search.
 * Included tags combine with AND by default (OR when tagMode is "or"); excluded tags always remove.
 * Included folders combine with OR (scope to any of them); excluded folders always remove.
 */
export function filterComics(
  comics: readonly ComicRecord[],
  f: FilterState,
  ranked: readonly string[] | null,
): ComicRecord[] {
  const inKeys = f.tagsIn.map(tagKey);
  const exKeys = new Set(f.tagsEx.map(tagKey));
  const authorInKeys = f.authorsIn.map(tagKey);
  const authorExKeys = new Set(f.authorsEx.map(tagKey));
  let base: readonly ComicRecord[] = comics;
  if (ranked) {
    const byId = new Map(comics.map((c) => [c.id, c]));
    base = ranked.map((id) => byId.get(id)).filter((c): c is ComicRecord => !!c);
  }
  return base.filter((c) => {
    if (f.favoritesOnly && !c.favorite) return false;
    if (f.recentOnly && !c.lastReadAt) return false;
    if (inKeys.length || exKeys.size) {
      const keys = new Set(normalTagsOf(c.tags).map(tagKey));
      for (const k of exKeys) if (keys.has(k)) return false;
      if (inKeys.length) {
        const ok = f.tagMode === "and" ? inKeys.every((k) => keys.has(k)) : inKeys.some((k) => keys.has(k));
        if (!ok) return false;
      }
    }
    if (authorInKeys.length || authorExKeys.size) {
      const aKeys = new Set(authorTagsOf(c.tags).map(tagKey));
      for (const k of authorExKeys) if (aKeys.has(k)) return false;
      if (authorInKeys.length && !authorInKeys.some((k) => aKeys.has(k))) return false;
    }
    if (f.foldersEx.some((p) => inFolder(c.folder, p))) return false;
    if (f.foldersIn.length && !f.foldersIn.some((p) => inFolder(c.folder, p))) return false;
    return true;
  });
}

export function countTags(comics: readonly ComicRecord[]): Map<string, { name: string; count: number }> {
  const out = new Map<string, { name: string; count: number }>();
  for (const c of comics) {
    for (const t of normalTagsOf(c.tags)) {
      const k = tagKey(t);
      const e = out.get(k);
      if (e) e.count++;
      else out.set(k, { name: t, count: 1 });
    }
  }
  return out;
}

export function countAuthors(comics: readonly ComicRecord[]): Map<string, { name: string; count: number }> {
  const out = new Map<string, { name: string; count: number }>();
  for (const c of comics) {
    for (const a of authorTagsOf(c.tags)) {
      const k = tagKey(a);
      const e = out.get(k);
      if (e) e.count++;
      else out.set(k, { name: a, count: 1 });
    }
  }
  return out;
}

export function countFolders(comics: readonly ComicRecord[]): Map<string, number> {
  const out = new Map<string, number>();
  for (const c of comics) {
    let p = c.folder;
    while (p) {
      out.set(p, (out.get(p) ?? 0) + 1);
      const i = p.lastIndexOf("/");
      p = i < 0 ? "" : p.slice(0, i);
    }
  }
  return out;
}

/** Toggle a value in the include or exclude list; the same value never sits in both. */
export function toggleInEx(
  inc: readonly string[],
  exc: readonly string[],
  value: string,
  kind: "in" | "ex",
): { inc: string[]; exc: string[] } {
  const without = (arr: readonly string[]) => arr.filter((x) => x !== value);
  const has = (arr: readonly string[]) => arr.includes(value);
  if (kind === "in") return { inc: has(inc) ? without(inc) : [...inc, value], exc: without(exc) };
  return { inc: without(inc), exc: has(exc) ? without(exc) : [...exc, value] };
}
