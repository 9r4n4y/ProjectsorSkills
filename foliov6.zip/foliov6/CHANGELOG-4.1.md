# Folio v4.1

- **Reader Lock Mode**: Added a Lock button in the reader top bar that hides all reader UI (top bar, bottom scrubber, arrows, auto badge) and suppresses tap-to-show UI, leaving only a thin semi-transparent right-edge tab—tap it (or press Back) to bring the UI back immediately.
- **Tap-Mode Swipe & Zoomed Quick Double-Swipe**: Made horizontal swipe back/forth more responsive when unzoomed, and added quick same-direction double-swipe while zoomed in (two quick horizontal flicks within 420ms) to jump to the next or previous page without interfering with smooth panning or pinch zoom.
- **Version Bump**: Updated code/build version to `4.1.0` (Android `versionCode 11`, `versionName 4.1`, `Folio-v4.1-debug.apk`).
