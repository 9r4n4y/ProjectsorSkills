# Folio v5.1

## Highlights
- **Snappy 120Hz Tap Mode (No Swipe / Zero Flicker):** Removed swipe-to-next gallery animation completely. Tap mode now uses narrow, thumb-friendly invisible left and right edge tap zones with 0ms page switching, persistent non-remounting images, eager `-1..+3` page preloading + `img.decode()`, and direct `requestAnimationFrame` GPU zoom/pan—eliminating zoom-bounce and flicker completely.
- **Always Keep Screen Awake:** Added a Settings toggle (`keepScreenAwake`) that keeps the display on via Android `FLAG_KEEP_SCREEN_ON`, Electron `powerSaveBlocker`, and the Web Wake Lock API.
- **Always-Live State & App Lock Timers:**
  - Folio stays mounted underneath the App Lock overlay so auto-locking preserves your exact open comic, page, and scroll position—unlocking returns you to the exact spot you left off.
  - **After idle** mode displays a live `MM:SS` countdown timer in Settings and auto-locks at `00:00`.
  - **On close** mode persists unlock state at the process level (`ComicApp.sessionUnlocked` on Android, process/session state on Desktop/Web) so switching between any number of other apps never re-prompts for a password until you manually close Folio.
- **Configurable Keyboard Shortcuts:** Added a dedicated **Keyboard shortcuts** page opened from Settings (keeping Settings compact) where all 16 Navigation, Library, and Reader shortcuts can be rebound, cleared, or reset.
