# Folio v5.5

## Highlights
- **Author Filter Section in Search (Tags | Authors):** Opening the Tag filter panel in Library search now shows two clean tabs—**Tags** and **Authors**—so you can search, include (`+`), exclude (`-`), bulk-tag, or select all comics by any author, with active Author filter chips in the search bar.
- **Connect Comics as Series / Parts (`Part 1, 2, 3, 4…`):**
  - Open any comic in **Quick Look** or inside the **Reader** top bar and tap **Connect parts**.
  - **Smart Name Matching:** Comics with the closest matching titles appear automatically at the very top (`Best match`), followed by all other comics below, plus instant search by name, author, or folder.
  - **Cover Photo & Full-Name Preview:** Every comic shows its cover thumbnail and full name; tap any comic to open an in-modal photo preview sheet showing its full untruncated name, metadata, and page photos, then assign it directly as **Part 1, 2, 3, 4…** or reorder parts anytime.
  - **Seamless 120Hz Part-to-Part Reading:**
    - **Scroll mode:** Reach the end of a comic to tap straight into the **Next Part** card (or scroll to the top for the **Previous Part** card).
    - **Tap mode:** Tapping the right edge on the last page flows straight into Part N+1 (Page 1), and tapping the left edge on Page 1 steps back into Part N-1 (Last Page), plus a compact **Prev part / Part X of Y / Next part** bar and configurable `[` / `]` keyboard shortcuts.
  - **Library Badges & Metadata v1 Compatibility:** Connected comics show a crisp `Pt X/Y` badge on library cards and save cleanly inside standard settings without altering the `comiclib.metadata` v1 schema.
