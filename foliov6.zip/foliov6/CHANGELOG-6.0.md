# Folio v6

## Highlights
- **True One-Step-Back Navigation History Everywhere:**
  - Opening a comic from **Quick Look (Comic Preview)** and tapping **X** or pressing **Android Back** now returns you directly one step back to **Quick Look** (keeping the preview synced if you jumped to another connected part!), and pressing Back once more returns to the Library.
  - Added full `screenHistory` stack in `store.ts` so Back always returns one screen back (e.g. `Detailed Tutorial → Settings → previous screen`, `Keyboard Shortcuts → Settings → previous screen`).
  - Pressing Back inside `ConnectPartsModal`'s photo preview sheet closes only the preview sheet instead of the entire modal.
- **Force-Group Connected Parts Together (Settings Toggle, Default: ON):**
  - New Settings switch (*Appearance and reading → Group connected parts together*, default ON) keeps connected comic parts arranged side by side in exact `Part 1, 2, 3…` order regardless of sort mode (Name, Date Added, Date Modified, Page Count, Last Read, Ascending or Descending). Turn it OFF for 100% normal independent sorting.
- **Connect Parts UI Overlap Fix:**
  - Replaced clipped `size-8` Mochi icon buttons in `ConnectPartsModal` with uniform, zero-overflow `h-9` / `size-9` pill buttons and balanced spacing so Up/Down arrows and Open/Preview/Remove buttons never overlap on mobile screens.
- **Dedicated Detailed Tutorial Page:**
  - Settings now features a concise **Quick guide & tutorial** card with a button to open a dedicated **Detailed Tutorial** page with search, quick section jump pills, related settings callouts, and concrete real-world examples for every single feature.
